import {
  a as s
} from "../_deps/RUVYHBJQ.js";

// convex/utils/errorHandling.ts
var r = class extends Error {
  constructor(e, n, a = 500, o) {
    super(e);
    this.code = n;
    this.statusCode = a;
    this.details = o;
    this.name = "ConvexError";
  }
  static {
    s(this, "ConvexError");
  }
}, g = class extends r {
  static {
    s(this, "AuthenticationError");
  }
  constructor(t = "\u8A8D\u8A3C\u304C\u5FC5\u8981\u3067\u3059", e) {
    super(t, "AUTH_REQUIRED", 401, e), this.name = "AuthenticationError";
  }
}, c = class extends r {
  static {
    s(this, "AuthorizationError");
  }
  constructor(t = "\u30A2\u30AF\u30BB\u30B9\u6A29\u9650\u304C\u3042\u308A\u307E\u305B\u3093", e) {
    super(t, "ACCESS_DENIED", 403, e), this.name = "AuthorizationError";
  }
}, m = class extends r {
  static {
    s(this, "ValidationError");
  }
  constructor(t, e, n) {
    super(t, "VALIDATION_ERROR", 400, { field: e, ...n }), this.name = "ValidationError";
  }
}, d = class extends r {
  static {
    s(this, "NotFoundError");
  }
  constructor(t, e) {
    let n = e ? `${t} (ID: ${e}) \u304C\u898B\u3064\u304B\u308A\u307E\u305B\u3093` : `${t} \u304C\u898B\u3064\u304B\u308A\u307E\u305B\u3093`;
    super(n, "NOT_FOUND", 404, { resource: t, id: e }), this.name = "NotFoundError";
  }
}, u = class extends r {
  static {
    s(this, "ConflictError");
  }
  constructor(t, e, n) {
    super(t, "CONFLICT", 409, { field: e, value: n }), this.name = "ConflictError";
  }
}, l = class extends r {
  static {
    s(this, "DatabaseError");
  }
  constructor(t, e, n) {
    super(t, "DATABASE_ERROR", 500, { operation: e, ...n }), this.name = "DatabaseError";
  }
}, h = class {
  static {
    s(this, "ErrorHandler");
  }
  /**
   * データベース操作のエラーハンドリング
   */
  static handleDatabaseOperation(t, e, n) {
    return t().catch((a) => {
      throw console.error(`Database operation failed: ${e}`, {
        context: n,
        error: a.message,
        stack: a.stack
      }), a.message.includes("Table not found") ? new l(`\u30C6\u30FC\u30D6\u30EB\u304C\u898B\u3064\u304B\u308A\u307E\u305B\u3093: ${e}`, e, {
        context: n,
        originalError: a.message
      }) : a.message.includes("Index not found") ? new l(`\u30A4\u30F3\u30C7\u30C3\u30AF\u30B9\u304C\u898B\u3064\u304B\u308A\u307E\u305B\u3093: ${e}`, e, {
        context: n,
        originalError: a.message
      }) : a.message.includes("Constraint violation") ? new u("\u30C7\u30FC\u30BF\u306E\u6574\u5408\u6027\u5236\u7D04\u306B\u9055\u53CD\u3057\u3066\u3044\u307E\u3059", void 0, a.message) : new l(`\u30C7\u30FC\u30BF\u30D9\u30FC\u30B9\u64CD\u4F5C\u306B\u5931\u6557\u3057\u307E\u3057\u305F: ${e}`, e, {
        context: n,
        originalError: a.message
      });
    });
  }
  /**
   * ユーザー認証のチェック
   */
  static async validateAuthentication(t) {
    let e = await t.auth.getUserIdentity();
    if (!e)
      throw new g();
    return e;
  }
  /**
   * 管理者権限のチェック - 非推奨
   * 新しいvalidateAdminAccess関数を使用してください
   * @deprecated Use validateAdminAccess in admin.ts instead
   */
  static async validateAdminPermission(t) {
    let e = await this.validateAuthentication(t), n = await this.handleDatabaseOperation(
      () => t.db.query("users").withIndex("by_token", (a) => a.eq("tokenIdentifier", e.tokenIdentifier)).unique(),
      "get_current_user",
      "admin_permission_check"
    );
    if (!n)
      throw new d("\u30E6\u30FC\u30B6\u30FC", e.tokenIdentifier);
    if (!n.isActive)
      throw new c("\u30A2\u30AB\u30A6\u30F3\u30C8\u304C\u7121\u52B9\u3067\u3059");
    if (n.role !== "admin")
      throw new c("\u7BA1\u7406\u8005\u6A29\u9650\u304C\u5FC5\u8981\u3067\u3059");
    return n;
  }
  /**
   * リソースの存在確認
   */
  static async validateResourceExists(t, e, n, a) {
    let o = await this.handleDatabaseOperation(
      a,
      `get_${e}`,
      `resource_id: ${n}`
    );
    if (!o)
      throw new d(e, n);
    return o;
  }
  /**
   * メールアドレスの重複チェック
   */
  static async validateEmailUniqueness(t, e, n) {
    let a = await this.handleDatabaseOperation(
      () => t.db.query("users").withIndex("by_email", (o) => o.eq("email", e)).first(),
      "check_email_uniqueness",
      `email: ${e}`
    );
    if (a && (!n || a._id !== n))
      throw new u("\u3053\u306E\u30E1\u30FC\u30EB\u30A2\u30C9\u30EC\u30B9\u306F\u65E2\u306B\u767B\u9332\u3055\u308C\u3066\u3044\u307E\u3059", "email", e);
  }
  /**
   * 入力値のバリデーション
   */
  static validateInput(t, e, n) {
    for (let a of n)
      if (!a.validate(t))
        throw new m(
          a.message || `${e} \u306E\u5F62\u5F0F\u304C\u6B63\u3057\u304F\u3042\u308A\u307E\u305B\u3093`,
          e,
          { value: t, rule: a.name }
        );
  }
  /**
   * 統計データの安全な計算
   */
  static safeCalculation(t, e, n) {
    try {
      return t();
    } catch (a) {
      return console.warn(`Calculation failed: ${n}`, a), e;
    }
  }
}, x = {
  required: /* @__PURE__ */ s((i) => ({
    name: "required",
    validate: /* @__PURE__ */ s((t) => t != null && t !== "", "validate"),
    message: `${i} \u306F\u5FC5\u9808\u3067\u3059`
  }), "required"),
  email: /* @__PURE__ */ s(() => ({
    name: "email",
    validate: /* @__PURE__ */ s((i) => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(i), "validate"),
    message: "\u30E1\u30FC\u30EB\u30A2\u30C9\u30EC\u30B9\u306E\u5F62\u5F0F\u304C\u6B63\u3057\u304F\u3042\u308A\u307E\u305B\u3093"
  }), "email"),
  minLength: /* @__PURE__ */ s((i) => ({
    name: "minLength",
    validate: /* @__PURE__ */ s((t) => !!(t && t.length >= i), "validate"),
    message: `${i}\u6587\u5B57\u4EE5\u4E0A\u3067\u5165\u529B\u3057\u3066\u304F\u3060\u3055\u3044`
  }), "minLength"),
  maxLength: /* @__PURE__ */ s((i) => ({
    name: "maxLength",
    validate: /* @__PURE__ */ s((t) => !t || t.length <= i, "validate"),
    message: `${i}\u6587\u5B57\u4EE5\u4E0B\u3067\u5165\u529B\u3057\u3066\u304F\u3060\u3055\u3044`
  }), "maxLength"),
  role: /* @__PURE__ */ s(() => ({
    name: "role",
    validate: /* @__PURE__ */ s((i) => ["admin", "manager", "employee", "trainer"].includes(i), "validate"),
    message: "\u6709\u52B9\u306A\u5F79\u8077\u3092\u9078\u629E\u3057\u3066\u304F\u3060\u3055\u3044"
  }), "role")
}, y = class {
  static {
    s(this, "Logger");
  }
  static info(t, e) {
    console.log(`[INFO] ${t}`, e ? JSON.stringify(e, null, 2) : "");
  }
  static warn(t, e) {
    console.warn(`[WARN] ${t}`, e ? JSON.stringify(e, null, 2) : "");
  }
  static error(t, e, n) {
    console.error(`[ERROR] ${t}`, {
      error: e?.message || e,
      stack: e?.stack,
      data: n
    });
  }
  static debug(t, e) {
  }
};
export {
  g as AuthenticationError,
  c as AuthorizationError,
  u as ConflictError,
  r as ConvexError,
  l as DatabaseError,
  h as ErrorHandler,
  y as Logger,
  d as NotFoundError,
  m as ValidationError,
  x as ValidationRules
};
//# sourceMappingURL=errorHandling.js.map
