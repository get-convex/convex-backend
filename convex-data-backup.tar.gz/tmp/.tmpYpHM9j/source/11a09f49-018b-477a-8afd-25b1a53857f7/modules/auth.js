import {
  a,
  b,
  c,
  d,
  e,
  f,
  g,
  h,
  i,
  j
} from "./_deps/SZVQRWFS.js";
import "./_deps/3TDUHHJO.js";
import "./_deps/RUVYHBJQ.js";
export {
  a as USER_ROLES,
  i as checkAuth,
  j as checkUser,
  c as requireAdmin,
  h as requireCriticalAdminAuth,
  g as requireEnhancedAuth,
  f as requireOwnershipOrAdmin,
  e as requireResourceAccess,
  d as requireTrainer,
  b as requireUser
};
//# sourceMappingURL=auth.js.map
