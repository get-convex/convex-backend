import {
  a as _,
  d as m
} from "./_deps/75JH2J25.js";
import "./_deps/6XQQNYIR.js";
import {
  j as e,
  n as y
} from "./_deps/3TDUHHJO.js";
import {
  a as i
} from "./_deps/RUVYHBJQ.js";

// convex/migration.ts
y();
var b = m({
  args: {},
  returns: e.object({
    success: e.boolean(),
    message: e.string(),
    migrated_modules: e.number(),
    skipped_modules: e.number(),
    errors: e.array(e.string())
  }),
  handler: /* @__PURE__ */ i(async (s) => {
    let t = [], n = 0, o = 0;
    try {
      let a;
      try {
        a = await s.db.query("moduleContents").collect();
      } catch {
        return {
          success: !0,
          message: "moduleContents\u30C6\u30FC\u30D6\u30EB\u304C\u5B58\u5728\u3057\u306A\u3044\u305F\u3081\u3001\u79FB\u884C\u306F\u4E0D\u8981\u3067\u3059",
          migrated_modules: 0,
          skipped_modules: 0,
          errors: []
        };
      }
      if (a.length === 0)
        return {
          success: !0,
          message: "\u79FB\u884C\u5BFE\u8C61\u306EmoduleContents\u30C7\u30FC\u30BF\u304C\u5B58\u5728\u3057\u307E\u305B\u3093",
          migrated_modules: 0,
          skipped_modules: 0,
          errors: []
        };
      let u = /* @__PURE__ */ new Map();
      for (let r of a) {
        let l = r.module_id;
        u.has(l) || u.set(l, []), u.get(l).push(r);
      }
      for (let [r, l] of u)
        try {
          if (!await s.db.get(r)) {
            t.push(`trainingModule not found for id: ${r}`), o++;
            continue;
          }
          let c = l.sort((g, h) => g.order_index - h.order_index)[0];
          await s.db.patch(r, {
            content: c.content,
            content_type: c.content_type,
            file_url: c.file_url,
            file_type: c.file_type
          }), n++;
        } catch (d) {
          let c = d instanceof Error ? d.message : "Unknown error";
          t.push(`Failed to migrate module ${r}: ${c}`), o++;
        }
      return {
        success: t.length === 0,
        message: t.length === 0 ? `${n}\u500B\u306E\u30E2\u30B8\u30E5\u30FC\u30EB\u306E\u79FB\u884C\u304C\u5B8C\u4E86\u3057\u307E\u3057\u305F` : `${n}\u500B\u306E\u30E2\u30B8\u30E5\u30FC\u30EB\u3092\u79FB\u884C\u3057\u307E\u3057\u305F\uFF08${t.length}\u500B\u306E\u30A8\u30E9\u30FC\uFF09`,
        migrated_modules: n,
        skipped_modules: o,
        errors: t
      };
    } catch (a) {
      let u = a instanceof Error ? a.message : "Unknown error";
      return {
        success: !1,
        message: `\u79FB\u884C\u51E6\u7406\u4E2D\u306B\u81F4\u547D\u7684\u306A\u30A8\u30E9\u30FC\u304C\u767A\u751F\u3057\u307E\u3057\u305F: ${u}`,
        migrated_modules: n,
        skipped_modules: o,
        errors: [u]
      };
    }
  }, "handler")
}), M = _({
  args: {},
  returns: e.object({
    has_module_contents_table: e.boolean(),
    module_contents_count: e.number(),
    training_modules_count: e.number(),
    training_modules_with_content: e.number(),
    ready_for_migration: e.boolean()
  }),
  handler: /* @__PURE__ */ i(async (s) => {
    try {
      let t, n = !0, o = 0;
      try {
        t = await s.db.query("moduleContents").collect(), o = t.length;
      } catch {
        n = !1;
      }
      let a = await s.db.query("trainingModules").collect(), u = a.length, r = a.filter(
        (d) => d.content || d.content_type
      ).length, l = n && o > 0 && r === 0;
      return {
        has_module_contents_table: n,
        module_contents_count: o,
        training_modules_count: u,
        training_modules_with_content: r,
        ready_for_migration: l
      };
    } catch {
      return {
        has_module_contents_table: !1,
        module_contents_count: 0,
        training_modules_count: 0,
        training_modules_with_content: 0,
        ready_for_migration: !1
      };
    }
  }, "handler")
}), C = m({
  args: {},
  returns: e.object({
    success: e.boolean(),
    message: e.string(),
    deleted_contents: e.number()
  }),
  handler: /* @__PURE__ */ i(async (s) => {
    try {
      let t;
      try {
        t = await s.db.query("moduleContents").collect();
      } catch {
        return {
          success: !0,
          message: "moduleContents\u30C6\u30FC\u30D6\u30EB\u304C\u5B58\u5728\u3057\u306A\u3044\u305F\u3081\u3001\u30AF\u30EA\u30FC\u30F3\u30A2\u30C3\u30D7\u306F\u4E0D\u8981\u3067\u3059",
          deleted_contents: 0
        };
      }
      let n = 0;
      for (let o of t)
        await s.db.delete(o._id), n++;
      return {
        success: !0,
        message: `${n}\u500B\u306EmoduleContents\u30EC\u30B3\u30FC\u30C9\u3092\u524A\u9664\u3057\u307E\u3057\u305F`,
        deleted_contents: n
      };
    } catch (t) {
      return {
        success: !1,
        message: `\u30AF\u30EA\u30FC\u30F3\u30A2\u30C3\u30D7\u4E2D\u306B\u30A8\u30E9\u30FC\u304C\u767A\u751F\u3057\u307E\u3057\u305F: ${t instanceof Error ? t.message : "Unknown error"}`,
        deleted_contents: 0
      };
    }
  }, "handler")
});
export {
  M as checkMigrationStatus,
  C as cleanupModuleContents,
  b as migrateModuleContentsToTrainingModules
};
//# sourceMappingURL=migration.js.map
