"use node";
import {
  d as l
} from "./_deps/node/PDGHC3PS.js";
import {
  a as s
} from "./_deps/node/UDHF6CTX.js";
import {
  a
} from "./_deps/node/V7X2J7BI.js";

// convex/vertexTokenManager.ts
var d = l({
  args: {},
  returns: s.object({
    success: s.boolean(),
    message: s.string(),
    newToken: s.optional(s.string()),
    updatedAt: s.number()
  }),
  handler: /* @__PURE__ */ a(async (i, g) => {
    try {
      console.log("[refreshVertexAccessToken] \u30A2\u30AF\u30BB\u30B9\u30C8\u30FC\u30AF\u30F3\u66F4\u65B0\u958B\u59CB");
      let { exec: e } = await import("child_process"), { promisify: r } = await import("util"), n = r(e);
      console.log("[refreshVertexAccessToken] gcloud \u30B3\u30DE\u30F3\u30C9\u5B9F\u884C");
      let { stdout: o, stderr: c } = await n("gcloud auth print-access-token");
      if (c)
        return console.error("[refreshVertexAccessToken] gcloud \u30B3\u30DE\u30F3\u30C9\u30A8\u30E9\u30FC:", c), {
          success: !1,
          message: `gcloud \u30B3\u30DE\u30F3\u30C9\u30A8\u30E9\u30FC: ${c}`,
          updatedAt: Date.now()
        };
      let t = o.trim();
      return !t || t.length < 10 ? (console.error("[refreshVertexAccessToken] \u7121\u52B9\u306A\u30C8\u30FC\u30AF\u30F3:", t), {
        success: !1,
        message: "\u7121\u52B9\u306A\u30A2\u30AF\u30BB\u30B9\u30C8\u30FC\u30AF\u30F3\u304C\u53D6\u5F97\u3055\u308C\u307E\u3057\u305F",
        updatedAt: Date.now()
      }) : (console.log("[refreshVertexAccessToken] \u65B0\u3057\u3044\u30C8\u30FC\u30AF\u30F3\u53D6\u5F97\u6210\u529F"), console.log(`[refreshVertexAccessToken] \u30C8\u30FC\u30AF\u30F3\u9577: ${t.length} \u6587\u5B57`), console.log("[refreshVertexAccessToken] \u74B0\u5883\u5909\u6570\u66F4\u65B0\u306FCI/CD\u307E\u305F\u306F\u624B\u52D5\u3067\u5B9F\u884C\u3057\u3066\u304F\u3060\u3055\u3044"), console.log(`[refreshVertexAccessToken] \u65B0\u3057\u3044\u30C8\u30FC\u30AF\u30F3: ${t.substring(0, 20)}...`), {
        success: !0,
        message: "\u30A2\u30AF\u30BB\u30B9\u30C8\u30FC\u30AF\u30F3\u66F4\u65B0\u6210\u529F",
        newToken: t.substring(0, 20) + "...",
        // セキュリティのため一部のみ返す
        updatedAt: Date.now()
      });
    } catch (e) {
      return console.error("[refreshVertexAccessToken] \u30A8\u30E9\u30FC:", e), {
        success: !1,
        message: `\u30A8\u30E9\u30FC: ${e instanceof Error ? e.message : "Unknown error"}`,
        updatedAt: Date.now()
      };
    }
  }, "handler")
}), k = l({
  args: {},
  returns: s.object({
    isValid: s.boolean(),
    message: s.string(),
    checkedAt: s.number()
  }),
  handler: /* @__PURE__ */ a(async (i, g) => {
    try {
      console.log("[checkTokenHealth] \u30C8\u30FC\u30AF\u30F3\u6709\u52B9\u6027\u30C1\u30A7\u30C3\u30AF\u958B\u59CB");
      let e = process.env.VERTEX_AI_ACCESS_TOKEN;
      if (!e)
        return {
          isValid: !1,
          message: "VERTEX_AI_ACCESS_TOKEN \u304C\u8A2D\u5B9A\u3055\u308C\u3066\u3044\u307E\u305B\u3093",
          checkedAt: Date.now()
        };
      let r = `https://us-central1-aiplatform.googleapis.com/v1/projects/${process.env.VERTEX_AI_PROJECT_ID}/locations/us-central1/publishers/google/models/gemini-2.5-flash:generateContent`, n = {
        contents: [{
          role: "user",
          parts: [{ text: "Hello" }]
        }],
        generationConfig: {
          temperature: 0.1,
          maxOutputTokens: 10
        }
      }, o = await fetch(r, {
        method: "POST",
        headers: {
          Authorization: `Bearer ${e}`,
          "Content-Type": "application/json"
        },
        body: JSON.stringify(n)
      });
      return o.ok ? (console.log("[checkTokenHealth] \u30C8\u30FC\u30AF\u30F3\u6709\u52B9"), {
        isValid: !0,
        message: "\u30A2\u30AF\u30BB\u30B9\u30C8\u30FC\u30AF\u30F3\u306F\u6709\u52B9\u3067\u3059",
        checkedAt: Date.now()
      }) : (console.log("[checkTokenHealth] \u30C8\u30FC\u30AF\u30F3\u7121\u52B9\u307E\u305F\u306F\u30A8\u30E9\u30FC:", o.status), {
        isValid: !1,
        message: `API\u547C\u3073\u51FA\u3057\u5931\u6557: ${o.status} ${o.statusText}`,
        checkedAt: Date.now()
      });
    } catch (e) {
      return console.error("[checkTokenHealth] \u30A8\u30E9\u30FC:", e), {
        isValid: !1,
        message: `\u30A8\u30E9\u30FC: ${e instanceof Error ? e.message : "Unknown error"}`,
        checkedAt: Date.now()
      };
    }
  }, "handler")
});
export {
  k as checkTokenHealth,
  d as refreshVertexAccessToken
};
//# sourceMappingURL=vertexTokenManager.js.map
