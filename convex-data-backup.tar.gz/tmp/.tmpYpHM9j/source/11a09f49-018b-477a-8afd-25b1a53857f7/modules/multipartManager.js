"use node";
import {
  b as d
} from "./_deps/node/VTOLWO7E.js";
import {
  c as E
} from "./_deps/node/PDGHC3PS.js";
import {
  a as t
} from "./_deps/node/UDHF6CTX.js";
import {
  a as P
} from "./_deps/node/V7X2J7BI.js";

// convex/multipartManager.ts
var B = E({
  args: {
    fileUploadId: t.id("fileUploads"),
    filename: t.string(),
    contentType: t.string(),
    fileSize: t.number()
  },
  returns: t.object({
    uploadId: t.string(),
    parts: t.array(
      t.object({
        partNumber: t.number(),
        uploadUrl: t.string(),
        startByte: t.number(),
        endByte: t.number()
      })
    )
  }),
  handler: /* @__PURE__ */ P(async (l, e) => {
    try {
      let r = process.env.GOOGLE_CLOUD_PROJECT_ID, a = process.env.GCS_BUCKET_NAME, o = process.env.GCS_CLIENT_EMAIL, n = process.env.GCS_PRIVATE_KEY_BASE64;
      if (!r || !a || !o || !n)
        throw new Error("GCS\u74B0\u5883\u5909\u6570\u304C\u8A2D\u5B9A\u3055\u308C\u3066\u3044\u307E\u305B\u3093");
      let { Storage: i } = await import("./_deps/node/57Z7VQNY.js"), m = Buffer.from(n, "base64").toString("utf-8"), g = {
        type: "service_account",
        project_id: r,
        private_key: m,
        client_email: o,
        auth_uri: "https://accounts.google.com/o/oauth2/auth",
        token_uri: "https://oauth2.googleapis.com/token",
        auth_provider_x509_cert_url: "https://www.googleapis.com/oauth2/v1/certs",
        client_x509_cert_url: `https://www.googleapis.com/robot/v1/metadata/x509/${encodeURIComponent(o)}`,
        universe_domain: "googleapis.com"
      }, _ = new i({
        projectId: r,
        credentials: g
      }).bucket(a), h = Date.now(), b = Math.random().toString(36).substring(2, 15), v = encodeURIComponent(e.filename).replace(/%/g, "_").substring(0, 100), f = `multipart/${h}-${b}-${v}`, S = _.file(f), p = `${h}-${b}`, c = 5 * 1024 * 1024, s = Math.ceil(e.fileSize / c), y = [];
      for (let u = 0; u < s; u++) {
        let U = u + 1, w = u * c, C = Math.min((u + 1) * c - 1, e.fileSize - 1), [M] = await S.getSignedUrl({
          version: "v4",
          action: "write",
          expires: Date.now() + 60 * 60 * 1e3,
          // 1時間後
          contentType: e.contentType,
          extensionHeaders: {
            "x-goog-content-length-range": `${C - w + 1},${C - w + 1}`
          }
        });
        y.push({
          partNumber: U,
          uploadUrl: M,
          startByte: w,
          endByte: C
        });
      }
      return await l.runMutation(d.multipartManagerQueries.storeMultipartUploadInfo, {
        fileUploadId: e.fileUploadId,
        uploadId: p,
        gcpFilePath: f,
        filename: e.filename,
        contentType: e.contentType,
        fileSize: e.fileSize,
        totalParts: s,
        status: "initiated"
      }), console.log("[initiateMultipartUpload] Initiated multipart upload:", {
        uploadId: p,
        gcpFilePath: f,
        totalParts: s
      }), {
        uploadId: p,
        parts: y
      };
    } catch (r) {
      throw console.error("[initiateMultipartUpload] \u30A8\u30E9\u30FC:", r), new Error(
        `\u30DE\u30EB\u30C1\u30D1\u30FC\u30C8\u30A2\u30C3\u30D7\u30ED\u30FC\u30C9\u958B\u59CB\u306B\u5931\u6557\u3057\u307E\u3057\u305F: ${r instanceof Error ? r.message : "\u4E0D\u660E\u306A\u30A8\u30E9\u30FC"}`
      );
    }
  }, "handler")
}), k = E({
  args: {
    fileUploadId: t.id("fileUploads"),
    uploadId: t.string(),
    partNumber: t.number(),
    etag: t.string()
  },
  returns: t.object({
    success: t.boolean(),
    completedParts: t.number(),
    totalParts: t.number(),
    isComplete: t.boolean()
  }),
  handler: /* @__PURE__ */ P(async (l, e) => {
    try {
      await l.runMutation(d.multipartManagerQueries.markPartComplete, {
        fileUploadId: e.fileUploadId,
        uploadId: e.uploadId,
        partNumber: e.partNumber,
        etag: e.etag
      });
      let r = await l.runQuery(
        d.multipartManagerQueries.getMultipartUploadInfo,
        {
          fileUploadId: e.fileUploadId,
          uploadId: e.uploadId
        }
      );
      if (!r)
        throw new Error("\u30A2\u30C3\u30D7\u30ED\u30FC\u30C9\u60C5\u5831\u304C\u898B\u3064\u304B\u308A\u307E\u305B\u3093");
      let a = r, o = a.completedParts?.length || 0, n = o === a.totalParts;
      return n && (await l.runMutation(d.multipartManagerQueries.markUploadComplete, {
        fileUploadId: e.fileUploadId,
        uploadId: e.uploadId
      }), console.log("[completePartUpload] Multipart upload completed:", {
        uploadId: e.uploadId,
        totalParts: a.totalParts
      })), {
        success: !0,
        completedParts: o,
        totalParts: a.totalParts,
        isComplete: n
      };
    } catch (r) {
      throw console.error("[completePartUpload] \u30A8\u30E9\u30FC:", r), new Error(
        `\u30D1\u30FC\u30C8\u5B8C\u4E86\u8A18\u9332\u306B\u5931\u6557\u3057\u307E\u3057\u305F: ${r instanceof Error ? r.message : "\u4E0D\u660E\u306A\u30A8\u30E9\u30FC"}`
      );
    }
  }, "handler")
}), G = E({
  args: {
    fileUploadId: t.id("fileUploads"),
    uploadId: t.string(),
    partNumber: t.number(),
    errorMessage: t.string()
  },
  returns: t.object({
    uploadUrl: t.string(),
    retryCount: t.number()
  }),
  handler: /* @__PURE__ */ P(async (l, e) => {
    try {
      await l.runMutation(d.multipartManagerQueries.recordRetryAttempt, {
        fileUploadId: e.fileUploadId,
        uploadId: e.uploadId,
        partNumber: e.partNumber,
        errorMessage: e.errorMessage
      });
      let r = await l.runQuery(
        d.multipartManagerQueries.getMultipartUploadInfo,
        {
          fileUploadId: e.fileUploadId,
          uploadId: e.uploadId
        }
      );
      if (!r)
        throw new Error("\u30A2\u30C3\u30D7\u30ED\u30FC\u30C9\u60C5\u5831\u304C\u898B\u3064\u304B\u308A\u307E\u305B\u3093");
      let a = r, o = process.env.GOOGLE_CLOUD_PROJECT_ID, n = process.env.GCS_BUCKET_NAME, i = process.env.GCS_CLIENT_EMAIL, m = process.env.GCS_PRIVATE_KEY_BASE64;
      if (!o || !n || !i || !m)
        throw new Error("GCS\u74B0\u5883\u5909\u6570\u304C\u8A2D\u5B9A\u3055\u308C\u3066\u3044\u307E\u305B\u3093");
      let { Storage: g } = await import("./_deps/node/57Z7VQNY.js"), I = Buffer.from(m, "base64").toString("utf-8"), _ = {
        type: "service_account",
        project_id: o,
        private_key: I,
        client_email: i,
        auth_uri: "https://accounts.google.com/o/oauth2/auth",
        token_uri: "https://oauth2.googleapis.com/token",
        auth_provider_x509_cert_url: "https://www.googleapis.com/oauth2/v1/certs",
        client_x509_cert_url: `https://www.googleapis.com/robot/v1/metadata/x509/${encodeURIComponent(i)}`,
        universe_domain: "googleapis.com"
      }, b = new g({
        projectId: o,
        credentials: _
      }).bucket(n);
      if (!a.gcpFilePath || !a.contentType)
        throw new Error("\u30A2\u30C3\u30D7\u30ED\u30FC\u30C9\u60C5\u5831\u304C\u4E0D\u5B8C\u5168\u3067\u3059");
      let v = b.file(a.gcpFilePath), [f] = await v.getSignedUrl({
        version: "v4",
        action: "write",
        expires: Date.now() + 60 * 60 * 1e3,
        // 1時間後
        contentType: a.contentType
      }), p = a.retryAttempts?.find(
        (c) => c.partNumber === e.partNumber
      )?.attempts || 0;
      return console.log("[retryPartUpload] Generated retry URL:", {
        partNumber: e.partNumber,
        retryCount: p
      }), {
        uploadUrl: f,
        retryCount: p
      };
    } catch (r) {
      throw console.error("[retryPartUpload] \u30A8\u30E9\u30FC:", r), new Error(
        `\u30D1\u30FC\u30C8\u518D\u8A66\u884C\u306B\u5931\u6557\u3057\u307E\u3057\u305F: ${r instanceof Error ? r.message : "\u4E0D\u660E\u306A\u30A8\u30E9\u30FC"}`
      );
    }
  }, "handler")
}), x = E({
  args: {
    fileUploadId: t.id("fileUploads")
  },
  returns: t.union(
    t.object({
      uploadId: t.string(),
      gcpFilePath: t.string(),
      completedParts: t.array(t.number()),
      pendingParts: t.array(
        t.object({
          partNumber: t.number(),
          uploadUrl: t.string(),
          startByte: t.number(),
          endByte: t.number()
        })
      ),
      totalParts: t.number(),
      fileSize: t.number(),
      contentType: t.string()
    }),
    t.null()
  ),
  handler: /* @__PURE__ */ P(async (l, e) => {
    try {
      let r = await l.runQuery(
        d.multipartManagerQueries.getLatestMultipartUpload,
        {
          fileUploadId: e.fileUploadId
        }
      );
      if (!r || r.status === "completed")
        return null;
      let o = r, n = o.completedParts?.map(
        (s) => s.partNumber
      ) || [], i = process.env.GOOGLE_CLOUD_PROJECT_ID, m = process.env.GCS_BUCKET_NAME, g = process.env.GCS_CLIENT_EMAIL, I = process.env.GCS_PRIVATE_KEY_BASE64;
      if (!i || !m || !g || !I)
        throw new Error("GCS\u74B0\u5883\u5909\u6570\u304C\u8A2D\u5B9A\u3055\u308C\u3066\u3044\u307E\u305B\u3093");
      let { Storage: _ } = await import("./_deps/node/57Z7VQNY.js"), h = Buffer.from(I, "base64").toString("utf-8"), b = {
        type: "service_account",
        project_id: i,
        private_key: h,
        client_email: g,
        auth_uri: "https://accounts.google.com/o/oauth2/auth",
        token_uri: "https://oauth2.googleapis.com/token",
        auth_provider_x509_cert_url: "https://www.googleapis.com/oauth2/v1/certs",
        client_x509_cert_url: `https://www.googleapis.com/robot/v1/metadata/x509/${encodeURIComponent(g)}`,
        universe_domain: "googleapis.com"
      }, S = new _({
        projectId: i,
        credentials: b
      }).bucket(m).file(o.gcpFilePath), p = 5 * 1024 * 1024, c = [];
      for (let s = 0; s < o.totalParts; s++) {
        let y = s + 1;
        if (n.includes(y))
          continue;
        let u = s * p, U = Math.min((s + 1) * p - 1, o.fileSize - 1), [w] = await S.getSignedUrl({
          version: "v4",
          action: "write",
          expires: Date.now() + 60 * 60 * 1e3,
          // 1時間後
          contentType: o.contentType,
          extensionHeaders: {
            "x-goog-content-length-range": `${U - u + 1},${U - u + 1}`
          }
        });
        c.push({
          partNumber: y,
          uploadUrl: w,
          startByte: u,
          endByte: U
        });
      }
      return console.log("[resumeMultipartUpload] Resuming upload:", {
        uploadId: o.uploadId,
        completedParts: n.length,
        pendingParts: c.length,
        totalParts: o.totalParts
      }), {
        uploadId: o.uploadId,
        gcpFilePath: o.gcpFilePath,
        completedParts: n,
        pendingParts: c,
        totalParts: o.totalParts,
        fileSize: o.fileSize,
        contentType: o.contentType
      };
    } catch (r) {
      throw console.error("[resumeMultipartUpload] \u30A8\u30E9\u30FC:", r), new Error(
        `\u30DE\u30EB\u30C1\u30D1\u30FC\u30C8\u30A2\u30C3\u30D7\u30ED\u30FC\u30C9\u518D\u958B\u306B\u5931\u6557\u3057\u307E\u3057\u305F: ${r instanceof Error ? r.message : "\u4E0D\u660E\u306A\u30A8\u30E9\u30FC"}`
      );
    }
  }, "handler")
});
export {
  k as completePartUpload,
  B as initiateMultipartUpload,
  x as resumeMultipartUpload,
  G as retryPartUpload
};
//# sourceMappingURL=multipartManager.js.map
