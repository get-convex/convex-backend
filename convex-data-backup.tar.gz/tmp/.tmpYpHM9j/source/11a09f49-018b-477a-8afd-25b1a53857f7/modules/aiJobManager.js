"use node";
import {
  d as e
} from "./_deps/node/PDGHC3PS.js";
import {
  a as o
} from "./_deps/node/UDHF6CTX.js";
import {
  a as r
} from "./_deps/node/V7X2J7BI.js";

// convex/aiJobManager.ts
var s = e({
  args: {
    job_id: o.id("aiProcessingJobs")
  },
  returns: o.null(),
  handler: /* @__PURE__ */ r(async (i, n) => (console.log(`[retryFailedJob] \u30B8\u30E7\u30D6\u30EA\u30C8\u30E9\u30A4\u6A5F\u80FD\u306F\u4E00\u6642\u7684\u306B\u7121\u52B9\u5316\u3055\u308C\u3066\u3044\u307E\u3059: ${n.job_id}`), null), "handler")
});
export {
  s as retryFailedJob
};
//# sourceMappingURL=aiJobManager.js.map
