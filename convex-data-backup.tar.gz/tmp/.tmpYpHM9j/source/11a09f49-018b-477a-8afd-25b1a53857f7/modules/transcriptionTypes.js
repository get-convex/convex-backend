import {
  a as p,
  b as d,
  c as s
} from "./_deps/75JH2J25.js";
import "./_deps/6XQQNYIR.js";
import {
  j as e,
  n as l
} from "./_deps/3TDUHHJO.js";
import {
  a as o
} from "./_deps/RUVYHBJQ.js";

// convex/transcriptionTypes.ts
l();
var m = d({
  args: {},
  returns: e.array(
    e.object({
      _id: e.id("transcriptionTypes"),
      name: e.string(),
      description: e.string(),
      key: e.string(),
      is_active: e.boolean()
    })
  ),
  handler: /* @__PURE__ */ o(async (r) => await r.db.query("transcriptionTypes").withIndex("by_is_active", (t) => t.eq("is_active", !0)).collect(), "handler")
}), b = p({
  args: {},
  returns: e.array(
    e.object({
      _id: e.optional(e.id("transcriptionTypes")),
      name: e.string(),
      description: e.string(),
      key: e.string(),
      prompt: e.string(),
      category: e.optional(e.string()),
      usage_count: e.number()
    })
  ),
  handler: /* @__PURE__ */ o(async (r) => (await r.db.query("transcriptionTypes").withIndex("by_is_active", (n) => n.eq("is_active", !0)).filter((n) => n.eq(n.field("available_for_quick_transcription"), !0)).collect()).map((n) => ({
    _id: n._id,
    name: n.name,
    description: n.description,
    key: n.key,
    prompt: n.prompt,
    category: n.category,
    usage_count: n.usage_count
  })), "handler")
}), w = d({
  args: {
    key: e.string()
  },
  returns: e.union(
    e.object({
      _id: e.id("transcriptionTypes"),
      _creationTime: e.number(),
      name: e.string(),
      description: e.string(),
      key: e.string(),
      prompt: e.string(),
      template: e.optional(e.string()),
      category: e.optional(e.string()),
      is_system: e.boolean(),
      is_active: e.boolean(),
      available_for_quick_transcription: e.boolean(),
      available_for_video_upload: e.boolean(),
      created_by: e.optional(e.string()),
      created_at: e.number(),
      updated_at: e.number(),
      display_order: e.number(),
      icon: e.optional(e.string()),
      color: e.optional(e.string()),
      usage_count: e.number(),
      last_used_at: e.optional(e.number())
    }),
    e.null()
  ),
  handler: /* @__PURE__ */ o(async (r, t) => await r.db.query("transcriptionTypes").withIndex("by_key", (n) => n.eq("key", t.key)).first(), "handler")
}), f = p({
  args: {},
  returns: e.array(
    e.object({
      _id: e.id("transcriptionTypes"),
      _creationTime: e.number(),
      name: e.string(),
      description: e.string(),
      key: e.string(),
      prompt: e.string(),
      template: e.optional(e.string()),
      category: e.optional(e.string()),
      is_system: e.boolean(),
      is_active: e.boolean(),
      available_for_quick_transcription: e.boolean(),
      available_for_video_upload: e.boolean(),
      created_by: e.optional(e.string()),
      created_at: e.number(),
      updated_at: e.number(),
      display_order: e.number(),
      icon: e.optional(e.string()),
      color: e.optional(e.string()),
      usage_count: e.number(),
      last_used_at: e.optional(e.number())
    })
  ),
  handler: /* @__PURE__ */ o(async (r) => {
    if (!await r.auth.getUserIdentity())
      throw new Error("\u8A8D\u8A3C\u304C\u5FC5\u8981\u3067\u3059");
    return await r.db.query("transcriptionTypes").order("desc").collect();
  }, "handler")
}), T = s({
  args: {
    name: e.string(),
    prompt: e.string()
  },
  returns: e.id("transcriptionTypes"),
  handler: /* @__PURE__ */ o(async (r, t) => {
    if (!await r.auth.getUserIdentity())
      throw new Error("\u8A8D\u8A3C\u304C\u5FC5\u8981\u3067\u3059");
    let i = Date.now();
    return await r.db.insert("transcriptionTypes", {
      name: t.name,
      description: t.name,
      // 名前を説明にも使用
      key: t.name.toLowerCase().replace(/\s+/g, "_"),
      // 名前からキーを自動生成
      prompt: t.prompt,
      template: void 0,
      category: "\u57FA\u672C",
      is_system: !1,
      is_active: !0,
      available_for_quick_transcription: !0,
      available_for_video_upload: !0,
      created_by: void 0,
      created_at: i,
      updated_at: i,
      display_order: 1,
      icon: void 0,
      color: void 0,
      usage_count: 0,
      last_used_at: void 0
    });
  }, "handler")
}), k = s({
  args: {
    id: e.id("transcriptionTypes"),
    name: e.string(),
    prompt: e.string()
  },
  returns: e.null(),
  handler: /* @__PURE__ */ o(async (r, t) => {
    if (!await r.auth.getUserIdentity())
      throw new Error("\u8A8D\u8A3C\u304C\u5FC5\u8981\u3067\u3059");
    if (!await r.db.get(t.id))
      throw new Error("\u6307\u5B9A\u3055\u308C\u305F\u6587\u5B57\u8D77\u3053\u3057\u30BF\u30A4\u30D7\u304C\u898B\u3064\u304B\u308A\u307E\u305B\u3093");
    let a = Date.now();
    return await r.db.patch(t.id, {
      name: t.name,
      description: t.name,
      // 名前を説明にも使用
      key: t.name.toLowerCase().replace(/\s+/g, "_"),
      // 名前からキーを自動生成（システムタイプ以外）
      prompt: t.prompt,
      updated_at: a
    }), null;
  }, "handler")
}), v = s({
  args: {
    id: e.id("transcriptionTypes")
  },
  returns: e.null(),
  handler: /* @__PURE__ */ o(async (r, t) => {
    if (!await r.auth.getUserIdentity())
      throw new Error("\u8A8D\u8A3C\u304C\u5FC5\u8981\u3067\u3059");
    let i = await r.db.get(t.id);
    if (!i)
      throw new Error("\u6307\u5B9A\u3055\u308C\u305F\u6587\u5B57\u8D77\u3053\u3057\u30BF\u30A4\u30D7\u304C\u898B\u3064\u304B\u308A\u307E\u305B\u3093");
    if (i.is_system)
      throw new Error("\u30B7\u30B9\u30C6\u30E0\u30BF\u30A4\u30D7\u306F\u524A\u9664\u3067\u304D\u307E\u305B\u3093");
    return await r.db.delete(t.id), null;
  }, "handler")
}), h = p({
  args: {},
  returns: e.array(
    e.object({
      _id: e.id("transcriptionTypes"),
      _creationTime: e.number(),
      name: e.string(),
      description: e.string(),
      key: e.string(),
      prompt: e.string(),
      template: e.optional(e.string()),
      category: e.optional(e.string()),
      is_system: e.boolean(),
      is_active: e.boolean(),
      available_for_quick_transcription: e.boolean(),
      available_for_video_upload: e.boolean(),
      created_by: e.optional(e.string()),
      created_at: e.number(),
      updated_at: e.number(),
      display_order: e.number(),
      icon: e.optional(e.string()),
      color: e.optional(e.string()),
      usage_count: e.number(),
      last_used_at: e.optional(e.number())
    })
  ),
  handler: /* @__PURE__ */ o(async (r) => await r.db.query("transcriptionTypes").withIndex("by_is_active", (t) => t.eq("is_active", !0)).filter((t) => t.eq(t.field("available_for_video_upload"), !0)).collect(), "handler")
}), q = s({
  args: {
    key: e.string()
  },
  returns: e.null(),
  handler: /* @__PURE__ */ o(async (r, t) => {
    let n = await r.db.query("transcriptionTypes").withIndex("by_key", (a) => a.eq("key", t.key)).first();
    if (!n)
      return console.warn(`Transcription type with key "${t.key}" not found`), null;
    let i = Date.now();
    return await r.db.patch(n._id, {
      usage_count: n.usage_count + 1,
      last_used_at: i,
      updated_at: i
    }), null;
  }, "handler")
}), x = s({
  args: {},
  returns: e.object({
    success: e.boolean(),
    message: e.string(),
    created: e.number()
  }),
  handler: /* @__PURE__ */ o(async (r) => {
    let t = [
      {
        key: "standard",
        name: "\u6A19\u6E96\u30D5\u30A9\u30FC\u30DE\u30C3\u30C8",
        description: "\u4F1A\u8B70\u306E\u5185\u5BB9\u3092\u6A19\u6E96\u7684\u306A\u8B70\u4E8B\u9332\u5F62\u5F0F\u3067\u8981\u7D04\u3057\u3066\u304F\u3060\u3055\u3044\u3002\u53C2\u52A0\u8005\u3001\u4E3B\u8981\u306A\u8B70\u984C\u3001\u6C7A\u5B9A\u4E8B\u9805\u3001\u6B21\u306E\u30DE\u30A4\u30EB\u30B9\u30C8\u30FC\u30F3\u3001\u62C5\u5F53\u8005\u3092\u91CD\u70B9\u7684\u306B\u8A18\u8F09\u3057\u3066\u304F\u3060\u3055\u3044\u3002",
        prompt: "\u4F1A\u8B70\u306E\u5185\u5BB9\u3092\u6A19\u6E96\u7684\u306A\u8B70\u4E8B\u9332\u5F62\u5F0F\u3067\u8981\u7D04\u3057\u3066\u304F\u3060\u3055\u3044\u3002\u53C2\u52A0\u8005\u3001\u4E3B\u8981\u306A\u8B70\u984C\u3001\u6C7A\u5B9A\u4E8B\u9805\u3001\u6B21\u306E\u30DE\u30A4\u30EB\u30B9\u30C8\u30FC\u30F3\u3001\u62C5\u5F53\u8005\u3092\u91CD\u70B9\u7684\u306B\u8A18\u8F09\u3057\u3066\u304F\u3060\u3055\u3044\u3002",
        category: "\u6A19\u6E96",
        display_order: 1
      },
      {
        key: "business_meeting",
        name: "\u55B6\u696D\u5546\u8AC7\u7528",
        description: "\u55B6\u696D\u5546\u8AC7\u306E\u5185\u5BB9\u3092\u8981\u7D04\u3057\u3066\u304F\u3060\u3055\u3044\u3002\u9867\u5BA2\u306E\u8AB2\u984C\u3001\u63D0\u6848\u5185\u5BB9\u3001\u9867\u5BA2\u306E\u8AB2\u984C\u3001\u63D0\u6848\u6848\u5185\u3001\u6B21\u306E\u30DE\u30A4\u30EB\u30B9\u30C8\u30FC\u30F3\u3001\u62C5\u5F53\u8005\u3092\u91CD\u70B9\u7684\u306B\u8A18\u8F09\u3057\u3066\u304F\u3060\u3055\u3044\u3002",
        prompt: "\u55B6\u696D\u5546\u8AC7\u306E\u5185\u5BB9\u3092\u8981\u7D04\u3057\u3066\u304F\u3060\u3055\u3044\u3002\u9867\u5BA2\u306E\u8AB2\u984C\u3001\u63D0\u6848\u5185\u5BB9\u3001\u9867\u5BA2\u306E\u8AB2\u984C\u3001\u63D0\u6848\u6848\u5185\u3001\u6B21\u306E\u30DE\u30A4\u30EB\u30B9\u30C8\u30FC\u30F3\u3001\u62C5\u5F53\u8005\u3092\u91CD\u70B9\u7684\u306B\u8A18\u8F09\u3057\u3066\u304F\u3060\u3055\u3044\u3002",
        category: "\u55B6\u696D",
        display_order: 2
      },
      {
        key: "interview",
        name: "\u9762\u63A5\u7528",
        description: "\u9762\u63A5\u306E\u5185\u5BB9\u3092\u8981\u7D04\u3057\u3066\u304F\u3060\u3055\u3044\u3002\u5019\u88DC\u8005\u306E\u56DE\u7B54\u3001\u8A55\u4FA1\u30DD\u30A4\u30F3\u30C8\u3001\u4ECA\u5F8C\u306E\u30D7\u30ED\u30BB\u30B9\u3001\u62C5\u5F53\u8005\u3092\u91CD\u70B9\u7684\u306B\u8A18\u8F09\u3057\u3066\u304F\u3060\u3055\u3044\u3002",
        prompt: "\u9762\u63A5\u306E\u5185\u5BB9\u3092\u8981\u7D04\u3057\u3066\u304F\u3060\u3055\u3044\u3002\u5019\u88DC\u8005\u306E\u56DE\u7B54\u3001\u8A55\u4FA1\u30DD\u30A4\u30F3\u30C8\u3001\u4ECA\u5F8C\u306E\u30D7\u30ED\u30BB\u30B9\u3001\u62C5\u5F53\u8005\u3092\u91CD\u70B9\u7684\u306B\u8A18\u8F09\u3057\u3066\u304F\u3060\u3055\u3044\u3002",
        category: "\u4EBA\u4E8B",
        display_order: 3
      },
      {
        key: "training",
        name: "\u7814\u4FEE\u7528",
        description: "\u7814\u4FEE\u306E\u5185\u5BB9\u3092\u8981\u7D04\u3057\u3066\u304F\u3060\u3055\u3044\u3002\u5B66\u7FD2\u76EE\u6A19\u3001\u4E3B\u8981\u306A\u30DD\u30A4\u30F3\u30C8\u3001\u8CEA\u7591\u5FDC\u7B54\u3001\u30D5\u30A9\u30ED\u30FC\u30A2\u30C3\u30D7\u4E8B\u9805\u3092\u91CD\u70B9\u7684\u306B\u8A18\u8F09\u3057\u3066\u304F\u3060\u3055\u3044\u3002",
        prompt: "\u7814\u4FEE\u306E\u5185\u5BB9\u3092\u8981\u7D04\u3057\u3066\u304F\u3060\u3055\u3044\u3002\u5B66\u7FD2\u76EE\u6A19\u3001\u4E3B\u8981\u306A\u30DD\u30A4\u30F3\u30C8\u3001\u8CEA\u7591\u5FDC\u7B54\u3001\u30D5\u30A9\u30ED\u30FC\u30A2\u30C3\u30D7\u4E8B\u9805\u3092\u91CD\u70B9\u7684\u306B\u8A18\u8F09\u3057\u3066\u304F\u3060\u3055\u3044\u3002",
        category: "\u7814\u4FEE",
        display_order: 4
      },
      {
        key: "custom",
        name: "\u30AB\u30B9\u30BF\u30E0",
        description: "\u4F1A\u8B70\u306E\u5185\u5BB9\u3092\u30AB\u30B9\u30BF\u30E0\u5F62\u5F0F\u3067\u8981\u7D04\u3057\u3066\u304F\u3060\u3055\u3044\u3002",
        prompt: "\u4F1A\u8B70\u306E\u5185\u5BB9\u3092\u30AB\u30B9\u30BF\u30E0\u5F62\u5F0F\u3067\u8981\u7D04\u3057\u3066\u304F\u3060\u3055\u3044\u3002",
        category: "\u305D\u306E\u4ED6",
        display_order: 5
      }
    ], n = 0, i = Date.now();
    for (let a of t)
      await r.db.query("transcriptionTypes").withIndex("by_key", (c) => c.eq("key", a.key)).first() || (await r.db.insert("transcriptionTypes", {
        name: a.name,
        description: a.description,
        key: a.key,
        prompt: a.prompt,
        template: void 0,
        category: a.category,
        is_system: !0,
        is_active: !0,
        available_for_quick_transcription: !0,
        available_for_video_upload: !0,
        created_by: void 0,
        created_at: i,
        updated_at: i,
        display_order: a.display_order,
        icon: void 0,
        color: void 0,
        usage_count: 0,
        last_used_at: void 0
      }), n++);
    return {
      success: !0,
      message: `${n}\u500B\u306E\u30C7\u30D5\u30A9\u30EB\u30C8\u6587\u5B57\u8D77\u3053\u3057\u30BF\u30A4\u30D7\u304C\u4F5C\u6210\u3055\u308C\u307E\u3057\u305F`,
      created: n
    };
  }, "handler")
});
export {
  T as createBasicTranscriptionType,
  v as deleteTranscriptionType,
  b as getActiveTranscriptionTypes,
  m as getActiveTranscriptionTypesInternal,
  f as getAllTranscriptionTypes,
  w as getTranscriptionTypeByKey,
  h as getVideoUploadTypes,
  q as incrementUsageCountByKey,
  x as initializeDefaultTranscriptionTypes,
  k as updateTranscriptionType
};
//# sourceMappingURL=transcriptionTypes.js.map
