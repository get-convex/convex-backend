import {
  c as p,
  d as l
} from "./_deps/75JH2J25.js";
import "./_deps/6XQQNYIR.js";
import {
  j as e,
  n as T
} from "./_deps/3TDUHHJO.js";
import {
  a as d
} from "./_deps/RUVYHBJQ.js";

// convex/testing.ts
T();
var E = l({
  args: {
    user_id: e.id("users"),
    clerk_session_id: e.string(),
    device_info: e.optional(e.string()),
    ip_address: e.optional(e.string()),
    user_agent: e.optional(e.string()),
    expires_at: e.number(),
    last_activity_at: e.number(),
    is_active: e.boolean()
  },
  returns: e.id("userSessions"),
  handler: /* @__PURE__ */ d(async (s, t) => {
    throw new Error("Testing functions can only be used in test environment");
  }, "handler")
}), w = l({
  args: {},
  returns: e.number(),
  handler: /* @__PURE__ */ d(async (s) => {
    throw new Error("Testing functions can only be used in test environment");
  }, "handler")
}), I = l({
  args: {
    clerkUserId: e.string(),
    tokenIdentifier: e.string(),
    email: e.string(),
    name: e.string(),
    role: e.string(),
    isActive: e.optional(e.boolean())
  },
  returns: e.id("users"),
  handler: /* @__PURE__ */ d(async (s, t) => {
    throw new Error("Testing functions can only be used in test environment");
  }, "handler")
}), V = l({
  args: {
    id: e.id("users"),
    email: e.string(),
    username: e.string(),
    role: e.string(),
    department: e.string()
  },
  returns: e.id("users"),
  handler: /* @__PURE__ */ d(async (s, t) => {
    throw new Error("Testing functions can only be used in test environment");
  }, "handler")
}), N = l({
  args: {
    userId: e.id("users"),
    title: e.optional(e.string()),
    description: e.optional(e.string()),
    type: e.optional(e.string()),
    url: e.optional(e.string())
  },
  returns: e.id("videos"),
  handler: /* @__PURE__ */ d(async (s, t) => {
    throw new Error("Testing functions can only be used in test environment");
  }, "handler")
}), D = l({
  args: {
    videoId: e.id("videos"),
    language: e.optional(e.string()),
    text: e.string(),
    segments: e.optional(
      e.array(
        e.object({
          id: e.number(),
          start: e.number(),
          end: e.number(),
          text: e.string()
        })
      )
    ),
    confidence: e.optional(e.number()),
    status: e.union(
      e.literal("pending"),
      e.literal("processing"),
      e.literal("completed"),
      e.literal("failed")
    )
  },
  returns: e.id("transcriptions"),
  handler: /* @__PURE__ */ d(async (s, t) => {
    throw new Error("Testing functions can only be used in test environment");
  }, "handler")
}), S = p({
  args: {
    videoType: e.string(),
    criteria: e.any(),
    userId: e.id("users")
  },
  returns: e.object({
    success: e.boolean(),
    message: e.string(),
    videoType: e.string(),
    updatedCriteria: e.any()
  }),
  handler: /* @__PURE__ */ d(async (s, t) => {
    if (process.env.VITEST !== "true")
      throw new Error("Testing functions can only be used in test environment");
    let { videoType: r, criteria: n, userId: i } = t, o = await s.db.query("evaluationCriteria").withIndex("by_video_type", (a) => a.eq("video_type", r)).collect();
    await Promise.all(o.map((a) => s.db.delete(a._id)));
    let c = Object.entries(n).map(([a, u]) => s.db.insert("evaluationCriteria", {
      video_type: r,
      criterion_key: a,
      criterion_name: a,
      description: u.description || "",
      scale: u,
      is_active: !0
    }));
    return await Promise.all(c), {
      success: !0,
      message: "\u8A55\u4FA1\u57FA\u6E96\u3092\u66F4\u65B0\u3057\u307E\u3057\u305F",
      videoType: r,
      updatedCriteria: n
    };
  }, "handler")
}), x = p({
  args: {
    userId: e.id("users"),
    action: e.string()
  },
  returns: e.object({
    hasPermission: e.boolean(),
    reason: e.string()
  }),
  handler: /* @__PURE__ */ d(async (s, t) => {
    if (process.env.VITEST !== "true")
      throw new Error("Testing functions can only be used in test environment");
    let { userId: r } = t, n = await s.db.get(r);
    return n ? n.role === "admin" ? {
      hasPermission: !0,
      reason: "\u7BA1\u7406\u8005\u6A29\u9650"
    } : {
      hasPermission: !1,
      reason: "\u6A29\u9650\u304C\u4E0D\u8DB3\u3057\u3066\u3044\u307E\u3059"
    } : {
      hasPermission: !1,
      reason: "\u30E6\u30FC\u30B6\u30FC\u304C\u898B\u3064\u304B\u308A\u307E\u305B\u3093"
    };
  }, "handler")
}), k = p({
  args: {
    videoType: e.string(),
    criteria: e.any(),
    userId: e.id("users")
  },
  returns: e.object({
    isValid: e.boolean(),
    errors: e.array(e.string())
  }),
  handler: /* @__PURE__ */ d(async (s, t) => {
    if (process.env.VITEST !== "true")
      throw new Error("Testing functions can only be used in test environment");
    let { videoType: r, criteria: n } = t, i = [];
    return ["M&A\u30ED\u30FC\u30EB\u30D7\u30EC\u30A4", "AD\u7DE0\u7D50\u63D0\u6848", "\u4F01\u696D\u6982\u8981\u66F8\u63D0\u6848", "\u8B72\u6E21\u67B6\u96FB"].includes(r) || i.push("\u7121\u52B9\u306A\u52D5\u753B\u30BF\u30A4\u30D7\u3067\u3059"), typeof n != "object" || n === null ? i.push("\u8A55\u4FA1\u57FA\u6E96\u306F\u6709\u52B9\u306A\u30AA\u30D6\u30B8\u30A7\u30AF\u30C8\u3067\u3042\u308B\u5FC5\u8981\u304C\u3042\u308A\u307E\u3059") : Object.entries(n).forEach(([c, a]) => {
      !a.minScore && a.minScore !== 0 && i.push(`${c}: minScore\u304C\u5FC5\u9808\u3067\u3059`), !a.maxScore && a.maxScore !== 0 && i.push(`${c}: maxScore\u304C\u5FC5\u9808\u3067\u3059`), a.description || i.push(`${c}: description\u304C\u5FC5\u9808\u3067\u3059`), (!a.scales || typeof a.scales != "object") && i.push(`${c}: scales\u304C\u5FC5\u9808\u3067\u3059`);
    }), {
      isValid: i.length === 0,
      errors: i
    };
  }, "handler")
}), M = p({
  args: {
    videoType: e.string(),
    criteria1: e.any(),
    criteria2: e.any(),
    user1Id: e.id("users"),
    user2Id: e.id("users")
  },
  returns: e.object({
    success: e.boolean(),
    concurrencyHandled: e.boolean(),
    finalState: e.any()
  }),
  handler: /* @__PURE__ */ d(async (s, t) => {
    if (process.env.VITEST !== "true")
      throw new Error("Testing functions can only be used in test environment");
    let { videoType: r, criteria1: n, criteria2: i, user1Id: o, user2Id: c } = t;
    try {
      let a = await s.db.get(o), u = await s.db.get(c);
      return !a || !u ? {
        success: !1,
        concurrencyHandled: !1,
        finalState: { error: "Users not found" }
      } : (await s.db.insert("evaluationCriteria", {
        video_type: r,
        criterion_key: "test1",
        criterion_name: "test1",
        description: "Test concurrent 1",
        scale: n,
        is_active: !0
      }), await s.db.insert("evaluationCriteria", {
        video_type: r,
        criterion_key: "test2",
        criterion_name: "test2",
        description: "Test concurrent 2",
        scale: i,
        is_active: !0
      }), {
        success: !0,
        concurrencyHandled: !0,
        finalState: { criteria1: n, criteria2: i }
      });
    } catch (a) {
      return {
        success: !1,
        concurrencyHandled: !1,
        finalState: { error: String(a) }
      };
    }
  }, "handler")
}), O = p({
  args: {
    scenario: e.string(),
    videoType: e.string(),
    criteria: e.any(),
    userId: e.id("users")
  },
  returns: e.object({
    success: e.boolean(),
    errorType: e.string(),
    message: e.string()
  }),
  handler: /* @__PURE__ */ d(async (s, t) => {
    if (process.env.VITEST !== "true")
      throw new Error("Testing functions can only be used in test environment");
    let { scenario: r, videoType: n } = t;
    switch (r) {
      case "nonExistentVideoType":
        return {
          success: !1,
          errorType: "INVALID_VIDEO_TYPE",
          message: "\u5B58\u5728\u3057\u306A\u3044\u52D5\u753B\u30BF\u30A4\u30D7\u304C\u6307\u5B9A\u3055\u308C\u307E\u3057\u305F"
        };
      default:
        return {
          success: !0,
          errorType: "NONE",
          message: "\u30A8\u30E9\u30FC\u306F\u3042\u308A\u307E\u305B\u3093\u3067\u3057\u305F"
        };
    }
  }, "handler")
}), $ = p({
  args: {
    scenario: e.string(),
    videoType: e.string(),
    criteria: e.any(),
    userId: e.id("users")
  },
  returns: e.object({
    securityPassed: e.boolean(),
    sanitizedCriteria: e.any()
  }),
  handler: /* @__PURE__ */ d(async (s, t) => {
    if (process.env.VITEST !== "true")
      throw new Error("Testing functions can only be used in test environment");
    let { criteria: r } = t, n = {};
    return Object.entries(r).forEach(([i, o]) => {
      n[i] = {
        ...o,
        description: o.description?.replace(/<script.*?<\/script>/gi, "").replace(/javascript:/gi, ""),
        scales: Object.fromEntries(
          Object.entries(o.scales || {}).map(([c, a]) => [
            c,
            a?.toString().replace(/<script.*?<\/script>/gi, "").replace(/javascript:/gi, "")
          ])
        )
      };
    }), {
      securityPassed: !0,
      sanitizedCriteria: n
    };
  }, "handler")
}), j = p({
  args: {
    scenario: e.string(),
    videoType: e.string(),
    criteria: e.any(),
    userId: e.id("users")
  },
  returns: e.object({
    success: e.boolean(),
    executionTime: e.number(),
    processedCount: e.number(),
    memoryUsage: e.number()
  }),
  handler: /* @__PURE__ */ d(async (s, t) => {
    if (process.env.VITEST !== "true")
      throw new Error("Testing functions can only be used in test environment");
    let { criteria: r } = t, n = Date.now(), i = Object.keys(r).length;
    return await new Promise((c) => setTimeout(c, 100)), {
      success: !0,
      executionTime: Date.now() - n,
      processedCount: i,
      memoryUsage: 50 * 1024 * 1024
      // Mock 50MB
    };
  }, "handler")
}), A = p({
  args: {
    videoType: e.string(),
    criteria: e.any(),
    userId: e.id("users")
  },
  returns: e.object({
    success: e.boolean(),
    processedInBatches: e.boolean(),
    memoryPeakUsage: e.number(),
    dataIntegrityCheck: e.boolean()
  }),
  handler: /* @__PURE__ */ d(async (s, t) => {
    if (process.env.VITEST !== "true")
      throw new Error("Testing functions can only be used in test environment");
    let { criteria: r } = t;
    return {
      success: !0,
      processedInBatches: Object.keys(r).length > 10,
      memoryPeakUsage: 30 * 1024 * 1024,
      // Mock 30MB
      dataIntegrityCheck: !0
    };
  }, "handler")
}), C = l({
  args: {
    userId: e.id("users"),
    videoId: e.id("videos"),
    status: e.optional(e.string()),
    totalScore: e.optional(e.number()),
    evaluationType: e.optional(e.string()),
    criteria: e.optional(e.any()),
    results: e.optional(e.any())
  },
  returns: e.id("evaluations"),
  handler: /* @__PURE__ */ d(async (s, t) => {
    if (process.env.VITEST !== "true")
      throw new Error("Testing functions can only be used in test environment");
    let { userId: r, videoId: n, status: i = "completed", totalScore: o = 85, evaluationType: c = "M&A\u30ED\u30FC\u30EB\u30D7\u30EC\u30A4", criteria: a = {}, results: u = {} } = t, v = await s.db.insert("transcriptions", {
      resource_type: "video",
      resource_id: n,
      text: "Test transcript content",
      status: "completed",
      duration_seconds: 60
    });
    return await s.db.insert("evaluations", {
      transcription_id: v,
      user_id: r,
      video_id: n,
      status: i,
      total_score: o,
      video_type: c,
      processing_duration_ms: 3e5,
      // 5 minutes
      hearingAbility: 80,
      problemSetting: 90,
      knowledge: 85,
      negotiation: 75,
      businessManners: 95
    });
  }, "handler")
}), U = l({
  args: {
    userId: e.id("users"),
    activityType: e.optional(e.string()),
    details: e.optional(e.any()),
    timestamp: e.optional(e.number())
  },
  returns: e.null(),
  handler: /* @__PURE__ */ d(async (s, t) => {
    if (process.env.VITEST !== "true")
      throw new Error("Testing functions can only be used in test environment");
    let { userId: r, activityType: n = "evaluation_completed", details: i = {}, timestamp: o = Date.now() } = t;
    return console.log(`Test user activity created: ${n} for user ${r}`), null;
  }, "handler")
}), P = l({
  args: {
    evaluationId: e.id("evaluations"),
    status: e.string(),
    totalScore: e.optional(e.number()),
    results: e.optional(e.any())
  },
  returns: e.null(),
  handler: /* @__PURE__ */ d(async (s, t) => {
    if (process.env.VITEST !== "true")
      throw new Error("Testing functions can only be used in test environment");
    let { evaluationId: r, status: n, totalScore: i, results: o } = t, c = { status: n };
    return i !== void 0 && (c.total_score = i), o !== void 0 && (c.feedback = o), await s.db.patch(r, c), null;
  }, "handler")
}), B = l({
  args: {
    userId: e.id("users"),
    videoType: e.string(),
    settings: e.any()
  },
  returns: e.object({
    settingsId: e.string(),
    settings: e.any()
  }),
  handler: /* @__PURE__ */ d(async (s, t) => {
    if (process.env.VITEST !== "true")
      throw new Error("Testing functions can only be used in test environment");
    let { userId: r, videoType: n, settings: i } = t;
    return {
      settingsId: `settings-${n}-${r}`,
      settings: i || {
        autoEvaluation: !0,
        notificationEnabled: !0,
        scoringMethod: "standard",
        thresholds: {
          excellent: 90,
          good: 75,
          fair: 60,
          poor: 0
        }
      }
    };
  }, "handler")
}), q = l({
  args: {
    settingsType: e.optional(e.string())
  },
  returns: e.object({
    settingsId: e.string(),
    settings: e.any()
  }),
  handler: /* @__PURE__ */ d(async (s, t) => {
    if (process.env.VITEST !== "true")
      throw new Error("Testing functions can only be used in test environment");
    let { settingsType: r = "default" } = t;
    return {
      settingsId: `settings-default-${Date.now()}`,
      settings: {
        autoEvaluation: !1,
        notificationEnabled: !1,
        scoringMethod: "manual",
        thresholds: {
          excellent: 95,
          good: 80,
          fair: 65,
          poor: 0
        },
        defaultLanguage: "ja",
        maxRetries: 3,
        timeoutSeconds: 300
      }
    };
  }, "handler")
}), H = l({
  args: {
    userId: e.id("users"),
    title: e.string(),
    message: e.string(),
    type: e.optional(e.string()),
    priority: e.optional(e.string())
  },
  returns: e.id("notifications"),
  handler: /* @__PURE__ */ d(async (s, t) => {
    if (process.env.VITEST !== "true")
      throw new Error("Testing functions can only be used in test environment");
    let { userId: r, title: n, message: i, type: o = "info", priority: c = "medium" } = t;
    return await s.db.insert("notifications", {
      user_id: r,
      title: n,
      message: i,
      type: o,
      data: JSON.stringify({ priority: c }),
      is_read: !1
    });
  }, "handler")
}), z = l({
  args: {
    delayMs: e.number(),
    shouldSucceed: e.optional(e.boolean())
  },
  returns: e.object({
    success: e.boolean(),
    duration: e.number(),
    message: e.string()
  }),
  handler: /* @__PURE__ */ d(async (s, t) => {
    if (process.env.VITEST !== "true")
      throw new Error("Testing functions can only be used in test environment");
    let { delayMs: r, shouldSucceed: n = !0 } = t, i = Date.now();
    await new Promise((c) => setTimeout(c, Math.min(r, 1e3)));
    let o = Date.now();
    return {
      success: n,
      duration: o - i,
      message: n ? "Processing completed successfully" : "Processing failed with simulated error"
    };
  }, "handler")
}), F = l({
  args: {
    clerkUserId: e.string(),
    email: e.string(),
    firstName: e.optional(e.string()),
    lastName: e.optional(e.string()),
    role: e.optional(e.string()),
    department: e.optional(e.string()),
    imageUrl: e.optional(e.string())
  },
  returns: e.id("users"),
  handler: /* @__PURE__ */ d(async (s, t) => {
    if (process.env.VITEST !== "true")
      throw new Error("Testing functions can only be used in test environment");
    let { clerkUserId: r, email: n, firstName: i, lastName: o, role: c = "user", department: a, imageUrl: u } = t;
    return await s.db.insert("users", {
      clerkUserId: r,
      tokenIdentifier: `test-token-${r}`,
      email: n,
      emailVerified: !0,
      name: i && o ? `${i} ${o}` : n,
      firstName: i,
      lastName: o,
      role: c,
      department: a,
      imageUrl: u,
      isActive: !0,
      joinDate: Date.now()
    });
  }, "handler")
}), L = l({
  args: {
    userId: e.id("users"),
    title: e.optional(e.string()),
    description: e.optional(e.string()),
    url: e.optional(e.string()),
    type: e.optional(e.string()),
    status: e.optional(e.string())
  },
  returns: e.id("videos"),
  handler: /* @__PURE__ */ d(async (s, t) => {
    if (process.env.VITEST !== "true")
      throw new Error("Testing functions can only be used in test environment");
    let { userId: r, title: n, description: i, url: o, type: c, status: a = "uploaded" } = t;
    return await s.db.insert("videos", {
      title: n || "\u30C6\u30B9\u30C8\u52D5\u753B",
      description: i || "\u30C6\u30B9\u30C8\u7528\u306E\u52D5\u753B\u3067\u3059",
      url: o || "https://example.com/test-video.mp4",
      type: c || "M&A\u30ED\u30FC\u30EB\u30D7\u30EC\u30A4",
      user_id: r,
      processing_status: a,
      uploaded_at: Date.now()
    });
  }, "handler")
}), R = l({
  args: {
    userId: e.id("users"),
    videoId: e.id("videos"),
    transcriptionId: e.optional(e.id("transcriptions")),
    status: e.optional(e.string()),
    totalScore: e.optional(e.number()),
    videoType: e.optional(e.string())
  },
  returns: e.id("evaluations"),
  handler: /* @__PURE__ */ d(async (s, t) => {
    if (process.env.VITEST !== "true")
      throw new Error("Testing functions can only be used in test environment");
    let { userId: r, videoId: n, transcriptionId: i, status: o = "completed", totalScore: c = 85, videoType: a = "M&A\u30ED\u30FC\u30EB\u30D7\u30EC\u30A4" } = t, u = i;
    return u || (u = await s.db.insert("transcriptions", {
      resource_type: "video",
      resource_id: n,
      video_id: n,
      text: "Test transcript content for evaluation",
      status: "completed",
      duration_seconds: 60
    })), await s.db.insert("evaluations", {
      transcription_id: u,
      user_id: r,
      video_id: n,
      status: o,
      total_score: c,
      video_type: a,
      processing_duration_ms: 3e5,
      hearingAbility: Math.floor(c * 0.9),
      problemSetting: Math.floor(c * 1.1),
      knowledge: c,
      negotiation: Math.floor(c * 0.8),
      businessManners: Math.floor(c * 1.2)
    });
  }, "handler")
}), W = l({
  args: {
    userId: e.id("users"),
    sector: e.string()
  },
  returns: e.null(),
  handler: /* @__PURE__ */ d(async (s, t) => {
    if (process.env.VITEST !== "true")
      throw new Error("Testing functions can only be used in test environment");
    let { userId: r, sector: n } = t;
    return await s.db.patch(r, { department: n }), null;
  }, "handler")
}), J = l({
  args: {
    name: e.string(),
    managerId: e.optional(e.id("users")),
    description: e.optional(e.string())
  },
  returns: e.string(),
  handler: /* @__PURE__ */ d(async (s, t) => {
    if (process.env.VITEST !== "true")
      throw new Error("Testing functions can only be used in test environment");
    let { name: r, managerId: n, description: i } = t, o = `dept-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
    return console.log(`Created test department: ${r} with ID: ${o}`), o;
  }, "handler")
}), Y = l({
  args: {
    name: e.string(),
    leaderId: e.optional(e.id("users")),
    departmentId: e.optional(e.string()),
    members: e.optional(e.array(e.id("users")))
  },
  returns: e.string(),
  handler: /* @__PURE__ */ d(async (s, t) => {
    if (process.env.VITEST !== "true")
      throw new Error("Testing functions can only be used in test environment");
    let { name: r, leaderId: n, departmentId: i, members: o } = t, c = `team-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
    return console.log(`Created test team: ${r} with ID: ${c}, members: ${o?.length || 0}`), c;
  }, "handler")
}), G = l({
  args: {
    userId: e.id("users"),
    videoTitle: e.optional(e.string()),
    videoType: e.optional(e.string()),
    evaluationScore: e.optional(e.number()),
    status: e.optional(e.string())
  },
  returns: e.object({
    userId: e.id("users"),
    videoId: e.id("videos"),
    evaluationId: e.id("evaluations"),
    transcriptionId: e.id("transcriptions")
  }),
  handler: /* @__PURE__ */ d(async (s, t) => {
    if (process.env.VITEST !== "true")
      throw new Error("Testing functions can only be used in test environment");
    let {
      userId: r,
      videoTitle: n = "\u30C6\u30B9\u30C8\u8A55\u4FA1\u52D5\u753B",
      videoType: i = "M&A\u30ED\u30FC\u30EB\u30D7\u30EC\u30A4",
      evaluationScore: o = 85,
      status: c = "completed"
    } = t, a = await s.db.insert("videos", {
      title: n,
      description: "\u8A55\u4FA1\u30C6\u30B9\u30C8\u7528\u306E\u52D5\u753B\u3067\u3059",
      url: "https://example.com/test-evaluation-video.mp4",
      type: i,
      user_id: r,
      processing_status: "completed",
      uploaded_at: Date.now()
    }), u = await s.db.insert("transcriptions", {
      resource_type: "video",
      resource_id: a,
      video_id: a,
      text: "\u30C6\u30B9\u30C8\u7528\u306E\u97F3\u58F0\u6587\u5B57\u8D77\u3053\u3057\u5185\u5BB9\u3067\u3059\u3002",
      status: "completed",
      duration_seconds: 120
    }), v = await s.db.insert("evaluations", {
      transcription_id: u,
      user_id: r,
      video_id: a,
      status: c,
      total_score: o,
      video_type: i,
      processing_duration_ms: 3e5,
      hearingAbility: Math.floor(o * 0.9),
      problemSetting: Math.floor(o * 1.1),
      knowledge: o,
      negotiation: Math.floor(o * 0.8),
      businessManners: Math.floor(o * 1.2)
    });
    return {
      userId: r,
      videoId: a,
      evaluationId: v,
      transcriptionId: u
    };
  }, "handler")
}), K = l({
  args: {
    userCount: e.number(),
    videosPerUser: e.number(),
    evaluationsPerVideo: e.number()
  },
  returns: e.object({
    usersCreated: e.number(),
    videosCreated: e.number(),
    evaluationsCreated: e.number()
  }),
  handler: /* @__PURE__ */ d(async (s, t) => {
    if (process.env.VITEST !== "true")
      throw new Error("Testing functions can only be used in test environment");
    let { userCount: r, videosPerUser: n, evaluationsPerVideo: i } = t, o = 0, c = 0, a = 0;
    for (let u = 0; u < r; u++) {
      let v = await s.db.insert("users", {
        clerkUserId: `bulk-test-user-${u}`,
        tokenIdentifier: `bulk-test-token-${u}`,
        email: `bulkuser${u}@example.com`,
        emailVerified: !0,
        name: `Bulk User ${u}`,
        firstName: "Bulk",
        lastName: `User${u}`,
        role: "user",
        isActive: !0,
        joinDate: Date.now() - Math.random() * 864e5 * 30
        // Random date within last 30 days
      });
      o++;
      for (let m = 0; m < n; m++) {
        let y = await s.db.insert("videos", {
          title: `Bulk Test Video ${u}-${m}`,
          description: `Bulk test video ${m} for user ${u}`,
          url: `https://example.com/bulk-video-${u}-${m}.mp4`,
          type: ["M&A\u30ED\u30FC\u30EB\u30D7\u30EC\u30A4", "AD\u7DE0\u7D50\u63D0\u6848", "\u4F01\u696D\u6982\u8981\u66F8\u63D0\u6848"][m % 3],
          user_id: v,
          processing_status: "completed",
          uploaded_at: Date.now() - Math.random() * 864e5 * 7
          // Random date within last 7 days
        });
        c++;
        for (let f = 0; f < i; f++) {
          let b = await s.db.insert("transcriptions", {
            resource_type: "video",
            resource_id: y,
            video_id: y,
            text: `Bulk test transcription ${f} for video ${u}-${m}`,
            status: "completed",
            duration_seconds: 60 + Math.random() * 120
          }), g = 60 + Math.random() * 40;
          await s.db.insert("evaluations", {
            transcription_id: b,
            user_id: v,
            video_id: y,
            status: "completed",
            total_score: Math.floor(g),
            video_type: ["M&A\u30ED\u30FC\u30EB\u30D7\u30EC\u30A4", "AD\u7DE0\u7D50\u63D0\u6848", "\u4F01\u696D\u6982\u8981\u66F8\u63D0\u6848"][m % 3],
            processing_duration_ms: 2e5 + Math.random() * 2e5,
            hearingAbility: Math.floor(g * 0.9),
            problemSetting: Math.floor(g * 1.1),
            knowledge: Math.floor(g),
            negotiation: Math.floor(g * 0.8),
            businessManners: Math.floor(g * 1.2)
          }), a++;
        }
      }
    }
    return {
      usersCreated: o,
      videosCreated: c,
      evaluationsCreated: a
    };
  }, "handler")
});
export {
  x as checkUpdatePermission,
  w as clearAllTestData,
  K as createBulkTestData,
  R as createEvaluationForTesting,
  G as createEvaluationWithVideo,
  q as createTestDefaultSettings,
  J as createTestDepartment,
  C as createTestEvaluation,
  B as createTestEvaluationSettings,
  H as createTestNotification,
  E as createTestSession,
  Y as createTestTeam,
  D as createTestTranscription,
  V as createTestUser,
  U as createTestUserActivity,
  I as createTestUserWithRole,
  N as createTestVideo,
  F as createUser,
  L as createVideoForTesting,
  M as simulateConcurrentUpdate,
  z as simulateProcessingDelay,
  O as testErrorHandling,
  A as testMemoryEfficiency,
  j as testPerformance,
  $ as testSecurityValidation,
  S as updateEvaluationCriteriaTest,
  P as updateEvaluationStatus,
  W as updateUserSector,
  k as validateUpdateCriteriaInput
};
//# sourceMappingURL=testing.js.map
