import {
  d as i,
  e as o
} from "../_deps/IVQGLTSC.js";
import "../_deps/6XQQNYIR.js";
import "../_deps/3TDUHHJO.js";
import {
  a as t,
  f as a
} from "../_deps/RUVYHBJQ.js";

// convex/helpers/unsafe.ts
var u = (o(), a(i)).api, y = (o(), a(i)).internal;
function f(n, e, r) {
  return n.runQuery(e, r);
}
t(f, "safeRunQuery");
function p(n, e, r) {
  return n.runMutation(e, r);
}
t(p, "safeRunMutation");
function s(n, e, r) {
  return n.runAction(e, r);
}
t(s, "safeRunAction");
export {
  u as safeApi,
  y as safeInternal,
  s as safeRunAction,
  p as safeRunMutation,
  f as safeRunQuery
};
//# sourceMappingURL=unsafe.js.map
