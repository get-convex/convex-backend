import {
  b as n,
  e as b
} from "./_deps/IVQGLTSC.js";
import {
  a as _,
  c as f,
  e as g
} from "./_deps/75JH2J25.js";
import "./_deps/6XQQNYIR.js";
import {
  j as e,
  n as v
} from "./_deps/3TDUHHJO.js";
import {
  a as d
} from "./_deps/RUVYHBJQ.js";

// convex/videoUploadGCS.ts
v();
b();
var z = g({
  args: {
    fileName: e.string(),
    fileType: e.string(),
    fileSize: e.number(),
    title: e.optional(e.string()),
    description: e.optional(e.string())
  },
  returns: e.union(
    e.object({
      success: e.literal(!0),
      message: e.string(),
      uploadUrl: e.string(),
      videoId: e.id("videos"),
      fileUploadId: e.id("fileUploads"),
      gcpFilePath: e.string()
    }),
    e.object({
      success: e.literal(!1),
      message: e.string(),
      uploadUrl: e.optional(e.string()),
      videoId: e.optional(e.id("videos")),
      fileUploadId: e.optional(e.id("fileUploads")),
      gcpFilePath: e.optional(e.string())
    })
  ),
  handler: /* @__PURE__ */ d(async (i, t) => {
    if (!await i.auth.getUserIdentity())
      return {
        success: !1,
        message: "\u8A8D\u8A3C\u304C\u5FC5\u8981\u3067\u3059"
      };
    let l = await i.runQuery(n.unifiedAuth.getCurrentUser, {});
    if (!l)
      return {
        success: !1,
        message: "\u30E6\u30FC\u30B6\u30FC\u60C5\u5831\u306E\u53D6\u5F97\u306B\u5931\u6557\u3057\u307E\u3057\u305F"
      };
    let { fileName: s, fileType: o, fileSize: r, title: p, description: c } = t;
    try {
      if (r > 2147483648)
        return {
          success: !1,
          message: `\u30D5\u30A1\u30A4\u30EB\u30B5\u30A4\u30BA\u304C\u5236\u9650\u3092\u8D85\u3048\u3066\u3044\u307E\u3059\uFF08\u6700\u5927: ${2147483648 / (1024 * 1024 * 1024)}GB\uFF09`
        };
      if (![
        // 動画形式
        "video/mp4",
        "video/webm",
        "video/quicktime",
        "video/avi",
        "video/mov",
        "video/mkv",
        // 音声形式（正規化されたMIMEタイプのみ）
        "audio/mp3",
        "audio/wav",
        "audio/m4a",
        "audio/x-m4a",
        "audio/aac",
        "audio/ogg",
        "audio/flac",
        "audio/webm",
        "audio/opus",
        // ドキュメント形式
        "application/pdf",
        "application/msword",
        "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
        "application/vnd.ms-excel",
        "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        "application/vnd.ms-powerpoint",
        "application/vnd.openxmlformats-officedocument.presentationml.presentation",
        // テキスト形式
        "text/plain",
        "text/csv",
        "text/markdown",
        // 画像形式
        "image/jpeg",
        "image/png",
        "image/gif",
        "image/webp",
        "image/svg+xml",
        // 汎用バイナリ形式（403エラー回避用）
        "application/octet-stream"
      ].includes(o))
        return {
          success: !1,
          message: `\u30B5\u30DD\u30FC\u30C8\u3055\u308C\u3066\u3044\u306A\u3044\u30D5\u30A1\u30A4\u30EB\u5F62\u5F0F\u3067\u3059: ${o}`
        };
      let m = "content";
      o.startsWith("video/") ? m = "video" : o.startsWith("audio/") ? m = "audio" : o === "application/pdf" || o.includes("document") || o.includes("text") ? m = "document" : o.startsWith("image/") && (m = "image");
      let U = await i.runMutation(
        n.videoUploadGCS.createVideoAndFileRecord,
        {
          userId: l._id,
          fileName: s,
          fileType: o,
          fileSize: r,
          title: p || s,
          description: c || "",
          folderName: m
        }
      );
      if (!U.success)
        return {
          success: !1,
          message: U.message
        };
      let h = await i.runAction(n.gcsActions.generateGCPUploadUrl, {
        filename: s,
        contentType: o,
        uploadType: m,
        fileSize: r
      }), y = h.uploadUrl, I = h.gcpFilePath;
      return {
        success: !0,
        message: "\u30A2\u30C3\u30D7\u30ED\u30FC\u30C9URL\u751F\u6210\u5B8C\u4E86",
        uploadUrl: y,
        videoId: U.videoId,
        fileUploadId: U.fileUploadId,
        gcpFilePath: I
      };
    } catch (u) {
      return console.error("[generateUploadUrl] \u30A8\u30E9\u30FC:", u), {
        success: !1,
        message: u instanceof Error ? u.message : "\u4E0D\u660E\u306A\u30A8\u30E9\u30FC\u304C\u767A\u751F\u3057\u307E\u3057\u305F"
      };
    }
  }, "handler")
}), A = f({
  args: {
    videoId: e.id("videos"),
    gcpFilePath: e.string(),
    fileUploadId: e.optional(e.id("fileUploads"))
  },
  returns: e.union(
    e.object({
      success: e.literal(!0),
      message: e.string(),
      videoUrl: e.string()
    }),
    e.object({
      success: e.literal(!1),
      message: e.string(),
      videoUrl: e.optional(e.string())
    })
  ),
  handler: /* @__PURE__ */ d(async (i, t) => {
    let a = await i.auth.getUserIdentity();
    if (!a)
      return {
        success: !1,
        message: "\u8A8D\u8A3C\u304C\u5FC5\u8981\u3067\u3059"
      };
    let l = await i.db.query("users").withIndex("by_clerk_user_id", (c) => c.eq("clerkUserId", a.subject)).first();
    if (!l)
      return {
        success: !1,
        message: "\u30E6\u30FC\u30B6\u30FC\u60C5\u5831\u304C\u898B\u3064\u304B\u308A\u307E\u305B\u3093"
      };
    let { videoId: s, gcpFilePath: o, fileUploadId: r } = t, p = await i.db.get(s);
    if (!p)
      return {
        success: !1,
        message: "\u52D5\u753B\u304C\u898B\u3064\u304B\u308A\u307E\u305B\u3093"
      };
    if (p.user_id !== l._id)
      return {
        success: !1,
        message: "\u30A2\u30AF\u30BB\u30B9\u62D2\u5426: \u81EA\u5206\u306E\u52D5\u753B\u306E\u307F\u30A2\u30C3\u30D7\u30ED\u30FC\u30C9\u5B8C\u4E86\u3067\u304D\u307E\u3059"
      };
    try {
      let u = `https://storage.googleapis.com/${process.env.GCS_BUCKET_NAME || "ai-sales-training-hub-media"}/${o}`;
      return await i.db.patch(s, {
        url: u
      }), r && await i.db.patch(r, {
        gcp_file_path: o,
        status: "completed",
        public_url: u,
        completed_at: Date.now()
      }), await i.scheduler.runAfter(0, n.videoUploadGCS.processUploadedVideo, {
        videoId: s,
        gcpFilePath: o,
        videoUrl: u
      }), {
        success: !0,
        message: "\u30A2\u30C3\u30D7\u30ED\u30FC\u30C9\u5B8C\u4E86",
        videoUrl: u
      };
    } catch (c) {
      if (console.error("[completeUpload] \u30A8\u30E9\u30FC:", c), r)
        try {
          await i.db.patch(r, {
            status: "failed",
            processing_error: c instanceof Error ? c.message : "Unknown error"
          });
        } catch (u) {
          console.error("[completeUpload] \u30D5\u30A1\u30A4\u30EB\u30A2\u30C3\u30D7\u30ED\u30FC\u30C9\u8A18\u9332\u66F4\u65B0\u30A8\u30E9\u30FC:", u);
        }
      return {
        success: !1,
        message: c instanceof Error ? c.message : "\u4E0D\u660E\u306A\u30A8\u30E9\u30FC\u304C\u767A\u751F\u3057\u307E\u3057\u305F"
      };
    }
  }, "handler")
}), C = g({
  args: {
    files: e.array(
      e.object({
        fileName: e.string(),
        fileType: e.string(),
        fileSize: e.number()
      })
    )
  },
  returns: e.union(
    e.object({
      success: e.literal(!0),
      message: e.string(),
      uploads: e.array(
        e.object({
          fileName: e.string(),
          uploadUrl: e.string(),
          videoId: e.id("videos"),
          fileUploadId: e.id("fileUploads"),
          gcpFilePath: e.string()
        })
      )
    }),
    e.object({
      success: e.literal(!1),
      message: e.string(),
      uploads: e.optional(
        e.array(
          e.object({
            fileName: e.string(),
            uploadUrl: e.string(),
            videoId: e.id("videos"),
            fileUploadId: e.id("fileUploads"),
            gcpFilePath: e.string()
          })
        )
      )
    })
  ),
  handler: /* @__PURE__ */ d(async (i, t) => {
    if (!await i.auth.getUserIdentity())
      return {
        success: !1,
        message: "\u8A8D\u8A3C\u304C\u5FC5\u8981\u3067\u3059"
      };
    let { files: l } = t;
    try {
      let s = [];
      for (let o of l) {
        let r = await i.runAction(n.videoUploadGCS.generateUploadUrl, {
          fileName: o.fileName,
          fileType: o.fileType,
          fileSize: o.fileSize
        });
        r.success && "uploadUrl" in r && "videoId" in r && "fileUploadId" in r && "gcpFilePath" in r && r.uploadUrl && r.videoId && r.fileUploadId && r.gcpFilePath ? s.push({
          fileName: o.fileName,
          uploadUrl: r.uploadUrl,
          videoId: r.videoId,
          fileUploadId: r.fileUploadId,
          gcpFilePath: r.gcpFilePath
        }) : console.error(
          `[generateBatchUploadUrls] \u30D5\u30A1\u30A4\u30EB ${o.fileName} \u306E\u51E6\u7406\u306B\u5931\u6557:`,
          r.message
        );
      }
      return {
        success: !0,
        message: `${s.length}/${l.length} \u30D5\u30A1\u30A4\u30EB\u306E\u7F72\u540D\u4ED8\u304DURL\u751F\u6210\u5B8C\u4E86`,
        uploads: s
      };
    } catch (s) {
      return console.error("[generateBatchUploadUrls] \u30A8\u30E9\u30FC:", s), {
        success: !1,
        message: s instanceof Error ? s.message : "\u4E0D\u660E\u306A\u30A8\u30E9\u30FC\u304C\u767A\u751F\u3057\u307E\u3057\u305F"
      };
    }
  }, "handler")
}), N = g({
  args: { fileUploadId: e.id("fileUploads") },
  returns: e.union(
    e.object({
      uploadUrl: e.string(),
      gcpFilePath: e.string(),
      ready: e.literal(!0)
    }),
    e.object({
      ready: e.literal(!1),
      message: e.string()
    })
  ),
  handler: /* @__PURE__ */ d(async (i, t) => {
    if (!await i.auth.getUserIdentity())
      return { ready: !1, message: "\u8A8D\u8A3C\u304C\u5FC5\u8981\u3067\u3059" };
    let l = await i.runQuery(n.unifiedAuth.getCurrentUser, {});
    if (!l)
      return { ready: !1, message: "\u30E6\u30FC\u30B6\u30FC\u60C5\u5831\u304C\u898B\u3064\u304B\u308A\u307E\u305B\u3093" };
    let s = await i.runQuery(n.videoUploadGCS.getUploadProgressInternal, {
      fileUploadId: t.fileUploadId
    });
    return s ? s.user_id !== l._id ? { ready: !1, message: "\u30A2\u30AF\u30BB\u30B9\u62D2\u5426" } : s.public_url && !s.public_url.includes("upload=pending") ? {
      ready: !0,
      uploadUrl: s.public_url,
      gcpFilePath: s.gcp_file_path || ""
    } : { ready: !1, message: "\u7F72\u540D\u4ED8\u304DURL\u751F\u6210\u4E2D..." } : { ready: !1, message: "\u30D5\u30A1\u30A4\u30EB\u30A2\u30C3\u30D7\u30ED\u30FC\u30C9\u8A18\u9332\u304C\u898B\u3064\u304B\u308A\u307E\u305B\u3093" };
  }, "handler")
}), G = g({
  args: { fileUploadId: e.id("fileUploads") },
  returns: e.union(
    e.object({
      id: e.id("fileUploads"),
      status: e.union(
        e.literal("preparing"),
        e.literal("pending"),
        e.literal("uploading"),
        e.literal("completed"),
        e.literal("failed"),
        e.literal("processing")
      ),
      progress_percentage: e.optional(e.number()),
      file_size: e.number(),
      uploaded_at: e.optional(e.number()),
      completed_at: e.optional(e.number()),
      error_message: e.optional(e.string()),
      gcp_file_path: e.optional(e.string()),
      public_url: e.optional(e.string())
    }),
    e.null()
  ),
  handler: /* @__PURE__ */ d(async (i, t) => {
    if (!await i.auth.getUserIdentity())
      return null;
    let l = await i.runQuery(n.unifiedAuth.getCurrentUser, {});
    if (!l)
      return null;
    let s = await i.runQuery(n.videoUploadGCS.getUploadProgressInternal, {
      fileUploadId: t.fileUploadId
    });
    return !s || s.related_resource_type === "video" && s.related_resource_id && await i.runQuery(n.videoUploadGCS.getUploadProgressInternal, {
      fileUploadId: s.related_resource_id
    }) && s.user_id !== l._id ? null : {
      id: s._id,
      status: s.status,
      progress_percentage: 100,
      // GCSでは進行状況の詳細追跡はクライアント側で実装
      file_size: s.file_size,
      uploaded_at: s.uploaded_at,
      completed_at: s.completed_at,
      error_message: s.processing_error,
      gcp_file_path: s.gcp_file_path,
      public_url: s.public_url
    };
  }, "handler")
}), $ = g({
  args: {
    videoId: e.id("videos"),
    fileName: e.string(),
    fileType: e.string(),
    gcpFilePath: e.string(),
    fileUploadId: e.optional(e.id("fileUploads"))
  },
  returns: e.null(),
  handler: /* @__PURE__ */ d(async (i, t) => {
    try {
      let l = (await i.runAction(n.gcsActions.generateGCPUploadUrl, {
        filename: t.fileName,
        contentType: t.fileType,
        uploadType: "video"
      })).uploadUrl;
      await i.runMutation(n.videoUploadGCS.updateVideoUploadUrl, {
        videoId: t.videoId,
        uploadUrl: l
      }), t.fileUploadId && await i.runMutation(n.videoUploadGCS.updateFileUploadUrl, {
        fileUploadId: t.fileUploadId,
        uploadUrl: l
      });
    } catch (a) {
      console.error("[generateGCSUrlAndUpdate] \u30A8\u30E9\u30FC:", a);
    }
    return null;
  }, "handler")
}), j = g({
  args: {
    videoId: e.id("videos"),
    gcpFilePath: e.string(),
    videoUrl: e.string()
  },
  returns: e.null(),
  handler: /* @__PURE__ */ d(async (i, t) => {
    let { videoId: a, gcpFilePath: l, videoUrl: s } = t;
    try {
      console.log(`[processUploadedVideo] \u5F8C\u51E6\u7406\u958B\u59CB (Video ID: ${a})`), await i.runMutation(n.videoUploadGCS.updateVideoMetadata, {
        videoId: a,
        gcpFilePath: l
      });
      let o = l.startsWith("audio/") || l.includes(".m4a") || l.includes(".mp3") || l.includes(".wav") || l.includes(".aac");
      o ? console.log(`[processUploadedVideo] \u97F3\u58F0\u30D5\u30A1\u30A4\u30EB\u3068\u3057\u3066\u51E6\u7406\u4E2D (Path: ${l})`) : (console.log(`[processUploadedVideo] \u52D5\u753B\u30D5\u30A1\u30A4\u30EB\u3068\u3057\u3066\u51E6\u7406\u4E2D (Path: ${l})`), await i.scheduler.runAfter(1e3, n.videoUploadGCS.generateThumbnail, {
        videoId: a,
        videoUrl: s,
        gcpFilePath: l
      }));
      let r = await i.runAction(
        n.transcriptions.startTranscriptionInternal,
        {
          resourceType: "video",
          resourceId: a,
          fileUrl: s,
          fileType: o ? "audio/mp4" : "video/mp4"
          // ファイルタイプを適切に設定
        }
      );
      r.success ? (console.log(
        `[processUploadedVideo] \u6587\u5B57\u8D77\u3053\u3057\u51E6\u7406\u958B\u59CB\u5B8C\u4E86 (transcriptionId: ${r.transcriptionId})`
      ), o && r.transcriptionId && r.message.includes("\u5B8C\u4E86") && (console.log("[processUploadedVideo] \u97F3\u58F0\u30D5\u30A1\u30A4\u30EB\u306E\u305F\u3081\u4E26\u5217\u5206\u6790\u3092\u958B\u59CB"), await i.scheduler.runAfter(5e3, n.googleGenAIActions.processAudioFileAnalysis, {
        transcriptionId: r.transcriptionId
      }), console.log("[processUploadedVideo] \u97F3\u58F0\u30D5\u30A1\u30A4\u30EB\u4E26\u5217\u5206\u6790\u3092\u30B9\u30B1\u30B8\u30E5\u30FC\u30EB"))) : console.error(`[processUploadedVideo] \u6587\u5B57\u8D77\u3053\u3057\u51E6\u7406\u5931\u6557: ${r.message}`), console.log(`[processUploadedVideo] \u5F8C\u51E6\u7406\u5B8C\u4E86 (Video ID: ${a})`);
    } catch (o) {
      console.error(`[processUploadedVideo] \u30A8\u30E9\u30FC (Video ID: ${a}):`, o), await i.runMutation(n.videoUploadGCS.updateVideoError, {
        videoId: a,
        errorMessage: o instanceof Error ? o.message : "\u4E0D\u660E\u306A\u30A8\u30E9\u30FC"
      });
    }
    return null;
  }, "handler")
}), M = g({
  args: {
    videoId: e.id("videos"),
    videoUrl: e.string(),
    gcpFilePath: e.string()
  },
  returns: e.null(),
  handler: /* @__PURE__ */ d(async (i, t) => {
    let { videoId: a, gcpFilePath: l } = t;
    try {
      console.log(`[generateThumbnail] \u30B5\u30E0\u30CD\u30A4\u30EB\u751F\u6210\u958B\u59CB (Video ID: ${a})`);
      let s = l.replace(/\.[^/.]+$/, "_thumbnail.jpg"), r = `https://storage.googleapis.com/${process.env.GCS_BUCKET_NAME || "ai-sales-training-hub-media"}/${s}`;
      await i.runMutation(n.videoUploadGCS.updateVideoThumbnail, {
        videoId: a,
        thumbnailUrl: r
      }), console.log(`[generateThumbnail] \u30B5\u30E0\u30CD\u30A4\u30EB\u751F\u6210\u5B8C\u4E86 (Video ID: ${a})`);
    } catch (s) {
      console.error(`[generateThumbnail] \u30A8\u30E9\u30FC (Video ID: ${a}):`, s);
    }
    return null;
  }, "handler")
}), E = _({
  args: { fileUploadId: e.id("fileUploads") },
  returns: e.union(
    e.object({
      id: e.id("fileUploads"),
      status: e.union(
        e.literal("preparing"),
        e.literal("pending"),
        e.literal("uploading"),
        e.literal("completed"),
        e.literal("failed"),
        e.literal("processing")
      ),
      progress_percentage: e.optional(e.number()),
      file_size: e.number(),
      uploaded_at: e.optional(e.number()),
      completed_at: e.optional(e.number()),
      error_message: e.optional(e.string()),
      gcp_file_path: e.optional(e.string()),
      public_url: e.optional(e.string())
    }),
    e.null()
  ),
  handler: /* @__PURE__ */ d(async (i, t) => {
    let a = await i.db.get(t.fileUploadId);
    return a ? {
      id: a._id,
      status: a.status,
      progress_percentage: 100,
      // GCSでは進行状況の詳細追跡はクライアント側で実装
      file_size: a.file_size,
      uploaded_at: a.uploaded_at,
      completed_at: a.completed_at,
      error_message: a.processing_error,
      gcp_file_path: a.gcp_file_path,
      public_url: a.public_url
    } : null;
  }, "handler")
}), k = f({
  args: {
    userId: e.id("users"),
    fileName: e.string(),
    fileType: e.string(),
    fileSize: e.number(),
    title: e.string(),
    description: e.string(),
    folderName: e.string()
  },
  returns: e.union(
    e.object({
      success: e.literal(!0),
      videoId: e.id("videos"),
      fileUploadId: e.id("fileUploads"),
      gcpFilePath: e.string()
    }),
    e.object({
      success: e.literal(!1),
      message: e.string()
    })
  ),
  handler: /* @__PURE__ */ d(async (i, t) => {
    try {
      let a = await i.db.get(t.userId);
      if (!a)
        return {
          success: !1,
          message: "User not found in unified system"
        };
      let l = Date.now(), s = Math.random().toString(36).substring(2, 15), o = encodeURIComponent(t.fileName).replace(/%/g, "_").substring(0, 100), r = `${t.folderName}/${l}-${s}-${o}`, p = await i.db.insert("videos", {
        user_id: a._id,
        title: t.title,
        description: t.description,
        type: "uploaded",
        url: "",
        // アップロード完了時に更新
        processing_status: "pending",
        content_type: t.fileType,
        file_size: t.fileSize
      }), c = await i.db.insert("fileUploads", {
        user_id: a._id,
        original_filename: t.fileName,
        content_type: t.fileType,
        file_size: t.fileSize,
        gcp_file_path: r,
        upload_type: "video",
        status: "pending",
        related_resource_type: "video",
        related_resource_id: p,
        uploaded_at: Date.now()
      });
      return {
        success: !0,
        videoId: p,
        fileUploadId: c,
        gcpFilePath: r
      };
    } catch (a) {
      return {
        success: !1,
        message: a instanceof Error ? a.message : "\u4E0D\u660E\u306A\u30A8\u30E9\u30FC"
      };
    }
  }, "handler")
}), D = f({
  args: {
    videoId: e.id("videos"),
    uploadUrl: e.string()
  },
  returns: e.null(),
  handler: /* @__PURE__ */ d(async (i, t) => (await i.db.patch(t.videoId, {
    url: t.uploadUrl
  }), null), "handler")
}), B = f({
  args: {
    videoId: e.id("videos"),
    gcpFilePath: e.string(),
    fileSize: e.optional(e.number()),
    contentType: e.optional(e.string()),
    duration: e.optional(e.number())
  },
  returns: e.null(),
  handler: /* @__PURE__ */ d(async (i, t) => {
    let { videoId: a, gcpFilePath: l, fileSize: s, contentType: o, duration: r } = t, p = {
      gcs_file_path: l
    };
    return s !== void 0 && (p.file_size = s), o !== void 0 && (p.content_type = o), r !== void 0 && (p.duration_seconds = r), await i.db.patch(a, p), null;
  }, "handler")
}), R = f({
  args: {
    videoId: e.id("videos"),
    thumbnailUrl: e.string()
  },
  returns: e.null(),
  handler: /* @__PURE__ */ d(async (i, t) => (await i.db.patch(t.videoId, {
    thumbnail_url: t.thumbnailUrl
  }), null), "handler")
}), x = f({
  args: {
    fileUploadId: e.id("fileUploads"),
    uploadUrl: e.string()
  },
  returns: e.null(),
  handler: /* @__PURE__ */ d(async (i, t) => (await i.db.patch(t.fileUploadId, {
    public_url: t.uploadUrl,
    status: "uploading"
  }), null), "handler")
}), Q = f({
  args: {
    videoId: e.id("videos"),
    errorMessage: e.string()
  },
  returns: e.null(),
  handler: /* @__PURE__ */ d(async (i, t) => (await i.db.patch(t.videoId, {
    error_message: t.errorMessage,
    processing_status: "failed"
  }), null), "handler")
}), q = g({
  args: { fileUploadId: e.string() },
  returns: e.any(),
  handler: /* @__PURE__ */ d(async (i, t) => {
    try {
      return {
        success: !0,
        data: await i.runQuery(n.videoUploadGCS.getUploadProgressInternal, {
          fileUploadId: t.fileUploadId
        })
      };
    } catch (a) {
      return {
        success: !1,
        message: a instanceof Error ? a.message : "\u4E0D\u660E\u306A\u30A8\u30E9\u30FC"
      };
    }
  }, "handler")
});
export {
  A as completeUpload,
  k as createVideoAndFileRecord,
  C as generateBatchUploadUrls,
  $ as generateGCSUrlAndUpdate,
  M as generateThumbnail,
  z as generateUploadUrl,
  N as getActualUploadUrl,
  G as getUploadProgress,
  E as getUploadProgressInternal,
  q as httpGetUploadProgress,
  j as processUploadedVideo,
  x as updateFileUploadUrl,
  Q as updateVideoError,
  B as updateVideoMetadata,
  R as updateVideoThumbnail,
  D as updateVideoUploadUrl
};
//# sourceMappingURL=videoUploadGCS.js.map
