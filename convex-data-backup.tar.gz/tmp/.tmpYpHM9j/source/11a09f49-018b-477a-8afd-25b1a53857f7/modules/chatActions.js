"use node";
import {
  o as m
} from "./_deps/node/NAH3KYY3.js";
import "./_deps/node/SEHFPZI7.js";
import "./_deps/node/27HPQ4GU.js";
import "./_deps/node/WLMMRF4U.js";
import "./_deps/node/YKKTZAAP.js";
import "./_deps/node/2SFASJNQ.js";
import "./_deps/node/BSU5XI2C.js";
import {
  d as c
} from "./_deps/node/PDGHC3PS.js";
import {
  a as t
} from "./_deps/node/UDHF6CTX.js";
import {
  a as o
} from "./_deps/node/V7X2J7BI.js";

// convex/chatActions.ts
var I = c({
  args: {
    sessionId: t.string(),
    userMessage: t.string(),
    userId: t.id("users"),
    // Required - userId should always be provided
    legacyUserId: t.optional(t.string())
    // Historical legacy user ID (string)
  },
  returns: t.null(),
  handler: /* @__PURE__ */ o(async (n, a) => {
    try {
      let e = [], r = [], i = await y(
        a.userMessage,
        r,
        e
      );
    } catch (e) {
      console.error("Error generating AI response:", e);
    }
  }, "handler")
});
function l(n, a, e = []) {
  let r = a.map((s) => `
## ${s.trainingTitle}

### \u8981\u7D04
${s.summary}

### \u91CD\u8981\u306A\u30DD\u30A4\u30F3\u30C8
${s.keyPoints.map((g) => `- ${g}`).join(`
`)}

### \u5B66\u7FD2\u76EE\u6A19
${s.learningObjectives.map((g) => `- ${g}`).join(`
`)}
`).join(`

`), i = e.length > 0 ? e.map((s) => `${s.role === "user" ? "\u30E6\u30FC\u30B6\u30FC" : "\u30A2\u30B7\u30B9\u30BF\u30F3\u30C8"}: ${s.message}`).join(`
`) : "\uFF08\u521D\u56DE\u306E\u8CEA\u554F\u3067\u3059\uFF09";
  return `
\u3042\u306A\u305F\u306F\u55B6\u696D\u30C8\u30EC\u30FC\u30CB\u30F3\u30B0\u306E\u5C02\u9580AI\u30A2\u30B7\u30B9\u30BF\u30F3\u30C8\u3067\u3059\u3002\u4EE5\u4E0B\u306E\u7814\u4FEE\u30B3\u30F3\u30C6\u30F3\u30C4\u306E\u5185\u5BB9\u3092\u8E0F\u307E\u3048\u3066\u3001\u30E6\u30FC\u30B6\u30FC\u306E\u8CEA\u554F\u306B\u89AA\u5207\u3067\u5B9F\u8DF5\u7684\u306A\u56DE\u7B54\u3092\u3057\u3066\u304F\u3060\u3055\u3044\u3002

## \u7814\u4FEE\u30B3\u30F3\u30C6\u30F3\u30C4
${r}

## \u4F1A\u8A71\u5C65\u6B74
${i}

## \u30E6\u30FC\u30B6\u30FC\u306E\u8CEA\u554F
${n}

\u56DE\u7B54\u306E\u6307\u91DD:
- \u7814\u4FEE\u30B3\u30F3\u30C6\u30F3\u30C4\u306E\u5185\u5BB9\u306B\u57FA\u3065\u3044\u3066\u56DE\u7B54\u3057\u3066\u304F\u3060\u3055\u3044
- \u5177\u4F53\u7684\u3067\u5B9F\u8DF5\u7684\u306A\u30A2\u30C9\u30D0\u30A4\u30B9\u3092\u63D0\u4F9B\u3057\u3066\u304F\u3060\u3055\u3044
- \u5FC5\u8981\u306B\u5FDC\u3058\u3066\u4F8B\u3084\u5177\u4F53\u7684\u306A\u624B\u6CD5\u3092\u793A\u3057\u3066\u304F\u3060\u3055\u3044
- \u55B6\u696D\u30B9\u30AD\u30EB\u5411\u4E0A\u306B\u5F79\u7ACB\u3064\u8FFD\u52A0\u306E\u8996\u70B9\u3082\u63D0\u4F9B\u3057\u3066\u304F\u3060\u3055\u3044
- \u3082\u3057\u7814\u4FEE\u30B3\u30F3\u30C6\u30F3\u30C4\u306B\u8A72\u5F53\u3059\u308B\u60C5\u5831\u304C\u306A\u3044\u5834\u5408\u306F\u3001\u4E00\u822C\u7684\u306A\u55B6\u696D\u77E5\u8B58\u3067\u88DC\u5B8C\u3057\u3066\u304F\u3060\u3055\u3044
- \u4E01\u5BE7\u3067\u89AA\u3057\u307F\u3084\u3059\u3044\u53E3\u8ABF\u3067\u56DE\u7B54\u3057\u3066\u304F\u3060\u3055\u3044
- \u56DE\u7B54\u306F300-500\u6587\u5B57\u7A0B\u5EA6\u3067\u7C21\u6F54\u306B\u307E\u3068\u3081\u3066\u304F\u3060\u3055\u3044

\u56DE\u7B54\u306E\u307F\u3092\u51FA\u529B\u3057\u3066\u304F\u3060\u3055\u3044\u3002JSON\u3084\u30DE\u30FC\u30AF\u30C0\u30A6\u30F3\u306F\u4F7F\u7528\u3057\u306A\u3044\u3067\u304F\u3060\u3055\u3044\u3002
`;
}
o(l, "buildChatPrompt");
async function p(n) {
  return await m(n);
}
o(p, "callVertexAI");
function u(n) {
  return n.trim();
}
o(u, "processAIResponse");
async function y(n, a, e = []) {
  try {
    let r = l(n, a, e), i = await p(r);
    return u(i);
  } catch (r) {
    console.error("Vertex AI error:", r);
    let i = r instanceof Error ? r.message : String(r);
    throw new Error(`AI\u5FDC\u7B54\u306E\u751F\u6210\u306B\u5931\u6557\u3057\u307E\u3057\u305F: ${i}`);
  }
}
o(y, "generateContextualResponse");
export {
  I as generateAIResponse
};
//# sourceMappingURL=chatActions.js.map
