import {
  a as y,
  b,
  e as g
} from "./_deps/IVQGLTSC.js";
import {
  a as p,
  b as U,
  c as f,
  d as I
} from "./_deps/75JH2J25.js";
import "./_deps/6XQQNYIR.js";
import {
  j as e,
  l as u,
  n as w
} from "./_deps/3TDUHHJO.js";
import {
  a as d
} from "./_deps/RUVYHBJQ.js";

// convex/unifiedAuth.ts
w();
w();
g();
var c = {
  ADMIN: "admin",
  TRAINER: "trainer",
  EMPLOYEE: "employee",
  VIEWER: "viewer"
}, D = {
  PENDING: "pending",
  IN_PROGRESS: "in_progress",
  COMPLETED: "completed",
  FAILED: "failed"
}, N = p({
  args: {},
  returns: e.union(
    e.null(),
    e.object({
      _id: e.id("users"),
      clerkUserId: e.string(),
      email: e.string(),
      name: e.string(),
      role: e.string(),
      department: e.optional(e.string()),
      position: e.optional(e.string()),
      isActive: e.boolean(),
      lastLoginAt: e.optional(e.number()),
      imageUrl: e.optional(e.string())
    })
  ),
  handler: /* @__PURE__ */ d(async (t) => {
    let i = await t.auth.getUserIdentity();
    if (!i) return null;
    let o = await t.db.query("users").withIndex("by_clerk_user_id", (r) => r.eq("clerkUserId", i.subject)).first();
    return o ? {
      _id: o._id,
      clerkUserId: o.clerkUserId,
      email: o.email,
      name: o.name,
      role: o.role,
      department: o.department,
      position: o.position,
      isActive: o.isActive,
      lastLoginAt: o.lastLoginAt,
      imageUrl: o.imageUrl
    } : null;
  }, "handler")
}), R = f({
  args: {
    clerkData: e.object({
      clerkUserId: e.string(),
      email: e.string(),
      firstName: e.optional(e.string()),
      lastName: e.optional(e.string()),
      imageUrl: e.optional(e.string()),
      emailVerified: e.boolean()
    }),
    userProfile: e.optional(
      e.object({
        employeeId: e.optional(e.string()),
        department: e.optional(e.string()),
        position: e.optional(e.string()),
        role: e.optional(e.string())
      })
    )
  },
  returns: e.object({
    userId: e.id("users"),
    isNewUser: e.boolean(),
    migrationNeeded: e.boolean()
  }),
  handler: /* @__PURE__ */ d(async (t, i) => {
    let o = await t.auth.getUserIdentity();
    if (!o)
      throw new u("\u8A8D\u8A3C\u304C\u5FC5\u8981\u3067\u3059");
    let r = await t.db.query("users").withIndex("by_clerk_user_id", (s) => s.eq("clerkUserId", i.clerkData.clerkUserId)).first();
    if (r)
      return await t.db.patch(r._id, {
        email: i.clerkData.email,
        firstName: i.clerkData.firstName,
        lastName: i.clerkData.lastName,
        imageUrl: i.clerkData.imageUrl,
        emailVerified: i.clerkData.emailVerified,
        lastLoginAt: Date.now(),
        ...i.userProfile && {
          employeeId: i.userProfile.employeeId,
          department: i.userProfile.department,
          position: i.userProfile.position,
          ...i.userProfile.role && { role: i.userProfile.role }
        }
      }), {
        userId: r._id,
        isNewUser: !1,
        migrationNeeded: !1
      };
    if (await t.runQuery(b.unifiedAuth.findMigrationCandidate, {
      email: i.clerkData.email
    }))
      throw new u("\u3053\u306E\u30E1\u30FC\u30EB\u30A2\u30C9\u30EC\u30B9\u306F\u65E2\u306B\u4F7F\u7528\u3055\u308C\u3066\u3044\u307E\u3059");
    let l = [i.clerkData.firstName, i.clerkData.lastName].filter(Boolean).join(" ") || i.clerkData.email;
    return {
      userId: await t.db.insert("users", {
        clerkUserId: i.clerkData.clerkUserId,
        tokenIdentifier: o.tokenIdentifier,
        email: i.clerkData.email,
        emailVerified: i.clerkData.emailVerified,
        name: l,
        firstName: i.clerkData.firstName,
        lastName: i.clerkData.lastName,
        imageUrl: i.clerkData.imageUrl,
        employeeId: i.userProfile?.employeeId,
        department: i.userProfile?.department,
        position: i.userProfile?.position,
        role: i.userProfile?.role || c.EMPLOYEE,
        isActive: !0,
        joinDate: Date.now(),
        lastLoginAt: Date.now()
      }),
      isNewUser: !0,
      migrationNeeded: !1
    };
  }, "handler")
}), E = p({
  args: {
    requiredRole: e.optional(e.string()),
    resourceOwnerId: e.optional(e.id("users"))
  },
  returns: e.object({
    hasPermission: e.boolean(),
    userRole: e.string(),
    isOwner: e.boolean(),
    isAdmin: e.boolean()
  }),
  handler: /* @__PURE__ */ d(async (t, i) => {
    let o = await t.auth.getUserIdentity();
    if (!o)
      return {
        hasPermission: !1,
        userRole: "anonymous",
        isOwner: !1,
        isAdmin: !1
      };
    let r = await t.db.query("users").withIndex("by_clerk_user_id", (s) => s.eq("clerkUserId", o.subject)).first();
    if (!r || !r.isActive)
      return {
        hasPermission: !1,
        userRole: "inactive",
        isOwner: !1,
        isAdmin: !1
      };
    let a = r.role === c.ADMIN, l = i.resourceOwnerId ? r._id === i.resourceOwnerId : !1, n = !0;
    if (i.requiredRole) {
      let s = {
        [c.VIEWER]: 1,
        [c.EMPLOYEE]: 2,
        [c.TRAINER]: 3,
        [c.ADMIN]: 4
      }, m = s[r.role] || 0, h = s[i.requiredRole] || 999;
      n = m >= h || l || a;
    }
    return {
      hasPermission: n,
      userRole: r.role,
      isOwner: l,
      isAdmin: a
    };
  }, "handler")
}), P = f({
  args: {
    updates: e.object({
      firstName: e.optional(e.string()),
      lastName: e.optional(e.string()),
      department: e.optional(e.string()),
      position: e.optional(e.string()),
      employeeId: e.optional(e.string())
    })
  },
  returns: e.object({ success: e.boolean() }),
  handler: /* @__PURE__ */ d(async (t, i) => {
    let o = await t.auth.getUserIdentity();
    if (!o)
      throw new u("\u8A8D\u8A3C\u304C\u5FC5\u8981\u3067\u3059");
    let r = await t.db.query("users").withIndex("by_clerk_user_id", (l) => l.eq("clerkUserId", o.subject)).first();
    if (!r)
      throw new u("\u30E6\u30FC\u30B6\u30FC\u304C\u898B\u3064\u304B\u308A\u307E\u305B\u3093");
    let a = [i.updates.firstName, i.updates.lastName].filter(Boolean).join(" ") || r.name;
    return await t.db.patch(r._id, {
      ...i.updates,
      name: a
    }), { success: !0 };
  }, "handler")
}), v = I({
  args: { userId: e.id("users") },
  returns: e.null(),
  handler: /* @__PURE__ */ d(async (t, i) => (await t.db.patch(i.userId, {
    lastLoginAt: Date.now()
  }), null), "handler")
}), L = U({
  args: { email: e.string() },
  returns: e.union(
    e.null(),
    e.object({
      betterAuthUserId: e.optional(e.string()),
      legacyUserId: e.optional(e.string())
    })
  ),
  handler: /* @__PURE__ */ d(async (t, i) => (await t.db.query("users").withIndex("by_email", (r) => r.eq("email", i.email)).first(), null), "handler")
}), j = I({
  args: {
    clerkUserId: e.string(),
    unifiedUserId: e.id("users"),
    betterAuthUserId: e.optional(e.string()),
    legacyUserId: e.optional(e.string())
  },
  returns: e.null(),
  handler: /* @__PURE__ */ d(async (t, i) => null, "handler")
}), O = p({
  args: {
    query: e.optional(e.string()),
    role: e.optional(e.string()),
    department: e.optional(e.string()),
    isActive: e.optional(e.boolean()),
    limit: e.optional(e.number())
  },
  returns: e.array(
    e.object({
      _id: e.id("users"),
      clerkUserId: e.string(),
      email: e.string(),
      name: e.string(),
      role: e.string(),
      department: e.optional(e.string()),
      position: e.optional(e.string()),
      isActive: e.boolean(),
      joinDate: e.number(),
      lastLoginAt: e.optional(e.number())
    })
  ),
  handler: /* @__PURE__ */ d(async (t, i) => {
    if (!(await t.runQuery(y.unifiedAuth.checkUserPermission, {
      requiredRole: c.ADMIN
    })).hasPermission)
      throw new u("\u7BA1\u7406\u8005\u6A29\u9650\u304C\u5FC5\u8981\u3067\u3059");
    let r = typeof i.isActive == "boolean" ? i.isActive : void 0, a;
    if (i.role && i.role.trim() !== "") {
      let n = i.role;
      a = t.db.query("users").withIndex("by_role", (m) => m.eq("role", n));
    } else if (i.department && i.department.trim() !== "") {
      let n = i.department;
      a = t.db.query("users").withIndex("by_department", (m) => m.eq("department", n));
    } else r !== void 0 ? a = t.db.query("users").withIndex("by_is_active", (s) => s.eq("isActive", r)) : a = t.db.query("users");
    let l = await a.take(i.limit || 50);
    if (r !== void 0 && !i.role && !i.department || r !== void 0 && (l = l.filter((n) => n.isActive === r)), i.query && i.query.trim() !== "") {
      let n = i.query.toLowerCase();
      return l.filter(
        (s) => s.name.toLowerCase().includes(n) || s.email.toLowerCase().includes(n) || s.employeeId && s.employeeId.toLowerCase().includes(n)
      );
    }
    return l.map((n) => ({
      _id: n._id,
      clerkUserId: n.clerkUserId,
      email: n.email,
      name: n.name,
      role: n.role,
      department: n.department,
      position: n.position,
      isActive: n.isActive,
      joinDate: n.joinDate,
      lastLoginAt: n.lastLoginAt
    }));
  }, "handler")
}), M = f({
  args: {
    userId: e.id("users"),
    newRole: e.string(),
    reason: e.optional(e.string())
  },
  returns: e.object({ success: e.boolean() }),
  handler: /* @__PURE__ */ d(async (t, i) => {
    if (!(await t.runQuery(y.unifiedAuth.checkUserPermission, {
      requiredRole: c.ADMIN
    })).hasPermission)
      throw new u("\u7BA1\u7406\u8005\u6A29\u9650\u304C\u5FC5\u8981\u3067\u3059");
    if (!Object.values(c).includes(i.newRole))
      throw new u("\u7121\u52B9\u306A\u5F79\u5272\u3067\u3059");
    let r = await t.db.get(i.userId);
    if (!r)
      throw new u("\u30E6\u30FC\u30B6\u30FC\u304C\u898B\u3064\u304B\u308A\u307E\u305B\u3093");
    return await t.db.patch(i.userId, {
      role: i.newRole
    }), await t.runMutation(y.securityMonitor.logSecurityEvent, {
      event_type: "user_privilege_change",
      severity: 2,
      target_user_id: i.userId,
      details: {
        target_user_id: i.userId,
        old_role: r.role,
        new_role: i.newRole,
        reason: i.reason || "\u7BA1\u7406\u8005\u306B\u3088\u308B\u5909\u66F4"
      }
    }), { success: !0 };
  }, "handler")
});
export {
  D as MIGRATION_STATUS,
  c as USER_ROLES,
  E as checkUserPermission,
  j as createMigrationLog,
  L as findMigrationCandidate,
  N as getCurrentUser,
  O as searchUsers,
  R as syncClerkUser,
  v as updateLastLogin,
  P as updateUserProfile,
  M as updateUserRole
};
//# sourceMappingURL=unifiedAuth.js.map
