import {
  a as g,
  b as l,
  e as v
} from "./_deps/IVQGLTSC.js";
import {
  a as f,
  b as _,
  c as I,
  d,
  e as w,
  f as y
} from "./_deps/75JH2J25.js";
import "./_deps/6XQQNYIR.js";
import {
  j as e,
  n as S
} from "./_deps/3TDUHHJO.js";
import {
  a as c
} from "./_deps/RUVYHBJQ.js";

// convex/transcriptions.ts
S();
v();
var $ = f({
  args: { transcriptionId: e.id("transcriptions") },
  returns: e.union(
    e.object({
      success: e.boolean(),
      status: e.string(),
      message: e.string()
    }),
    e.null()
  ),
  handler: /* @__PURE__ */ c(async (n, r) => {
    try {
      let t = await n.db.get(r.transcriptionId);
      return t ? {
        success: !0,
        status: t.status,
        message: "\u30B9\u30C6\u30FC\u30BF\u30B9\u3092\u53D6\u5F97\u3057\u307E\u3057\u305F"
      } : {
        success: !1,
        status: "not_found",
        message: "\u6307\u5B9A\u3055\u308C\u305Ftranscription\u304C\u898B\u3064\u304B\u308A\u307E\u305B\u3093"
      };
    } catch (t) {
      return console.error("[getTranscriptionStatus] \u30A8\u30E9\u30FC:", t), {
        success: !1,
        status: "error",
        message: t instanceof Error ? t.message : "\u4E0D\u660E\u306A\u30A8\u30E9\u30FC\u304C\u767A\u751F\u3057\u307E\u3057\u305F"
      };
    }
  }, "handler")
}), R = y({
  args: {
    resourceType: e.union(e.literal("video"), e.literal("training_content")),
    resourceId: e.string(),
    fileUrl: e.string(),
    fileType: e.string(),
    options: e.optional(
      e.object({
        enableSpeakerDiarization: e.optional(e.boolean()),
        enableAiEvaluation: e.optional(e.boolean()),
        enableContentAnalysis: e.optional(e.boolean()),
        language: e.optional(e.string()),
        autoStartAnalysis: e.optional(e.boolean())
      })
    )
  },
  returns: e.null(),
  handler: /* @__PURE__ */ c(async (n, r) => {
    try {
      console.log(`[startTranscription] \u958B\u59CB: ${r.resourceType}/${r.resourceId}`);
      let t = await n.runQuery(l.transcriptions.getExistingTranscription, {
        resourceType: r.resourceType,
        resourceId: r.resourceId
      });
      if (t)
        return console.log(`[startTranscription] \u65E2\u5B58\u306E\u6587\u5B57\u8D77\u3053\u3057\u3092\u767A\u898B: ${t.id}`), null;
      let s = "", a = "failed";
      try {
        console.log(`[startTranscription] ElevenLabs API\u547C\u3073\u51FA\u3057\u958B\u59CB: ${r.fileUrl}`);
        let o = await n.runAction(
          g.transcriptionActions.performElevenLabsTranscription,
          {
            fileUrl: r.fileUrl,
            fileType: r.fileType,
            options: {
              enableSpeakerDiarization: r.options?.enableSpeakerDiarization || !0,
              language: r.options?.language || "ja"
            }
          }
        );
        if (o && o.text)
          s = o.text, a = "completed", console.log(`[startTranscription] ElevenLabs\u6587\u5B57\u8D77\u3053\u3057\u6210\u529F: ${s.length}\u6587\u5B57`);
        else
          throw new Error("ElevenLabs API\u304B\u3089\u7121\u52B9\u306A\u30EC\u30B9\u30DD\u30F3\u30B9");
      } catch (o) {
        console.error("[startTranscription] ElevenLabs\u6587\u5B57\u8D77\u3053\u3057\u30A8\u30E9\u30FC:", o), s = `\u6587\u5B57\u8D77\u3053\u3057\u51E6\u7406\u4E2D\u306B\u30A8\u30E9\u30FC\u304C\u767A\u751F\u3057\u307E\u3057\u305F: ${o instanceof Error ? o.message : "\u4E0D\u660E\u306A\u30A8\u30E9\u30FC"}`, a = "failed";
      }
      let i = await n.runMutation(
        l.transcriptions.createTranscriptionRecord,
        {
          resourceType: r.resourceType,
          resourceId: r.resourceId,
          text: s,
          status: a
        }
      );
      if (r.resourceType === "training_content")
        try {
          await n.runMutation(g.training.updateModuleTranscriptionStatus, {
            moduleId: r.resourceId,
            status: a === "completed" ? "completed" : "failed",
            error: a === "failed" ? s : void 0
          }), console.log(`[startTranscription] \u30E2\u30B8\u30E5\u30FC\u30EB\u30B9\u30C6\u30FC\u30BF\u30B9\u66F4\u65B0\u5B8C\u4E86: ${r.resourceId}`);
        } catch (o) {
          console.error("[startTranscription] \u30E2\u30B8\u30E5\u30FC\u30EB\u30B9\u30C6\u30FC\u30BF\u30B9\u66F4\u65B0\u30A8\u30E9\u30FC:", o);
        }
      if (r.options?.enableAiEvaluation && a === "completed")
        try {
          if (console.log(`[startTranscription] AI\u8A55\u4FA1\u958B\u59CB: transcriptionId=${i}`), r.resourceType === "video") {
            let o = await n.runMutation(l.evaluations.startEvaluationInternal, {
              transcriptionId: i,
              videoId: r.resourceId,
              transcript: s,
              videoType: "\u8B72\u6E21\u67B6\u96FB",
              // Transfer meetingに適した評価タイプ
              autoRetry: !0
            });
            console.log("[startTranscription] AI\u8A55\u4FA1\u958B\u59CB\u7D50\u679C:", o);
          }
        } catch (o) {
          console.error("[startTranscription] AI\u8A55\u4FA1\u958B\u59CB\u30A8\u30E9\u30FC:", o);
        }
      return console.log(`[startTranscription] \u5B8C\u4E86: ${i}`), null;
    } catch (t) {
      return console.error("[startTranscription] \u30A8\u30E9\u30FC:", t), null;
    }
  }, "handler")
}), U = _({
  args: {
    resourceType: e.union(e.literal("video"), e.literal("training_content")),
    resourceId: e.string()
  },
  returns: e.union(
    e.null(),
    e.object({
      id: e.id("transcriptions"),
      status: e.string()
    })
  ),
  handler: /* @__PURE__ */ c(async (n, r) => {
    let t = await n.db.query("transcriptions").withIndex(
      "by_resource",
      (s) => s.eq("resource_type", r.resourceType).eq("resource_id", r.resourceId)
    ).first();
    return t ? {
      id: t._id,
      status: t.status
    } : null;
  }, "handler")
}), k = d({
  args: {
    resourceType: e.union(e.literal("video"), e.literal("training_content")),
    resourceId: e.string(),
    text: e.string(),
    status: e.union(e.literal("pending"), e.literal("completed"), e.literal("failed"))
  },
  returns: e.id("transcriptions"),
  handler: /* @__PURE__ */ c(async (n, r) => {
    let t = Date.now(), s = {
      resource_type: r.resourceType,
      resource_id: r.resourceId,
      text: r.text,
      status: r.status,
      created_at: t,
      updated_at: t
    };
    return r.resourceType === "video" && (s.enable_ai_evaluation = !0, s.speaker_analysis_status = "pending", s.evaluation_status = "pending", s.meeting_minutes_status = "pending", s.case_summary_status = "pending", s.meeting_summary_status = "pending"), await n.db.insert("transcriptions", s);
  }, "handler")
}), E = d({
  args: {
    resourceType: e.union(e.literal("video"), e.literal("training_content")),
    resourceId: e.string()
  },
  returns: e.id("transcriptions"),
  handler: /* @__PURE__ */ c(async (n, r) => {
    let t = Date.now(), s = {
      resource_type: r.resourceType,
      resource_id: r.resourceId,
      text: "",
      // 処理開始時は空
      status: "processing",
      // 文字起こし処理中
      created_at: t,
      updated_at: t
    };
    return r.resourceType === "video" && (s.enable_ai_evaluation = !0, s.speaker_analysis_status = "pending", s.evaluation_status = "pending", s.meeting_minutes_status = "pending", s.case_summary_status = "pending", s.meeting_summary_status = "pending"), await n.db.insert("transcriptions", s);
  }, "handler")
}), F = d({
  args: {
    transcriptionId: e.id("transcriptions"),
    text: e.string(),
    status: e.union(e.literal("completed"), e.literal("failed"))
  },
  returns: e.null(),
  handler: /* @__PURE__ */ c(async (n, r) => (await n.db.patch(r.transcriptionId, {
    text: r.text,
    status: r.status,
    updated_at: Date.now()
  }), null), "handler")
}), M = d({
  args: {
    resourceType: e.union(e.literal("video"), e.literal("training_content")),
    resourceId: e.string(),
    text: e.string(),
    status: e.union(e.literal("pending"), e.literal("completed"), e.literal("failed"))
  },
  returns: e.id("transcriptions"),
  handler: /* @__PURE__ */ c(async (n, r) => {
    let t = Date.now(), s = {
      resource_type: r.resourceType,
      resource_id: r.resourceId,
      text: r.text,
      status: r.status,
      created_at: t,
      updated_at: t
    };
    return r.resourceType === "video" && (s.enable_ai_evaluation = !0, s.speaker_analysis_status = "pending", s.evaluation_status = "pending", s.meeting_minutes_status = "pending", s.case_summary_status = "pending", s.meeting_summary_status = "pending"), await n.db.insert("transcriptions", s);
  }, "handler")
}), j = I({
  args: {
    resourceType: e.union(e.literal("video"), e.literal("training_content")),
    resourceId: e.string(),
    text: e.string()
  },
  returns: e.object({
    success: e.boolean(),
    message: e.string(),
    transcriptionId: e.optional(e.id("transcriptions"))
  }),
  handler: /* @__PURE__ */ c(async (n, r) => {
    try {
      if (!await n.auth.getUserIdentity())
        return {
          success: !1,
          message: "\u8A8D\u8A3C\u304C\u5FC5\u8981\u3067\u3059"
        };
      let s = await n.db.query("transcriptions").withIndex(
        "by_resource",
        (u) => u.eq("resource_type", r.resourceType).eq("resource_id", r.resourceId)
      ).first();
      if (s)
        return {
          success: !0,
          message: s.status === "completed" ? "\u6587\u5B57\u8D77\u3053\u3057\u306F\u65E2\u306B\u5B8C\u4E86\u3057\u3066\u3044\u307E\u3059" : "\u6587\u5B57\u8D77\u3053\u3057\u51E6\u7406\u4E2D\u3067\u3059",
          transcriptionId: s._id
        };
      let a = Date.now(), i = {
        resource_type: r.resourceType,
        resource_id: r.resourceId,
        text: r.text,
        status: "pending",
        created_at: a,
        updated_at: a
      };
      r.resourceType === "video" && (i.enable_ai_evaluation = !0, i.evaluation_status = "pending", i.meeting_minutes_status = "pending", i.case_summary_status = "pending", i.meeting_summary_status = "pending");
      let o = await n.db.insert("transcriptions", i);
      return await n.scheduler.runAfter(1e3, l.transcriptions.completeTranscription, {
        transcriptionId: o
      }), {
        success: !0,
        message: "\u6587\u5B57\u8D77\u3053\u3057\u3092\u958B\u59CB\u3057\u307E\u3057\u305F",
        transcriptionId: o
      };
    } catch (t) {
      return console.error("[startPublicTranscription] \u30A8\u30E9\u30FC:", t), {
        success: !1,
        message: t instanceof Error ? t.message : "\u4E0D\u660E\u306A\u30A8\u30E9\u30FC\u304C\u767A\u751F\u3057\u307E\u3057\u305F"
      };
    }
  }, "handler")
}), L = d({
  args: { transcriptionId: e.id("transcriptions") },
  returns: e.null(),
  handler: /* @__PURE__ */ c(async (n, r) => {
    try {
      await n.db.patch(r.transcriptionId, {
        status: "completed",
        updated_at: Date.now()
      });
    } catch (t) {
      console.error("\u6587\u5B57\u8D77\u3053\u3057\u5B8C\u4E86\u66F4\u65B0\u30A8\u30E9\u30FC:", t), await n.db.patch(r.transcriptionId, {
        status: "failed",
        updated_at: Date.now()
      });
    }
    return null;
  }, "handler")
}), P = I({
  args: {
    resourceType: e.union(e.literal("video"), e.literal("training_content")),
    resourceId: e.string(),
    text: e.string()
  },
  returns: e.object({
    success: e.boolean(),
    message: e.string(),
    transcriptionId: e.optional(e.id("transcriptions"))
  }),
  handler: /* @__PURE__ */ c(async (n, r) => {
    try {
      if (!await n.auth.getUserIdentity())
        return {
          success: !1,
          message: "\u8A8D\u8A3C\u304C\u5FC5\u8981\u3067\u3059"
        };
      let s = await n.db.query("transcriptions").withIndex(
        "by_resource",
        (u) => u.eq("resource_type", r.resourceType).eq("resource_id", r.resourceId)
      ).first();
      if (s && s.status === "completed")
        return {
          success: !0,
          message: "\u6587\u5B57\u8D77\u3053\u3057\u306F\u65E2\u306B\u5B8C\u4E86\u3057\u3066\u3044\u307E\u3059",
          transcriptionId: s._id
        };
      let a = Date.now(), i = {
        resource_type: r.resourceType,
        resource_id: r.resourceId,
        text: r.text,
        status: "completed",
        created_at: a,
        updated_at: a
      };
      return r.resourceType === "video" && (i.enable_ai_evaluation = !0, i.evaluation_status = "pending", i.meeting_minutes_status = "pending", i.case_summary_status = "pending", i.meeting_summary_status = "pending"), {
        success: !0,
        message: "\u6587\u5B57\u8D77\u3053\u3057\u304C\u5B8C\u4E86\u3057\u307E\u3057\u305F",
        transcriptionId: await n.db.insert("transcriptions", i)
      };
    } catch (t) {
      return console.error("[startBasicTranscription] \u30A8\u30E9\u30FC:", t), {
        success: !1,
        message: t instanceof Error ? t.message : "\u4E0D\u660E\u306A\u30A8\u30E9\u30FC\u304C\u767A\u751F\u3057\u307E\u3057\u305F"
      };
    }
  }, "handler")
}), q = f({
  args: { transcriptionId: e.id("transcriptions") },
  returns: e.union(
    e.object({
      success: e.boolean(),
      message: e.string(),
      data: e.optional(
        e.object({
          id: e.id("transcriptions"),
          text: e.string(),
          status: e.string(),
          resource_type: e.string(),
          resource_id: e.string(),
          transcript_with_speaker: e.optional(e.string()),
          _creationTime: e.number()
        })
      )
    }),
    e.null()
  ),
  handler: /* @__PURE__ */ c(async (n, r) => {
    try {
      console.log(`[getTranscriptionResult] transcriptionId\u53D6\u5F97\u958B\u59CB: ${r.transcriptionId}`);
      let t = await n.db.get(r.transcriptionId);
      if (!t)
        return console.log(`[getTranscriptionResult] transcription\u898B\u3064\u304B\u3089\u305A: ${r.transcriptionId}`), {
          success: !1,
          message: "\u6307\u5B9A\u3055\u308C\u305Ftranscription\u304C\u898B\u3064\u304B\u308A\u307E\u305B\u3093"
        };
      console.log(`[getTranscriptionResult] transcription\u53D6\u5F97\u6210\u529F: ${r.transcriptionId}`, {
        textLength: t.text?.length || 0,
        status: t.status,
        resource_type: t.resource_type,
        hasTranscriptWithSpeaker: !!t.transcript_with_speaker
      });
      let s = {
        success: !0,
        message: "\u6587\u5B57\u8D77\u3053\u3057\u7D50\u679C\u3092\u53D6\u5F97\u3057\u307E\u3057\u305F",
        data: {
          id: t._id,
          text: t.text || "",
          status: t.status,
          resource_type: t.resource_type,
          resource_id: t.resource_id,
          transcript_with_speaker: t.transcript_with_speaker,
          _creationTime: t._creationTime
        }
      };
      return console.log(`[getTranscriptionResult] \u30EC\u30B9\u30DD\u30F3\u30B9\u6E96\u5099\u5B8C\u4E86: ${r.transcriptionId}`), s;
    } catch (t) {
      return console.error(`[getTranscriptionResult] \u30A8\u30E9\u30FC\u767A\u751F: ${r.transcriptionId}`, {
        message: t instanceof Error ? t.message : "Unknown error",
        stack: t instanceof Error ? t.stack : "No stack trace",
        type: typeof t,
        name: t instanceof Error ? t.constructor.name : "Unknown"
      }), {
        success: !1,
        message: "\u5185\u90E8\u30A8\u30E9\u30FC\u304C\u767A\u751F\u3057\u307E\u3057\u305F"
      };
    }
  }, "handler")
}), B = d({
  args: { transcriptionId: e.id("transcriptions") },
  returns: e.union(
    e.object({
      _id: e.id("transcriptions"),
      text: e.string(),
      status: e.string(),
      resource_type: e.string(),
      resource_id: e.string(),
      transcript_with_speaker: e.optional(e.string()),
      _creationTime: e.number()
    }),
    e.null()
  ),
  handler: /* @__PURE__ */ c(async (n, r) => {
    let t = await n.db.get(r.transcriptionId);
    return t ? {
      _id: t._id,
      text: t.text || "",
      status: t.status,
      resource_type: t.resource_type,
      resource_id: t.resource_id,
      transcript_with_speaker: t.transcript_with_speaker,
      _creationTime: t._creationTime
    } : null;
  }, "handler")
}), W = f({
  args: {
    resourceType: e.union(e.literal("video"), e.literal("training_content")),
    resourceId: e.string()
  },
  returns: e.array(
    e.object({
      id: e.id("transcriptions"),
      status: e.string(),
      text: e.string(),
      created_at: e.optional(e.number()),
      updated_at: e.optional(e.number())
    })
  ),
  handler: /* @__PURE__ */ c(async (n, r) => (await n.db.query("transcriptions").withIndex(
    "by_resource",
    (s) => s.eq("resource_type", r.resourceType).eq("resource_id", r.resourceId)
  ).collect()).map((s) => ({
    id: s._id,
    status: s.status,
    text: s.text,
    created_at: s.created_at,
    updated_at: s.updated_at
  })), "handler")
}), N = I({
  args: {
    transcriptionId: e.id("transcriptions"),
    analysisType: e.string()
  },
  returns: e.object({
    success: e.boolean(),
    message: e.string()
  }),
  handler: /* @__PURE__ */ c(async (n, r) => {
    try {
      let t = await n.db.get(r.transcriptionId);
      return t ? t.status !== "completed" ? { success: !1, message: "\u6587\u5B57\u8D77\u3053\u3057\u304C\u5B8C\u4E86\u3057\u3066\u3044\u307E\u305B\u3093" } : (console.log(`\u57FA\u672C\u7684\u306ADify\u89E3\u6790\u3092\u5B9F\u884C: ${r.analysisType}`), { success: !0, message: `${r.analysisType}\u51E6\u7406\u3092\u958B\u59CB\u3057\u307E\u3057\u305F` }) : { success: !1, message: "\u6307\u5B9A\u3055\u308C\u305Ftranscription\u304C\u898B\u3064\u304B\u308A\u307E\u305B\u3093" };
    } catch (t) {
      return console.error("[processDifyAnalysis] \u30A8\u30E9\u30FC:", t), {
        success: !1,
        message: t instanceof Error ? t.message : "\u4E0D\u660E\u306A\u30A8\u30E9\u30FC\u304C\u767A\u751F\u3057\u307E\u3057\u305F"
      };
    }
  }, "handler")
}), Q = _({
  args: {
    transcriptionId: e.id("transcriptions")
  },
  returns: e.object({
    success: e.boolean(),
    progress: e.object({
      speakerTranscription: e.boolean(),
      evaluation: e.boolean(),
      meetingMinutes: e.boolean(),
      caseSummary: e.boolean(),
      meetingSummary: e.boolean(),
      completed: e.boolean()
    }),
    processingTime: e.optional(e.number())
  }),
  handler: /* @__PURE__ */ c(async (n, r) => {
    try {
      let t = await n.db.get(r.transcriptionId);
      return t ? {
        success: !0,
        progress: {
          speakerTranscription: !!t.transcript_with_speaker,
          evaluation: !!t.evaluation_result,
          meetingMinutes: !!t.meeting_minutes,
          caseSummary: !!t.case_summary,
          meetingSummary: !!t.meeting_summary,
          completed: !!t.audio_analysis_completed
        },
        processingTime: t.audio_analysis_processing_time
      } : {
        success: !1,
        progress: {
          speakerTranscription: !1,
          evaluation: !1,
          meetingMinutes: !1,
          caseSummary: !1,
          meetingSummary: !1,
          completed: !1
        }
      };
    } catch (t) {
      return console.error("[getAudioAnalysisProgress] \u30A8\u30E9\u30FC:", t), {
        success: !1,
        progress: {
          speakerTranscription: !1,
          evaluation: !1,
          meetingMinutes: !1,
          caseSummary: !1,
          meetingSummary: !1,
          completed: !1
        }
      };
    }
  }, "handler")
});
async function b(n, r) {
  try {
    console.log(`[startTranscriptionInternal] \u6587\u5B57\u8D77\u3053\u3057\u958B\u59CB: ${r.resourceType}/${r.resourceId}`);
    let t = await n.runQuery(l.transcriptions.getExistingTranscription, {
      resourceType: r.resourceType,
      resourceId: r.resourceId
    });
    if (t)
      return console.log(`[startTranscriptionInternal] \u65E2\u5B58\u306E\u6587\u5B57\u8D77\u3053\u3057\u3092\u767A\u898B: ${t.id}`), {
        success: !0,
        message: "\u6587\u5B57\u8D77\u3053\u3057\u306F\u65E2\u306B\u5B58\u5728\u3057\u3066\u3044\u307E\u3059",
        transcriptionId: t.id
      };
    let s = await n.runMutation(
      l.transcriptions.createAndStartTranscription,
      {
        resourceType: r.resourceType,
        resourceId: r.resourceId
      }
    );
    console.log(`[startTranscriptionInternal] \u6587\u5B57\u8D77\u3053\u3057\u30EC\u30B3\u30FC\u30C9\u4F5C\u6210\u5B8C\u4E86\u3001\u51E6\u7406\u958B\u59CB: ${s}`);
    let a = "", i = "failed";
    try {
      console.log(`[startTranscriptionInternal] ElevenLabs API\u547C\u3073\u51FA\u3057\u958B\u59CB: ${r.fileUrl}`);
      let o = r.fileUrl;
      if (r.fileUrl.includes("storage.googleapis.com") || r.fileUrl.startsWith("gs://"))
        try {
          console.log(`[startTranscriptionInternal] GCS\u30D5\u30A1\u30A4\u30EB\u691C\u51FA\u3001\u7F72\u540D\u4ED8\u304DURL\u751F\u6210\u4E2D: ${r.fileUrl}`);
          let p = "";
          if (r.fileUrl.includes("storage.googleapis.com")) {
            let m = r.fileUrl.split("/"), T = m.findIndex((h) => h.includes("storage.googleapis.com")) + 1;
            T > 0 && m.length > T && (p = m.slice(T + 1).join("/"));
          } else r.fileUrl.startsWith("gs://") && (p = r.fileUrl.replace(/^gs:\/\/[^\/]+\//, ""));
          if (p) {
            console.log(`[startTranscriptionInternal] \u62BD\u51FA\u3055\u308C\u305FGCP\u30D5\u30A1\u30A4\u30EB\u30D1\u30B9: ${p}`);
            let m = await n.runAction(g.gcsActions.generateGCPReadUrl, {
              gcpFilePath: p,
              expirationMinutes: 120
              // 2時間有効
            });
            m.success && m.readUrl ? (o = m.readUrl, console.log(`[startTranscriptionInternal] \u7F72\u540D\u4ED8\u304DURL\u751F\u6210\u6210\u529F: ${m.expiresAt}`)) : console.warn(`[startTranscriptionInternal] \u7F72\u540D\u4ED8\u304DURL\u751F\u6210\u5931\u6557\u3001\u5143\u306EURL\u3092\u4F7F\u7528: ${r.fileUrl}`);
          } else
            console.warn(`[startTranscriptionInternal] GCP\u30D5\u30A1\u30A4\u30EB\u30D1\u30B9\u62BD\u51FA\u5931\u6557: ${r.fileUrl}`);
        } catch (p) {
          console.warn("[startTranscriptionInternal] \u7F72\u540D\u4ED8\u304DURL\u751F\u6210\u30A8\u30E9\u30FC\u3001\u5143\u306EURL\u3092\u4F7F\u7528:", p);
        }
      let u = await n.runAction(
        g.transcriptionActions.performElevenLabsTranscription,
        {
          fileUrl: o,
          fileType: r.fileType,
          options: {
            enableSpeakerDiarization: !0,
            language: "ja"
          }
        }
      );
      if (u && u.text)
        a = u.text, i = "completed", console.log(`[startTranscriptionInternal] ElevenLabs\u6587\u5B57\u8D77\u3053\u3057\u6210\u529F: ${a.length}\u6587\u5B57`);
      else
        throw new Error("ElevenLabs API\u304B\u3089\u7121\u52B9\u306A\u30EC\u30B9\u30DD\u30F3\u30B9");
    } catch (o) {
      console.error("[startTranscriptionInternal] ElevenLabs\u6587\u5B57\u8D77\u3053\u3057\u30A8\u30E9\u30FC:", o), a = `\u6587\u5B57\u8D77\u3053\u3057\u51E6\u7406\u4E2D\u306B\u30A8\u30E9\u30FC\u304C\u767A\u751F\u3057\u307E\u3057\u305F: ${o instanceof Error ? o.message : "\u4E0D\u660E\u306A\u30A8\u30E9\u30FC"}`, i = "failed";
    }
    if (await n.runMutation(
      l.transcriptions.updateTranscriptionResult,
      {
        transcriptionId: s,
        text: a,
        status: i
      }
    ), console.log(`[startTranscriptionInternal] \u6587\u5B57\u8D77\u3053\u3057\u5B8C\u4E86: ${s}, \u30B9\u30C6\u30FC\u30BF\u30B9: ${i}`), i === "completed" && r.resourceType === "video")
      try {
        console.log(`[startTranscriptionInternal] \u8A71\u8005\u89E3\u6790\u51E6\u7406\u3092\u81EA\u52D5\u958B\u59CB: ${s}`), await n.scheduler.runAfter(0, l.videoUpload.processWithSpeakerTranscription, {
          transcriptionId: s
        }), console.log("[startTranscriptionInternal] \u8A71\u8005\u89E3\u6790\u51E6\u7406\u30B9\u30B1\u30B8\u30E5\u30FC\u30EB\u5B8C\u4E86");
      } catch (o) {
        console.error("[startTranscriptionInternal] \u8A71\u8005\u89E3\u6790\u51E6\u7406\u958B\u59CB\u30A8\u30E9\u30FC:", o);
      }
    return {
      success: !0,
      message: i === "completed" ? "\u6587\u5B57\u8D77\u3053\u3057\u304C\u5B8C\u4E86\u3057\u307E\u3057\u305F" : "\u6587\u5B57\u8D77\u3053\u3057\u306B\u5931\u6557\u3057\u307E\u3057\u305F",
      transcriptionId: s
    };
  } catch (t) {
    return console.error("[startTranscriptionInternal] \u30A8\u30E9\u30FC:", t), {
      success: !1,
      message: t instanceof Error ? t.message : "\u4E0D\u660E\u306A\u30A8\u30E9\u30FC\u304C\u767A\u751F\u3057\u307E\u3057\u305F"
    };
  }
}
c(b, "handleTranscriptionInternal");
var J = y({
  args: {
    resourceType: e.union(e.literal("video"), e.literal("training_content")),
    resourceId: e.string(),
    fileUrl: e.string(),
    fileType: e.string()
  },
  returns: e.object({
    success: e.boolean(),
    message: e.string(),
    transcriptionId: e.optional(e.id("transcriptions"))
  }),
  handler: b
}), O = d({
  args: {
    transcriptionId: e.id("transcriptions"),
    processingTime: e.optional(e.number()),
    status: e.optional(e.string()),
    // "completed" or "failed"
    error: e.optional(e.string())
  },
  returns: e.null(),
  handler: /* @__PURE__ */ c(async (n, r) => {
    try {
      console.log(`[updateAudioAnalysisStatus] \u57FA\u672C\u30B9\u30C6\u30FC\u30BF\u30B9\u4FDD\u5B58: ${r.transcriptionId}`);
      let t = {
        updated_at: Date.now()
      };
      return r.status === "completed" ? (t.audio_analysis_completed = !0, t.audio_analysis_processing_time = r.processingTime, t.analysis_completed_at = Date.now()) : r.status === "failed" && (t.audio_analysis_completed = !1, t.audio_analysis_error = r.error), await n.db.patch(r.transcriptionId, t), console.log(`[updateAudioAnalysisStatus] \u57FA\u672C\u30B9\u30C6\u30FC\u30BF\u30B9\u4FDD\u5B58\u5B8C\u4E86: ${r.transcriptionId}`), null;
    } catch (t) {
      throw console.error("[updateAudioAnalysisStatus] \u30A8\u30E9\u30FC:", t), t;
    }
  }, "handler")
}), C = d({
  args: {
    transcriptionId: e.id("transcriptions"),
    status: e.union(
      e.literal("pending"),
      e.literal("processing"),
      e.literal("completed"),
      e.literal("failed")
    ),
    error: e.optional(e.string())
  },
  returns: e.null(),
  handler: /* @__PURE__ */ c(async (n, r) => {
    try {
      console.log(`[updateSpeakerAnalysisStatus] \u8A71\u8005\u89E3\u6790\u30B9\u30C6\u30FC\u30BF\u30B9\u66F4\u65B0: ${r.transcriptionId} -> ${r.status}`);
      let t = {
        speaker_analysis_status: r.status,
        updated_at: Date.now()
      };
      return r.status === "failed" && r.error && (t.speaker_analysis_error = r.error), await n.db.patch(r.transcriptionId, t), console.log("[updateSpeakerAnalysisStatus] \u8A71\u8005\u89E3\u6790\u30B9\u30C6\u30FC\u30BF\u30B9\u66F4\u65B0\u5B8C\u4E86"), null;
    } catch (t) {
      throw console.error("[updateSpeakerAnalysisStatus] \u30A8\u30E9\u30FC:", t), t;
    }
  }, "handler")
}), G = y({
  args: {
    transcriptionId: e.id("transcriptions"),
    processingTime: e.optional(e.number()),
    status: e.optional(e.string()),
    error: e.optional(e.string())
  },
  returns: e.null(),
  handler: /* @__PURE__ */ c(async (n, r) => {
    try {
      return console.log(`[updateAudioAnalysisStatusAsync] \u975E\u540C\u671F\u30B9\u30C6\u30FC\u30BF\u30B9\u66F4\u65B0\u958B\u59CB: ${r.transcriptionId}`), await n.runMutation(l.transcriptions.updateAudioAnalysisStatus, {
        transcriptionId: r.transcriptionId,
        processingTime: r.processingTime,
        status: r.status,
        error: r.error
      }), console.log("[updateAudioAnalysisStatusAsync] \u975E\u540C\u671F\u30B9\u30C6\u30FC\u30BF\u30B9\u66F4\u65B0\u5B8C\u4E86"), null;
    } catch (t) {
      throw console.error("[updateAudioAnalysisStatusAsync] \u30A8\u30E9\u30FC:", t), t;
    }
  }, "handler")
}), z = d({
  args: {
    transcriptionId: e.id("transcriptions"),
    processingTime: e.number(),
    evaluationFileId: e.optional(e.id("_storage")),
    meetingMinutesFileId: e.optional(e.id("_storage")),
    caseSummaryFileId: e.optional(e.id("_storage")),
    meetingSummaryFileId: e.optional(e.id("_storage"))
  },
  returns: e.null(),
  handler: /* @__PURE__ */ c(async (n, r) => {
    try {
      console.log(`[saveStorageBasedResults] \u30B9\u30C8\u30EC\u30FC\u30B8\u30D9\u30FC\u30B9\u4FDD\u5B58\u958B\u59CB: ${r.transcriptionId}`);
      let t = {
        audio_analysis_completed: !0,
        audio_analysis_processing_time: r.processingTime,
        analysis_completed_at: Date.now(),
        updated_at: Date.now()
      };
      return r.evaluationFileId && (t.evaluation_file_id = r.evaluationFileId, t.evaluation_status = "completed", t.evaluation_generated_at = Date.now(), console.log(`[saveStorageBasedResults] \u8A55\u4FA1\u7D50\u679C\u30D5\u30A1\u30A4\u30EBID\u4FDD\u5B58: ${r.evaluationFileId}`)), r.meetingMinutesFileId && (t.meeting_minutes_file_id = r.meetingMinutesFileId, t.meeting_minutes_status = "completed", t.meeting_minutes_generated_at = Date.now(), console.log(`[saveStorageBasedResults] \u8B70\u4E8B\u9332\u30D5\u30A1\u30A4\u30EBID\u4FDD\u5B58: ${r.meetingMinutesFileId}`)), r.caseSummaryFileId && (t.case_summary_file_id = r.caseSummaryFileId, t.case_summary_status = "completed", t.case_summary_generated_at = Date.now(), console.log(`[saveStorageBasedResults] \u6848\u4EF6\u5316\u30B5\u30DE\u30EA\u30FC\u30D5\u30A1\u30A4\u30EBID\u4FDD\u5B58: ${r.caseSummaryFileId}`)), r.meetingSummaryFileId && (t.meeting_summary_file_id = r.meetingSummaryFileId, t.meeting_summary_status = "completed", t.meeting_summary_generated_at = Date.now(), console.log(`[saveStorageBasedResults] \u5546\u8AC7\u8A18\u9332\u30B5\u30DE\u30EA\u30FC\u30D5\u30A1\u30A4\u30EBID\u4FDD\u5B58: ${r.meetingSummaryFileId}`)), await n.db.patch(r.transcriptionId, t), console.log(`[saveStorageBasedResults] \u30B9\u30C8\u30EC\u30FC\u30B8\u30D9\u30FC\u30B9\u4FDD\u5B58\u5B8C\u4E86: ${r.transcriptionId}`), null;
    } catch (t) {
      console.error("[saveStorageBasedResults] \u30B9\u30C8\u30EC\u30FC\u30B8\u30D9\u30FC\u30B9\u4FDD\u5B58\u30A8\u30E9\u30FC:", t);
      try {
        await n.db.patch(r.transcriptionId, {
          audio_analysis_completed: !0,
          updated_at: Date.now()
        }), console.log(`[saveStorageBasedResults] \u6700\u5C0F\u9650\u30B9\u30C6\u30FC\u30BF\u30B9\u4FDD\u5B58\u5B8C\u4E86: ${r.transcriptionId}`);
      } catch (s) {
        console.error("[saveStorageBasedResults] \u6700\u5C0F\u9650\u30B9\u30C6\u30FC\u30BF\u30B9\u4FDD\u5B58\u3082\u5931\u6557:", s);
      }
      return null;
    }
  }, "handler")
}), H = d({
  args: {
    transcriptionId: e.id("transcriptions"),
    saveData: e.object({
      processingTime: e.optional(e.number()),
      evaluationResult: e.optional(e.any()),
      meetingMinutes: e.optional(e.any()),
      caseSummary: e.optional(e.any()),
      meetingSummary: e.optional(e.any())
    })
  },
  returns: e.null(),
  handler: /* @__PURE__ */ c(async (n, r) => {
    try {
      console.log(`[scheduleDataSave] \u975E\u540C\u671F\u30C7\u30FC\u30BF\u4FDD\u5B58\u958B\u59CB: ${r.transcriptionId}`);
      let t = {
        audio_analysis_completed: !0,
        updated_at: Date.now()
      };
      return r.saveData.processingTime && (t.audio_analysis_processing_time = r.saveData.processingTime, t.analysis_completed_at = Date.now()), r.saveData.evaluationResult && (t.evaluation = r.saveData.evaluationResult, t.evaluation_status = "completed", t.evaluation_generated_at = Date.now()), r.saveData.meetingMinutes && (t.meeting_minutes = JSON.stringify(r.saveData.meetingMinutes), t.meeting_minutes_status = "completed", t.meeting_minutes_generated_at = Date.now()), r.saveData.caseSummary && (t.case_summary = JSON.stringify(r.saveData.caseSummary), t.case_summary_status = "completed", t.case_summary_generated_at = Date.now()), r.saveData.meetingSummary && (t.meeting_summary = JSON.stringify(r.saveData.meetingSummary), t.meeting_summary_status = "completed", t.meeting_summary_generated_at = Date.now()), await n.db.patch(r.transcriptionId, t), console.log(`[scheduleDataSave] \u975E\u540C\u671F\u30C7\u30FC\u30BF\u4FDD\u5B58\u5B8C\u4E86: ${r.transcriptionId}`), null;
    } catch (t) {
      console.error("[scheduleDataSave] \u975E\u540C\u671F\u30C7\u30FC\u30BF\u4FDD\u5B58\u30A8\u30E9\u30FC:", t);
      try {
        await n.db.patch(r.transcriptionId, {
          audio_analysis_completed: !0,
          updated_at: Date.now()
        }), console.log(`[scheduleDataSave] \u6700\u5C0F\u9650\u30B9\u30C6\u30FC\u30BF\u30B9\u4FDD\u5B58\u5B8C\u4E86: ${r.transcriptionId}`);
      } catch (s) {
        console.error("[scheduleDataSave] \u6700\u5C0F\u9650\u30B9\u30C6\u30FC\u30BF\u30B9\u4FDD\u5B58\u3082\u5931\u6557:", s);
      }
      return null;
    }
  }, "handler")
}), K = _({
  args: {
    transcriptionId: e.id("transcriptions")
  },
  returns: e.union(
    e.object({
      audio_analysis_processing_time: e.optional(e.number()),
      evaluation_file_id: e.optional(e.id("_storage")),
      meeting_minutes_file_id: e.optional(e.id("_storage")),
      case_summary_file_id: e.optional(e.id("_storage")),
      meeting_summary_file_id: e.optional(e.id("_storage"))
    }),
    e.null()
  ),
  handler: /* @__PURE__ */ c(async (n, r) => {
    let t = await n.db.get(r.transcriptionId);
    return t ? {
      audio_analysis_processing_time: t.audio_analysis_processing_time,
      evaluation_file_id: t.evaluation_file_id,
      meeting_minutes_file_id: t.meeting_minutes_file_id,
      case_summary_file_id: t.case_summary_file_id,
      meeting_summary_file_id: t.meeting_summary_file_id
    } : null;
  }, "handler")
}), V = w({
  args: {
    transcriptionId: e.id("transcriptions")
  },
  returns: e.object({
    success: e.boolean(),
    evaluation: e.optional(e.any()),
    meetingMinutes: e.optional(e.any()),
    caseSummary: e.optional(e.any()),
    meetingSummary: e.optional(e.any()),
    processingTime: e.optional(e.number()),
    message: e.optional(e.string())
  }),
  handler: /* @__PURE__ */ c(async (n, r) => {
    try {
      console.log(`[getAnalysisResultsFromStorage] \u5206\u6790\u7D50\u679C\u8AAD\u307F\u8FBC\u307F\u958B\u59CB: ${r.transcriptionId}`);
      let t = await n.runQuery(l.transcriptions.getTranscriptionForStorage, {
        transcriptionId: r.transcriptionId
      });
      if (!t)
        return {
          success: !1,
          message: "transcription\u304C\u898B\u3064\u304B\u308A\u307E\u305B\u3093"
        };
      let s = {
        success: !0,
        processingTime: t.audio_analysis_processing_time
      };
      if (t.evaluation_file_id)
        try {
          let a = await n.runQuery(l.transcriptions.getStorageUrl, {
            fileId: t.evaluation_file_id
          });
          if (a) {
            let o = await (await fetch(a)).text();
            s.evaluation = JSON.parse(o), console.log("[getAnalysisResultsFromStorage] \u8A55\u4FA1\u7D50\u679C\u8AAD\u307F\u8FBC\u307F\u5B8C\u4E86");
          }
        } catch (a) {
          console.error("[getAnalysisResultsFromStorage] \u8A55\u4FA1\u7D50\u679C\u8AAD\u307F\u8FBC\u307F\u30A8\u30E9\u30FC:", a);
        }
      if (t.meeting_minutes_file_id)
        try {
          let a = await n.runQuery(l.transcriptions.getStorageUrl, {
            fileId: t.meeting_minutes_file_id
          });
          if (a) {
            let o = await (await fetch(a)).text();
            s.meetingMinutes = JSON.parse(o), console.log("[getAnalysisResultsFromStorage] \u8B70\u4E8B\u9332\u8AAD\u307F\u8FBC\u307F\u5B8C\u4E86");
          }
        } catch (a) {
          console.error("[getAnalysisResultsFromStorage] \u8B70\u4E8B\u9332\u8AAD\u307F\u8FBC\u307F\u30A8\u30E9\u30FC:", a);
        }
      if (t.case_summary_file_id)
        try {
          let a = await n.runQuery(l.transcriptions.getStorageUrl, {
            fileId: t.case_summary_file_id
          });
          if (a) {
            let o = await (await fetch(a)).text();
            s.caseSummary = JSON.parse(o), console.log("[getAnalysisResultsFromStorage] \u6848\u4EF6\u5316\u30B5\u30DE\u30EA\u30FC\u8AAD\u307F\u8FBC\u307F\u5B8C\u4E86");
          }
        } catch (a) {
          console.error("[getAnalysisResultsFromStorage] \u6848\u4EF6\u5316\u30B5\u30DE\u30EA\u30FC\u8AAD\u307F\u8FBC\u307F\u30A8\u30E9\u30FC:", a);
        }
      if (t.meeting_summary_file_id)
        try {
          let a = await n.runQuery(l.transcriptions.getStorageUrl, {
            fileId: t.meeting_summary_file_id
          });
          if (a) {
            let o = await (await fetch(a)).text();
            s.meetingSummary = JSON.parse(o), console.log("[getAnalysisResultsFromStorage] \u5546\u8AC7\u8A18\u9332\u30B5\u30DE\u30EA\u30FC\u8AAD\u307F\u8FBC\u307F\u5B8C\u4E86");
          }
        } catch (a) {
          console.error("[getAnalysisResultsFromStorage] \u5546\u8AC7\u8A18\u9332\u30B5\u30DE\u30EA\u30FC\u8AAD\u307F\u8FBC\u307F\u30A8\u30E9\u30FC:", a);
        }
      return console.log(`[getAnalysisResultsFromStorage] \u5206\u6790\u7D50\u679C\u8AAD\u307F\u8FBC\u307F\u5B8C\u4E86: ${r.transcriptionId}`), s;
    } catch (t) {
      return console.error("[getAnalysisResultsFromStorage] \u5206\u6790\u7D50\u679C\u8AAD\u307F\u8FBC\u307F\u30A8\u30E9\u30FC:", t), {
        success: !1,
        message: t instanceof Error ? t.message : "\u4E0D\u660E\u306A\u30A8\u30E9\u30FC"
      };
    }
  }, "handler")
}), X = _({
  args: {
    fileId: e.id("_storage")
  },
  returns: e.union(e.string(), e.null()),
  handler: /* @__PURE__ */ c(async (n, r) => {
    try {
      return await n.storage.getUrl(r.fileId);
    } catch (t) {
      return console.error("[getStorageUrl] URL\u53D6\u5F97\u30A8\u30E9\u30FC:", t), null;
    }
  }, "handler")
}), Y = y({
  args: {
    fileId: e.id("_storage"),
    dataType: e.string()
    // "evaluation", "meetingMinutes", "caseSummary", "meetingSummary"
  },
  returns: e.union(e.any(), e.null()),
  handler: /* @__PURE__ */ c(async (n, r) => {
    try {
      console.log(`[getStorageData] ${r.dataType}\u30C7\u30FC\u30BF\u8AAD\u307F\u8FBC\u307F\u958B\u59CB: ${r.fileId}`);
      let t = await n.runQuery(l.transcriptions.getStorageUrl, {
        fileId: r.fileId
      });
      if (!t)
        return console.warn(`[getStorageData] \u30D5\u30A1\u30A4\u30EB\u304C\u898B\u3064\u304B\u308A\u307E\u305B\u3093: ${r.fileId}`), null;
      let a = await (await fetch(t)).text(), i = JSON.parse(a);
      return console.log(`[getStorageData] ${r.dataType}\u30C7\u30FC\u30BF\u8AAD\u307F\u8FBC\u307F\u5B8C\u4E86: ${a.length} chars`), i;
    } catch (t) {
      return console.error(`[getStorageData] ${r.dataType}\u30C7\u30FC\u30BF\u8AAD\u307F\u8FBC\u307F\u30A8\u30E9\u30FC:`, t), null;
    }
  }, "handler")
}), Z = d({
  args: {
    transcriptionId: e.id("transcriptions"),
    evaluationResult: e.optional(e.any()),
    meetingMinutes: e.optional(e.any()),
    caseSummary: e.optional(e.any()),
    meetingSummary: e.optional(e.any()),
    processingTime: e.optional(e.number())
  },
  returns: e.null(),
  handler: /* @__PURE__ */ c(async (n, r) => {
    try {
      if (console.log(`[updateAudioAnalysisResults] \u97F3\u58F0\u5206\u6790\u7D50\u679C\u3092\u4FDD\u5B58: ${r.transcriptionId}`), !await n.db.get(r.transcriptionId))
        throw new Error("\u6307\u5B9A\u3055\u308C\u305Ftranscription\u304C\u898B\u3064\u304B\u308A\u307E\u305B\u3093");
      let s = {
        audio_analysis_completed: !0,
        audio_analysis_processing_time: r.processingTime,
        analysis_completed_at: Date.now(),
        updated_at: Date.now()
      };
      if (r.evaluationResult && typeof r.evaluationResult == "object") {
        let u = {
          status: "completed",
          timestamp: Date.now(),
          hasData: !0
        };
        s.evaluation_status = JSON.stringify(u);
      }
      let a = 3, i = 0, o = !1;
      for (; i < a && !o; )
        try {
          let u = Date.now();
          await n.db.patch(r.transcriptionId, s);
          let p = Date.now() - u;
          console.log(`[updateAudioAnalysisResults] \u4FDD\u5B58\u5B8C\u4E86: ${r.transcriptionId} (${p}ms, \u8A66\u884C${i + 1}\u56DE\u76EE)`), p > 3e3 && console.warn(`[updateAudioAnalysisResults] \u4FDD\u5B58\u306B${p}ms \u304B\u304B\u308A\u307E\u3057\u305F - \u30D1\u30D5\u30A9\u30FC\u30DE\u30F3\u30B9\u8981\u6CE8\u610F`), o = !0;
        } catch (u) {
          if (i++, console.warn(`[updateAudioAnalysisResults] \u4FDD\u5B58\u8A66\u884C${i}\u56DE\u76EE\u5931\u6557:`, u), i < a)
            await new Promise((p) => setTimeout(p, 500 * i));
          else
            throw u;
        }
      return null;
    } catch (t) {
      throw console.error("[updateAudioAnalysisResults] \u30A8\u30E9\u30FC:", t), t;
    }
  }, "handler")
}), ee = d({
  args: {
    transcriptionId: e.id("transcriptions"),
    transcriptWithSpeaker: e.string()
  },
  returns: e.null(),
  handler: /* @__PURE__ */ c(async (n, r) => {
    try {
      console.log(`[updateTranscriptWithSpeaker] \u8A71\u8005\u4ED8\u304D\u6587\u5B57\u8D77\u3053\u3057\u3092\u66F4\u65B0: ${r.transcriptionId}`);
      let t = await n.db.get(r.transcriptionId);
      if (!t)
        throw new Error("\u6307\u5B9A\u3055\u308C\u305Ftranscription\u304C\u898B\u3064\u304B\u308A\u307E\u305B\u3093");
      return t.transcript_with_speaker && t.transcript_with_speaker.length > 0 ? (console.log(`[updateTranscriptWithSpeaker] \u65E2\u5B58\u306E\u8A71\u8005\u4ED8\u304D\u6587\u5B57\u8D77\u3053\u3057\u304C\u5B58\u5728\u3059\u308B\u305F\u3081\u66F4\u65B0\u3092\u30B9\u30AD\u30C3\u30D7: ${r.transcriptionId}`), null) : (await n.db.patch(r.transcriptionId, {
        transcript_with_speaker: r.transcriptWithSpeaker,
        updated_at: Date.now()
      }), console.log(`[updateTranscriptWithSpeaker] \u8A71\u8005\u4ED8\u304D\u6587\u5B57\u8D77\u3053\u3057\u66F4\u65B0\u5B8C\u4E86: ${r.transcriptionId}`), null);
    } catch (t) {
      throw console.error("[updateTranscriptWithSpeaker] \u30A8\u30E9\u30FC:", t), t;
    }
  }, "handler")
});
export {
  L as completeTranscription,
  M as create,
  E as createAndStartTranscription,
  k as createTranscriptionRecord,
  V as getAnalysisResultsFromStorage,
  Q as getAudioAnalysisProgress,
  U as getExistingTranscription,
  Y as getStorageData,
  X as getStorageUrl,
  B as getTranscriptionForAction,
  K as getTranscriptionForStorage,
  q as getTranscriptionResult,
  $ as getTranscriptionStatus,
  W as getTranscriptionsByResource,
  N as processDifyAnalysis,
  z as saveStorageBasedResults,
  H as scheduleDataSave,
  P as startBasicTranscription,
  j as startPublicTranscription,
  R as startTranscription,
  J as startTranscriptionInternal,
  Z as updateAudioAnalysisResults,
  O as updateAudioAnalysisStatus,
  G as updateAudioAnalysisStatusAsync,
  C as updateSpeakerAnalysisStatus,
  ee as updateTranscriptWithSpeaker,
  F as updateTranscriptionResult
};
//# sourceMappingURL=transcriptions.js.map
