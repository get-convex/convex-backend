import {
  d as o,
  e as i,
  f as a
} from "./_deps/SMJ6X5F7.js";
import {
  j as e,
  n as s
} from "./_deps/3TDUHHJO.js";
import {
  a as n
} from "./_deps/RUVYHBJQ.js";

// convex/evaluationTypes.ts
s();
var u = e.object({
  videoId: e.optional(e.id("videos")),
  transcriptionId: e.optional(e.id("transcriptions")),
  videoType: e.optional(o),
  transcript: e.optional(e.string()),
  userId: e.optional(e.id("users")),
  // Migration: Updated from better_auth_users to unified users table
  autoRetry: e.optional(e.boolean())
}), m = e.union(
  // Processing Response
  e.object({
    success: e.boolean(),
    status: e.literal("processing"),
    evaluationId: e.string(),
    message: e.string()
  }),
  // Completed Response
  e.object({
    success: e.boolean(),
    status: e.literal("completed"),
    evaluationId: e.string(),
    finalScore: e.number(),
    recommendation: a,
    evaluationDetails: e.optional(
      e.record(
        e.string(),
        e.object({
          score: e.number(),
          analysis: e.string(),
          strength: e.optional(e.string()),
          weakness: e.optional(e.string())
        })
      )
    ),
    goodPoints: e.array(e.string()),
    improvementPoints: e.array(e.string()),
    recommendedActions: e.array(e.string())
  }),
  // Failed Response
  e.object({
    success: e.boolean(),
    status: e.literal("failed"),
    evaluationId: e.string(),
    error: e.string(),
    errorCode: e.optional(e.string())
  })
), p = e.object({
  evaluations: e.array(u),
  batchSize: e.optional(e.number()),
  maxConcurrency: e.optional(e.number()),
  failurePolicy: e.optional(e.union(e.literal("stop"), e.literal("continue"), e.literal("retry")))
}), g = e.object({
  userId: e.optional(e.id("users")),
  // Migration: Updated from better_auth_users to unified users table
  videoType: e.optional(o),
  status: e.optional(i),
  dateFrom: e.optional(e.number()),
  dateTo: e.optional(e.number()),
  limit: e.optional(e.number()),
  offset: e.optional(e.number())
}), b = e.object({
  comments: e.string(),
  overrideScore: e.optional(e.number()),
  overrideRecommendation: e.optional(e.string()),
  reviewedAt: e.number(),
  reviewerId: e.id("users")
  // Migration: Updated from better_auth_users to unified users table
});
function v(t) {
  return t.status === "processing";
}
n(v, "isProcessingResponse");
function _(t) {
  return t.status === "completed";
}
n(_, "isCompletedResponse");
function y(t) {
  return t.status === "failed";
}
n(y, "isFailedResponse");
function f(t) {
  if (typeof t != "object" || t === null) return !1;
  let r = t;
  return !(!r.transcriptionId && !r.transcript || r.videoType !== void 0 && !["M&A\u30ED\u30FC\u30EB\u30D7\u30EC\u30A4", "AD\u7DE0\u7D50\u63D0\u6848", "\u4F01\u696D\u6982\u8981\u66F8\u63D0\u6848", "\u8B72\u6E21\u67B6\u96FB"].includes(r.videoType));
}
n(f, "isValidEvaluationRequest");
var R = e.object({
  code: e.string(),
  message: e.string(),
  details: e.optional(e.record(e.string(), e.union(e.string(), e.number(), e.boolean()))),
  timestamp: e.number(),
  context: e.optional(
    e.object({
      function_name: e.string(),
      user_id: e.optional(e.string()),
      evaluation_id: e.optional(e.string())
    })
  )
});
export {
  p as batchEvaluationRequestValidator,
  R as evaluationErrorValidator,
  g as evaluationHistoryFilterValidator,
  u as evaluationRequestValidator,
  m as evaluationResponseValidator,
  _ as isCompletedResponse,
  y as isFailedResponse,
  v as isProcessingResponse,
  f as isValidEvaluationRequest,
  b as managerReviewValidator
};
//# sourceMappingURL=evaluationTypes.js.map
