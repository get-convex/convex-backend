import {
  a as d,
  b as T,
  e as m
} from "./_deps/IVQGLTSC.js";
import {
  a as h
} from "./_deps/6HNJFR7B.js";
import {
  g as c
} from "./_deps/75JH2J25.js";
import {
  l as g,
  p as f
} from "./_deps/6XQQNYIR.js";
import "./_deps/3TDUHHJO.js";
import "./_deps/RUVYHBJQ.js";

// convex/http.ts
f();
m();
m();
var l = g(), s = {
  "Access-Control-Allow-Origin": process.env.ALLOWED_ORIGINS || "http://localhost:5173,https://jbci-training.com,https://ai-sales-training-convex-362493512175.asia-northeast1.run.app,https://ai-sales-training-convex-46sq37wpza-an.a.run.app",
  "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization",
  "Access-Control-Allow-Credentials": "true",
  "Access-Control-Max-Age": "86400"
  // 24時間キャッシュ
};
l.route({
  path: "/ping",
  method: "GET",
  handler: c(async (o, a) => (console.log("[HTTP] Ping endpoint called via Convex HTTP Router!"), new Response(
    JSON.stringify({
      success: !0,
      message: "Convex HTTP Router is working!",
      timestamp: (/* @__PURE__ */ new Date()).toISOString(),
      url: a.url,
      method: a.method
    }),
    {
      status: 200,
      headers: {
        "Content-Type": "application/json",
        ...s
      }
    }
  )))
});
l.route({
  path: "/notifications/slack-oauth/auth-url",
  method: "GET",
  handler: c(async (o) => {
    console.log("[HTTP] Slack OAuth auth-url endpoint called");
    let a = process.env.SLACK_CLIENT_ID, e = process.env.SLACK_REDIRECT_URI;
    if (!a || !e)
      return new Response(
        JSON.stringify({
          success: !1,
          error: "Slack OAuth configuration missing"
        }),
        {
          status: 500,
          headers: { "Content-Type": "application/json", ...s }
        }
      );
    let n = "channels:read,chat:write,users:read", t = crypto.randomUUID(), r = `https://slack.com/oauth/v2/authorize?client_id=${encodeURIComponent(a)}&scope=${encodeURIComponent(n)}&redirect_uri=${encodeURIComponent(e)}&state=${t}`;
    return new Response(
      JSON.stringify({
        success: !0,
        authUrl: r,
        state: t
      }),
      {
        status: 200,
        headers: { "Content-Type": "application/json", ...s }
      }
    );
  })
});
l.route({
  path: "/notifications/slack-oauth/status",
  method: "GET",
  handler: c(async (o) => (console.log("[HTTP] Slack OAuth status endpoint called"), new Response(
    JSON.stringify({
      success: !0,
      isConnected: !1,
      integration: null
    }),
    {
      status: 200,
      headers: { "Content-Type": "application/json", ...s }
    }
  )))
});
l.route({
  path: "/notifications/slack-oauth/callback",
  method: "POST",
  handler: c(async (o, a) => {
    console.log("[HTTP] Slack OAuth callback endpoint called");
    let e = await a.json(), { code: n } = e;
    if (!n)
      return new Response(
        JSON.stringify({
          success: !1,
          error: "Authorization code is required"
        }),
        {
          status: 400,
          headers: { "Content-Type": "application/json", ...s }
        }
      );
    let t = process.env.SLACK_CLIENT_ID, r = process.env.SLACK_CLIENT_SECRET, u = process.env.SLACK_REDIRECT_URI;
    if (!t || !r || !u)
      return new Response(
        JSON.stringify({
          success: !1,
          error: "Slack OAuth configuration missing"
        }),
        {
          status: 500,
          headers: { "Content-Type": "application/json", ...s }
        }
      );
    try {
      let i = await (await fetch("https://slack.com/api/oauth.v2.access", {
        method: "POST",
        headers: {
          "Content-Type": "application/x-www-form-urlencoded"
        },
        body: new URLSearchParams({
          client_id: t,
          client_secret: r,
          code: n,
          redirect_uri: u
        })
      })).json();
      if (!i.ok)
        throw new Error(i.error || "Token exchange failed");
      return new Response(
        JSON.stringify({
          success: !0,
          message: "Slack integration completed",
          teamName: i.team?.name || "Unknown Team"
        }),
        {
          status: 200,
          headers: { "Content-Type": "application/json", ...s }
        }
      );
    } catch (p) {
      return console.error("[HTTP] Slack OAuth error:", p), new Response(
        JSON.stringify({
          success: !1,
          error: "OAuth authentication failed"
        }),
        {
          status: 500,
          headers: { "Content-Type": "application/json", ...s }
        }
      );
    }
  })
});
l.route({
  path: "/notifications/slack-oauth/channels",
  method: "GET",
  handler: c(async (o) => (console.log("[HTTP] Slack channels endpoint called"), new Response(
    JSON.stringify({
      success: !0,
      channels: [
        {
          id: "C1234567890",
          name: "general",
          purpose: "Company-wide announcements",
          isMember: !0,
          isPrivate: !1,
          isArchived: !1
        },
        {
          id: "C2345678901",
          name: "random",
          purpose: "Random conversations",
          isMember: !0,
          isPrivate: !1,
          isArchived: !1
        }
      ]
    }),
    {
      status: 200,
      headers: { "Content-Type": "application/json", ...s }
    }
  )))
});
l.route({
  path: "/notifications/slack-oauth/disconnect",
  method: "DELETE",
  handler: c(async (o) => (console.log("[HTTP] Slack disconnect endpoint called"), new Response(
    JSON.stringify({
      success: !0,
      message: "Slack integration disconnected"
    }),
    {
      status: 200,
      headers: { "Content-Type": "application/json", ...s }
    }
  )))
});
l.route({
  path: "/notifications/slack-oauth/test",
  method: "POST",
  handler: c(async (o, a) => {
    console.log("[HTTP] Slack test message endpoint called");
    let e = await a.json(), { channelId: n } = e;
    return n ? (console.log("[HTTP] Would send test message to channel:", n), new Response(
      JSON.stringify({
        success: !0,
        message: "Test message sent successfully"
      }),
      {
        status: 200,
        headers: { "Content-Type": "application/json", ...s }
      }
    )) : new Response(
      JSON.stringify({
        success: !1,
        error: "Channel ID is required"
      }),
      {
        status: 400,
        headers: { "Content-Type": "application/json", ...s }
      }
    );
  })
});
l.route({
  path: "/api/upload/course-thumbnail/generate-url",
  method: "POST",
  handler: c(async (o, a) => {
    console.log("[HTTP] Course thumbnail upload URL generation endpoint called");
    try {
      await h(o);
      let e = await a.json(), { filename: n, contentType: t, size: r } = e;
      if (!n || !t)
        return new Response(
          JSON.stringify({
            success: !1,
            error: "filename and contentType are required"
          }),
          {
            status: 400,
            headers: { "Content-Type": "application/json", ...s }
          }
        );
      if (![
        "image/jpeg",
        "image/jpg",
        "image/png",
        "image/webp",
        "image/gif"
      ].includes(t))
        return new Response(
          JSON.stringify({
            success: !1,
            error: `Unsupported file type: ${t}`
          }),
          {
            status: 400,
            headers: { "Content-Type": "application/json", ...s }
          }
        );
      let p = 5 * 1024 * 1024;
      if (r && r > p)
        return new Response(
          JSON.stringify({
            success: !1,
            error: "File size exceeds 5MB limit"
          }),
          {
            status: 400,
            headers: { "Content-Type": "application/json", ...s }
          }
        );
      let i = await o.runAction(d.gcsActions.generateGCPUploadUrl, {
        filename: n,
        contentType: t,
        uploadType: "course_thumbnail",
        fileSize: r
      });
      return new Response(
        JSON.stringify({
          success: !0,
          uploadUrl: i.uploadUrl,
          fileKey: i.gcpFilePath,
          fileUrl: `https://storage.googleapis.com/${process.env.GCS_BUCKET_NAME}/${i.gcpFilePath}`
        }),
        {
          status: 200,
          headers: { "Content-Type": "application/json", ...s }
        }
      );
    } catch (e) {
      return console.error("[HTTP] Course thumbnail upload URL generation error:", e), new Response(
        JSON.stringify({
          success: !1,
          error: e instanceof Error ? e.message : "Internal server error"
        }),
        {
          status: 500,
          headers: { "Content-Type": "application/json", ...s }
        }
      );
    }
  })
});
l.route({
  path: "/api/upload/module-content/generate-url",
  method: "POST",
  handler: c(async (o, a) => {
    console.log("[HTTP] Module content upload URL generation endpoint called");
    try {
      await h(o);
      let e = await a.json(), { filename: n, contentType: t, size: r } = e;
      if (!n || !t)
        return new Response(
          JSON.stringify({
            success: !1,
            error: "filename and contentType are required"
          }),
          {
            status: 400,
            headers: { "Content-Type": "application/json", ...s }
          }
        );
      if (![
        // テキスト・マークダウン
        "text/markdown",
        "text/plain",
        // Word・PowerPoint・PDF
        "application/msword",
        "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
        "application/pdf",
        "application/vnd.ms-powerpoint",
        "application/vnd.openxmlformats-officedocument.presentationml.presentation",
        // 動画・音声
        "video/mp4",
        "video/quicktime",
        "video/webm",
        "audio/mpeg",
        "audio/mp3",
        "audio/wav",
        "application/zip"
      ].includes(t))
        return new Response(
          JSON.stringify({
            success: !1,
            error: `Unsupported file type: ${t}`
          }),
          {
            status: 400,
            headers: { "Content-Type": "application/json", ...s }
          }
        );
      let p = 2 * 1024 * 1024 * 1024;
      if (r && r > p)
        return new Response(
          JSON.stringify({
            success: !1,
            error: "File size exceeds 2GB limit"
          }),
          {
            status: 400,
            headers: { "Content-Type": "application/json", ...s }
          }
        );
      let i = await o.runAction(d.gcsActions.generateGCPUploadUrl, {
        filename: n,
        contentType: t,
        uploadType: "module_content",
        fileSize: r
      });
      return new Response(
        JSON.stringify({
          success: !0,
          uploadUrl: i.uploadUrl,
          fileKey: i.gcpFilePath,
          fileUrl: `https://storage.googleapis.com/${process.env.GCS_BUCKET_NAME}/${i.gcpFilePath}`
        }),
        {
          status: 200,
          headers: { "Content-Type": "application/json", ...s }
        }
      );
    } catch (e) {
      return console.error("[HTTP] Module content upload URL generation error:", e), new Response(
        JSON.stringify({
          success: !1,
          error: e instanceof Error ? e.message : "Internal server error"
        }),
        {
          status: 500,
          headers: { "Content-Type": "application/json", ...s }
        }
      );
    }
  })
});
l.route({
  path: "/api/upload/training-content/generate-url",
  method: "POST",
  handler: c(async (o, a) => {
    console.log("[HTTP] Training content upload URL generation endpoint called");
    try {
      await h(o);
      let e = await a.json(), { filename: n, contentType: t, size: r } = e;
      if (!n || !t)
        return new Response(
          JSON.stringify({
            success: !1,
            error: "filename and contentType are required"
          }),
          {
            status: 400,
            headers: { "Content-Type": "application/json", ...s }
          }
        );
      if (![
        // テキスト・マークダウン
        "text/markdown",
        "text/plain",
        // Word・PowerPoint・PDF
        "application/msword",
        "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
        "application/pdf",
        "application/vnd.ms-powerpoint",
        "application/vnd.openxmlformats-officedocument.presentationml.presentation",
        // 動画・音声
        "video/mp4",
        "video/quicktime",
        "video/webm",
        "audio/mpeg",
        "audio/mp3",
        "audio/wav",
        "application/zip"
      ].includes(t))
        return new Response(
          JSON.stringify({
            success: !1,
            error: `Unsupported file type: ${t}`
          }),
          {
            status: 400,
            headers: { "Content-Type": "application/json", ...s }
          }
        );
      let p = 50 * 1024 * 1024 * 1024;
      if (r && r > p)
        return new Response(
          JSON.stringify({
            success: !1,
            error: "File size exceeds 50GB limit"
          }),
          {
            status: 400,
            headers: { "Content-Type": "application/json", ...s }
          }
        );
      let i = await o.runAction(d.gcsActions.generateGCPUploadUrl, {
        filename: n,
        contentType: t,
        uploadType: "training",
        fileSize: r
      });
      return new Response(
        JSON.stringify({
          success: !0,
          uploadUrl: i.uploadUrl,
          fileKey: i.gcpFilePath,
          fileUrl: `https://storage.googleapis.com/${process.env.GCS_BUCKET_NAME}/${i.gcpFilePath}`
        }),
        {
          status: 200,
          headers: { "Content-Type": "application/json", ...s }
        }
      );
    } catch (e) {
      return console.error("[HTTP] Training content upload URL generation error:", e), new Response(
        JSON.stringify({
          success: !1,
          error: e instanceof Error ? e.message : "Internal server error"
        }),
        {
          status: 500,
          headers: { "Content-Type": "application/json", ...s }
        }
      );
    }
  })
});
l.route({
  path: "/api/training/modules/create",
  method: "POST",
  handler: c(async (o, a) => {
    console.log("[HTTP] Training module create endpoint called");
    try {
      await h(o);
      let e = await a.json();
      if (console.log("[HTTP] Request body:", e), !e.module)
        return new Response(
          JSON.stringify({
            success: !1,
            error: "module data is required"
          }),
          {
            status: 400,
            headers: { "Content-Type": "application/json", ...s }
          }
        );
      let { module: n } = e, t, r = await o.runQuery(d.training.list, {});
      r.length > 0 ? t = r[0].id : t = await o.runMutation(d.training.createTraining, {
        title: "\u30C7\u30D5\u30A9\u30EB\u30C8\u30C8\u30EC\u30FC\u30CB\u30F3\u30B0",
        description: "\u30D5\u30A1\u30A4\u30EB\u30A2\u30C3\u30D7\u30ED\u30FC\u30C9\u7528\u306E\u30C7\u30D5\u30A9\u30EB\u30C8\u30C8\u30EC\u30FC\u30CB\u30F3\u30B0",
        category: "other"
      });
      let u = (n.contents || []).map((i) => ({
        title: i.title,
        content: i.content || "",
        content_type: i.content_type,
        file_url: i.file_url,
        file_type: i.file_type
      })), p = await o.runMutation(d.training.createModule, {
        trainingId: t,
        title: n.title,
        description: n.description || "",
        category: "document",
        // デフォルトカテゴリ
        durationMinutes: typeof n.duration == "string" ? Number.parseInt(n.duration) || 30 : n.duration || 30,
        contents: u
      });
      return new Response(
        JSON.stringify({
          success: !0,
          data: p,
          message: "\u30C8\u30EC\u30FC\u30CB\u30F3\u30B0\u30E2\u30B8\u30E5\u30FC\u30EB\u304C\u6B63\u5E38\u306B\u4F5C\u6210\u3055\u308C\u307E\u3057\u305F"
        }),
        {
          status: 200,
          headers: { "Content-Type": "application/json", ...s }
        }
      );
    } catch (e) {
      return console.error("[HTTP] Training module create error:", e), new Response(
        JSON.stringify({
          success: !1,
          error: e instanceof Error ? e.message : "Internal server error"
        }),
        {
          status: 500,
          headers: { "Content-Type": "application/json", ...s }
        }
      );
    }
  })
});
var y = [
  "/ping",
  "/notifications/slack-oauth/auth-url",
  "/notifications/slack-oauth/status",
  "/notifications/slack-oauth/callback",
  "/notifications/slack-oauth/channels",
  "/notifications/slack-oauth/disconnect",
  "/notifications/slack-oauth/test",
  "/api/upload/course-thumbnail/generate-url",
  "/api/upload/module-content/generate-url",
  "/api/upload/training-content/generate-url",
  "/api/training/modules/create",
  "/api/vertex-ai/token/health",
  "/api/vertex-ai/token/refresh"
];
y.forEach((o) => {
  l.route({
    path: o,
    method: "OPTIONS",
    handler: c(async () => new Response(null, {
      status: 200,
      headers: s
    }))
  });
});
l.route({
  path: "/api/vertex-ai/token/health",
  method: "GET",
  handler: c(async (o, a) => {
    console.log("[HTTP] Vertex AI token health check endpoint called");
    try {
      let e = await o.runAction(T.vertexTokenManager.checkTokenHealth, {});
      return new Response(
        JSON.stringify({
          success: !0,
          data: e
        }),
        {
          status: 200,
          headers: { "Content-Type": "application/json", ...s }
        }
      );
    } catch (e) {
      return console.error("[HTTP] Vertex AI token health check error:", e), new Response(
        JSON.stringify({
          success: !1,
          error: e instanceof Error ? e.message : "Internal server error"
        }),
        {
          status: 500,
          headers: { "Content-Type": "application/json", ...s }
        }
      );
    }
  })
});
l.route({
  path: "/api/vertex-ai/token/refresh",
  method: "POST",
  handler: c(async (o, a) => {
    console.log("[HTTP] Vertex AI token refresh endpoint called");
    try {
      let e = await o.runAction(T.vertexTokenManager.refreshVertexAccessToken, {});
      return new Response(
        JSON.stringify({
          success: e.success,
          data: e,
          message: e.message
        }),
        {
          status: e.success ? 200 : 500,
          headers: { "Content-Type": "application/json", ...s }
        }
      );
    } catch (e) {
      return console.error("[HTTP] Vertex AI token refresh error:", e), new Response(
        JSON.stringify({
          success: !1,
          error: e instanceof Error ? e.message : "Internal server error"
        }),
        {
          status: 500,
          headers: { "Content-Type": "application/json", ...s }
        }
      );
    }
  })
});
l.route({
  path: "/slack/events",
  method: "POST",
  handler: c(async (o, a) => {
    console.log("[HTTP] Slack events endpoint called");
    try {
      let e = await a.text();
      console.log("[HTTP] Raw Slack event body:", e);
      let n;
      try {
        n = JSON.parse(e);
      } catch (t) {
        return console.error("[HTTP] JSON parse error:", t), new Response("Invalid JSON", {
          status: 400,
          headers: { "Content-Type": "text/plain" }
        });
      }
      if (console.log("[HTTP] Parsed Slack event:", n), n.type === "url_verification" && n.challenge)
        return console.log("[HTTP] Slack URL verification challenge received"), new Response(n.challenge, {
          status: 200,
          headers: { "Content-Type": "text/plain" }
        });
      if (n.type === "event_callback" && n.event) {
        let t = n.event;
        console.log("[HTTP] Slack event received:", t.type, t), t.type === "message" && !t.bot_id && (console.log("[HTTP] User message:", t.text, "from channel:", t.channel), console.log("[HTTP] Would respond to message:", t.text));
      }
      return new Response("OK", {
        status: 200,
        headers: { "Content-Type": "text/plain" }
      });
    } catch (e) {
      return console.error("[HTTP] Slack events error:", e), new Response(`Error processing event: ${e instanceof Error ? e.message : "Unknown error"}`, {
        status: 500,
        headers: { "Content-Type": "text/plain" }
      });
    }
  })
});
l.route({
  path: "/slack/commands",
  method: "POST",
  handler: c(async (o, a) => {
    console.log("[HTTP] Slack slash command endpoint called");
    try {
      let e = await a.formData(), n = e.get("command"), t = e.get("text"), r = e.get("user_name"), u = e.get("channel_name");
      console.log("[HTTP] Slash command received:", {
        command: n,
        text: t,
        userName: r,
        channelName: u
      });
      let p = {
        response_type: "in_channel",
        text: `Hello ${r}! You said: "${t}" in #${u}`,
        attachments: [
          {
            color: "good",
            fields: [
              {
                title: "Command",
                value: n,
                short: !0
              },
              {
                title: "Channel",
                value: `#${u}`,
                short: !0
              }
            ]
          }
        ]
      };
      return new Response(JSON.stringify(p), {
        status: 200,
        headers: { "Content-Type": "application/json" }
      });
    } catch (e) {
      return console.error("[HTTP] Slack slash command error:", e), new Response("Error processing command", {
        status: 500,
        headers: { "Content-Type": "text/plain" }
      });
    }
  })
});
l.route({
  path: "/slack/interactive",
  method: "POST",
  handler: c(async (o, a) => {
    console.log("[HTTP] Slack interactive endpoint called");
    try {
      let e = await a.formData(), n = JSON.parse(e.get("payload"));
      if (console.log("[HTTP] Interactive payload:", n), n.type === "block_actions") {
        let t = n.actions[0];
        return console.log("[HTTP] Action received:", t.action_id, t.value), new Response(JSON.stringify({
          text: `Action "${t.action_id}" processed successfully!`
        }), {
          status: 200,
          headers: { "Content-Type": "application/json" }
        });
      }
      return new Response("OK", {
        status: 200,
        headers: { "Content-Type": "text/plain" }
      });
    } catch (e) {
      return console.error("[HTTP] Slack interactive error:", e), new Response("Error processing interaction", {
        status: 500,
        headers: { "Content-Type": "text/plain" }
      });
    }
  })
});
var P = l;
export {
  P as default
};
//# sourceMappingURL=http.js.map
