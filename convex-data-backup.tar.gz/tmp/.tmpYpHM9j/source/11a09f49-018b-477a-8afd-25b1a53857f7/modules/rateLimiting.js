import {
  d as f
} from "./_deps/75JH2J25.js";
import "./_deps/6XQQNYIR.js";
import {
  j as s,
  l as m,
  n as d
} from "./_deps/3TDUHHJO.js";
import {
  a
} from "./_deps/RUVYHBJQ.js";

// convex/rateLimiting.ts
d();
d();
async function R(e, t, i, n) {
  let r = Date.now(), w = Math.floor(r / n.windowMs) * n.windowMs, u = await e.db.query("rateLimitRecords").withIndex("by_user_action", (o) => o.eq("userId", t).eq("action", i)).collect(), c = u.find((o) => o.windowStart === w);
  if (c) {
    if (c.count >= n.maxRequests)
      return !1;
    await e.db.patch(c._id, {
      count: c.count + 1
    });
  } else
    await e.db.insert("rateLimitRecords", {
      userId: t,
      action: i,
      count: 1,
      windowStart: w
    });
  let l = r - n.windowMs * 2, x = u.filter((o) => o.windowStart < l);
  for (let o of x)
    await e.db.delete(o._id);
  return !0;
}
a(R, "checkRateLimit");
async function p(e, t, i, n) {
  let { internal: r } = await import("./_deps/3EDAOEH2.js");
  return await e.runMutation(r.rateLimiting.checkRateLimitInternal, {
    userId: t,
    action: i,
    windowMs: n.windowMs,
    maxRequests: n.maxRequests
  });
}
a(p, "checkRateLimitFromAction");
function M(e, t) {
  let i = Math.ceil(t / 6e4);
  throw new m(
    `Rate limit exceeded for ${e}. Please try again in ${i} minute(s).`
  );
}
a(M, "throwRateLimitError");
var k = {
  // 通知作成: 1分間に10回まで
  createNotification: {
    windowMs: 60 * 1e3,
    maxRequests: 10,
    keyPrefix: "create_notification"
  },
  // Slack通知: 1分間に5回まで
  slackNotification: {
    windowMs: 60 * 1e3,
    maxRequests: 5,
    keyPrefix: "slack_notification"
  },
  // Webhook検証: 1分間に3回まで
  webhookValidation: {
    windowMs: 60 * 1e3,
    maxRequests: 3,
    keyPrefix: "webhook_validation"
  },
  // 一括操作: 10分間に3回まで
  bulkOperations: {
    windowMs: 10 * 60 * 1e3,
    maxRequests: 3,
    keyPrefix: "bulk_operations"
  }
};
function q(e, t, i) {
  return async (n, r) => {
    let w = await n.auth.getUserIdentity();
    if (!w)
      throw new m("Authentication required for rate-limited operations");
    return await R(n, w.subject, t, i) || M(t, i.windowMs), await e(n, r);
  };
}
a(q, "withRateLimit");
var y = f({
  args: {
    userId: s.string(),
    action: s.string(),
    windowMs: s.number(),
    maxRequests: s.number()
  },
  returns: s.boolean(),
  handler: /* @__PURE__ */ a(async (e, t) => {
    let i = {
      windowMs: t.windowMs,
      maxRequests: t.maxRequests
    };
    return await R(e, t.userId, t.action, i);
  }, "handler")
});
export {
  k as NOTIFICATION_RATE_LIMITS,
  R as checkRateLimit,
  p as checkRateLimitFromAction,
  y as checkRateLimitInternal,
  M as throwRateLimitError,
  q as withRateLimit
};
//# sourceMappingURL=rateLimiting.js.map
