"use node";
import {
  b as I
} from "./_deps/node/VTOLWO7E.js";
import {
  f as k,
  g as _,
  i as w,
  j as f
} from "./_deps/node/NAH3KYY3.js";
import "./_deps/node/SEHFPZI7.js";
import "./_deps/node/27HPQ4GU.js";
import "./_deps/node/WLMMRF4U.js";
import "./_deps/node/YKKTZAAP.js";
import "./_deps/node/2SFASJNQ.js";
import "./_deps/node/BSU5XI2C.js";
import {
  a as A,
  d as m
} from "./_deps/node/PDGHC3PS.js";
import {
  a as r
} from "./_deps/node/UDHF6CTX.js";
import {
  a as u
} from "./_deps/node/V7X2J7BI.js";

// convex/googleGenAIActions.ts
var P = m({
  args: {
    transcript_id: r.string(),
    environment: r.optional(r.string()),
    workflow_type: r.optional(r.string()),
    force_execution: r.optional(r.boolean())
  },
  returns: r.any(),
  handler: /* @__PURE__ */ u(async (i, t) => {
    console.log(`GoogleGenAI: Starting workflow execution for transcript ${t.transcript_id}`);
    try {
      let n = t.transcript_id, o = await A.transcriptions.getTranscriptionResult({
        transcriptionId: n
      });
      if (!o || !o.success)
        throw new Error(`Transcription not found or not completed: ${t.transcript_id}`);
      let e = o.data, s = null;
      if (console.log(
        `[GoogleGenAI DEBUG] transcription.resource_type: ${e.resource_type}`
      ), console.log(`[GoogleGenAI DEBUG] transcription.resource_id: ${e.resource_id}`), e.resource_type === "video" && e.resource_id)
        try {
          console.log(
            `[GoogleGenAI DEBUG] Fetching video data for ID: ${e.resource_id}`
          );
          let c = e.resource_id;
          s = await i.runQuery(I.videos.getByIdInternal, { videoId: c }), console.log("[GoogleGenAI DEBUG] Video data retrieved:", s), console.log(`[GoogleGenAI DEBUG] video.type: ${s?.type}`);
        } catch (c) {
          console.warn(
            `[GoogleGenAI] Could not fetch video data for ${e.resource_id}:`,
            c
          );
        }
      else
        console.log(
          `[GoogleGenAI DEBUG] Skipping video fetch - resource_type: ${e.resource_type}, resource_id: ${e.resource_id}`
        );
      let l = s?.type || "unknown";
      console.log(`[GoogleGenAI DEBUG] final_videoType: ${l}`);
      let a = e.transcript_with_speaker || e.transcript || "";
      console.log(
        `[GoogleGenAI] Using transcript_with_speaker: ${!!e.transcript_with_speaker}`
      );
      let d = {
        transcript: a,
        videoType: l || "\u521D\u56DE\u9762\u8AC7",
        doAddSpeaker: e.speaker_detection_enabled ? 1 : 0,
        transcriptionId: t.transcript_id,
        metadata: {
          video_title: s?.title || e.video_title || "Unknown",
          video_duration: s?.duration_seconds || e.video_duration || 0,
          created_at: e._creationTime,
          user_id: e.user_id
        }
      }, g = Date.now();
      console.log(`Starting evaluation for ${t.transcript_id}, type: ${l}`);
      let [
        p,
        E,
        G,
        S,
        $
      ] = await Promise.all([
        // 評価エンジンの実行
        (async () => {
          try {
            let c = ["VERTEX_AI_PROJECT_ID"];
            for (let y of c)
              if (!process.env[y])
                return console.warn(`[executeWorkflow] \u74B0\u5883\u5909\u6570 ${y} \u304C\u8A2D\u5B9A\u3055\u308C\u3066\u3044\u307E\u305B\u3093\u3002\u8A55\u4FA1\u3092\u30B9\u30AD\u30C3\u30D7\u3057\u307E\u3059\u3002`), {
                  success: !1,
                  error: `\u74B0\u5883\u5909\u6570 ${y} \u304C\u8A2D\u5B9A\u3055\u308C\u3066\u3044\u307E\u305B\u3093`
                };
            let { HybridEvaluationEngine: h } = await import("./evaluation/evaluationEngineV2.js");
            return { success: !0, evaluation: (await new h().process(d)).evaluation };
          } catch (c) {
            return console.error(`Evaluation failed for ${t.transcript_id}:`, c), {
              success: !1,
              error: c instanceof Error ? c.message : "Unknown error"
            };
          }
        })(),
        // 話者付き文字起こし生成（話者情報が含まれていない場合は再処理）
        (async () => e.transcript_with_speaker && /(##\s*[👤👔⭐🔧💰]\s*話者[ABC]|話者[ABC]:\s*|###\s*[📝🎯💼🔍])/.test(e.transcript_with_speaker) ? e.transcript_with_speaker : await k(a))(),
        // 議事録生成（話者付き文字起こしを使用）
        _(a),
        // 案件化情報サマリー生成（話者付き文字起こしを使用）
        w(a),
        // 商談記録サマリー生成（話者付き文字起こしを使用）
        f(a)
      ]), v = Date.now() - g;
      console.log(`Evaluation completed for ${t.transcript_id} in ${v}ms`);
      let T = p.success;
      return {
        data: {
          outputs: {
            evaluation: p.success ? p.evaluation : {
              improvementSummary: "\u30B7\u30B9\u30C6\u30E0\u30A8\u30E9\u30FC\u304C\u767A\u751F\u3057\u307E\u3057\u305F\u3002",
              overallComment: "\u30B7\u30B9\u30C6\u30E0\u30A8\u30E9\u30FC\u306E\u305F\u3081\u3001\u66AB\u5B9A\u7684\u306A\u8A55\u4FA1\u3092\u8868\u793A\u3057\u3066\u3044\u307E\u3059\u3002\u8A73\u7D30\u306A\u5206\u6790\u306B\u3064\u3044\u3066\u306F\u3001\u518D\u5EA6\u8A55\u4FA1\u3092\u5B9F\u884C\u3057\u3066\u304F\u3060\u3055\u3044\u3002"
            },
            caseSummary: S,
            meetingSummary: $,
            meetingMinutes: G,
            transcript_with_speaker: E
          }
        },
        success: T,
        processing_time_ms: v,
        error: p.success ? void 0 : p.error
      };
    } catch (n) {
      return console.error(`GoogleGenAI: Workflow execution failed for ${t.transcript_id}:`, n), console.log("Generating fallback response for unknown video type"), {
        data: {
          outputs: {
            evaluation: {
              improvementSummary: "\u30B7\u30B9\u30C6\u30E0\u30A8\u30E9\u30FC\u304C\u767A\u751F\u3057\u307E\u3057\u305F\u3002",
              overallComment: "\u30B7\u30B9\u30C6\u30E0\u30A8\u30E9\u30FC\u306E\u305F\u3081\u3001\u66AB\u5B9A\u7684\u306A\u8A55\u4FA1\u3092\u8868\u793A\u3057\u3066\u3044\u307E\u3059\u3002\u8A73\u7D30\u306A\u5206\u6790\u306B\u3064\u3044\u3066\u306F\u3001\u518D\u5EA6\u8A55\u4FA1\u3092\u5B9F\u884C\u3057\u3066\u304F\u3060\u3055\u3044\u3002"
            },
            caseSummary: null,
            meetingSummary: null,
            meetingMinutes: null,
            transcript_with_speaker: ""
          }
        },
        success: !1,
        error: n instanceof Error ? n.message : "Unknown error occurred",
        processing_time_ms: 1
      };
    }
  }, "handler")
}), V = m({
  args: {
    transcriptionId: r.id("transcriptions"),
    environment: r.optional(r.string()),
    transcriptionData: r.optional(r.object({
      text: r.string(),
      status: r.string(),
      resource_type: r.string(),
      resource_id: r.string(),
      transcript_with_speaker: r.optional(r.string()),
      _creationTime: r.number()
    }))
  },
  returns: r.any(),
  handler: /* @__PURE__ */ u(async (i, t) => {
    let n = Date.now();
    console.log(`[processAudioFileAnalysis] \u97F3\u58F0\u30D5\u30A1\u30A4\u30EB\u5206\u6790\u958B\u59CB (transcriptionId: ${t.transcriptionId}) - ${(/* @__PURE__ */ new Date()).toISOString()}`);
    try {
      let o;
      if (t.transcriptionData)
        o = t.transcriptionData;
      else
        throw new Error("transcriptionData\u30D1\u30E9\u30E1\u30FC\u30BF\u304C\u5FC5\u8981\u3067\u3059");
      if (!o.text || o.text.length < 10)
        throw new Error("\u6587\u5B57\u8D77\u3053\u3057\u30C6\u30AD\u30B9\u30C8\u304C\u4E0D\u5B8C\u5168\u3067\u3059");
      let e = o.transcript_with_speaker || o.text;
      console.log("[processAudioFileAnalysis] \u5168\u3066\u306EAI\u51E6\u7406\u3092\u4E26\u5217\u5B9F\u884C\u958B\u59CB");
      let [s, l, a, d] = await Promise.all([
        D(e, "\u97F3\u58F0\u30D5\u30A1\u30A4\u30EB", o._creationTime, t.environment),
        U(e),
        x(e),
        M(e)
      ]);
      console.log(`[processAudioFileAnalysis] \u8A55\u4FA1\u30A8\u30F3\u30B8\u30F3\u5B9F\u884C\u5B8C\u4E86: ${s.success ? "\u6210\u529F" : "\u5931\u6557"}`), console.log(`[processAudioFileAnalysis] \u8B70\u4E8B\u9332\u751F\u6210\u5B8C\u4E86: ${l.success ? "\u6210\u529F" : "\u5931\u6557"}`), console.log(`[processAudioFileAnalysis] \u6848\u4EF6\u5316\u30B5\u30DE\u30EA\u30FC\u751F\u6210\u5B8C\u4E86: ${a.success ? "\u6210\u529F" : "\u5931\u6557"}`), console.log(`[processAudioFileAnalysis] \u5546\u8AC7\u8A18\u9332\u30B5\u30DE\u30EA\u30FC\u751F\u6210\u5B8C\u4E86: ${d.success ? "\u6210\u529F" : "\u5931\u6557"}`), console.log("[processAudioFileAnalysis] \u5168\u3066\u306EAI\u51E6\u7406\u5B8C\u4E86");
      let g = Date.now() - n;
      return console.log(`[processAudioFileAnalysis] \u5168\u3066\u306EAI\u51E6\u7406\u5B8C\u4E86 (${g}ms)`), {
        success: !0,
        message: "\u5168\u3066\u306EAI\u51E6\u7406\u304C\u5B8C\u4E86\u3057\u307E\u3057\u305F\u3002",
        processing_time_ms: g,
        results: {
          evaluation: s,
          meetingMinutes: l,
          caseSummary: a,
          meetingSummary: d
        }
      };
    } catch (o) {
      return console.error("[processAudioFileAnalysis] \u97F3\u58F0\u30D5\u30A1\u30A4\u30EB\u5206\u6790\u4E2D\u306B\u30A8\u30E9\u30FC\u767A\u751F:", o), {
        success: !1,
        error: o instanceof Error ? o.message : "Unknown error occurred"
      };
    }
  }, "handler")
});
async function D(i, t, n, o) {
  try {
    let e = {
      transcript: i,
      videoType: t,
      doAddSpeaker: 0,
      transcriptionId: "dummy",
      // ヘルパー関数内では使用しない
      metadata: {
        video_title: "\u97F3\u58F0\u30D5\u30A1\u30A4\u30EB",
        video_duration: 0,
        created_at: n,
        user_id: null
      }
    }, { HybridEvaluationEngine: s } = await import("./evaluation/evaluationEngineV2.js"), a = await new s().process(e);
    return a.success ? { success: !0, result: a.evaluation } : { success: !1, error: a.error || "\u8A55\u4FA1\u30A8\u30F3\u30B8\u30F3\u3067\u4E0D\u660E\u306A\u30A8\u30E9\u30FC\u304C\u767A\u751F\u3057\u307E\u3057\u305F" };
  } catch (e) {
    return console.error("[runEvaluationHelper] \u30A8\u30E9\u30FC:", e), { success: !1, error: e instanceof Error ? e.message : "Unknown evaluation error" };
  }
}
u(D, "runEvaluationHelper");
async function U(i) {
  try {
    return { success: !0, result: await _(i) };
  } catch (t) {
    return console.error("[runMeetingMinutesHelper] \u30A8\u30E9\u30FC:", t), { success: !1, error: t instanceof Error ? t.message : "Unknown meeting minutes error" };
  }
}
u(U, "runMeetingMinutesHelper");
async function x(i) {
  try {
    return { success: !0, result: await w(i) };
  } catch (t) {
    return console.error("[runCaseSummaryHelper] \u30A8\u30E9\u30FC:", t), { success: !1, error: t instanceof Error ? t.message : "Unknown case summary error" };
  }
}
u(x, "runCaseSummaryHelper");
async function M(i) {
  try {
    return { success: !0, result: await f(i) };
  } catch (t) {
    return console.error("[runMeetingSummaryHelper] \u30A8\u30E9\u30FC:", t), { success: !1, error: t instanceof Error ? t.message : "Unknown meeting summary error" };
  }
}
u(M, "runMeetingSummaryHelper");
var W = m({
  args: {
    environment: r.optional(r.string())
  },
  returns: r.object({
    status: r.string(),
    service: r.string(),
    timestamp: r.number(),
    error: r.optional(r.string())
  }),
  handler: /* @__PURE__ */ u(async (i, t) => {
    try {
      let { HybridEvaluationEngine: n } = await import("./evaluation/evaluationEngineV2.js");
      return {
        status: await new n().healthCheck() ? "healthy" : "unhealthy",
        service: "google-genai",
        timestamp: Date.now()
      };
    } catch (n) {
      return console.error("GoogleGenAI health check failed:", n), {
        status: "unhealthy",
        service: "google-genai",
        error: n instanceof Error ? n.message : "Unknown error",
        timestamp: Date.now()
      };
    }
  }, "handler")
}), j = m({
  args: {
    environment: r.optional(r.string())
  },
  returns: r.any(),
  handler: /* @__PURE__ */ u(async (i, t) => {
    try {
      let { HybridEvaluationEngine: n } = await import("./evaluation/evaluationEngineV2.js"), o = new n(), e = {
        transcript: "\u30C6\u30B9\u30C8\u7528\u306E\u77ED\u3044\u6587\u5B57\u8D77\u3053\u3057\u3067\u3059\u3002",
        videoType: "\u8B72\u6E21\u67B6\u96FB",
        doAddSpeaker: 0,
        transcriptionId: "test-" + Date.now(),
        metadata: {}
      }, s = await o.process(e);
      return {
        success: s.success,
        processing_time_ms: s.metrics?.totalDuration,
        has_evaluation: !!s.evaluation,
        test_completed: !0
      };
    } catch (n) {
      return console.error("GoogleGenAI configuration test failed:", n), {
        success: !1,
        error: n instanceof Error ? n.message : "Unknown error",
        test_completed: !1
      };
    }
  }, "handler")
});
export {
  P as executeWorkflow,
  W as healthCheck,
  V as processAudioFileAnalysis,
  j as testConfiguration
};
//# sourceMappingURL=googleGenAIActions.js.map
