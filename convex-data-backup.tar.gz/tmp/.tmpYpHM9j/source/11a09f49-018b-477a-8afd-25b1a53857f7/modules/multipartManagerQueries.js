import {
  b as n,
  d as o
} from "./_deps/75JH2J25.js";
import "./_deps/6XQQNYIR.js";
import {
  j as t,
  n as a
} from "./_deps/3TDUHHJO.js";
import {
  a as e
} from "./_deps/RUVYHBJQ.js";

// convex/multipartManagerQueries.ts
a();
var u = n({
  args: {
    fileUploadId: t.id("fileUploads")
  },
  returns: t.union(
    t.object({
      uploadId: t.string(),
      gcpFilePath: t.string(),
      totalParts: t.number(),
      fileSize: t.number(),
      contentType: t.string(),
      status: t.string(),
      completedParts: t.optional(
        t.array(
          t.object({
            partNumber: t.number(),
            etag: t.string(),
            completedAt: t.number()
          })
        )
      )
    }),
    t.null()
  ),
  handler: /* @__PURE__ */ e(async (l, r) => (console.log("[getLatestMultipartUpload] Query for latest upload:", r), null), "handler")
}), d = n({
  args: {
    fileUploadId: t.id("fileUploads"),
    uploadId: t.string()
  },
  returns: t.union(
    t.object({
      uploadId: t.string(),
      gcpFilePath: t.string(),
      totalParts: t.number(),
      completedParts: t.optional(
        t.array(
          t.object({
            partNumber: t.number(),
            etag: t.string(),
            completedAt: t.number()
          })
        )
      ),
      contentType: t.string(),
      retryAttempts: t.optional(
        t.array(
          t.object({
            partNumber: t.number(),
            attempts: t.number(),
            lastError: t.string(),
            lastAttempt: t.number()
          })
        )
      )
    }),
    t.null()
  ),
  handler: /* @__PURE__ */ e(async (l, r) => (console.log("[getMultipartUploadInfo] Query for upload info:", r), null), "handler")
}), i = o({
  args: {
    fileUploadId: t.id("fileUploads"),
    uploadId: t.string(),
    gcpFilePath: t.string(),
    filename: t.string(),
    contentType: t.string(),
    fileSize: t.number(),
    totalParts: t.number(),
    status: t.string()
  },
  returns: t.null(),
  handler: /* @__PURE__ */ e(async (l, r) => (console.log("[storeMultipartUploadInfo] Storing upload info:", r), null), "handler")
}), g = o({
  args: {
    fileUploadId: t.id("fileUploads"),
    uploadId: t.string(),
    partNumber: t.number(),
    etag: t.string()
  },
  returns: t.null(),
  handler: /* @__PURE__ */ e(async (l, r) => (console.log("[markPartComplete] Part completed:", r), null), "handler")
}), c = o({
  args: {
    fileUploadId: t.id("fileUploads"),
    uploadId: t.string()
  },
  returns: t.null(),
  handler: /* @__PURE__ */ e(async (l, r) => (console.log("[markUploadComplete] Upload completed:", r), null), "handler")
}), m = o({
  args: {
    fileUploadId: t.id("fileUploads"),
    uploadId: t.string(),
    partNumber: t.number(),
    errorMessage: t.string()
  },
  returns: t.null(),
  handler: /* @__PURE__ */ e(async (l, r) => (console.log("[recordRetryAttempt] Retry attempt recorded:", r), null), "handler")
});
export {
  u as getLatestMultipartUpload,
  d as getMultipartUploadInfo,
  g as markPartComplete,
  c as markUploadComplete,
  m as recordRetryAttempt,
  i as storeMultipartUploadInfo
};
//# sourceMappingURL=multipartManagerQueries.js.map
