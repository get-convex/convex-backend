"use node";
import {
  b as d
} from "./_deps/node/NAH3KYY3.js";
import "./_deps/node/SEHFPZI7.js";
import "./_deps/node/27HPQ4GU.js";
import "./_deps/node/WLMMRF4U.js";
import "./_deps/node/YKKTZAAP.js";
import "./_deps/node/2SFASJNQ.js";
import "./_deps/node/BSU5XI2C.js";
import {
  c as y
} from "./_deps/node/PDGHC3PS.js";
import {
  a as t
} from "./_deps/node/UDHF6CTX.js";
import {
  a as p
} from "./_deps/node/V7X2J7BI.js";

// convex/transcriptionFormatting.ts
var P = y({
  args: {
    transcriptionText: t.string(),
    options: t.optional(t.object({
      includeTimestamps: t.optional(t.boolean()),
      includeSpeakerDiarization: t.optional(t.boolean()),
      outputFormat: t.optional(t.union(t.literal("structured"), t.literal("paragraph"), t.literal("bullets")))
    }))
  },
  returns: t.object({
    formattedText: t.string(),
    summary: t.optional(t.string()),
    keyPoints: t.optional(t.array(t.string()))
  }),
  handler: /* @__PURE__ */ p(async (u, o) => {
    try {
      let { transcriptionText: n, options: i = {} } = o, {
        includeTimestamps: s = !1,
        includeSpeakerDiarization: e = !1,
        outputFormat: T = "structured"
      } = i, m = f(n, {
        includeTimestamps: s,
        includeSpeakerDiarization: e,
        outputFormat: T
      });
      console.log("[formatTranscriptionWithGemini] Gemini\u3067\u30C6\u30AD\u30B9\u30C8\u6574\u5F62\u958B\u59CB");
      let r = await new d({
        vertexAI: {
          projectId: process.env.VERTEX_AI_PROJECT_ID || process.env.GOOGLE_CLOUD_PROJECT_ID || "",
          location: process.env.VERTEX_AI_LOCATION || "asia-northeast1",
          model: "gemini-1.5-pro",
          temperature: 0.3,
          maxOutputTokens: 4e3
        }
      }).generateText(m, {
        maxOutputTokens: 4e3
      }), c = r.match(/```json\s*([\s\S]*?)\s*```/), a;
      if (c)
        try {
          a = JSON.parse(c[1]);
        } catch (g) {
          console.warn("[formatTranscriptionWithGemini] JSON\u89E3\u6790\u5931\u6557\u3001\u30D5\u30A9\u30FC\u30EB\u30D0\u30C3\u30AF\u51E6\u7406:", g), a = {
            formattedText: r,
            summary: "",
            keyPoints: []
          };
        }
      else
        a = {
          formattedText: r,
          summary: "",
          keyPoints: []
        };
      return console.log("[formatTranscriptionWithGemini] \u6574\u5F62\u5B8C\u4E86"), {
        formattedText: a.formattedText || n,
        summary: a.summary,
        keyPoints: a.keyPoints || []
      };
    } catch (n) {
      return console.error("[formatTranscriptionWithGemini] \u30A8\u30E9\u30FC:", n), {
        formattedText: o.transcriptionText,
        summary: void 0,
        keyPoints: void 0
      };
    }
  }, "handler")
});
function f(u, o) {
  let { includeTimestamps: n, includeSpeakerDiarization: i, outputFormat: s } = o, e = `\u4EE5\u4E0B\u306E\u6587\u5B57\u8D77\u3053\u3057\u30C6\u30AD\u30B9\u30C8\u3092\u8AAD\u307F\u3084\u3059\u304F\u6574\u5F62\u3057\u3066\u304F\u3060\u3055\u3044\u3002

## \u6574\u5F62\u30EB\u30FC\u30EB:
1. \u8A71\u3057\u8A00\u8449\u3092\u81EA\u7136\u306A\u6587\u7AE0\u306B\u5909\u63DB
2. \u4E0D\u8981\u306A\u9593\u6295\u8A5E\uFF08\u300C\u3048\u30FC\u3063\u3068\u300D\u300C\u3042\u306E\u30FC\u300D\u306A\u3069\uFF09\u3092\u9664\u53BB
3. \u53E5\u8AAD\u70B9\u3092\u9069\u5207\u306B\u914D\u7F6E
4. \u6BB5\u843D\u3092\u9069\u5207\u306B\u5206\u5272
`;
  switch (n && (e += `5. \u30BF\u30A4\u30E0\u30B9\u30BF\u30F3\u30D7\u304C\u3042\u308B\u5834\u5408\u306F\u4FDD\u6301
`), i && (e += `6. \u8A71\u8005\u60C5\u5831\u304C\u3042\u308B\u5834\u5408\u306F\u4FDD\u6301\u3057\u3001\u8A71\u8005\u3054\u3068\u306B\u6574\u7406
`), s) {
    case "structured":
      e += `
## \u51FA\u529B\u5F62\u5F0F:
\u4EE5\u4E0B\u306EJSON\u5F62\u5F0F\u3067\u56DE\u7B54\u3057\u3066\u304F\u3060\u3055\u3044\uFF1A

\`\`\`json
{
  "formattedText": "\u6574\u5F62\u3055\u308C\u305F\u30C6\u30AD\u30B9\u30C8\uFF08\u6BB5\u843D\u5206\u3051\u3055\u308C\u305F\u8AAD\u307F\u3084\u3059\u3044\u6587\u7AE0\uFF09",
  "summary": "\u5185\u5BB9\u306E\u8981\u7D04\uFF083-5\u6587\u7A0B\u5EA6\uFF09",
  "keyPoints": ["\u91CD\u8981\u306A\u30DD\u30A4\u30F3\u30C81", "\u91CD\u8981\u306A\u30DD\u30A4\u30F3\u30C82", "\u91CD\u8981\u306A\u30DD\u30A4\u30F3\u30C83"]
}
\`\`\`
`;
      break;
    case "paragraph":
      e += `
## \u51FA\u529B\u5F62\u5F0F:
\u6BB5\u843D\u5F62\u5F0F\u3067\u6574\u5F62\u3057\u3001\u4EE5\u4E0B\u306EJSON\u5F62\u5F0F\u3067\u56DE\u7B54\u3057\u3066\u304F\u3060\u3055\u3044\uFF1A

\`\`\`json
{
  "formattedText": "\u6BB5\u843D\u5F62\u5F0F\u3067\u6574\u5F62\u3055\u308C\u305F\u30C6\u30AD\u30B9\u30C8",
  "summary": "\u5185\u5BB9\u306E\u8981\u7D04",
  "keyPoints": ["\u91CD\u8981\u306A\u30DD\u30A4\u30F3\u30C81", "\u91CD\u8981\u306A\u30DD\u30A4\u30F3\u30C82"]
}
\`\`\`
`;
      break;
    case "bullets":
      e += `
## \u51FA\u529B\u5F62\u5F0F:
\u7B87\u6761\u66F8\u304D\u5F62\u5F0F\u3067\u6574\u5F62\u3057\u3001\u4EE5\u4E0B\u306EJSON\u5F62\u5F0F\u3067\u56DE\u7B54\u3057\u3066\u304F\u3060\u3055\u3044\uFF1A

\`\`\`json
{
  "formattedText": "\u2022 \u30DD\u30A4\u30F3\u30C81\\n\u2022 \u30DD\u30A4\u30F3\u30C82\\n\u2022 \u30DD\u30A4\u30F3\u30C83",
  "summary": "\u5185\u5BB9\u306E\u8981\u7D04",
  "keyPoints": ["\u91CD\u8981\u306A\u30DD\u30A4\u30F3\u30C81", "\u91CD\u8981\u306A\u30DD\u30A4\u30F3\u30C82"]
}
\`\`\`
`;
      break;
  }
  return e += `
## \u5143\u306E\u6587\u5B57\u8D77\u3053\u3057\u30C6\u30AD\u30B9\u30C8:
${u}
`, e;
}
p(f, "buildFormattingPrompt");
var h = y({
  args: {
    transcriptionText: t.string(),
    audioTitle: t.optional(t.string()),
    audioType: t.optional(t.string())
  },
  returns: t.object({
    summary: t.string(),
    keyPoints: t.array(t.string()),
    actionItems: t.optional(t.array(t.string())),
    participants: t.optional(t.array(t.string()))
  }),
  handler: /* @__PURE__ */ p(async (u, o) => {
    try {
      let { transcriptionText: n, audioTitle: i, audioType: s } = o, e = `\u4EE5\u4E0B\u306E\u97F3\u58F0\u8A18\u9332\u306E\u5185\u5BB9\u3092\u5206\u6790\u3057\u3001\u8981\u7D04\u3092\u4F5C\u6210\u3057\u3066\u304F\u3060\u3055\u3044\u3002

## \u97F3\u58F0\u60C5\u5831:
- \u30BF\u30A4\u30C8\u30EB: ${i || "\u672A\u8A2D\u5B9A"}
- \u7A2E\u985E: ${s || "\u4E00\u822C"}

## \u5206\u6790\u6307\u793A:
1. \u5168\u4F53\u306E\u8981\u7D04\u3092\u4F5C\u6210
2. \u91CD\u8981\u306A\u30DD\u30A4\u30F3\u30C8\u3092\u62BD\u51FA
3. \u30A2\u30AF\u30B7\u30E7\u30F3\u30A2\u30A4\u30C6\u30E0\uFF08\u5B9F\u884C\u3059\u3079\u304D\u4E8B\u9805\uFF09\u304C\u3042\u308C\u3070\u62BD\u51FA
4. \u53C2\u52A0\u8005\u30FB\u8A71\u8005\u304C\u7279\u5B9A\u3067\u304D\u308B\u5834\u5408\u306F\u62BD\u51FA

## \u51FA\u529B\u5F62\u5F0F:
\u4EE5\u4E0B\u306EJSON\u5F62\u5F0F\u3067\u56DE\u7B54\u3057\u3066\u304F\u3060\u3055\u3044\uFF1A

\`\`\`json
{
  "summary": "\u97F3\u58F0\u8A18\u9332\u306E\u5168\u4F53\u8981\u7D04\uFF085-10\u6587\u7A0B\u5EA6\uFF09",
  "keyPoints": ["\u91CD\u8981\u306A\u30DD\u30A4\u30F3\u30C81", "\u91CD\u8981\u306A\u30DD\u30A4\u30F3\u30C82", "\u91CD\u8981\u306A\u30DD\u30A4\u30F3\u30C83"],
  "actionItems": ["\u5B9F\u884C\u3059\u3079\u304D\u4E8B\u98051", "\u5B9F\u884C\u3059\u3079\u304D\u4E8B\u98052"],
  "participants": ["\u53C2\u52A0\u8005\u30FB\u8A71\u80051", "\u53C2\u52A0\u8005\u30FB\u8A71\u80052"]
}
\`\`\`

## \u97F3\u58F0\u8A18\u9332\u306E\u6587\u5B57\u8D77\u3053\u3057:
${n}
`;
      console.log("[generateAudioSummary] \u97F3\u58F0\u8981\u7D04\u751F\u6210\u958B\u59CB");
      let m = await new d({
        vertexAI: {
          projectId: process.env.VERTEX_AI_PROJECT_ID || process.env.GOOGLE_CLOUD_PROJECT_ID || "",
          location: process.env.VERTEX_AI_LOCATION || "asia-northeast1",
          model: "gemini-1.5-pro",
          temperature: 0.4,
          maxOutputTokens: 2e3
        }
      }).generateText(e, {
        maxOutputTokens: 2e3
      }), l = m.match(/```json\s*([\s\S]*?)\s*```/), r;
      if (l)
        try {
          r = JSON.parse(l[1]);
        } catch (c) {
          console.warn("[generateAudioSummary] JSON\u89E3\u6790\u5931\u6557:", c), r = {
            summary: "\u8981\u7D04\u751F\u6210\u306B\u5931\u6557\u3057\u307E\u3057\u305F",
            keyPoints: [],
            actionItems: [],
            participants: []
          };
        }
      else
        r = {
          summary: m.substring(0, 500) + "...",
          keyPoints: [],
          actionItems: [],
          participants: []
        };
      return console.log("[generateAudioSummary] \u8981\u7D04\u751F\u6210\u5B8C\u4E86"), {
        summary: r.summary || "\u8981\u7D04\u3092\u751F\u6210\u3067\u304D\u307E\u305B\u3093\u3067\u3057\u305F",
        keyPoints: r.keyPoints || [],
        actionItems: r.actionItems,
        participants: r.participants
      };
    } catch (n) {
      return console.error("[generateAudioSummary] \u30A8\u30E9\u30FC:", n), {
        summary: "\u8981\u7D04\u751F\u6210\u4E2D\u306B\u30A8\u30E9\u30FC\u304C\u767A\u751F\u3057\u307E\u3057\u305F",
        keyPoints: [],
        actionItems: void 0,
        participants: void 0
      };
    }
  }, "handler")
});
export {
  P as formatTranscriptionWithGemini,
  h as generateAudioSummary
};
//# sourceMappingURL=transcriptionFormatting.js.map
