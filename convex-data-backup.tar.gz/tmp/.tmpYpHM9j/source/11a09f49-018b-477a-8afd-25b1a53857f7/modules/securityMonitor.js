import {
  a as v,
  e as b
} from "./_deps/IVQGLTSC.js";
import {
  a as y,
  c as E,
  d as l
} from "./_deps/75JH2J25.js";
import "./_deps/6XQQNYIR.js";
import {
  j as e,
  l as c,
  n as g
} from "./_deps/3TDUHHJO.js";
import {
  a as u
} from "./_deps/RUVYHBJQ.js";

// convex/securityMonitor.ts
g();
g();
b();
var p = {
  LOW: 1,
  MEDIUM: 2,
  HIGH: 3,
  CRITICAL: 4
}, T = {
  LOGIN_FAILURE: "login_failure",
  USER_PRIVILEGE_CHANGE: "user_privilege_change",
  SUSPICIOUS_ACTIVITY: "suspicious_activity",
  UNAUTHORIZED_ACCESS: "unauthorized_access",
  DATA_ACCESS: "data_access",
  CONFIGURATION_CHANGE: "configuration_change",
  AUTHENTICATION_SUCCESS: "authentication_success",
  AUTHENTICATION_FAILURE: "authentication_failure",
  SESSION_ANOMALY: "session_anomaly"
}, w = E({
  args: {
    event_type: e.string(),
    severity: e.number(),
    details: e.optional(
      e.union(
        e.string(),
        // JSON文字列
        e.record(e.string(), e.any())
        // オブジェクト（内部で文字列化）
      )
    ),
    target_user_id: e.optional(e.id("users")),
    ip_address: e.optional(e.string()),
    user_agent: e.optional(e.string())
  },
  returns: e.object({
    success: e.boolean(),
    event_id: e.optional(e.id("securityEvents"))
  }),
  handler: /* @__PURE__ */ u(async (a, t) => {
    try {
      let s = await a.auth.getUserIdentity(), r;
      s && (r = (await a.db.query("users").withIndex("by_clerk_user_id", (d) => d.eq("clerkUserId", s.subject)).first())?._id);
      let i;
      t.details && (typeof t.details == "string" ? i = t.details : i = JSON.stringify(t.details));
      let o = {
        event_type: t.event_type,
        severity: t.severity,
        created_at: Date.now()
      };
      r && (o.user_id = r), t.target_user_id && (o.target_user_id = t.target_user_id), i && (o.details = i), t.ip_address && (o.ip_address = t.ip_address), t.user_agent && (o.user_agent = t.user_agent);
      let _ = await a.db.insert("securityEvents", o);
      return t.severity >= p.HIGH && console.warn(`High severity security event logged: ${t.event_type}`, {
        severity: t.severity,
        event_id: _,
        details: i
      }), {
        success: !0,
        event_id: _
      };
    } catch (s) {
      return console.error("Failed to log security event:", s), {
        success: !1
      };
    }
  }, "handler")
}), C = y({
  args: {
    limit: e.optional(e.number()),
    event_type: e.optional(e.string()),
    severity: e.optional(e.number()),
    user_id: e.optional(e.id("users")),
    start_date: e.optional(e.number()),
    end_date: e.optional(e.number())
  },
  returns: e.array(
    e.object({
      _id: e.id("securityEvents"),
      event_type: e.string(),
      severity: e.number(),
      user_id: e.optional(e.id("users")),
      target_user_id: e.optional(e.id("users")),
      ip_address: e.optional(e.string()),
      user_agent: e.optional(e.string()),
      details: e.optional(e.string()),
      created_at: e.number()
    })
  ),
  handler: /* @__PURE__ */ u(async (a, t) => {
    if (!(await a.runQuery(v.unifiedAuth.checkUserPermission, {
      requiredRole: "admin"
    })).hasPermission)
      throw new c("\u7BA1\u7406\u8005\u6A29\u9650\u304C\u5FC5\u8981\u3067\u3059");
    let r = await a.db.query("securityEvents").withIndex("by_created_at").order("desc").take(t.limit || 100);
    return t.event_type && (r = r.filter((i) => i.event_type === t.event_type)), t.severity && (r = r.filter((i) => i.severity === t.severity)), t.user_id && (r = r.filter((i) => i.user_id === t.user_id)), t.start_date && (r = r.filter((i) => i.created_at >= t.start_date)), t.end_date && (r = r.filter((i) => i.created_at <= t.end_date)), r;
  }, "handler")
}), A = y({
  args: {
    period_days: e.optional(e.number())
    // デフォルト7日間
  },
  returns: e.object({
    total_events: e.number(),
    events_by_severity: e.record(e.string(), e.number()),
    events_by_type: e.record(e.string(), e.number()),
    high_severity_events: e.number(),
    recent_critical_events: e.array(
      e.object({
        event_type: e.string(),
        created_at: e.number(),
        details: e.optional(e.string())
      })
    )
  }),
  handler: /* @__PURE__ */ u(async (a, t) => {
    if (!(await a.runQuery(v.unifiedAuth.checkUserPermission, {
      requiredRole: "admin"
    })).hasPermission)
      throw new c("\u7BA1\u7406\u8005\u6A29\u9650\u304C\u5FC5\u8981\u3067\u3059");
    let r = t.period_days || 7, i = Date.now() - r * 24 * 60 * 60 * 1e3, o = await a.db.query("securityEvents").withIndex("by_created_at").filter((n) => n.gte(n.field("created_at"), i)).collect(), _ = {
      total_events: o.length,
      events_by_severity: {},
      events_by_type: {},
      high_severity_events: 0,
      recent_critical_events: []
    };
    for (let n of o) {
      let d = n.severity.toString();
      if (_.events_by_severity[d] = (_.events_by_severity[d] || 0) + 1, _.events_by_type[n.event_type] = (_.events_by_type[n.event_type] || 0) + 1, n.severity >= p.HIGH && _.high_severity_events++, n.severity === p.CRITICAL && _.recent_critical_events.length < 5) {
        let f = {
          event_type: n.event_type,
          created_at: n.created_at
        };
        n.details && (f.details = n.details), _.recent_critical_events.push(f);
      }
    }
    return _.recent_critical_events.sort((n, d) => d.created_at - n.created_at), _;
  }, "handler")
}), R = l({
  args: {
    retention_days: e.number()
    // 保持期間（日）
  },
  returns: e.object({
    deleted_count: e.number()
  }),
  handler: /* @__PURE__ */ u(async (a, t) => {
    let s = Date.now() - t.retention_days * 24 * 60 * 60 * 1e3, r = await a.db.query("securityEvents").withIndex("by_created_at").filter((o) => o.lt(o.field("created_at"), s)).collect(), i = 0;
    for (let o of r)
      await a.db.delete(o._id), i++;
    return { deleted_count: i };
  }, "handler")
}), U = l({
  args: {
    event_type: e.string(),
    severity: e.number(),
    user_id: e.optional(e.id("users")),
    target_user_id: e.optional(e.id("users")),
    details: e.optional(e.string()),
    ip_address: e.optional(e.string()),
    user_agent: e.optional(e.string())
  },
  returns: e.object({
    success: e.boolean(),
    event_id: e.optional(e.id("securityEvents"))
  }),
  handler: /* @__PURE__ */ u(async (a, t) => {
    try {
      let s = {
        event_type: t.event_type,
        severity: t.severity,
        created_at: Date.now()
      };
      return t.user_id && (s.user_id = t.user_id), t.target_user_id && (s.target_user_id = t.target_user_id), t.details && (s.details = t.details), t.ip_address && (s.ip_address = t.ip_address), t.user_agent && (s.user_agent = t.user_agent), {
        success: !0,
        event_id: await a.db.insert("securityEvents", s)
      };
    } catch (s) {
      return console.error("Failed to log internal security event:", s), {
        success: !1
      };
    }
  }, "handler")
});
export {
  T as SECURITY_EVENT_TYPES,
  p as SECURITY_SEVERITY,
  R as cleanupOldSecurityEvents,
  C as getSecurityEvents,
  A as getSecurityStats,
  U as logInternalSecurityEvent,
  w as logSecurityEvent
};
//# sourceMappingURL=securityMonitor.js.map
