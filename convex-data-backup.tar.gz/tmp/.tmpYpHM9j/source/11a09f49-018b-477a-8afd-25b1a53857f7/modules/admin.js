import {
  a as U,
  c as j
} from "./_deps/75JH2J25.js";
import "./_deps/6XQQNYIR.js";
import {
  j as e,
  n as L
} from "./_deps/3TDUHHJO.js";
import {
  a as _
} from "./_deps/RUVYHBJQ.js";

// convex/admin.ts
L();
var m = class {
  static {
    _(this, "SecurityLogger");
  }
  static logSecurityEvent(t, i, a) {
    let r = (/* @__PURE__ */ new Date()).toISOString();
    console.log(`[SECURITY] ${r} ${t}`, {
      userId: i,
      timestamp: r,
      event: t,
      details: a
    });
  }
  static logAdminAction(t, i, a, r) {
    let u = (/* @__PURE__ */ new Date()).toISOString();
    console.log(`[ADMIN_ACTION] ${u} ${t}`, {
      adminId: i,
      action: t,
      targetResource: a,
      timestamp: u,
      details: r
    });
  }
};
async function w(n) {
  let t = await n.auth.getUserIdentity();
  if (!t)
    throw m.logSecurityEvent("UNAUTHORIZED_ACCESS_ATTEMPT", "anonymous"), new Error("\u8A8D\u8A3C\u304C\u5FC5\u8981\u3067\u3059");
  let i = await n.db.query("users").withIndex("by_token", (a) => a.eq("tokenIdentifier", t.tokenIdentifier)).unique();
  if (!i)
    throw m.logSecurityEvent("USER_NOT_FOUND", t.tokenIdentifier), new Error("\u30E6\u30FC\u30B6\u30FC\u304C\u898B\u3064\u304B\u308A\u307E\u305B\u3093");
  if (!i.isActive)
    throw m.logSecurityEvent("INACTIVE_USER_ACCESS_ATTEMPT", i._id), new Error("\u30A2\u30AB\u30A6\u30F3\u30C8\u304C\u7121\u52B9\u3067\u3059");
  if (i.role !== "admin")
    throw m.logSecurityEvent("UNAUTHORIZED_ADMIN_ACCESS_ATTEMPT", i._id, {
      attemptedRole: "admin",
      actualRole: i.role
    }), new Error("\u7BA1\u7406\u8005\u6A29\u9650\u304C\u5FC5\u8981\u3067\u3059");
  return m.logSecurityEvent("ADMIN_ACCESS_GRANTED", i._id), i;
}
_(w, "validateAdminAccess");
function R(n, t) {
  let i = ["employee", "manager", "trainer", "admin"];
  if (!i.includes(n))
    throw m.logSecurityEvent("INVALID_ROLE_ASSIGNMENT_ATTEMPT", t._id, {
      requestedRole: n,
      validRoles: i
    }), new Error("\u7121\u52B9\u306A\u30ED\u30FC\u30EB\u304C\u6307\u5B9A\u3055\u308C\u307E\u3057\u305F");
  if (n === "admin" && t.role !== "admin")
    throw m.logSecurityEvent("UNAUTHORIZED_ADMIN_CREATION_ATTEMPT", t._id), new Error("\u7BA1\u7406\u8005\u306E\u4F5C\u6210\u306B\u306F\u7BA1\u7406\u8005\u6A29\u9650\u304C\u5FC5\u8981\u3067\u3059");
}
_(R, "validateRoleAssignment");
var H = U({
  args: {},
  returns: e.object({
    users: e.object({
      total_users: e.number(),
      active_users: e.number(),
      admin_count: e.number(),
      manager_count: e.number(),
      user_count: e.number(),
      latest_user_created: e.optional(e.string())
    }),
    videos: e.object({
      total_videos: e.number(),
      roleplay_videos: e.number(),
      sales_videos: e.number(),
      avg_duration: e.number()
    }),
    evaluations: e.object({
      total_evaluations: e.number(),
      avg_total_score: e.number()
    })
  }),
  handler: /* @__PURE__ */ _(async (n) => {
    let t = await w(n);
    m.logAdminAction("DASHBOARD_STATS_REQUESTED", t._id);
    try {
      let [i, a, r, u, c] = await Promise.all([
        n.db.query("users").collect(),
        n.db.query("users").withIndex("by_is_active", (s) => s.eq("isActive", !0)).collect(),
        n.db.query("users").withIndex("by_role", (s) => s.eq("role", "admin")).collect(),
        n.db.query("users").withIndex("by_role", (s) => s.eq("role", "manager")).collect(),
        n.db.query("users").withIndex("by_role", (s) => s.eq("role", "employee")).collect()
      ]), l = i.reduce(
        (s, h) => !s || h._creationTime > s._creationTime ? h : s,
        null
      ), p = 0, E = 0, g = 0, d = 0;
      try {
        let [s, h, f] = await Promise.all([
          n.db.query("videos").collect(),
          n.db.query("videos").filter((y) => y.eq(y.field("type"), "roleplay")).collect(),
          n.db.query("videos").filter((y) => y.eq(y.field("type"), "sales")).collect()
        ]);
        p = s.length, E = h.length, g = f.length, d = s.length > 0 ? s.reduce((y, D) => y + (D.duration_seconds || 0), 0) / s.length : 0;
      } catch (s) {
        console.warn("Videos table access failed, using default values:", s);
      }
      let v = 0, S = 0;
      try {
        let s = await n.db.query("evaluations").collect();
        v = s.length;
        let h = s.filter((f) => f.total_score != null && f.total_score > 0).map((f) => f.total_score);
        S = h.length > 0 ? h.reduce((f, y) => f + y, 0) / h.length : 0;
      } catch (s) {
        console.warn("Evaluations table access failed, using default values:", s);
      }
      return {
        users: {
          total_users: i.length,
          active_users: a.length,
          admin_count: r.length,
          manager_count: u.length,
          user_count: c.length,
          latest_user_created: l ? new Date(l._creationTime).toISOString() : void 0
        },
        videos: {
          total_videos: p,
          roleplay_videos: E,
          sales_videos: g,
          avg_duration: d
        },
        evaluations: {
          total_evaluations: v,
          avg_total_score: S
        }
      };
    } catch (i) {
      throw m.logSecurityEvent("DASHBOARD_STATS_ERROR", t._id, {
        error: i instanceof Error ? i.message : String(i),
        operation: "getDashboardStats"
      }), new Error("\u7D71\u8A08\u60C5\u5831\u306E\u53D6\u5F97\u306B\u5931\u6557\u3057\u307E\u3057\u305F");
    }
  }, "handler")
}), z = U({
  args: {
    limit: e.optional(e.number())
  },
  returns: e.object({
    activities: e.array(
      e.object({
        activity_type: e.string(),
        timestamp: e.string(),
        entity_id: e.string(),
        entity_name: e.string(),
        user_id: e.optional(e.string()),
        user_name: e.optional(e.string()),
        description: e.string()
      })
    )
  }),
  handler: /* @__PURE__ */ _(async (n, t) => {
    let i = await w(n);
    m.logAdminAction("DASHBOARD_ACTIVITIES_REQUESTED", i._id, void 0, {
      limit: t.limit
    });
    let a = t.limit || 20;
    try {
      return {
        activities: (await n.db.query("users").order("desc").take(a)).map((c) => ({
          activity_type: "user_registered",
          timestamp: new Date(c._creationTime).toISOString(),
          entity_id: c._id,
          entity_name: c.name,
          user_id: c._id,
          user_name: c.name,
          description: `\u65B0\u3057\u3044\u30E6\u30FC\u30B6\u30FC\u300C${c.name}\u300D\u304C\u767B\u9332\u3055\u308C\u307E\u3057\u305F`
        }))
      };
    } catch (r) {
      throw console.error("Dashboard activities calculation error:", r), new Error("\u30A2\u30AF\u30C6\u30A3\u30D3\u30C6\u30A3\u306E\u53D6\u5F97\u306B\u5931\u6557\u3057\u307E\u3057\u305F");
    }
  }, "handler")
}), Q = U({
  args: {
    search: e.optional(e.string()),
    department: e.optional(e.string()),
    role: e.optional(e.string()),
    page: e.optional(e.number()),
    limit: e.optional(e.number())
  },
  returns: e.object({
    users: e.array(
      e.object({
        id: e.string(),
        name: e.string(),
        email: e.string(),
        department: e.optional(e.string()),
        role: e.string(),
        createdAt: e.string(),
        updatedAt: e.string()
      })
    ),
    total: e.number(),
    page: e.number(),
    limit: e.number(),
    totalPages: e.number()
  }),
  handler: /* @__PURE__ */ _(async (n, t) => {
    let i = await w(n);
    m.logAdminAction("USER_LIST_REQUESTED", i._id, void 0, {
      search: t.search,
      department: t.department,
      role: t.role,
      page: t.page,
      limit: t.limit
    });
    let a = t.page || 1, r = t.limit || 20, u = (a - 1) * r;
    try {
      let l = await n.db.query("users").collect();
      t.search && (l = l.filter(
        (d) => d.name.toLowerCase().includes(t.search?.toLowerCase() || "") || d.email.toLowerCase().includes(t.search?.toLowerCase() || "")
      )), t.role && (l = l.filter((d) => d.role === t.role)), t.department && (l = l.filter((d) => d.department === t.department));
      let p = l.length;
      return {
        users: l.slice(u, u + r).map((d) => ({
          id: d._id,
          name: d.name || "",
          email: d.email,
          department: d.department || "",
          role: d.role,
          createdAt: new Date(d._creationTime).toISOString(),
          updatedAt: new Date(d._creationTime).toISOString()
          // 更新日時は作成日時と同じ
        })),
        total: p,
        page: a,
        limit: r,
        totalPages: Math.ceil(p / r)
      };
    } catch (c) {
      throw console.error("Users list calculation error:", c), new Error("\u30E6\u30FC\u30B6\u30FC\u4E00\u89A7\u306E\u53D6\u5F97\u306B\u5931\u6557\u3057\u307E\u3057\u305F");
    }
  }, "handler")
}), $ = U({
  args: { userId: e.id("users") },
  returns: e.union(
    e.object({
      user: e.object({
        _id: e.id("users"),
        name: e.string(),
        email: e.string(),
        emailVerified: e.boolean(),
        _creationTime: e.number()
      }),
      stats: e.object({
        videos_uploaded: e.number(),
        evaluations_received: e.number(),
        last_activity: e.optional(e.number())
      })
    }),
    e.null()
  ),
  handler: /* @__PURE__ */ _(async (n, t) => {
    let i = await w(n);
    m.logAdminAction("USER_DETAIL_REQUESTED", i._id, t.userId);
    let a = await n.db.get(t.userId);
    if (!a) return null;
    let r = 0, u = 0;
    try {
      r = (await n.db.query("videos").withIndex("by_user_id", (l) => l.eq("user_id", t.userId)).collect()).length;
    } catch {
    }
    try {
      u = (await n.db.query("evaluations").withIndex("by_user_id", (l) => l.eq("user_id", t.userId)).collect()).length;
    } catch {
    }
    return {
      user: {
        _id: a._id,
        name: a.name,
        email: a.email,
        emailVerified: a.emailVerified,
        _creationTime: a._creationTime
      },
      stats: {
        videos_uploaded: r,
        evaluations_received: u,
        last_activity: a.lastLoginAt
      }
    };
  }, "handler")
}), B = j({
  args: {
    userId: e.id("users"),
    name: e.optional(e.string()),
    email: e.optional(e.string()),
    department: e.optional(e.string()),
    role: e.optional(e.string()),
    isActive: e.optional(e.boolean())
  },
  returns: e.null(),
  handler: /* @__PURE__ */ _(async (n, t) => {
    let i = await w(n);
    if (t.role && R(t.role, i), m.logAdminAction("USER_UPDATE_REQUESTED", i._id, t.userId, {
      updates: {
        name: t.name,
        email: t.email,
        department: t.department,
        role: t.role,
        isActive: t.isActive
      }
    }), !await n.db.get(t.userId))
      throw new Error("\u30E6\u30FC\u30B6\u30FC\u304C\u898B\u3064\u304B\u308A\u307E\u305B\u3093");
    try {
      let r = {};
      if (t.name !== void 0 && (r.name = t.name), t.email !== void 0) {
        let u = await n.db.query("users").filter((c) => c.eq(c.field("email"), t.email)).first();
        if (u && u._id !== t.userId)
          throw new Error("\u3053\u306E\u30E1\u30FC\u30EB\u30A2\u30C9\u30EC\u30B9\u306F\u65E2\u306B\u767B\u9332\u3055\u308C\u3066\u3044\u307E\u3059");
        r.email = t.email;
      }
      return t.department !== void 0 && (r.department = t.department), t.role !== void 0 && (r.role = t.role), t.isActive !== void 0 && (r.isActive = t.isActive), await n.db.patch(t.userId, r), null;
    } catch (r) {
      throw console.error("User update error:", r), new Error(r instanceof Error ? r.message : "\u30E6\u30FC\u30B6\u30FC\u306E\u66F4\u65B0\u306B\u5931\u6557\u3057\u307E\u3057\u305F");
    }
  }, "handler")
}), W = j({
  args: {
    userId: e.id("users")
  },
  returns: e.null(),
  handler: /* @__PURE__ */ _(async (n, t) => {
    let i = await w(n);
    m.logAdminAction("USER_DELETE_REQUESTED", i._id, t.userId);
    let a = await n.db.get(t.userId);
    if (!a)
      throw new Error("\u30E6\u30FC\u30B6\u30FC\u304C\u898B\u3064\u304B\u308A\u307E\u305B\u3093");
    if (a._id === i._id)
      throw new Error("\u81EA\u5206\u81EA\u8EAB\u3092\u524A\u9664\u3059\u308B\u3053\u3068\u306F\u3067\u304D\u307E\u305B\u3093");
    try {
      return await n.db.delete(t.userId), null;
    } catch (r) {
      throw console.error("User deletion error:", r), new Error("\u30E6\u30FC\u30B6\u30FC\u306E\u524A\u9664\u306B\u5931\u6557\u3057\u307E\u3057\u305F");
    }
  }, "handler")
}), F = U({
  args: {
    limit: e.optional(e.number()),
    search: e.optional(e.string())
  },
  returns: e.object({
    users: e.array(
      e.object({
        id: e.string(),
        username: e.string(),
        email: e.string(),
        role: e.string(),
        department: e.optional(e.string()),
        created_at: e.string(),
        last_login_at: e.union(e.string(), e.null()),
        is_active: e.boolean(),
        training_stats: e.object({
          completed: e.number(),
          in_progress: e.number(),
          total: e.number(),
          completion_rate: e.number()
        }),
        performance: e.object({
          avg_score: e.number(),
          highest_score: e.number(),
          lowest_score: e.number(),
          recent_activities: e.number()
        })
      })
    ),
    total: e.number()
  }),
  handler: /* @__PURE__ */ _(async (n, t) => {
    let i = await w(n);
    m.logAdminAction("USERS_DASHBOARD_STATS_REQUESTED", i._id, void 0, {
      limit: t.limit,
      search: t.search
    });
    let a = t.limit || 100;
    try {
      let r = await n.db.query("users").order("desc").collect();
      if (t.search) {
        let l = t.search.toLowerCase();
        r = r.filter(
          (p) => p.name.toLowerCase().includes(l) || p.email.toLowerCase().includes(l) || p.department && p.department.toLowerCase().includes(l)
        );
      }
      let u = r.slice(0, a);
      return {
        users: await Promise.all(
          u.map(async (l) => {
            let p = {
              completed: 0,
              in_progress: 0,
              total: 0,
              completion_rate: 0
            };
            try {
              let g = await n.db.query("trainingProgress").withIndex("by_user_training", (s) => s.eq("user_id", l._id)).collect(), d = g.filter((s) => s.status === "completed").length, v = g.filter((s) => s.status === "in_progress").length, S = g.length;
              p = {
                completed: d,
                in_progress: v,
                total: S,
                completion_rate: S > 0 ? Math.round(d / S * 100) : 0
              };
            } catch {
            }
            let E = {
              avg_score: 0,
              highest_score: 0,
              lowest_score: 0,
              recent_activities: 0
            };
            try {
              let g = await n.db.query("evaluations").withIndex("by_user_id", (d) => d.eq("user_id", l._id)).collect();
              if (g.length > 0) {
                let d = g.filter((v) => v.total_score && v.total_score > 0).map((v) => v.total_score || 0);
                if (d.length > 0) {
                  let v = d.reduce((S, s) => S + s, 0) / d.length;
                  E = {
                    avg_score: Math.round(v * 10) / 10,
                    highest_score: Math.max(...d),
                    lowest_score: Math.min(...d),
                    recent_activities: g.length
                  };
                }
              }
            } catch {
            }
            return {
              id: l._id,
              username: l.name || "",
              email: l.email,
              role: l.role,
              department: l.department || void 0,
              created_at: new Date(l._creationTime).toISOString(),
              last_login_at: l.lastLoginAt ? new Date(l.lastLoginAt).toISOString() : null,
              is_active: l.isActive,
              training_stats: p,
              performance: E
            };
          })
        ),
        total: r.length
      };
    } catch (r) {
      throw console.error("Users dashboard stats calculation error:", r), new Error("\u30E6\u30FC\u30B6\u30FC\u30C0\u30C3\u30B7\u30E5\u30DC\u30FC\u30C9\u7D71\u8A08\u306E\u53D6\u5F97\u306B\u5931\u6557\u3057\u307E\u3057\u305F");
    }
  }, "handler")
}), Y = U({
  args: { userId: e.id("users") },
  returns: e.union(
    e.object({
      user: e.object({
        _id: e.id("users"),
        name: e.string(),
        email: e.string(),
        emailVerified: e.boolean(),
        role: e.string(),
        department: e.optional(e.string()),
        isActive: e.boolean(),
        _creationTime: e.number()
      }),
      stats: e.object({
        videos_uploaded: e.number(),
        evaluations_received: e.number(),
        last_activity: e.optional(e.number())
      })
    }),
    e.null()
  ),
  handler: /* @__PURE__ */ _(async (n, t) => {
    let i = await w(n);
    m.logAdminAction("USER_DETAIL_BY_ID_REQUESTED", i._id, t.userId);
    let a = await n.db.get(t.userId);
    if (!a) return null;
    let r = 0, u = 0;
    try {
      r = (await n.db.query("videos").withIndex("by_user_id", (l) => l.eq("user_id", t.userId)).collect()).length;
    } catch {
    }
    try {
      u = (await n.db.query("evaluations").withIndex("by_user_id", (l) => l.eq("user_id", t.userId)).collect()).length;
    } catch {
    }
    return {
      user: {
        _id: a._id,
        name: a.name,
        email: a.email,
        emailVerified: a.emailVerified,
        role: a.role,
        department: a.department,
        isActive: a.isActive,
        _creationTime: a._creationTime
      },
      stats: {
        videos_uploaded: r,
        evaluations_received: u,
        last_activity: a.lastLoginAt
      }
    };
  }, "handler")
}), Z = U({
  args: {
    startDate: e.optional(e.number()),
    endDate: e.optional(e.number()),
    includeEngagementPatterns: e.optional(e.boolean()),
    includeTypeRankings: e.optional(e.boolean()),
    includePerformanceMetrics: e.optional(e.boolean()),
    includeBottleneckAnalysis: e.optional(e.boolean()),
    includeUtilizationStats: e.optional(e.boolean()),
    includeUtilizationTrends: e.optional(e.boolean()),
    trendPeriod: e.optional(e.string()),
    dashboardView: e.optional(e.boolean()),
    includeAlerts: e.optional(e.boolean()),
    includeAdminInsights: e.optional(e.boolean()),
    useCache: e.optional(e.boolean()),
    forceRefresh: e.optional(e.boolean()),
    cacheTimeout: e.optional(e.number()),
    includeAllMetrics: e.optional(e.boolean()),
    includeDetailedMetrics: e.optional(e.boolean()),
    optimizeMemory: e.optional(e.boolean()),
    timeout: e.optional(e.number()),
    requestId: e.optional(e.string())
  },
  returns: e.object({
    overview: e.object({
      totalEvaluations: e.number(),
      completedEvaluations: e.number(),
      runningEvaluations: e.number(),
      failedEvaluations: e.number(),
      completionRate: e.number(),
      failureRate: e.optional(e.number()),
      successRate: e.optional(e.number()),
      averageScore: e.number(),
      highestScore: e.number(),
      lowestScore: e.number(),
      averageDuration: e.number(),
      totalProcessingTime: e.number(),
      totalUsers: e.optional(e.number()),
      systemHealth: e.optional(e.string())
    }),
    userActivity: e.object({
      activeUsers: e.number(),
      totalUsers: e.optional(e.number()),
      inactiveUsers: e.optional(e.number()),
      evaluationsPerUser: e.number(),
      activityLevels: e.optional(e.object({
        high: e.number(),
        medium: e.number(),
        low: e.number()
      })),
      userSuccessRates: e.optional(e.any()),
      averageUserScore: e.optional(e.number()),
      newUsersActive: e.optional(e.number()),
      recentActivityCount: e.optional(e.number()),
      engagementPatterns: e.optional(e.object({
        dailyActive: e.number(),
        weeklyActive: e.number(),
        retentionRate: e.number()
      })),
      activityFrequency: e.optional(e.object({
        high: e.number(),
        medium: e.number(),
        low: e.number()
      }))
    }),
    evaluationTypes: e.array(e.object({
      name: e.string(),
      totalCount: e.number(),
      completedCount: e.number(),
      averageScore: e.number(),
      averageDuration: e.optional(e.number()),
      completionRate: e.number()
    })),
    trends: e.optional(e.object({
      daily: e.array(e.object({
        date: e.string(),
        evaluationCount: e.number(),
        averageScore: e.number()
      }))
    })),
    typeRankings: e.optional(e.object({
      byPerformance: e.array(e.any()),
      byPopularity: e.array(e.any()),
      byCompletionRate: e.array(e.any())
    })),
    performance: e.optional(e.object({
      processingTimes: e.object({
        average: e.number(),
        median: e.number(),
        min: e.number(),
        max: e.number()
      }),
      resourceUsage: e.object({
        averageCpu: e.number(),
        averageMemory: e.number(),
        totalAiTokens: e.number(),
        totalAiCost: e.number()
      }),
      qualityMetrics: e.object({
        averageAccuracy: e.number(),
        averageConfidence: e.number(),
        averageConsistency: e.number()
      }),
      throughput: e.object({
        averagePerHour: e.number(),
        totalCompletedToday: e.number()
      }),
      bottlenecks: e.optional(e.object({
        mostCommon: e.any(),
        cpuIntensive: e.object({ count: e.number() }),
        memoryIntensive: e.object({ count: e.number() }),
        aiCostIntensive: e.object({ count: e.number() })
      })),
      optimizationRecommendations: e.optional(e.array(e.any())),
      costAnalysis: e.optional(e.object({
        averageCostPerEvaluation: e.number(),
        highCostEvaluations: e.number()
      })),
      logSummary: e.optional(e.object({
        totalLogEntries: e.number(),
        sampleLogs: e.array(e.any())
      }))
    })),
    utilization: e.optional(e.object({
      hourlyDistribution: e.array(e.object({
        hour: e.number(),
        count: e.number()
      })),
      peakHours: e.object({
        morning: e.array(e.object({
          hour: e.number(),
          count: e.number()
        }))
      }),
      patterns: e.object({
        peakUtilization: e.number(),
        averageUtilization: e.number(),
        offPeakUtilization: e.number()
      }),
      capacityPlanning: e.object({
        currentCapacityUsage: e.number(),
        recommendedCapacity: e.number()
      }),
      trends: e.optional(e.object({
        daily: e.array(e.object({
          date: e.string(),
          evaluationCount: e.number(),
          averageScore: e.number()
        })),
        efficiency: e.object({
          improving: e.boolean()
        })
      })),
      forecasting: e.optional(e.object({
        nextWeekPrediction: e.number(),
        growthRate: e.number()
      }))
    })),
    dashboard: e.optional(e.object({
      keyMetrics: e.object({
        totalEvaluations: e.number(),
        activeEvaluations: e.number(),
        failedEvaluations: e.number(),
        systemHealth: e.string()
      }),
      departmentStats: e.array(e.object({
        name: e.string(),
        totalEvaluations: e.number(),
        averageScore: e.number()
      })),
      alerts: e.array(e.object({
        type: e.string(),
        message: e.optional(e.string())
      })),
      onboarding: e.object({
        newUsersThisWeek: e.number(),
        firstEvaluationCompletionRate: e.number()
      }),
      systemStatus: e.object({
        overallHealth: e.string(),
        componentStatus: e.any()
      })
    })),
    insights: e.optional(e.object({
      performanceWarnings: e.object({
        lowPerformingUsers: e.number(),
        highRetryUsers: e.number()
      }),
      engagement: e.object({
        inactiveUsers: e.number(),
        superUsers: e.number()
      }),
      technicalIssues: e.object({
        networkProblems: e.number(),
        systemFailures: e.number()
      }),
      recommendedActions: e.array(e.object({
        type: e.string(),
        priority: e.string(),
        description: e.string()
      })),
      successPatterns: e.object({
        bestPractices: e.any(),
        improvementTrends: e.any()
      })
    })),
    metadata: e.object({
      lastUpdated: e.number(),
      dataFreshness: e.optional(e.string()),
      cached: e.optional(e.boolean()),
      cacheAge: e.optional(e.number()),
      performanceStats: e.optional(e.object({
        executionTime: e.number(),
        dataProcessed: e.number()
      })),
      hasPartialData: e.optional(e.boolean()),
      timedOut: e.optional(e.boolean()),
      timeoutReason: e.optional(e.string()),
      partialData: e.optional(e.boolean()),
      requestId: e.optional(e.string()),
      memoryOptimization: e.optional(e.object({
        enabled: e.boolean(),
        dataSampled: e.boolean(),
        compressionRatio: e.number()
      }))
    })
  }),
  handler: /* @__PURE__ */ _(async (n, t) => {
    let i = await w(n);
    if (m.logAdminAction("SYSTEM_EVALUATION_STATS_REQUESTED", i._id, void 0, t), t.startDate && t.endDate && t.startDate > t.endDate)
      throw new Error("\u4E0D\u6B63\u306A\u65E5\u4ED8\u7BC4\u56F2\u3067\u3059\uFF1A\u958B\u59CB\u65E5\u306F\u7D42\u4E86\u65E5\u3088\u308A\u524D\u3067\u3042\u308B\u5FC5\u8981\u304C\u3042\u308A\u307E\u3059");
    let a = Date.now();
    try {
      let r = await n.db.query("evaluations").collect(), u = r;
      (t.startDate || t.endDate) && (u = r.filter((o) => {
        let b = o._creationTime;
        return !(t.startDate && b < t.startDate || t.endDate && b > t.endDate);
      }));
      let c = u.length, l = u.filter((o) => o.status === "completed").length, p = u.filter((o) => o.status === "processing").length, E = u.filter((o) => o.status === "failed").length, g = c > 0 ? Math.round(l / c * 100) : 0, d = c > 0 ? Math.round(E / c * 100) : 0, v = g, s = u.filter((o) => o.status === "completed" && o.total_score != null).map((o) => o.total_score || 0), h = s.length > 0 ? s.reduce((o, b) => o + b, 0) / s.length : 0, f = s.length > 0 ? Math.max(...s) : 0, y = s.length > 0 ? Math.min(...s) : 0, D = u.filter((o) => o.processing_duration_ms != null).map((o) => o.processing_duration_ms || 0), C = D.length > 0 ? D.reduce((o, b) => o + b, 0) / D.length : 0, q = D.reduce((o, b) => o + b, 0), T = new Set(u.map((o) => o.user_id)).size, P = T > 0 ? c / T : 0, I = /* @__PURE__ */ new Map();
      u.forEach((o) => {
        let b = o.video_type || "\u4E0D\u660E";
        I.has(b) || I.set(b, {
          name: b,
          totalCount: 0,
          completedCount: 0,
          scores: [],
          durations: []
        });
        let A = I.get(b);
        A.totalCount++, o.status === "completed" && (A.completedCount++, o.total_score != null && A.scores.push(o.total_score), o.processing_duration_ms != null && A.durations.push(o.processing_duration_ms));
      });
      let M = Array.from(I.values()).map((o) => ({
        name: o.name,
        totalCount: o.totalCount,
        completedCount: o.completedCount,
        averageScore: o.scores.length > 0 ? o.scores.reduce((b, A) => b + A, 0) / o.scores.length : 0,
        averageDuration: o.durations.length > 0 ? o.durations.reduce((b, A) => b + A, 0) / o.durations.length : void 0,
        completionRate: o.totalCount > 0 ? Math.round(o.completedCount / o.totalCount * 100) : 0
      })), O = Date.now() - a;
      return {
        overview: {
          totalEvaluations: c,
          completedEvaluations: l,
          runningEvaluations: p,
          failedEvaluations: E,
          completionRate: g,
          failureRate: d,
          successRate: v,
          averageScore: Math.round(h * 100) / 100,
          highestScore: f,
          lowestScore: y,
          averageDuration: Math.round(C),
          totalProcessingTime: q,
          totalUsers: T,
          systemHealth: "healthy"
        },
        userActivity: {
          activeUsers: T,
          totalUsers: T,
          inactiveUsers: 0,
          evaluationsPerUser: Math.round(P * 100) / 100,
          activityLevels: {
            high: 0,
            medium: 0,
            low: T
          },
          averageUserScore: h,
          newUsersActive: 0,
          recentActivityCount: c
        },
        evaluationTypes: M,
        trends: t.startDate && t.endDate ? {
          daily: Array.from({ length: 7 }, (o, b) => ({
            date: new Date(Date.now() - b * 864e5).toISOString().split("T")[0],
            evaluationCount: Math.floor(c / 7),
            averageScore: h
          }))
        } : void 0,
        metadata: {
          lastUpdated: Date.now(),
          dataFreshness: "real-time",
          cached: t.useCache || !1,
          cacheAge: 0,
          performanceStats: {
            executionTime: O,
            dataProcessed: c
          },
          hasPartialData: !1,
          requestId: t.requestId
        }
      };
    } catch (r) {
      throw console.error("System evaluation stats error:", r), new Error("\u30B7\u30B9\u30C6\u30E0\u7D71\u8A08\u306E\u53D6\u5F97\u306B\u5931\u6557\u3057\u307E\u3057\u305F");
    }
  }, "handler")
}), G = j({
  args: {
    name: e.string(),
    email: e.string(),
    role: e.string(),
    department: e.optional(e.string()),
    password: e.optional(e.string())
    // 実際のパスワード処理は認証システムによる
  },
  returns: e.object({
    success: e.boolean(),
    userId: e.optional(e.id("users")),
    message: e.string()
  }),
  handler: /* @__PURE__ */ _(async (n, t) => {
    let i = await w(n);
    R(t.role, i), m.logAdminAction("USER_CREATE_REQUESTED", i._id, void 0, {
      targetName: t.name,
      targetEmail: t.email,
      targetRole: t.role,
      targetDepartment: t.department
    });
    try {
      if (await n.db.query("users").filter((c) => c.eq(c.field("email"), t.email)).first())
        return {
          success: !1,
          message: "\u3053\u306E\u30E1\u30FC\u30EB\u30A2\u30C9\u30EC\u30B9\u306F\u65E2\u306B\u767B\u9332\u3055\u308C\u3066\u3044\u307E\u3059"
        };
      let r = {
        clerkUserId: `temp_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
        // 一時的なID（Clerkで後で更新される）
        tokenIdentifier: `temp_token_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
        // 一時的なトークン（認証システムで設定される）
        email: t.email,
        emailVerified: !1,
        name: t.name,
        role: t.role,
        isActive: !0,
        joinDate: Date.now()
      };
      return t.department && (r.department = t.department), {
        success: !0,
        userId: await n.db.insert("users", r),
        message: "\u30E6\u30FC\u30B6\u30FC\u304C\u6B63\u5E38\u306B\u4F5C\u6210\u3055\u308C\u307E\u3057\u305F"
      };
    } catch (a) {
      return console.error("User creation error:", a), {
        success: !1,
        message: a instanceof Error ? a.message : "\u30E6\u30FC\u30B6\u30FC\u306E\u4F5C\u6210\u306B\u5931\u6557\u3057\u307E\u3057\u305F"
      };
    }
  }, "handler")
});
export {
  G as createUser,
  W as deleteUser,
  z as getDashboardActivities,
  H as getDashboardStats,
  Z as getSystemEvaluationStats,
  $ as getUserDetail,
  Y as getUserDetailById,
  Q as getUsers,
  F as getUsersDashboardStats,
  B as updateUser
};
//# sourceMappingURL=admin.js.map
