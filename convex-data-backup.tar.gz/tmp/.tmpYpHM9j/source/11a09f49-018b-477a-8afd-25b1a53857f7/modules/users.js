import {
  a as m,
  b as c,
  c as g,
  d as I
} from "./_deps/75JH2J25.js";
import "./_deps/6XQQNYIR.js";
import {
  j as e,
  n as b
} from "./_deps/3TDUHHJO.js";
import {
  a as l
} from "./_deps/RUVYHBJQ.js";

// convex/users.ts
b();
var N = g({
  args: {},
  returns: e.id("users"),
  handler: /* @__PURE__ */ l(async (n) => {
    let t = await n.auth.getUserIdentity();
    if (!t)
      throw new Error("\u8A8D\u8A3C\u60C5\u5831\u304C\u898B\u3064\u304B\u308A\u307E\u305B\u3093\u3002\u30ED\u30B0\u30A4\u30F3\u3057\u3066\u304F\u3060\u3055\u3044\u3002");
    let r = await n.db.query("users").withIndex("by_token", (a) => a.eq("tokenIdentifier", t.tokenIdentifier)).unique();
    return r !== null ? ((r.name !== t.name || r.email !== t.email) && await n.db.patch(r._id, {
      name: t.name || r.name,
      email: t.email || r.email
    }), r._id) : await n.db.insert("users", {
      clerkUserId: t.subject || t.tokenIdentifier,
      // ClerkのユーザーID
      tokenIdentifier: t.tokenIdentifier,
      email: t.email || "",
      emailVerified: t.emailVerified || !1,
      name: t.name || "",
      firstName: t.givenName,
      lastName: t.familyName,
      imageUrl: t.pictureUrl,
      role: "employee",
      // デフォルトロール
      isActive: !0,
      joinDate: Date.now()
    });
  }, "handler")
}), j = m({
  args: {},
  returns: e.union(
    e.object({
      _id: e.id("users"),
      _creationTime: e.number(),
      name: e.string(),
      email: e.string(),
      tokenIdentifier: e.string(),
      clerkUserId: e.string(),
      emailVerified: e.boolean(),
      firstName: e.optional(e.string()),
      lastName: e.optional(e.string()),
      imageUrl: e.optional(e.string()),
      role: e.string(),
      isActive: e.boolean(),
      joinDate: e.number(),
      // 追加フィールド
      employeeId: e.optional(e.string()),
      department: e.optional(e.string()),
      position: e.optional(e.string()),
      lastLoginAt: e.optional(e.number())
    }),
    e.null()
  ),
  handler: /* @__PURE__ */ l(async (n) => {
    let t = await n.auth.getUserIdentity();
    return t ? await n.db.query("users").withIndex("by_token", (a) => a.eq("tokenIdentifier", t.tokenIdentifier)).unique() : null;
  }, "handler")
}), E = m({
  args: {
    search: e.optional(e.string()),
    department: e.optional(e.string()),
    role: e.optional(e.string()),
    page: e.optional(e.number()),
    limit: e.optional(e.number())
  },
  returns: e.object({
    users: e.array(
      e.object({
        _id: e.id("users"),
        tokenIdentifier: e.string(),
        name: e.string(),
        email: e.string(),
        role: e.optional(e.string()),
        department: e.optional(e.string()),
        managerId: e.optional(e.id("users")),
        managerName: e.optional(e.string()),
        _creationTime: e.number()
      })
    ),
    total: e.number(),
    page: e.number(),
    limit: e.number(),
    totalPages: e.number()
  }),
  handler: /* @__PURE__ */ l(async (n, t) => {
    let r = await n.auth.getUserIdentity();
    if (!r)
      throw new Error("\u8A8D\u8A3C\u304C\u5FC5\u8981\u3067\u3059");
    if (!await n.db.query("users").withIndex("by_token", (s) => s.eq("tokenIdentifier", r.tokenIdentifier)).unique())
      throw new Error("\u30E6\u30FC\u30B6\u30FC\u304C\u898B\u3064\u304B\u308A\u307E\u305B\u3093");
    let i = t.page || 1, o = t.limit || 20, d = (i - 1) * o, f = await n.db.query("users").collect();
    if (t.search) {
      let s = t.search.toLowerCase();
      f = f.filter(
        (u) => u.name.toLowerCase().includes(s) || u.email.toLowerCase().includes(s)
      );
    }
    let p = f.length, w = f.slice(d, d + o);
    return {
      users: await Promise.all(
        w.map(async (s) => {
          let u;
          return s.managerId && (u = (await n.db.get(s.managerId))?.name), {
            _id: s._id,
            tokenIdentifier: s.tokenIdentifier,
            name: s.name,
            email: s.email,
            role: s.role,
            department: s.department,
            managerId: s.managerId,
            managerName: u,
            _creationTime: s._creationTime
          };
        })
      ),
      total: p,
      page: i,
      limit: o,
      totalPages: Math.ceil(p / o)
    };
  }, "handler")
}), A = m({
  args: {
    userId: e.id("users")
  },
  returns: e.union(
    e.object({
      _id: e.id("users"),
      tokenIdentifier: e.string(),
      name: e.string(),
      email: e.string(),
      role: e.optional(e.string()),
      department: e.optional(e.string()),
      _creationTime: e.number()
    }),
    e.null()
  ),
  handler: /* @__PURE__ */ l(async (n, t) => {
    let r = await n.auth.getUserIdentity();
    if (!r)
      throw new Error("\u8A8D\u8A3C\u304C\u5FC5\u8981\u3067\u3059");
    let a = await n.db.query("users").withIndex("by_token", (o) => o.eq("tokenIdentifier", r.tokenIdentifier)).unique();
    if (!a)
      throw new Error("\u30E6\u30FC\u30B6\u30FC\u304C\u898B\u3064\u304B\u308A\u307E\u305B\u3093");
    let i = await n.db.get(t.userId);
    return i ? (a._id, i._id, {
      _id: i._id,
      tokenIdentifier: i.tokenIdentifier,
      name: i.name,
      email: i.email,
      role: i.role,
      department: i.department,
      _creationTime: i._creationTime
    }) : null;
  }, "handler")
}), D = g({
  args: {
    userId: e.id("users"),
    name: e.optional(e.string()),
    email: e.optional(e.string()),
    role: e.optional(e.string()),
    department: e.optional(e.string()),
    managerId: e.optional(e.id("users"))
  },
  returns: e.null(),
  handler: /* @__PURE__ */ l(async (n, t) => {
    let r = await n.auth.getUserIdentity();
    if (!r)
      throw new Error("\u8A8D\u8A3C\u304C\u5FC5\u8981\u3067\u3059");
    if (!await n.db.query("users").withIndex("by_token", (d) => d.eq("tokenIdentifier", r.tokenIdentifier)).unique())
      throw new Error("\u30E6\u30FC\u30B6\u30FC\u304C\u898B\u3064\u304B\u308A\u307E\u305B\u3093");
    if (!await n.db.get(t.userId))
      throw new Error("\u66F4\u65B0\u5BFE\u8C61\u306E\u30E6\u30FC\u30B6\u30FC\u304C\u898B\u3064\u304B\u308A\u307E\u305B\u3093");
    if (t.managerId) {
      if (!await n.db.get(t.managerId))
        throw new Error("\u6307\u5B9A\u3055\u308C\u305F\u4E0A\u9577\u304C\u898B\u3064\u304B\u308A\u307E\u305B\u3093");
      if (t.managerId === t.userId)
        throw new Error("\u81EA\u5206\u81EA\u8EAB\u3092\u4E0A\u9577\u306B\u8A2D\u5B9A\u3059\u308B\u3053\u3068\u306F\u3067\u304D\u307E\u305B\u3093");
    }
    let o = {};
    return t.name !== void 0 && (o.name = t.name), t.email !== void 0 && (o.email = t.email), t.role !== void 0 && (o.role = t.role), t.department !== void 0 && (o.department = t.department), t.managerId !== void 0 && (o.managerId = t.managerId), Object.keys(o).length > 0 && await n.db.patch(t.userId, o), null;
  }, "handler")
}), T = g({
  args: {},
  returns: e.null(),
  handler: /* @__PURE__ */ l(async (n) => {
    let t = await n.auth.getUserIdentity();
    if (!t)
      throw new Error("\u8A8D\u8A3C\u304C\u5FC5\u8981\u3067\u3059");
    let r = await n.db.query("users").withIndex("by_token", (a) => a.eq("tokenIdentifier", t.tokenIdentifier)).unique();
    if (!r)
      throw new Error("\u30E6\u30FC\u30B6\u30FC\u304C\u898B\u3064\u304B\u308A\u307E\u305B\u3093");
    return await n.db.patch(r._id, {
      role: "admin"
    }), null;
  }, "handler")
}), v = m({
  args: {},
  returns: e.union(
    e.object({
      _id: e.id("users"),
      _creationTime: e.number(),
      name: e.string(),
      email: e.string(),
      tokenIdentifier: e.string(),
      clerkUserId: e.string(),
      emailVerified: e.boolean(),
      firstName: e.optional(e.string()),
      lastName: e.optional(e.string()),
      imageUrl: e.optional(e.string()),
      role: e.string(),
      isActive: e.boolean(),
      joinDate: e.number(),
      // 追加フィールド
      employeeId: e.optional(e.string()),
      department: e.optional(e.string()),
      position: e.optional(e.string()),
      lastLoginAt: e.optional(e.number())
    }),
    e.null()
  ),
  handler: /* @__PURE__ */ l(async (n) => {
    let t = await n.auth.getUserIdentity();
    return t ? await n.db.query("users").withIndex("by_token", (a) => a.eq("tokenIdentifier", t.tokenIdentifier)).unique() : null;
  }, "handler")
}), V = m({
  args: {
    email: e.string()
  },
  returns: e.union(
    e.object({
      _id: e.id("users"),
      _creationTime: e.number(),
      name: e.string(),
      email: e.string(),
      tokenIdentifier: e.string(),
      clerkUserId: e.string(),
      emailVerified: e.boolean(),
      firstName: e.optional(e.string()),
      lastName: e.optional(e.string()),
      imageUrl: e.optional(e.string()),
      role: e.string(),
      isActive: e.boolean(),
      joinDate: e.number(),
      // 追加フィールド
      employeeId: e.optional(e.string()),
      department: e.optional(e.string()),
      position: e.optional(e.string()),
      lastLoginAt: e.optional(e.number())
    }),
    e.null()
  ),
  handler: /* @__PURE__ */ l(async (n, t) => t.email ? await n.db.query("users").filter((a) => a.eq(a.field("email"), t.email)).first() : null, "handler")
}), x = c({
  args: {
    clerkUserId: e.string()
  },
  returns: e.union(
    e.object({
      _id: e.id("users"),
      clerkUserId: e.string(),
      email: e.string(),
      name: e.string(),
      role: e.string()
    }),
    e.null()
  ),
  handler: /* @__PURE__ */ l(async (n, t) => {
    let r = await n.db.query("users").withIndex("by_clerk_user_id", (a) => a.eq("clerkUserId", t.clerkUserId)).first();
    return r ? {
      _id: r._id,
      clerkUserId: r.clerkUserId,
      email: r.email,
      name: r.name,
      role: r.role
    } : null;
  }, "handler")
}), C = c({
  args: {
    tokenIdentifier: e.string()
  },
  returns: e.union(
    e.object({
      _id: e.id("users"),
      clerkUserId: e.string(),
      tokenIdentifier: e.string(),
      email: e.string(),
      name: e.string(),
      role: e.string()
    }),
    e.null()
  ),
  handler: /* @__PURE__ */ l(async (n, t) => {
    let r = await n.db.query("users").withIndex("by_token", (a) => a.eq("tokenIdentifier", t.tokenIdentifier)).first();
    return r ? {
      _id: r._id,
      clerkUserId: r.clerkUserId,
      tokenIdentifier: r.tokenIdentifier,
      email: r.email,
      name: r.name,
      role: r.role
    } : null;
  }, "handler")
}), M = I({
  args: {
    clerkUserId: e.string(),
    tokenIdentifier: e.string(),
    email: e.string(),
    name: e.string(),
    firstName: e.optional(e.string()),
    lastName: e.optional(e.string()),
    role: e.string(),
    department: e.optional(e.string()),
    emailVerified: e.boolean(),
    imageUrl: e.optional(e.string())
  },
  returns: e.id("users"),
  handler: /* @__PURE__ */ l(async (n, t) => {
    if (await n.db.query("users").filter((i) => i.eq(i.field("email"), t.email)).first())
      throw new Error("\u3053\u306E\u30E1\u30FC\u30EB\u30A2\u30C9\u30EC\u30B9\u306F\u65E2\u306B\u767B\u9332\u3055\u308C\u3066\u3044\u307E\u3059");
    return await n.db.insert("users", {
      clerkUserId: t.clerkUserId,
      tokenIdentifier: t.tokenIdentifier,
      email: t.email,
      emailVerified: t.emailVerified,
      name: t.name,
      firstName: t.firstName,
      lastName: t.lastName,
      imageUrl: t.imageUrl,
      role: t.role,
      isActive: !0,
      department: t.department,
      joinDate: Date.now()
    });
  }, "handler")
}), L = g({
  args: {
    email: e.string(),
    name: e.string(),
    role: e.optional(e.string()),
    department: e.optional(e.string()),
    managerId: e.optional(e.id("users"))
  },
  returns: e.id("users"),
  handler: /* @__PURE__ */ l(async (n, t) => {
    if (await n.db.query("users").filter((d) => d.eq(d.field("email"), t.email)).first())
      throw new Error("\u3053\u306E\u30E1\u30FC\u30EB\u30A2\u30C9\u30EC\u30B9\u306F\u65E2\u306B\u767B\u9332\u3055\u308C\u3066\u3044\u307E\u3059");
    if (t.managerId && !await n.db.get(t.managerId))
      throw new Error("\u6307\u5B9A\u3055\u308C\u305F\u4E0A\u9577\u304C\u898B\u3064\u304B\u308A\u307E\u305B\u3093");
    let a = `test-token-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`, i = `test-clerk-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
    return await n.db.insert("users", {
      clerkUserId: i,
      tokenIdentifier: a,
      email: t.email,
      emailVerified: !0,
      name: t.name,
      firstName: void 0,
      lastName: void 0,
      imageUrl: void 0,
      role: t.role || "employee",
      isActive: !0,
      department: t.department,
      managerId: t.managerId,
      joinDate: Date.now()
    });
  }, "handler")
}), B = m({
  args: {},
  returns: e.array(
    e.object({
      _id: e.id("users"),
      name: e.string(),
      email: e.string(),
      department: e.optional(e.string()),
      position: e.optional(e.string())
    })
  ),
  handler: /* @__PURE__ */ l(async (n) => {
    let t = await n.auth.getUserIdentity();
    if (!t)
      throw new Error("\u8A8D\u8A3C\u304C\u5FC5\u8981\u3067\u3059");
    if (!await n.db.query("users").withIndex("by_token", (i) => i.eq("tokenIdentifier", t.tokenIdentifier)).unique())
      throw new Error("\u30E6\u30FC\u30B6\u30FC\u304C\u898B\u3064\u304B\u308A\u307E\u305B\u3093");
    return (await n.db.query("users").withIndex("by_is_active", (i) => i.eq("isActive", !0)).collect()).map((i) => ({
      _id: i._id,
      name: i.name,
      email: i.email,
      department: i.department,
      position: i.position
    }));
  }, "handler")
});
export {
  M as createConvexUser,
  L as createUser,
  j as current,
  V as getBetterAuthUser,
  A as getById,
  v as getCurrentUser,
  x as getUserByClerkId,
  C as getUserByToken,
  E as list,
  B as listForManagerSelection,
  T as makeCurrentUserAdmin,
  N as store,
  D as update
};
//# sourceMappingURL=users.js.map
