import {
  a as _,
  b as s,
  e as w
} from "./_deps/IVQGLTSC.js";
import {
  a as y,
  b as h,
  d,
  e as g
} from "./_deps/75JH2J25.js";
import "./_deps/6XQQNYIR.js";
import {
  j as e,
  n as I
} from "./_deps/3TDUHHJO.js";
import {
  a as n
} from "./_deps/RUVYHBJQ.js";

// convex/uploads.ts
I();
w();
var b = {
  video: 10 * 1024 * 1024 * 1024,
  // 10GB
  training: 50 * 1024 * 1024 * 1024,
  // 50GB
  thumbnail: 5 * 1024 * 1024,
  // 5MB
  course_thumbnail: 5 * 1024 * 1024,
  // 5MB
  module_content: 1 * 1024 * 1024 * 1024,
  // 1GB
  roleplay_material: 1 * 1024 * 1024 * 1024
  // 1GB
}, T = [
  // 動画形式
  "video/mp4",
  "video/quicktime",
  "video/x-msvideo",
  "video/webm",
  "video/x-ms-wmv",
  "video/mov",
  "video/avi",
  "video/mkv",
  // 音声形式
  "audio/mpeg",
  "audio/mp3",
  "audio/wav",
  "audio/wave",
  "audio/ogg",
  "audio/aac",
  "audio/x-m4a",
  "audio/m4a",
  "audio/mp4",
  "audio/flac",
  "audio/x-wav",
  "audio/vnd.wave"
], k = g({
  args: {
    filename: e.string(),
    contentType: e.string(),
    size: e.number(),
    title: e.optional(e.string()),
    description: e.optional(e.string()),
    type: e.optional(e.string())
  },
  returns: e.object({
    fileUploadId: e.id("fileUploads"),
    preparationToken: e.string(),
    uploadUrl: e.optional(e.string()),
    gcpFilePath: e.string(),
    isMultipart: e.boolean(),
    uploadId: e.optional(e.string())
  }),
  handler: /* @__PURE__ */ n(async (r, t) => {
    let a = await r.auth.getUserIdentity();
    if (!a)
      throw new Error("\u8A8D\u8A3C\u304C\u5FC5\u8981\u3067\u3059");
    if (!T.includes(t.contentType))
      throw new Error(`\u8A31\u53EF\u3055\u308C\u3066\u3044\u306A\u3044\u30D5\u30A1\u30A4\u30EB\u5F62\u5F0F\u3067\u3059: ${t.contentType}`);
    if (t.size > b.video)
      throw new Error("\u30D5\u30A1\u30A4\u30EB\u30B5\u30A4\u30BA\u304C\u5927\u304D\u3059\u304E\u307E\u3059\uFF08\u6700\u592710GB\uFF09");
    let i = await r.runMutation(s.uploads.createFileUploadRecord, {
      userEmail: a.email || "",
      filename: t.filename,
      contentType: t.contentType,
      size: t.size
    }), o = await r.runAction(_.uploads.generateVideoUploadUrl, {
      fileUploadId: i.fileUploadId,
      preparationToken: i.preparationToken
    });
    return {
      fileUploadId: i.fileUploadId,
      preparationToken: i.preparationToken,
      uploadUrl: o.uploadUrl,
      gcpFilePath: o.gcpFilePath,
      isMultipart: o.isMultipart,
      uploadId: o.uploadId
    };
  }, "handler")
}), F = g({
  args: {
    fileUploadId: e.id("fileUploads"),
    preparationToken: e.string()
  },
  returns: e.object({
    uploadUrl: e.optional(e.string()),
    gcpFilePath: e.string(),
    fileUploadId: e.id("fileUploads"),
    isMultipart: e.boolean(),
    uploadId: e.optional(e.string()),
    // マルチパート用
    parts: e.optional(
      e.array(
        e.object({
          partNumber: e.number(),
          uploadUrl: e.string(),
          startByte: e.number(),
          endByte: e.number()
        })
      )
    ),
    partSize: e.optional(e.number()),
    totalParts: e.optional(e.number())
  }),
  handler: /* @__PURE__ */ n(async (r, t) => {
    let a = await r.auth.getUserIdentity();
    if (!a)
      throw new Error("\u8A8D\u8A3C\u304C\u5FC5\u8981\u3067\u3059");
    try {
      let i = await r.runQuery(s.uploads.validateUploadPreparation, {
        fileUploadId: t.fileUploadId,
        preparationToken: t.preparationToken,
        userEmail: a.email || ""
      });
      if (!i)
        throw new Error("\u7121\u52B9\u306A\u30A2\u30C3\u30D7\u30ED\u30FC\u30C9\u6E96\u5099\u60C5\u5831\u3067\u3059");
      let o = 100 * 1024 * 1024, l = i.file_size >= o, p, m, c = !1, f;
      if (l)
        throw new Error(
          "\u30DE\u30EB\u30C1\u30D1\u30FC\u30C8\u30A2\u30C3\u30D7\u30ED\u30FC\u30C9\u6A5F\u80FD\u306F\u73FE\u5728\u7121\u52B9\u3067\u3059\u3002\u30D5\u30A1\u30A4\u30EB\u30B5\u30A4\u30BA\u3092100MB\u4EE5\u4E0B\u306B\u3057\u3066\u304F\u3060\u3055\u3044\u3002"
        );
      {
        let U = await r.runAction(_.gcsActions.generateGCPUploadUrl, {
          filename: i.original_filename,
          contentType: i.content_type,
          uploadType: "video",
          fileSize: i.file_size
        });
        p = U.uploadUrl, m = U.gcpFilePath, c = U.isMultipart, f = void 0;
      }
      await r.runMutation(s.uploads.commitUploadPreparation, {
        fileUploadId: t.fileUploadId,
        gcpFilePath: m,
        uploadUrl: p || "",
        isMultipart: c || !1,
        uploadId: f
      });
      let u = {
        gcpFilePath: m,
        fileUploadId: t.fileUploadId,
        isMultipart: c || !1
      };
      return p !== void 0 && (u.uploadUrl = p), f !== void 0 && (u.uploadId = f), c && (u.parts = void 0, u.partSize = void 0, u.totalParts = void 0), u;
    } catch (i) {
      throw await r.runMutation(s.uploads.rollbackUploadPreparation, {
        fileUploadId: t.fileUploadId,
        errorMessage: i instanceof Error ? i.message : "\u4E0D\u660E\u306A\u30A8\u30E9\u30FC"
      }), i;
    }
  }, "handler")
}), z = g({
  args: {
    fileUploadId: e.id("fileUploads"),
    title: e.optional(e.string()),
    description: e.optional(e.string()),
    type: e.optional(e.string())
  },
  returns: e.object({
    videoId: e.id("videos"),
    fileUploadId: e.id("fileUploads")
  }),
  handler: /* @__PURE__ */ n(async (r, t) => {
    let a = await r.auth.getUserIdentity();
    if (!a)
      throw new Error("\u8A8D\u8A3C\u304C\u5FC5\u8981\u3067\u3059");
    try {
      let i = await r.runQuery(s.uploads.getVideoUploadInfo, {
        fileUploadId: t.fileUploadId,
        userEmail: a.email || ""
      });
      if (!i)
        throw new Error("\u30D5\u30A1\u30A4\u30EB\u30A2\u30C3\u30D7\u30ED\u30FC\u30C9\u60C5\u5831\u304C\u898B\u3064\u304B\u3089\u306A\u3044\u304B\u3001\u30A2\u30AF\u30BB\u30B9\u6A29\u9650\u304C\u3042\u308A\u307E\u305B\u3093");
      if (i.fileUpload.status === "failed")
        throw new Error("\u5931\u6557\u3057\u305F\u30A2\u30C3\u30D7\u30ED\u30FC\u30C9\u306F\u5B8C\u4E86\u51E6\u7406\u3067\u304D\u307E\u305B\u3093");
      if (i.fileUpload.status === "completed")
        throw new Error("\u3053\u306E\u30D5\u30A1\u30A4\u30EB\u306F\u65E2\u306B\u51E6\u7406\u6E08\u307F\u3067\u3059");
      if (i.fileUpload.status === "preparing")
        throw new Error("\u30A2\u30C3\u30D7\u30ED\u30FC\u30C9\u306E\u6E96\u5099\u304C\u5B8C\u4E86\u3057\u3066\u3044\u307E\u305B\u3093");
      if (!i.fileUpload.gcp_file_path)
        throw new Error(
          "\u30D5\u30A1\u30A4\u30EB\u30D1\u30B9\u304C\u898B\u3064\u304B\u308A\u307E\u305B\u3093\u3002\u30A2\u30C3\u30D7\u30ED\u30FC\u30C9\u304C\u6B63\u5E38\u306B\u5B8C\u4E86\u3057\u3066\u3044\u306A\u3044\u53EF\u80FD\u6027\u304C\u3042\u308A\u307E\u3059"
        );
      await r.runMutation(s.uploads.updateUploadProgress, {
        fileUploadId: t.fileUploadId,
        stage: "processing",
        progress: 80
      });
      let { downloadUrl: o } = await r.runAction(
        _.gcsActions.generateGCPDownloadUrl,
        {
          gcpFilePath: i.fileUpload.gcp_file_path,
          expirationMinutes: 7 * 24 * 60
          // 7日間有効
        }
      );
      return {
        videoId: await r.runMutation(s.uploads.createVideoRecord, {
          fileUploadId: t.fileUploadId,
          legacyUserId: i.userMapping.legacy_user_id,
          unifiedUserId: i.user._id,
          title: t.title || i.fileUpload.original_filename,
          description: t.description,
          type: t.type,
          fileUrl: o
        }),
        fileUploadId: t.fileUploadId
      };
    } catch (i) {
      throw await r.runMutation(s.uploads.markUploadAsFailed, {
        fileUploadId: t.fileUploadId,
        errorMessage: i instanceof Error ? i.message : "\u52D5\u753B\u5B8C\u4E86\u51E6\u7406\u4E2D\u306B\u30A8\u30E9\u30FC\u304C\u767A\u751F\u3057\u307E\u3057\u305F"
      }), i;
    }
  }, "handler")
}), D = d({
  args: {
    userEmail: e.string(),
    filename: e.string(),
    contentType: e.string(),
    size: e.number()
  },
  returns: e.object({
    fileUploadId: e.id("fileUploads"),
    preparationToken: e.string()
  }),
  handler: /* @__PURE__ */ n(async (r, t) => {
    let a = await r.db.query("users").withIndex("by_email", (l) => l.eq("email", t.userEmail)).first();
    if (!a)
      throw new Error("\u30E6\u30FC\u30B6\u30FC\u304C\u898B\u3064\u304B\u308A\u307E\u305B\u3093");
    let i = `prep_${Date.now()}_${Math.random().toString(36).substring(2, 15)}`;
    return {
      fileUploadId: await r.db.insert("fileUploads", {
        user_id: a._id,
        original_filename: t.filename,
        content_type: t.contentType,
        file_size: t.size,
        gcp_file_path: "",
        // 空のまま（フェーズ2で設定）
        upload_type: "video",
        status: "preparing",
        // 新ステータス
        uploaded_at: Date.now()
      }),
      preparationToken: i
    };
  }, "handler")
}), q = h({
  args: {
    fileUploadId: e.id("fileUploads"),
    preparationToken: e.string(),
    userEmail: e.string()
  },
  returns: e.union(
    e.null(),
    e.object({
      original_filename: e.string(),
      content_type: e.string(),
      file_size: e.number(),
      status: e.string()
    })
  ),
  handler: /* @__PURE__ */ n(async (r, t) => {
    let a = await r.db.query("users").withIndex("by_email", (o) => o.eq("email", t.userEmail)).first();
    if (!a) return null;
    let i = await r.db.get(t.fileUploadId);
    return !i || i.user_id !== a._id || i.status !== "preparing" ? null : {
      original_filename: i.original_filename,
      content_type: i.content_type,
      file_size: i.file_size,
      status: i.status
    };
  }, "handler")
}), S = d({
  args: {
    fileUploadId: e.id("fileUploads"),
    gcpFilePath: e.string(),
    uploadUrl: e.string(),
    isMultipart: e.boolean(),
    uploadId: e.optional(e.string())
  },
  returns: e.null(),
  handler: /* @__PURE__ */ n(async (r, t) => (await r.db.patch(t.fileUploadId, {
    gcp_file_path: t.gcpFilePath,
    status: "pending"
    // 準備完了、アップロード待ち
  }), null), "handler")
}), j = d({
  args: {
    fileUploadId: e.id("fileUploads"),
    errorMessage: e.string()
  },
  returns: e.null(),
  handler: /* @__PURE__ */ n(async (r, t) => {
    let a = {
      status: "failed"
    };
    return t.errorMessage && (a.processing_error = t.errorMessage), await r.db.patch(t.fileUploadId, a), null;
  }, "handler")
}), C = h({
  args: {
    fileUploadId: e.id("fileUploads"),
    userEmail: e.string()
  },
  returns: e.union(
    e.null(),
    e.object({
      user: e.object({
        _id: e.id("users"),
        email: e.string()
      }),
      fileUpload: e.object({
        _id: e.id("fileUploads"),
        user_id: e.id("users"),
        gcp_file_path: e.optional(e.string()),
        original_filename: e.string(),
        content_type: e.string(),
        file_size: e.number(),
        status: e.string()
      }),
      userMapping: e.object({
        legacy_user_id: e.id("users")
      })
    })
  ),
  handler: /* @__PURE__ */ n(async (r, t) => {
    let a = await r.db.query("users").withIndex("by_email", (l) => l.eq("email", t.userEmail)).first();
    if (!a) return null;
    let i = await r.db.get(t.fileUploadId);
    if (!i || i.user_id !== a._id) return null;
    let o = {
      legacy_user_id: a._id
      // 統一ユーザーテーブルを使用
    };
    return {
      user: {
        _id: a._id,
        email: a.email
      },
      fileUpload: {
        _id: i._id,
        user_id: i.user_id,
        gcp_file_path: i.gcp_file_path,
        original_filename: i.original_filename,
        content_type: i.content_type,
        file_size: i.file_size,
        status: i.status
      },
      userMapping: {
        legacy_user_id: o.legacy_user_id
      }
    };
  }, "handler")
}), A = d({
  args: {
    fileUploadId: e.id("fileUploads"),
    legacyUserId: e.id("users"),
    unifiedUserId: e.id("users"),
    title: e.string(),
    description: e.optional(e.string()),
    type: e.optional(e.string()),
    fileUrl: e.string()
  },
  returns: e.id("videos"),
  handler: /* @__PURE__ */ n(async (r, t) => {
    try {
      let a = await r.db.get(t.fileUploadId);
      if (!a)
        throw new Error("\u30D5\u30A1\u30A4\u30EB\u30A2\u30C3\u30D7\u30ED\u30FC\u30C9\u30EC\u30B3\u30FC\u30C9\u304C\u898B\u3064\u304B\u308A\u307E\u305B\u3093");
      if (a.status === "completed")
        throw new Error("\u3053\u306E\u30D5\u30A1\u30A4\u30EB\u306F\u65E2\u306B\u51E6\u7406\u6E08\u307F\u3067\u3059");
      if (a.status === "failed")
        throw new Error("\u5931\u6557\u3057\u305F\u30D5\u30A1\u30A4\u30EB\u30A2\u30C3\u30D7\u30ED\u30FC\u30C9\u304B\u3089\u306F\u52D5\u753B\u3092\u4F5C\u6210\u3067\u304D\u307E\u305B\u3093");
      let i = {
        user_id: t.legacyUserId,
        title: t.title,
        url: t.fileUrl,
        processing_status: "completed"
      };
      t.description !== void 0 && (i.description = t.description), t.type !== void 0 && (i.type = t.type);
      let o = await r.db.insert("videos", i);
      return await r.db.patch(t.fileUploadId, {
        status: "completed",
        public_url: t.fileUrl,
        related_resource_type: "video",
        related_resource_id: o,
        completed_at: Date.now()
      }), o;
    } catch (a) {
      throw await r.db.patch(t.fileUploadId, {
        status: "failed",
        processing_error: a instanceof Error ? a.message : "\u52D5\u753B\u30EC\u30B3\u30FC\u30C9\u4F5C\u6210\u4E2D\u306B\u30A8\u30E9\u30FC\u304C\u767A\u751F\u3057\u307E\u3057\u305F"
      }), a;
    }
  }, "handler")
}), R = d({
  args: {
    olderThanHours: e.optional(e.number())
  },
  returns: e.object({
    cleanedCount: e.number()
  }),
  handler: /* @__PURE__ */ n(async (r, t) => {
    let a = Date.now() - (t.olderThanHours || 24) * 60 * 60 * 1e3, i = await r.db.query("fileUploads").withIndex("by_status", (l) => l.eq("status", "preparing")).filter((l) => l.lt(l.field("uploaded_at"), a)).collect(), o = 0;
    for (let l of i)
      await r.db.patch(l._id, {
        status: "failed",
        processing_error: "\u30A2\u30C3\u30D7\u30ED\u30FC\u30C9\u6E96\u5099\u304C\u30BF\u30A4\u30E0\u30A2\u30A6\u30C8\u3057\u307E\u3057\u305F"
      }), o++;
    return { cleanedCount: o };
  }, "handler")
}), x = d({
  args: {
    fileUploadId: e.id("fileUploads"),
    stage: e.union(
      e.literal("generating_url"),
      e.literal("uploading"),
      e.literal("processing"),
      e.literal("completed"),
      e.literal("failed")
    ),
    progress: e.number(),
    error: e.optional(e.string())
  },
  returns: e.null(),
  handler: /* @__PURE__ */ n(async (r, t) => {
    let i = {
      status: {
        generating_url: "preparing",
        uploading: "uploading",
        processing: "processing",
        completed: "completed",
        failed: "failed"
      }[t.stage] || "pending"
    };
    return t.error !== void 0 && (i.processing_error = t.error), await r.db.patch(t.fileUploadId, i), null;
  }, "handler")
}), B = d({
  args: {
    fileUploadId: e.id("fileUploads"),
    errorMessage: e.string()
  },
  returns: e.null(),
  handler: /* @__PURE__ */ n(async (r, t) => {
    let a = {
      status: "failed"
    };
    return t.errorMessage && (a.processing_error = t.errorMessage), await r.db.patch(t.fileUploadId, a), null;
  }, "handler")
}), G = d({
  args: {},
  returns: e.object({
    checkedCount: e.number(),
    fixedCount: e.number(),
    issues: e.array(e.string())
  }),
  handler: /* @__PURE__ */ n(async (r) => {
    let t = 0, a = 0, i = [];
    try {
      let o = await r.db.query("fileUploads").collect();
      t = o.length;
      for (let l of o) {
        l.status === "completed" && !l.gcp_file_path && (await r.db.patch(l._id, {
          status: "failed",
          processing_error: "GCS file path is missing for completed upload"
        }), a++, i.push(`Fixed completed upload without GCS path: ${l._id}`));
        let p = 24 * 60 * 60 * 1e3;
        l.status === "pending" && l.uploaded_at && Date.now() - l.uploaded_at > p && (await r.db.patch(l._id, {
          status: "failed",
          processing_error: "Upload timeout - exceeded 24 hour limit"
        }), a++, i.push(`Timed out pending upload marked as failed: ${l._id}`));
      }
      return {
        checkedCount: t,
        fixedCount: a,
        issues: i
      };
    } catch (o) {
      return i.push(
        `Data integrity check failed: ${o instanceof Error ? o.message : "Unknown error"}`
      ), {
        checkedCount: t,
        fixedCount: a,
        issues: i
      };
    }
  }, "handler")
}), V = y({
  args: { fileUploadId: e.id("fileUploads") },
  returns: e.union(
    e.object({
      progress_percentage: e.number(),
      stage: e.union(
        e.literal("generating_url"),
        e.literal("uploading"),
        e.literal("processing"),
        e.literal("completed"),
        e.literal("failed")
      ),
      error_message: e.optional(e.string())
    }),
    e.null()
  ),
  handler: /* @__PURE__ */ n(async (r, t) => {
    let a = await r.db.get(t.fileUploadId);
    if (!a)
      return null;
    let i = {
      preparing: "generating_url",
      pending: "uploading",
      uploading: "uploading",
      processing: "processing",
      completed: "completed",
      failed: "failed"
    };
    return {
      progress_percentage: a.status === "completed" ? 100 : a.status === "failed" ? 0 : 50,
      stage: i[a.status] || "uploading",
      error_message: a.processing_error
    };
  }, "handler")
}), $ = y({
  args: {
    uploadType: e.optional(
      e.union(
        e.literal("video"),
        e.literal("training"),
        e.literal("thumbnail"),
        e.literal("course_thumbnail"),
        e.literal("module_content"),
        e.literal("roleplay_material")
      )
    )
  },
  returns: e.array(
    e.object({
      _id: e.id("fileUploads"),
      original_filename: e.string(),
      upload_type: e.union(
        e.literal("video"),
        e.literal("training"),
        e.literal("thumbnail"),
        e.literal("course_thumbnail"),
        e.literal("module_content"),
        e.literal("roleplay_material")
      ),
      status: e.union(
        e.literal("preparing"),
        e.literal("pending"),
        e.literal("uploading"),
        e.literal("completed"),
        e.literal("failed"),
        e.literal("processing")
      ),
      public_url: e.optional(e.string()),
      uploaded_at: e.optional(e.number()),
      completed_at: e.optional(e.number())
    })
  ),
  handler: /* @__PURE__ */ n(async (r, t) => {
    let a = await r.auth.getUserIdentity();
    if (!a)
      return [];
    let i = await r.db.query("users").withIndex("by_email", (l) => l.eq("email", a.email || "")).first();
    if (!i)
      return [];
    let o;
    return t.uploadType ? o = await r.db.query("fileUploads").withIndex(
      "by_user_type",
      (l) => l.eq("user_id", i._id).eq("upload_type", t.uploadType)
    ).order("desc").take(50) : o = await r.db.query("fileUploads").withIndex("by_user_id", (l) => l.eq("user_id", i._id)).order("desc").take(50), o.map((l) => ({
      _id: l._id,
      original_filename: l.original_filename,
      upload_type: l.upload_type,
      status: l.status,
      public_url: l.public_url,
      uploaded_at: l.uploaded_at,
      completed_at: l.completed_at
    }));
  }, "handler")
}), Q = d({
  args: {
    transcriptionId: e.id("transcriptions"),
    storageId: e.id("_storage")
  },
  returns: e.null(),
  handler: /* @__PURE__ */ n(async (r, t) => {
    let a = await r.db.get(t.transcriptionId);
    if (!a)
      throw new Error("\u6587\u5B57\u8D77\u3053\u3057\u30EC\u30B3\u30FC\u30C9\u304C\u898B\u3064\u304B\u308A\u307E\u305B\u3093");
    return a.status === "completed" || await r.db.patch(t.transcriptionId, {
      status: "processing",
      // アップロード完了、文字起こし処理中
      original_file_url: await r.storage.getUrl(t.storageId)
    }), null;
  }, "handler")
}), L = d({
  args: {
    transcriptionId: e.id("transcriptions"),
    gcpFilePath: e.string()
  },
  returns: e.null(),
  handler: /* @__PURE__ */ n(async (r, t) => {
    let a = await r.db.get(t.transcriptionId);
    if (!a)
      throw new Error("\u6587\u5B57\u8D77\u3053\u3057\u30EC\u30B3\u30FC\u30C9\u304C\u898B\u3064\u304B\u308A\u307E\u305B\u3093");
    return a.status === "completed" || await r.db.patch(t.transcriptionId, {
      status: "processing",
      original_file_url: `gs://${process.env.GCP_STORAGE_BUCKET}/${t.gcpFilePath}`
    }), null;
  }, "handler")
}), O = d({
  args: {
    transcriptionId: e.id("transcriptions"),
    transcriptionText: e.string(),
    audioFileUrl: e.optional(e.string())
  },
  returns: e.null(),
  handler: /* @__PURE__ */ n(async (r, t) => {
    if (!await r.db.get(t.transcriptionId))
      throw new Error("\u6587\u5B57\u8D77\u3053\u3057\u30EC\u30B3\u30FC\u30C9\u304C\u898B\u3064\u304B\u308A\u307E\u305B\u3093");
    return await r.db.patch(t.transcriptionId, {
      status: "completed",
      result: t.transcriptionText,
      original_file_url: t.audioFileUrl,
      completed_at: Date.now(),
      updated_at: Date.now()
    }), null;
  }, "handler")
});
export {
  R as cleanupStaleUploads,
  S as commitUploadPreparation,
  Q as completeFileUploadForQuickTranscription,
  L as completeGCSUploadForQuickTranscription,
  O as completeQuickTranscriptionUploadForQuickTranscription,
  z as completeVideoUpload,
  D as createFileUploadRecord,
  A as createVideoRecord,
  F as generateVideoUploadUrl,
  V as getUploadProgress,
  $ as getUserUploads,
  C as getVideoUploadInfo,
  B as markUploadAsFailed,
  G as performDataIntegrityCheck,
  k as prepareVideoUpload,
  j as rollbackUploadPreparation,
  x as updateUploadProgress,
  q as validateUploadPreparation
};
//# sourceMappingURL=uploads.js.map
