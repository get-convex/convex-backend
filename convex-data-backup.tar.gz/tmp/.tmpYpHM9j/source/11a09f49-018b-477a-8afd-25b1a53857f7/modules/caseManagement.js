import {
  b as g
} from "./_deps/SZVQRWFS.js";
import {
  a as h,
  c as w
} from "./_deps/75JH2J25.js";
import "./_deps/6XQQNYIR.js";
import {
  j as e,
  l as c,
  n as D
} from "./_deps/3TDUHHJO.js";
import {
  a as u
} from "./_deps/RUVYHBJQ.js";

// convex/caseManagement.ts
D();
D();
var f = e.union(
  e.literal("active"),
  e.literal("completed"),
  e.literal("on_hold"),
  e.literal("cancelled")
), b = e.union(e.literal("high"), e.literal("medium"), e.literal("low")), I = e.union(
  e.literal("completed"),
  e.literal("partial"),
  e.literal("missing"),
  e.literal("in_progress")
), A = e.object({
  title: e.string(),
  company_name: e.string(),
  description: e.optional(e.string()),
  status: f,
  created_by: e.id("users"),
  assigned_to: e.optional(e.id("users")),
  overall_progress: e.number(),
  priority: b,
  due_date: e.optional(e.number()),
  interview_data: e.optional(e.any())
}), $ = e.object({
  case_id: e.id("cases"),
  item_id: e.string(),
  category: e.string(),
  label: e.string(),
  description: e.optional(e.string()),
  weight: e.number(),
  priority: b,
  status: I,
  completed_at: e.optional(e.number()),
  notes: e.optional(e.string()),
  collected_data: e.optional(
    e.record(e.string(), e.union(e.string(), e.number(), e.boolean(), e.array(e.string())))
  )
}), O = h({
  args: {
    status: e.optional(f),
    assigned_to: e.optional(e.id("users")),
    created_by: e.optional(e.id("users"))
  },
  returns: e.array(
    e.object({
      _id: e.id("cases"),
      title: e.string(),
      company_name: e.string(),
      description: e.optional(e.string()),
      status: f,
      created_by: e.id("users"),
      assigned_to: e.optional(e.id("users")),
      overall_progress: e.number(),
      priority: b,
      due_date: e.optional(e.number()),
      _creationTime: e.number(),
      // 計算フィールド
      total_items: e.number(),
      completed_items: e.number(),
      creator_name: e.optional(e.string()),
      assignee_name: e.optional(e.string())
    })
  ),
  handler: /* @__PURE__ */ u(async (s, t) => {
    let r = await g(s);
    if (!(r.user.role === "admin" || r.user.role === "trainer")) {
      if (t.assigned_to && t.assigned_to !== r.unifiedUserId)
        throw new c("\u4ED6\u306E\u30E6\u30FC\u30B6\u30FC\u306E\u6848\u4EF6\u3092\u95B2\u89A7\u3059\u308B\u6A29\u9650\u304C\u3042\u308A\u307E\u305B\u3093");
      if (t.created_by && t.created_by !== r.unifiedUserId)
        throw new c("\u4ED6\u306E\u30E6\u30FC\u30B6\u30FC\u306E\u6848\u4EF6\u3092\u95B2\u89A7\u3059\u308B\u6A29\u9650\u304C\u3042\u308A\u307E\u305B\u3093");
    }
    let a;
    t.assigned_to ? a = s.db.query("cases").withIndex("by_assigned_to", (n) => n.eq("assigned_to", t.assigned_to)) : t.created_by ? a = s.db.query("cases").withIndex("by_created_by", (n) => n.eq("created_by", t.created_by)) : t.status ? a = s.db.query("cases").withIndex("by_status", (n) => n.eq("status", t.status)) : a = s.db.query("cases").order("desc");
    let p = await a.take(50);
    t.status && !t.assigned_to && !t.created_by && (p = p.filter((n) => n.status === t.status));
    let _ = /* @__PURE__ */ new Set();
    p.forEach((n) => {
      n.created_by && _.add(n.created_by), n.assigned_to && _.add(n.assigned_to);
    });
    let o = await Promise.all(Array.from(_).map((n) => s.db.get(n))), d = new Map(o.filter(Boolean).map((n) => [n?._id, n])), i = p.map((n) => n._id), y = await Promise.all(
      i.map(
        (n) => s.db.query("case_progress").withIndex("by_case_id", (v) => v.eq("case_id", n)).collect()
      )
    );
    return p.map((n, v) => {
      let q = y[v], C = q.length, P = q.filter((S) => S.status === "completed").length, j = d.get(n.created_by), U = n.assigned_to ? d.get(n.assigned_to) : null;
      return {
        ...n,
        total_items: C,
        completed_items: P,
        creator_name: j?.name,
        assignee_name: U?.name
      };
    });
  }, "handler")
}), k = w({
  args: {
    title: e.string(),
    company_name: e.string(),
    description: e.optional(e.string()),
    priority: e.optional(b),
    assigned_to: e.optional(e.id("users")),
    due_date: e.optional(e.number()),
    interview_data: e.optional(e.any())
  },
  returns: e.object({
    success: e.boolean(),
    caseId: e.optional(e.id("cases")),
    message: e.string(),
    data: e.optional(e.any())
  }),
  handler: /* @__PURE__ */ u(async (s, t) => {
    let r = await g(s);
    if (!t.title?.trim())
      throw new c("\u6848\u4EF6\u30BF\u30A4\u30C8\u30EB\u306F\u5FC5\u9808\u3067\u3059");
    if (!t.company_name?.trim())
      throw new c("\u4F01\u696D\u540D\u306F\u5FC5\u9808\u3067\u3059");
    if (t.title.length > 100)
      throw new c("\u6848\u4EF6\u30BF\u30A4\u30C8\u30EB\u306F100\u6587\u5B57\u4EE5\u5185\u3067\u5165\u529B\u3057\u3066\u304F\u3060\u3055\u3044");
    if (t.company_name.length > 100)
      throw new c("\u4F01\u696D\u540D\u306F100\u6587\u5B57\u4EE5\u5185\u3067\u5165\u529B\u3057\u3066\u304F\u3060\u3055\u3044");
    if (t.due_date && t.due_date < Date.now())
      throw new c("\u671F\u9650\u65E5\u306F\u73FE\u5728\u3088\u308A\u672A\u6765\u306E\u65E5\u4ED8\u3092\u8A2D\u5B9A\u3057\u3066\u304F\u3060\u3055\u3044");
    if (t.assigned_to) {
      let a = await s.db.get(t.assigned_to);
      if (!a || !a.isActive)
        throw new c("\u6307\u5B9A\u3055\u308C\u305F\u5272\u308A\u5F53\u3066\u5148\u30E6\u30FC\u30B6\u30FC\u304C\u898B\u3064\u304B\u3089\u306A\u3044\u304B\u3001\u7121\u52B9\u3067\u3059");
    }
    if (await s.db.query("cases").filter(
      (a) => a.and(
        a.eq(a.field("company_name"), t.company_name.trim()),
        a.eq(a.field("title"), t.title.trim()),
        a.eq(a.field("created_by"), r.unifiedUserId)
      )
    ).first())
      throw new c("\u540C\u3058\u4F1A\u793E\u540D\u3068\u30BF\u30A4\u30C8\u30EB\u306E\u6848\u4EF6\u304C\u65E2\u306B\u5B58\u5728\u3057\u307E\u3059");
    try {
      let a = [
        { category: "\u57FA\u672C\u60C5\u5831", label: "\u4F01\u696D\u6982\u8981\u53CE\u96C6", weight: 10, priority: "high" },
        { category: "\u57FA\u672C\u60C5\u5831", label: "\u8CA1\u52D9\u60C5\u5831\u53CE\u96C6", weight: 15, priority: "high" },
        { category: "\u57FA\u672C\u60C5\u5831", label: "\u4E8B\u696D\u5185\u5BB9\u8A73\u7D30", weight: 10, priority: "medium" },
        { category: "DD\u6E96\u5099", label: "DD\u9805\u76EE\u30EA\u30B9\u30C8\u4F5C\u6210", weight: 10, priority: "high" },
        { category: "DD\u6E96\u5099", label: "DD\u8CC7\u6599\u53CE\u96C6", weight: 15, priority: "high" },
        { category: "\u8A55\u4FA1", label: "\u4F01\u696D\u4FA1\u5024\u7B97\u5B9A", weight: 20, priority: "high" },
        { category: "\u8A55\u4FA1", label: "\u30EA\u30B9\u30AF\u5206\u6790", weight: 15, priority: "medium" },
        { category: "\u6700\u7D42\u5316", label: "\u6700\u7D42\u63D0\u6848\u66F8\u4F5C\u6210", weight: 5, priority: "low" }
      ], l = a.reduce((d, i) => d + i.weight, 0);
      if (l !== 100)
        throw new c(`\u9032\u6357\u9805\u76EE\u306E\u91CD\u307F\u306E\u5408\u8A08\u304C100%\u306B\u306A\u308A\u307E\u305B\u3093\uFF08\u73FE\u5728: ${l}%\uFF09`);
      let p = {
        title: t.title.trim(),
        company_name: t.company_name.trim(),
        status: "active",
        created_by: r.unifiedUserId,
        assigned_to: t.assigned_to || r.unifiedUserId,
        overall_progress: 0,
        priority: t.priority || "medium",
        ...t.description?.trim() && { description: t.description.trim() },
        ...t.due_date !== void 0 && { due_date: t.due_date },
        ...t.interview_data !== void 0 && { interview_data: t.interview_data }
      }, _ = await s.db.insert("cases", p);
      await Promise.all(
        a.map(
          (d, i) => s.db.insert("case_progress", {
            case_id: _,
            item_id: `item_${String(i + 1).padStart(3, "0")}`,
            category: d.category,
            label: d.label,
            description: `${d.label}\u306B\u95A2\u3059\u308B\u4F5C\u696D\u9805\u76EE`,
            weight: d.weight,
            priority: d.priority,
            status: "missing"
          })
        )
      );
      let o = await s.db.get(_);
      if (!o)
        throw new c("\u4F5C\u6210\u3055\u308C\u305F\u6848\u4EF6\u306E\u53D6\u5F97\u306B\u5931\u6557\u3057\u307E\u3057\u305F");
      return {
        success: !0,
        caseId: _,
        message: "\u6848\u4EF6\u304C\u6B63\u5E38\u306B\u4F5C\u6210\u3055\u308C\u307E\u3057\u305F",
        data: o
      };
    } catch (a) {
      let l = a instanceof c ? a.message : "\u6848\u4EF6\u4F5C\u6210\u4E2D\u306B\u4E88\u671F\u3057\u306A\u3044\u30A8\u30E9\u30FC\u304C\u767A\u751F\u3057\u307E\u3057\u305F";
      throw new c(l);
    }
  }, "handler")
}), N = h({
  args: {
    caseId: e.id("cases")
  },
  returns: e.union(
    e.object({
      _id: e.id("cases"),
      title: e.string(),
      company_name: e.string(),
      description: e.optional(e.string()),
      status: f,
      created_by: e.id("users"),
      assigned_to: e.optional(e.id("users")),
      overall_progress: e.number(),
      priority: b,
      due_date: e.optional(e.number()),
      interview_data: e.optional(e.any()),
      _creationTime: e.number(),
      // 計算フィールド
      total_items: e.number(),
      completed_items: e.number(),
      creator_name: e.optional(e.string()),
      assignee_name: e.optional(e.string())
    }),
    e.null()
  ),
  handler: /* @__PURE__ */ u(async (s, t) => {
    await g(s);
    let r = await s.db.get(t.caseId);
    if (!r)
      return null;
    let m = await s.db.query("case_progress").withIndex("by_case_id", (o) => o.eq("case_id", t.caseId)).collect(), a = m.length, l = m.filter((o) => o.status === "completed").length, p = r.created_by ? await s.db.get(r.created_by) : null, _ = r.assigned_to ? await s.db.get(r.assigned_to) : null;
    return {
      ...r,
      total_items: a,
      completed_items: l,
      creator_name: p?.name,
      assignee_name: _?.name
    };
  }, "handler")
}), R = h({
  args: {
    caseId: e.id("cases")
  },
  returns: e.object({
    case_info: e.object({
      _id: e.id("cases"),
      title: e.string(),
      company_name: e.string(),
      overall_progress: e.number(),
      _creationTime: e.number()
    }),
    items: e.array(
      e.object({
        _id: e.id("case_progress"),
        item_id: e.string(),
        category: e.string(),
        label: e.string(),
        description: e.optional(e.string()),
        weight: e.number(),
        priority: b,
        status: I,
        completed_at: e.optional(e.number()),
        notes: e.optional(e.string()),
        collected_data: e.optional(
          e.record(e.string(), e.union(e.string(), e.number(), e.boolean(), e.array(e.string())))
        )
      })
    )
  }),
  handler: /* @__PURE__ */ u(async (s, t) => {
    await g(s);
    let r = await s.db.get(t.caseId);
    if (!r)
      throw new c("\u6848\u4EF6\u304C\u898B\u3064\u304B\u308A\u307E\u305B\u3093");
    let m = await s.db.query("case_progress").withIndex("by_case_id", (a) => a.eq("case_id", t.caseId)).collect();
    return {
      case_info: {
        _id: r._id,
        title: r.title,
        company_name: r.company_name,
        overall_progress: r.overall_progress,
        _creationTime: r._creationTime
      },
      items: m
    };
  }, "handler")
}), B = w({
  args: {
    caseId: e.id("cases"),
    itemId: e.string(),
    status: I,
    notes: e.optional(e.string()),
    collected_data: e.optional(
      e.record(e.string(), e.union(e.string(), e.number(), e.boolean(), e.array(e.string())))
    )
  },
  returns: e.object({
    success: e.boolean(),
    message: e.string(),
    overall_progress: e.number()
  }),
  handler: /* @__PURE__ */ u(async (s, t) => {
    if (await g(s), !await s.db.get(t.caseId))
      throw new c("\u6848\u4EF6\u304C\u898B\u3064\u304B\u308A\u307E\u305B\u3093");
    let m = await s.db.query("case_progress").withIndex("by_case_id", (i) => i.eq("case_id", t.caseId)).filter((i) => i.eq(i.field("item_id"), t.itemId)).first();
    if (!m)
      throw new c("\u9032\u6357\u9805\u76EE\u304C\u898B\u3064\u304B\u308A\u307E\u305B\u3093");
    let a = Date.now(), l = {
      status: t.status
    };
    t.notes !== void 0 && (l.notes = t.notes), t.collected_data !== void 0 && (l.collected_data = t.collected_data), t.status === "completed" && m.status !== "completed" ? l.completed_at = a : t.status !== "completed" && m.completed_at && (l.completed_at = void 0), await s.db.patch(m._id, l);
    let p = await s.db.query("case_progress").withIndex("by_case_id", (i) => i.eq("case_id", t.caseId)).collect(), _ = p.reduce((i, y) => i + y.weight, 0), o = p.filter((i) => i.status === "completed").reduce((i, y) => i + y.weight, 0), d = _ > 0 ? Math.round(o / _ * 100) : 0;
    return await s.db.patch(t.caseId, {
      overall_progress: d
    }), {
      success: !0,
      message: "\u9032\u6357\u304C\u66F4\u65B0\u3055\u308C\u307E\u3057\u305F",
      overall_progress: d
    };
  }, "handler")
}), z = w({
  args: {
    caseId: e.id("cases"),
    items: e.array(
      e.object({
        itemId: e.string(),
        status: I,
        notes: e.optional(e.string()),
        collected_data: e.optional(
          e.record(e.string(), e.union(e.string(), e.number(), e.boolean(), e.array(e.string())))
        )
      })
    )
  },
  returns: e.object({
    success: e.boolean(),
    message: e.string(),
    overall_progress: e.number()
  }),
  handler: /* @__PURE__ */ u(async (s, t) => {
    if (await g(s), !await s.db.get(t.caseId))
      throw new c("\u6848\u4EF6\u304C\u898B\u3064\u304B\u308A\u307E\u305B\u3093");
    let m = Date.now();
    for (let o of t.items) {
      let d = await s.db.query("case_progress").withIndex("by_case_id", (i) => i.eq("case_id", t.caseId)).filter((i) => i.eq(i.field("item_id"), o.itemId)).first();
      if (d) {
        let i = {
          status: o.status
        };
        o.notes !== void 0 && (i.notes = o.notes), o.collected_data !== void 0 && (i.collected_data = o.collected_data), o.status === "completed" && d.status !== "completed" ? i.completed_at = m : o.status !== "completed" && d.completed_at && (i.completed_at = void 0), await s.db.patch(d._id, i);
      }
    }
    let a = await s.db.query("case_progress").withIndex("by_case_id", (o) => o.eq("case_id", t.caseId)).collect(), l = a.reduce((o, d) => o + d.weight, 0), p = a.filter((o) => o.status === "completed").reduce((o, d) => o + d.weight, 0), _ = l > 0 ? Math.round(p / l * 100) : 0;
    return await s.db.patch(t.caseId, {
      overall_progress: _
    }), {
      success: !0,
      message: `${t.items.length}\u4EF6\u306E\u9032\u6357\u304C\u66F4\u65B0\u3055\u308C\u307E\u3057\u305F`,
      overall_progress: _
    };
  }, "handler")
}), F = w({
  args: {
    caseId: e.id("cases")
  },
  returns: e.object({
    success: e.boolean(),
    message: e.string()
  }),
  handler: /* @__PURE__ */ u(async (s, t) => {
    let r = await g(s), m = await s.db.get(t.caseId);
    if (!m)
      throw new c("\u6848\u4EF6\u304C\u898B\u3064\u304B\u308A\u307E\u305B\u3093");
    if (m.created_by !== r.unifiedUserId && r.user.role !== "admin")
      throw new c("\u3053\u306E\u6848\u4EF6\u3092\u524A\u9664\u3059\u308B\u6A29\u9650\u304C\u3042\u308A\u307E\u305B\u3093");
    try {
      let a = await s.db.query("case_progress").withIndex("by_case_id", (l) => l.eq("case_id", t.caseId)).collect();
      for (let l of a)
        await s.db.delete(l._id);
      return await s.db.delete(t.caseId), {
        success: !0,
        message: "\u6848\u4EF6\u304C\u524A\u9664\u3055\u308C\u307E\u3057\u305F"
      };
    } catch (a) {
      throw console.error("Case deletion error:", a), new c("\u6848\u4EF6\u306E\u524A\u9664\u306B\u5931\u6557\u3057\u307E\u3057\u305F");
    }
  }, "handler")
});
export {
  z as bulkUpdateCaseProgress,
  f as caseStatusValidator,
  A as caseValidator,
  k as createCase,
  F as deleteCase,
  N as getCaseDetail,
  R as getCaseProgress,
  O as listCases,
  b as priorityValidator,
  $ as progressItemValidator,
  I as progressStatusValidator,
  B as updateCaseProgressItem
};
//# sourceMappingURL=caseManagement.js.map
