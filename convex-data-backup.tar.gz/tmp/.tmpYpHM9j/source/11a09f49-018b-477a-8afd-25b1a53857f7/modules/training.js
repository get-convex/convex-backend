import {
  a as b,
  b as w,
  e as T
} from "./_deps/IVQGLTSC.js";
import {
  a as d
} from "./_deps/6HNJFR7B.js";
import {
  a as g,
  c as m,
  e as y
} from "./_deps/75JH2J25.js";
import "./_deps/6XQQNYIR.js";
import {
  j as t,
  n as I
} from "./_deps/3TDUHHJO.js";
import {
  a as u
} from "./_deps/RUVYHBJQ.js";

// convex/training.ts
T();
I();
var F = g({
  args: {},
  returns: t.array(t.any()),
  handler: /* @__PURE__ */ u(async (e) => {
    await d(e);
    let n = await e.db.query("trainings").order("asc").collect();
    return await Promise.all(
      n.map(async (r) => {
        let o = await e.db.query("trainingModules").withIndex("by_training_id", (l) => l.eq("training_id", r._id)).collect(), a = o.length, s = o.filter(
          (l) => l.quiz_generation_status === "completed"
        ).length, _ = o.filter(
          (l) => l.quiz_generation_status === "generating"
        ).length, f = o.filter(
          (l) => l.quiz_generation_status === "failed"
        ).length, q = o.filter(
          (l) => l.quiz_generation_status === "pending" || !l.quiz_generation_status
        ).length, c = "pending", p = "";
        a === 0 ? (c = "no_modules", p = "\u30EC\u30C3\u30B9\u30F3\u304C\u3042\u308A\u307E\u305B\u3093") : _ > 0 ? (c = "generating", p = `${_}\u500B\u306E\u30EC\u30C3\u30B9\u30F3\u3067\u30C6\u30B9\u30C8\u751F\u6210\u4E2D\u3067\u3059`) : s === a ? (c = "completed", p = "\u3059\u3079\u3066\u306E\u30C6\u30B9\u30C8\u304C\u5229\u7528\u53EF\u80FD\u3067\u3059") : f > 0 ? (c = "partial_failed", p = `${s}/${a}\u500B\u306E\u30C6\u30B9\u30C8\u304C\u5229\u7528\u53EF\u80FD\uFF08${f}\u500B\u5931\u6557\uFF09`) : s > 0 ? (c = "partial_completed", p = `${s}/${a}\u500B\u306E\u30C6\u30B9\u30C8\u304C\u5229\u7528\u53EF\u80FD`) : (c = "pending", p = "\u30C6\u30B9\u30C8\u751F\u6210\u5F85\u3061\u3067\u3059");
        let U = /* @__PURE__ */ u((l) => {
          let h = {
            "first-meeting": "https://images.unsplash.com/photo-1552664730-d307ca884978?auto=format&fit=crop&w=800&q=80",
            proposal: "https://images.unsplash.com/photo-1557804506-669a67965ba0?auto=format&fit=crop&w=800&q=80",
            closing: "https://images.unsplash.com/photo-1516321318423-f06f85e504b3?auto=format&fit=crop&w=800&q=80",
            "lead-generation": "https://images.unsplash.com/photo-1454165804606-c3d57bc86b40?auto=format&fit=crop&w=800&q=80",
            other: "https://images.unsplash.com/photo-1517180102446-f3ece451e9d8?auto=format&fit=crop&w=800&q=80"
          };
          return h[l || "other"] || h.other;
        }, "generateThumbnailUrl"), M = o.length > 0 && o[0].content_type || "mixed";
        return {
          id: r._id.toString(),
          title: r.title,
          description: r.description || "",
          category: r.category || "other",
          duration_minutes: r.duration_minutes || 0,
          duration: `${Math.floor((r.duration_minutes || 0) / 60)}\u6642\u9593${(r.duration_minutes || 0) % 60}\u5206`,
          format: M,
          progress: 0,
          // This seems to be mock data, keeping it for now
          status: "\u672A\u958B\u59CB",
          // This seems to be mock data, keeping it for now
          thumbnail: r.thumbnail_url || U(r.category || null),
          priority: r.priority,
          module_count: a,
          quiz_generation: {
            status: c,
            message: p,
            stats: {
              total: a,
              completed: s,
              generating: _,
              failed: f,
              pending: q
            }
          }
        };
      })
    );
  }, "handler")
}), P = g({
  args: {
    trainingId: t.id("trainings")
  },
  returns: t.union(
    t.object({
      _id: t.id("trainings"),
      title: t.string(),
      description: t.optional(t.string()),
      category: t.optional(t.string()),
      duration_minutes: t.optional(t.float64()),
      thumbnail_url: t.optional(t.string()),
      priority: t.optional(t.string()),
      modules: t.array(
        t.object({
          _id: t.id("trainingModules"),
          title: t.string(),
          description: t.optional(t.string()),
          duration_minutes: t.optional(t.float64()),
          order_index: t.float64(),
          quiz_generation_status: t.optional(t.string())
        })
      )
    }),
    t.null()
  ),
  handler: /* @__PURE__ */ u(async (e, n) => {
    await d(e);
    let i = await e.db.get(n.trainingId);
    if (!i)
      return null;
    let r = await e.db.query("trainingModules").withIndex("by_training_id", (o) => o.eq("training_id", i._id)).order("asc").collect();
    return {
      ...i,
      modules: r
    };
  }, "handler")
}), G = g({
  args: {
    trainingId: t.id("trainings")
  },
  returns: t.object({
    overall_progress: t.number(),
    completed_modules: t.number(),
    total_modules: t.number(),
    status: t.string(),
    started_at: t.optional(t.number()),
    completed_at: t.optional(t.number())
  }),
  handler: /* @__PURE__ */ u(async (e, n) => (await d(e), {
    overall_progress: 0,
    completed_modules: 0,
    total_modules: (await e.db.query("trainingModules").withIndex("by_training_id", (r) => r.eq("training_id", n.trainingId)).collect()).length,
    status: "\u672A\u958B\u59CB",
    started_at: void 0,
    completed_at: void 0
  }), "handler")
}), j = m({
  args: {
    title: t.string(),
    description: t.optional(t.string()),
    category: t.optional(t.string()),
    durationMinutes: t.optional(t.number()),
    priority: t.optional(t.string()),
    thumbnailUrl: t.optional(t.string())
  },
  returns: t.id("trainings"),
  handler: /* @__PURE__ */ u(async (e, n) => {
    await d(e);
    let i = /* @__PURE__ */ u((a) => {
      let s = {
        "first-meeting": "https://images.unsplash.com/photo-1552664730-d307ca884978?auto=format&fit=crop&w=800&q=80",
        proposal: "https://images.unsplash.com/photo-1557804506-669a67965ba0?auto=format&fit=crop&w=800&q=80",
        closing: "https://images.unsplash.com/photo-1516321318423-f06f85e504b3?auto=format&fit=crop&w=800&q=80",
        "lead-generation": "https://images.unsplash.com/photo-1454165804606-c3d57bc86b40?auto=format&fit=crop&w=800&q=80",
        other: "https://images.unsplash.com/photo-1517180102446-f3ece451e9d8?auto=format&fit=crop&w=800&q=80"
      };
      return s[a || "other"] || s.other;
    }, "generateThumbnailUrl"), r = n.thumbnailUrl || i(n.category || null);
    return await e.db.insert("trainings", {
      title: n.title,
      description: n.description,
      category: n.category,
      duration_minutes: n.durationMinutes,
      priority: n.priority,
      thumbnail_url: r
    });
  }, "handler")
}), A = m({
  args: {
    trainingId: t.id("trainings"),
    title: t.string(),
    description: t.optional(t.string()),
    category: t.string(),
    durationMinutes: t.optional(t.number()),
    content: t.optional(t.string()),
    contentType: t.string(),
    fileUrl: t.optional(t.string()),
    fileType: t.optional(t.string())
  },
  returns: t.object({
    id: t.id("trainingModules"),
    message: t.string()
  }),
  handler: /* @__PURE__ */ u(async (e, n) => {
    if (await d(e), !await e.db.get(n.trainingId))
      throw new Error("\u30C8\u30EC\u30FC\u30CB\u30F3\u30B0\u304C\u898B\u3064\u304B\u308A\u307E\u305B\u3093");
    let o = (await e.db.query("trainingModules").withIndex("by_training_id", (s) => s.eq("training_id", n.trainingId)).collect()).length, a = await e.db.insert("trainingModules", {
      training_id: n.trainingId,
      title: n.title,
      description: n.description,
      content: n.content,
      content_type: n.contentType,
      file_url: n.fileUrl,
      file_type: n.fileType,
      duration_minutes: n.durationMinutes,
      order_index: o,
      quiz_generation_status: "pending",
      transcription_status: n.contentType === "audio" ? "pending" : void 0
    });
    if (n.contentType === "audio" && n.fileUrl && n.fileType)
      try {
        console.log(`[createModule] \u97F3\u58F0\u30D5\u30A1\u30A4\u30EB\u691C\u51FA\u3001\u6587\u5B57\u8D77\u3053\u3057\u958B\u59CB: ${n.fileUrl}`), await e.scheduler.runAfter(0, w.transcriptions.startTranscription, {
          resourceType: "training_content",
          resourceId: a,
          fileUrl: n.fileUrl,
          fileType: n.fileType,
          options: {
            enableSpeakerDiarization: !0,
            language: "ja",
            autoStartAnalysis: !1
          }
        }), console.log(`[createModule] \u6587\u5B57\u8D77\u3053\u3057\u51E6\u7406\u3092\u30B9\u30B1\u30B8\u30E5\u30FC\u30EB\u5B8C\u4E86: moduleId=${a}`);
      } catch (s) {
        console.error("[createModule] \u6587\u5B57\u8D77\u3053\u3057\u958B\u59CB\u30A8\u30E9\u30FC:", s);
      }
    return {
      id: a,
      message: "\u30C8\u30EC\u30FC\u30CB\u30F3\u30B0\u30E2\u30B8\u30E5\u30FC\u30EB\u304C\u6B63\u5E38\u306B\u4F5C\u6210\u3055\u308C\u307E\u3057\u305F"
    };
  }, "handler")
}), R = g({
  args: {
    trainingId: t.id("trainings")
  },
  returns: t.union(
    t.object({
      _id: t.id("trainings"),
      _creationTime: t.number(),
      title: t.string(),
      description: t.optional(t.string()),
      category: t.optional(t.string()),
      duration_minutes: t.optional(t.float64()),
      thumbnail_url: t.optional(t.string()),
      priority: t.optional(t.string()),
      modules: t.array(
        t.object({
          _id: t.id("trainingModules"),
          _creationTime: t.number(),
          title: t.string(),
          description: t.optional(t.string()),
          duration_minutes: t.optional(t.float64()),
          order_index: t.float64(),
          quiz_generation_status: t.optional(t.string()),
          content: t.optional(t.string()),
          content_type: t.optional(t.string()),
          file_url: t.optional(t.string()),
          file_type: t.optional(t.string())
        })
      )
    }),
    t.null()
  ),
  handler: /* @__PURE__ */ u(async (e, n) => {
    await d(e);
    let i = await e.db.get(n.trainingId);
    if (!i)
      return null;
    let r = await e.db.query("trainingModules").withIndex("by_training_id", (o) => o.eq("training_id", i._id)).order("asc").collect();
    return {
      ...i,
      modules: r.map((o) => ({
        _id: o._id,
        _creationTime: o._creationTime,
        title: o.title,
        description: o.description,
        duration_minutes: o.duration_minutes,
        order_index: o.order_index,
        quiz_generation_status: o.quiz_generation_status,
        content: o.content,
        content_type: o.content_type,
        file_url: o.file_url,
        file_type: o.file_type
      }))
    };
  }, "handler")
}), D = y({
  args: {
    fileUrl: t.string(),
    expirationMinutes: t.optional(t.number())
  },
  returns: t.object({
    success: t.boolean(),
    signedUrl: t.optional(t.string()),
    error: t.optional(t.string())
  }),
  handler: /* @__PURE__ */ u(async (e, n) => {
    try {
      console.log(`[generateContentFileSignedUrl] \u30D5\u30A1\u30A4\u30EBURL: ${n.fileUrl}`);
      let i = x(n.fileUrl);
      if (!i)
        return {
          success: !1,
          error: "\u6709\u52B9\u306AGCS\u30D5\u30A1\u30A4\u30EBURL\u3067\u306F\u3042\u308A\u307E\u305B\u3093"
        };
      console.log(`[generateContentFileSignedUrl] \u62BD\u51FA\u3055\u308C\u305FGCP\u30D5\u30A1\u30A4\u30EB\u30D1\u30B9: ${i}`);
      let r = await e.runAction(b.gcsActions.generateGCPReadUrl, {
        gcpFilePath: i,
        expirationMinutes: n.expirationMinutes || 120
        // デフォルト2時間
      });
      return r.success && r.readUrl ? (console.log("[generateContentFileSignedUrl] \u7F72\u540D\u4ED8\u304DURL\u751F\u6210\u6210\u529F"), {
        success: !0,
        signedUrl: r.readUrl
      }) : (console.error("[generateContentFileSignedUrl] \u7F72\u540D\u4ED8\u304DURL\u751F\u6210\u5931\u6557:", r.error), {
        success: !1,
        error: r.error || "\u7F72\u540D\u4ED8\u304DURL\u751F\u6210\u306B\u5931\u6557\u3057\u307E\u3057\u305F"
      });
    } catch (i) {
      return console.error("[generateContentFileSignedUrl] \u30A8\u30E9\u30FC:", i), {
        success: !1,
        error: `\u4E88\u671F\u3057\u306A\u3044\u30A8\u30E9\u30FC: ${i instanceof Error ? i.message : String(i)}`
      };
    }
  }, "handler")
}), L = m({
  args: {
    moduleId: t.id("trainingModules"),
    status: t.union(t.literal("pending"), t.literal("in_progress"), t.literal("completed"), t.literal("failed")),
    error: t.optional(t.string())
  },
  returns: t.null(),
  handler: /* @__PURE__ */ u(async (e, n) => {
    await d(e);
    let i = {
      transcriptionStatus: n.status
    };
    return n.status === "in_progress" ? i.transcriptionStartedAt = Date.now() : n.status === "completed" ? (i.transcriptionCompletedAt = Date.now(), i.transcriptionError = void 0) : n.status === "failed" && (i.transcriptionError = n.error), await e.db.patch(n.moduleId, i), console.log(`[updateModuleTranscriptionStatus] moduleId=${n.moduleId}, status=${n.status}`), null;
  }, "handler")
});
function x(e) {
  try {
    let n = /https:\/\/storage\.googleapis\.com\/([^\/]+)\/(.+)/, i = e.match(n);
    return i && i[2] ? i[2] : e.includes("://") ? (console.warn(`[extractGcpFilePathFromUrl] GCS\u30D5\u30A1\u30A4\u30EB\u30D1\u30B9\u306E\u62BD\u51FA\u306B\u5931\u6557: ${e}`), null) : e;
  } catch (n) {
    return console.error("[extractGcpFilePathFromUrl] \u30A8\u30E9\u30FC:", n), null;
  }
}
u(x, "extractGcpFilePathFromUrl");
export {
  A as createModule,
  j as createTraining,
  D as generateContentFileSignedUrl,
  P as getById,
  G as getProgress,
  R as getTrainingWithModules,
  F as list,
  L as updateModuleTranscriptionStatus
};
//# sourceMappingURL=training.js.map
