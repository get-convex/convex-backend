import {
  a as s,
  e as g
} from "./_deps/IVQGLTSC.js";
import {
  a
} from "./_deps/75JH2J25.js";
import "./_deps/6XQQNYIR.js";
import {
  j as e,
  n as m
} from "./_deps/3TDUHHJO.js";
import {
  a as r
} from "./_deps/RUVYHBJQ.js";

// convex/systemConfig.ts
m();
g();
var i = e.object({
  storageType: e.union(e.literal("local"), e.literal("gcp")),
  deploymentType: e.string(),
  useGcpStorage: e.boolean(),
  maxFileSize: e.number(),
  cloudRunMaxRequestSize: e.number(),
  environment: e.string()
}), y = a({
  args: {},
  returns: i,
  handler: /* @__PURE__ */ r(async () => {
    let o = "production", n = process.env.DEPLOYMENT_TYPE || "standalone", t = process.env.USE_GCP_STORAGE === "true", l = t ? "gcp" : "local", c = Number.parseInt(process.env.MAX_FILE_SIZE || "104857600"), u = Number.parseInt(
      process.env.CLOUD_RUN_MAX_REQUEST_SIZE || "33554432"
    );
    return {
      storageType: l,
      deploymentType: n,
      useGcpStorage: t,
      maxFileSize: c,
      cloudRunMaxRequestSize: u,
      environment: o
    };
  }, "handler")
}), b = a({
  args: {},
  returns: e.object({
    config: i,
    healthCheck: e.object({
      convexHealthy: e.boolean(),
      storageAccessible: e.boolean(),
      timestamp: e.number()
    })
  }),
  handler: /* @__PURE__ */ r(async (o) => {
    let n = await o.runQuery(s.systemConfig.getSystemConfig, {}), t = {
      convexHealthy: !0,
      // Convex内で実行されているため常にtrue
      storageAccessible: !0,
      // 実際のストレージチェックは複雑なので簡略化
      timestamp: Date.now()
    };
    return {
      config: n,
      healthCheck: t
    };
  }, "handler")
}), x = a({
  args: {
    fileSize: e.number()
  },
  returns: e.object({
    strategy: e.union(e.literal("direct"), e.literal("chunked"), e.literal("signed-url")),
    reason: e.string(),
    maxAllowedSize: e.number()
  }),
  handler: /* @__PURE__ */ r(async (o, n) => {
    let t = await o.runQuery(s.systemConfig.getSystemConfig, {});
    return n.fileSize > t.maxFileSize ? {
      strategy: "chunked",
      reason: `\u30D5\u30A1\u30A4\u30EB\u30B5\u30A4\u30BA (${Math.round(n.fileSize / 1024 / 1024)}MB) \u304C\u5236\u9650 (${Math.round(t.maxFileSize / 1024 / 1024)}MB) \u3092\u8D85\u3048\u3066\u3044\u307E\u3059`,
      maxAllowedSize: t.maxFileSize
    } : t.storageType === "gcp" || t.useGcpStorage ? {
      strategy: "signed-url",
      reason: "GCP\u30B9\u30C8\u30EC\u30FC\u30B8\u4F7F\u7528\u306E\u305F\u3081\u7F72\u540D\u4ED8\u304DURL\u65B9\u5F0F\u3092\u63A8\u5968",
      maxAllowedSize: t.maxFileSize
    } : n.fileSize > t.cloudRunMaxRequestSize ? {
      strategy: "chunked",
      reason: `Cloud Run\u5236\u9650 (${Math.round(t.cloudRunMaxRequestSize / 1024 / 1024)}MB) \u3092\u8D85\u3048\u308B\u305F\u3081\u30C1\u30E3\u30F3\u30AF\u5206\u5272\u304C\u5FC5\u8981`,
      maxAllowedSize: t.maxFileSize
    } : {
      strategy: "direct",
      reason: "\u5236\u9650\u5185\u306E\u305F\u3081\u76F4\u63A5\u30A2\u30C3\u30D7\u30ED\u30FC\u30C9\u304C\u53EF\u80FD",
      maxAllowedSize: t.maxFileSize
    };
  }, "handler")
});
export {
  x as getRecommendedUploadStrategy,
  y as getSystemConfig,
  b as getSystemStatus,
  i as systemConfigValidator
};
//# sourceMappingURL=systemConfig.js.map
