import {
  a as p,
  c as u
} from "./_deps/75JH2J25.js";
import "./_deps/6XQQNYIR.js";
import {
  j as t,
  n as _
} from "./_deps/3TDUHHJO.js";
import {
  a as d
} from "./_deps/RUVYHBJQ.js";

// convex/cases.ts
_();
function g(r) {
  return `mock-${r}-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
}
d(g, "createMockId");
var f = p({
  args: {
    status: t.optional(t.string()),
    priority: t.optional(t.string()),
    search: t.optional(t.string()),
    page: t.optional(t.number()),
    limit: t.optional(t.number())
  },
  returns: t.object({
    cases: t.array(
      t.object({
        _id: t.id("cases"),
        title: t.string(),
        company_name: t.string(),
        description: t.optional(t.string()),
        status: t.string(),
        priority: t.string(),
        overall_progress: t.number(),
        due_date: t.optional(t.string()),
        created_by: t.id("users"),
        assigned_to: t.optional(t.id("users")),
        _creationTime: t.number(),
        total_items: t.number(),
        completed_items: t.number()
      })
    ),
    total: t.number(),
    page: t.number(),
    limit: t.number(),
    totalPages: t.number()
  }),
  handler: /* @__PURE__ */ d(async (r, e) => {
    let i = await r.auth.getUserIdentity();
    if (!i)
      throw new Error("\u8A8D\u8A3C\u304C\u5FC5\u8981\u3067\u3059");
    let n = await r.db.query("users").withIndex("by_token", (a) => a.eq("tokenIdentifier", i.tokenIdentifier)).unique();
    if (!n)
      throw new Error("\u30E6\u30FC\u30B6\u30FC\u304C\u898B\u3064\u304B\u308A\u307E\u305B\u3093");
    let l = e.page || 1, o = e.limit || 20, c = (l - 1) * o, s = [
      {
        _id: g("case-1"),
        title: "\u682A\u5F0F\u4F1A\u793E\u30B5\u30F3\u30D7\u30EB\u8CB7\u53CE\u6848\u4EF6",
        company_name: "\u682A\u5F0F\u4F1A\u793E\u30B5\u30F3\u30D7\u30EB",
        description: "IT\u4F01\u696D\u306E\u8CB7\u53CE\u6848\u4EF6\u3067\u3059",
        status: "in_progress",
        priority: "high",
        overall_progress: 65,
        due_date: "2024-03-15",
        created_by: n._id,
        assigned_to: n._id,
        _creationTime: Date.now(),
        total_items: 20,
        completed_items: 13
      },
      {
        _id: g("case-2"),
        title: "\u30C6\u30B9\u30C8\u5546\u4E8B\u8CB7\u53CE\u691C\u8A0E",
        company_name: "\u30C6\u30B9\u30C8\u5546\u4E8B",
        description: "\u88FD\u9020\u696D\u306E\u8CB7\u53CE\u691C\u8A0E\u6848\u4EF6\u3067\u3059",
        status: "pending",
        priority: "medium",
        overall_progress: 25,
        due_date: "2024-04-30",
        created_by: n._id,
        assigned_to: void 0,
        _creationTime: Date.now() - 864e5,
        total_items: 20,
        completed_items: 5
      }
    ];
    e.status && e.status !== "all" && (s = s.filter((a) => a.status === e.status)), e.priority && e.priority !== "all" && (s = s.filter((a) => a.priority === e.priority)), e.search && (s = s.filter(
      (a) => a.title.toLowerCase().includes(e.search?.toLowerCase() || "") || a.company_name.toLowerCase().includes(e.search?.toLowerCase() || "")
    ));
    let m = s.length;
    return {
      cases: s.slice(c, c + o),
      total: m,
      page: l,
      limit: o,
      totalPages: Math.ceil(m / o)
    };
  }, "handler")
}), I = p({
  args: {
    caseId: t.id("cases")
  },
  returns: t.union(
    t.object({
      _id: t.id("cases"),
      title: t.string(),
      company_name: t.string(),
      description: t.optional(t.string()),
      status: t.string(),
      priority: t.string(),
      overall_progress: t.number(),
      due_date: t.optional(t.string()),
      created_by: t.id("users"),
      assigned_to: t.optional(t.id("users")),
      interview_data: t.optional(
        t.object({
          questions: t.optional(
            t.array(
              t.object({
                question: t.string(),
                answer: t.optional(t.string()),
                category: t.optional(t.string()),
                importance: t.optional(t.string())
              })
            )
          ),
          notes: t.optional(t.string()),
          interviewer: t.optional(t.string()),
          interview_date: t.optional(t.number()),
          follow_up_required: t.optional(t.boolean())
        })
      ),
      _creationTime: t.number()
    }),
    t.null()
  ),
  handler: /* @__PURE__ */ d(async (r, e) => {
    let i = await r.auth.getUserIdentity();
    if (!i)
      throw new Error("\u8A8D\u8A3C\u304C\u5FC5\u8981\u3067\u3059");
    let n = await r.db.query("users").withIndex("by_token", (l) => l.eq("tokenIdentifier", i.tokenIdentifier)).unique();
    if (!n)
      throw new Error("\u30E6\u30FC\u30B6\u30FC\u304C\u898B\u3064\u304B\u308A\u307E\u305B\u3093");
    return {
      _id: e.caseId,
      title: "\u682A\u5F0F\u4F1A\u793E\u30B5\u30F3\u30D7\u30EB\u8CB7\u53CE\u6848\u4EF6",
      company_name: "\u682A\u5F0F\u4F1A\u793E\u30B5\u30F3\u30D7\u30EB",
      description: "IT\u4F01\u696D\u306E\u8CB7\u53CE\u6848\u4EF6\u3067\u3059\u3002\u8A73\u7D30\u306A\u30C7\u30E5\u30FC\u30C7\u30EA\u30B8\u30A7\u30F3\u30B9\u3092\u5B9F\u65BD\u4E2D\u3002",
      status: "in_progress",
      priority: "high",
      overall_progress: 65,
      due_date: "2024-03-15",
      created_by: n._id,
      assigned_to: n._id,
      interview_data: {
        questions: [
          {
            question: "CEO\u30A4\u30F3\u30BF\u30D3\u30E5\u30FC\u306E\u9032\u6357\u306F\u3044\u304B\u304C\u3067\u3059\u304B\uFF1F",
            answer: "\u5B8C\u4E86",
            category: "\u7D4C\u55B6\u9663",
            importance: "high"
          },
          {
            question: "\u8CA1\u52D9\u30EC\u30D3\u30E5\u30FC\u306E\u72B6\u6CC1\u3092\u6559\u3048\u3066\u304F\u3060\u3055\u3044",
            answer: "\u9032\u884C\u4E2D",
            category: "\u8CA1\u52D9",
            importance: "high"
          },
          {
            question: "\u5E02\u5834\u5206\u6790\u306F\u958B\u59CB\u3055\u308C\u3066\u3044\u307E\u3059\u304B\uFF1F",
            answer: "\u672A\u7740\u624B",
            category: "\u5E02\u5834",
            importance: "medium"
          }
        ],
        notes: "\u9806\u8ABF\u306B\u9032\u6357\u3057\u3066\u3044\u307E\u3059",
        interviewer: "\u62C5\u5F53\u8005",
        interview_date: Date.now(),
        follow_up_required: !1
      },
      _creationTime: Date.now()
    };
  }, "handler")
}), q = p({
  args: {
    caseId: t.id("cases")
  },
  returns: t.object({
    overall_progress: t.number(),
    progress_items: t.array(
      t.object({
        id: t.string(),
        category: t.string(),
        label: t.string(),
        description: t.optional(t.string()),
        weight: t.number(),
        priority: t.string(),
        status: t.string(),
        notes: t.optional(t.string()),
        collected_data: t.optional(
          t.record(t.string(), t.union(t.string(), t.number(), t.boolean(), t.array(t.string())))
        ),
        completed_at: t.optional(t.number())
      })
    )
  }),
  handler: /* @__PURE__ */ d(async (r) => {
    if (!await r.auth.getUserIdentity())
      throw new Error("\u8A8D\u8A3C\u304C\u5FC5\u8981\u3067\u3059");
    let i = [
      {
        id: "1",
        category: "\u57FA\u672C\u60C5\u5831",
        label: "\u4F1A\u793E\u6982\u8981",
        description: "\u4F1A\u793E\u306E\u57FA\u672C\u7684\u306A\u60C5\u5831\u3092\u53CE\u96C6",
        weight: 5,
        priority: "high",
        status: "completed",
        notes: "\u8CC7\u6599\u53CE\u96C6\u5B8C\u4E86",
        collected_data: { company_profile: "\u8A73\u7D30\u30C7\u30FC\u30BF" },
        completed_at: Date.now() - 864e5
      },
      {
        id: "2",
        category: "\u8CA1\u52D9\u60C5\u5831",
        label: "\u8CA1\u52D9\u8AF8\u8868",
        description: "\u904E\u53BB3\u5E74\u5206\u306E\u8CA1\u52D9\u8AF8\u8868\u3092\u53CE\u96C6",
        weight: 10,
        priority: "high",
        status: "in_progress",
        notes: "2\u5E74\u5206\u53CE\u96C6\u6E08\u307F",
        collected_data: void 0,
        completed_at: void 0
      }
      // ... 他の進捗項目
    ], n = i.filter((o) => o.status === "completed");
    return {
      overall_progress: Math.round(
        n.reduce((o, c) => o + c.weight, 0) / i.reduce((o, c) => o + c.weight, 0) * 100
      ),
      progress_items: i
    };
  }, "handler")
}), v = u({
  args: {
    title: t.string(),
    company_name: t.string(),
    description: t.optional(t.string()),
    priority: t.string(),
    due_date: t.optional(t.string()),
    assigned_to: t.optional(t.id("users"))
  },
  returns: t.id("cases"),
  handler: /* @__PURE__ */ d(async (r, e) => {
    let i = await r.auth.getUserIdentity();
    if (!i)
      throw new Error("\u8A8D\u8A3C\u304C\u5FC5\u8981\u3067\u3059");
    if (!await r.db.query("users").withIndex("by_token", (l) => l.eq("tokenIdentifier", i.tokenIdentifier)).unique())
      throw new Error("\u30E6\u30FC\u30B6\u30FC\u304C\u898B\u3064\u304B\u308A\u307E\u305B\u3093");
    return console.log("\u6848\u4EF6\u4F5C\u6210:", e), g("new");
  }, "handler")
}), k = u({
  args: {
    caseId: t.id("cases"),
    progressUpdates: t.array(
      t.object({
        item_id: t.string(),
        status: t.string(),
        notes: t.optional(t.string()),
        collected_data: t.optional(
          t.record(t.string(), t.union(t.string(), t.number(), t.boolean(), t.array(t.string())))
        )
      })
    )
  },
  returns: t.null(),
  handler: /* @__PURE__ */ d(async (r, e) => {
    if (!await r.auth.getUserIdentity())
      throw new Error("\u8A8D\u8A3C\u304C\u5FC5\u8981\u3067\u3059");
    return console.log("\u9032\u6357\u66F4\u65B0:", e), null;
  }, "handler")
}), U = u({
  args: {
    caseId: t.id("cases"),
    title: t.optional(t.string()),
    company_name: t.optional(t.string()),
    description: t.optional(t.string()),
    status: t.optional(t.string()),
    priority: t.optional(t.string()),
    due_date: t.optional(t.string()),
    assigned_to: t.optional(t.id("users"))
  },
  returns: t.null(),
  handler: /* @__PURE__ */ d(async (r, e) => {
    if (!await r.auth.getUserIdentity())
      throw new Error("\u8A8D\u8A3C\u304C\u5FC5\u8981\u3067\u3059");
    return console.log("\u6848\u4EF6\u66F4\u65B0:", e), null;
  }, "handler")
});
export {
  v as create,
  I as getById,
  q as getProgress,
  f as list,
  U as update,
  k as updateProgress
};
//# sourceMappingURL=cases.js.map
