import {
  a as w,
  e as _
} from "./_deps/IVQGLTSC.js";
import {
  c as p
} from "./_deps/SZVQRWFS.js";
import {
  b as h
} from "./_deps/6HNJFR7B.js";
import {
  a as b,
  c as y
} from "./_deps/75JH2J25.js";
import "./_deps/6XQQNYIR.js";
import {
  j as e,
  l as c,
  n as f
} from "./_deps/3TDUHHJO.js";
import {
  a as m
} from "./_deps/RUVYHBJQ.js";

// convex/userManagement.ts
f();
f();
_();
var C = b({
  args: {},
  returns: e.object({
    id: e.id("users"),
    email: e.string(),
    name: e.optional(e.string()),
    role: e.string(),
    department: e.optional(e.string()),
    position: e.optional(e.string()),
    isActive: e.boolean(),
    isAdmin: e.boolean(),
    isTrainer: e.boolean()
  }),
  handler: /* @__PURE__ */ m(async (i) => {
    let { user: t } = await h(i);
    return {
      id: t._id,
      email: t.email,
      name: t.name,
      role: t.role,
      department: t.department,
      position: t.position,
      isActive: t.isActive,
      isAdmin: t.role === "admin",
      isTrainer: t.role === "trainer"
    };
  }, "handler")
}), D = b({
  args: {
    search: e.optional(e.string()),
    department: e.optional(e.string()),
    role: e.optional(e.string()),
    page: e.optional(e.number()),
    limit: e.optional(e.number())
  },
  returns: e.object({
    users: e.array(
      e.object({
        _id: e.id("users"),
        email: e.string(),
        name: e.string(),
        role: e.string(),
        department: e.optional(e.string()),
        position: e.optional(e.string()),
        isActive: e.boolean(),
        _creationTime: e.number()
      })
    ),
    total: e.number(),
    hasMore: e.boolean()
  }),
  handler: /* @__PURE__ */ m(async (i, t) => {
    await p(i);
    let r = await i.db.query("users").collect();
    if (t.search) {
      let o = t.search.toLowerCase();
      r = r.filter(
        (g) => g.name.toLowerCase().includes(o) || g.email.toLowerCase().includes(o)
      );
    }
    t.department && (r = r.filter((o) => o.department === t.department)), t.role && (r = r.filter((o) => o.role === t.role));
    let u = t.page || 1, s = t.limit || 20, d = (u - 1) * s;
    return {
      users: r.slice(d, d + s),
      total: r.length,
      hasMore: r.length > d + s
    };
  }, "handler")
}), T = y({
  args: {
    firstName: e.string(),
    lastName: e.string(),
    email: e.string(),
    employeeId: e.string(),
    department: e.string(),
    position: e.string(),
    role: e.string(),
    joinDate: e.string()
  },
  returns: e.object({
    success: e.boolean(),
    userId: e.optional(e.id("users")),
    message: e.string()
  }),
  handler: /* @__PURE__ */ m(async (i, t) => {
    if (await p(i), await i.db.query("users").withIndex("by_email", (r) => r.eq("email", t.email)).first())
      throw new c("\u3053\u306E\u30E1\u30FC\u30EB\u30A2\u30C9\u30EC\u30B9\u306F\u65E2\u306B\u767B\u9332\u3055\u308C\u3066\u3044\u307E\u3059");
    if (await i.db.query("users").withIndex("by_employee_id", (r) => r.eq("employeeId", t.employeeId)).first())
      throw new c("\u3053\u306E\u793E\u54E1ID\u306F\u65E2\u306B\u767B\u9332\u3055\u308C\u3066\u3044\u307E\u3059");
    try {
      return {
        success: !0,
        userId: await i.db.insert("users", {
          name: `${t.firstName} ${t.lastName}`,
          email: t.email,
          emailVerified: !1,
          employeeId: t.employeeId,
          department: t.department,
          position: t.position,
          role: t.role,
          joinDate: new Date(t.joinDate).getTime(),
          isActive: !0,
          // ClerkユーザーIDは後で設定（招待メール送信時）
          clerkUserId: "",
          tokenIdentifier: ""
        }),
        message: "\u30E6\u30FC\u30B6\u30FC\u304C\u6B63\u5E38\u306B\u767B\u9332\u3055\u308C\u307E\u3057\u305F"
      };
    } catch (r) {
      throw console.error("User registration error:", r), new c("\u30E6\u30FC\u30B6\u30FC\u767B\u9332\u306B\u5931\u6557\u3057\u307E\u3057\u305F");
    }
  }, "handler")
}), N = y({
  args: {
    userId: e.id("users"),
    updates: e.object({
      department: e.optional(e.string()),
      position: e.optional(e.string()),
      role: e.optional(e.string()),
      isActive: e.optional(e.boolean())
    })
  },
  returns: e.object({
    success: e.boolean(),
    message: e.string()
  }),
  handler: /* @__PURE__ */ m(async (i, t) => {
    if (await p(i), !await i.db.get(t.userId))
      throw new c("\u30E6\u30FC\u30B6\u30FC\u304C\u898B\u3064\u304B\u308A\u307E\u305B\u3093");
    try {
      let n = {};
      return t.updates.department !== void 0 && (n.department = t.updates.department), t.updates.position !== void 0 && (n.position = t.updates.position), t.updates.role !== void 0 && (n.role = t.updates.role), t.updates.isActive !== void 0 && (n.isActive = t.updates.isActive), await i.db.patch(t.userId, n), {
        success: !0,
        message: "\u30E6\u30FC\u30B6\u30FC\u60C5\u5831\u304C\u66F4\u65B0\u3055\u308C\u307E\u3057\u305F"
      };
    } catch (n) {
      throw console.error("User update error:", n), new c("\u30E6\u30FC\u30B6\u30FC\u60C5\u5831\u306E\u66F4\u65B0\u306B\u5931\u6557\u3057\u307E\u3057\u305F");
    }
  }, "handler")
}), M = b({
  args: {},
  returns: e.object({
    totalUsers: e.number(),
    activeUsers: e.number(),
    totalVideos: e.number(),
    totalRoleplays: e.number(),
    recentActivities: e.array(
      e.object({
        id: e.string(),
        type: e.string(),
        description: e.string(),
        timestamp: e.number(),
        userId: e.optional(e.string()),
        userName: e.optional(e.string())
      })
    )
  }),
  handler: /* @__PURE__ */ m(async (i) => {
    await p(i);
    let [t, a, n] = await Promise.all([
      i.db.query("users").collect(),
      i.db.query("videos").collect(),
      i.db.query("roleplays").collect()
    ]), r = t.length, u = t.filter((o) => o.isActive).length, s = a.length, d = n.length, l = [
      ...a.slice(-5).map((o) => ({
        id: o._id,
        type: "video_upload",
        description: `\u52D5\u753B\u300C${o.title}\u300D\u304C\u30A2\u30C3\u30D7\u30ED\u30FC\u30C9\u3055\u308C\u307E\u3057\u305F`,
        timestamp: o._creationTime,
        userId: o.user_id,
        userName: "\u672A\u8A2D\u5B9A"
        // 実際の実装では関連するユーザー名を取得
      })),
      ...n.slice(-5).map((o) => ({
        id: o._id,
        type: "roleplay_created",
        description: `\u30ED\u30FC\u30EB\u30D7\u30EC\u30A4\u300C${o.title}\u300D\u304C\u4F5C\u6210\u3055\u308C\u307E\u3057\u305F`,
        timestamp: o._creationTime,
        userId: o.created_by,
        userName: "\u672A\u8A2D\u5B9A"
        // 実際の実装では関連するユーザー名を取得
      }))
    ].sort((o, g) => g.timestamp - o.timestamp).slice(0, 10);
    return {
      totalUsers: r,
      activeUsers: u,
      totalVideos: s,
      totalRoleplays: d,
      recentActivities: l
    };
  }, "handler")
}), $ = b({
  args: {
    limit: e.optional(e.number())
  },
  returns: e.array(
    e.object({
      id: e.string(),
      type: e.string(),
      description: e.string(),
      timestamp: e.number(),
      userId: e.optional(e.string()),
      userName: e.optional(e.string())
    })
  ),
  handler: /* @__PURE__ */ m(async (i, t) => {
    await p(i);
    let a = t.limit || 50, [n, r] = await Promise.all([
      i.db.query("videos").order("desc").take(a),
      i.db.query("roleplays").order("desc").take(a)
    ]);
    return [
      ...n.map((s) => ({
        id: s._id,
        type: "video_upload",
        description: `\u52D5\u753B\u300C${s.title}\u300D\u304C\u30A2\u30C3\u30D7\u30ED\u30FC\u30C9\u3055\u308C\u307E\u3057\u305F`,
        timestamp: s._creationTime,
        userId: s.user_id,
        userName: "\u672A\u8A2D\u5B9A"
      })),
      ...r.map((s) => ({
        id: s._id,
        type: "roleplay_created",
        description: `\u30ED\u30FC\u30EB\u30D7\u30EC\u30A4\u300C${s.title}\u300D\u304C\u4F5C\u6210\u3055\u308C\u307E\u3057\u305F`,
        timestamp: s._creationTime,
        userId: s.created_by,
        userName: "\u672A\u8A2D\u5B9A"
      }))
    ].sort((s, d) => d.timestamp - s.timestamp).slice(0, a);
  }, "handler")
}), P = b({
  args: {
    search: e.optional(e.string()),
    department: e.optional(e.string()),
    role: e.optional(e.string()),
    page: e.optional(e.number()),
    limit: e.optional(e.number())
  },
  returns: e.object({
    users: e.array(
      e.object({
        _id: e.id("users"),
        name: e.string(),
        email: e.string(),
        department: e.optional(e.string()),
        role: e.string(),
        isActive: e.boolean(),
        videoCount: e.number(),
        roleplayCount: e.number(),
        lastActivity: e.optional(e.number())
      })
    ),
    total: e.number(),
    hasMore: e.boolean()
  }),
  handler: /* @__PURE__ */ m(async (i, t) => {
    await p(i);
    let a = await i.runQuery(w.userManagement.getUsers, t);
    return {
      users: await Promise.all(
        a.users.map(async (r) => {
          let [u, s] = await Promise.all([
            i.db.query("videos").filter((l) => l.eq(l.field("user_id"), r._id)).collect(),
            i.db.query("roleplays").filter((l) => l.eq(l.field("created_by"), r._id)).collect()
          ]), d = Math.max(
            ...u.map((l) => l._creationTime),
            ...s.map((l) => l._creationTime),
            0
          );
          return {
            ...r,
            videoCount: u.length,
            roleplayCount: s.length,
            lastActivity: d > 0 ? d : void 0
          };
        })
      ),
      total: a.total,
      hasMore: a.hasMore
    };
  }, "handler")
});
export {
  $ as getAdminActivities,
  M as getAdminStats,
  C as getCurrentUser,
  D as getUsers,
  P as getUsersDashboardStats,
  T as registerUser,
  N as updateUser
};
//# sourceMappingURL=userManagement.js.map
