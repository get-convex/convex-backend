import {
  a as h,
  b as a,
  e as S
} from "./_deps/IVQGLTSC.js";
import {
  a as q,
  b as T,
  d as w,
  e as b,
  f as I
} from "./_deps/75JH2J25.js";
import "./_deps/6XQQNYIR.js";
import {
  j as t,
  n as M
} from "./_deps/3TDUHHJO.js";
import {
  a as p
} from "./_deps/RUVYHBJQ.js";

// convex/quickTranscription.ts
M();
S();
var P = w({
  args: {
    transcriptionId: t.id("transcriptions"),
    gcpFilePath: t.string(),
    publicUrl: t.string()
  },
  returns: t.null(),
  handler: /* @__PURE__ */ p(async (r, e) => {
    let n = await r.db.get(e.transcriptionId);
    if (!n)
      throw new Error("\u6587\u5B57\u8D77\u3053\u3057\u30EC\u30B3\u30FC\u30C9\u304C\u898B\u3064\u304B\u308A\u307E\u305B\u3093");
    return await r.db.patch(n.resource_id, {
      gcp_file_path: e.gcpFilePath,
      public_url: e.publicUrl,
      status: "pending",
      // アップロード準備完了状態
      uploaded_at: Date.now()
    }), null;
  }, "handler")
}), x = b({
  args: {
    filename: t.string(),
    contentType: t.string(),
    fileSize: t.number(),
    transcriptionType: t.string(),
    customPrompt: t.optional(t.string())
  },
  returns: t.object({
    transcriptionId: t.id("transcriptions"),
    uploadUrl: t.string(),
    fileUploadId: t.id("fileUploads"),
    gcpFilePath: t.string()
  }),
  handler: /* @__PURE__ */ p(async (r, e) => {
    let n = await r.auth.getUserIdentity();
    if (!n)
      throw new Error("\u8A8D\u8A3C\u304C\u5FC5\u8981\u3067\u3059");
    let i = n.email || "", { filename: c, contentType: s, fileSize: o, transcriptionType: l, customPrompt: g } = e, f = s.startsWith("audio/"), u = s.startsWith("video/");
    if (!f && !u)
      throw new Error(
        "\u30B5\u30DD\u30FC\u30C8\u3055\u308C\u3066\u3044\u306A\u3044\u30D5\u30A1\u30A4\u30EB\u5F62\u5F0F\u3067\u3059\u3002\u97F3\u58F0\u30D5\u30A1\u30A4\u30EB\u307E\u305F\u306F\u52D5\u753B\u30D5\u30A1\u30A4\u30EB\u3092\u30A2\u30C3\u30D7\u30ED\u30FC\u30C9\u3057\u3066\u304F\u3060\u3055\u3044\u3002"
      );
    let d = 2 * 1024 * 1024 * 1024;
    if (o > d)
      throw new Error(
        "\u30D5\u30A1\u30A4\u30EB\u30B5\u30A4\u30BA\u304C\u5927\u304D\u3059\u304E\u307E\u3059\u30022GB\u4EE5\u4E0B\u306E\u30D5\u30A1\u30A4\u30EB\u3092\u30A2\u30C3\u30D7\u30ED\u30FC\u30C9\u3057\u3066\u304F\u3060\u3055\u3044\u3002"
      );
    try {
      let m = "content";
      s.startsWith("video/") ? m = "video" : s.startsWith("audio/") && (m = "audio");
      let _ = await r.runMutation(a.quickTranscription.createQuickTranscriptionRecord, {
        userEmail: i,
        filename: c,
        contentType: s,
        fileSize: o,
        transcriptionType: l,
        customPrompt: g,
        folderName: m
      });
      if (!_.success)
        throw new Error(_.message);
      let y = await r.runAction(h.gcsActions.generateGCPUploadUrl, {
        filename: e.filename,
        contentType: e.contentType,
        uploadType: "quick-transcription",
        fileSize: e.fileSize
      });
      if (!_.transcriptionId)
        throw new Error("transcriptionId\u306E\u4F5C\u6210\u306B\u5931\u6557\u3057\u307E\u3057\u305F");
      if (await r.runMutation(a.quickTranscription.updateFileUploadGCPPath, {
        transcriptionId: _.transcriptionId,
        gcpFilePath: y.gcpFilePath,
        publicUrl: `https://storage.googleapis.com/${process.env.GCS_BUCKET_NAME || "ai-sales-training-hub-media"}/${y.gcpFilePath}`
      }), !_.transcriptionId || !_.fileUploadId)
        throw new Error("\u30EC\u30B3\u30FC\u30C9\u4F5C\u6210\u306B\u5931\u6557\u3057\u307E\u3057\u305F");
      return {
        transcriptionId: _.transcriptionId,
        uploadUrl: y.uploadUrl,
        fileUploadId: _.fileUploadId,
        gcpFilePath: y.gcpFilePath
      };
    } catch (m) {
      throw console.error("[generateQuickTranscriptionUploadUrl] \u30A8\u30E9\u30FC:", m), new Error(m instanceof Error ? m.message : "\u4E0D\u660E\u306A\u30A8\u30E9\u30FC\u304C\u767A\u751F\u3057\u307E\u3057\u305F");
    }
  }, "handler")
}), $ = w({
  args: {
    userEmail: t.string(),
    fileName: t.string(),
    fileType: t.string(),
    fileSize: t.number(),
    transcriptionType: t.string(),
    customPrompt: t.optional(t.string()),
    folderName: t.string()
  },
  returns: t.union(
    t.object({
      success: t.literal(!0),
      transcriptionId: t.id("transcriptions"),
      fileUploadId: t.id("fileUploads")
    }),
    t.object({
      success: t.literal(!1),
      message: t.string()
    })
  ),
  handler: /* @__PURE__ */ p(async (r, e) => {
    try {
      let n = await r.db.query("users").withIndex("by_email", (f) => f.eq("email", e.userEmail)).first();
      if (!n)
        return {
          success: !1,
          message: "User not found in unified system"
        };
      let i = Date.now(), c = Math.random().toString(36).substring(2, 15), s = encodeURIComponent(e.fileName).replace(/%/g, "_").substring(0, 100), o = `${e.folderName}/${i}-${c}-${s}`, l = await r.db.insert("fileUploads", {
        user_id: n._id,
        original_filename: e.fileName,
        content_type: e.fileType,
        file_size: e.fileSize,
        gcp_file_path: o,
        upload_type: "quick_transcription",
        status: "preparing",
        related_resource_type: "quick_transcription",
        uploaded_at: Date.now()
      }), g = await r.db.insert("transcriptions", {
        resource_type: "quick_transcription",
        resource_id: l,
        status: "pending",
        text: "",
        quick_transcription: {
          original_filename: e.fileName,
          file_size: e.fileSize,
          temporary: !0,
          expires_at: Date.now() + 24 * 60 * 60 * 1e3,
          // 24時間後に期限切れ
          transcription_type: e.transcriptionType,
          custom_prompt: e.customPrompt
        },
        created_at: Date.now(),
        updated_at: Date.now()
      });
      return await r.db.patch(l, {
        related_resource_id: g
      }), {
        success: !0,
        transcriptionId: g,
        fileUploadId: l
      };
    } catch (n) {
      return {
        success: !1,
        message: n instanceof Error ? n.message : "\u4E0D\u660E\u306A\u30A8\u30E9\u30FC"
      };
    }
  }, "handler")
}), C = w({
  args: {
    userEmail: t.string(),
    filename: t.string(),
    contentType: t.string(),
    fileSize: t.number(),
    transcriptionType: t.string(),
    customPrompt: t.optional(t.string()),
    folderName: t.string()
  },
  returns: t.union(
    t.object({
      success: t.literal(!0),
      transcriptionId: t.id("transcriptions"),
      fileUploadId: t.id("fileUploads")
    }),
    t.object({
      success: t.literal(!1),
      message: t.string()
    })
  ),
  handler: /* @__PURE__ */ p(async (r, e) => {
    try {
      let n = await r.db.query("users").withIndex("by_email", (f) => f.eq("email", e.userEmail)).first();
      if (!n)
        return {
          success: !1,
          message: "User not found in unified system"
        };
      let i = Date.now(), c = Math.random().toString(36).substring(2, 15), s = encodeURIComponent(e.filename).replace(/%/g, "_").substring(0, 100), o = `${e.folderName}/${i}-${c}-${s}`, l = await r.db.insert("fileUploads", {
        user_id: n._id,
        original_filename: e.filename,
        content_type: e.contentType,
        file_size: e.fileSize,
        gcp_file_path: o,
        upload_type: "quick_transcription",
        status: "preparing",
        related_resource_type: "quick_transcription",
        uploaded_at: Date.now()
      }), g = await r.db.insert("transcriptions", {
        resource_type: "quick_transcription",
        resource_id: l,
        status: "pending",
        text: "",
        quick_transcription: {
          original_filename: e.filename,
          file_size: e.fileSize,
          temporary: !0,
          expires_at: Date.now() + 24 * 60 * 60 * 1e3,
          // 24時間後に期限切れ
          transcription_type: e.transcriptionType,
          custom_prompt: e.customPrompt
        },
        created_at: Date.now(),
        updated_at: Date.now()
      });
      return await r.db.patch(l, {
        related_resource_id: g
      }), {
        success: !0,
        transcriptionId: g,
        fileUploadId: l
      };
    } catch (n) {
      return {
        success: !1,
        message: n instanceof Error ? n.message : "\u4E0D\u660E\u306A\u30A8\u30E9\u30FC"
      };
    }
  }, "handler")
}), D = I({
  args: {
    transcriptionId: t.id("transcriptions"),
    gcpFilePath: t.string(),
    fileUploadId: t.optional(t.id("fileUploads")),
    uploadUrl: t.optional(t.string())
    // アップロード時の署名付きURLを保持
  },
  returns: t.null(),
  handler: /* @__PURE__ */ p(async (r, e) => (await r.runMutation(a.uploads.completeGCSUploadForQuickTranscription, e), await r.scheduler.runAfter(0, a.quickTranscription.processTranscriptionFromGCS, {
    transcriptionId: e.transcriptionId,
    gcpFilePath: e.gcpFilePath,
    fileUploadId: e.fileUploadId,
    uploadUrl: e.uploadUrl
  }), null), "handler")
}), A = I({
  args: {
    transcriptionId: t.id("transcriptions"),
    storageId: t.id("_storage")
  },
  returns: t.null(),
  handler: /* @__PURE__ */ p(async (r, e) => {
    try {
      let n = await r.runQuery(
        a.quickTranscription.getTranscriptionForProcessing,
        {
          transcriptionId: e.transcriptionId
        }
      );
      if (!n)
        throw new Error("\u6587\u5B57\u8D77\u3053\u3057\u30EC\u30B3\u30FC\u30C9\u304C\u898B\u3064\u304B\u308A\u307E\u305B\u3093");
      if (!n.quick_transcription)
        throw new Error("\u30AF\u30A4\u30C3\u30AF\u6587\u5B57\u8D77\u3053\u3057\u60C5\u5831\u304C\u898B\u3064\u304B\u308A\u307E\u305B\u3093");
      let i = await r.storage.getUrl(e.storageId);
      if (!i)
        throw new Error("\u30D5\u30A1\u30A4\u30EB\u304C\u898B\u3064\u304B\u308A\u307E\u305B\u3093");
      if (console.log("Convex Storage\u304B\u3089\u76F4\u63A5\u6587\u5B57\u8D77\u3053\u3057\u51E6\u7406\u958B\u59CB:", i), !n || !n.resource_id)
        return null;
      let c = await r.runQuery(a.quickTranscription.getFileUpload, {
        fileUploadId: n.resource_id
      });
      if (!c)
        throw new Error("\u30D5\u30A1\u30A4\u30EB\u30A2\u30C3\u30D7\u30ED\u30FC\u30C9\u60C5\u5831\u304C\u898B\u3064\u304B\u308A\u307E\u305B\u3093");
      console.log("\u6587\u5B57\u8D77\u3053\u3057\u51E6\u7406\u958B\u59CB:", c.original_filename), console.log("\u52D5\u753B\u30A2\u30C3\u30D7\u30ED\u30FC\u30C9\u3068\u540C\u3058Node.js\u30A2\u30AF\u30B7\u30E7\u30F3\u7D4C\u7531\u3067\u306E\u6587\u5B57\u8D77\u3053\u3057\u51E6\u7406\u3092\u958B\u59CB:", i);
      let s = Date.now(), o = await r.runAction(h.transcriptionActions.performElevenLabsTranscription, {
        fileUrl: i,
        fileType: c.content_type,
        options: {
          enableSpeakerDiarization: n.quick_transcription.transcription_type !== "standard",
          language: "ja"
        }
      });
      console.log(`ElevenLabs API\u51E6\u7406\u5B8C\u4E86: ${o.text.length}\u6587\u5B57`);
      let l = Date.now() - s, g = o.text, u = o.segments;
      if (u && Array.isArray(u)) {
        console.log(
          `[processTranscriptionFromConvexStorage] \u5143\u306E\u30BB\u30B0\u30E1\u30F3\u30C8\u6570: ${u.length}`
        );
        let d = 8e3;
        if (u.length > d)
          console.warn(
            `[processTranscriptionFromConvexStorage] \u30BB\u30B0\u30E1\u30F3\u30C8\u6570\u304CConvex\u5236\u9650\u3092\u8D85\u904E (${u.length} > ${d})`
          ), console.warn(
            "[processTranscriptionFromConvexStorage] \u5927\u5BB9\u91CF\u30D5\u30A1\u30A4\u30EB\u306E\u305F\u3081\u3001\u30BB\u30B0\u30E1\u30F3\u30C8\u30C7\u30FC\u30BF\u3092\u4FDD\u5B58\u3057\u307E\u305B\u3093\uFF08\u30C6\u30AD\u30B9\u30C8\u306E\u307F\u4FDD\u5B58\uFF09"
          ), u = void 0;
        else if (u.length > 7e3) {
          console.log(
            `[processTranscriptionFromConvexStorage] \u30BB\u30B0\u30E1\u30F3\u30C8\u6570\u304C\u591A\u3081\u3067\u3059 (${u.length}), \u9593\u5F15\u304D\u51E6\u7406\u3092\u5B9F\u884C`
          );
          let m = 7e3, _ = Math.ceil(u.length / m), y = [];
          for (let k = 0; k < u.length && !(y.length >= m); k += _)
            y.push(u[k]);
          u = y, console.log(
            `[processTranscriptionFromConvexStorage] \u30BB\u30B0\u30E1\u30F3\u30C8\u6570\u3092${u.length}\u306B\u524A\u6E1B\u3057\u307E\u3057\u305F\uFF08step: ${_}\uFF09`
          );
        } else
          console.log(
            `[processTranscriptionFromConvexStorage] \u30BB\u30B0\u30E1\u30F3\u30C8\u6570\u306F\u5236\u9650\u5185\u3067\u3059 (${u.length})`
          );
      }
      n?.quick_transcription?.transcription_type === "custom" && n?.quick_transcription?.custom_prompt && (g = `${n?.quick_transcription?.custom_prompt}

${g}`), await r.runMutation(a.quickTranscription.saveTranscriptionResult, {
        transcriptionId: e.transcriptionId,
        text: g,
        segments: u,
        processingDuration: l,
        confidenceScore: o.confidence?.toString() || "0.9"
        // ElevenLabsの信頼度スコアを使用
      }), await r.scheduler.runAfter(0, a.quickTranscription.generateQuickMinutes, {
        transcriptionId: e.transcriptionId
      });
    } catch (n) {
      console.error("Convex Storage Quick transcription processing error:", n), await r.runMutation(a.quickTranscription.markTranscriptionFailed, {
        transcriptionId: e.transcriptionId,
        errorMessage: n instanceof Error ? n.message : "\u4E0D\u660E\u306A\u30A8\u30E9\u30FC\u304C\u767A\u751F\u3057\u307E\u3057\u305F"
      });
    }
    return null;
  }, "handler")
}), v = I({
  args: {
    transcriptionId: t.id("transcriptions"),
    gcpFilePath: t.string(),
    fileUploadId: t.optional(t.id("fileUploads")),
    uploadUrl: t.optional(t.string())
    // アップロード時の署名付きURLを受け取る
  },
  returns: t.null(),
  handler: /* @__PURE__ */ p(async (r, e) => {
    try {
      let n = await r.runQuery(
        a.quickTranscription.getTranscriptionForProcessing,
        {
          transcriptionId: e.transcriptionId
        }
      );
      if (!n)
        throw new Error("\u6587\u5B57\u8D77\u3053\u3057\u30EC\u30B3\u30FC\u30C9\u304C\u898B\u3064\u304B\u308A\u307E\u305B\u3093");
      if (!n.quick_transcription)
        throw new Error("\u30AF\u30A4\u30C3\u30AF\u6587\u5B57\u8D77\u3053\u3057\u60C5\u5831\u304C\u898B\u3064\u304B\u308A\u307E\u305B\u3093");
      let i = "audio/m4a";
      if (e.fileUploadId) {
        let o = await r.runQuery(a.quickTranscription.getFileUpload, {
          fileUploadId: e.fileUploadId
        });
        o && o.content_type && (i = o.content_type, console.log("\u30D5\u30A1\u30A4\u30EB\u30A2\u30C3\u30D7\u30ED\u30FC\u30C9\u60C5\u5831\u304B\u3089\u53D6\u5F97\u3057\u305F\u30D5\u30A1\u30A4\u30EB\u30BF\u30A4\u30D7:", i));
      }
      console.log("GCS\u304B\u3089\u6587\u5B57\u8D77\u3053\u3057\u51E6\u7406\u958B\u59CB - \u7F72\u540D\u4ED8\u304DURL\u751F\u6210\u4E2D:", e.gcpFilePath);
      let c = Date.now(), s;
      try {
        console.log("GCS\u8AAD\u307F\u53D6\u308A\u5C02\u7528\u7F72\u540D\u4ED8\u304DURL\u751F\u6210\u958B\u59CB:", e.gcpFilePath);
        let o = await r.runAction(h.gcsActions.generateGCPReadUrl, {
          gcpFilePath: e.gcpFilePath,
          expirationMinutes: 120
          // 2時間有効
        });
        !o.success || !o.readUrl ? (console.warn("\u7F72\u540D\u4ED8\u304DURL\u751F\u6210\u306B\u5931\u6557\u3057\u307E\u3057\u305F\u3002\u30D1\u30D6\u30EA\u30C3\u30AFURL\u306B\u30D5\u30A9\u30FC\u30EB\u30D0\u30C3\u30AF"), s = `https://storage.googleapis.com/${process.env.GCS_BUCKET_NAME || "ai-sales-hub-dev-new_dify-ai-sales-hub-dev-new"}/${e.gcpFilePath}`) : (s = o.readUrl, console.log("\u7F72\u540D\u4ED8\u304DURL\u751F\u6210\u6210\u529F:", {
          expiresAt: o.expiresAt,
          urlLength: s.length
        }));
        let l = await r.runAction(h.transcriptionActions.performElevenLabsTranscription, {
          fileUrl: s,
          fileType: i,
          options: {
            enableSpeakerDiarization: n.quick_transcription.transcription_type !== "standard",
            language: "ja"
          }
        });
        console.log(`ElevenLabs API\u51E6\u7406\u5B8C\u4E86: ${l.text.length}\u6587\u5B57`);
        let g = Date.now() - c, f = l.text, d = l.segments;
        if (d && Array.isArray(d)) {
          console.log(
            `[processTranscriptionFromGCS] \u5143\u306E\u30BB\u30B0\u30E1\u30F3\u30C8\u6570: ${d.length}`
          );
          let m = 8e3;
          if (d.length > m)
            console.warn(
              `[processTranscriptionFromGCS] \u30BB\u30B0\u30E1\u30F3\u30C8\u6570\u304CConvex\u5236\u9650\u3092\u8D85\u904E (${d.length} > ${m})`
            ), console.warn(
              "[processTranscriptionFromGCS] \u5927\u5BB9\u91CF\u30D5\u30A1\u30A4\u30EB\u306E\u305F\u3081\u3001\u30BB\u30B0\u30E1\u30F3\u30C8\u30C7\u30FC\u30BF\u3092\u4FDD\u5B58\u3057\u307E\u305B\u3093\uFF08\u30C6\u30AD\u30B9\u30C8\u306E\u307F\u4FDD\u5B58\uFF09"
            ), d = void 0;
          else if (d.length > 7e3) {
            console.log(
              `[processTranscriptionFromGCS] \u30BB\u30B0\u30E1\u30F3\u30C8\u6570\u304C\u591A\u3081\u3067\u3059 (${d.length}), \u9593\u5F15\u304D\u51E6\u7406\u3092\u5B9F\u884C`
            );
            let _ = 7e3, y = Math.ceil(d.length / _), k = [];
            for (let U = 0; U < d.length && !(k.length >= _); U += y)
              k.push(d[U]);
            d = k, console.log(
              `[processTranscriptionFromGCS] \u30BB\u30B0\u30E1\u30F3\u30C8\u6570\u3092${d.length}\u306B\u524A\u6E1B\u3057\u307E\u3057\u305F\uFF08step: ${y}\uFF09`
            );
          } else
            console.log(
              `[processTranscriptionFromGCS] \u30BB\u30B0\u30E1\u30F3\u30C8\u6570\u306F\u5236\u9650\u5185\u3067\u3059 (${d.length})`
            );
        }
        n?.quick_transcription?.transcription_type === "custom" && n?.quick_transcription?.custom_prompt && (f = `${n?.quick_transcription?.custom_prompt}

${f}`), await r.runMutation(a.quickTranscription.saveTranscriptionResult, {
          transcriptionId: e.transcriptionId,
          text: f,
          segments: d,
          processingDuration: g,
          confidenceScore: l.confidence?.toString() || "0.9"
          // ElevenLabsの信頼度スコアを使用
        }), await r.scheduler.runAfter(0, a.quickTranscription.generateQuickMinutes, {
          transcriptionId: e.transcriptionId
        });
      } catch (o) {
        console.error("GCS Quick transcription processing error:", o), await r.runMutation(a.quickTranscription.markTranscriptionFailed, {
          transcriptionId: e.transcriptionId,
          errorMessage: o instanceof Error ? o.message : "\u4E0D\u660E\u306A\u30A8\u30E9\u30FC\u304C\u767A\u751F\u3057\u307E\u3057\u305F"
        });
      }
    } catch (n) {
      throw console.error("processTranscriptionFromGCS outer error:", n), n;
    }
    return null;
  }, "handler")
}), R = w({
  args: {
    transcriptionId: t.id("transcriptions"),
    text: t.string(),
    segments: t.optional(
      t.array(
        t.object({
          start: t.number(),
          end: t.number(),
          text: t.string(),
          speaker: t.optional(t.string()),
          confidence: t.optional(t.number())
        })
      )
    ),
    // 文字起こしセグメント配列
    processingDuration: t.number(),
    confidenceScore: t.string()
  },
  returns: t.null(),
  handler: /* @__PURE__ */ p(async (r, e) => {
    let n = e.segments;
    return Array.isArray(n) && n.length > 8e3 && (console.warn(
      `[saveTranscriptionResult] Segments array too large (${n.length}), excluding from database storage for large files`
    ), n = void 0), await r.db.patch(e.transcriptionId, {
      status: "completed",
      text: e.text,
      segments: n,
      processing_duration_ms: e.processingDuration,
      confidence_score: e.confidenceScore,
      updated_at: Date.now()
    }), null;
  }, "handler")
}), G = w({
  args: {
    transcriptionId: t.id("transcriptions"),
    errorMessage: t.string()
  },
  returns: t.null(),
  handler: /* @__PURE__ */ p(async (r, e) => (await r.db.patch(e.transcriptionId, {
    status: "failed",
    error_message: e.errorMessage,
    updated_at: Date.now()
  }), null), "handler")
}), j = T({
  args: {
    transcriptionId: t.id("transcriptions")
  },
  returns: t.union(
    t.object({
      _id: t.id("transcriptions"),
      _creationTime: t.number(),
      resource_type: t.string(),
      resource_id: t.string(),
      status: t.string(),
      text: t.string(),
      created_at: t.optional(t.number()),
      updated_at: t.optional(t.number()),
      // 文字起こし処理結果の追加フィールド
      confidence_score: t.optional(t.string()),
      processing_duration_ms: t.optional(t.number()),
      error_message: t.optional(t.string()),
      segments: t.optional(
        t.array(
          t.object({
            start: t.number(),
            end: t.number(),
            text: t.string(),
            speaker: t.optional(t.string()),
            confidence: t.optional(t.number())
          })
        )
      ),
      // GCSファイルURL追加
      original_file_url: t.optional(t.string()),
      quick_transcription: t.optional(
        t.object({
          original_filename: t.string(),
          file_size: t.number(),
          duration_seconds: t.optional(t.number()),
          temporary: t.boolean(),
          expires_at: t.optional(t.number()),
          transcription_type: t.string(),
          custom_prompt: t.optional(t.string()),
          // 議事録関連フィールド（処理用クエリでも必要）
          meeting_minutes: t.optional(
            t.object({
              summary: t.string(),
              keyPoints: t.string(),
              actionItems: t.string(),
              participants: t.string(),
              duration: t.string()
            })
          ),
          meeting_minutes_status: t.optional(
            t.union(
              t.literal("pending"),
              t.literal("processing"),
              t.literal("completed"),
              t.literal("failed")
            )
          ),
          meeting_minutes_generated_at: t.optional(t.number()),
          transcript_with_speaker: t.optional(t.string())
        })
      )
    }),
    t.null()
  ),
  handler: /* @__PURE__ */ p(async (r, e) => await r.db.get(e.transcriptionId), "handler")
}), z = q({
  args: {
    transcriptionId: t.id("transcriptions")
  },
  returns: t.union(
    t.object({
      _id: t.id("transcriptions"),
      _creationTime: t.number(),
      resource_id: t.string(),
      resource_type: t.string(),
      status: t.string(),
      text: t.string(),
      segments: t.optional(
        t.array(
          t.object({
            start: t.number(),
            end: t.number(),
            text: t.string(),
            speaker: t.optional(t.string()),
            confidence: t.optional(t.number())
          })
        )
      ),
      quick_transcription: t.optional(
        t.object({
          original_filename: t.string(),
          file_size: t.number(),
          duration_seconds: t.optional(t.number()),
          temporary: t.boolean(),
          expires_at: t.optional(t.number()),
          transcription_type: t.string(),
          custom_prompt: t.optional(t.string()),
          // 議事録関連フィールド
          meeting_minutes: t.optional(
            t.object({
              summary: t.string(),
              keyPoints: t.string(),
              actionItems: t.string(),
              participants: t.string(),
              duration: t.string()
            })
          ),
          meeting_minutes_status: t.optional(
            t.union(
              t.literal("pending"),
              t.literal("processing"),
              t.literal("completed"),
              t.literal("failed")
            )
          ),
          meeting_minutes_generated_at: t.optional(t.number()),
          transcript_with_speaker: t.optional(t.string())
        })
      ),
      error_message: t.optional(t.string()),
      processing_duration_ms: t.optional(t.number()),
      confidence_score: t.optional(t.string()),
      created_at: t.optional(t.number()),
      updated_at: t.optional(t.number()),
      original_file_url: t.optional(t.string())
    }),
    t.null()
  ),
  handler: /* @__PURE__ */ p(async (r, e) => {
    if (!await r.auth.getUserIdentity())
      throw new Error("\u8A8D\u8A3C\u304C\u5FC5\u8981\u3067\u3059");
    let i = await r.db.get(e.transcriptionId);
    if (!i)
      return null;
    if (i.resource_type !== "quick_transcription")
      throw new Error("\u30AF\u30A4\u30C3\u30AF\u6587\u5B57\u8D77\u3053\u3057\u4EE5\u5916\u306E\u30EC\u30B3\u30FC\u30C9\u3067\u3059");
    return i;
  }, "handler")
}), N = T({
  args: {
    limit: t.optional(t.number())
  },
  returns: t.array(
    t.object({
      _id: t.id("transcriptions"),
      status: t.string(),
      quick_transcription: t.optional(
        t.object({
          original_filename: t.string(),
          transcription_type: t.string(),
          temporary: t.boolean(),
          expires_at: t.optional(t.number())
        })
      ),
      created_at: t.optional(t.number())
    })
  ),
  handler: /* @__PURE__ */ p(async (r, e) => {
    let n = await r.auth.getUserIdentity();
    if (!n)
      throw new Error("\u8A8D\u8A3C\u304C\u5FC5\u8981\u3067\u3059");
    let i = await r.db.query("users").withIndex("by_clerk_user_id", (o) => o.eq("clerkUserId", n.subject)).unique();
    if (!i)
      throw new Error("\u30E6\u30FC\u30B6\u30FC\u304C\u898B\u3064\u304B\u308A\u307E\u305B\u3093");
    let c = await r.db.query("transcriptions").withIndex("by_resource_type", (o) => o.eq("resource_type", "quick_transcription")).order("desc").take(e.limit || 20), s = [];
    for (let o of c)
      try {
        let l = await r.db.get(o.resource_id);
        l && l.user_id === i._id && s.push(o);
      } catch {
        continue;
      }
    return s;
  }, "handler")
}), L = b({
  args: {},
  returns: t.null(),
  handler: /* @__PURE__ */ p(async (r) => {
    let e = Date.now(), n = await r.runQuery(
      a.quickTranscription.getExpiredTranscriptions,
      {
        currentTime: e
      }
    );
    for (let i of n)
      try {
        let c = await r.runQuery(a.quickTranscription.getFileUpload, {
          fileUploadId: i.resource_id
        });
        c && c.storage_id && await r.storage.delete(c.storage_id), await r.runMutation(a.quickTranscription.deleteTranscription, {
          transcriptionId: i._id,
          fileUploadId: i.resource_id
        });
      } catch (c) {
        console.error(`Failed to cleanup transcription ${i._id}:`, c);
      }
    return null;
  }, "handler")
}), W = T({
  args: {
    currentTime: t.number()
  },
  returns: t.array(
    t.object({
      _id: t.id("transcriptions"),
      resource_id: t.string()
    })
  ),
  handler: /* @__PURE__ */ p(async (r, e) => (await r.db.query("transcriptions").withIndex("by_resource_type", (i) => i.eq("resource_type", "quick_transcription")).collect()).filter(
    (i) => i.quick_transcription !== void 0 && i.quick_transcription.temporary === !0 && i.quick_transcription.expires_at !== void 0 && typeof i.quick_transcription.expires_at == "number" && i.quick_transcription.expires_at < e.currentTime
  ), "handler")
}), B = b({
  args: {
    transcriptionId: t.id("transcriptions"),
    storageId: t.id("_storage")
  },
  returns: t.null(),
  handler: /* @__PURE__ */ p(async (r, e) => {
    if (!await r.auth.getUserIdentity())
      throw new Error("\u8A8D\u8A3C\u304C\u5FC5\u8981\u3067\u3059");
    return await r.runMutation(a.quickTranscription.completeFileUploadInternal, e);
  }, "handler")
}), K = b({
  args: {
    transcriptionId: t.id("transcriptions"),
    fileUploadId: t.id("fileUploads")
  },
  returns: t.null(),
  handler: /* @__PURE__ */ p(async (r, e) => {
    if (!await r.auth.getUserIdentity())
      throw new Error("\u8A8D\u8A3C\u304C\u5FC5\u8981\u3067\u3059");
    let i = await r.runQuery(a.quickTranscription.getFileUpload, {
      fileUploadId: e.fileUploadId
    });
    if (!i)
      throw new Error("\u30D5\u30A1\u30A4\u30EB\u30A2\u30C3\u30D7\u30ED\u30FC\u30C9\u60C5\u5831\u304C\u898B\u3064\u304B\u308A\u307E\u305B\u3093");
    if (!i.gcp_file_path)
      throw new Error("GCP\u30D5\u30A1\u30A4\u30EB\u30D1\u30B9\u304C\u8A2D\u5B9A\u3055\u308C\u3066\u3044\u307E\u305B\u3093");
    return await r.runAction(a.quickTranscription.completeGCSUpload, {
      transcriptionId: e.transcriptionId,
      gcpFilePath: i.gcp_file_path,
      // uploadUrlは署名付きURLを含む
      uploadUrl: void 0
      // 現在は利用できない
    }), null;
  }, "handler")
}), V = I({
  args: {
    transcriptionId: t.id("transcriptions"),
    storageId: t.id("_storage")
  },
  returns: t.null(),
  handler: /* @__PURE__ */ p(async (r, e) => (await r.runMutation(a.uploads.completeFileUploadForQuickTranscription, e), null), "handler")
}), H = T({
  args: {
    fileUploadId: t.id("fileUploads")
  },
  returns: t.any(),
  handler: /* @__PURE__ */ p(async (r, e) => await r.db.get(e.fileUploadId), "handler")
}), J = w({
  args: {
    transcriptionId: t.id("transcriptions"),
    fileUploadId: t.id("fileUploads")
  },
  returns: t.null(),
  handler: /* @__PURE__ */ p(async (r, e) => (await r.db.delete(e.transcriptionId), await r.db.delete(e.fileUploadId), null), "handler")
}), O = w({
  args: {
    transcriptionId: t.id("transcriptions"),
    storageId: t.id("_storage")
  },
  returns: t.null(),
  handler: /* @__PURE__ */ p(async (r, e) => (await r.db.patch(e.transcriptionId, {
    resource_id: e.storageId,
    updated_at: Date.now()
  }), null), "handler")
}), X = I({
  args: {
    transcriptionId: t.id("transcriptions")
  },
  returns: t.null(),
  handler: /* @__PURE__ */ p(async (r, e) => {
    console.log(
      "\u{1F525} [generateQuickMinutes] Starting quick minutes generation for:",
      e.transcriptionId
    );
    try {
      let n = await r.runQuery(
        a.quickTranscription.getTranscriptionForProcessing,
        {
          transcriptionId: e.transcriptionId
        }
      );
      if (!n)
        throw new Error("\u6587\u5B57\u8D77\u3053\u3057\u30EC\u30B3\u30FC\u30C9\u304C\u898B\u3064\u304B\u308A\u307E\u305B\u3093");
      if (!n.quick_transcription)
        throw new Error("\u30AF\u30A4\u30C3\u30AF\u6587\u5B57\u8D77\u3053\u3057\u60C5\u5831\u304C\u898B\u3064\u304B\u308A\u307E\u305B\u3093");
      if (!n.text || n.text.length < 10)
        return console.warn("\u6587\u5B57\u8D77\u3053\u3057\u30C6\u30AD\u30B9\u30C8\u304C\u77ED\u3059\u304E\u308B\u305F\u3081\u3001\u8B70\u4E8B\u9332\u751F\u6210\u3092\u30B9\u30AD\u30C3\u30D7\u3057\u307E\u3059"), null;
      console.log("[generateQuickMinutes] \u8B70\u4E8B\u9332\u751F\u6210\u958B\u59CB - \u6587\u5B57\u8D77\u3053\u3057\u30BF\u30A4\u30D7:", n.quick_transcription.transcription_type), await r.runMutation(a.quickTranscription.updateQuickMinutesStatus, {
        transcriptionId: e.transcriptionId,
        status: "processing"
      }), console.log(`[generateQuickMinutes] \u30C6\u30F3\u30D7\u30EC\u30FC\u30C8\u53D6\u5F97\u958B\u59CB: transcription_type=${n.quick_transcription.transcription_type}`);
      let i = null, c = null;
      try {
        c = await r.runQuery(h.transcriptionTypes.getTranscriptionTypeByKey, {
          key: n.quick_transcription.transcription_type
        });
      } catch (s) {
        console.warn("\u30C7\u30FC\u30BF\u30D9\u30FC\u30B9\u304B\u3089\u30C6\u30F3\u30D7\u30EC\u30FC\u30C8\u53D6\u5F97\u306B\u5931\u6557:", s);
      }
      if (c?.template)
        i = c.template, console.log("[generateQuickMinutes] \u30C7\u30FC\u30BF\u30D9\u30FC\u30B9\u304B\u3089\u30C6\u30F3\u30D7\u30EC\u30FC\u30C8\u3092\u53D6\u5F97");
      else if (c?.prompt)
        i = c.prompt, console.log("[generateQuickMinutes] \u30C7\u30FC\u30BF\u30D9\u30FC\u30B9\u304B\u3089\u30D7\u30ED\u30F3\u30D7\u30C8\u3092\u53D6\u5F97");
      else {
        console.warn(`[generateQuickMinutes] \u30C7\u30FC\u30BF\u30D9\u30FC\u30B9\u306B\u30C6\u30F3\u30D7\u30EC\u30FC\u30C8\u304C\u898B\u3064\u304B\u308A\u307E\u305B\u3093: ${n.quick_transcription.transcription_type}`);
        let { getQuickMinutesPrompt: s } = await import("./lib/quickMinutesPrompts.js");
        i = s(
          n.quick_transcription.transcription_type,
          n.quick_transcription.custom_prompt
        ), console.log("[generateQuickMinutes] \u30CF\u30FC\u30C9\u30B3\u30FC\u30C9\u30D7\u30ED\u30F3\u30D7\u30C8\u3092\u4F7F\u7528");
      }
      if (!i || i.trim().length === 0) {
        console.warn(`[generateQuickMinutes] meetingMinutesTemplate\u304Cnull\u307E\u305F\u306F\u7A7A\u3067\u3059\u3002transcription_type: ${n.quick_transcription.transcription_type}`);
        let s = null;
        try {
          s = await r.runQuery(h.transcriptionTypes.getTranscriptionTypeByKey, {
            key: "standard"
          });
        } catch (o) {
          console.warn("\u6A19\u6E96\u30D5\u30A9\u30FC\u30DE\u30C3\u30C8\u53D6\u5F97\u306B\u5931\u6557:", o);
        }
        if (s?.template || s?.prompt)
          i = s.template || s.prompt, console.log("[generateQuickMinutes] \u30C7\u30FC\u30BF\u30D9\u30FC\u30B9\u304B\u3089\u6A19\u6E96\u30D5\u30A9\u30FC\u30DE\u30C3\u30C8\u3092\u53D6\u5F97");
        else {
          let { getQuickMinutesPrompt: o } = await import("./lib/quickMinutesPrompts.js");
          i = o("standard", void 0), console.log("[generateQuickMinutes] \u30CF\u30FC\u30C9\u30B3\u30FC\u30C9\u6A19\u6E96\u30D5\u30A9\u30FC\u30DE\u30C3\u30C8\u3092\u4F7F\u7528");
        }
      }
      if (!i)
        throw new Error(
          "meetingMinutesTemplate\u306E\u53D6\u5F97\u306B\u5931\u6557\u3057\u307E\u3057\u305F\u3002\u30C7\u30FC\u30BF\u30D9\u30FC\u30B9\u3068\u30CF\u30FC\u30C9\u30B3\u30FC\u30C9\u4E21\u65B9\u3067\u6A19\u6E96\u30D5\u30A9\u30FC\u30DE\u30C3\u30C8\u304C\u5229\u7528\u3067\u304D\u307E\u305B\u3093\u3002"
        );
      console.log(`[generateQuickMinutes] \u6700\u7D42\u30C6\u30F3\u30D7\u30EC\u30FC\u30C8\u53D6\u5F97\u5B8C\u4E86 (\u9577\u3055: ${i.length}\u6587\u5B57)`);
      try {
        await r.runMutation(h.transcriptionTypes.incrementUsageCountByKey, {
          key: n.quick_transcription.transcription_type
        }), console.log(`[generateQuickMinutes] \u4F7F\u7528\u56DE\u6570\u3092\u66F4\u65B0: ${n.quick_transcription.transcription_type}`);
      } catch (s) {
        console.warn("[generateQuickMinutes] \u4F7F\u7528\u56DE\u6570\u66F4\u65B0\u306B\u5931\u6557:", s);
      }
      if (!n.text || n.text.trim().length === 0)
        throw new Error("\u6587\u5B57\u8D77\u3053\u3057\u30C6\u30AD\u30B9\u30C8\u304C\u7A7A\u3067\u3059\u3002\u8B70\u4E8B\u9332\u751F\u6210\u3092\u5B9F\u884C\u3067\u304D\u307E\u305B\u3093\u3002");
      console.log("[generateQuickMinutes] Vertex AI \u3092\u4F7F\u7528\u3057\u3066\u8B70\u4E8B\u9332\u751F\u6210\u3092\u958B\u59CB"), console.log("[generateQuickMinutes] \u6587\u5B57\u8D77\u3053\u3057\u30C6\u30AD\u30B9\u30C8:", n.text ? n.text.length + "\u6587\u5B57" : "null");
      try {
        let { generateMeetingMinutes: s, addSpeakersToTranscript: o } = await import("./_deps/BLZNFBTP.js"), l = await o(n.text);
        console.log("[generateQuickMinutes] \u8A71\u8005\u4ED8\u304D\u6587\u5B57\u8D77\u3053\u3057\u751F\u6210\u5B8C\u4E86");
        let g = await s(l, {
          temperature: 0.2,
          maxTokens: 3072
        });
        console.log("[generateQuickMinutes] Vertex AI \u306B\u3088\u308B\u51E6\u7406\u5B8C\u4E86");
        let f = {
          summary: g.summary || "\u8B70\u4E8B\u9332\u306E\u751F\u6210\u306B\u5931\u6557\u3057\u307E\u3057\u305F",
          participants: g.participants || "",
          actionItems: g.actionItems || "",
          keyPoints: g.keyPoints || "",
          duration: g.duration || ""
        };
        console.log("[generateQuickMinutes] \u8B70\u4E8B\u9332\u30C7\u30FC\u30BF\u62BD\u51FA\u5B8C\u4E86:", {
          hasMeetingMinutes: !0,
          hasTranscriptWithSpeaker: !0
        });
        let u = Date.now();
        await r.runMutation(a.quickTranscription.saveQuickMinutesResult, {
          transcriptionId: e.transcriptionId,
          meetingMinutes: f,
          transcriptWithSpeaker: l,
          processingDuration: Date.now() - u
        }), console.log("[generateQuickMinutes] \u8B70\u4E8B\u9332\u751F\u6210\u5B8C\u4E86");
      } catch (s) {
        throw s;
      }
    } catch (n) {
      console.error("[generateQuickMinutes] \u8B70\u4E8B\u9332\u751F\u6210\u30A8\u30E9\u30FC:", n), await r.runMutation(a.quickTranscription.updateQuickMinutesStatus, {
        transcriptionId: e.transcriptionId,
        status: "failed",
        errorMessage: n instanceof Error ? n.message : "\u4E0D\u660E\u306A\u30A8\u30E9\u30FC\u304C\u767A\u751F\u3057\u307E\u3057\u305F"
      });
    }
    return null;
  }, "handler")
}), Y = w({
  args: {
    transcriptionId: t.id("transcriptions"),
    status: t.union(
      t.literal("pending"),
      t.literal("processing"),
      t.literal("completed"),
      t.literal("failed")
    ),
    errorMessage: t.optional(t.string())
  },
  returns: t.null(),
  handler: /* @__PURE__ */ p(async (r, e) => {
    let n = await r.db.get(e.transcriptionId);
    if (!n || !n.quick_transcription)
      return null;
    let i = {
      quick_transcription: {
        ...n.quick_transcription,
        meeting_minutes_status: e.status,
        meeting_minutes_generated_at: e.status === "completed" ? Date.now() : n.quick_transcription.meeting_minutes_generated_at
      },
      updated_at: Date.now()
    };
    return e.status === "failed" && e.errorMessage && (i.error_message = e.errorMessage), await r.db.patch(e.transcriptionId, i), null;
  }, "handler")
}), Z = w({
  args: {
    transcriptionId: t.id("transcriptions"),
    meetingMinutes: t.union(
      t.object({
        summary: t.string(),
        keyPoints: t.string(),
        actionItems: t.string(),
        participants: t.string(),
        duration: t.string()
      }),
      t.null()
    ),
    transcriptWithSpeaker: t.optional(t.string()),
    processingDuration: t.number()
  },
  returns: t.null(),
  handler: /* @__PURE__ */ p(async (r, e) => {
    let n = await r.db.get(e.transcriptionId);
    if (!n || !n.quick_transcription)
      throw new Error("\u30AF\u30A4\u30C3\u30AF\u6587\u5B57\u8D77\u3053\u3057\u30EC\u30B3\u30FC\u30C9\u304C\u898B\u3064\u304B\u308A\u307E\u305B\u3093");
    let i = {
      quick_transcription: {
        ...n.quick_transcription,
        meeting_minutes: e.meetingMinutes || void 0,
        meeting_minutes_status: "completed",
        meeting_minutes_generated_at: Date.now(),
        // 既存のtranscript_with_speakerが存在する場合は上書きしない
        transcript_with_speaker: n.quick_transcription.transcript_with_speaker || e.transcriptWithSpeaker
      },
      updated_at: Date.now()
    };
    return await r.db.patch(e.transcriptionId, i), console.log("[saveQuickMinutesResult] \u8B70\u4E8B\u9332\u7D50\u679C\u3092\u30C7\u30FC\u30BF\u30D9\u30FC\u30B9\u306B\u4FDD\u5B58\u5B8C\u4E86"), null;
  }, "handler")
});
export {
  L as cleanupExpiredQuickTranscriptions,
  B as completeFileUpload,
  V as completeFileUploadInternal,
  D as completeGCSUpload,
  K as completeQuickTranscriptionUpload,
  $ as createQuickTranscriptionAndFileRecord,
  C as createQuickTranscriptionRecord,
  J as deleteTranscription,
  X as generateQuickMinutes,
  x as generateQuickTranscriptionUploadUrl,
  W as getExpiredTranscriptions,
  H as getFileUpload,
  z as getQuickTranscription,
  j as getTranscriptionForProcessing,
  N as listUserQuickTranscriptions,
  G as markTranscriptionFailed,
  A as processTranscriptionFromConvexStorage,
  v as processTranscriptionFromGCS,
  Z as saveQuickMinutesResult,
  R as saveTranscriptionResult,
  P as updateFileUploadGCPPath,
  Y as updateQuickMinutesStatus,
  O as updateTranscriptionStorageId
};
//# sourceMappingURL=quickTranscription.js.map
