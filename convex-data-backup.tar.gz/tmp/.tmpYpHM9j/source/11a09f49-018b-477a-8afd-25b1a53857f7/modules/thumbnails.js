import {
  b as g,
  d as h
} from "./_deps/LTTL23ZP.js";
import {
  b as r,
  e as _
} from "./_deps/IVQGLTSC.js";
import {
  a as m,
  b as u,
  c as f,
  d as s,
  f as c
} from "./_deps/75JH2J25.js";
import "./_deps/6XQQNYIR.js";
import {
  j as e,
  n as b
} from "./_deps/3TDUHHJO.js";
import {
  a as n
} from "./_deps/RUVYHBJQ.js";

// convex/thumbnails.ts
b();
_();
var T = u({
  args: { fileUploadId: e.id("fileUploads") },
  returns: e.union(
    e.object({
      _id: e.id("fileUploads"),
      gcp_file_path: e.string(),
      content_type: e.string(),
      original_filename: e.string()
    }),
    e.null()
  ),
  handler: /* @__PURE__ */ n(async (a, i) => {
    let t = await a.db.get(i.fileUploadId);
    return !t || !t.gcp_file_path ? null : {
      _id: t._id,
      gcp_file_path: t.gcp_file_path,
      content_type: t.content_type,
      original_filename: t.original_filename
    };
  }, "handler")
}), j = u({
  args: {
    fileUploadId: e.id("fileUploads"),
    size: e.optional(e.union(e.literal("small"), e.literal("medium"), e.literal("large")))
  },
  returns: e.union(
    e.object({
      _id: e.id("thumbnails"),
      gcp_file_path: e.string(),
      size: e.optional(e.string()),
      format: e.union(e.literal("webp"), e.literal("jpeg"), e.literal("png")),
      generated_at: e.optional(e.number())
    }),
    e.null()
  ),
  handler: /* @__PURE__ */ n(async (a, i) => {
    let t = await a.db.query("thumbnails").withIndex("by_file_upload_id", (l) => l.eq("file_upload_id", i.fileUploadId)).filter((l) => l.eq(l.field("size_category"), i.size ?? "medium")).first();
    return t ? {
      _id: t._id,
      gcp_file_path: t.gcp_file_path,
      size: t.size,
      format: t.format,
      generated_at: t.generated_at
    } : null;
  }, "handler")
}), v = s({
  args: {
    fileUploadId: e.id("fileUploads"),
    thumbnailStorageId: e.string(),
    thumbnailSize: e.string(),
    thumbnailFormat: e.string()
  },
  returns: e.null(),
  handler: /* @__PURE__ */ n(async (a, i) => {
    await a.db.insert("thumbnails", {
      file_upload_id: i.fileUploadId,
      gcp_file_path: i.thumbnailStorageId,
      // Using string as per schema
      thumbnail_url: "",
      // 後で設定
      width: 0,
      // 後で設定
      height: 0,
      // 後で設定
      size_category: ["small", "medium", "large", "poster", "custom"].includes(i.thumbnailSize) ? i.thumbnailSize : "custom",
      size: i.thumbnailSize,
      format: ["webp", "jpeg", "png"].includes(i.thumbnailFormat) ? i.thumbnailFormat : "jpeg",
      quality: 85,
      file_size: 0,
      generation_method: "auto_generated",
      generation_status: "completed",
      generated_at: Date.now(),
      optimized: !1
    }), await a.db.patch(i.fileUploadId, {
      thumbnail_generated: !0
    });
  }, "handler")
}), S = m({
  args: { fileUploadId: e.id("fileUploads") },
  returns: e.array(
    e.object({
      _id: e.id("thumbnails"),
      gcp_file_path: e.string(),
      size: e.optional(e.string()),
      format: e.union(e.literal("webp"), e.literal("jpeg"), e.literal("png")),
      generated_at: e.optional(e.number())
    })
  ),
  handler: /* @__PURE__ */ n(async (a, i) => (await a.db.query("thumbnails").withIndex("by_file_upload_id", (l) => l.eq("file_upload_id", i.fileUploadId)).collect()).map((l) => ({
    _id: l._id,
    gcp_file_path: l.gcp_file_path,
    size: l.size,
    format: l.format,
    generated_at: l.generated_at
  })), "handler")
}), A = m({
  args: { fileUploadId: e.id("fileUploads") },
  returns: e.union(
    e.object({
      _id: e.id("fileUploads"),
      status: e.union(
        e.literal("preparing"),
        e.literal("pending"),
        e.literal("uploading"),
        e.literal("completed"),
        e.literal("failed"),
        e.literal("processing")
      ),
      error: e.optional(e.string()),
      uploaded_at: e.optional(e.number()),
      completed_at: e.optional(e.number())
    }),
    e.null()
  ),
  handler: /* @__PURE__ */ n(async (a, i) => {
    let t = await a.db.get(i.fileUploadId);
    return t ? {
      _id: t._id,
      status: t.status,
      error: t.processing_error,
      uploaded_at: t.uploaded_at,
      completed_at: t.completed_at
    } : null;
  }, "handler")
}), q = f({
  args: {
    fileUploadId: e.id("fileUploads"),
    sizes: e.optional(
      e.array(e.union(e.literal("small"), e.literal("medium"), e.literal("large")))
    )
  },
  returns: e.object({
    success: e.boolean(),
    message: e.string()
  }),
  handler: /* @__PURE__ */ n(async (a, i) => {
    try {
      return await a.db.get(i.fileUploadId) ? (await a.scheduler.runAfter(0, r.thumbnails.generateAdvancedThumbnails, {
        fileUploadId: i.fileUploadId,
        config: {
          sizes: i.sizes ?? ["small", "medium", "large"],
          formats: ["webp", "jpeg"],
          quality: 85,
          frameSelection: "optimal",
          analysisEnabled: !0
        }
      }), {
        success: !0,
        message: "\u30B5\u30E0\u30CD\u30A4\u30EB\u518D\u751F\u6210\u30B8\u30E7\u30D6\u3092\u958B\u59CB\u3057\u307E\u3057\u305F"
      }) : {
        success: !1,
        message: "\u30D5\u30A1\u30A4\u30EB\u304C\u898B\u3064\u304B\u308A\u307E\u305B\u3093"
      };
    } catch (t) {
      return console.error("\u30B5\u30E0\u30CD\u30A4\u30EB\u518D\u751F\u6210\u30A8\u30E9\u30FC:", t), {
        success: !1,
        message: t instanceof Error ? t.message : "\u4E0D\u660E\u306A\u30A8\u30E9\u30FC"
      };
    }
  }, "handler")
}), E = f({
  args: {
    fileUploadId: e.id("fileUploads"),
    config: e.optional(
      e.object({
        sizes: e.array(e.string()),
        formats: e.array(e.string()),
        quality: e.number(),
        frameSelection: e.string(),
        enableAIAnalysis: e.boolean()
      })
    )
  },
  returns: e.object({
    success: e.boolean(),
    message: e.string(),
    estimatedCost: e.optional(e.number())
  }),
  handler: /* @__PURE__ */ n(async (a, i) => {
    let t = await a.db.get(i.fileUploadId);
    if (!t)
      throw new Error("\u30D5\u30A1\u30A4\u30EB\u30A2\u30C3\u30D7\u30ED\u30FC\u30C9\u304C\u898B\u3064\u304B\u308A\u307E\u305B\u3093");
    if (!t.upload_type.includes("video"))
      throw new Error("\u52D5\u753B\u30D5\u30A1\u30A4\u30EB\u306E\u307F\u30B5\u30E0\u30CD\u30A4\u30EB\u751F\u6210\u304C\u53EF\u80FD\u3067\u3059");
    let l = await a.db.query("thumbnails").withIndex("by_file_upload_id", (p) => p.eq("file_upload_id", i.fileUploadId)).collect();
    if (l.length > 0 && l.some((p) => p.generation_status === "processing"))
      return {
        success: !1,
        message: "\u30B5\u30E0\u30CD\u30A4\u30EB\u751F\u6210\u304C\u65E2\u306B\u9032\u884C\u4E2D\u3067\u3059"
      };
    let o = i.config ? {
      sizes: i.config.sizes,
      formats: i.config.formats,
      quality: i.config.quality,
      frameSelection: i.config.frameSelection,
      analysisEnabled: i.config.enableAIAnalysis
    } : g(t.upload_type), d = h({
      fileName: t.original_filename,
      fileSize: t.file_size,
      mimeType: t.content_type,
      uploadType: t.upload_type,
      generateThumbnails: !0,
      thumbnailConfig: o
    });
    return await a.scheduler.runAfter(0, r.thumbnails.generateAdvancedThumbnails, {
      fileUploadId: i.fileUploadId,
      config: o
    }), await a.db.patch(i.fileUploadId, {
      thumbnail_generated: !1,
      status: "processing"
    }), {
      success: !0,
      message: "\u9AD8\u5EA6\u306A\u30B5\u30E0\u30CD\u30A4\u30EB\u751F\u6210\u3092\u958B\u59CB\u3057\u307E\u3057\u305F",
      estimatedCost: d.totalCost
    };
  }, "handler")
}), x = c({
  args: {
    fileUploadId: e.id("fileUploads"),
    config: e.object({
      sizes: e.array(e.string()),
      formats: e.array(e.string()),
      quality: e.number(),
      frameSelection: e.string(),
      analysisEnabled: e.boolean()
    })
  },
  returns: e.null(),
  handler: /* @__PURE__ */ n(async (a, i) => {
    try {
      console.log(`\u30B5\u30E0\u30CD\u30A4\u30EB\u751F\u6210\u958B\u59CB: ${i.fileUploadId}`);
      let t = await a.runQuery(r.thumbnails.getFileUploadHybrid, {
        fileUploadId: i.fileUploadId
      });
      if (!t)
        throw new Error("\u30D5\u30A1\u30A4\u30EB\u30A2\u30C3\u30D7\u30ED\u30FC\u30C9\u304C\u898B\u3064\u304B\u308A\u307E\u305B\u3093");
      let l = {
        duration: 0,
        resolution: { width: 1920, height: 1080 },
        bitrate: 0,
        framerate: 30,
        codec: "unknown",
        audioTracks: 1,
        fileSize: t.file_size
      }, o = i.config.sizes.map((d) => ({
        thumbnailId: void 0,
        size: d,
        format: "jpeg",
        url: `https://storage.googleapis.com/ai-sales-hub-dev-new_dify-ai-sales-hub-dev-new/thumbnails/${i.fileUploadId}/${d}.jpeg`
      }));
      await a.runMutation(r.thumbnails.saveThumbnailResults, {
        fileUploadId: i.fileUploadId,
        videoMetadata: l,
        thumbnails: o,
        bestThumbnailId: void 0
      }), console.log(`\u30B5\u30E0\u30CD\u30A4\u30EB\u51E6\u7406\u5B8C\u4E86\uFF08\u30E1\u30BF\u30C7\u30FC\u30BF\u306E\u307F\uFF09: ${i.fileUploadId}`);
    } catch (t) {
      console.error("\u30B5\u30E0\u30CD\u30A4\u30EB\u751F\u6210\u30A8\u30E9\u30FC:", t), await a.runMutation(r.thumbnails.markThumbnailGenerationFailed, {
        fileUploadId: i.fileUploadId,
        error: t instanceof Error ? t.message : String(t)
      });
    }
  }, "handler")
}), C = u({
  args: { fileUploadId: e.id("fileUploads") },
  returns: e.union(
    e.null(),
    e.object({
      gcp_file_path: e.string(),
      original_filename: e.string(),
      content_type: e.string(),
      file_size: e.number(),
      upload_type: e.string()
    })
  ),
  handler: /* @__PURE__ */ n(async (a, i) => {
    let t = await a.db.get(i.fileUploadId);
    return !t || !t.gcp_file_path ? null : {
      gcp_file_path: t.gcp_file_path,
      original_filename: t.original_filename,
      content_type: t.content_type,
      file_size: t.file_size,
      upload_type: t.upload_type
    };
  }, "handler")
}), F = s({
  args: {
    fileUploadId: e.id("fileUploads"),
    videoMetadata: e.object({
      duration: e.number(),
      resolution: e.object({ width: e.number(), height: e.number() }),
      bitrate: e.number(),
      framerate: e.number(),
      codec: e.string(),
      audioTracks: e.number(),
      fileSize: e.number()
    }),
    thumbnails: e.array(
      e.object({
        thumbnailId: e.optional(e.id("thumbnails")),
        size: e.string(),
        format: e.string(),
        url: e.string()
      })
    ),
    bestThumbnailId: e.optional(e.id("thumbnails"))
  },
  returns: e.null(),
  handler: /* @__PURE__ */ n(async (a, i) => {
    await a.db.patch(i.fileUploadId, {
      duration_seconds: i.videoMetadata.duration,
      resolution: i.videoMetadata.resolution,
      bitrate: i.videoMetadata.bitrate,
      frame_rate: i.videoMetadata.framerate,
      video_codec: i.videoMetadata.codec,
      thumbnail_generated: !0,
      status: "completed"
    });
    for (let t of i.thumbnails) {
      let l = y(t.size), o = await a.db.insert("thumbnails", {
        file_upload_id: i.fileUploadId,
        // 新フィールド名
        gcp_file_path: `thumbnails/${i.fileUploadId}/${t.size}.${t.format}`,
        // GCS上のパス
        thumbnail_url: t.url,
        width: l.width,
        height: l.height,
        size_category: ["small", "medium", "large", "poster", "custom"].includes(t.size) ? t.size : "custom",
        size: t.size,
        // 新フィールド追加
        format: ["webp", "jpeg", "png"].includes(t.format) ? t.format : "jpeg",
        quality: 85,
        file_size: 0,
        // 実際のサイズは後で更新可能
        generation_method: "frame_extraction",
        // 必須フィールド
        generation_status: "completed",
        generated_at: Date.now(),
        optimized: !0
      });
      t.thumbnailId = o;
    }
    console.log(`\u30B5\u30E0\u30CD\u30A4\u30EB\u4FDD\u5B58\u5B8C\u4E86: ${i.fileUploadId}, ${i.thumbnails.length}\u500B`);
  }, "handler")
}), P = s({
  args: {
    fileUploadId: e.id("fileUploads"),
    error: e.string()
  },
  returns: e.null(),
  handler: /* @__PURE__ */ n(async (a, i) => {
    await a.db.patch(i.fileUploadId, {
      thumbnail_generated: !1,
      status: "failed",
      processing_error: i.error
    }), console.error(`\u30B5\u30E0\u30CD\u30A4\u30EB\u751F\u6210\u5931\u6557: ${i.fileUploadId}, ${i.error}`);
  }, "handler")
});
function y(a) {
  switch (a) {
    case "small":
      return { width: 150, height: 150 };
    case "medium":
      return { width: 300, height: 300 };
    case "large":
      return { width: 640, height: 360 };
    case "poster":
      return { width: 1280, height: 720 };
    default:
      return { width: 300, height: 300 };
  }
}
n(y, "getThumbnailDimensions");
var $ = s({
  args: { fileUploadId: e.id("fileUploads") },
  returns: e.null(),
  handler: /* @__PURE__ */ n(async (a, i) => {
    let t = await a.db.get(i.fileUploadId);
    !t || !t.upload_type.includes("video") || (await a.scheduler.runAfter(5e3, r.thumbnails.generateAdvancedThumbnails, {
      fileUploadId: i.fileUploadId,
      config: {
        sizes: ["small", "medium", "large", "poster"],
        formats: ["webp", "jpeg"],
        quality: 85,
        frameSelection: "optimal",
        analysisEnabled: !0
      }
    }), await a.db.patch(i.fileUploadId, {
      thumbnail_generated: !1,
      status: "processing"
    }));
  }, "handler")
});
export {
  $ as autoStartThumbnailGeneration,
  x as generateAdvancedThumbnails,
  S as getFileThumbnails,
  T as getFileUpload,
  C as getFileUploadHybrid,
  j as getThumbnail,
  A as getThumbnailProgress,
  P as markThumbnailGenerationFailed,
  q as regenerateThumbnails,
  F as saveThumbnailResults,
  E as startAdvancedThumbnailGeneration,
  v as updateFileUploadThumbnail
};
//# sourceMappingURL=thumbnails.js.map
