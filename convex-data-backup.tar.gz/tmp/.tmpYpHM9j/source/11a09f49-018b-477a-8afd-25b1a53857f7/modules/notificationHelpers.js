import {
  d as s
} from "./_deps/75JH2J25.js";
import "./_deps/6XQQNYIR.js";
import {
  j as i,
  n as r
} from "./_deps/3TDUHHJO.js";
import {
  a
} from "./_deps/RUVYHBJQ.js";

// convex/notificationHelpers.ts
r();
var c = s({
  args: {
    user_id: i.id("users"),
    type: i.string(),
    title: i.string(),
    message: i.string(),
    data: i.optional(i.string())
  },
  returns: i.id("notifications"),
  handler: /* @__PURE__ */ a(async (e, t) => await e.db.insert("notifications", {
    user_id: t.user_id,
    type: t.type,
    title: t.title,
    message: t.message,
    data: t.data,
    is_read: !1
  }), "handler")
}), u = s({
  args: {
    user_id: i.id("users")
  },
  returns: i.object({
    success: i.boolean(),
    deleted_count: i.number()
  }),
  handler: /* @__PURE__ */ a(async (e, t) => {
    let n = await e.db.query("notifications").filter((o) => o.eq(o.field("user_id"), t.user_id)).collect();
    return await Promise.all(
      n.map((o) => e.db.delete(o._id))
    ), {
      success: !0,
      deleted_count: n.length
    };
  }, "handler")
}), f = s({
  args: {
    user_id: i.id("users"),
    video_id: i.id("videos"),
    evaluation_id: i.id("evaluations"),
    score: i.number()
  },
  returns: i.id("notifications"),
  handler: /* @__PURE__ */ a(async (e, t) => {
    let n = {
      videoId: t.video_id,
      evaluationId: t.evaluation_id,
      score: t.score,
      url: `/videos/${t.video_id}/evaluation`
    };
    return await e.db.insert("notifications", {
      user_id: t.user_id,
      type: "evaluation_complete",
      title: "\u52D5\u753B\u8A55\u4FA1\u304C\u5B8C\u4E86\u3057\u307E\u3057\u305F",
      message: `\u3042\u306A\u305F\u306E\u52D5\u753B\u306E\u8A55\u4FA1\u304C\u5B8C\u4E86\u3057\u307E\u3057\u305F\u3002\u30B9\u30B3\u30A2: ${t.score}\u70B9`,
      data: JSON.stringify(n),
      is_read: !1
    });
  }, "handler")
}), _ = s({
  args: {
    user_id: i.id("users"),
    roleplay_id: i.id("roleplays"),
    applicant_name: i.string()
  },
  returns: i.id("notifications"),
  handler: /* @__PURE__ */ a(async (e, t) => {
    let n = {
      roleplayId: t.roleplay_id,
      url: `/roleplays/${t.roleplay_id}`
    };
    return await e.db.insert("notifications", {
      user_id: t.user_id,
      type: "roleplay_application",
      title: "\u30ED\u30FC\u30EB\u30D7\u30EC\u30A4\u306B\u65B0\u3057\u3044\u53C2\u52A0\u7533\u8ACB\u304C\u3042\u308A\u307E\u3059",
      message: `${t.applicant_name}\u3055\u3093\u304C\u30ED\u30FC\u30EB\u30D7\u30EC\u30A4\u306B\u53C2\u52A0\u7533\u8ACB\u3057\u307E\u3057\u305F\u3002`,
      data: JSON.stringify(n),
      is_read: !1
    });
  }, "handler")
}), p = s({
  args: {
    user_id: i.id("users"),
    title: i.string(),
    message: i.string(),
    url: i.optional(i.string())
  },
  returns: i.id("notifications"),
  handler: /* @__PURE__ */ a(async (e, t) => {
    let n = t.url ? { url: t.url } : null;
    return await e.db.insert("notifications", {
      user_id: t.user_id,
      type: "system_notification",
      title: t.title,
      message: t.message,
      data: n ? JSON.stringify(n) : void 0,
      is_read: !1
    });
  }, "handler")
});
export {
  u as clearUserNotifications,
  c as createTestNotification,
  f as sendEvaluationCompleteNotification,
  _ as sendRoleplayApplicationNotification,
  p as sendSystemNotification
};
//# sourceMappingURL=notificationHelpers.js.map
