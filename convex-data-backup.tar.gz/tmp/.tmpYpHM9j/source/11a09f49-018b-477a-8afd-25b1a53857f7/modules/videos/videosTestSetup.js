import {
  a as s,
  c as o
} from "../_deps/75JH2J25.js";
import "../_deps/6XQQNYIR.js";
import {
  j as e,
  n as a
} from "../_deps/3TDUHHJO.js";
import {
  a as r
} from "../_deps/RUVYHBJQ.js";

// convex/videos/videosTestSetup.ts
a();
var c = o({
  args: {
    clerkUserId: e.string(),
    email: e.string(),
    name: e.string(),
    role: e.optional(e.string()),
    isActive: e.optional(e.boolean())
  },
  returns: e.id("users"),
  handler: /* @__PURE__ */ r(async (n, i) => await n.db.insert("users", {
    clerkUserId: i.clerkUserId,
    tokenIdentifier: `clerk-${i.clerkUserId}`,
    email: i.email,
    emailVerified: !0,
    name: i.name,
    role: i.role || "employee",
    isActive: i.isActive ?? !0,
    joinDate: Date.now()
  }), "handler")
}), p = o({
  args: {
    userId: e.id("users"),
    title: e.string(),
    url: e.string(),
    status: e.optional(e.string()),
    processingStatus: e.optional(e.string()),
    type: e.optional(e.string()),
    description: e.optional(e.string()),
    fileSize: e.optional(e.number()),
    contentType: e.optional(e.string()),
    uploadSessionId: e.optional(e.string()),
    isGroupPrimary: e.optional(e.boolean()),
    groupOrder: e.optional(e.number())
  },
  returns: e.id("videos"),
  handler: /* @__PURE__ */ r(async (n, i) => {
    let t = {
      user_id: i.userId,
      title: i.title,
      url: i.url,
      type: i.type || "training",
      content_type: i.contentType || "video/mp4",
      processing_status: i.processingStatus || "pending"
    };
    return i.description !== void 0 && (t.description = i.description), i.fileSize !== void 0 && (t.file_size = i.fileSize), i.uploadSessionId !== void 0 && (t.upload_session_id = i.uploadSessionId), i.isGroupPrimary !== void 0 && (t.is_group_primary = i.isGroupPrimary), i.groupOrder !== void 0 && (t.group_order = i.groupOrder), await n.db.insert("videos", t);
  }, "handler")
}), g = o({
  args: {
    videoId: e.id("videos"),
    userId: e.id("users"),
    status: e.string(),
    text: e.optional(e.string()),
    confidence: e.optional(e.number()),
    processingJobId: e.optional(e.string())
  },
  returns: e.id("transcriptions"),
  handler: /* @__PURE__ */ r(async (n, i) => {
    let t = {
      resource_type: "video",
      resource_id: i.videoId,
      video_id: i.videoId,
      text: i.text || "",
      status: i.status
    };
    return i.confidence !== void 0 && (t.confidence = i.confidence), i.processingJobId !== void 0 && (t.processing_job_id = i.processingJobId), await n.db.insert("transcriptions", t);
  }, "handler")
}), I = o({
  args: {
    videoId: e.id("videos"),
    jobId: e.string(),
    status: e.string(),
    stage: e.string(),
    progress: e.optional(e.number()),
    priority: e.optional(e.string()),
    startedAt: e.optional(e.number()),
    estimatedCompletion: e.optional(e.number()),
    enableTranscription: e.optional(e.boolean()),
    enableAnalysis: e.optional(e.boolean())
  },
  returns: e.string(),
  handler: /* @__PURE__ */ r(async (n, i) => i.jobId, "handler")
}), v = o({
  args: {
    videoId: e.id("videos"),
    status: e.string(),
    errorMessage: e.optional(e.string())
  },
  returns: e.null(),
  handler: /* @__PURE__ */ r(async (n, i) => {
    let t = {
      processing_status: i.status
    };
    return i.errorMessage !== void 0 && (t.error_message = i.errorMessage), await n.db.patch(i.videoId, t), null;
  }, "handler")
}), b = s({
  args: { videoId: e.id("videos") },
  returns: e.union(
    e.object({
      _id: e.id("videos"),
      _creationTime: e.number(),
      user_id: e.id("users"),
      title: e.string(),
      description: e.optional(e.string()),
      url: e.string(),
      type: e.optional(e.string()),
      processing_status: e.optional(e.string()),
      error_message: e.optional(e.string()),
      file_size: e.optional(e.number()),
      content_type: e.optional(e.string())
    }),
    e.null()
  ),
  handler: /* @__PURE__ */ r(async (n, i) => await n.db.get(i.videoId), "handler")
}), m = s({
  args: { userId: e.id("users") },
  returns: e.union(
    e.object({
      _id: e.id("users"),
      _creationTime: e.number(),
      clerkUserId: e.string(),
      email: e.string(),
      name: e.string(),
      role: e.string(),
      isActive: e.boolean()
    }),
    e.null()
  ),
  handler: /* @__PURE__ */ r(async (n, i) => await n.db.get(i.userId), "handler")
}), f = s({
  args: { videoId: e.id("videos") },
  returns: e.union(
    e.object({
      _id: e.id("transcriptions"),
      _creationTime: e.number(),
      resource_type: e.string(),
      resource_id: e.string(),
      video_id: e.optional(e.id("videos")),
      text: e.string(),
      status: e.string()
    }),
    e.null()
  ),
  handler: /* @__PURE__ */ r(async (n, i) => await n.db.query("transcriptions").withIndex("by_video_id", (d) => d.eq("video_id", i.videoId)).first(), "handler")
}), y = o({
  args: {
    userId: e.optional(e.id("users")),
    videoId: e.optional(e.id("videos")),
    transcriptionId: e.optional(e.id("transcriptions"))
  },
  returns: e.null(),
  handler: /* @__PURE__ */ r(async (n, i) => (i.transcriptionId && await n.db.delete(i.transcriptionId), i.videoId && await n.db.delete(i.videoId), i.userId && await n.db.delete(i.userId), null), "handler")
}), _ = s({
  args: { userId: e.id("users") },
  returns: e.object({
    userId: e.id("users"),
    clerkUserId: e.string(),
    role: e.string()
  }),
  handler: /* @__PURE__ */ r(async (n, i) => {
    let t = await n.db.get(i.userId);
    if (!t)
      throw new Error("User not found");
    return {
      userId: t._id,
      clerkUserId: t.clerkUserId,
      role: t.role
    };
  }, "handler")
}), x = o({
  args: {
    serviceName: e.string(),
    isAvailable: e.boolean()
  },
  returns: e.null(),
  handler: /* @__PURE__ */ r(async (n, i) => (console.log(`[setServiceAvailability] ${i.serviceName}: ${i.isAvailable}`), null), "handler")
});
export {
  y as cleanupTestData,
  I as createTestProcessingJob,
  g as createTestTranscription,
  c as createTestUser,
  p as createTestVideo,
  f as getTestTranscription,
  m as getTestUser,
  b as getTestVideo,
  _ as mockAuthContext,
  x as setServiceAvailability,
  v as setVideoProcessingStatus
};
//# sourceMappingURL=videosTestSetup.js.map
