import {
  b as u
} from "../_deps/6HNJFR7B.js";
import {
  a as d,
  c as b
} from "../_deps/75JH2J25.js";
import "../_deps/6XQQNYIR.js";
import {
  j as t,
  n as I
} from "../_deps/3TDUHHJO.js";
import {
  a as l
} from "../_deps/RUVYHBJQ.js";

// convex/videos/coreTest.ts
I();
var j = d({
  args: {
    page: t.optional(t.number()),
    limit: t.optional(t.number()),
    type: t.optional(t.string()),
    sort: t.optional(t.string()),
    order: t.optional(t.string()),
    showAll: t.optional(t.boolean()),
    person: t.optional(t.string()),
    scoreRange: t.optional(t.string()),
    company: t.optional(t.string()),
    searchQuery: t.optional(t.string())
  },
  returns: t.object({
    success: t.boolean(),
    data: t.array(
      t.object({
        _id: t.id("videos"),
        title: t.string(),
        date: t.string(),
        duration: t.string(),
        type: t.optional(t.string()),
        description: t.optional(t.string()),
        url: t.string(),
        thumbnail_url: t.optional(t.string()),
        user_id: t.id("users"),
        username: t.optional(t.string()),
        status: t.string(),
        views: t.number(),
        comments: t.number(),
        likes: t.number()
      })
    ),
    meta: t.object({
      page: t.number(),
      limit: t.number(),
      total: t.number(),
      pages: t.number()
    })
  }),
  handler: /* @__PURE__ */ l(async (n, i) => {
    try {
      await u(n);
      let r = i.page || 1, o = i.limit || 12, T = i.order || "desc", s = n.db.query("videos");
      i.type && (s = s.filter((e) => e.eq(e.field("type"), i.type))), i.searchQuery && (s = s.filter(
        (e) => e.or(
          e.eq(e.field("title"), i.searchQuery),
          e.eq(e.field("description"), i.searchQuery)
        )
      ));
      let p = await s.collect(), c = p.length, m = (r - 1) * o, g = p.slice(m, m + o), _ = [...new Set(g.map((e) => e.user_id))], y = await Promise.all(
        _.map(async (e) => {
          try {
            let a = await n.db.get(e);
            return { id: e, user: a };
          } catch (a) {
            return console.warn("\u30E6\u30FC\u30B6\u30FC\u60C5\u5831\u53D6\u5F97\u30A8\u30E9\u30FC:", a), { id: e, user: null };
          }
        })
      ), h = new Map(y.map(({ id: e, user: a }) => [e, a?.name || "\u4E0D\u660E\u306A\u30E6\u30FC\u30B6\u30FC"])), f = g.map((e) => ({
        _id: e._id,
        title: e.title,
        date: new Date(e._creationTime).toISOString().split("T")[0],
        duration: e.duration_seconds ? `${Math.floor(e.duration_seconds / 60)}:${(e.duration_seconds % 60).toString().padStart(2, "0")}` : "0:00",
        type: e.type,
        description: e.description,
        url: e.url,
        thumbnail_url: e.thumbnail_url,
        user_id: e.user_id,
        username: h.get(e.user_id),
        status: e.processing_status || "completed",
        views: 0,
        comments: 0,
        likes: 0
      })), w = Math.ceil(c / o);
      return {
        success: !0,
        data: f,
        meta: {
          page: r,
          limit: o,
          total: c,
          pages: w
        }
      };
    } catch (r) {
      return console.error("\u52D5\u753B\u4E00\u89A7\u53D6\u5F97\u30A8\u30E9\u30FC:", r), {
        success: !1,
        data: [],
        meta: {
          page: i.page || 1,
          limit: i.limit || 12,
          total: 0,
          pages: 0
        }
      };
    }
  }, "handler")
}), v = d({
  args: { videoId: t.id("videos") },
  returns: t.union(
    t.object({
      _id: t.id("videos"),
      _creationTime: t.number(),
      title: t.string(),
      description: t.optional(t.string()),
      url: t.string(),
      thumbnail_url: t.optional(t.string()),
      user_id: t.id("users"),
      duration_seconds: t.optional(t.number()),
      type: t.optional(t.string()),
      processing_status: t.optional(t.string())
    }),
    t.null()
  ),
  handler: /* @__PURE__ */ l(async (n, i) => (await u(n), await n.db.get(i.videoId)), "handler")
}), C = b({
  args: {
    title: t.string(),
    description: t.optional(t.string()),
    url: t.string(),
    thumbnail_url: t.optional(t.string()),
    duration_seconds: t.optional(t.number()),
    type: t.optional(t.string())
  },
  returns: t.id("videos"),
  handler: /* @__PURE__ */ l(async (n, i) => {
    let { user: r } = await u(n);
    return await n.db.insert("videos", {
      title: i.title,
      description: i.description,
      url: i.url,
      thumbnail_url: i.thumbnail_url,
      user_id: r._id,
      duration_seconds: i.duration_seconds,
      type: i.type || "training",
      processing_status: "completed"
    });
  }, "handler")
});
export {
  C as createTestCompatible,
  v as getByIdTestCompatible,
  j as listTestCompatible
};
//# sourceMappingURL=coreTest.js.map
