"use node";
import {
  a as y
} from "../_deps/node/4BJOKGGA.js";
import {
  a as u
} from "../_deps/node/VTOLWO7E.js";
import {
  c as g
} from "../_deps/node/PDGHC3PS.js";
import {
  a as e
} from "../_deps/node/UDHF6CTX.js";
import {
  a as c
} from "../_deps/node/V7X2J7BI.js";

// convex/videos/download.ts
var x = g({
  args: {
    videoId: e.id("videos"),
    quality: e.optional(
      e.union(
        e.literal("original"),
        e.literal("high"),
        e.literal("medium"),
        e.literal("low"),
        e.literal("ultra_high")
      )
    )
  },
  returns: e.union(
    e.object({
      success: e.literal(!0),
      downloadUrl: e.string(),
      fileName: e.string(),
      expiresAt: e.number(),
      warning: e.optional(e.string())
    }),
    e.object({
      success: e.literal(!1),
      error: e.object({
        code: e.string(),
        message: e.string(),
        suggestions: e.optional(e.array(e.string())),
        availableQualities: e.optional(e.array(e.string())),
        estimatedCompletionTime: e.optional(e.number()),
        currentDownloads: e.optional(e.number()),
        waitTimeMinutes: e.optional(e.number())
      })
    })
  ),
  handler: /* @__PURE__ */ c(async (s, o) => {
    try {
      let l = (await y(s)).unifiedUserId, i = o.quality || "original", a = await s.runQuery(u.videos.core.getById, {
        videoId: o.videoId
      });
      if (!a.success || !a.data)
        return {
          success: !1,
          error: {
            code: "VIDEO_NOT_FOUND",
            message: "\u52D5\u753B\u304C\u5B58\u5728\u3057\u307E\u305B\u3093"
          }
        };
      let n = a.data;
      if (!n)
        return {
          success: !1,
          error: {
            code: "VIDEO_NOT_FOUND",
            message: "\u52D5\u753B\u304C\u5B58\u5728\u3057\u307E\u305B\u3093"
          }
        };
      if (!await s.runQuery(u.videos.core.checkVideoAccess, {
        videoId: o.videoId,
        userId: l
      }))
        return {
          success: !1,
          error: {
            code: "ACCESS_DENIED",
            message: "\u30C0\u30A6\u30F3\u30ED\u30FC\u30C9\u6A29\u9650\u304C\u3042\u308A\u307E\u305B\u3093"
          }
        };
      if (n.processing_status === "processing")
        return {
          success: !1,
          error: {
            code: "VIDEO_NOT_READY",
            message: "\u52D5\u753B\u306F\u307E\u3060\u51E6\u7406\u4E2D\u3067\u3059",
            estimatedCompletionTime: Date.now() + 36e5
            // 1時間後（仮）
          }
        };
      let b = ["original", "high", "medium", "low"];
      if (!b.includes(i))
        return i === "ultra_high" ? {
          success: !1,
          error: {
            code: "QUALITY_NOT_AVAILABLE",
            message: "\u6307\u5B9A\u54C1\u8CEA\u306E\u30D5\u30A1\u30A4\u30EB\u304C\u5B58\u5728\u3057\u307E\u305B\u3093",
            availableQualities: b
          }
        } : {
          success: !1,
          error: {
            code: "INVALID_QUALITY",
            message: "\u4E0D\u6B63\u306A\u54C1\u8CEA\u6307\u5B9A\u3067\u3059",
            availableQualities: b
          }
        };
      let r = 0;
      if (r >= 5)
        return {
          success: !1,
          error: {
            code: "DOWNLOAD_LIMIT_EXCEEDED",
            message: "\u540C\u6642\u30C0\u30A6\u30F3\u30ED\u30FC\u30C9\u6570\u306E\u4E0A\u9650\u306B\u9054\u3057\u3066\u3044\u307E\u3059",
            currentDownloads: r,
            waitTimeMinutes: 30
          }
        };
      let m = `${n._id}-${i}.mp4`, p = 1;
      n.file_size && n.file_size > 2 * 1024 * 1024 * 1024 && (p = 6);
      let d = Date.now() + p * 60 * 60 * 1e3, _ = `https://storage.googleapis.com/video-storage/${m}?expires=${d}`, f;
      return n.file_size && n.file_size > 2 * 1024 * 1024 * 1024 && (f = "\u5927\u5BB9\u91CF\u30D5\u30A1\u30A4\u30EB\u3067\u3059\u3002\u5206\u5272\u30C0\u30A6\u30F3\u30ED\u30FC\u30C9\u306E\u5229\u7528\u3092\u63A8\u5968\u3057\u307E\u3059\u3002"), {
        success: !0,
        downloadUrl: _,
        fileName: m,
        expiresAt: d,
        warning: f
      };
    } catch (t) {
      return console.error("[downloadVideo] \u30A8\u30E9\u30FC:", t), t instanceof Error && t.message.includes("storage") ? {
        success: !1,
        error: {
          code: "STORAGE_SERVICE_ERROR",
          message: "\u30B9\u30C8\u30EC\u30FC\u30B8\u30B5\u30FC\u30D3\u30B9\u304C\u4E00\u6642\u7684\u306B\u5229\u7528\u3067\u304D\u307E\u305B\u3093",
          suggestions: ["\u3057\u3070\u3089\u304F\u6642\u9593\u3092\u304A\u3044\u3066\u518D\u8A66\u884C\u3057\u3066\u304F\u3060\u3055\u3044"]
        }
      } : {
        success: !1,
        error: {
          code: "INTERNAL_ERROR",
          message: "\u5185\u90E8\u30A8\u30E9\u30FC\u304C\u767A\u751F\u3057\u307E\u3057\u305F"
        }
      };
    }
  }, "handler")
}), U = g({
  args: {
    videoId: e.id("videos"),
    format: e.optional(e.union(e.literal("srt"), e.literal("vtt"), e.literal("txt"))),
    language: e.optional(e.string())
  },
  returns: e.union(
    e.object({
      success: e.literal(!0),
      downloadUrl: e.string(),
      fileName: e.string(),
      expiresAt: e.number(),
      warning: e.optional(e.string()),
      confidenceScore: e.optional(e.number())
    }),
    e.object({
      success: e.literal(!1),
      error: e.object({
        code: e.string(),
        message: e.string(),
        suggestions: e.optional(e.array(e.string())),
        supportedFormats: e.optional(e.array(e.string())),
        availableLanguages: e.optional(e.array(e.string())),
        estimatedCompletionTime: e.optional(e.number())
      })
    })
  ),
  handler: /* @__PURE__ */ c(async (s, o) => {
    try {
      let l = (await y(s)).unifiedUserId, i = o.format || "srt", a = o.language || "ja", n = await s.runQuery(u.videos.core.getById, {
        videoId: o.videoId
      });
      if (!n.success || !n.data)
        return {
          success: !1,
          error: {
            code: "VIDEO_NOT_FOUND",
            message: "\u52D5\u753B\u304C\u5B58\u5728\u3057\u307E\u305B\u3093"
          }
        };
      let I = n.data;
      if (!I)
        return {
          success: !1,
          error: {
            code: "VIDEO_NOT_FOUND",
            message: "\u52D5\u753B\u304C\u5B58\u5728\u3057\u307E\u305B\u3093"
          }
        };
      if (!await s.runQuery(u.videos.core.checkVideoAccess, {
        videoId: o.videoId,
        userId: l
      }))
        return {
          success: !1,
          error: {
            code: "ACCESS_DENIED",
            message: "\u30A2\u30AF\u30BB\u30B9\u6A29\u9650\u304C\u3042\u308A\u307E\u305B\u3093"
          }
        };
      let r = {
        status: "completed",
        segments: [],
        confidence: 0.8
      };
      if (!r)
        return {
          success: !1,
          error: {
            code: "TRANSCRIPTION_NOT_FOUND",
            message: "\u6587\u5B57\u8D77\u3053\u3057\u304C\u5B58\u5728\u3057\u307E\u305B\u3093",
            suggestions: ["\u6587\u5B57\u8D77\u3053\u3057\u51E6\u7406\u3092\u958B\u59CB\u3057\u3066\u304F\u3060\u3055\u3044"]
          }
        };
      if (r.status === "processing")
        return {
          success: !1,
          error: {
            code: "TRANSCRIPTION_IN_PROGRESS",
            message: "\u6587\u5B57\u8D77\u3053\u3057\u304C\u51E6\u7406\u4E2D\u3067\u3059",
            estimatedCompletionTime: Date.now() + 18e5
            // 30分後（仮）
          }
        };
      if (!r.segments || r.segments.length === 0)
        return {
          success: !1,
          error: {
            code: "EMPTY_TRANSCRIPTION",
            message: "\u6587\u5B57\u8D77\u3053\u3057\u30C7\u30FC\u30BF\u304C\u7A7A\u3067\u3059",
            suggestions: ["\u6587\u5B57\u8D77\u3053\u3057\u3092\u518D\u5B9F\u884C\u3057\u3066\u304F\u3060\u3055\u3044"]
          }
        };
      let m = ["srt", "vtt", "txt"];
      if (!m.includes(i))
        return {
          success: !1,
          error: {
            code: "UNSUPPORTED_FORMAT",
            message: "\u4E0D\u5BFE\u5FDC\u306E\u5B57\u5E55\u5F62\u5F0F\u3067\u3059",
            supportedFormats: m
          }
        };
      let p = ["ja", "en"];
      if (!p.includes(a))
        return {
          success: !1,
          error: {
            code: "LANGUAGE_NOT_AVAILABLE",
            message: "\u6307\u5B9A\u8A00\u8A9E\u306E\u6587\u5B57\u8D77\u3053\u3057\u304C\u5B58\u5728\u3057\u307E\u305B\u3093",
            availableLanguages: p
          }
        };
      let d;
      i === "txt" ? d = `${I._id}-transcript-${a}.${i}` : d = `${I._id}-subtitles-${a}.${i}`;
      let _ = 1;
      r.segments.length > 1e3 && (_ = 2);
      let f = Date.now() + _ * 60 * 60 * 1e3, T = `https://storage.googleapis.com/subtitle-storage/${d}?expires=${f}`, E, N;
      return r.confidence < 0.7 && (E = "\u6587\u5B57\u8D77\u3053\u3057\u306E\u4FE1\u983C\u5EA6\u304C\u4F4E\u3044\u305F\u3081\u3001\u624B\u52D5\u6821\u6B63\u3092\u63A8\u5968\u3057\u307E\u3059\u3002", N = r.confidence), r.segments.length > 1e3 && (E = "\u5927\u5BB9\u91CF\u30D5\u30A1\u30A4\u30EB\u306E\u305F\u3081\u751F\u6210\u306B\u6642\u9593\u304C\u304B\u304B\u308B\u5834\u5408\u304C\u3042\u308A\u307E\u3059\u3002"), {
        success: !0,
        downloadUrl: T,
        fileName: d,
        expiresAt: f,
        warning: E,
        confidenceScore: N
      };
    } catch (t) {
      return console.error("[downloadSubtitles] \u30A8\u30E9\u30FC:", t), t instanceof Error && t.message.includes("subtitle") ? {
        success: !1,
        error: {
          code: "SUBTITLE_SERVICE_ERROR",
          message: "\u5B57\u5E55\u5909\u63DB\u30B5\u30FC\u30D3\u30B9\u304C\u4E00\u6642\u7684\u306B\u5229\u7528\u3067\u304D\u307E\u305B\u3093",
          suggestions: ["\u3057\u3070\u3089\u304F\u6642\u9593\u3092\u304A\u3044\u3066\u518D\u8A66\u884C\u3057\u3066\u304F\u3060\u3055\u3044"]
        }
      } : {
        success: !1,
        error: {
          code: "INTERNAL_ERROR",
          message: "\u5185\u90E8\u30A8\u30E9\u30FC\u304C\u767A\u751F\u3057\u307E\u3057\u305F"
        }
      };
    }
  }, "handler")
}), C = g({
  args: {
    videoId: e.id("videos"),
    userId: e.id("users"),
    action: e.string(),
    quality: e.optional(e.string()),
    format: e.optional(e.string()),
    language: e.optional(e.string()),
    fileName: e.string()
  },
  returns: e.null(),
  handler: /* @__PURE__ */ c(async (s, o) => (console.log(
    `[\u30C0\u30A6\u30F3\u30ED\u30FC\u30C9\u30ED\u30B0] \u30E6\u30FC\u30B6\u30FC:${o.userId}, \u52D5\u753B:${o.videoId}, \u30A2\u30AF\u30B7\u30E7\u30F3:${o.action}`
  ), null), "handler")
}), $ = g({
  args: {
    videoId: e.id("videos")
  },
  returns: e.object({
    success: e.boolean(),
    downloadUrl: e.optional(e.string()),
    fileName: e.optional(e.string()),
    message: e.string()
  }),
  handler: /* @__PURE__ */ c(async (s, o) => {
    try {
      await y(s);
      let t = await s.runQuery(u.videos.getVideoReviewData, {
        videoId: o.videoId
      });
      if (!t)
        return {
          success: !1,
          message: "\u30EC\u30D3\u30E5\u30FC\u30C7\u30FC\u30BF\u304C\u898B\u3064\u304B\u308A\u307E\u305B\u3093"
        };
      let l = A(t), i = `video-review-${t.id || "unknown"}-${Date.now()}.json`;
      return {
        success: !0,
        downloadUrl: `data:application/json;charset=utf-8,${encodeURIComponent(JSON.stringify(l, null, 2))}`,
        fileName: i,
        message: "\u30EC\u30D3\u30E5\u30FC\u30D5\u30A1\u30A4\u30EB\u304C\u751F\u6210\u3055\u308C\u307E\u3057\u305F"
      };
    } catch (t) {
      return console.error("[generateReviewPdf] \u30A8\u30E9\u30FC:", t), {
        success: !1,
        message: "\u30EC\u30D3\u30E5\u30FC\u30D5\u30A1\u30A4\u30EB\u306E\u751F\u6210\u4E2D\u306B\u30A8\u30E9\u30FC\u304C\u767A\u751F\u3057\u307E\u3057\u305F"
      };
    }
  }, "handler")
});
function A(s) {
  return {
    videoId: s.id,
    videoType: s.videoType,
    generatedAt: (/* @__PURE__ */ new Date()).toISOString(),
    // 評価サマリー
    evaluationSummary: {
      overallComment: s.overallComment,
      scores: s.scores,
      improvementSummary: s.improvementSummary
    },
    // 詳細評価
    detailedEvaluation: {
      hearing: {
        score: s.details.hearing.score,
        description: s.details.hearing.description,
        details: s.details.hearing.details,
        examples: {
          good: s.details.hearing.goodExamples,
          bad: s.details.hearing.badExamples
        }
      },
      problemDefinition: {
        score: s.details.problemDefinition.score,
        description: s.details.problemDefinition.description,
        details: s.details.problemDefinition.details,
        examples: {
          good: s.details.problemDefinition.goodExamples,
          bad: s.details.problemDefinition.badExamples
        }
      },
      reactivity: {
        score: s.details.reactivity.score,
        description: s.details.reactivity.description,
        details: s.details.reactivity.details,
        examples: {
          good: s.details.reactivity.goodExamples,
          bad: s.details.reactivity.badExamples
        }
      },
      counter: {
        score: s.details.counter.score,
        description: s.details.counter.description,
        details: s.details.counter.details,
        examples: {
          good: s.details.counter.goodExamples,
          bad: s.details.counter.badExamples
        }
      },
      businessSense: {
        score: s.details.businessSense.score,
        description: s.details.businessSense.description,
        details: s.details.businessSense.details,
        examples: {
          good: s.details.businessSense.goodExamples,
          bad: s.details.businessSense.badExamples
        }
      }
    },
    // 会話ログ
    conversationLogs: s.conversationLogs,
    // AI分析結果
    aiAnalysis: {
      meetingMinutes: {
        data: s.meeting_minutes,
        status: s.meeting_minutes_status,
        generatedAt: s.meeting_minutes_generated_at
      },
      caseSummary: {
        data: s.case_summary,
        status: s.case_summary_status,
        generatedAt: s.case_summary_generated_at
      },
      meetingSummary: {
        data: s.meeting_summary,
        status: s.meeting_summary_status,
        generatedAt: s.meeting_summary_generated_at
      }
    }
  };
}
c(A, "generatePdfContent");
var w = g({
  args: {
    videoId: e.id("videos"),
    format: e.optional(e.union(e.literal("pdf"), e.literal("json")))
  },
  returns: e.object({
    success: e.boolean(),
    content: e.optional(e.string()),
    contentType: e.optional(e.string()),
    fileName: e.optional(e.string()),
    message: e.string()
  }),
  handler: /* @__PURE__ */ c(async (s, o) => {
    try {
      await y(s);
      let t = o.format || "json", l = await s.runQuery(u.videos.getVideoReviewData, {
        videoId: o.videoId
      });
      if (!l)
        return {
          success: !1,
          message: "\u30EC\u30D3\u30E5\u30FC\u30C7\u30FC\u30BF\u304C\u898B\u3064\u304B\u308A\u307E\u305B\u3093"
        };
      let i = A(l), a = `video-review-${l.id || "unknown"}-${Date.now()}.${t}`;
      return t === "json" ? {
        success: !0,
        content: JSON.stringify(i, null, 2),
        contentType: "application/json",
        fileName: a,
        message: "\u30EC\u30D3\u30E5\u30FC\u30D5\u30A1\u30A4\u30EB\u306E\u5185\u5BB9\u3092\u53D6\u5F97\u3057\u307E\u3057\u305F"
      } : {
        success: !1,
        message: "PDF\u5F62\u5F0F\u306F\u73FE\u5728\u5B9F\u88C5\u4E2D\u3067\u3059\u3002JSON\u5F62\u5F0F\u3092\u3054\u5229\u7528\u304F\u3060\u3055\u3044\u3002"
      };
    } catch (t) {
      return console.error("[downloadReviewFile] \u30A8\u30E9\u30FC:", t), {
        success: !1,
        message: "\u30EC\u30D3\u30E5\u30FC\u30D5\u30A1\u30A4\u30EB\u306E\u30C0\u30A6\u30F3\u30ED\u30FC\u30C9\u4E2D\u306B\u30A8\u30E9\u30FC\u304C\u767A\u751F\u3057\u307E\u3057\u305F"
      };
    }
  }, "handler")
});
export {
  w as downloadReviewFile,
  U as downloadSubtitles,
  x as downloadVideo,
  $ as generateReviewPdf,
  C as logDownloadActivity
};
//# sourceMappingURL=download.js.map
