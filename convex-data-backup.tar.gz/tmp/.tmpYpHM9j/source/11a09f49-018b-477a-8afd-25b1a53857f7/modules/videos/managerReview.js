import {
  g as w,
  h as g
} from "../_deps/6HNJFR7B.js";
import {
  a as l,
  c as u
} from "../_deps/75JH2J25.js";
import "../_deps/6XQQNYIR.js";
import {
  j as i,
  n as m
} from "../_deps/3TDUHHJO.js";
import {
  a as c
} from "../_deps/RUVYHBJQ.js";

// convex/videos/managerReview.ts
m();
var _ = i.object({
  listening_skills: i.optional(i.number()),
  // ヒアリング能力
  proposal_design: i.optional(i.number()),
  // 提案設計能力
  knowledge: i.optional(i.number()),
  // 知識力
  responsiveness: i.optional(i.number()),
  // 切り返し力
  business_manner: i.optional(i.number())
  // ビジネスマナー
}), p = l({
  args: {
    videoId: i.id("videos")
  },
  handler: /* @__PURE__ */ c(async (s, e) => {
    let r = await g(s, e.videoId);
    if (!r.success)
      return {
        canReview: !1,
        message: r.message
      };
    let d = await s.db.query("managerReviews").withIndex(
      "by_video_and_reviewer",
      (n) => n.eq("video_id", e.videoId).eq("reviewer_id", r.user._id)
    ).unique();
    return {
      canReview: !0,
      hasExistingReview: !!d,
      existingReview: d,
      video: r.video,
      uploader: r.uploader,
      user: r.user
    };
  }, "handler")
}), R = u({
  args: {
    videoId: i.id("videos"),
    overallRating: i.number(),
    comments: i.string(),
    categoryScores: i.optional(_)
  },
  handler: /* @__PURE__ */ c(async (s, e) => {
    try {
      let { video: r, uploader: d, user: n } = await w(s, e.videoId);
      if (e.overallRating < 1 || e.overallRating > 10)
        throw new Error("\u7DCF\u5408\u8A55\u4FA1\u306F1\u304B\u308910\u306E\u7BC4\u56F2\u3067\u5165\u529B\u3057\u3066\u304F\u3060\u3055\u3044");
      if (e.categoryScores) {
        let o = Object.values(e.categoryScores);
        for (let a of o)
          if (a !== void 0 && (a < 1 || a > 10))
            throw new Error("\u30AB\u30C6\u30B4\u30EA\u5225\u8A55\u4FA1\u306F1\u304B\u308910\u306E\u7BC4\u56F2\u3067\u5165\u529B\u3057\u3066\u304F\u3060\u3055\u3044");
      }
      if (e.comments.trim().length < 1)
        throw new Error("\u30D5\u30A3\u30FC\u30C9\u30D0\u30C3\u30AF\u30B3\u30E1\u30F3\u30C8\u3092\u5165\u529B\u3057\u3066\u304F\u3060\u3055\u3044");
      let t = await s.db.query("managerReviews").withIndex(
        "by_video_and_reviewer",
        (o) => o.eq("video_id", e.videoId).eq("reviewer_id", n._id)
      ).unique();
      return t ? (await s.db.patch(t._id, {
        overall_rating: e.overallRating,
        comments: e.comments.trim(),
        category_scores: e.categoryScores
      }), {
        success: !0,
        message: "\u30EC\u30D3\u30E5\u30FC\u3092\u66F4\u65B0\u3057\u307E\u3057\u305F",
        reviewId: t._id
      }) : {
        success: !0,
        message: "\u30EC\u30D3\u30E5\u30FC\u3092\u6295\u7A3F\u3057\u307E\u3057\u305F",
        reviewId: await s.db.insert("managerReviews", {
          video_id: e.videoId,
          reviewer_id: n._id,
          overall_rating: e.overallRating,
          comments: e.comments.trim(),
          category_scores: e.categoryScores
        })
      };
    } catch (r) {
      return {
        success: !1,
        message: r instanceof Error ? r.message : "\u30EC\u30D3\u30E5\u30FC\u6295\u7A3F\u306B\u5931\u6557\u3057\u307E\u3057\u305F"
      };
    }
  }, "handler")
}), b = l({
  args: {
    videoId: i.id("videos")
  },
  handler: /* @__PURE__ */ c(async (s, e) => {
    if (!await s.db.get(e.videoId))
      return {
        success: !1,
        message: "\u52D5\u753B\u304C\u898B\u3064\u304B\u308A\u307E\u305B\u3093",
        reviews: []
      };
    let d = await s.db.query("managerReviews").withIndex("by_video_id", (t) => t.eq("video_id", e.videoId)).collect();
    return {
      success: !0,
      reviews: await Promise.all(
        d.map(async (t) => {
          let o = await s.db.get(t.reviewer_id);
          return {
            ...t,
            reviewer: o ? {
              _id: o._id,
              name: o.name,
              role: o.role
            } : null
          };
        })
      )
    };
  }, "handler")
}), I = u({
  args: {
    reviewId: i.id("managerReviews")
  },
  handler: /* @__PURE__ */ c(async (s, e) => {
    try {
      let r = await s.db.get(e.reviewId);
      if (!r)
        throw new Error("\u30EC\u30D3\u30E5\u30FC\u304C\u898B\u3064\u304B\u308A\u307E\u305B\u3093");
      let { video: d, uploader: n, user: t } = await w(s, r.video_id);
      if (t._id !== r.reviewer_id && t.role !== "admin")
        throw new Error("\u3053\u306E\u30EC\u30D3\u30E5\u30FC\u3092\u524A\u9664\u3059\u308B\u6A29\u9650\u304C\u3042\u308A\u307E\u305B\u3093");
      return await s.db.delete(e.reviewId), {
        success: !0,
        message: "\u30EC\u30D3\u30E5\u30FC\u3092\u524A\u9664\u3057\u307E\u3057\u305F"
      };
    } catch (r) {
      return {
        success: !1,
        message: r instanceof Error ? r.message : "\u30EC\u30D3\u30E5\u30FC\u524A\u9664\u306B\u5931\u6557\u3057\u307E\u3057\u305F"
      };
    }
  }, "handler")
}), q = l({
  args: {
    videoId: i.id("videos")
  },
  handler: /* @__PURE__ */ c(async (s, e) => {
    let r = await s.db.query("managerReviews").withIndex("by_video_id", (o) => o.eq("video_id", e.videoId)).collect();
    if (r.length === 0)
      return {
        totalReviews: 0,
        averageRating: 0,
        categoryAverages: null
      };
    let d = r.reduce((o, a) => o + a.overall_rating, 0) / r.length, n = {
      listening_skills: { sum: 0, count: 0 },
      proposal_design: { sum: 0, count: 0 },
      knowledge: { sum: 0, count: 0 },
      responsiveness: { sum: 0, count: 0 },
      business_manner: { sum: 0, count: 0 }
    };
    r.forEach((o) => {
      o.category_scores && Object.entries(o.category_scores).forEach(([a, v]) => {
        v !== void 0 && a in n && (n[a].sum += v, n[a].count += 1);
      });
    });
    let t = {};
    return Object.entries(n).forEach(([o, { sum: a, count: v }]) => {
      v > 0 && (t[o] = a / v);
    }), {
      totalReviews: r.length,
      averageRating: Math.round(d * 10) / 10,
      categoryAverages: Object.keys(t).length > 0 ? t : null
    };
  }, "handler")
});
export {
  p as checkCanReview,
  I as deleteManagerReview,
  b as getManagerReviews,
  q as getReviewStats,
  R as submitManagerReview
};
//# sourceMappingURL=managerReview.js.map
