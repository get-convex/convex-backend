import {
  b as g
} from "./_deps/SZVQRWFS.js";
import {
  a as h,
  c as y
} from "./_deps/75JH2J25.js";
import "./_deps/6XQQNYIR.js";
import {
  j as e,
  l as r,
  n as T
} from "./_deps/3TDUHHJO.js";
import {
  a as w
} from "./_deps/RUVYHBJQ.js";

// convex/lessonManagement.ts
T();
T();
var D = y({
  args: {
    videoId: e.id("videos"),
    courseId: e.optional(e.id("courses")),
    trainingId: e.optional(e.id("trainings")),
    moduleTitle: e.string(),
    moduleDescription: e.optional(e.string()),
    orderIndex: e.optional(e.number())
  },
  returns: e.object({
    success: e.boolean(),
    message: e.string(),
    moduleId: e.optional(e.union(e.id("modules"), e.id("trainingModules"))),
    moduleType: e.optional(e.union(e.literal("new_course"), e.literal("legacy_training")))
  }),
  handler: /* @__PURE__ */ w(async (t, i) => {
    let l = await g(t), o = await t.db.get(i.videoId);
    if (!o)
      throw new r("\u6307\u5B9A\u3055\u308C\u305F\u52D5\u753B\u304C\u898B\u3064\u304B\u308A\u307E\u305B\u3093");
    if (o.user_id !== l.unifiedUserId)
      throw new r("\u52D5\u753B\u306B\u30A2\u30AF\u30BB\u30B9\u3059\u308B\u6A29\u9650\u304C\u3042\u308A\u307E\u305B\u3093");
    let n, a;
    if (i.courseId) {
      let c = await t.db.get(i.courseId);
      if (!c)
        throw new r("\u6307\u5B9A\u3055\u308C\u305F\u30B3\u30FC\u30B9\u304C\u898B\u3064\u304B\u308A\u307E\u305B\u3093");
      if (c.created_by !== l.unifiedUserId)
        throw new r("\u30B3\u30FC\u30B9\u3092\u7DE8\u96C6\u3059\u308B\u6A29\u9650\u304C\u3042\u308A\u307E\u305B\u3093");
      let u = i.orderIndex;
      if (u === void 0) {
        let _ = await t.db.query("modules").withIndex("by_course_order", (b) => b.eq("course_id", i.courseId)).order("desc").first();
        u = _ ? _.order_index + 1 : 0;
      }
      n = await t.db.insert("modules", {
        course_id: i.courseId,
        title: i.moduleTitle,
        description: i.moduleDescription || "",
        duration_minutes: o.duration_seconds ? Math.ceil(o.duration_seconds / 60) : 0,
        order_index: u,
        content_type: "video",
        content_url: o.url,
        is_published: !1
      }), await t.db.patch(i.courseId, {
        modules_count: c.modules_count + 1
      }), a = "new_course";
    } else if (i.trainingId) {
      if (!await t.db.get(i.trainingId))
        throw new r("\u6307\u5B9A\u3055\u308C\u305F\u30C8\u30EC\u30FC\u30CB\u30F3\u30B0\u304C\u898B\u3064\u304B\u308A\u307E\u305B\u3093");
      let u = i.orderIndex;
      if (u === void 0) {
        let _ = await t.db.query("trainingModules").withIndex("by_training_id", (b) => b.eq("training_id", i.trainingId)).order("desc").first();
        u = _ ? _.order_index + 1 : 0;
      }
      n = await t.db.insert("trainingModules", {
        training_id: i.trainingId,
        title: i.moduleTitle,
        description: i.moduleDescription || "",
        duration_minutes: o.duration_seconds ? Math.ceil(o.duration_seconds / 60) : 0,
        order_index: u,
        content_type: "video",
        content: o.description || "",
        file_url: o.url,
        file_type: o.content_type || "video/mp4"
      }), a = "legacy_training";
    } else
      throw new r("\u30B3\u30FC\u30B9ID\u307E\u305F\u306F\u30C8\u30EC\u30FC\u30CB\u30F3\u30B0ID\u306E\u3044\u305A\u308C\u304B\u3092\u6307\u5B9A\u3057\u3066\u304F\u3060\u3055\u3044");
    return {
      success: !0,
      message: "\u52D5\u753B\u304C\u30EC\u30C3\u30B9\u30F3\u3068\u3057\u3066\u6B63\u5E38\u306B\u8FFD\u52A0\u3055\u308C\u307E\u3057\u305F",
      moduleId: n,
      moduleType: a
    };
  }, "handler")
}), j = y({
  args: {
    videoId: e.id("videos"),
    courseTitle: e.string(),
    courseDescription: e.string(),
    category: e.string(),
    moduleTitle: e.optional(e.string()),
    moduleDescription: e.optional(e.string())
  },
  returns: e.object({
    success: e.boolean(),
    message: e.string(),
    courseId: e.optional(e.id("courses")),
    moduleId: e.optional(e.id("modules"))
  }),
  handler: /* @__PURE__ */ w(async (t, i) => {
    let l = await g(t), o = await t.db.get(i.videoId);
    if (!o)
      throw new r("\u6307\u5B9A\u3055\u308C\u305F\u52D5\u753B\u304C\u898B\u3064\u304B\u308A\u307E\u305B\u3093");
    if (o.user_id !== l.unifiedUserId)
      throw new r("\u52D5\u753B\u306B\u30A2\u30AF\u30BB\u30B9\u3059\u308B\u6A29\u9650\u304C\u3042\u308A\u307E\u305B\u3093");
    if (await t.db.query("courses").withIndex("by_title", (u) => u.eq("title", i.courseTitle)).first())
      throw new r("\u540C\u3058\u540D\u524D\u306E\u30B3\u30FC\u30B9\u304C\u65E2\u306B\u5B58\u5728\u3057\u307E\u3059");
    let a = await t.db.insert("courses", {
      title: i.courseTitle,
      description: i.courseDescription,
      category: i.category,
      duration_minutes: o.duration_seconds ? Math.ceil(o.duration_seconds / 60) : 0,
      thumbnail_url: o.thumbnail_url,
      is_published: !1,
      created_by: l.unifiedUserId,
      modules_count: 1
    }), c = await t.db.insert("modules", {
      course_id: a,
      title: i.moduleTitle || o.title,
      description: i.moduleDescription || o.description || "",
      duration_minutes: o.duration_seconds ? Math.ceil(o.duration_seconds / 60) : 0,
      order_index: 0,
      content_type: "video",
      content_url: o.url,
      is_published: !1
    });
    return {
      success: !0,
      message: "\u52D5\u753B\u304B\u3089\u65B0\u3057\u3044\u30B3\u30FC\u30B9\u304C\u6B63\u5E38\u306B\u4F5C\u6210\u3055\u308C\u307E\u3057\u305F",
      courseId: a,
      moduleId: c
    };
  }, "handler")
}), L = h({
  args: {
    limit: e.optional(e.number()),
    offset: e.optional(e.number()),
    search: e.optional(e.string())
  },
  returns: e.object({
    videos: e.array(
      e.object({
        _id: e.id("videos"),
        title: e.string(),
        description: e.optional(e.string()),
        url: e.string(),
        thumbnail_url: e.optional(e.string()),
        duration_seconds: e.optional(e.number()),
        duration_display: e.string(),
        content_type: e.optional(e.string()),
        processing_status: e.optional(e.string()),
        labels: e.optional(e.array(e.string())),
        intervieweeName: e.optional(e.string()),
        _creationTime: e.number(),
        isAlreadyUsed: e.boolean(),
        usedInCourses: e.array(
          e.object({
            moduleId: e.union(e.id("modules"), e.id("trainingModules")),
            courseId: e.union(e.id("courses"), e.id("trainings")),
            courseTitle: e.string(),
            moduleTitle: e.string(),
            courseType: e.union(e.literal("new_course"), e.literal("legacy_training"))
          })
        )
      })
    ),
    total: e.number(),
    hasMore: e.boolean()
  }),
  handler: /* @__PURE__ */ w(async (t, i) => {
    let l = await g(t), o = i.limit || 20, n = i.offset || 0, c = await t.db.query("videos").withIndex("by_user_id", (s) => s.eq("user_id", l.unifiedUserId)).filter((s) => s.eq(s.field("processing_status"), "completed")).order("desc").collect();
    if (i.search) {
      let s = i.search.toLowerCase();
      c = c.filter(
        (p) => p.title.toLowerCase().includes(s) || p.description && p.description.toLowerCase().includes(s) || p.intervieweeName && p.intervieweeName.toLowerCase().includes(s)
      );
    }
    let u = c.length, _ = c.slice(n, n + o);
    return {
      videos: await Promise.all(
        _.map(async (s) => {
          let p = await t.db.query("modules").filter((d) => d.eq(d.field("content_url"), s.url)).collect(), M = await t.db.query("trainingModules").filter((d) => d.eq(d.field("file_url"), s.url)).collect(), I = [];
          for (let d of p) {
            let m = await t.db.get(d.course_id);
            m && I.push({
              moduleId: d._id,
              courseId: m._id,
              courseTitle: m.title,
              moduleTitle: d.title,
              courseType: "new_course"
            });
          }
          for (let d of M) {
            let m = await t.db.get(d.training_id);
            m && I.push({
              moduleId: d._id,
              courseId: m._id,
              courseTitle: m.title,
              moduleTitle: d.title,
              courseType: "legacy_training"
            });
          }
          let f = "\u4E0D\u660E";
          if (s.duration_seconds) {
            let d = Math.floor(s.duration_seconds / 60), m = s.duration_seconds % 60;
            d > 0 ? f = `${d}\u5206${m}\u79D2` : f = `${m}\u79D2`;
          }
          return {
            _id: s._id,
            title: s.title,
            description: s.description,
            url: s.url,
            thumbnail_url: s.thumbnail_url,
            duration_seconds: s.duration_seconds,
            duration_display: f,
            content_type: s.content_type,
            processing_status: s.processing_status,
            labels: s.labels,
            intervieweeName: s.intervieweeName,
            _creationTime: s._creationTime,
            isAlreadyUsed: I.length > 0,
            usedInCourses: I
          };
        })
      ),
      total: u,
      hasMore: n + o < u
    };
  }, "handler")
}), V = h({
  args: {},
  returns: e.object({
    newCourses: e.array(
      e.object({
        _id: e.id("courses"),
        title: e.string(),
        description: e.string(),
        category: e.string(),
        modules_count: e.number(),
        is_published: e.boolean(),
        type: e.literal("new_course")
      })
    ),
    legacyTrainings: e.array(
      e.object({
        _id: e.id("trainings"),
        title: e.string(),
        description: e.optional(e.string()),
        category: e.optional(e.string()),
        type: e.literal("legacy_training")
      })
    )
  }),
  handler: /* @__PURE__ */ w(async (t) => {
    let i = await g(t), l = await t.db.query("courses").withIndex("by_creator", (n) => n.eq("created_by", i.unifiedUserId)).collect(), o = await t.db.query("trainings").collect();
    return {
      newCourses: l.map((n) => ({
        _id: n._id,
        title: n.title,
        description: n.description,
        category: n.category,
        modules_count: n.modules_count,
        is_published: n.is_published,
        type: "new_course"
      })),
      legacyTrainings: o.map((n) => ({
        _id: n._id,
        title: n.title,
        description: n.description,
        category: n.category,
        type: "legacy_training"
      }))
    };
  }, "handler")
}), N = y({
  args: {
    moduleId: e.union(e.id("modules"), e.id("trainingModules")),
    moduleType: e.union(e.literal("new_course"), e.literal("legacy_training")),
    videoId: e.id("videos")
  },
  returns: e.object({
    success: e.boolean(),
    message: e.string()
  }),
  handler: /* @__PURE__ */ w(async (t, i) => {
    let l = await g(t), o = await t.db.get(i.videoId);
    if (!o || o.user_id !== l.unifiedUserId)
      throw new r("\u52D5\u753B\u306B\u30A2\u30AF\u30BB\u30B9\u3059\u308B\u6A29\u9650\u304C\u3042\u308A\u307E\u305B\u3093");
    if (i.moduleType === "new_course") {
      let n = await t.db.get(i.moduleId);
      if (!n)
        throw new r("\u6307\u5B9A\u3055\u308C\u305F\u30E2\u30B8\u30E5\u30FC\u30EB\u304C\u898B\u3064\u304B\u308A\u307E\u305B\u3093");
      let a = await t.db.get(n.course_id);
      if (!a || a.created_by !== l.unifiedUserId)
        throw new r("\u30E2\u30B8\u30E5\u30FC\u30EB\u3092\u524A\u9664\u3059\u308B\u6A29\u9650\u304C\u3042\u308A\u307E\u305B\u3093");
      await t.db.delete(i.moduleId), await t.db.patch(n.course_id, {
        modules_count: Math.max(0, a.modules_count - 1)
      });
    } else {
      if (!await t.db.get(i.moduleId))
        throw new r("\u6307\u5B9A\u3055\u308C\u305F\u30E2\u30B8\u30E5\u30FC\u30EB\u304C\u898B\u3064\u304B\u308A\u307E\u305B\u3093");
      await t.db.delete(i.moduleId);
    }
    return {
      success: !0,
      message: "\u30EC\u30C3\u30B9\u30F3\u304B\u3089\u52D5\u753B\u304C\u6B63\u5E38\u306B\u524A\u9664\u3055\u308C\u307E\u3057\u305F"
    };
  }, "handler")
}), A = y({
  args: {
    moduleId: e.union(e.id("modules"), e.id("trainingModules")),
    moduleType: e.union(e.literal("new_course"), e.literal("legacy_training")),
    moduleTitle: e.string(),
    moduleDescription: e.optional(e.string())
  },
  returns: e.object({
    success: e.boolean(),
    message: e.string()
  }),
  handler: /* @__PURE__ */ w(async (t, i) => {
    let l = await g(t);
    if (i.moduleType === "new_course") {
      let o = await t.db.get(i.moduleId);
      if (!o)
        throw new r("\u6307\u5B9A\u3055\u308C\u305F\u30EC\u30C3\u30B9\u30F3\u304C\u898B\u3064\u304B\u308A\u307E\u305B\u3093");
      let n = await t.db.get(o.course_id);
      if (!n || n.created_by !== l.unifiedUserId)
        throw new r("\u30EC\u30C3\u30B9\u30F3\u3092\u7DE8\u96C6\u3059\u308B\u6A29\u9650\u304C\u3042\u308A\u307E\u305B\u3093");
      await t.db.patch(i.moduleId, {
        title: i.moduleTitle.trim(),
        description: i.moduleDescription?.trim() || ""
      });
    } else {
      if (!await t.db.get(i.moduleId))
        throw new r("\u6307\u5B9A\u3055\u308C\u305F\u30EC\u30C3\u30B9\u30F3\u304C\u898B\u3064\u304B\u308A\u307E\u305B\u3093");
      await t.db.patch(i.moduleId, {
        title: i.moduleTitle.trim(),
        description: i.moduleDescription?.trim() || ""
      });
    }
    return {
      success: !0,
      message: "\u30EC\u30C3\u30B9\u30F3\u60C5\u5831\u304C\u6B63\u5E38\u306B\u66F4\u65B0\u3055\u308C\u307E\u3057\u305F"
    };
  }, "handler")
});
export {
  D as addVideoToModule,
  j as createCourseFromVideo,
  V as getAvailableCourses,
  L as getAvailableVideos,
  N as removeVideoFromLesson,
  A as updateVideoLesson
};
//# sourceMappingURL=lessonManagement.js.map
