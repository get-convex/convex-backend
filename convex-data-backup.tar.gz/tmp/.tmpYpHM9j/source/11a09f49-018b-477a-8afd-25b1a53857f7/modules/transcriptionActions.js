"use node";
import {
  a
} from "./_deps/node/N4BEONGG.js";
import {
  a as l
} from "./_deps/node/VTOLWO7E.js";
import {
  c as t
} from "./_deps/node/PDGHC3PS.js";
import {
  a as e
} from "./_deps/node/UDHF6CTX.js";
import {
  a as i
} from "./_deps/node/V7X2J7BI.js";

// convex/transcriptionActions.ts
var L = t({
  args: {
    fileUrl: e.string(),
    fileType: e.string(),
    options: e.object({
      enableSpeakerDiarization: e.optional(e.boolean()),
      language: e.optional(e.string())
    })
  },
  returns: e.object({
    text: e.string(),
    segments: e.optional(e.any()),
    confidence: e.optional(e.number()),
    duration_seconds: e.optional(e.number())
  }),
  handler: /* @__PURE__ */ i(async (c, n) => {
    try {
      console.log(`[performElevenLabsTranscription] \u958B\u59CB: ${n.fileUrl}`), console.log(`[performElevenLabsTranscription] \u30D5\u30A1\u30A4\u30EB\u30BF\u30A4\u30D7: ${n.fileType}`), console.log("[performElevenLabsTranscription] \u30AA\u30D7\u30B7\u30E7\u30F3:", n.options);
      let o = n.fileUrl;
      if (n.fileUrl.includes("storage.googleapis.com") || n.fileUrl.startsWith("gs://")) {
        console.log("[performElevenLabsTranscription] GCS\u30D5\u30A1\u30A4\u30EB\u691C\u51FA\u3001\u7F72\u540D\u4ED8\u304DURL\u751F\u6210\u4E2D...");
        try {
          let r = await c.runAction(l.training.generateContentFileSignedUrl, {
            fileUrl: n.fileUrl,
            expirationMinutes: 60
            // 1時間有効
          });
          if (console.log("[performElevenLabsTranscription] \u7F72\u540D\u4ED8\u304DURL\u7D50\u679C:", {
            success: r.success,
            hasSignedUrl: !!r.signedUrl,
            error: r.error
          }), r.success && r.signedUrl)
            o = r.signedUrl, console.log(`[performElevenLabsTranscription] \u7F72\u540D\u4ED8\u304DURL\u751F\u6210\u6210\u529F: ${o.substring(0, 100)}...`);
          else
            throw console.error("[performElevenLabsTranscription] \u7F72\u540D\u4ED8\u304DURL\u751F\u6210\u5931\u6557:", r.error), new Error(`\u7F72\u540D\u4ED8\u304DURL\u751F\u6210\u306B\u5931\u6557: ${r.error}`);
        } catch (r) {
          throw console.error("[performElevenLabsTranscription] \u7F72\u540D\u4ED8\u304DURL\u751F\u6210\u3067\u30A8\u30E9\u30FC:", r), new Error(`\u7F72\u540D\u4ED8\u304DURL\u751F\u6210\u30A8\u30E9\u30FC: ${r instanceof Error ? r.message : String(r)}`);
        }
      } else
        console.log(`[performElevenLabsTranscription] \u975EGCS\u30D5\u30A1\u30A4\u30EB\u3001\u76F4\u63A5URL\u3092\u4F7F\u7528: ${n.fileUrl}`);
      console.log(`[performElevenLabsTranscription] \u6587\u5B57\u8D77\u3053\u3057\u5B9F\u884C\u958B\u59CB - URL: ${o.substring(0, 100)}...`);
      let s = await a(o, n.fileType, n.options);
      return console.log("[performElevenLabsTranscription] \u6587\u5B57\u8D77\u3053\u3057\u5B8C\u4E86:", {
        textLength: s.text?.length || 0,
        segmentsCount: s.segments?.length || 0,
        confidence: s.confidence
      }), s;
    } catch (o) {
      console.error("[performElevenLabsTranscription] \u30A8\u30E9\u30FC:", o), console.error("[performElevenLabsTranscription] \u30A8\u30E9\u30FC\u30B9\u30BF\u30C3\u30AF:", o instanceof Error ? o.stack : "No stack trace");
      let s = "\u4E0D\u660E\u306A\u30A8\u30E9\u30FC";
      throw o instanceof Error && (s = o.message, s.includes("fetch failed") && (s = `\u30CD\u30C3\u30C8\u30EF\u30FC\u30AF\u63A5\u7D9A\u30A8\u30E9\u30FC: ${s}. URL\u3078\u306E\u30A2\u30AF\u30BB\u30B9\u306B\u5931\u6557\u3057\u307E\u3057\u305F\u3002`)), new Error(`ElevenLabs\u6587\u5B57\u8D77\u3053\u3057\u51E6\u7406\u30A8\u30E9\u30FC: ${s}`);
    }
  }, "handler")
});
export {
  L as performElevenLabsTranscription
};
//# sourceMappingURL=transcriptionActions.js.map
