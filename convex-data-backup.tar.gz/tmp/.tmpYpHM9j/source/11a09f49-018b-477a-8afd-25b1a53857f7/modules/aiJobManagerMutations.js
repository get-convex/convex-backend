import {
  b as a,
  d as _
} from "./_deps/75JH2J25.js";
import "./_deps/6XQQNYIR.js";
import {
  j as t,
  n as b
} from "./_deps/3TDUHHJO.js";
import {
  a as s
} from "./_deps/RUVYHBJQ.js";

// convex/aiJobManagerMutations.ts
b();
var y = _({
  args: {
    transcription_id: t.id("transcriptions"),
    job_type: t.union(
      t.literal("audio_analysis"),
      t.literal("evaluation"),
      t.literal("meeting_minutes"),
      t.literal("case_summary"),
      t.literal("meeting_summary")
    ),
    parent_job_id: t.optional(t.id("aiProcessingJobs")),
    step: t.optional(t.number()),
    total_steps: t.optional(t.number())
  },
  returns: t.id("aiProcessingJobs"),
  handler: /* @__PURE__ */ s(async (o, e) => {
    let r = Date.now(), n = await o.db.insert("aiProcessingJobs", {
      transcription_id: e.transcription_id,
      job_type: e.job_type,
      status: "pending",
      parent_job_id: e.parent_job_id,
      step: e.step,
      total_steps: e.total_steps,
      error_count: 0,
      retry_count: 0,
      max_retries: 3,
      created_at: r,
      updated_at: r
    });
    return console.log(`[createJob] \u65B0\u3057\u3044\u30B8\u30E7\u30D6\u3092\u4F5C\u6210: ${n} (type: ${e.job_type})`), n;
  }, "handler")
}), j = _({
  args: {
    job_id: t.id("aiProcessingJobs"),
    status: t.union(
      t.literal("pending"),
      t.literal("processing"),
      t.literal("completed"),
      t.literal("failed"),
      t.literal("cancelled")
    ),
    current_action: t.optional(t.string()),
    result_data: t.optional(t.string()),
    error_message: t.optional(t.string()),
    processing_duration_ms: t.optional(t.number())
  },
  returns: t.null(),
  handler: /* @__PURE__ */ s(async (o, e) => {
    let r = {
      status: e.status,
      updated_at: Date.now()
    };
    if (e.current_action !== void 0 && (r.current_action = e.current_action), e.result_data !== void 0 && (r.result_data = e.result_data), e.processing_duration_ms !== void 0 && (r.processing_duration_ms = e.processing_duration_ms), e.status === "processing" ? r.started_at = Date.now() : (e.status === "completed" || e.status === "failed") && (r.completed_at = Date.now()), e.error_message) {
      let n = await o.db.get(e.job_id);
      n && (r.error_message = e.error_message, r.error_count = (n.error_count || 0) + 1, r.last_error_at = Date.now());
    }
    return await o.db.patch(e.job_id, r), console.log(`[updateJobStatus] \u30B8\u30E7\u30D6\u30B9\u30C6\u30FC\u30BF\u30B9\u66F4\u65B0: ${e.job_id} -> ${e.status}`), null;
  }, "handler")
}), f = a({
  args: {
    transcription_id: t.id("transcriptions"),
    current_step: t.number()
  },
  returns: t.union(t.id("aiProcessingJobs"), t.null()),
  handler: /* @__PURE__ */ s(async (o, e) => (await o.db.query("aiProcessingJobs").withIndex(
    "by_transcription_status",
    (n) => n.eq("transcription_id", e.transcription_id).eq("status", "pending")
  ).filter((n) => n.gt(n.field("step"), e.current_step)).order("asc").first())?._id || null, "handler")
}), J = a({
  args: {
    job_id: t.id("aiProcessingJobs")
  },
  returns: t.union(
    t.object({
      _id: t.id("aiProcessingJobs"),
      transcription_id: t.id("transcriptions"),
      job_type: t.string(),
      status: t.string(),
      step: t.optional(t.number()),
      total_steps: t.optional(t.number()),
      current_action: t.optional(t.string()),
      result_data: t.optional(t.string()),
      error_message: t.optional(t.string()),
      error_count: t.optional(t.number()),
      retry_count: t.optional(t.number()),
      max_retries: t.optional(t.number()),
      next_job_id: t.optional(t.id("aiProcessingJobs")),
      parent_job_id: t.optional(t.id("aiProcessingJobs")),
      created_at: t.number(),
      started_at: t.optional(t.number()),
      completed_at: t.optional(t.number()),
      updated_at: t.number()
    }),
    t.null()
  ),
  handler: /* @__PURE__ */ s(async (o, e) => await o.db.get(e.job_id), "handler")
}), w = _({
  args: {
    job_id: t.id("aiProcessingJobs"),
    retry_count: t.number()
  },
  returns: t.null(),
  handler: /* @__PURE__ */ s(async (o, e) => (await o.db.patch(e.job_id, {
    retry_count: e.retry_count,
    status: "pending",
    // リトライのためにpendingに戻す
    updated_at: Date.now()
  }), null), "handler")
}), h = a({
  args: {
    transcription_id: t.id("transcriptions")
  },
  returns: t.array(t.object({
    _id: t.id("aiProcessingJobs"),
    job_type: t.string(),
    status: t.string(),
    step: t.optional(t.number()),
    error_message: t.optional(t.string()),
    created_at: t.number(),
    completed_at: t.optional(t.number()),
    processing_duration_ms: t.optional(t.number())
  })),
  handler: /* @__PURE__ */ s(async (o, e) => (await o.db.query("aiProcessingJobs").withIndex("by_transcription_id", (n) => n.eq("transcription_id", e.transcription_id)).order("desc").collect()).map((n) => ({
    _id: n._id,
    job_type: n.job_type,
    status: n.status,
    step: n.step,
    error_message: n.error_message,
    created_at: n.created_at,
    completed_at: n.completed_at,
    processing_duration_ms: n.processing_duration_ms
  })), "handler")
}), P = a({
  args: {
    transcription_id: t.id("transcriptions")
  },
  returns: t.object({
    total_jobs: t.number(),
    completed_jobs: t.number(),
    failed_jobs: t.number(),
    processing_jobs: t.number(),
    overall_status: t.string(),
    progress_percentage: t.number()
  }),
  handler: /* @__PURE__ */ s(async (o, e) => {
    let r = await o.db.query("aiProcessingJobs").withIndex("by_transcription_id", (i) => i.eq("transcription_id", e.transcription_id)).collect(), n = r.length, c = r.filter((i) => i.status === "completed").length, p = r.filter((i) => i.status === "failed").length, l = r.filter((i) => i.status === "processing").length, d = "pending";
    p > 0 ? d = "failed" : c === n && n > 0 ? d = "completed" : l > 0 && (d = "processing");
    let u = n > 0 ? Math.round(c / n * 100) : 0;
    return {
      total_jobs: n,
      completed_jobs: c,
      failed_jobs: p,
      processing_jobs: l,
      overall_status: d,
      progress_percentage: u
    };
  }, "handler")
});
export {
  y as createJob,
  J as getJob,
  h as getJobsByTranscription,
  f as getNextJob,
  P as getProcessingProgress,
  w as updateJobRetryCount,
  j as updateJobStatus
};
//# sourceMappingURL=aiJobManagerMutations.js.map
