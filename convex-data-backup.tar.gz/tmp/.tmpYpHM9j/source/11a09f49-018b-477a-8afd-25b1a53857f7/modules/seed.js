import {
  b as _,
  e as b
} from "./_deps/IVQGLTSC.js";
import {
  c as y,
  d as g
} from "./_deps/75JH2J25.js";
import "./_deps/6XQQNYIR.js";
import {
  j as t,
  n as f
} from "./_deps/3TDUHHJO.js";
import {
  a as p
} from "./_deps/RUVYHBJQ.js";

// convex/seed.ts
f();
b();
var h = [
  {
    title: "\u55B6\u696D\u57FA\u790E\u7814\u4FEE\uFF08\u5B9F\u8DF5\u7248\uFF09",
    description: "\u5B9F\u969B\u306E\u52D5\u753B\u3068PDF\u3092\u6D3B\u7528\u3057\u305F\u55B6\u696D\u306E\u57FA\u672C\u30B9\u30AD\u30EB\u7FD2\u5F97\u30D7\u30ED\u30B0\u30E9\u30E0",
    category: "\u55B6\u696D\u30B9\u30AD\u30EB",
    duration_minutes: 480,
    priority: "must",
    modules: [
      {
        title: "\u55B6\u696D\u30DE\u30A4\u30F3\u30C9\u30BB\u30C3\u30C8\u5B9F\u8DF5",
        description: "\u6210\u529F\u3059\u308B\u55B6\u696D\u30D1\u30FC\u30BD\u30F3\u306E\u8003\u3048\u65B9\u3068\u5B9F\u8DF5\u7684\u30A2\u30AF\u30B7\u30E7\u30F3",
        duration_minutes: 90,
        order_index: 1,
        contents: [
          {
            title: "\u30D7\u30ED\u30D5\u30A7\u30C3\u30B7\u30E7\u30CA\u30EB\u55B6\u696D\u306E\u5FC3\u69CB\u3048",
            content: "\u55B6\u696D\u6D3B\u52D5\u306E\u57FA\u672C\u3068\u306A\u308B\u8003\u3048\u65B9\u3084\u59FF\u52E2\u306B\u3064\u3044\u3066\u5B66\u3073\u307E\u3059\u3002\u9867\u5BA2\u4E2D\u5FC3\u306E\u8003\u3048\u65B9\u3084\u4FE1\u983C\u95A2\u4FC2\u69CB\u7BC9\u306E\u91CD\u8981\u6027\u3092\u7406\u89E3\u3057\u307E\u3057\u3087\u3046\u3002",
            content_type: "text",
            order_index: 1
          },
          {
            title: "\u55B6\u696D\u30DE\u30A4\u30F3\u30C9\u30BB\u30C3\u30C8\u5B9F\u8DF5\u30AC\u30A4\u30C9",
            content: "\u55B6\u696D\u6D3B\u52D5\u306B\u304A\u3051\u308B\u57FA\u672C\u7684\u306A\u5FC3\u69CB\u3048\u3068\u30D7\u30ED\u30BB\u30B9\u3092\u89E3\u8AAC\u3057\u307E\u3059\u3002",
            content_type: "pdf",
            order_index: 2
          },
          {
            title: "\u5B9F\u8DF5\u30EF\u30FC\u30AF\uFF1A\u76EE\u6A19\u8A2D\u5B9A",
            content: "\u500B\u4EBA\u306E\u55B6\u696D\u76EE\u6A19\u3092\u8A2D\u5B9A\u3057\u3001\u9054\u6210\u306E\u305F\u3081\u306E\u5177\u4F53\u7684\u306A\u30A2\u30AF\u30B7\u30E7\u30F3\u30D7\u30E9\u30F3\u3092\u7B56\u5B9A\u3057\u307E\u3057\u3087\u3046\u3002",
            content_type: "text",
            order_index: 3
          }
        ]
      },
      {
        title: "\u9867\u5BA2\u7406\u89E3\u3068\u30D2\u30A2\u30EA\u30F3\u30B0\u6280\u6CD5",
        description: "SPIN\u55B6\u696D\u6280\u6CD5\u3068\u52B9\u679C\u7684\u306A\u8CEA\u554F\u6280\u8853\u306E\u5B9F\u8DF5",
        duration_minutes: 120,
        order_index: 2,
        contents: [
          {
            title: "SPIN\u55B6\u696D\u6280\u6CD5\u5B8C\u5168\u30AC\u30A4\u30C9",
            content: "SPIN\uFF08Situation, Problem, Implication, Need-payoff\uFF09\u55B6\u696D\u6280\u6CD5\u306E\u8A73\u7D30\u306A\u89E3\u8AAC\u3068\u5B9F\u8DF5\u65B9\u6CD5\u3092\u5B66\u3073\u307E\u3059\u3002",
            content_type: "pdf",
            order_index: 1
          },
          {
            title: "\u52B9\u679C\u7684\u306A\u8CEA\u554F\u6280\u8853",
            content: "\u9867\u5BA2\u306E\u30CB\u30FC\u30BA\u3092\u5F15\u304D\u51FA\u3059\u305F\u3081\u306E\u6226\u7565\u7684\u306A\u8CEA\u554F\u624B\u6CD5\u3092\u7FD2\u5F97\u3057\u307E\u3057\u3087\u3046\u3002",
            content_type: "text",
            order_index: 2
          },
          {
            title: "\u30D2\u30A2\u30EA\u30F3\u30B0\u5B9F\u8DF5\u6F14\u7FD2",
            content: "\u5B9F\u969B\u306E\u30B7\u30CA\u30EA\u30AA\u3092\u4F7F\u3063\u305F\u30D2\u30A2\u30EA\u30F3\u30B0\u7DF4\u7FD2\u3067\u3001\u8CEA\u554F\u30B9\u30AD\u30EB\u3092\u5411\u4E0A\u3055\u305B\u307E\u3059\u3002",
            content_type: "text",
            order_index: 3
          }
        ]
      },
      {
        title: "\u63D0\u6848\u529B\u5F37\u5316\u3068\u8CC7\u6599\u4F5C\u6210",
        description: "\u8AAC\u5F97\u529B\u306E\u3042\u308B\u63D0\u6848\u66F8\u4F5C\u6210\u3068\u30D7\u30EC\u30BC\u30F3\u30C6\u30FC\u30B7\u30E7\u30F3\u6280\u8853",
        duration_minutes: 150,
        order_index: 3,
        contents: [
          {
            title: "\u52B9\u679C\u7684\u306A\u63D0\u6848\u66F8\u4F5C\u6210\u5B8C\u5168\u30AC\u30A4\u30C9",
            content: "\u8AAD\u307F\u624B\u3092\u60F9\u304D\u3064\u3051\u308B\u63D0\u6848\u66F8\u306E\u69CB\u6210\u3068\u4F5C\u6210\u65B9\u6CD5\u3092\u8A73\u3057\u304F\u5B66\u3073\u307E\u3059\u3002",
            content_type: "pdf",
            order_index: 1
          },
          {
            title: "\u30C7\u30FC\u30BF\u6D3B\u7528\u3068\u30B9\u30C8\u30FC\u30EA\u30FC\u30C6\u30EA\u30F3\u30B0",
            content: "\u6570\u5024\u30C7\u30FC\u30BF\u3092\u52B9\u679C\u7684\u306B\u6D3B\u7528\u3057\u3001\u8AAC\u5F97\u529B\u306E\u3042\u308B\u30B9\u30C8\u30FC\u30EA\u30FC\u3092\u69CB\u7BC9\u3059\u308B\u65B9\u6CD5\u3092\u5B66\u7FD2\u3057\u307E\u3059\u3002",
            content_type: "text",
            order_index: 2
          },
          {
            title: "\u30D7\u30EC\u30BC\u30F3\u30C6\u30FC\u30B7\u30E7\u30F3\u5B9F\u8DF5",
            content: "\u63D0\u6848\u66F8\u3092\u4F7F\u3063\u305F\u52B9\u679C\u7684\u306A\u30D7\u30EC\u30BC\u30F3\u30C6\u30FC\u30B7\u30E7\u30F3\u624B\u6CD5\u3092\u5B9F\u8DF5\u7684\u306B\u5B66\u3073\u307E\u3059\u3002",
            content_type: "text",
            order_index: 3
          }
        ]
      }
    ]
  },
  {
    title: "\u65B0\u4EBA\u55B6\u696D\u5B9F\u8DF5\u30D7\u30ED\u30B0\u30E9\u30E0",
    description: "\u55B6\u696D\u672A\u7D4C\u9A13\u8005\u5411\u3051\u306E\u6BB5\u968E\u7684\u30B9\u30AD\u30EB\u7FD2\u5F97\u30AB\u30EA\u30AD\u30E5\u30E9\u30E0",
    category: "\u65B0\u4EBA\u7814\u4FEE",
    duration_minutes: 600,
    priority: "recommended",
    modules: [
      {
        title: "\u30D3\u30B8\u30CD\u30B9\u30DE\u30CA\u30FC\u3068\u57FA\u790E\u77E5\u8B58",
        description: "\u793E\u4F1A\u4EBA\u3068\u3057\u3066\u5FC5\u8981\u306A\u57FA\u672C\u30DE\u30CA\u30FC\u3068\u30B3\u30DF\u30E5\u30CB\u30B1\u30FC\u30B7\u30E7\u30F3",
        duration_minutes: 150,
        order_index: 1,
        contents: [
          {
            title: "\u30D3\u30B8\u30CD\u30B9\u30DE\u30CA\u30FC\u57FA\u790E",
            content: "\u793E\u4F1A\u4EBA\u3068\u3057\u3066\u6C42\u3081\u3089\u308C\u308B\u57FA\u672C\u7684\u306A\u30DE\u30CA\u30FC\u3068\u30A8\u30C1\u30B1\u30C3\u30C8\u3092\u5B66\u3073\u307E\u3059\u3002",
            content_type: "text",
            order_index: 1
          },
          {
            title: "\u96FB\u8A71\u5FDC\u5BFE\u30DE\u30CB\u30E5\u30A2\u30EB\u5B8C\u5168\u7248",
            content: "\u9069\u5207\u306A\u96FB\u8A71\u5FDC\u5BFE\u306E\u65B9\u6CD5\u3068\u6CE8\u610F\u70B9\u3092\u8A73\u3057\u304F\u89E3\u8AAC\u3057\u307E\u3059\u3002",
            content_type: "pdf",
            order_index: 2
          },
          {
            title: "\u540D\u523A\u4EA4\u63DB\u3068\u30D3\u30B8\u30CD\u30B9\u6328\u62F6",
            content: "\u6B63\u3057\u3044\u540D\u523A\u4EA4\u63DB\u306E\u4F5C\u6CD5\u3068\u30D3\u30B8\u30CD\u30B9\u30B7\u30FC\u30F3\u3067\u306E\u9069\u5207\u306A\u6328\u62F6\u65B9\u6CD5\u3092\u7FD2\u5F97\u3057\u307E\u3059\u3002",
            content_type: "text",
            order_index: 3
          }
        ]
      },
      {
        title: "\u5546\u54C1\u77E5\u8B58\u3068\u55B6\u696D\u57FA\u790E",
        description: "\u81EA\u793E\u88FD\u54C1\u7406\u89E3\u3068\u55B6\u696D\u6D3B\u52D5\u306E\u57FA\u672C\u30D7\u30ED\u30BB\u30B9",
        duration_minutes: 200,
        order_index: 2,
        contents: [
          {
            title: "AI\u55B6\u696D\u30CF\u30D6\u88FD\u54C1\u30AB\u30BF\u30ED\u30B0\u5B8C\u5168\u7248",
            content: "\u5F53\u793E\u306EAI\u55B6\u696D\u652F\u63F4\u30C4\u30FC\u30EB\u306E\u6A5F\u80FD\u3068\u7279\u5FB4\u3092\u8A73\u3057\u304F\u7406\u89E3\u3057\u307E\u3057\u3087\u3046\u3002",
            content_type: "pdf",
            order_index: 1
          },
          {
            title: "\u7AF6\u5408\u5206\u6790\u3068\u5DEE\u5225\u5316\u30DD\u30A4\u30F3\u30C8",
            content: "\u7AF6\u5408\u4ED6\u793E\u3068\u306E\u6BD4\u8F03\u306B\u304A\u3051\u308B\u5F53\u793E\u306E\u5F37\u307F\u3068\u5DEE\u5225\u5316\u8981\u56E0\u3092\u5B66\u7FD2\u3057\u307E\u3059\u3002",
            content_type: "text",
            order_index: 2
          },
          {
            title: "\u88FD\u54C1\u30C7\u30E2\u30F3\u30B9\u30C8\u30EC\u30FC\u30B7\u30E7\u30F3",
            content: "\u52B9\u679C\u7684\u306A\u88FD\u54C1\u30C7\u30E2\u306E\u5B9F\u65BD\u65B9\u6CD5\u3068\u9867\u5BA2\u306E\u95A2\u5FC3\u3092\u5F15\u304F\u8981\u7D20\u3092\u7406\u89E3\u3057\u307E\u3059\u3002",
            content_type: "text",
            order_index: 3
          }
        ]
      },
      {
        title: "\u5B9F\u8DF5\u30ED\u30FC\u30EB\u30D7\u30EC\u30A4",
        description: "\u5B9F\u969B\u306E\u55B6\u696D\u5834\u9762\u3092\u60F3\u5B9A\u3057\u305F\u5B9F\u8DF5\u7DF4\u7FD2",
        duration_minutes: 250,
        order_index: 3,
        contents: [
          {
            title: "\u30ED\u30FC\u30EB\u30D7\u30EC\u30A4\u30B7\u30CA\u30EA\u30AA\u96C6",
            content: "\u69D8\u3005\u306A\u696D\u754C\u30FB\u898F\u6A21\u306E\u9867\u5BA2\u3092\u60F3\u5B9A\u3057\u305F\u30ED\u30FC\u30EB\u30D7\u30EC\u30A4\u30B7\u30CA\u30EA\u30AA\u3092\u63D0\u4F9B\u3057\u307E\u3059\u3002",
            content_type: "pdf",
            order_index: 1
          },
          {
            title: "\u55B6\u696D\u30B7\u30DF\u30E5\u30EC\u30FC\u30B7\u30E7\u30F3\u5B9F\u8DF5",
            content: "\u5B9F\u969B\u306E\u55B6\u696D\u30D7\u30ED\u30BB\u30B9\u3092\u6A21\u64EC\u4F53\u9A13\u3057\u3001\u30B9\u30AD\u30EB\u3092\u5B9F\u8DF5\u7684\u306B\u5411\u4E0A\u3055\u305B\u307E\u3059\u3002",
            content_type: "text",
            order_index: 2
          },
          {
            title: "\u30D5\u30A3\u30FC\u30C9\u30D0\u30C3\u30AF\u3068\u6539\u5584",
            content: "\u30ED\u30FC\u30EB\u30D7\u30EC\u30A4\u306E\u7D50\u679C\u3092\u5206\u6790\u3057\u3001\u500B\u4EBA\u306E\u5F37\u307F\u3068\u6539\u5584\u70B9\u3092\u660E\u78BA\u5316\u3057\u307E\u3059\u3002",
            content_type: "text",
            order_index: 3
          }
        ]
      }
    ]
  },
  {
    title: "\u30C7\u30B8\u30BF\u30EB\u55B6\u696D\u30DE\u30B9\u30BF\u30FC\u30AF\u30E9\u30B9",
    description: "\u30AA\u30F3\u30E9\u30A4\u30F3\u6642\u4EE3\u306E\u55B6\u696D\u624B\u6CD5\u3068\u30C4\u30FC\u30EB\u6D3B\u7528\u8853",
    category: "\u55B6\u696D\u30B9\u30AD\u30EB",
    duration_minutes: 360,
    priority: "optional",
    modules: [
      {
        title: "\u30AA\u30F3\u30E9\u30A4\u30F3\u5546\u8AC7\u306E\u6975\u610F",
        description: "Web\u4F1A\u8B70\u30C4\u30FC\u30EB\u3092\u4F7F\u3063\u305F\u52B9\u679C\u7684\u306A\u5546\u8AC7\u9032\u884C",
        duration_minutes: 120,
        order_index: 1,
        contents: [
          {
            title: "\u30AA\u30F3\u30E9\u30A4\u30F3\u5546\u8AC7\u30D9\u30B9\u30C8\u30D7\u30E9\u30AF\u30C6\u30A3\u30B9",
            content: "Web\u4F1A\u8B70\u3067\u306E\u52B9\u679C\u7684\u306A\u5546\u8AC7\u9032\u884C\u306E\u30DD\u30A4\u30F3\u30C8\u3068\u6CE8\u610F\u4E8B\u9805\u3092\u5B66\u3073\u307E\u3059\u3002",
            content_type: "text",
            order_index: 1
          },
          {
            title: "\u30C7\u30B8\u30BF\u30EB\u30C4\u30FC\u30EB\u6D3B\u7528\u6CD5",
            content: "\u753B\u9762\u5171\u6709\u3001\u8CC7\u6599\u63D0\u793A\u3001\u30AA\u30F3\u30E9\u30A4\u30F3\u30DB\u30EF\u30A4\u30C8\u30DC\u30FC\u30C9\u306A\u3069\u306E\u52B9\u679C\u7684\u306A\u4F7F\u3044\u65B9\u3092\u7FD2\u5F97\u3057\u307E\u3059\u3002",
            content_type: "text",
            order_index: 2
          },
          {
            title: "\u30C8\u30E9\u30D6\u30EB\u30B7\u30E5\u30FC\u30C6\u30A3\u30F3\u30B0",
            content: "\u30AA\u30F3\u30E9\u30A4\u30F3\u5546\u8AC7\u3067\u3088\u304F\u767A\u751F\u3059\u308B\u6280\u8853\u7684\u554F\u984C\u3078\u306E\u5BFE\u51E6\u6CD5\u3092\u5B66\u7FD2\u3057\u307E\u3059\u3002",
            content_type: "text",
            order_index: 3
          }
        ]
      },
      {
        title: "\u30C7\u30B8\u30BF\u30EB\u30C4\u30FC\u30EB\u6D3B\u7528",
        description: "CRM\u3001MA\u3001\u5206\u6790\u30C4\u30FC\u30EB\u306E\u52B9\u679C\u7684\u306A\u4F7F\u3044\u65B9",
        duration_minutes: 120,
        order_index: 2,
        contents: [
          {
            title: "CRM\u6D3B\u7528\u306E\u57FA\u672C",
            content: "\u9867\u5BA2\u95A2\u4FC2\u7BA1\u7406\u30B7\u30B9\u30C6\u30E0\u3092\u52B9\u679C\u7684\u306B\u6D3B\u7528\u3059\u308B\u65B9\u6CD5\u3092\u5B66\u3073\u307E\u3059\u3002",
            content_type: "text",
            order_index: 1
          },
          {
            title: "\u30C7\u30FC\u30BF\u30C9\u30EA\u30D6\u30F3\u55B6\u696D",
            content: "\u55B6\u696D\u6D3B\u52D5\u306B\u304A\u3051\u308B\u610F\u601D\u6C7A\u5B9A\u306B\u30C7\u30FC\u30BF\u3092\u6D3B\u7528\u3059\u308B\u624B\u6CD5\u3092\u7FD2\u5F97\u3057\u307E\u3059\u3002",
            content_type: "text",
            order_index: 2
          },
          {
            title: "\u30DE\u30FC\u30B1\u30C6\u30A3\u30F3\u30B0\u30AA\u30FC\u30C8\u30E1\u30FC\u30B7\u30E7\u30F3\u9023\u643A",
            content: "MA\u30C4\u30FC\u30EB\u3068\u55B6\u696D\u6D3B\u52D5\u306E\u52B9\u679C\u7684\u306A\u9023\u643A\u65B9\u6CD5\u3092\u7406\u89E3\u3057\u307E\u3059\u3002",
            content_type: "text",
            order_index: 3
          }
        ]
      },
      {
        title: "\u55B6\u696D\u30C7\u30FC\u30BF\u5206\u6790",
        description: "\u30C7\u30FC\u30BF\u30C9\u30EA\u30D6\u30F3\u306A\u55B6\u696D\u6D3B\u52D5\u306E\u5B9F\u8DF5\u65B9\u6CD5",
        duration_minutes: 120,
        order_index: 3,
        contents: [
          {
            title: "\u55B6\u696D\u30E1\u30C8\u30EA\u30AF\u30B9\u5206\u6790",
            content: "\u91CD\u8981\u306A\u55B6\u696D\u6307\u6A19\u306E\u7406\u89E3\u3068\u52B9\u679C\u7684\u306A\u5206\u6790\u65B9\u6CD5\u3092\u5B66\u7FD2\u3057\u307E\u3059\u3002",
            content_type: "text",
            order_index: 1
          },
          {
            title: "\u4E88\u6E2C\u5206\u6790\u3068\u76EE\u6A19\u8A2D\u5B9A",
            content: "\u904E\u53BB\u306E\u30C7\u30FC\u30BF\u3092\u57FA\u306B\u3057\u305F\u5C06\u6765\u4E88\u6E2C\u3068\u73FE\u5B9F\u7684\u306A\u76EE\u6A19\u8A2D\u5B9A\u306E\u65B9\u6CD5\u3092\u7FD2\u5F97\u3057\u307E\u3059\u3002",
            content_type: "text",
            order_index: 2
          },
          {
            title: "\u30EC\u30DD\u30FC\u30C6\u30A3\u30F3\u30B0\u30B9\u30AD\u30EB",
            content: "\u52B9\u679C\u7684\u306A\u55B6\u696D\u30EC\u30DD\u30FC\u30C8\u306E\u4F5C\u6210\u3068\u60C5\u5831\u5171\u6709\u306E\u65B9\u6CD5\u3092\u5B66\u3073\u307E\u3059\u3002",
            content_type: "text",
            order_index: 3
          }
        ]
      }
    ]
  }
], x = [
  {
    title: "SaaS\u30B5\u30FC\u30D3\u30B9\u521D\u56DE\u63D0\u6848",
    description: "\u4E2D\u5805\u4F01\u696D\u306EIT\u90E8\u9580\u8CAC\u4EFB\u8005\u306B\u5BFE\u3057\u3066\u3001\u81EA\u793E\u306ESaaS\u30B5\u30FC\u30D3\u30B9\u3092\u521D\u3081\u3066\u63D0\u6848\u3059\u308B\u5834\u9762\u3002\u696D\u754C\u7279\u6709\u306E\u8AB2\u984C\u3092\u7406\u89E3\u3057\u3001\u89E3\u6C7A\u7B56\u3092\u63D0\u793A\u3059\u308B\u3002",
    type: "sales",
    status: "scheduled",
    max_participants: 3,
    scheduled_at: Date.now() + 3 * 24 * 60 * 60 * 1e3
    // 3日後
  },
  {
    title: "M&A\u6848\u4EF6\u306E\u521D\u56DE\u63D0\u6848",
    description: "\u4E8B\u696D\u627F\u7D99\u3092\u691C\u8A0E\u4E2D\u306E\u4E2D\u5C0F\u4F01\u696D\u30AA\u30FC\u30CA\u30FC\u306B\u5BFE\u3057\u3066\u3001M&A\u30A2\u30C9\u30D0\u30A4\u30B6\u30EA\u30FC\u30B5\u30FC\u30D3\u30B9\u3092\u63D0\u6848\u3002\u6A5F\u5BC6\u6027\u3068\u5C02\u9580\u6027\u3092\u91CD\u8996\u3057\u305F\u5BFE\u5FDC\u3002",
    type: "sales",
    status: "scheduled",
    max_participants: 4,
    scheduled_at: Date.now() + 5 * 24 * 60 * 60 * 1e3
    // 5日後
  },
  {
    title: "\u30B5\u30FC\u30D3\u30B9\u969C\u5BB3\u306E\u304A\u8A6B\u3073\u5BFE\u5FDC",
    description: "2\u6642\u9593\u306E\u30B5\u30FC\u30D3\u30B9\u505C\u6B62\u306B\u3088\u308A\u58F2\u4E0A\u6A5F\u4F1A\u640D\u5931\u304C\u767A\u751F\u3002\u9867\u5BA2\u3078\u306E\u8B1D\u7F6A\u3068\u4FE1\u983C\u56DE\u5FA9\u3001\u518D\u767A\u9632\u6B62\u7B56\u306E\u8AAC\u660E\u3002",
    type: "support",
    status: "scheduled",
    max_participants: 3,
    scheduled_at: Date.now() + 2 * 24 * 60 * 60 * 1e3
    // 2日後
  },
  {
    title: "\u65B0\u30D7\u30ED\u30C0\u30AF\u30C8\u767A\u8868\u4F1A",
    description: "\u5168\u793E\u4F1A\u8B70\u3067\u65B0\u30D7\u30ED\u30C0\u30AF\u30C8\u306E\u30B3\u30F3\u30BB\u30D7\u30C8\u3068\u5E02\u5834\u6226\u7565\u3092\u767A\u8868\u3002\u7D4C\u55B6\u9663\u306E\u627F\u8A8D\u3092\u5F97\u308B\u91CD\u8981\u306A\u30D7\u30EC\u30BC\u30F3\u30C6\u30FC\u30B7\u30E7\u30F3\u3002",
    type: "presentation",
    status: "scheduled",
    max_participants: 5,
    scheduled_at: Date.now() + 7 * 24 * 60 * 60 * 1e3
    // 7日後
  },
  {
    title: "\u65B0\u4EBA\u55B6\u696D\u306E\u521D\u56DE\u5546\u8AC7",
    description: "\u55B6\u696D\u7D4C\u9A133\u30F6\u6708\u306E\u65B0\u4EBA\u304C\u521D\u3081\u3066\u4E00\u4EBA\u3067\u884C\u3046\u5546\u8AC7\u3002\u57FA\u672C\u7684\u306A\u30DE\u30CA\u30FC\u304B\u3089\u5546\u54C1\u8AAC\u660E\u3001\u8CEA\u7591\u5FDC\u7B54\u307E\u3067\u7DCF\u5408\u7684\u306B\u30C1\u30A7\u30C3\u30AF\u3002",
    type: "training",
    status: "scheduled",
    max_participants: 3,
    scheduled_at: Date.now() + 1 * 24 * 60 * 60 * 1e3
    // 1日後
  }
], C = /* @__PURE__ */ p((n, c) => {
  let e = [
    "#4299E1",
    // ブルー
    "#48BB78",
    // グリーン
    "#ED8936",
    // オレンジ
    "#9F7AEA",
    // パープル
    "#F56565",
    // レッド
    "#38B2AC",
    // ティール
    "#ED64A6",
    // ピンク
    "#ECC94B"
    // イエロー
  ], o = n.replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#39;").replace(/&/g, "&amp;").slice(0, 50), s = e[Math.abs(c) % e.length], a = o.length > 10 ? 24 : 32;
  return `<svg width="320" height="180" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 320 180">
    <rect width="320" height="180" fill="${s}" />
    <text 
      x="160" 
      y="90" 
      font-family="system-ui, -apple-system, sans-serif" 
      font-size="${a}" 
      font-weight="600" 
      fill="white" 
      text-anchor="middle" 
      dominant-baseline="middle"
    >
      ${o}
    </text>
  </svg>`;
}, "generateThumbnailSvg"), w = /* @__PURE__ */ p((n) => `data:image/svg+xml;base64,${btoa(unescape(encodeURIComponent(n)))}`, "svgToDataUrl"), A = g({
  args: {},
  returns: t.object({
    created: t.number(),
    userIds: t.array(t.id("users"))
  }),
  handler: /* @__PURE__ */ p(async (n, c) => {
    console.warn(
      "seedBetterAuthUsers: This function is deprecated. The better_auth_users table has been migrated to the unified users table."
    );
    let e = [], o = 0, s = await n.db.query("users").take(5);
    return s.length > 0 && console.log(
      `Found ${s.length} existing users in unified table. Migration appears complete.`
    ), {
      created: o,
      userIds: e
    };
  }, "handler")
}), $ = g({
  args: {
    userIds: t.array(t.id("users"))
  },
  returns: t.object({
    trainingsCreated: t.number(),
    modulesCreated: t.number(),
    contentsCreated: t.number()
  }),
  handler: /* @__PURE__ */ p(async (n, c) => {
    let e = 0, o = 0, s = 0;
    for (let [a, i] of h.entries()) {
      let u = C(i.title, a), r = w(u), d = await n.db.insert("trainings", {
        title: i.title,
        description: i.description,
        category: i.category,
        duration_minutes: i.duration_minutes,
        priority: i.priority,
        thumbnail_url: r
      });
      e++;
      for (let l of i.modules) {
        let m = l.contents[0], I = await n.db.insert("trainingModules", {
          training_id: d,
          title: l.title,
          description: l.description,
          content: m?.content,
          content_type: m?.content_type,
          file_url: void 0,
          // サンプルデータではファイルURLなし
          file_type: void 0,
          // サンプルデータではファイルタイプなし
          duration_minutes: l.duration_minutes,
          order_index: l.order_index
        });
        o++, s += l.contents.length;
      }
    }
    return {
      trainingsCreated: e,
      modulesCreated: o,
      contentsCreated: s
    };
  }, "handler")
}), D = g({
  args: {
    userIds: t.array(t.id("users"))
  },
  returns: t.object({
    roleplaysCreated: t.number(),
    participantsCreated: t.number()
  }),
  handler: /* @__PURE__ */ p(async (n, c) => {
    let e = 0, o = 0;
    for (let s of x) {
      let a = await n.db.insert("roleplays", {
        title: s.title,
        description: s.description,
        type: s.type,
        status: s.status,
        max_participants: s.max_participants,
        scheduled_at: s.scheduled_at,
        created_by: c.userIds[0]
        // Use the first user as creator
      });
      e++;
      for (let i = 0; i < Math.min(s.max_participants, c.userIds.length); i++) {
        let u = c.userIds[i % c.userIds.length];
        await n.db.insert("roleplayParticipants", {
          roleplay_id: a,
          user_id: u,
          is_creator: i === 0,
          role: i === 0 ? "\u9032\u884C\u5F79" : `\u53C2\u52A0\u8005${i}`
        }), o++;
      }
    }
    return {
      roleplaysCreated: e,
      participantsCreated: o
    };
  }, "handler")
}), E = g({
  args: {
    userIds: t.array(t.id("users"))
  },
  returns: t.object({
    settingsCreated: t.number()
  }),
  handler: /* @__PURE__ */ p(async (n, c) => {
    let e = 0, o = [
      "evaluation_complete",
      "roleplay_application",
      "system",
      "training_reminder",
      "weekly_report"
    ], s = await n.db.query("notificationSettings").collect(), a = new Set(
      s.map((r) => `${r.user_id}:${r.notification_type}`)
    ), i = [];
    for (let r of c.userIds)
      for (let d of o) {
        let l = `${r}:${d}`;
        a.has(l) || i.push({
          user_id: r,
          notification_type: d,
          email_enabled: !0,
          system_enabled: !0,
          slack_enabled: !1
        });
      }
    let u = 25;
    for (let r = 0; r < i.length; r += u) {
      let d = i.slice(r, r + u);
      for (let l of d)
        try {
          await n.db.insert("notificationSettings", l), e++;
        } catch (m) {
          console.warn(
            `Failed to create notification setting for user ${l.user_id}, type ${l.notification_type}:`,
            m
          );
        }
    }
    return {
      settingsCreated: e
    };
  }, "handler")
}), T = g({
  args: {},
  returns: t.object({
    message: t.string(),
    deletedCounts: t.object({
      notifications: t.number(),
      notificationSettings: t.number(),
      roleplayParticipants: t.number(),
      roleplays: t.number(),
      moduleContents: t.number(),
      trainingModules: t.number(),
      trainings: t.number(),
      betterAuthUsers: t.number()
    })
  }),
  handler: /* @__PURE__ */ p(async (n, c) => {
    let e = {
      notifications: 0,
      notificationSettings: 0,
      roleplayParticipants: 0,
      roleplays: 0,
      moduleContents: 0,
      trainingModules: 0,
      trainings: 0,
      betterAuthUsers: 0
    }, o = await n.db.query("notifications").collect();
    for (let d of o)
      await n.db.delete(d._id), e.notifications++;
    let s = await n.db.query("notificationSettings").collect();
    for (let d of s)
      await n.db.delete(d._id), e.notificationSettings++;
    let a = await n.db.query("roleplayParticipants").collect();
    for (let d of a)
      await n.db.delete(d._id), e.roleplayParticipants++;
    let i = await n.db.query("roleplays").collect();
    for (let d of i)
      await n.db.delete(d._id), e.roleplays++;
    e.moduleContents = 0;
    let u = await n.db.query("trainingModules").collect();
    for (let d of u)
      await n.db.delete(d._id), e.trainingModules++;
    let r = await n.db.query("trainings").collect();
    for (let d of r)
      await n.db.delete(d._id), e.trainings++;
    return console.log(
      "Better Auth users table has been migrated to unified users table - skipping deletion"
    ), e.betterAuthUsers = 0, {
      message: "\u5168\u30C7\u30FC\u30BF\u306E\u30AF\u30EA\u30FC\u30F3\u30A2\u30C3\u30D7\u304C\u5B8C\u4E86\u3057\u307E\u3057\u305F",
      deletedCounts: e
    };
  }, "handler")
}), U = y({
  args: {},
  returns: t.object({
    success: t.boolean(),
    message: t.string(),
    results: t.object({
      usersCreated: t.number(),
      trainingsCreated: t.number(),
      modulesCreated: t.number(),
      contentsCreated: t.number(),
      roleplaysCreated: t.number(),
      participantsCreated: t.number(),
      settingsCreated: t.number()
    }),
    errors: t.optional(t.array(t.string())),
    warnings: t.optional(t.array(t.string()))
  }),
  handler: /* @__PURE__ */ p(async (n, c) => {
    let e = [], o = [], s = {
      usersCreated: 0,
      trainingsCreated: 0,
      modulesCreated: 0,
      contentsCreated: 0,
      roleplaysCreated: 0,
      participantsCreated: 0,
      settingsCreated: 0
    };
    try {
      console.log("\u{1F331} Convex \u30B7\u30FC\u30EA\u30F3\u30B0\u30D7\u30ED\u30BB\u30B9\u958B\u59CB"), console.log("\u{1F4CA} Step 1: \u30E6\u30FC\u30B6\u30FC\u30C7\u30FC\u30BF\u4F5C\u6210\u4E2D...");
      let a = await n.runMutation(_.seed.seedBetterAuthUsers, {});
      if (s.usersCreated = a.created, a.userIds.length === 0)
        throw new Error("\u30E6\u30FC\u30B6\u30FC\u304C\u4F5C\u6210\u3055\u308C\u307E\u305B\u3093\u3067\u3057\u305F\u3002\u30C7\u30FC\u30BF\u30D9\u30FC\u30B9\u63A5\u7D9A\u3092\u78BA\u8A8D\u3057\u3066\u304F\u3060\u3055\u3044\u3002");
      console.log("\u{1F4DA} Step 2: \u7814\u4FEE\u30C7\u30FC\u30BF\u4F5C\u6210\u4E2D...");
      try {
        let r = await n.runMutation(_.seed.seedTrainings, {
          userIds: a.userIds
        });
        s.trainingsCreated = r.trainingsCreated, s.modulesCreated = r.modulesCreated, s.contentsCreated = r.contentsCreated;
      } catch (r) {
        e.push(
          `\u7814\u4FEE\u30C7\u30FC\u30BF\u4F5C\u6210\u30A8\u30E9\u30FC: ${r instanceof Error ? r.message : "\u4E0D\u660E\u306A\u30A8\u30E9\u30FC"}`
        ), o.push("\u7814\u4FEE\u30C7\u30FC\u30BF\u306E\u4F5C\u6210\u3092\u30B9\u30AD\u30C3\u30D7\u3057\u307E\u3057\u305F");
      }
      console.log("\u{1F3AD} Step 3: \u30ED\u30FC\u30EB\u30D7\u30EC\u30A4\u30C7\u30FC\u30BF\u4F5C\u6210\u4E2D...");
      try {
        let r = await n.runMutation(_.seed.seedRoleplays, {
          userIds: a.userIds
        });
        s.roleplaysCreated = r.roleplaysCreated, s.participantsCreated = r.participantsCreated;
      } catch (r) {
        e.push(
          `\u30ED\u30FC\u30EB\u30D7\u30EC\u30A4\u30C7\u30FC\u30BF\u4F5C\u6210\u30A8\u30E9\u30FC: ${r instanceof Error ? r.message : "\u4E0D\u660E\u306A\u30A8\u30E9\u30FC"}`
        ), o.push("\u30ED\u30FC\u30EB\u30D7\u30EC\u30A4\u30C7\u30FC\u30BF\u306E\u4F5C\u6210\u3092\u30B9\u30AD\u30C3\u30D7\u3057\u307E\u3057\u305F");
      }
      console.log("\u{1F514} Step 4: \u901A\u77E5\u8A2D\u5B9A\u4F5C\u6210\u4E2D...");
      try {
        let r = await n.runMutation(_.seed.seedNotificationSettings, {
          userIds: a.userIds
        });
        s.settingsCreated = r.settingsCreated;
      } catch (r) {
        e.push(
          `\u901A\u77E5\u8A2D\u5B9A\u4F5C\u6210\u30A8\u30E9\u30FC: ${r instanceof Error ? r.message : "\u4E0D\u660E\u306A\u30A8\u30E9\u30FC"}`
        ), o.push("\u901A\u77E5\u8A2D\u5B9A\u306E\u4F5C\u6210\u3092\u30B9\u30AD\u30C3\u30D7\u3057\u307E\u3057\u305F");
      }
      let i = e.length > 0, u = o.length > 0;
      return console.log(`\u2705 \u30B7\u30FC\u30EA\u30F3\u30B0\u5B8C\u4E86 - \u30A8\u30E9\u30FC: ${e.length}, \u8B66\u544A: ${o.length}`), {
        success: !i,
        message: i ? `\u90E8\u5206\u7684\u306B\u5B8C\u4E86\u3057\u307E\u3057\u305F\uFF08${e.length}\u4EF6\u306E\u30A8\u30E9\u30FC, ${o.length}\u4EF6\u306E\u8B66\u544A\uFF09` : u ? `\u6B63\u5E38\u306B\u5B8C\u4E86\u3057\u307E\u3057\u305F\uFF08${o.length}\u4EF6\u306E\u8B66\u544A\u3042\u308A\uFF09` : "\u5168\u3066\u306E\u30B5\u30F3\u30D7\u30EB\u30C7\u30FC\u30BF\u306E\u4F5C\u6210\u304C\u5B8C\u4E86\u3057\u307E\u3057\u305F",
        results: s,
        ...i && { errors: e },
        ...u && { warnings: o }
      };
    } catch (a) {
      console.error("\u30B7\u30FC\u30EA\u30F3\u30B0\u4E2D\u306B\u81F4\u547D\u7684\u306A\u30A8\u30E9\u30FC\u304C\u767A\u751F:", a);
      let i = a instanceof Error ? a.message : "\u4E0D\u660E\u306A\u30A8\u30E9\u30FC";
      return e.push(`\u81F4\u547D\u7684\u30A8\u30E9\u30FC: ${i}`), {
        success: !1,
        message: `\u30B7\u30FC\u30EA\u30F3\u30B0\u4E2D\u306B\u81F4\u547D\u7684\u306A\u30A8\u30E9\u30FC\u304C\u767A\u751F\u3057\u307E\u3057\u305F: ${i}`,
        results: s,
        errors: e,
        ...o.length > 0 && { warnings: o }
      };
    }
  }, "handler")
}), P = y({
  args: {},
  returns: t.object({
    success: t.boolean(),
    message: t.string(),
    deletedCounts: t.object({
      notifications: t.number(),
      notificationSettings: t.number(),
      roleplayParticipants: t.number(),
      roleplays: t.number(),
      moduleContents: t.number(),
      trainingModules: t.number(),
      trainings: t.number(),
      betterAuthUsers: t.number()
    })
  }),
  handler: /* @__PURE__ */ p(async (n, c) => {
    try {
      let e = await n.runMutation(_.seed.cleanupAllData, {});
      return {
        success: !0,
        message: e.message,
        deletedCounts: e.deletedCounts
      };
    } catch (e) {
      return console.error("\u30AF\u30EA\u30FC\u30F3\u30A2\u30C3\u30D7\u4E2D\u306B\u30A8\u30E9\u30FC\u304C\u767A\u751F:", e), {
        success: !1,
        message: `\u30AF\u30EA\u30FC\u30F3\u30A2\u30C3\u30D7\u4E2D\u306B\u30A8\u30E9\u30FC\u304C\u767A\u751F\u3057\u307E\u3057\u305F: ${e instanceof Error ? e.message : "\u4E0D\u660E\u306A\u30A8\u30E9\u30FC"}`,
        deletedCounts: {
          notifications: 0,
          notificationSettings: 0,
          roleplayParticipants: 0,
          roleplays: 0,
          moduleContents: 0,
          trainingModules: 0,
          trainings: 0,
          betterAuthUsers: 0
        }
      };
    }
  }, "handler")
});
export {
  P as cleanupAll,
  T as cleanupAllData,
  U as seedAll,
  A as seedBetterAuthUsers,
  E as seedNotificationSettings,
  D as seedRoleplays,
  $ as seedTrainings
};
//# sourceMappingURL=seed.js.map
