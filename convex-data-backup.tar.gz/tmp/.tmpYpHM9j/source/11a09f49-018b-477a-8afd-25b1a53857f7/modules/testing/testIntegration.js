import {
  a as ai
} from "../_deps/LQPOT665.js";
import {
  b as fe,
  e as Ws
} from "../_deps/IVQGLTSC.js";
import {
  a as ti,
  b as ni,
  d as ri,
  f as dn,
  h as ii,
  i as rt,
  n as C,
  o as oi,
  p as si
} from "../_deps/6XQQNYIR.js";
import {
  c as ae,
  d as U,
  j as r,
  n as ei
} from "../_deps/3TDUHHJO.js";
import {
  a as c,
  c as Ce,
  e as Zr
} from "../_deps/RUVYHBJQ.js";

// node_modules/strip-literal/node_modules/js-tokens/index.js
var fs = Ce((wd, us) => {
  var as, Jt, Wt, Vt, Xt, Kt, He, Ur, Ze, Gt, cs, Ht, Qe, Qt, Zt, en, Se, ls, tn, nn, gl;
  Qt = /\/(?![*\/])(?:\[(?:[^\]\\\n\r\u2028\u2029]+|\\.)*\]?|[^\/[\\\n\r\u2028\u2029]+|\\.)*(\/[$_\u200C\u200D\p{ID_Continue}]*|\\)?/yu;
  Qe = /--|\+\+|=>|\.{3}|\??\.(?!\d)|(?:&&|\|\||\?\?|[+\-%&|^]|\*{1,2}|<{1,2}|>{1,3}|!=?|={1,2}|\/(?![\/*]))=?|[?~,:;[\](){}]/y;
  Jt = /(\x23?)(?=[$_\p{ID_Start}\\])(?:[$_\u200C\u200D\p{ID_Continue}]+|\\u[\da-fA-F]{4}|\\u\{[\da-fA-F]+\})+/yu;
  en = /(['"])(?:[^'"\\\n\r]+|(?!\1)['"]|\\(?:\r\n|[^]))*(\1)?/y;
  Ht = /(?:0[xX][\da-fA-F](?:_?[\da-fA-F])*|0[oO][0-7](?:_?[0-7])*|0[bB][01](?:_?[01])*)n?|0n|[1-9](?:_?\d)*n|(?:(?:0(?!\d)|0\d*[89]\d*|[1-9](?:_?\d)*)(?:\.(?:\d(?:_?\d)*)?)?|\.\d(?:_?\d)*)(?:[eE][+-]?\d(?:_?\d)*)?|0[0-7]+/y;
  Se = /[`}](?:[^`\\$]+|\\[^]|\$(?!\{))*(`|\$\{)?/y;
  nn = /[\t\v\f\ufeff\p{Zs}]+/yu;
  Ze = /\r?\n|[\r\u2028\u2029]/y;
  Gt = /\/\*(?:[^*]+|\*(?!\/))*(\*\/)?/y;
  Zt = /\/\/.*/y;
  as = /^#!.*/;
  Vt = /[<>.:={}]|\/(?![\/*])/y;
  Wt = /[$_\p{ID_Start}][$_\u200C\u200D\p{ID_Continue}-]*/yu;
  Xt = /(['"])(?:[^'"]+|(?!\1)['"])*(\1)?/y;
  Kt = /[^<>{}]+/y;
  tn = /^(?:[\/+-]|\.{3}|\?(?:InterpolationIn(?:JSX|Template)|NoLineTerminatorHere|NonExpressionParenEnd|UnaryIncDec))?$|[{}([,;<>=*%&|^!~?:]$/;
  ls = /^(?:=>|[;\]){}]|else|\?(?:NoLineTerminatorHere|NonExpressionParenEnd))?$/;
  He = /^(?:await|case|default|delete|do|else|instanceof|new|return|throw|typeof|void|yield)$/;
  Ur = /^(?:return|throw|yield)$/;
  cs = RegExp(Ze.source);
  us.exports = gl = /* @__PURE__ */ c(function* (e, { jsx: t = !1 } = {}) {
    var n, i, o, s, a, l, u, p, h, g, w, _, T, b;
    for ({ length: l } = e, s = 0, a = "", b = [
      { tag: "JS" }
    ], n = [], w = 0, _ = !1, (u = as.exec(e)) && (yield {
      type: "HashbangComment",
      value: u[0]
    }, s = u[0].length); s < l; ) {
      switch (p = b[b.length - 1], p.tag) {
        case "JS":
        case "JSNonExpressionParen":
        case "InterpolationInTemplate":
        case "InterpolationInJSX":
          if (e[s] === "/" && (tn.test(a) || He.test(a)) && (Qt.lastIndex = s, u = Qt.exec(e))) {
            s = Qt.lastIndex, a = u[0], _ = !0, yield {
              type: "RegularExpressionLiteral",
              value: u[0],
              closed: u[1] !== void 0 && u[1] !== "\\"
            };
            continue;
          }
          if (Qe.lastIndex = s, u = Qe.exec(e)) {
            switch (T = u[0], h = Qe.lastIndex, g = T, T) {
              case "(":
                a === "?NonExpressionParenKeyword" && b.push({
                  tag: "JSNonExpressionParen",
                  nesting: w
                }), w++, _ = !1;
                break;
              case ")":
                w--, _ = !0, p.tag === "JSNonExpressionParen" && w === p.nesting && (b.pop(), g = "?NonExpressionParenEnd", _ = !1);
                break;
              case "{":
                Qe.lastIndex = 0, o = !ls.test(a) && (tn.test(a) || He.test(a)), n.push(o), _ = !1;
                break;
              case "}":
                switch (p.tag) {
                  case "InterpolationInTemplate":
                    if (n.length === p.nesting) {
                      Se.lastIndex = s, u = Se.exec(e), s = Se.lastIndex, a = u[0], u[1] === "${" ? (a = "?InterpolationInTemplate", _ = !1, yield {
                        type: "TemplateMiddle",
                        value: u[0]
                      }) : (b.pop(), _ = !0, yield {
                        type: "TemplateTail",
                        value: u[0],
                        closed: u[1] === "`"
                      });
                      continue;
                    }
                    break;
                  case "InterpolationInJSX":
                    if (n.length === p.nesting) {
                      b.pop(), s += 1, a = "}", yield {
                        type: "JSXPunctuator",
                        value: "}"
                      };
                      continue;
                    }
                }
                _ = n.pop(), g = _ ? "?ExpressionBraceEnd" : "}";
                break;
              case "]":
                _ = !0;
                break;
              case "++":
              case "--":
                g = _ ? "?PostfixIncDec" : "?UnaryIncDec";
                break;
              case "<":
                if (t && (tn.test(a) || He.test(a))) {
                  b.push({ tag: "JSXTag" }), s += 1, a = "<", yield {
                    type: "JSXPunctuator",
                    value: T
                  };
                  continue;
                }
                _ = !1;
                break;
              default:
                _ = !1;
            }
            s = h, a = g, yield {
              type: "Punctuator",
              value: T
            };
            continue;
          }
          if (Jt.lastIndex = s, u = Jt.exec(e)) {
            switch (s = Jt.lastIndex, g = u[0], u[0]) {
              case "for":
              case "if":
              case "while":
              case "with":
                a !== "." && a !== "?." && (g = "?NonExpressionParenKeyword");
            }
            a = g, _ = !He.test(u[0]), yield {
              type: u[1] === "#" ? "PrivateIdentifier" : "IdentifierName",
              value: u[0]
            };
            continue;
          }
          if (en.lastIndex = s, u = en.exec(e)) {
            s = en.lastIndex, a = u[0], _ = !0, yield {
              type: "StringLiteral",
              value: u[0],
              closed: u[2] !== void 0
            };
            continue;
          }
          if (Ht.lastIndex = s, u = Ht.exec(e)) {
            s = Ht.lastIndex, a = u[0], _ = !0, yield {
              type: "NumericLiteral",
              value: u[0]
            };
            continue;
          }
          if (Se.lastIndex = s, u = Se.exec(e)) {
            s = Se.lastIndex, a = u[0], u[1] === "${" ? (a = "?InterpolationInTemplate", b.push({
              tag: "InterpolationInTemplate",
              nesting: n.length
            }), _ = !1, yield {
              type: "TemplateHead",
              value: u[0]
            }) : (_ = !0, yield {
              type: "NoSubstitutionTemplate",
              value: u[0],
              closed: u[1] === "`"
            });
            continue;
          }
          break;
        case "JSXTag":
        case "JSXTagEnd":
          if (Vt.lastIndex = s, u = Vt.exec(e)) {
            switch (s = Vt.lastIndex, g = u[0], u[0]) {
              case "<":
                b.push({ tag: "JSXTag" });
                break;
              case ">":
                b.pop(), a === "/" || p.tag === "JSXTagEnd" ? (g = "?JSX", _ = !0) : b.push({ tag: "JSXChildren" });
                break;
              case "{":
                b.push({
                  tag: "InterpolationInJSX",
                  nesting: n.length
                }), g = "?InterpolationInJSX", _ = !1;
                break;
              case "/":
                a === "<" && (b.pop(), b[b.length - 1].tag === "JSXChildren" && b.pop(), b.push({ tag: "JSXTagEnd" }));
            }
            a = g, yield {
              type: "JSXPunctuator",
              value: u[0]
            };
            continue;
          }
          if (Wt.lastIndex = s, u = Wt.exec(e)) {
            s = Wt.lastIndex, a = u[0], yield {
              type: "JSXIdentifier",
              value: u[0]
            };
            continue;
          }
          if (Xt.lastIndex = s, u = Xt.exec(e)) {
            s = Xt.lastIndex, a = u[0], yield {
              type: "JSXString",
              value: u[0],
              closed: u[2] !== void 0
            };
            continue;
          }
          break;
        case "JSXChildren":
          if (Kt.lastIndex = s, u = Kt.exec(e)) {
            s = Kt.lastIndex, a = u[0], yield {
              type: "JSXText",
              value: u[0]
            };
            continue;
          }
          switch (e[s]) {
            case "<":
              b.push({ tag: "JSXTag" }), s++, a = "<", yield {
                type: "JSXPunctuator",
                value: "<"
              };
              continue;
            case "{":
              b.push({
                tag: "InterpolationInJSX",
                nesting: n.length
              }), s++, a = "?InterpolationInJSX", _ = !1, yield {
                type: "JSXPunctuator",
                value: "{"
              };
              continue;
          }
      }
      if (nn.lastIndex = s, u = nn.exec(e)) {
        s = nn.lastIndex, yield {
          type: "WhiteSpace",
          value: u[0]
        };
        continue;
      }
      if (Ze.lastIndex = s, u = Ze.exec(e)) {
        s = Ze.lastIndex, _ = !1, Ur.test(a) && (a = "?NoLineTerminatorHere"), yield {
          type: "LineTerminatorSequence",
          value: u[0]
        };
        continue;
      }
      if (Gt.lastIndex = s, u = Gt.exec(e)) {
        s = Gt.lastIndex, cs.test(u[0]) && (_ = !1, Ur.test(a) && (a = "?NoLineTerminatorHere")), yield {
          type: "MultiLineComment",
          value: u[0],
          closed: u[1] !== void 0
        };
        continue;
      }
      if (Zt.lastIndex = s, u = Zt.exec(e)) {
        s = Zt.lastIndex, _ = !1, yield {
          type: "SingleLineComment",
          value: u[0]
        };
        continue;
      }
      i = String.fromCodePoint(e.codePointAt(s)), s += i.length, a = i, _ = !1, yield {
        type: p.tag.startsWith("JSX") ? "JSXInvalid" : "Invalid",
        value: i
      };
    }
  }, "jsTokens");
});

// node_modules/expect-type/dist/branding.js
var Fs = Ce((ks) => {
  "use strict";
  Object.defineProperty(ks, "__esModule", { value: !0 });
});

// node_modules/expect-type/dist/messages.js
var Ls = Ce((Ds) => {
  "use strict";
  Object.defineProperty(Ds, "__esModule", { value: !0 });
  var sp = Symbol("inverted"), ap = Symbol("expectNull"), cp = Symbol("expectUndefined"), lp = Symbol("expectNumber"), up = Symbol("expectString"), fp = Symbol("expectBoolean"), dp = Symbol("expectVoid"), pp = Symbol("expectFunction"), hp = Symbol("expectObject"), mp = Symbol("expectArray"), gp = Symbol("expectSymbol"), yp = Symbol("expectAny"), bp = Symbol("expectUnknown"), _p = Symbol("expectNever"), wp = Symbol("expectNullable"), Ep = Symbol("expectBigInt");
});

// node_modules/expect-type/dist/overloads.js
var zs = Ce((qs) => {
  "use strict";
  Object.defineProperty(qs, "__esModule", { value: !0 });
});

// node_modules/expect-type/dist/utils.js
var Us = Ce((Bs) => {
  "use strict";
  Object.defineProperty(Bs, "__esModule", { value: !0 });
  var xp = Symbol("secret"), Sp = Symbol("mismatch"), Ip = Symbol("avalue");
});

// node_modules/expect-type/dist/index.js
var Ys = Ce((L) => {
  "use strict";
  var Gl = L && L.__createBinding || (Object.create ? function(e, t, n, i) {
    i === void 0 && (i = n);
    var o = Object.getOwnPropertyDescriptor(t, n);
    (!o || ("get" in o ? !t.__esModule : o.writable || o.configurable)) && (o = { enumerable: !0, get: /* @__PURE__ */ c(function() {
      return t[n];
    }, "get") }), Object.defineProperty(e, i, o);
  } : function(e, t, n, i) {
    i === void 0 && (i = n), e[i] = t[n];
  }), un = L && L.__exportStar || function(e, t) {
    for (var n in e) n !== "default" && !Object.prototype.hasOwnProperty.call(t, n) && Gl(t, e, n);
  };
  Object.defineProperty(L, "__esModule", { value: !0 });
  L.expectTypeOf = void 0;
  un(Fs(), L);
  un(Ls(), L);
  un(zs(), L);
  un(Us(), L);
  var z = /* @__PURE__ */ c(() => !0, "fn"), Hl = /* @__PURE__ */ c((e) => {
    let t = [
      "parameters",
      "returns",
      "resolves",
      "not",
      "items",
      "constructorParameters",
      "thisParameter",
      "instance",
      "guards",
      "asserts",
      "branded"
    ], n = {
      /* eslint-disable @typescript-eslint/no-unsafe-assignment */
      toBeAny: z,
      toBeUnknown: z,
      toBeNever: z,
      toBeFunction: z,
      toBeObject: z,
      toBeArray: z,
      toBeString: z,
      toBeNumber: z,
      toBeBoolean: z,
      toBeVoid: z,
      toBeSymbol: z,
      toBeNull: z,
      toBeUndefined: z,
      toBeNullable: z,
      toBeBigInt: z,
      toMatchTypeOf: z,
      toEqualTypeOf: z,
      toBeConstructibleWith: z,
      toMatchObjectType: z,
      toExtend: z,
      map: L.expectTypeOf,
      toBeCallableWith: L.expectTypeOf,
      extract: L.expectTypeOf,
      exclude: L.expectTypeOf,
      pick: L.expectTypeOf,
      omit: L.expectTypeOf,
      toHaveProperty: L.expectTypeOf,
      parameter: L.expectTypeOf
    };
    return t.forEach((o) => Object.defineProperty(n, o, { get: /* @__PURE__ */ c(() => (0, L.expectTypeOf)({}), "get") })), n;
  }, "expectTypeOf");
  L.expectTypeOf = Hl;
});

// node_modules/convex-test/dist/index.js
si();
ei();

// node_modules/convex-test/dist/compare.js
function ne(e, t) {
  return ci(Le(e), Le(t));
}
c(ne, "compareValues");
function ci(e, t) {
  return e[0] === t[0] ? Vs(e[1], t[1]) : e[0] < t[0] ? -1 : 1;
}
c(ci, "compareAsTuples");
function Vs(e, t) {
  if (e == null)
    return 0;
  if (typeof e == "bigint" || typeof e == "number" || typeof e == "boolean" || typeof e == "string")
    return e < t ? -1 : e === t ? 0 : 1;
  if (!Array.isArray(e) || !Array.isArray(t))
    throw new Error(`Unexpected type ${e}`);
  for (let n = 0; n < e.length && n < t.length; n++) {
    let i = ci(e[n], t[n]);
    if (i !== 0)
      return i;
  }
  return e.length < t.length ? -1 : e.length > t.length ? 1 : 0;
}
c(Vs, "compareSameTypeValues");
function Le(e) {
  return e === void 0 ? [0, void 0] : e === null ? [1, null] : typeof e == "bigint" ? [2, e] : typeof e == "number" ? isNaN(e) ? [3.5, 0] : [3, e] : typeof e == "boolean" ? [4, e] : typeof e == "string" ? [5, e] : e instanceof ArrayBuffer ? [6, Array.from(new Uint8Array(e)).map(Le)] : Array.isArray(e) ? [7, e.map(Le)] : [8, Object.keys(e).sort().map((i) => [i, e[i]]).map(Le)];
}
c(Le, "makeComparable");

// node_modules/convex-test/dist/index.js
var mn = "", at = class {
  static {
    c(this, "DatabaseFake");
  }
  _componentPath;
  _documents = {};
  _storage = {};
  _nextQueryId = 1;
  _nextDocId = 1e4;
  _lastCreationTime = 0;
  _queryResults = {};
  // TODO: Make this more robust and cleaner
  jobListener = /* @__PURE__ */ c(() => {
  }, "jobListener");
  // Pending writes for each level of transaction nesting.
  // Whenever a child mutation begins, a new level is created for all
  // components.
  // - When a mutation performs updates, they are staged in the last
  //   level of writes for the mutation's component.
  // - When a child mutation commits, the writes are merged up one level.
  // - When the top-level mutation commits, the writes are applied to the
  //   database.
  // - When a mutation is rolled back, last level of writes is discarded.
  _writes = [];
  _schema;
  constructor(t, n) {
    this._schema = t === null ? null : {
      schemaValidation: t.schemaValidation,
      tables: new Map(Object.entries(t.tables).map(([i, o]) => [
        i,
        o.export()
      ]))
    }, this._componentPath = n, this.validateSchema();
  }
  // Called by TransactionManager.begin.
  startTransaction() {
    this._writes.push({});
  }
  get(t) {
    if (typeof t != "string")
      throw new Error(`Invalid argument \`id\` for \`db.get\`, expected string but got '${typeof t}': ${t}`);
    for (let n = this._writes.length - 1; n >= 0; n--) {
      let i = this._writes[n][t];
      if (i !== void 0)
        return i;
    }
    return this._documents[t] ?? null;
  }
  // Note that this is not the format the real backend
  // uses for IDs.
  _generateId(t) {
    let n = this._nextDocId.toString() + ";" + t;
    return this._nextDocId += 1, n;
  }
  storeFile(t, n) {
    this._storage[t] = n;
  }
  getFile(t) {
    return this.get(t) === null ? null : this._storage[t];
  }
  _addWrite(t, n) {
    if (this._writes.length === 0)
      throw new Error(`Write outside of transaction ${t}`);
    this._writes[this._writes.length - 1][t] = n;
  }
  insert(t, n) {
    this._validate(t, n);
    let i = this._generateId(t), o = Date.now(), s = o <= this._lastCreationTime ? this._lastCreationTime + 1e-3 : o;
    return this._lastCreationTime = s, this._addWrite(i, { ...n, _id: i, _creationTime: s }), i;
  }
  patch(t, n) {
    let i = this.get(t);
    if (i === null)
      throw new Error(`Patch on non-existent document with ID "${t}"`);
    let { _id: o, _creationTime: s, ...a } = i;
    if (n._id !== void 0 && n._id !== o)
      throw new Error(`Provided \`_id\` field value "${n._id}" does not match the document ID "${o}"`);
    if (n._creationTime !== void 0 && n._creationTime !== s)
      throw new Error(`Provided \`_creationTime\` field value ${n._creationTime} does not match the document's creation time ${s}`);
    delete n._id, delete n._creationTime;
    let l = {};
    for (let [p, h] of Object.entries(n))
      l[p] = ct(h);
    let u = { ...a, ...l };
    this._validate(ot(o), u), this._addWrite(t, { _id: o, _creationTime: s, ...u });
  }
  replace(t, n) {
    let i = this.get(t);
    if (i === null)
      throw new Error(`Replace on non-existent document with ID "${t}"`);
    if (n._id !== void 0 && n._id !== i._id)
      throw new Error(`Provided \`_id\` field value "${n._id}" does not match the document ID "${i._id}"`);
    if (n._creationTime !== void 0 && n._creationTime !== i._creationTime)
      throw new Error(`Provided \`_creationTime\` field value ${n._creationTime} does not match the document's creation time ${i._creationTime}`);
    delete n._id, delete n._creationTime;
    let o = {};
    for (let [s, a] of Object.entries(n))
      o[s] = ct(a);
    this._validate(ot(i._id), o), this._addWrite(t, {
      ...o,
      _id: i._id,
      _creationTime: i._creationTime
    });
  }
  delete(t) {
    if (this.get(t) === null)
      throw new Error("Delete on non-existent doc");
    this._addWrite(t, null);
  }
  commit() {
    let t = this._writes.pop();
    if (!t)
      throw new Error("Transaction already committed or rolled back");
    for (let [n, i] of Object.entries(t)) {
      let o = n;
      this._writes.length === 0 ? i === null ? delete this._documents[o] : this._documents[o] = i : this._addWrite(o, i);
    }
  }
  rollbackWrites() {
    if (this._writes.length === 0)
      throw new Error("Transaction already committed or rolled back");
    this._writes.pop();
  }
  _validate(t, n) {
    if (this._schema === null || !this._schema.schemaValidation)
      return;
    let i = this._schema.tables.get(t)?.documentType;
    i !== void 0 && be(i, n);
  }
  startQuery(t) {
    let n = this._nextQueryId, i = this._evaluateQuery(t);
    return this._queryResults[n] = i, this._nextQueryId += 1, n;
  }
  queryNext(t) {
    let n = this._queryResults[t];
    if (n === void 0)
      throw new Error("Bad queryId");
    return n.length === 0 ? { value: null, done: !0 } : { value: n.shift(), done: !1 };
  }
  paginate({ query: t, cursor: n, pageSize: i }) {
    let o = this.startQuery(t), s = [], a = n === null, l = !1, u = null;
    for (; ; ) {
      let { value: p, done: h } = this.queryNext(o);
      if (h) {
        l = !0, u = "_end_cursor";
        break;
      }
      if (a && (s.push(p), s.length >= i)) {
        u = p._id;
        break;
      }
      p._id === n && (a = !0);
    }
    return {
      page: s,
      isDone: l,
      continueCursor: u
    };
  }
  _iterateDocs(t, n) {
    let i = /* @__PURE__ */ c((s) => ot(s) === t, "isInTable"), o = new Set(Object.keys(this._documents).filter(i));
    for (let s = 0; s < this._writes.length; s++)
      for (let a of Object.keys(this._writes[s]).filter(i))
        o.add(a);
    for (let s of o) {
      let a = this.get(s);
      a !== null && n(a);
    }
  }
  _evaluateQuery(t) {
    let n = t.source, i = [], o, s;
    switch (n.type) {
      case "FullTableScan": {
        let u = n.tableName;
        this._iterateDocs(u, (p) => {
          i.push(p);
        }), s = n.order ?? "asc", o = ["_creationTime"];
        break;
      }
      case "IndexRange": {
        let [u, p] = n.indexName.split(".");
        s = n.order ?? "asc";
        let h;
        if (p === "by_creation_time")
          h = ["_creationTime", "_id"];
        else if (p === "by_id")
          h = ["_id"];
        else {
          let w = this._schema?.tables.get(u)?.indexes?.find(({ indexDescriptor: _ }) => _ === p);
          if (w === void 0)
            throw new Error(`Cannot use index "${p}" for table "${u}" because it is not declared in the schema.`);
          h = w.fields.concat(["_creationTime", "_id"]);
        }
        o = h, Hs(n, h), this._iterateDocs(u, (g) => {
          n.range.every((w) => Xs(g, w)) && i.push(g);
        });
        break;
      }
      case "Search": {
        let [u] = n.indexName.split(".");
        this._iterateDocs(u, (p) => {
          n.filters.every((h) => Ks(p, h)) && i.push(p);
        }), o = [], s = "asc";
        break;
      }
    }
    let a = t.operators.filter((u) => "filter" in u).map((u) => u.filter), l = t.operators.filter((u) => "limit" in u)[0] ?? null;
    return i = i.filter((u) => a.every((p) => k(u, p))), i.sort((u, p) => {
      let h = s === "asc" ? 1 : -1, g = 0;
      for (let w of o)
        if (g = ne(ze(w, u), ze(w, p)), g !== 0)
          return g * h;
      return g * h;
    }), l !== null ? i.slice(0, l.limit) : i;
  }
  jobFinished(t) {
    this.jobListener(t);
  }
  vectorSearch(t, n, i, o) {
    let s = [], [a, l] = t.split(".");
    this._iterateDocs(a, (w) => {
      i.every((_) => k(w, _)) && s.push(w);
    });
    let p = this._schema?.tables.get(a)?.vectorIndexes?.find(({ indexDescriptor: w }) => w === l);
    if (p === void 0)
      throw new Error(`Cannot use vector index "${l}" for table "${a}" because it is not declared in the schema.`);
    let { vectorField: h } = p, g = s.map((w) => {
      let _ = Gs(n, w[h]);
      return { _id: w._id, _score: _ };
    });
    return g.sort((w, _) => _._score - w._score), g.slice(0, o);
  }
  validateSchema() {
    this._schema?.tables.forEach((t, n) => {
      if (!gn(n))
        throw new Error(`Table names must be valid identifiers, got "${n}"`);
      di(t.documentType), t.indexes.forEach(({ indexDescriptor: i }) => {
        if (!gn(i))
          throw new Error(`Index names must be valid identifiers, got "${i}"`);
      });
    });
  }
  get componentPath() {
    return this._componentPath;
  }
};
function ot(e) {
  return e.split(";").length !== 2 ? null : e.split(";")[1];
}
c(ot, "tableNameFromId");
function bn(e) {
  let t = typeof e == "object", n = Object.getPrototypeOf(e), i = n === null || n === Object.prototype || // Objects generated from other contexts (e.g. across Node.js `vm` modules) will not satisfy the previous
  // conditions but are still simple objects.
  n?.constructor?.name === "Object";
  return t && i;
}
c(bn, "isSimpleObject");
function ze(e, t) {
  let n = e.split("."), i = t;
  for (let o of n)
    i = i != null && bn(i) ? i[o] : void 0;
  return i;
}
c(ze, "evaluateFieldPath");
function k(e, t) {
  if (t.$eq !== void 0)
    return ne(k(e, t.$eq[0]), k(e, t.$eq[1])) === 0;
  if (t.$neq !== void 0)
    return ne(k(e, t.$neq[0]), k(e, t.$neq[1])) !== 0;
  if (t.$and !== void 0)
    return t.$and.every((n) => k(e, n));
  if (t.$or !== void 0)
    return t.$or.some((n) => k(e, n));
  if (t.$not !== void 0)
    return !k(e, t.$not);
  if (t.$gt !== void 0)
    return k(e, t.$gt[0]) > k(e, t.$gt[1]);
  if (t.$gte !== void 0)
    return k(e, t.$gte[0]) >= k(e, t.$gte[1]);
  if (t.$lt !== void 0)
    return k(e, t.$lt[0]) < k(e, t.$lt[1]);
  if (t.$lte !== void 0)
    return k(e, t.$lte[0]) <= k(e, t.$lte[1]);
  if (t.$add !== void 0)
    return k(e, t.$add[0]) + k(e, t.$add[1]);
  if (t.$sub !== void 0)
    return k(e, t.$sub[0]) - k(e, t.$sub[1]);
  if (t.$mul !== void 0)
    return k(e, t.$mul[0]) * k(e, t.$mul[1]);
  if (t.$div !== void 0)
    return k(e, t.$div[0]) / k(e, t.$div[1]);
  if (t.$mod !== void 0)
    return k(e, t.$mod[0]) % k(e, t.$mod[1]);
  if (t.$field !== void 0)
    return ze(t.$field, e);
  if (t.$literal !== void 0)
    return ct(t.$literal);
  throw new Error(`not implemented: ${JSON.stringify(t)}`);
}
c(k, "evaluateFilter");
function Xs(e, t) {
  let n = ze(t.fieldPath, e), i = ct(t.value);
  switch (t.type) {
    case "Eq":
      return ne(n, i) === 0;
    case "Gt":
      return ne(n, i) > 0;
    case "Gte":
      return ne(n, i) >= 0;
    case "Lt":
      return ne(n, i) < 0;
    case "Lte":
      return ne(n, i) <= 0;
  }
}
c(Xs, "evaluateRangeFilter");
function ct(e) {
  if (!(typeof e == "object" && e !== null && "$undefined" in e))
    return ae(e);
}
c(ct, "evaluateValue");
function Ks(e, t) {
  let n = ze(t.fieldPath, e);
  switch (t.type) {
    case "Eq":
      return ne(n, t.value) === 0;
    case "Search":
      return n.split(/\s/).some((i) => i.startsWith(t.value));
  }
}
c(Ks, "evaluateSearchFilter");
function Gs(e, t) {
  let n = 0, i = 0, o = 0;
  for (let s = 0; s < e.length; s++)
    n += e[s] * t[s], i += e[s] * e[s], o += t[s] * t[s];
  return i === 0 || o === 0 ? 0 : n / (Math.sqrt(i) * Math.sqrt(o));
}
c(Gs, "cosineSimilarity");
function Hs(e, t) {
  let n = 0, i = "eq";
  for (let [o, s] of e.range.entries()) {
    if (i === "done")
      throw new Error(`Incorrect operator used in \`withIndex\`, cannot chain more operators after both \`.gt\` and \`.lt\` were already used, got \`${Qs(s)}\`.`);
    let a = s.type == "Gt" || s.type == "Gte" ? "gt" : s.type == "Lt" || s.type == "Lte" ? "lt" : "eq";
    switch (`${i}|${a}`) {
      // Allow to operate on the current indexed field
      case "eq|eq":
      case "eq|gt":
      case "eq|lt":
        if (s.fieldPath === t[n]) {
          n += 1, i = a;
          continue;
        }
        throw new Error(`Incorrect field used in \`withIndex\`, expected "${t[n]}", got "${s.fieldPath}"`);
      // Allow to operate on the previous field (gt and lt must operate on same field)
      case "lt|gt":
      case "gt|lt":
        if (n > 0 && s.fieldPath === t[n - 1]) {
          i = "done";
          continue;
        }
        throw new Error(`Incorrect field used in \`withIndex\`, \`.gt\` and \`.lt\` must operate on the same field, expected "${t[n - 1]}", got "${s.fieldPath}"`);
      default:
        throw new Error(`Incorrect operator used in \`withIndex\`, cannot chain \`.${s.type.toLowerCase()}()\` after \`.${e.range[o - 1].type.toLowerCase()}()\``);
    }
  }
}
c(Hs, "validateIndexRangeExpression");
function Qs(e) {
  return `.${e.type.toLowerCase()}(${e.fieldPath}, ${JSON.stringify(e.value)})`;
}
c(Qs, "printIndexOperator");
function di(e) {
  e.type === "object" && Object.keys(e.value).forEach((t) => {
    if (!gn(t))
      throw new Error(`Field names must be valid identifiers, got "${t}"`);
  }), e.type === "union" && e.value.forEach(di);
}
c(di, "validateFieldNames");
function gn(e) {
  return /(^_(id|creationTime)$)|^[a-zA-Z][a-zA-Z0-9_]*$/.test(e);
}
c(gn, "isValidIdentifier");
function be(e, t) {
  switch (e.type) {
    case "null": {
      if (t !== null)
        throw new Error(`Validator error: Expected \`null\`, got \`${t}\``);
      return;
    }
    case "number": {
      if (typeof t != "number")
        throw new Error(`Validator error: Expected \`number\`, got \`${t}\``);
      return;
    }
    case "bigint": {
      if (typeof t != "bigint")
        throw new Error(`Validator error: Expected \`bigint\`, got \`${t}\``);
      return;
    }
    case "boolean": {
      if (typeof t != "boolean")
        throw new Error(`Validator error: Expected \`boolean\`, got \`${t}\``);
      return;
    }
    case "string": {
      if (typeof t != "string")
        throw new Error(`Validator error: Expected \`string\`, got \`${t}\``);
      return;
    }
    case "bytes": {
      if (!(t instanceof ArrayBuffer))
        throw new Error(`Validator error: Expected \`ArrayBuffer\`, got \`${t}\``);
      return;
    }
    case "any":
      return;
    case "literal": {
      if (t !== e.value)
        throw new Error(`Validator error: Expected \`${e.value}\`, got \`${t}\``);
      return;
    }
    case "id": {
      if (typeof t != "string")
        throw new Error(`Validator error: Expected \`string\`, got \`${t}\``);
      if (ot(t) !== e.tableName)
        throw new Error(`Validator error: Expected ID for table "${e.tableName}", got \`${t}\``);
      return;
    }
    case "array": {
      if (!Array.isArray(t))
        throw new Error(`Validator error: Expected \`Array\`, got \`${t}\``);
      for (let n of t)
        be(e.value, n);
      return;
    }
    case "union": {
      let n = !1;
      for (let i of e.value)
        try {
          be(i, t), n = !0;
          break;
        } catch {
        }
      if (!n)
        throw new Error(`Validator error: Expected one of ${e.value.map((i) => i.type).join(", ")}, got \`${JSON.stringify(U(t))}\``);
      return;
    }
    case "object": {
      if (typeof t != "object")
        throw new Error(`Validator error: Expected \`object\`, got \`${t}\``);
      if (!bn(t))
        throw new Error(`Validator error: Expected a plain old JavaScript \`object\`, got \`${t}\``);
      for (let [n, { fieldType: i, optional: o }] of Object.entries(e.value))
        if (t[n] === void 0) {
          if (!o)
            throw new Error(`Validator error: Missing required field \`${n}\` in object`);
        } else
          be(i, t[n]);
      for (let n of Object.keys(t))
        if (e.value[n] === void 0)
          throw new Error(`Validator error: Unexpected field \`${n}\` in object`);
      return;
    }
  }
}
c(be, "validateValidator");
function Zs() {
  return (e, t) => {
    let n = JSON.parse(t), i = ut();
    switch (e) {
      case "1.0/queryStream": {
        let { query: o } = n, s = i.startQuery(o);
        return JSON.stringify({ queryId: s });
      }
      case "1.0/queryCleanup":
        return JSON.stringify({});
      case "1.0/db/normalizeId": {
        let o = n.idString, s = o.endsWith(`;${n.table}`);
        return JSON.stringify({
          id: s ? o : null
        });
      }
      default:
        throw new Error(`\`convexTest\` does not support syscall: "${e}"`);
    }
  };
}
c(Zs, "syscallImpl");
var lt = class {
  static {
    c(this, "AuthFake");
  }
  _userIdentity;
  constructor(t = null) {
    this._userIdentity = t;
  }
  getUserIdentity() {
    return Promise.resolve(this._userIdentity);
  }
};
function ea() {
  return async (e, t) => {
    let n = JSON.parse(t), i = ut();
    switch (e) {
      case "1.0/get": {
        let o = i.get(n.id);
        return JSON.stringify(U(o));
      }
      case "1.0/queryStreamNext": {
        let { value: o, done: s } = i.queryNext(n.queryId);
        return JSON.stringify(U({ value: o, done: s }));
      }
      case "1.0/queryPage": {
        let { query: o, cursor: s, pageSize: a } = n, { page: l, isDone: u, continueCursor: p } = i.paginate({
          query: o,
          cursor: s,
          pageSize: a
        });
        return JSON.stringify(U({ page: l, isDone: u, continueCursor: p }));
      }
      case "1.0/insert": {
        let o = i.insert(n.table, ae(n.value));
        return JSON.stringify({ _id: o });
      }
      case "1.0/shallowMerge": {
        let { id: o, value: s } = n;
        return i.patch(o, s), JSON.stringify({});
      }
      case "1.0/replace": {
        let { id: o, value: s } = n;
        return i.replace(o, s), JSON.stringify({});
      }
      case "1.0/remove": {
        let { id: o } = n;
        return i.delete(o), JSON.stringify({});
      }
      case "1.0/actions/query": {
        let { name: o, args: s } = n;
        return JSON.stringify(U(await V().query(rt(o), s)));
      }
      case "1.0/actions/mutation": {
        let { name: o, args: s } = n;
        return JSON.stringify(U(await V().mutation(rt(o), s)));
      }
      case "1.0/actions/action": {
        let { name: o, args: s } = n;
        return JSON.stringify(U(await V().action(rt(o), s)));
      }
      case "1.0/runUdf": {
        let { udfType: o, name: s, reference: a, functionHandle: l, args: u } = n, p = ae(u), h = await st({
          name: s,
          reference: a,
          functionHandle: l
        });
        if (o === "query")
          return JSON.stringify(U(await V().queryFromPath(
            h,
            /* isNested */
            !0,
            p
          )));
        if (o === "mutation")
          return JSON.stringify(U(await V().mutationFromPath(
            h,
            /* isNested */
            !0,
            p
          )));
        throw new Error(`\`convexTest\` does not support udf type: "${o}"`);
      }
      case "1.0/createFunctionHandle": {
        let { name: o, reference: s, functionHandle: a } = n, l = await st({
          name: o,
          reference: s,
          functionHandle: a
        }), u = sa(l);
        return JSON.stringify(u);
      }
      case "1.0/actions/schedule":
        return await V().run(async () => await ui().asyncSyscall("1.0/schedule", t));
      case "1.0/schedule": {
        let { name: o, reference: s, functionHandle: a, args: l, ts: u } = n, p = await st({
          name: o,
          reference: s,
          functionHandle: a
        }), h = ae(l), g = i.insert("_scheduled_functions", {
          args: [h],
          name: p.udfPath,
          scheduledTime: u * 1e3,
          state: { kind: "pending" }
        }), w = _e();
        return setTimeout(async () => {
          if (!await V().runInComponent(w, async () => {
            let T = i.get(g);
            if (T.state.kind === "canceled")
              return !0;
            if (T.state.kind !== "pending")
              throw new Error(`\`convexTest\` invariant error: Unexpected scheduled function state when starting it: ${T.state.kind}`);
            return i.patch(g, { state: { kind: "inProgress" } }), !1;
          })) {
            try {
              await V().fun(p, h);
            } catch (T) {
              console.error(`Error when running scheduled function ${o}`, T), await V().runInComponent(w, async () => {
                i.patch(g, {
                  state: { kind: "failed" },
                  completedTime: Date.now()
                });
              }), i.jobFinished(g);
              return;
            }
            await V().runInComponent(w, async () => {
              let T = i.get(g);
              if (T.state.kind !== "inProgress")
                throw new Error(`\`convexTest\` invariant error: Unexpected scheduled function state after it finished running: ${T.state.kind}`);
              i.patch(g, { state: { kind: "success" } });
            }), i.jobFinished(g);
          }
        }, u * 1e3 - Date.now()), JSON.stringify(U(g));
      }
      case "1.0/actions/cancel_job":
        return await V().run(async () => {
          await ui().asyncSyscall("1.0/cancel_job", t);
        }), JSON.stringify({});
      case "1.0/actions/vectorSearch": {
        let { query: { indexName: o, limit: s, vector: a, expressions: l } } = n, u = i.vectorSearch(
          o,
          a,
          // Probably an unintentional implementation in Convex
          // where expressions is only a single expression
          l === null ? [] : [l],
          s
        );
        return JSON.stringify(U({ results: u }));
      }
      case "1.0/cancel_job": {
        let { id: o } = n;
        return i.patch(o, { state: { kind: "canceled" } }), JSON.stringify({});
      }
      case "1.0/storageDelete": {
        let { storageId: o } = n;
        return await pi(async (s) => {
          s.delete(o);
        }), JSON.stringify({});
      }
      case "1.0/storageGetUrl": {
        let { storageId: o } = n, s = i.get(o);
        if (s === null)
          return JSON.stringify(null);
        let { sha256: a } = s, l = "https://some-deployment.convex.cloud/api/storage/" + a;
        return JSON.stringify(U(l));
      }
      case "1.0/storageGenerateUploadUrl": {
        let o = "https://some-deployment.convex.cloud/api/storage/upload?token=" + Math.random();
        return JSON.stringify(U(o));
      }
      case "1.0/count": {
        let { table: o } = n, s = i.startQuery({
          source: { type: "FullTableScan", tableName: o, order: "asc" },
          operators: []
        }), a = 0;
        for (; !i.queryNext(s).done; )
          a += 1;
        return JSON.stringify(a);
      }
      default:
        throw new Error(`\`convexTest\` does not support async syscall: "${e}"`);
    }
  };
}
c(ea, "asyncSyscallImpl");
function ta() {
  return async (e, t) => {
    let n = ut();
    switch (e) {
      case "storage/storeBlob": {
        let { blob: i } = t, o = await pi(async (s) => s.insert("_storage", {
          size: i.size,
          sha256: await na(i)
        }));
        return n.storeFile(o, i), o;
      }
      case "storage/getBlob": {
        let { storageId: i } = t;
        return n.getFile(i);
      }
      default:
        throw new Error(`\`convexTest\` does not support js syscall: "${e}"`);
    }
  };
}
c(ta, "jsSyscallImpl");
async function pi(e) {
  let t = ut();
  return ye().isInTransaction() ? await e(t) : await V().run(async () => await e(t));
}
c(pi, "writeToDatabase");
async function na(e) {
  let t = await e.arrayBuffer(), n = await crypto.subtle.digest("SHA-256", t), i = new Uint8Array(n);
  return btoa(String.fromCharCode(...i));
}
c(na, "blobSha");
async function li() {
  let e = !1;
  for (let t of Object.keys(de().components)) {
    let i = (await V().runInComponent(t, async (o) => (await o.db.system.query("_scheduled_functions").collect()).filter((s) => s.state.kind === "inProgress"))).length;
    i !== 0 && (e = !0, await new Promise((o) => {
      mi(t).jobListener = () => {
        i -= 1, i === 0 && o();
      };
    }));
  }
  return e;
}
c(li, "waitForInProgressScheduledFunctions");
function hi(e) {
  let t = de();
  if (t.components[e] === void 0)
    throw new Error(`Component "${e}" is not registered. Call "t.registerComponent".`);
  return t.components[e];
}
c(hi, "getComponentInfo");
function mi(e) {
  return hi(e).db;
}
c(mi, "getDbForComponent");
function ut() {
  return mi(_e());
}
c(ut, "getDb");
function ye() {
  return de().transactionManager;
}
c(ye, "getTransactionManager");
function _e() {
  let e = ye().functionStack;
  return e[e.length - 1]?.componentPath ?? mn;
}
c(_e, "getCurrentComponentPath");
function ra() {
  return gi(_e());
}
c(ra, "getModules");
function gi(e) {
  return hi(e).modules;
}
c(gi, "getModulesForComponent");
function ui() {
  return global.Convex;
}
c(ui, "getSyscalls");
function fi(e) {
  let t = e ?? import.meta.glob("../../../convex/**/*.*s"), n = ia(Object.keys(t), e !== void 0), i = Object.fromEntries(Object.entries(t).map(([o, s]) => [
    o.replace(/\.[^.]+$/, ""),
    s
  ]));
  return async (o) => {
    let s = i[n + o];
    if (s === void 0)
      throw new Error(`Could not find module for: "${o}"`);
    return await s();
  };
}
c(fi, "moduleCache");
function ia(e, t) {
  let n = e.find((i) => i.includes("_generated"));
  if (n !== void 0)
    return n.split("_generated", 2)[0];
  throw new Error('Could not find the "_generated" directory, make sure to run `npx convex dev` or `npx convex codegen`. ' + (t ? 'Make sure your `import.meta.glob` includes the files in the "_generated" directory' : 'If your Convex functions aren\'t defined in a directory called "convex" sibling to your node_modules, provide the second argument to `convexTest`'));
}
c(ia, "findModulesRoot");
function de() {
  return global.Convex;
}
c(de, "getConvexGlobal");
function oa(e) {
  if (de() && ye().isInTransaction())
    throw new Error("test began while previous transaction was still open");
  global.Convex = e;
}
c(oa, "setConvexGlobal");
var yn = class {
  static {
    c(this, "TransactionManager");
  }
  // The DatabaseFake is used in the Convex global,
  // and so it restricts `convexTest` to run one function
  // at a time.
  // We force sequential execution to make sure actions
  // can run mutations in parallel.
  _waitOnCurrentFunction = null;
  _markTransactionDone = null;
  functionStack = [];
  async begin(t, n) {
    if (!n) {
      for (; this._waitOnCurrentFunction !== null; )
        await this._waitOnCurrentFunction;
      this._waitOnCurrentFunction = new Promise((o) => {
        this._markTransactionDone = o;
      });
    }
    this.functionStack.push(t);
    let i = de();
    for (let o of Object.values(i.components))
      o.db.startTransaction();
  }
  beginAction(t) {
    this.functionStack.push(t);
  }
  finishAction() {
    this.functionStack.pop();
  }
  // Used to distinguish between mutation and action execution
  // environment.
  isInTransaction() {
    return this._waitOnCurrentFunction !== null;
  }
  commit(t) {
    let n = de();
    for (let i of Object.values(n.components))
      i.db.commit();
    this._endTransaction(t);
  }
  rollback(t) {
    let n = de();
    for (let i of Object.values(n.components))
      i.db.rollbackWrites();
    this._endTransaction(t);
  }
  _endTransaction(t) {
    if (this._markTransactionDone === null)
      throw new Error("Transaction not started");
    this.functionStack.pop(), t || (this._waitOnCurrentFunction = null, this._markTransactionDone(), this._markTransactionDone = null);
  }
}, yi = /* @__PURE__ */ c((e, t) => {
  let n = new at(e ?? null, mn);
  return oa({
    components: {
      [mn]: {
        db: n,
        modules: fi(t)
      }
    },
    transactionManager: new yn(),
    syscall: Zs(),
    asyncSyscall: ea(),
    jsSyscall: ta()
  }), {
    withIdentity(i) {
      let o = i.subject ?? "" + ca(JSON.stringify(i)), s = i.issuer ?? "https://convex.test", a = i.tokenIdentifier ?? `${s}|${o}`;
      return V(new lt({ ...i, subject: o, issuer: s, tokenIdentifier: a }));
    },
    ...V(),
    registerComponent(i, o, s) {
      let a = {
        db: new at(o, i),
        modules: fi(s)
      };
      de().components[i] = a;
    }
  };
}, "convexTest");
function V(e = new lt()) {
  let t = /* @__PURE__ */ c(async (s, a, l = {}, u, p) => {
    let h = ni({
      handler: /* @__PURE__ */ c((w, _) => {
        let T = { ...w, auth: e, ...l };
        return s(T, _);
      }, "handler")
    }), g = ye();
    await g.begin(u, p);
    try {
      let w = await h.invokeMutation(JSON.stringify(U([pn(a)])));
      return g.commit(p), ae(JSON.parse(w));
    } catch (w) {
      throw g.rollback(p), w;
    }
  }, "runTransaction"), n = {
    queryFromPath: /* @__PURE__ */ c(async (s, a, l) => {
      let u = await it(s, "query");
      be(JSON.parse(u.exportArgs()), l ?? {});
      let p = ri({
        handler: /* @__PURE__ */ c((g, w) => {
          let _ = { ...g, auth: e };
          return qe(u)(_, w);
        }, "handler")
      }), h = ye();
      await h.begin(s, a);
      try {
        let g = await p.invokeQuery(JSON.stringify(U([pn(l)])));
        return ae(JSON.parse(g));
      } finally {
        h.rollback(a);
      }
    }, "queryFromPath"),
    mutationFromPath: /* @__PURE__ */ c(async (s, a, l) => {
      let u = await it(s, "mutation");
      return be(JSON.parse(u.exportArgs()), l ?? {}), await t(qe(u), l, {}, s, a);
    }, "mutationFromPath"),
    actionFromPath: /* @__PURE__ */ c(async (s, a) => {
      let l = await it(s, "action");
      be(JSON.parse(l.exportArgs()), a ?? {});
      let u = dn({
        handler: /* @__PURE__ */ c((g, w) => {
          let _ = {
            ...g,
            runQuery: i.query,
            runMutation: i.mutation,
            runAction: i.action,
            auth: e
          };
          return qe(l)(_, w);
        }, "handler")
      });
      ye().beginAction(s);
      let p = "" + Math.random(), h = await u.invokeAction(p, JSON.stringify(U([pn(a)])));
      return ye().finishAction(), ae(JSON.parse(h));
    }, "actionFromPath")
  }, i = {
    query: /* @__PURE__ */ c(async (s, a) => {
      let l = await hn(s);
      return await n.queryFromPath(
        l,
        /* isNested */
        !1,
        a
      );
    }, "query"),
    mutation: /* @__PURE__ */ c(async (s, a) => {
      let l = await hn(s);
      return await n.mutationFromPath(
        l,
        /* isNested */
        !1,
        a
      );
    }, "mutation"),
    action: /* @__PURE__ */ c(async (s, a) => {
      let l = await hn(s);
      return await n.actionFromPath(l, a);
    }, "action")
  }, o = /* @__PURE__ */ c(async (s, a) => {
    let l = dn({
      handler: /* @__PURE__ */ c(async ({ storage: h }) => await t(
        a,
        {},
        { storage: h },
        // Fake mutation path.
        {
          componentPath: s,
          udfPath: "custom"
        },
        !1
      ), "handler")
    }), u = "" + Math.random(), p = await l.invokeAction(u, JSON.stringify(U([{}])));
    return ae(JSON.parse(p));
  }, "run");
  return {
    ...i,
    ...n,
    runInComponent: o,
    run: /* @__PURE__ */ c(async (s) => await o(_e(), s), "run"),
    fun: /* @__PURE__ */ c(async (s, a) => {
      let l = await it(s, "any");
      if (l.isQuery)
        return await n.queryFromPath(
          s,
          /* isNested */
          !1,
          a
        );
      if (l.isMutation)
        return await n.mutationFromPath(
          s,
          /* isNested */
          !1,
          a
        );
      if (l.isAction)
        return await n.actionFromPath(s, a);
    }, "fun"),
    fetch: /* @__PURE__ */ c(async (s, a) => {
      let l = (await ra()("http")).default;
      if (!s.startsWith("/"))
        throw new Error("Path given to `t.fetch` must start with a `/`");
      let u = new URL(`https://some.convex.site${s}`), p = l.lookup(u.pathname, a?.method ?? "GET");
      if (!p)
        return new Response(`No HttpAction routed for ${u.pathname}`, {
          status: 404
        });
      let [h] = p;
      return await ii((_, T) => {
        let b = {
          ..._,
          runQuery: i.query,
          runMutation: i.mutation,
          runAction: i.action,
          auth: e
        };
        return qe(h)(b, T);
      }).invokeHttpAction(new Request(u, a));
    }, "fetch"),
    // This is needed because when we execute functions
    // we are performing dynamic `import`s, and those
    // are real work that cannot be force-awaited.
    finishInProgressScheduledFunctions: /* @__PURE__ */ c(async () => {
      await li();
    }, "finishInProgressScheduledFunctions"),
    finishAllScheduledFunctions: /* @__PURE__ */ c(async (s, a = 100) => {
      for (let l = 0; l < a; l++)
        if (s(), !await li())
          return;
      throw new Error("finishAllScheduledFunctions: too many iterations. Check for infinitely recursive scheduled functions, or increase maxIterations.");
    }, "finishAllScheduledFunctions")
  };
}
c(V, "withAuth");
function pn(e) {
  if (e === void 0)
    return {};
  if (!bn(e))
    throw new Error(`The arguments to a Convex function must be an object. Received: ${e}`);
  return e;
}
c(pn, "parseArgs");
function sa(e) {
  return `function://${e.componentPath};${e.udfPath}`;
}
c(sa, "createFunctionHandle");
function aa(e) {
  let [t, n] = e.split("function://")[1].split(";");
  return { componentPath: t, udfPath: n };
}
c(aa, "parseFunctionHandle");
async function st(e) {
  if (e.functionHandle !== void 0)
    return aa(e.functionHandle);
  if (e.name !== void 0)
    return {
      udfPath: e.name,
      componentPath: _e()
    };
  if (e.reference !== void 0) {
    let n = e.reference.split("/")[2];
    _e().length > 0 && (n = `${_e()}/${n}`);
    let i = e.reference.split("/").slice(3).join("/"), o = i.split("/").slice(0, -1).join("/"), s = i.split("/").pop();
    return {
      udfPath: `${o}:${s}`,
      componentPath: n
    };
  }
  throw new Error("Function address not supported");
}
c(st, "getFunctionPathFromAddress");
async function hn(e) {
  let t = ti(e);
  return await st(t);
}
c(hn, "getFunctionPathFromReference");
function qe(e) {
  return "_handler" in e ? e._handler : e;
}
c(qe, "getHandler");
async function it(e, t) {
  let [n, i] = e.udfPath.split(":"), o = i === void 0 ? "default" : i, a = (await gi(e.componentPath)(n))[o];
  if (a === void 0)
    throw new Error(`Expected a Convex function exported from module "${n}" as \`${o}\`, but there is no such export.`);
  if (typeof qe(a) != "function")
    throw new Error(`Expected a Convex function exported from module "${n}" as \`${o}\`, but got: ${a}`);
  switch (t) {
    case "query":
      if (!a.isQuery)
        throw new Error(`Expected a query function, but the function exported from module "${n}" as \`${o}\` is not a query.`);
      break;
    case "mutation":
      if (!a.isMutation)
        throw new Error(`Expected a mutation function, but the function exported from module "${n}" as \`${o}\` is not a mutation.`);
      break;
    case "action":
      if (!a.isAction)
        throw new Error(`Expected an action function, but the function exported from module "${n}" as \`${o}\` is not an action.`);
      break;
    case "any":
      break;
    default:
      throw t;
  }
  return a;
}
c(it, "getFunctionFromPath");
function ca(e) {
  let t = 0;
  for (let n = 0; n < e.length; n++) {
    let i = e.charCodeAt(n);
    t = (t << 5) - t + i, t = t & t;
  }
  return t;
}
c(ca, "simpleHash");

// node_modules/tinyrainbow/dist/chunk-BVHSVHOK.js
var la = {
  reset: [0, 0],
  bold: [1, 22, "\x1B[22m\x1B[1m"],
  dim: [2, 22, "\x1B[22m\x1B[2m"],
  italic: [3, 23],
  underline: [4, 24],
  inverse: [7, 27],
  hidden: [8, 28],
  strikethrough: [9, 29],
  black: [30, 39],
  red: [31, 39],
  green: [32, 39],
  yellow: [33, 39],
  blue: [34, 39],
  magenta: [35, 39],
  cyan: [36, 39],
  white: [37, 39],
  gray: [90, 39],
  bgBlack: [40, 49],
  bgRed: [41, 49],
  bgGreen: [42, 49],
  bgYellow: [43, 49],
  bgBlue: [44, 49],
  bgMagenta: [45, 49],
  bgCyan: [46, 49],
  bgWhite: [47, 49],
  blackBright: [90, 39],
  redBright: [91, 39],
  greenBright: [92, 39],
  yellowBright: [93, 39],
  blueBright: [94, 39],
  magentaBright: [95, 39],
  cyanBright: [96, 39],
  whiteBright: [97, 39],
  bgBlackBright: [100, 49],
  bgRedBright: [101, 49],
  bgGreenBright: [102, 49],
  bgYellowBright: [103, 49],
  bgBlueBright: [104, 49],
  bgMagentaBright: [105, 49],
  bgCyanBright: [106, 49],
  bgWhiteBright: [107, 49]
}, ua = Object.entries(la);
function _n(e) {
  return String(e);
}
c(_n, "a");
_n.open = "";
_n.close = "";
function bi(e = !1) {
  let t = typeof process < "u" ? process : void 0, n = t?.env || {}, i = t?.argv || [];
  return !("NO_COLOR" in n || i.includes("--no-color")) && ("FORCE_COLOR" in n || i.includes("--color") || t?.platform === "win32" || e && n.TERM !== "dumb" || "CI" in n) || typeof window < "u" && !!window.chrome;
}
c(bi, "C");
function _i(e = !1) {
  let t = bi(e), n = /* @__PURE__ */ c((a, l, u, p) => {
    let h = "", g = 0;
    do
      h += a.substring(g, p) + u, g = p + l.length, p = a.indexOf(l, g);
    while (~p);
    return h + a.substring(g);
  }, "i"), i = /* @__PURE__ */ c((a, l, u = a) => {
    let p = /* @__PURE__ */ c((h) => {
      let g = String(h), w = g.indexOf(l, a.length);
      return ~w ? a + n(g, l, u, w) + l : a + g + l;
    }, "o");
    return p.open = a, p.close = l, p;
  }, "g"), o = {
    isColorSupported: t
  }, s = /* @__PURE__ */ c((a) => `\x1B[${a}m`, "d");
  for (let [a, l] of ua)
    o[a] = t ? i(
      s(l[0]),
      s(l[1]),
      l[2]
    ) : _n;
  return o;
}
c(_i, "p");

// node_modules/tinyrainbow/dist/browser.js
var wi = _i();

// node_modules/@vitest/pretty-format/dist/index.js
function Ai(e, t) {
  return t.forEach(function(n) {
    n && typeof n != "string" && !Array.isArray(n) && Object.keys(n).forEach(function(i) {
      if (i !== "default" && !(i in e)) {
        var o = Object.getOwnPropertyDescriptor(n, i);
        Object.defineProperty(e, i, o.get ? o : {
          enumerable: !0,
          get: /* @__PURE__ */ c(function() {
            return n[i];
          }, "get")
        });
      }
    });
  }), Object.freeze(e);
}
c(Ai, "_mergeNamespaces");
function fa(e, t) {
  let n = Object.keys(e), i = t === null ? n : n.sort(t);
  if (Object.getOwnPropertySymbols)
    for (let o of Object.getOwnPropertySymbols(e))
      Object.getOwnPropertyDescriptor(e, o).enumerable && i.push(o);
  return i;
}
c(fa, "getKeysOfEnumerableProperties");
function dt(e, t, n, i, o, s, a = ": ") {
  let l = "", u = 0, p = e.next();
  if (!p.done) {
    l += t.spacingOuter;
    let h = n + t.indent;
    for (; !p.done; ) {
      if (l += h, u++ === t.maxWidth) {
        l += "\u2026";
        break;
      }
      let g = s(p.value[0], t, h, i, o), w = s(p.value[1], t, h, i, o);
      l += g + a + w, p = e.next(), p.done ? t.min || (l += ",") : l += `,${t.spacingInner}`;
    }
    l += t.spacingOuter + n;
  }
  return l;
}
c(dt, "printIteratorEntries");
function Ci(e, t, n, i, o, s) {
  let a = "", l = 0, u = e.next();
  if (!u.done) {
    a += t.spacingOuter;
    let p = n + t.indent;
    for (; !u.done; ) {
      if (a += p, l++ === t.maxWidth) {
        a += "\u2026";
        break;
      }
      a += s(u.value, t, p, i, o), u = e.next(), u.done ? t.min || (a += ",") : a += `,${t.spacingInner}`;
    }
    a += t.spacingOuter + n;
  }
  return a;
}
c(Ci, "printIteratorValues");
function $i(e, t, n, i, o, s) {
  let a = "";
  e = e instanceof ArrayBuffer ? new DataView(e) : e;
  let l = /* @__PURE__ */ c((p) => p instanceof DataView, "isDataView"), u = l(e) ? e.byteLength : e.length;
  if (u > 0) {
    a += t.spacingOuter;
    let p = n + t.indent;
    for (let h = 0; h < u; h++) {
      if (a += p, h === t.maxWidth) {
        a += "\u2026";
        break;
      }
      (l(e) || h in e) && (a += s(l(e) ? e.getInt8(h) : e[h], t, p, i, o)), h < u - 1 ? a += `,${t.spacingInner}` : t.min || (a += ",");
    }
    a += t.spacingOuter + n;
  }
  return a;
}
c($i, "printListItems");
function Ni(e, t, n, i, o, s) {
  let a = "", l = fa(e, t.compareKeys);
  if (l.length > 0) {
    a += t.spacingOuter;
    let u = n + t.indent;
    for (let p = 0; p < l.length; p++) {
      let h = l[p], g = s(h, t, u, i, o), w = s(e[h], t, u, i, o);
      a += `${u + g}: ${w}`, p < l.length - 1 ? a += `,${t.spacingInner}` : t.min || (a += ",");
    }
    a += t.spacingOuter + n;
  }
  return a;
}
c(Ni, "printObjectProperties");
var da = typeof Symbol == "function" && Symbol.for ? Symbol.for("jest.asymmetricMatcher") : 1267621, ft = " ", pa = /* @__PURE__ */ c((e, t, n, i, o, s) => {
  let a = e.toString();
  if (a === "ArrayContaining" || a === "ArrayNotContaining")
    return ++i > t.maxDepth ? `[${a}]` : `${a + ft}[${$i(e.sample, t, n, i, o, s)}]`;
  if (a === "ObjectContaining" || a === "ObjectNotContaining")
    return ++i > t.maxDepth ? `[${a}]` : `${a + ft}{${Ni(e.sample, t, n, i, o, s)}}`;
  if (a === "StringMatching" || a === "StringNotMatching" || a === "StringContaining" || a === "StringNotContaining")
    return a + ft + s(e.sample, t, n, i, o);
  if (typeof e.toAsymmetricMatcher != "function")
    throw new TypeError(`Asymmetric matcher ${e.constructor.name} does not implement toAsymmetricMatcher()`);
  return e.toAsymmetricMatcher();
}, "serialize$5"), ha = /* @__PURE__ */ c((e) => e && e.$$typeof === da, "test$5"), ma = {
  serialize: pa,
  test: ha
}, ga = " ", Oi = /* @__PURE__ */ new Set(["DOMStringMap", "NamedNodeMap"]), ya = /^(?:HTML\w*Collection|NodeList)$/;
function ba(e) {
  return Oi.has(e) || ya.test(e);
}
c(ba, "testName");
var _a = /* @__PURE__ */ c((e) => e && e.constructor && !!e.constructor.name && ba(e.constructor.name), "test$4");
function wa(e) {
  return e.constructor.name === "NamedNodeMap";
}
c(wa, "isNamedNodeMap");
var Ea = /* @__PURE__ */ c((e, t, n, i, o, s) => {
  let a = e.constructor.name;
  return ++i > t.maxDepth ? `[${a}]` : (t.min ? "" : a + ga) + (Oi.has(a) ? `{${Ni(wa(e) ? [...e].reduce((l, u) => (l[u.name] = u.value, l), {}) : { ...e }, t, n, i, o, s)}}` : `[${$i([...e], t, n, i, o, s)}]`);
}, "serialize$4"), Ta = {
  serialize: Ea,
  test: _a
};
function Ri(e) {
  return e.replaceAll("<", "&lt;").replaceAll(">", "&gt;");
}
c(Ri, "escapeHTML");
function xn(e, t, n, i, o, s, a) {
  let l = i + n.indent, u = n.colors;
  return e.map((p) => {
    let h = t[p], g = a(h, n, l, o, s);
    return typeof h != "string" && (g.includes(`
`) && (g = n.spacingOuter + l + g + n.spacingOuter + i), g = `{${g}}`), `${n.spacingInner + i + u.prop.open + p + u.prop.close}=${u.value.open}${g}${u.value.close}`;
  }).join("");
}
c(xn, "printProps");
function Sn(e, t, n, i, o, s) {
  return e.map((a) => t.spacingOuter + n + (typeof a == "string" ? Mi(a, t) : s(a, t, n, i, o))).join("");
}
c(Sn, "printChildren");
function Mi(e, t) {
  let n = t.colors.content;
  return n.open + Ri(e) + n.close;
}
c(Mi, "printText");
function va(e, t) {
  let n = t.colors.comment;
  return `${n.open}<!--${Ri(e)}-->${n.close}`;
}
c(va, "printComment");
function In(e, t, n, i, o) {
  let s = i.colors.tag;
  return `${s.open}<${e}${t && s.close + t + i.spacingOuter + o + s.open}${n ? `>${s.close}${n}${i.spacingOuter}${o}${s.open}</${e}` : `${t && !i.min ? "" : " "}/`}>${s.close}`;
}
c(In, "printElement");
function Pn(e, t) {
  let n = t.colors.tag;
  return `${n.open}<${e}${n.close} \u2026${n.open} />${n.close}`;
}
c(Pn, "printElementAsLeaf");
var xa = 1, ji = 3, ki = 8, Fi = 11, Sa = /^(?:(?:HTML|SVG)\w*)?Element$/;
function Ia(e) {
  try {
    return typeof e.hasAttribute == "function" && e.hasAttribute("is");
  } catch {
    return !1;
  }
}
c(Ia, "testHasAttribute");
function Pa(e) {
  let t = e.constructor.name, { nodeType: n, tagName: i } = e, o = typeof i == "string" && i.includes("-") || Ia(e);
  return n === xa && (Sa.test(t) || o) || n === ji && t === "Text" || n === ki && t === "Comment" || n === Fi && t === "DocumentFragment";
}
c(Pa, "testNode");
var Aa = /* @__PURE__ */ c((e) => {
  var t;
  return (e == null || (t = e.constructor) === null || t === void 0 ? void 0 : t.name) && Pa(e);
}, "test$3");
function Ca(e) {
  return e.nodeType === ji;
}
c(Ca, "nodeIsText");
function $a(e) {
  return e.nodeType === ki;
}
c($a, "nodeIsComment");
function wn(e) {
  return e.nodeType === Fi;
}
c(wn, "nodeIsFragment");
var Na = /* @__PURE__ */ c((e, t, n, i, o, s) => {
  if (Ca(e))
    return Mi(e.data, t);
  if ($a(e))
    return va(e.data, t);
  let a = wn(e) ? "DocumentFragment" : e.tagName.toLowerCase();
  return ++i > t.maxDepth ? Pn(a, t) : In(a, xn(wn(e) ? [] : Array.from(e.attributes, (l) => l.name).sort(), wn(e) ? {} : [...e.attributes].reduce((l, u) => (l[u.name] = u.value, l), {}), t, n + t.indent, i, o, s), Sn(Array.prototype.slice.call(e.childNodes || e.children), t, n + t.indent, i, o, s), t, n);
}, "serialize$3"), Oa = {
  serialize: Na,
  test: Aa
}, Ra = "@@__IMMUTABLE_ITERABLE__@@", Ma = "@@__IMMUTABLE_LIST__@@", ja = "@@__IMMUTABLE_KEYED__@@", ka = "@@__IMMUTABLE_MAP__@@", Ei = "@@__IMMUTABLE_ORDERED__@@", Fa = "@@__IMMUTABLE_RECORD__@@", Da = "@@__IMMUTABLE_SEQ__@@", La = "@@__IMMUTABLE_SET__@@", qa = "@@__IMMUTABLE_STACK__@@", $e = /* @__PURE__ */ c((e) => `Immutable.${e}`, "getImmutableName"), pt = /* @__PURE__ */ c((e) => `[${e}]`, "printAsLeaf"), Be = " ", Ti = "\u2026";
function za(e, t, n, i, o, s, a) {
  return ++i > t.maxDepth ? pt($e(a)) : `${$e(a) + Be}{${dt(e.entries(), t, n, i, o, s)}}`;
}
c(za, "printImmutableEntries");
function Ba(e) {
  let t = 0;
  return { next() {
    if (t < e._keys.length) {
      let n = e._keys[t++];
      return {
        done: !1,
        value: [n, e.get(n)]
      };
    }
    return {
      done: !0,
      value: void 0
    };
  } };
}
c(Ba, "getRecordEntries");
function Ua(e, t, n, i, o, s) {
  let a = $e(e._name || "Record");
  return ++i > t.maxDepth ? pt(a) : `${a + Be}{${dt(Ba(e), t, n, i, o, s)}}`;
}
c(Ua, "printImmutableRecord");
function Ya(e, t, n, i, o, s) {
  let a = $e("Seq");
  return ++i > t.maxDepth ? pt(a) : e[ja] ? `${a + Be}{${e._iter || e._object ? dt(e.entries(), t, n, i, o, s) : Ti}}` : `${a + Be}[${e._iter || e._array || e._collection || e._iterable ? Ci(e.values(), t, n, i, o, s) : Ti}]`;
}
c(Ya, "printImmutableSeq");
function En(e, t, n, i, o, s, a) {
  return ++i > t.maxDepth ? pt($e(a)) : `${$e(a) + Be}[${Ci(e.values(), t, n, i, o, s)}]`;
}
c(En, "printImmutableValues");
var Ja = /* @__PURE__ */ c((e, t, n, i, o, s) => e[ka] ? za(e, t, n, i, o, s, e[Ei] ? "OrderedMap" : "Map") : e[Ma] ? En(e, t, n, i, o, s, "List") : e[La] ? En(e, t, n, i, o, s, e[Ei] ? "OrderedSet" : "Set") : e[qa] ? En(e, t, n, i, o, s, "Stack") : e[Da] ? Ya(e, t, n, i, o, s) : Ua(e, t, n, i, o, s), "serialize$2"), Wa = /* @__PURE__ */ c((e) => e && (e[Ra] === !0 || e[Fa] === !0), "test$2"), Va = {
  serialize: Ja,
  test: Wa
};
function Di(e) {
  return e && e.__esModule && Object.prototype.hasOwnProperty.call(e, "default") ? e.default : e;
}
c(Di, "getDefaultExportFromCjs");
var Tn = { exports: {} }, M = {};
var vi;
function Xa() {
  if (vi) return M;
  vi = 1;
  var e = Symbol.for("react.transitional.element"), t = Symbol.for("react.portal"), n = Symbol.for("react.fragment"), i = Symbol.for("react.strict_mode"), o = Symbol.for("react.profiler"), s = Symbol.for("react.consumer"), a = Symbol.for("react.context"), l = Symbol.for("react.forward_ref"), u = Symbol.for("react.suspense"), p = Symbol.for("react.suspense_list"), h = Symbol.for("react.memo"), g = Symbol.for("react.lazy"), w = Symbol.for("react.view_transition"), _ = Symbol.for("react.client.reference");
  function T(b) {
    if (typeof b == "object" && b !== null) {
      var E = b.$$typeof;
      switch (E) {
        case e:
          switch (b = b.type, b) {
            case n:
            case o:
            case i:
            case u:
            case p:
            case w:
              return b;
            default:
              switch (b = b && b.$$typeof, b) {
                case a:
                case l:
                case g:
                case h:
                  return b;
                case s:
                  return b;
                default:
                  return E;
              }
          }
        case t:
          return E;
      }
    }
  }
  return c(T, "typeOf"), M.ContextConsumer = s, M.ContextProvider = a, M.Element = e, M.ForwardRef = l, M.Fragment = n, M.Lazy = g, M.Memo = h, M.Portal = t, M.Profiler = o, M.StrictMode = i, M.Suspense = u, M.SuspenseList = p, M.isContextConsumer = function(b) {
    return T(b) === s;
  }, M.isContextProvider = function(b) {
    return T(b) === a;
  }, M.isElement = function(b) {
    return typeof b == "object" && b !== null && b.$$typeof === e;
  }, M.isForwardRef = function(b) {
    return T(b) === l;
  }, M.isFragment = function(b) {
    return T(b) === n;
  }, M.isLazy = function(b) {
    return T(b) === g;
  }, M.isMemo = function(b) {
    return T(b) === h;
  }, M.isPortal = function(b) {
    return T(b) === t;
  }, M.isProfiler = function(b) {
    return T(b) === o;
  }, M.isStrictMode = function(b) {
    return T(b) === i;
  }, M.isSuspense = function(b) {
    return T(b) === u;
  }, M.isSuspenseList = function(b) {
    return T(b) === p;
  }, M.isValidElementType = function(b) {
    return typeof b == "string" || typeof b == "function" || b === n || b === o || b === i || b === u || b === p || typeof b == "object" && b !== null && (b.$$typeof === g || b.$$typeof === h || b.$$typeof === a || b.$$typeof === s || b.$$typeof === l || b.$$typeof === _ || b.getModuleId !== void 0);
  }, M.typeOf = T, M;
}
c(Xa, "requireReactIs_production");
var xi;
function Ka() {
  return xi || (xi = 1, Tn.exports = Xa()), Tn.exports;
}
c(Ka, "requireReactIs$1");
var Li = Ka(), Ga = /* @__PURE__ */ Di(Li), Ha = /* @__PURE__ */ Ai({
  __proto__: null,
  default: Ga
}, [Li]), vn = { exports: {} }, R = {};
var Si;
function Qa() {
  if (Si) return R;
  Si = 1;
  var e = Symbol.for("react.element"), t = Symbol.for("react.portal"), n = Symbol.for("react.fragment"), i = Symbol.for("react.strict_mode"), o = Symbol.for("react.profiler"), s = Symbol.for("react.provider"), a = Symbol.for("react.context"), l = Symbol.for("react.server_context"), u = Symbol.for("react.forward_ref"), p = Symbol.for("react.suspense"), h = Symbol.for("react.suspense_list"), g = Symbol.for("react.memo"), w = Symbol.for("react.lazy"), _ = Symbol.for("react.offscreen"), T;
  T = Symbol.for("react.module.reference");
  function b(E) {
    if (typeof E == "object" && E !== null) {
      var v = E.$$typeof;
      switch (v) {
        case e:
          switch (E = E.type, E) {
            case n:
            case o:
            case i:
            case p:
            case h:
              return E;
            default:
              switch (E = E && E.$$typeof, E) {
                case l:
                case a:
                case u:
                case w:
                case g:
                case s:
                  return E;
                default:
                  return v;
              }
          }
        case t:
          return v;
      }
    }
  }
  return c(b, "v"), R.ContextConsumer = a, R.ContextProvider = s, R.Element = e, R.ForwardRef = u, R.Fragment = n, R.Lazy = w, R.Memo = g, R.Portal = t, R.Profiler = o, R.StrictMode = i, R.Suspense = p, R.SuspenseList = h, R.isAsyncMode = function() {
    return !1;
  }, R.isConcurrentMode = function() {
    return !1;
  }, R.isContextConsumer = function(E) {
    return b(E) === a;
  }, R.isContextProvider = function(E) {
    return b(E) === s;
  }, R.isElement = function(E) {
    return typeof E == "object" && E !== null && E.$$typeof === e;
  }, R.isForwardRef = function(E) {
    return b(E) === u;
  }, R.isFragment = function(E) {
    return b(E) === n;
  }, R.isLazy = function(E) {
    return b(E) === w;
  }, R.isMemo = function(E) {
    return b(E) === g;
  }, R.isPortal = function(E) {
    return b(E) === t;
  }, R.isProfiler = function(E) {
    return b(E) === o;
  }, R.isStrictMode = function(E) {
    return b(E) === i;
  }, R.isSuspense = function(E) {
    return b(E) === p;
  }, R.isSuspenseList = function(E) {
    return b(E) === h;
  }, R.isValidElementType = function(E) {
    return typeof E == "string" || typeof E == "function" || E === n || E === o || E === i || E === p || E === h || E === _ || typeof E == "object" && E !== null && (E.$$typeof === w || E.$$typeof === g || E.$$typeof === s || E.$$typeof === a || E.$$typeof === u || E.$$typeof === T || E.getModuleId !== void 0);
  }, R.typeOf = b, R;
}
c(Qa, "requireReactIs_production_min");
var Ii;
function Za() {
  return Ii || (Ii = 1, vn.exports = Qa()), vn.exports;
}
c(Za, "requireReactIs");
var qi = Za(), ec = /* @__PURE__ */ Di(qi), tc = /* @__PURE__ */ Ai({
  __proto__: null,
  default: ec
}, [qi]), nc = [
  "isAsyncMode",
  "isConcurrentMode",
  "isContextConsumer",
  "isContextProvider",
  "isElement",
  "isForwardRef",
  "isFragment",
  "isLazy",
  "isMemo",
  "isPortal",
  "isProfiler",
  "isStrictMode",
  "isSuspense",
  "isSuspenseList",
  "isValidElementType"
], we = Object.fromEntries(nc.map((e) => [e, (t) => tc[e](t) || Ha[e](t)]));
function zi(e, t = []) {
  if (Array.isArray(e))
    for (let n of e)
      zi(n, t);
  else e != null && e !== !1 && e !== "" && t.push(e);
  return t;
}
c(zi, "getChildren");
function Pi(e) {
  let t = e.type;
  if (typeof t == "string")
    return t;
  if (typeof t == "function")
    return t.displayName || t.name || "Unknown";
  if (we.isFragment(e))
    return "React.Fragment";
  if (we.isSuspense(e))
    return "React.Suspense";
  if (typeof t == "object" && t !== null) {
    if (we.isContextProvider(e))
      return "Context.Provider";
    if (we.isContextConsumer(e))
      return "Context.Consumer";
    if (we.isForwardRef(e)) {
      if (t.displayName)
        return t.displayName;
      let n = t.render.displayName || t.render.name || "";
      return n === "" ? "ForwardRef" : `ForwardRef(${n})`;
    }
    if (we.isMemo(e)) {
      let n = t.displayName || t.type.displayName || t.type.name || "";
      return n === "" ? "Memo" : `Memo(${n})`;
    }
  }
  return "UNDEFINED";
}
c(Pi, "getType");
function rc(e) {
  let { props: t } = e;
  return Object.keys(t).filter((n) => n !== "children" && t[n] !== void 0).sort();
}
c(rc, "getPropKeys$1");
var ic = /* @__PURE__ */ c((e, t, n, i, o, s) => ++i > t.maxDepth ? Pn(Pi(e), t) : In(Pi(e), xn(rc(e), e.props, t, n + t.indent, i, o, s), Sn(zi(e.props.children), t, n + t.indent, i, o, s), t, n), "serialize$1"), oc = /* @__PURE__ */ c((e) => e != null && we.isElement(e), "test$1"), sc = {
  serialize: ic,
  test: oc
}, ac = typeof Symbol == "function" && Symbol.for ? Symbol.for("react.test.json") : 245830487;
function cc(e) {
  let { props: t } = e;
  return t ? Object.keys(t).filter((n) => t[n] !== void 0).sort() : [];
}
c(cc, "getPropKeys");
var lc = /* @__PURE__ */ c((e, t, n, i, o, s) => ++i > t.maxDepth ? Pn(e.type, t) : In(e.type, e.props ? xn(cc(e), e.props, t, n + t.indent, i, o, s) : "", e.children ? Sn(e.children, t, n + t.indent, i, o, s) : "", t, n), "serialize"), uc = /* @__PURE__ */ c((e) => e && e.$$typeof === ac, "test"), fc = {
  serialize: lc,
  test: uc
};
var pu = Date.prototype.toISOString, hu = Error.prototype.toString, mu = RegExp.prototype.toString;
function dc(e) {
  return typeof e.constructor == "function" && e.constructor.name || "Object";
}
c(dc, "getConstructorName");
var pc = {
  test: /* @__PURE__ */ c((e) => e && e instanceof Error, "test"),
  serialize(e, t, n, i, o, s) {
    if (o.includes(e))
      return "[Circular]";
    o = [...o, e];
    let a = ++i > t.maxDepth, { message: l, cause: u, ...p } = e, h = {
      message: l,
      ...typeof u < "u" ? { cause: u } : {},
      ...e instanceof AggregateError ? { errors: e.errors } : {},
      ...p
    }, g = e.name !== "Error" ? e.name : dc(e);
    return a ? `[${g}]` : `${g} {${dt(Object.entries(h).values(), t, n, i, o, s)}}`;
  }
};
var Bi = {
  comment: "gray",
  content: "reset",
  prop: "yellow",
  tag: "cyan",
  value: "green"
}, gu = Object.keys(Bi), yu = {
  callToJSON: !0,
  compareKeys: void 0,
  escapeRegex: !1,
  escapeString: !0,
  highlight: !1,
  indent: 2,
  maxDepth: Number.POSITIVE_INFINITY,
  maxWidth: Number.POSITIVE_INFINITY,
  min: !1,
  plugins: [],
  printBasicPrototype: !0,
  printFunctionName: !0,
  theme: Bi
};
var Ui = {
  AsymmetricMatcher: ma,
  DOMCollection: Ta,
  DOMElement: Oa,
  Immutable: Va,
  ReactElement: sc,
  ReactTestComponent: fc,
  Error: pc
};

// node_modules/loupe/lib/helpers.js
var Yi = {
  bold: ["1", "22"],
  dim: ["2", "22"],
  italic: ["3", "23"],
  underline: ["4", "24"],
  // 5 & 6 are blinking
  inverse: ["7", "27"],
  hidden: ["8", "28"],
  strike: ["9", "29"],
  // 10-20 are fonts
  // 21-29 are resets for 1-9
  black: ["30", "39"],
  red: ["31", "39"],
  green: ["32", "39"],
  yellow: ["33", "39"],
  blue: ["34", "39"],
  magenta: ["35", "39"],
  cyan: ["36", "39"],
  white: ["37", "39"],
  brightblack: ["30;1", "39"],
  brightred: ["31;1", "39"],
  brightgreen: ["32;1", "39"],
  brightyellow: ["33;1", "39"],
  brightblue: ["34;1", "39"],
  brightmagenta: ["35;1", "39"],
  brightcyan: ["36;1", "39"],
  brightwhite: ["37;1", "39"],
  grey: ["90", "39"]
}, hc = {
  special: "cyan",
  number: "yellow",
  bigint: "yellow",
  boolean: "yellow",
  undefined: "grey",
  null: "bold",
  string: "green",
  symbol: "green",
  date: "magenta",
  regexp: "red"
}, ce = "\u2026";
function mc(e, t) {
  let n = Yi[hc[t]] || Yi[t] || "";
  return n ? `\x1B[${n[0]}m${String(e)}\x1B[${n[1]}m` : String(e);
}
c(mc, "colorise");
function Ji({
  showHidden: e = !1,
  depth: t = 2,
  colors: n = !1,
  customInspect: i = !0,
  showProxy: o = !1,
  maxArrayLength: s = 1 / 0,
  breakLength: a = 1 / 0,
  seen: l = [],
  // eslint-disable-next-line no-shadow
  truncate: u = 1 / 0,
  stylize: p = String
} = {}, h) {
  let g = {
    showHidden: !!e,
    depth: Number(t),
    colors: !!n,
    customInspect: !!i,
    showProxy: !!o,
    maxArrayLength: Number(s),
    breakLength: Number(a),
    truncate: Number(u),
    seen: l,
    inspect: h,
    stylize: p
  };
  return g.colors && (g.stylize = mc), g;
}
c(Ji, "normaliseOptions");
function gc(e) {
  return e >= "\uD800" && e <= "\uDBFF";
}
c(gc, "isHighSurrogate");
function W(e, t, n = ce) {
  e = String(e);
  let i = n.length, o = e.length;
  if (i > t && o > i)
    return n;
  if (o > t && o > i) {
    let s = t - i;
    return s > 0 && gc(e[s - 1]) && (s = s - 1), `${e.slice(0, s)}${n}`;
  }
  return e;
}
c(W, "truncate");
function B(e, t, n, i = ", ") {
  n = n || t.inspect;
  let o = e.length;
  if (o === 0)
    return "";
  let s = t.truncate, a = "", l = "", u = "";
  for (let p = 0; p < o; p += 1) {
    let h = p + 1 === e.length, g = p + 2 === e.length;
    u = `${ce}(${e.length - p})`;
    let w = e[p];
    t.truncate = s - a.length - (h ? 0 : i.length);
    let _ = l || n(w, t) + (h ? "" : i), T = a.length + _.length, b = T + u.length;
    if (h && T > s && a.length + u.length <= s || !h && !g && b > s || (l = h ? "" : n(e[p + 1], t) + (g ? "" : i), !h && g && b > s && T + l.length > s))
      break;
    if (a += _, !h && !g && T + l.length >= s) {
      u = `${ce}(${e.length - p - 1})`;
      break;
    }
    u = "";
  }
  return `${a}${u}`;
}
c(B, "inspectList");
function yc(e) {
  return e.match(/^[a-zA-Z_][a-zA-Z_0-9]*$/) ? e : JSON.stringify(e).replace(/'/g, "\\'").replace(/\\"/g, '"').replace(/(^"|"$)/g, "'");
}
c(yc, "quoteComplexKey");
function le([e, t], n) {
  return n.truncate -= 2, typeof e == "string" ? e = yc(e) : typeof e != "number" && (e = `[${n.inspect(e, n)}]`), n.truncate -= e.length, t = n.inspect(t, n), `${e}: ${t}`;
}
c(le, "inspectProperty");

// node_modules/loupe/lib/array.js
function An(e, t) {
  let n = Object.keys(e).slice(e.length);
  if (!e.length && !n.length)
    return "[]";
  t.truncate -= 4;
  let i = B(e, t);
  t.truncate -= i.length;
  let o = "";
  return n.length && (o = B(n.map((s) => [s, e[s]]), t, le)), `[ ${i}${o ? `, ${o}` : ""} ]`;
}
c(An, "inspectArray");

// node_modules/loupe/lib/typedarray.js
var bc = /* @__PURE__ */ c((e) => typeof Buffer == "function" && e instanceof Buffer ? "Buffer" : e[Symbol.toStringTag] ? e[Symbol.toStringTag] : e.constructor.name, "getArrayName");
function ee(e, t) {
  let n = bc(e);
  t.truncate -= n.length + 4;
  let i = Object.keys(e).slice(e.length);
  if (!e.length && !i.length)
    return `${n}[]`;
  let o = "";
  for (let a = 0; a < e.length; a++) {
    let l = `${t.stylize(W(e[a], t.truncate), "number")}${a === e.length - 1 ? "" : ", "}`;
    if (t.truncate -= l.length, e[a] !== e.length && t.truncate <= 3) {
      o += `${ce}(${e.length - e[a] + 1})`;
      break;
    }
    o += l;
  }
  let s = "";
  return i.length && (s = B(i.map((a) => [a, e[a]]), t, le)), `${n}[ ${o}${s ? `, ${s}` : ""} ]`;
}
c(ee, "inspectTypedArray");

// node_modules/loupe/lib/date.js
function Cn(e, t) {
  let n = e.toJSON();
  if (n === null)
    return "Invalid Date";
  let i = n.split("T"), o = i[0];
  return t.stylize(`${o}T${W(i[1], t.truncate - o.length - 1)}`, "date");
}
c(Cn, "inspectDate");

// node_modules/loupe/lib/function.js
function ht(e, t) {
  let n = e[Symbol.toStringTag] || "Function", i = e.name;
  return i ? t.stylize(`[${n} ${W(i, t.truncate - 11)}]`, "special") : t.stylize(`[${n}]`, "special");
}
c(ht, "inspectFunction");

// node_modules/loupe/lib/map.js
function _c([e, t], n) {
  return n.truncate -= 4, e = n.inspect(e, n), n.truncate -= e.length, t = n.inspect(t, n), `${e} => ${t}`;
}
c(_c, "inspectMapEntry");
function wc(e) {
  let t = [];
  return e.forEach((n, i) => {
    t.push([i, n]);
  }), t;
}
c(wc, "mapToEntries");
function $n(e, t) {
  return e.size === 0 ? "Map{}" : (t.truncate -= 7, `Map{ ${B(wc(e), t, _c)} }`);
}
c($n, "inspectMap");

// node_modules/loupe/lib/number.js
var Ec = Number.isNaN || ((e) => e !== e);
function mt(e, t) {
  return Ec(e) ? t.stylize("NaN", "number") : e === 1 / 0 ? t.stylize("Infinity", "number") : e === -1 / 0 ? t.stylize("-Infinity", "number") : e === 0 ? t.stylize(1 / e === 1 / 0 ? "+0" : "-0", "number") : t.stylize(W(String(e), t.truncate), "number");
}
c(mt, "inspectNumber");

// node_modules/loupe/lib/bigint.js
function gt(e, t) {
  let n = W(e.toString(), t.truncate - 1);
  return n !== ce && (n += "n"), t.stylize(n, "bigint");
}
c(gt, "inspectBigInt");

// node_modules/loupe/lib/regexp.js
function Nn(e, t) {
  let n = e.toString().split("/")[2], i = t.truncate - (2 + n.length), o = e.source;
  return t.stylize(`/${W(o, i)}/${n}`, "regexp");
}
c(Nn, "inspectRegExp");

// node_modules/loupe/lib/set.js
function Tc(e) {
  let t = [];
  return e.forEach((n) => {
    t.push(n);
  }), t;
}
c(Tc, "arrayFromSet");
function On(e, t) {
  return e.size === 0 ? "Set{}" : (t.truncate -= 7, `Set{ ${B(Tc(e), t)} }`);
}
c(On, "inspectSet");

// node_modules/loupe/lib/string.js
var Wi = new RegExp("['\\u0000-\\u001f\\u007f-\\u009f\\u00ad\\u0600-\\u0604\\u070f\\u17b4\\u17b5\\u200c-\\u200f\\u2028-\\u202f\\u2060-\\u206f\\ufeff\\ufff0-\\uffff]", "g"), vc = {
  "\b": "\\b",
  "	": "\\t",
  "\n": "\\n",
  "\f": "\\f",
  "\r": "\\r",
  "'": "\\'",
  "\\": "\\\\"
}, xc = 16, Sc = 4;
function Ic(e) {
  return vc[e] || `\\u${`0000${e.charCodeAt(0).toString(xc)}`.slice(-Sc)}`;
}
c(Ic, "escape");
function yt(e, t) {
  return Wi.test(e) && (e = e.replace(Wi, Ic)), t.stylize(`'${W(e, t.truncate - 2)}'`, "string");
}
c(yt, "inspectString");

// node_modules/loupe/lib/symbol.js
function bt(e) {
  return "description" in Symbol.prototype ? e.description ? `Symbol(${e.description})` : "Symbol()" : e.toString();
}
c(bt, "inspectSymbol");

// node_modules/loupe/lib/promise.js
var Vi = /* @__PURE__ */ c(() => "Promise{\u2026}", "getPromiseValue");
try {
  let { getPromiseDetails: e, kPending: t, kRejected: n } = process.binding("util");
  Array.isArray(e(Promise.resolve())) && (Vi = /* @__PURE__ */ c((i, o) => {
    let [s, a] = e(i);
    return s === t ? "Promise{<pending>}" : `Promise${s === n ? "!" : ""}{${o.inspect(a, o)}}`;
  }, "getPromiseValue"));
} catch {
}
var Xi = Vi;

// node_modules/loupe/lib/object.js
function Ee(e, t) {
  let n = Object.getOwnPropertyNames(e), i = Object.getOwnPropertySymbols ? Object.getOwnPropertySymbols(e) : [];
  if (n.length === 0 && i.length === 0)
    return "{}";
  if (t.truncate -= 4, t.seen = t.seen || [], t.seen.includes(e))
    return "[Circular]";
  t.seen.push(e);
  let o = B(n.map((l) => [l, e[l]]), t, le), s = B(i.map((l) => [l, e[l]]), t, le);
  t.seen.pop();
  let a = "";
  return o && s && (a = ", "), `{ ${o}${a}${s} }`;
}
c(Ee, "inspectObject");

// node_modules/loupe/lib/class.js
var Rn = typeof Symbol < "u" && Symbol.toStringTag ? Symbol.toStringTag : !1;
function Mn(e, t) {
  let n = "";
  return Rn && Rn in e && (n = e[Rn]), n = n || e.constructor.name, (!n || n === "_class") && (n = "<Anonymous Class>"), t.truncate -= n.length, `${n}${Ee(e, t)}`;
}
c(Mn, "inspectClass");

// node_modules/loupe/lib/arguments.js
function jn(e, t) {
  return e.length === 0 ? "Arguments[]" : (t.truncate -= 13, `Arguments[ ${B(e, t)} ]`);
}
c(jn, "inspectArguments");

// node_modules/loupe/lib/error.js
var Pc = [
  "stack",
  "line",
  "column",
  "name",
  "message",
  "fileName",
  "lineNumber",
  "columnNumber",
  "number",
  "description",
  "cause"
];
function kn(e, t) {
  let n = Object.getOwnPropertyNames(e).filter((a) => Pc.indexOf(a) === -1), i = e.name;
  t.truncate -= i.length;
  let o = "";
  if (typeof e.message == "string" ? o = W(e.message, t.truncate) : n.unshift("message"), o = o ? `: ${o}` : "", t.truncate -= o.length + 5, t.seen = t.seen || [], t.seen.includes(e))
    return "[Circular]";
  t.seen.push(e);
  let s = B(n.map((a) => [a, e[a]]), t, le);
  return `${i}${o}${s ? ` { ${s} }` : ""}`;
}
c(kn, "inspectObject");

// node_modules/loupe/lib/html.js
function Ac([e, t], n) {
  return n.truncate -= 3, t ? `${n.stylize(String(e), "yellow")}=${n.stylize(`"${t}"`, "string")}` : `${n.stylize(String(e), "yellow")}`;
}
c(Ac, "inspectAttribute");
function _t(e, t) {
  return B(e, t, Cc, `
`);
}
c(_t, "inspectNodeCollection");
function Cc(e, t) {
  switch (e.nodeType) {
    case 1:
      return wt(e, t);
    case 3:
      return t.inspect(e.data, t);
    default:
      return t.inspect(e, t);
  }
}
c(Cc, "inspectNode");
function wt(e, t) {
  let n = e.getAttributeNames(), i = e.tagName.toLowerCase(), o = t.stylize(`<${i}`, "special"), s = t.stylize(">", "special"), a = t.stylize(`</${i}>`, "special");
  t.truncate -= i.length * 2 + 5;
  let l = "";
  n.length > 0 && (l += " ", l += B(n.map((h) => [h, e.getAttribute(h)]), t, Ac, " ")), t.truncate -= l.length;
  let u = t.truncate, p = _t(e.children, t);
  return p && p.length > u && (p = `${ce}(${e.children.length})`), `${o}${l}${s}${p}${a}`;
}
c(wt, "inspectHTML");

// node_modules/loupe/lib/index.js
var $c = typeof Symbol == "function" && typeof Symbol.for == "function", Fn = $c ? Symbol.for("chai/inspect") : "@@chai/inspect", Dn = Symbol.for("nodejs.util.inspect.custom"), Ki = /* @__PURE__ */ new WeakMap(), Gi = {}, Hi = {
  undefined: /* @__PURE__ */ c((e, t) => t.stylize("undefined", "undefined"), "undefined"),
  null: /* @__PURE__ */ c((e, t) => t.stylize("null", "null"), "null"),
  boolean: /* @__PURE__ */ c((e, t) => t.stylize(String(e), "boolean"), "boolean"),
  Boolean: /* @__PURE__ */ c((e, t) => t.stylize(String(e), "boolean"), "Boolean"),
  number: mt,
  Number: mt,
  bigint: gt,
  BigInt: gt,
  string: yt,
  String: yt,
  function: ht,
  Function: ht,
  symbol: bt,
  // A Symbol polyfill will return `Symbol` not `symbol` from typedetect
  Symbol: bt,
  Array: An,
  Date: Cn,
  Map: $n,
  Set: On,
  RegExp: Nn,
  Promise: Xi,
  // WeakSet, WeakMap are totally opaque to us
  WeakSet: /* @__PURE__ */ c((e, t) => t.stylize("WeakSet{\u2026}", "special"), "WeakSet"),
  WeakMap: /* @__PURE__ */ c((e, t) => t.stylize("WeakMap{\u2026}", "special"), "WeakMap"),
  Arguments: jn,
  Int8Array: ee,
  Uint8Array: ee,
  Uint8ClampedArray: ee,
  Int16Array: ee,
  Uint16Array: ee,
  Int32Array: ee,
  Uint32Array: ee,
  Float32Array: ee,
  Float64Array: ee,
  Generator: /* @__PURE__ */ c(() => "", "Generator"),
  DataView: /* @__PURE__ */ c(() => "", "DataView"),
  ArrayBuffer: /* @__PURE__ */ c(() => "", "ArrayBuffer"),
  Error: kn,
  HTMLCollection: _t,
  NodeList: _t
}, Nc = /* @__PURE__ */ c((e, t, n) => Fn in e && typeof e[Fn] == "function" ? e[Fn](t) : Dn in e && typeof e[Dn] == "function" ? e[Dn](t.depth, t) : "inspect" in e && typeof e.inspect == "function" ? e.inspect(t.depth, t) : "constructor" in e && Ki.has(e.constructor) ? Ki.get(e.constructor)(e, t) : Gi[n] ? Gi[n](e, t) : "", "inspectCustom"), Oc = Object.prototype.toString;
function Et(e, t = {}) {
  let n = Ji(t, Et), { customInspect: i } = n, o = e === null ? "null" : typeof e;
  if (o === "object" && (o = Oc.call(e).slice(8, -1)), o in Hi)
    return Hi[o](e, n);
  if (i && e) {
    let a = Nc(e, n, o);
    if (a)
      return typeof a == "string" ? a : Et(a, n);
  }
  let s = e ? Object.getPrototypeOf(e) : !1;
  return s === Object.prototype || s === null ? Ee(e, n) : e && typeof HTMLElement == "function" && e instanceof HTMLElement ? wt(e, n) : "constructor" in e ? e.constructor !== Object ? Mn(e, n) : Ee(e, n) : e === Object(e) ? Ee(e, n) : n.stylize(String(e), o);
}
c(Et, "inspect");

// node_modules/@vitest/utils/dist/chunk-_commonjsHelpers.js
var { AsymmetricMatcher: Lf, DOMCollection: qf, DOMElement: zf, Immutable: Bf, ReactElement: Uf, ReactTestComponent: Yf } = Ui;
var Mc = /%[sdjifoOc%]/g;
function Ln(...e) {
  if (typeof e[0] != "string") {
    let s = [];
    for (let a = 0; a < e.length; a++)
      s.push(Te(e[a], {
        depth: 0,
        colors: !1
      }));
    return s.join(" ");
  }
  let t = e.length, n = 1, i = e[0], o = String(i).replace(Mc, (s) => {
    if (s === "%%")
      return "%";
    if (n >= t)
      return s;
    switch (s) {
      case "%s": {
        let a = e[n++];
        return typeof a == "bigint" ? `${a.toString()}n` : typeof a == "number" && a === 0 && 1 / a < 0 ? "-0" : typeof a == "object" && a !== null ? typeof a.toString == "function" && a.toString !== Object.prototype.toString ? a.toString() : Te(a, {
          depth: 0,
          colors: !1
        }) : String(a);
      }
      case "%d": {
        let a = e[n++];
        return typeof a == "bigint" ? `${a.toString()}n` : Number(a).toString();
      }
      case "%i": {
        let a = e[n++];
        return typeof a == "bigint" ? `${a.toString()}n` : Number.parseInt(String(a)).toString();
      }
      case "%f":
        return Number.parseFloat(String(e[n++])).toString();
      case "%o":
        return Te(e[n++], {
          showHidden: !0,
          showProxy: !0
        });
      case "%O":
        return Te(e[n++]);
      case "%c":
        return n++, "";
      case "%j":
        try {
          return JSON.stringify(e[n++]);
        } catch (a) {
          let l = a.message;
          if (l.includes("circular structure") || l.includes("cyclic structures") || l.includes("cyclic object"))
            return "[Circular]";
          throw a;
        }
      default:
        return s;
    }
  });
  for (let s = e[n]; n < t; s = e[++n])
    s === null || typeof s != "object" ? o += ` ${s}` : o += ` ${Te(s)}`;
  return o;
}
c(Ln, "format");
function Te(e, t = {}) {
  return t.truncate === 0 && (t.truncate = Number.POSITIVE_INFINITY), Et(e, t);
}
c(Te, "inspect");
function qn(e, t = {}) {
  typeof t.truncate > "u" && (t.truncate = 40);
  let n = Te(e, t), i = Object.prototype.toString.call(e);
  if (t.truncate && n.length >= t.truncate)
    if (i === "[object Function]") {
      let o = e;
      return o.name ? `[Function: ${o.name}]` : "[Function]";
    } else {
      if (i === "[object Array]")
        return `[ Array(${e.length}) ]`;
      if (i === "[object Object]") {
        let o = Object.keys(e);
        return `{ Object (${o.length > 2 ? `${o.splice(0, 2).join(", ")}, ...` : o.join(", ")}) }`;
      } else
        return n;
    }
  return n;
}
c(qn, "objDisplay");

// node_modules/@vitest/utils/dist/helpers.js
function Ue(e, t, n) {
  let i = typeof e;
  if (!n.includes(i))
    throw new TypeError(`${t} value must be ${n.join(" or ")}, received "${i}"`);
}
c(Ue, "assertTypes");
function Tt(e) {
  return e == null && (e = []), Array.isArray(e) ? e : [e];
}
c(Tt, "toArray");
function vt(e) {
  return e != null && typeof e == "object" && !Array.isArray(e);
}
c(vt, "isObject");
function xt(e, t, n = void 0) {
  let i = t.replace(/\[(\d+)\]/g, ".$1").split("."), o = e;
  for (let s of i)
    if (o = new Object(o)[s], o === void 0)
      return n;
  return o;
}
c(xt, "objectAttr");
function St() {
  let e = null, t = null, n = new Promise((i, o) => {
    e = i, t = o;
  });
  return n.resolve = e, n.reject = t, n;
}
c(St, "createDefer");
function zn(e) {
  if (!Number.isNaN(e))
    return !1;
  let t = new Float64Array(1);
  return t[0] = e, new Uint32Array(t.buffer)[1] >>> 31 === 1;
}
c(zn, "isNegativeNaN");

// node_modules/@vitest/utils/dist/index.js
var Bn, Qi;
function jc() {
  if (Qi) return Bn;
  Qi = 1;
  var e, t, n, i, o, s, a, l, u, p, h, g, w, _, T, b, E, v, S;
  return w = /\/(?![*\/])(?:\[(?:(?![\]\\]).|\\.)*\]|(?![\/\\]).|\\.)*(\/[$_\u200C\u200D\p{ID_Continue}]*|\\)?/yu, g = /--|\+\+|=>|\.{3}|\??\.(?!\d)|(?:&&|\|\||\?\?|[+\-%&|^]|\*{1,2}|<{1,2}|>{1,3}|!=?|={1,2}|\/(?![\/*]))=?|[?~,:;[\](){}]/y, e = /(\x23?)(?=[$_\p{ID_Start}\\])(?:[$_\u200C\u200D\p{ID_Continue}]|\\u[\da-fA-F]{4}|\\u\{[\da-fA-F]+\})+/yu, T = /(['"])(?:(?!\1)[^\\\n\r]|\\(?:\r\n|[^]))*(\1)?/y, h = /(?:0[xX][\da-fA-F](?:_?[\da-fA-F])*|0[oO][0-7](?:_?[0-7])*|0[bB][01](?:_?[01])*)n?|0n|[1-9](?:_?\d)*n|(?:(?:0(?!\d)|0\d*[89]\d*|[1-9](?:_?\d)*)(?:\.(?:\d(?:_?\d)*)?)?|\.\d(?:_?\d)*)(?:[eE][+-]?\d(?:_?\d)*)?|0[0-7]+/y, b = /[`}](?:[^`\\$]|\\[^]|\$(?!\{))*(`|\$\{)?/y, S = /[\t\v\f\ufeff\p{Zs}]+/yu, l = /\r?\n|[\r\u2028\u2029]/y, u = /\/\*(?:[^*]|\*(?!\/))*(\*\/)?/y, _ = /\/\/.*/y, n = /[<>.:={}]|\/(?![\/*])/y, t = /[$_\p{ID_Start}][$_\u200C\u200D\p{ID_Continue}-]*/yu, i = /(['"])(?:(?!\1)[^])*(\1)?/y, o = /[^<>{}]+/y, v = /^(?:[\/+-]|\.{3}|\?(?:InterpolationIn(?:JSX|Template)|NoLineTerminatorHere|NonExpressionParenEnd|UnaryIncDec))?$|[{}([,;<>=*%&|^!~?:]$/, E = /^(?:=>|[;\]){}]|else|\?(?:NoLineTerminatorHere|NonExpressionParenEnd))?$/, s = /^(?:await|case|default|delete|do|else|instanceof|new|return|throw|typeof|void|yield)$/, a = /^(?:return|throw|yield)$/, p = RegExp(l.source), Bn = /* @__PURE__ */ c(function* (I, { jsx: J = !1 } = {}) {
    var K, oe, nt, P, $, ge, x, se, Qr, H, Fe, F, De, q;
    for ({ length: ge } = I, P = 0, $ = "", q = [
      { tag: "JS" }
    ], K = [], Fe = 0, F = !1; P < ge; ) {
      switch (se = q[q.length - 1], se.tag) {
        case "JS":
        case "JSNonExpressionParen":
        case "InterpolationInTemplate":
        case "InterpolationInJSX":
          if (I[P] === "/" && (v.test($) || s.test($)) && (w.lastIndex = P, x = w.exec(I))) {
            P = w.lastIndex, $ = x[0], F = !0, yield {
              type: "RegularExpressionLiteral",
              value: x[0],
              closed: x[1] !== void 0 && x[1] !== "\\"
            };
            continue;
          }
          if (g.lastIndex = P, x = g.exec(I)) {
            switch (De = x[0], Qr = g.lastIndex, H = De, De) {
              case "(":
                $ === "?NonExpressionParenKeyword" && q.push({
                  tag: "JSNonExpressionParen",
                  nesting: Fe
                }), Fe++, F = !1;
                break;
              case ")":
                Fe--, F = !0, se.tag === "JSNonExpressionParen" && Fe === se.nesting && (q.pop(), H = "?NonExpressionParenEnd", F = !1);
                break;
              case "{":
                g.lastIndex = 0, nt = !E.test($) && (v.test($) || s.test($)), K.push(nt), F = !1;
                break;
              case "}":
                switch (se.tag) {
                  case "InterpolationInTemplate":
                    if (K.length === se.nesting) {
                      b.lastIndex = P, x = b.exec(I), P = b.lastIndex, $ = x[0], x[1] === "${" ? ($ = "?InterpolationInTemplate", F = !1, yield {
                        type: "TemplateMiddle",
                        value: x[0]
                      }) : (q.pop(), F = !0, yield {
                        type: "TemplateTail",
                        value: x[0],
                        closed: x[1] === "`"
                      });
                      continue;
                    }
                    break;
                  case "InterpolationInJSX":
                    if (K.length === se.nesting) {
                      q.pop(), P += 1, $ = "}", yield {
                        type: "JSXPunctuator",
                        value: "}"
                      };
                      continue;
                    }
                }
                F = K.pop(), H = F ? "?ExpressionBraceEnd" : "}";
                break;
              case "]":
                F = !0;
                break;
              case "++":
              case "--":
                H = F ? "?PostfixIncDec" : "?UnaryIncDec";
                break;
              case "<":
                if (J && (v.test($) || s.test($))) {
                  q.push({ tag: "JSXTag" }), P += 1, $ = "<", yield {
                    type: "JSXPunctuator",
                    value: De
                  };
                  continue;
                }
                F = !1;
                break;
              default:
                F = !1;
            }
            P = Qr, $ = H, yield {
              type: "Punctuator",
              value: De
            };
            continue;
          }
          if (e.lastIndex = P, x = e.exec(I)) {
            switch (P = e.lastIndex, H = x[0], x[0]) {
              case "for":
              case "if":
              case "while":
              case "with":
                $ !== "." && $ !== "?." && (H = "?NonExpressionParenKeyword");
            }
            $ = H, F = !s.test(x[0]), yield {
              type: x[1] === "#" ? "PrivateIdentifier" : "IdentifierName",
              value: x[0]
            };
            continue;
          }
          if (T.lastIndex = P, x = T.exec(I)) {
            P = T.lastIndex, $ = x[0], F = !0, yield {
              type: "StringLiteral",
              value: x[0],
              closed: x[2] !== void 0
            };
            continue;
          }
          if (h.lastIndex = P, x = h.exec(I)) {
            P = h.lastIndex, $ = x[0], F = !0, yield {
              type: "NumericLiteral",
              value: x[0]
            };
            continue;
          }
          if (b.lastIndex = P, x = b.exec(I)) {
            P = b.lastIndex, $ = x[0], x[1] === "${" ? ($ = "?InterpolationInTemplate", q.push({
              tag: "InterpolationInTemplate",
              nesting: K.length
            }), F = !1, yield {
              type: "TemplateHead",
              value: x[0]
            }) : (F = !0, yield {
              type: "NoSubstitutionTemplate",
              value: x[0],
              closed: x[1] === "`"
            });
            continue;
          }
          break;
        case "JSXTag":
        case "JSXTagEnd":
          if (n.lastIndex = P, x = n.exec(I)) {
            switch (P = n.lastIndex, H = x[0], x[0]) {
              case "<":
                q.push({ tag: "JSXTag" });
                break;
              case ">":
                q.pop(), $ === "/" || se.tag === "JSXTagEnd" ? (H = "?JSX", F = !0) : q.push({ tag: "JSXChildren" });
                break;
              case "{":
                q.push({
                  tag: "InterpolationInJSX",
                  nesting: K.length
                }), H = "?InterpolationInJSX", F = !1;
                break;
              case "/":
                $ === "<" && (q.pop(), q[q.length - 1].tag === "JSXChildren" && q.pop(), q.push({ tag: "JSXTagEnd" }));
            }
            $ = H, yield {
              type: "JSXPunctuator",
              value: x[0]
            };
            continue;
          }
          if (t.lastIndex = P, x = t.exec(I)) {
            P = t.lastIndex, $ = x[0], yield {
              type: "JSXIdentifier",
              value: x[0]
            };
            continue;
          }
          if (i.lastIndex = P, x = i.exec(I)) {
            P = i.lastIndex, $ = x[0], yield {
              type: "JSXString",
              value: x[0],
              closed: x[2] !== void 0
            };
            continue;
          }
          break;
        case "JSXChildren":
          if (o.lastIndex = P, x = o.exec(I)) {
            P = o.lastIndex, $ = x[0], yield {
              type: "JSXText",
              value: x[0]
            };
            continue;
          }
          switch (I[P]) {
            case "<":
              q.push({ tag: "JSXTag" }), P++, $ = "<", yield {
                type: "JSXPunctuator",
                value: "<"
              };
              continue;
            case "{":
              q.push({
                tag: "InterpolationInJSX",
                nesting: K.length
              }), P++, $ = "?InterpolationInJSX", F = !1, yield {
                type: "JSXPunctuator",
                value: "{"
              };
              continue;
          }
      }
      if (S.lastIndex = P, x = S.exec(I)) {
        P = S.lastIndex, yield {
          type: "WhiteSpace",
          value: x[0]
        };
        continue;
      }
      if (l.lastIndex = P, x = l.exec(I)) {
        P = l.lastIndex, F = !1, a.test($) && ($ = "?NoLineTerminatorHere"), yield {
          type: "LineTerminatorSequence",
          value: x[0]
        };
        continue;
      }
      if (u.lastIndex = P, x = u.exec(I)) {
        P = u.lastIndex, p.test(x[0]) && (F = !1, a.test($) && ($ = "?NoLineTerminatorHere")), yield {
          type: "MultiLineComment",
          value: x[0],
          closed: x[1] !== void 0
        };
        continue;
      }
      if (_.lastIndex = P, x = _.exec(I)) {
        P = _.lastIndex, F = !1, yield {
          type: "SingleLineComment",
          value: x[0]
        };
        continue;
      }
      oe = String.fromCodePoint(I.codePointAt(P)), P += oe.length, $ = oe, F = !1, yield {
        type: se.tag.startsWith("JSX") ? "JSXInvalid" : "Invalid",
        value: oe
      };
    }
  }, "jsTokens_1"), Bn;
}
c(jc, "requireJsTokens");
var ud = jc();
var eo = {
  keyword: [
    "break",
    "case",
    "catch",
    "continue",
    "debugger",
    "default",
    "do",
    "else",
    "finally",
    "for",
    "function",
    "if",
    "return",
    "switch",
    "throw",
    "try",
    "var",
    "const",
    "while",
    "with",
    "new",
    "this",
    "super",
    "class",
    "extends",
    "export",
    "import",
    "null",
    "true",
    "false",
    "in",
    "instanceof",
    "typeof",
    "void",
    "delete"
  ],
  strict: [
    "implements",
    "interface",
    "let",
    "package",
    "private",
    "protected",
    "public",
    "static",
    "yield"
  ]
}, fd = new Set(eo.keyword), dd = new Set(eo.strict);
var Zi = Symbol("vitest:SAFE_TIMERS");
function Un() {
  let { setTimeout: e, setInterval: t, clearInterval: n, clearTimeout: i, setImmediate: o, clearImmediate: s, queueMicrotask: a } = globalThis[Zi] || globalThis, { nextTick: l } = globalThis[Zi] || globalThis.process || { nextTick: /* @__PURE__ */ c((u) => u(), "nextTick") };
  return {
    nextTick: l,
    setTimeout: e,
    setInterval: t,
    clearInterval: n,
    clearTimeout: i,
    setImmediate: o,
    clearImmediate: s,
    queueMicrotask: a
  };
}
c(Un, "getSafeTimers");

// node_modules/chai/chai.js
var uo = Object.defineProperty, kc = Object.getOwnPropertyNames, y = /* @__PURE__ */ c((e, t) => uo(e, "name", { value: t, configurable: !0 }), "__name"), Fc = /* @__PURE__ */ c((e, t) => /* @__PURE__ */ c(function() {
  return t || (0, e[kc(e)[0]])((t = { exports: {} }).exports, t), t.exports;
}, "__require"), "__commonJS"), sr = /* @__PURE__ */ c((e, t) => {
  for (var n in t)
    uo(e, n, { get: t[n], enumerable: !0 });
}, "__export"), Dc = Fc({
  "(disabled):util"() {
  }
}), It = {};
sr(It, {
  addChainableMethod: /* @__PURE__ */ c(() => br, "addChainableMethod"),
  addLengthGuard: /* @__PURE__ */ c(() => Xe, "addLengthGuard"),
  addMethod: /* @__PURE__ */ c(() => mr, "addMethod"),
  addProperty: /* @__PURE__ */ c(() => hr, "addProperty"),
  checkError: /* @__PURE__ */ c(() => G, "checkError"),
  compareByInspect: /* @__PURE__ */ c(() => $t, "compareByInspect"),
  eql: /* @__PURE__ */ c(() => Lo, "eql"),
  expectTypes: /* @__PURE__ */ c(() => _o, "expectTypes"),
  flag: /* @__PURE__ */ c(() => A, "flag"),
  getActual: /* @__PURE__ */ c(() => kt, "getActual"),
  getMessage: /* @__PURE__ */ c(() => lr, "getMessage"),
  getName: /* @__PURE__ */ c(() => Dt, "getName"),
  getOperator: /* @__PURE__ */ c(() => Tr, "getOperator"),
  getOwnEnumerableProperties: /* @__PURE__ */ c(() => Er, "getOwnEnumerableProperties"),
  getOwnEnumerablePropertySymbols: /* @__PURE__ */ c(() => wr, "getOwnEnumerablePropertySymbols"),
  getPathInfo: /* @__PURE__ */ c(() => pr, "getPathInfo"),
  hasProperty: /* @__PURE__ */ c(() => Ft, "hasProperty"),
  inspect: /* @__PURE__ */ c(() => N, "inspect"),
  isNaN: /* @__PURE__ */ c(() => Nt, "isNaN"),
  isNumeric: /* @__PURE__ */ c(() => Y, "isNumeric"),
  isProxyEnabled: /* @__PURE__ */ c(() => Ve, "isProxyEnabled"),
  isRegExp: /* @__PURE__ */ c(() => Ot, "isRegExp"),
  objDisplay: /* @__PURE__ */ c(() => ve, "objDisplay"),
  overwriteChainableMethod: /* @__PURE__ */ c(() => _r, "overwriteChainableMethod"),
  overwriteMethod: /* @__PURE__ */ c(() => yr, "overwriteMethod"),
  overwriteProperty: /* @__PURE__ */ c(() => gr, "overwriteProperty"),
  proxify: /* @__PURE__ */ c(() => Me, "proxify"),
  test: /* @__PURE__ */ c(() => ar, "test"),
  transferFlags: /* @__PURE__ */ c(() => te, "transferFlags"),
  type: /* @__PURE__ */ c(() => j, "type")
});
var G = {};
sr(G, {
  compatibleConstructor: /* @__PURE__ */ c(() => ho, "compatibleConstructor"),
  compatibleInstance: /* @__PURE__ */ c(() => po, "compatibleInstance"),
  compatibleMessage: /* @__PURE__ */ c(() => mo, "compatibleMessage"),
  getConstructorName: /* @__PURE__ */ c(() => go, "getConstructorName"),
  getMessage: /* @__PURE__ */ c(() => yo, "getMessage")
});
function jt(e) {
  return e instanceof Error || Object.prototype.toString.call(e) === "[object Error]";
}
c(jt, "isErrorInstance");
y(jt, "isErrorInstance");
function fo(e) {
  return Object.prototype.toString.call(e) === "[object RegExp]";
}
c(fo, "isRegExp");
y(fo, "isRegExp");
function po(e, t) {
  return jt(t) && e === t;
}
c(po, "compatibleInstance");
y(po, "compatibleInstance");
function ho(e, t) {
  return jt(t) ? e.constructor === t.constructor || e instanceof t.constructor : (typeof t == "object" || typeof t == "function") && t.prototype ? e.constructor === t || e instanceof t : !1;
}
c(ho, "compatibleConstructor");
y(ho, "compatibleConstructor");
function mo(e, t) {
  let n = typeof e == "string" ? e : e.message;
  return fo(t) ? t.test(n) : typeof t == "string" ? n.indexOf(t) !== -1 : !1;
}
c(mo, "compatibleMessage");
y(mo, "compatibleMessage");
function go(e) {
  let t = e;
  return jt(e) ? t = e.constructor.name : typeof e == "function" && (t = e.name, t === "" && (t = new e().name || t)), t;
}
c(go, "getConstructorName");
y(go, "getConstructorName");
function yo(e) {
  let t = "";
  return e && e.message ? t = e.message : typeof e == "string" && (t = e), t;
}
c(yo, "getMessage");
y(yo, "getMessage");
function A(e, t, n) {
  var i = e.__flags || (e.__flags = /* @__PURE__ */ Object.create(null));
  if (arguments.length === 3)
    i[t] = n;
  else
    return i[t];
}
c(A, "flag");
y(A, "flag");
function ar(e, t) {
  var n = A(e, "negate"), i = t[0];
  return n ? !i : i;
}
c(ar, "test");
y(ar, "test");
function j(e) {
  if (typeof e > "u")
    return "undefined";
  if (e === null)
    return "null";
  let t = e[Symbol.toStringTag];
  return typeof t == "string" ? t : Object.prototype.toString.call(e).slice(8, -1);
}
c(j, "type");
y(j, "type");
var Lc = "captureStackTrace" in Error, O = class bo extends Error {
  static {
    c(this, "_AssertionError");
  }
  static {
    y(this, "AssertionError");
  }
  message;
  get name() {
    return "AssertionError";
  }
  get ok() {
    return !1;
  }
  constructor(t = "Unspecified AssertionError", n, i) {
    super(t), this.message = t, Lc && Error.captureStackTrace(this, i || bo);
    for (let o in n)
      o in this || (this[o] = n[o]);
  }
  toJSON(t) {
    return {
      ...this,
      name: this.name,
      message: this.message,
      ok: !1,
      stack: t !== !1 ? this.stack : void 0
    };
  }
};
function _o(e, t) {
  var n = A(e, "message"), i = A(e, "ssfi");
  n = n ? n + ": " : "", e = A(e, "object"), t = t.map(function(a) {
    return a.toLowerCase();
  }), t.sort();
  var o = t.map(function(a, l) {
    var u = ~["a", "e", "i", "o", "u"].indexOf(a.charAt(0)) ? "an" : "a", p = t.length > 1 && l === t.length - 1 ? "or " : "";
    return p + u + " " + a;
  }).join(", "), s = j(e).toLowerCase();
  if (!t.some(function(a) {
    return s === a;
  }))
    throw new O(
      n + "object tested must be " + o + ", but " + s + " given",
      void 0,
      i
    );
}
c(_o, "expectTypes");
y(_o, "expectTypes");
function kt(e, t) {
  return t.length > 4 ? t[4] : e._obj;
}
c(kt, "getActual");
y(kt, "getActual");
var to = {
  bold: ["1", "22"],
  dim: ["2", "22"],
  italic: ["3", "23"],
  underline: ["4", "24"],
  // 5 & 6 are blinking
  inverse: ["7", "27"],
  hidden: ["8", "28"],
  strike: ["9", "29"],
  // 10-20 are fonts
  // 21-29 are resets for 1-9
  black: ["30", "39"],
  red: ["31", "39"],
  green: ["32", "39"],
  yellow: ["33", "39"],
  blue: ["34", "39"],
  magenta: ["35", "39"],
  cyan: ["36", "39"],
  white: ["37", "39"],
  brightblack: ["30;1", "39"],
  brightred: ["31;1", "39"],
  brightgreen: ["32;1", "39"],
  brightyellow: ["33;1", "39"],
  brightblue: ["34;1", "39"],
  brightmagenta: ["35;1", "39"],
  brightcyan: ["36;1", "39"],
  brightwhite: ["37;1", "39"],
  grey: ["90", "39"]
}, qc = {
  special: "cyan",
  number: "yellow",
  bigint: "yellow",
  boolean: "yellow",
  undefined: "grey",
  null: "bold",
  string: "green",
  symbol: "green",
  date: "magenta",
  regexp: "red"
}, Oe = "\u2026";
function wo(e, t) {
  let n = to[qc[t]] || to[t] || "";
  return n ? `\x1B[${n[0]}m${String(e)}\x1B[${n[1]}m` : String(e);
}
c(wo, "colorise");
y(wo, "colorise");
function Eo({
  showHidden: e = !1,
  depth: t = 2,
  colors: n = !1,
  customInspect: i = !0,
  showProxy: o = !1,
  maxArrayLength: s = 1 / 0,
  breakLength: a = 1 / 0,
  seen: l = [],
  // eslint-disable-next-line no-shadow
  truncate: u = 1 / 0,
  stylize: p = String
} = {}, h) {
  let g = {
    showHidden: !!e,
    depth: Number(t),
    colors: !!n,
    customInspect: !!i,
    showProxy: !!o,
    maxArrayLength: Number(s),
    breakLength: Number(a),
    truncate: Number(u),
    seen: l,
    inspect: h,
    stylize: p
  };
  return g.colors && (g.stylize = wo), g;
}
c(Eo, "normaliseOptions");
y(Eo, "normaliseOptions");
function To(e) {
  return e >= "\uD800" && e <= "\uDBFF";
}
c(To, "isHighSurrogate");
y(To, "isHighSurrogate");
function ue(e, t, n = Oe) {
  e = String(e);
  let i = n.length, o = e.length;
  if (i > t && o > i)
    return n;
  if (o > t && o > i) {
    let s = t - i;
    return s > 0 && To(e[s - 1]) && (s = s - 1), `${e.slice(0, s)}${n}`;
  }
  return e;
}
c(ue, "truncate");
y(ue, "truncate");
function Q(e, t, n, i = ", ") {
  n = n || t.inspect;
  let o = e.length;
  if (o === 0)
    return "";
  let s = t.truncate, a = "", l = "", u = "";
  for (let p = 0; p < o; p += 1) {
    let h = p + 1 === e.length, g = p + 2 === e.length;
    u = `${Oe}(${e.length - p})`;
    let w = e[p];
    t.truncate = s - a.length - (h ? 0 : i.length);
    let _ = l || n(w, t) + (h ? "" : i), T = a.length + _.length, b = T + u.length;
    if (h && T > s && a.length + u.length <= s || !h && !g && b > s || (l = h ? "" : n(e[p + 1], t) + (g ? "" : i), !h && g && b > s && T + l.length > s))
      break;
    if (a += _, !h && !g && T + l.length >= s) {
      u = `${Oe}(${e.length - p - 1})`;
      break;
    }
    u = "";
  }
  return `${a}${u}`;
}
c(Q, "inspectList");
y(Q, "inspectList");
function vo(e) {
  return e.match(/^[a-zA-Z_][a-zA-Z_0-9]*$/) ? e : JSON.stringify(e).replace(/'/g, "\\'").replace(/\\"/g, '"').replace(/(^"|"$)/g, "'");
}
c(vo, "quoteComplexKey");
y(vo, "quoteComplexKey");
function Re([e, t], n) {
  return n.truncate -= 2, typeof e == "string" ? e = vo(e) : typeof e != "number" && (e = `[${n.inspect(e, n)}]`), n.truncate -= e.length, t = n.inspect(t, n), `${e}: ${t}`;
}
c(Re, "inspectProperty");
y(Re, "inspectProperty");
function xo(e, t) {
  let n = Object.keys(e).slice(e.length);
  if (!e.length && !n.length)
    return "[]";
  t.truncate -= 4;
  let i = Q(e, t);
  t.truncate -= i.length;
  let o = "";
  return n.length && (o = Q(n.map((s) => [s, e[s]]), t, Re)), `[ ${i}${o ? `, ${o}` : ""} ]`;
}
c(xo, "inspectArray");
y(xo, "inspectArray");
var zc = /* @__PURE__ */ y((e) => typeof Buffer == "function" && e instanceof Buffer ? "Buffer" : e[Symbol.toStringTag] ? e[Symbol.toStringTag] : e.constructor.name, "getArrayName");
function re(e, t) {
  let n = zc(e);
  t.truncate -= n.length + 4;
  let i = Object.keys(e).slice(e.length);
  if (!e.length && !i.length)
    return `${n}[]`;
  let o = "";
  for (let a = 0; a < e.length; a++) {
    let l = `${t.stylize(ue(e[a], t.truncate), "number")}${a === e.length - 1 ? "" : ", "}`;
    if (t.truncate -= l.length, e[a] !== e.length && t.truncate <= 3) {
      o += `${Oe}(${e.length - e[a] + 1})`;
      break;
    }
    o += l;
  }
  let s = "";
  return i.length && (s = Q(i.map((a) => [a, e[a]]), t, Re)), `${n}[ ${o}${s ? `, ${s}` : ""} ]`;
}
c(re, "inspectTypedArray");
y(re, "inspectTypedArray");
function So(e, t) {
  let n = e.toJSON();
  if (n === null)
    return "Invalid Date";
  let i = n.split("T"), o = i[0];
  return t.stylize(`${o}T${ue(i[1], t.truncate - o.length - 1)}`, "date");
}
c(So, "inspectDate");
y(So, "inspectDate");
function Wn(e, t) {
  let n = e[Symbol.toStringTag] || "Function", i = e.name;
  return i ? t.stylize(`[${n} ${ue(i, t.truncate - 11)}]`, "special") : t.stylize(`[${n}]`, "special");
}
c(Wn, "inspectFunction");
y(Wn, "inspectFunction");
function Io([e, t], n) {
  return n.truncate -= 4, e = n.inspect(e, n), n.truncate -= e.length, t = n.inspect(t, n), `${e} => ${t}`;
}
c(Io, "inspectMapEntry");
y(Io, "inspectMapEntry");
function Po(e) {
  let t = [];
  return e.forEach((n, i) => {
    t.push([i, n]);
  }), t;
}
c(Po, "mapToEntries");
y(Po, "mapToEntries");
function Ao(e, t) {
  return e.size - 1 <= 0 ? "Map{}" : (t.truncate -= 7, `Map{ ${Q(Po(e), t, Io)} }`);
}
c(Ao, "inspectMap");
y(Ao, "inspectMap");
var Bc = Number.isNaN || ((e) => e !== e);
function Vn(e, t) {
  return Bc(e) ? t.stylize("NaN", "number") : e === 1 / 0 ? t.stylize("Infinity", "number") : e === -1 / 0 ? t.stylize("-Infinity", "number") : e === 0 ? t.stylize(1 / e === 1 / 0 ? "+0" : "-0", "number") : t.stylize(ue(String(e), t.truncate), "number");
}
c(Vn, "inspectNumber");
y(Vn, "inspectNumber");
function Xn(e, t) {
  let n = ue(e.toString(), t.truncate - 1);
  return n !== Oe && (n += "n"), t.stylize(n, "bigint");
}
c(Xn, "inspectBigInt");
y(Xn, "inspectBigInt");
function Co(e, t) {
  let n = e.toString().split("/")[2], i = t.truncate - (2 + n.length), o = e.source;
  return t.stylize(`/${ue(o, i)}/${n}`, "regexp");
}
c(Co, "inspectRegExp");
y(Co, "inspectRegExp");
function $o(e) {
  let t = [];
  return e.forEach((n) => {
    t.push(n);
  }), t;
}
c($o, "arrayFromSet");
y($o, "arrayFromSet");
function No(e, t) {
  return e.size === 0 ? "Set{}" : (t.truncate -= 7, `Set{ ${Q($o(e), t)} }`);
}
c(No, "inspectSet");
y(No, "inspectSet");
var no = new RegExp("['\\u0000-\\u001f\\u007f-\\u009f\\u00ad\\u0600-\\u0604\\u070f\\u17b4\\u17b5\\u200c-\\u200f\\u2028-\\u202f\\u2060-\\u206f\\ufeff\\ufff0-\\uffff]", "g"), Uc = {
  "\b": "\\b",
  "	": "\\t",
  "\n": "\\n",
  "\f": "\\f",
  "\r": "\\r",
  "'": "\\'",
  "\\": "\\\\"
}, Yc = 16, Jc = 4;
function Oo(e) {
  return Uc[e] || `\\u${`0000${e.charCodeAt(0).toString(Yc)}`.slice(-Jc)}`;
}
c(Oo, "escape");
y(Oo, "escape");
function Kn(e, t) {
  return no.test(e) && (e = e.replace(no, Oo)), t.stylize(`'${ue(e, t.truncate - 2)}'`, "string");
}
c(Kn, "inspectString");
y(Kn, "inspectString");
function Gn(e) {
  return "description" in Symbol.prototype ? e.description ? `Symbol(${e.description})` : "Symbol()" : e.toString();
}
c(Gn, "inspectSymbol");
y(Gn, "inspectSymbol");
var Ro = /* @__PURE__ */ y(() => "Promise{\u2026}", "getPromiseValue");
try {
  let { getPromiseDetails: e, kPending: t, kRejected: n } = process.binding("util");
  Array.isArray(e(Promise.resolve())) && (Ro = /* @__PURE__ */ y((i, o) => {
    let [s, a] = e(i);
    return s === t ? "Promise{<pending>}" : `Promise${s === n ? "!" : ""}{${o.inspect(a, o)}}`;
  }, "getPromiseValue"));
} catch {
}
var Wc = Ro;
function Je(e, t) {
  let n = Object.getOwnPropertyNames(e), i = Object.getOwnPropertySymbols ? Object.getOwnPropertySymbols(e) : [];
  if (n.length === 0 && i.length === 0)
    return "{}";
  if (t.truncate -= 4, t.seen = t.seen || [], t.seen.includes(e))
    return "[Circular]";
  t.seen.push(e);
  let o = Q(n.map((l) => [l, e[l]]), t, Re), s = Q(i.map((l) => [l, e[l]]), t, Re);
  t.seen.pop();
  let a = "";
  return o && s && (a = ", "), `{ ${o}${a}${s} }`;
}
c(Je, "inspectObject");
y(Je, "inspectObject");
var Yn = typeof Symbol < "u" && Symbol.toStringTag ? Symbol.toStringTag : !1;
function Mo(e, t) {
  let n = "";
  return Yn && Yn in e && (n = e[Yn]), n = n || e.constructor.name, (!n || n === "_class") && (n = "<Anonymous Class>"), t.truncate -= n.length, `${n}${Je(e, t)}`;
}
c(Mo, "inspectClass");
y(Mo, "inspectClass");
function jo(e, t) {
  return e.length === 0 ? "Arguments[]" : (t.truncate -= 13, `Arguments[ ${Q(e, t)} ]`);
}
c(jo, "inspectArguments");
y(jo, "inspectArguments");
var Vc = [
  "stack",
  "line",
  "column",
  "name",
  "message",
  "fileName",
  "lineNumber",
  "columnNumber",
  "number",
  "description",
  "cause"
];
function ko(e, t) {
  let n = Object.getOwnPropertyNames(e).filter((a) => Vc.indexOf(a) === -1), i = e.name;
  t.truncate -= i.length;
  let o = "";
  if (typeof e.message == "string" ? o = ue(e.message, t.truncate) : n.unshift("message"), o = o ? `: ${o}` : "", t.truncate -= o.length + 5, t.seen = t.seen || [], t.seen.includes(e))
    return "[Circular]";
  t.seen.push(e);
  let s = Q(n.map((a) => [a, e[a]]), t, Re);
  return `${i}${o}${s ? ` { ${s} }` : ""}`;
}
c(ko, "inspectObject2");
y(ko, "inspectObject");
function Fo([e, t], n) {
  return n.truncate -= 3, t ? `${n.stylize(String(e), "yellow")}=${n.stylize(`"${t}"`, "string")}` : `${n.stylize(String(e), "yellow")}`;
}
c(Fo, "inspectAttribute");
y(Fo, "inspectAttribute");
function Pt(e, t) {
  return Q(e, t, cr, `
`);
}
c(Pt, "inspectHTMLCollection");
y(Pt, "inspectHTMLCollection");
function cr(e, t) {
  let n = e.getAttributeNames(), i = e.tagName.toLowerCase(), o = t.stylize(`<${i}`, "special"), s = t.stylize(">", "special"), a = t.stylize(`</${i}>`, "special");
  t.truncate -= i.length * 2 + 5;
  let l = "";
  n.length > 0 && (l += " ", l += Q(n.map((h) => [h, e.getAttribute(h)]), t, Fo, " ")), t.truncate -= l.length;
  let u = t.truncate, p = Pt(e.children, t);
  return p && p.length > u && (p = `${Oe}(${e.children.length})`), `${o}${l}${s}${p}${a}`;
}
c(cr, "inspectHTML");
y(cr, "inspectHTML");
var Xc = typeof Symbol == "function" && typeof Symbol.for == "function", Jn = Xc ? Symbol.for("chai/inspect") : "@@chai/inspect", Ne = !1;
try {
  let e = Dc();
  Ne = e.inspect ? e.inspect.custom : !1;
} catch {
  Ne = !1;
}
var ro = /* @__PURE__ */ new WeakMap(), io = {}, oo = {
  undefined: /* @__PURE__ */ c((e, t) => t.stylize("undefined", "undefined"), "undefined"),
  null: /* @__PURE__ */ c((e, t) => t.stylize("null", "null"), "null"),
  boolean: /* @__PURE__ */ c((e, t) => t.stylize(String(e), "boolean"), "boolean"),
  Boolean: /* @__PURE__ */ c((e, t) => t.stylize(String(e), "boolean"), "Boolean"),
  number: Vn,
  Number: Vn,
  bigint: Xn,
  BigInt: Xn,
  string: Kn,
  String: Kn,
  function: Wn,
  Function: Wn,
  symbol: Gn,
  // A Symbol polyfill will return `Symbol` not `symbol` from typedetect
  Symbol: Gn,
  Array: xo,
  Date: So,
  Map: Ao,
  Set: No,
  RegExp: Co,
  Promise: Wc,
  // WeakSet, WeakMap are totally opaque to us
  WeakSet: /* @__PURE__ */ c((e, t) => t.stylize("WeakSet{\u2026}", "special"), "WeakSet"),
  WeakMap: /* @__PURE__ */ c((e, t) => t.stylize("WeakMap{\u2026}", "special"), "WeakMap"),
  Arguments: jo,
  Int8Array: re,
  Uint8Array: re,
  Uint8ClampedArray: re,
  Int16Array: re,
  Uint16Array: re,
  Int32Array: re,
  Uint32Array: re,
  Float32Array: re,
  Float64Array: re,
  Generator: /* @__PURE__ */ c(() => "", "Generator"),
  DataView: /* @__PURE__ */ c(() => "", "DataView"),
  ArrayBuffer: /* @__PURE__ */ c(() => "", "ArrayBuffer"),
  Error: ko,
  HTMLCollection: Pt,
  NodeList: Pt
}, Kc = /* @__PURE__ */ y((e, t, n) => Jn in e && typeof e[Jn] == "function" ? e[Jn](t) : Ne && Ne in e && typeof e[Ne] == "function" ? e[Ne](t.depth, t) : "inspect" in e && typeof e.inspect == "function" ? e.inspect(t.depth, t) : "constructor" in e && ro.has(e.constructor) ? ro.get(e.constructor)(e, t) : io[n] ? io[n](e, t) : "", "inspectCustom"), Gc = Object.prototype.toString;
function At(e, t = {}) {
  let n = Eo(t, At), { customInspect: i } = n, o = e === null ? "null" : typeof e;
  if (o === "object" && (o = Gc.call(e).slice(8, -1)), o in oo)
    return oo[o](e, n);
  if (i && e) {
    let a = Kc(e, n, o);
    if (a)
      return typeof a == "string" ? a : At(a, n);
  }
  let s = e ? Object.getPrototypeOf(e) : !1;
  return s === Object.prototype || s === null ? Je(e, n) : e && typeof HTMLElement == "function" && e instanceof HTMLElement ? cr(e, n) : "constructor" in e ? e.constructor !== Object ? Mo(e, n) : Je(e, n) : e === Object(e) ? Je(e, n) : n.stylize(String(e), o);
}
c(At, "inspect");
y(At, "inspect");
var X = {
  /**
   * ### config.includeStack
   *
   * User configurable property, influences whether stack trace
   * is included in Assertion error message. Default of false
   * suppresses stack trace in the error message.
   *
   *     chai.config.includeStack = true;  // enable stack on error
   *
   * @param {boolean}
   * @public
   */
  includeStack: !1,
  /**
   * ### config.showDiff
   *
   * User configurable property, influences whether or not
   * the `showDiff` flag should be included in the thrown
   * AssertionErrors. `false` will always be `false`; `true`
   * will be true when the assertion has requested a diff
   * be shown.
   *
   * @param {boolean}
   * @public
   */
  showDiff: !0,
  /**
   * ### config.truncateThreshold
   *
   * User configurable property, sets length threshold for actual and
   * expected values in assertion errors. If this threshold is exceeded, for
   * example for large data structures, the value is replaced with something
   * like `[ Array(3) ]` or `{ Object (prop1, prop2) }`.
   *
   * Set it to zero if you want to disable truncating altogether.
   *
   * This is especially userful when doing assertions on arrays: having this
   * set to a reasonable large value makes the failure messages readily
   * inspectable.
   *
   *     chai.config.truncateThreshold = 0;  // disable truncating
   *
   * @param {number}
   * @public
   */
  truncateThreshold: 40,
  /**
   * ### config.useProxy
   *
   * User configurable property, defines if chai will use a Proxy to throw
   * an error when a non-existent property is read, which protects users
   * from typos when using property-based assertions.
   *
   * Set it to false if you want to disable this feature.
   *
   *     chai.config.useProxy = false;  // disable use of Proxy
   *
   * This feature is automatically disabled regardless of this config value
   * in environments that don't support proxies.
   *
   * @param {boolean}
   * @public
   */
  useProxy: !0,
  /**
   * ### config.proxyExcludedKeys
   *
   * User configurable property, defines which properties should be ignored
   * instead of throwing an error if they do not exist on the assertion.
   * This is only applied if the environment Chai is running in supports proxies and
   * if the `useProxy` configuration setting is enabled.
   * By default, `then` and `inspect` will not throw an error if they do not exist on the
   * assertion object because the `.inspect` property is read by `util.inspect` (for example, when
   * using `console.log` on the assertion object) and `.then` is necessary for promise type-checking.
   *
   *     // By default these keys will not throw an error if they do not exist on the assertion object
   *     chai.config.proxyExcludedKeys = ['then', 'inspect'];
   *
   * @param {Array}
   * @public
   */
  proxyExcludedKeys: ["then", "catch", "inspect", "toJSON"],
  /**
   * ### config.deepEqual
   *
   * User configurable property, defines which a custom function to use for deepEqual
   * comparisons.
   * By default, the function used is the one from the `deep-eql` package without custom comparator.
   *
   *     // use a custom comparator
   *     chai.config.deepEqual = (expected, actual) => {
   *         return chai.util.eql(expected, actual, {
   *             comparator: (expected, actual) => {
   *                 // for non number comparison, use the default behavior
   *                 if(typeof expected !== 'number') return null;
   *                 // allow a difference of 10 between compared numbers
   *                 return typeof actual === 'number' && Math.abs(actual - expected) < 10
   *             }
   *         })
   *     };
   *
   * @param {Function}
   * @public
   */
  deepEqual: null
};
function N(e, t, n, i) {
  var o = {
    colors: i,
    depth: typeof n > "u" ? 2 : n,
    showHidden: t,
    truncate: X.truncateThreshold ? X.truncateThreshold : 1 / 0
  };
  return At(e, o);
}
c(N, "inspect2");
y(N, "inspect");
function ve(e) {
  var t = N(e), n = Object.prototype.toString.call(e);
  if (X.truncateThreshold && t.length >= X.truncateThreshold) {
    if (n === "[object Function]")
      return !e.name || e.name === "" ? "[Function]" : "[Function: " + e.name + "]";
    if (n === "[object Array]")
      return "[ Array(" + e.length + ") ]";
    if (n === "[object Object]") {
      var i = Object.keys(e), o = i.length > 2 ? i.splice(0, 2).join(", ") + ", ..." : i.join(", ");
      return "{ Object (" + o + ") }";
    } else
      return t;
  } else
    return t;
}
c(ve, "objDisplay");
y(ve, "objDisplay");
function lr(e, t) {
  var n = A(e, "negate"), i = A(e, "object"), o = t[3], s = kt(e, t), a = n ? t[2] : t[1], l = A(e, "message");
  return typeof a == "function" && (a = a()), a = a || "", a = a.replace(/#\{this\}/g, function() {
    return ve(i);
  }).replace(/#\{act\}/g, function() {
    return ve(s);
  }).replace(/#\{exp\}/g, function() {
    return ve(o);
  }), l ? l + ": " + a : a;
}
c(lr, "getMessage2");
y(lr, "getMessage");
function te(e, t, n) {
  var i = e.__flags || (e.__flags = /* @__PURE__ */ Object.create(null));
  t.__flags || (t.__flags = /* @__PURE__ */ Object.create(null)), n = arguments.length === 3 ? n : !0;
  for (var o in i)
    (n || o !== "object" && o !== "ssfi" && o !== "lockSsfi" && o != "message") && (t.__flags[o] = i[o]);
}
c(te, "transferFlags");
y(te, "transferFlags");
function Hn(e) {
  if (typeof e > "u")
    return "undefined";
  if (e === null)
    return "null";
  let t = e[Symbol.toStringTag];
  return typeof t == "string" ? t : Object.prototype.toString.call(e).slice(8, -1);
}
c(Hn, "type2");
y(Hn, "type");
function ur() {
  this._key = "chai/deep-eql__" + Math.random() + Date.now();
}
c(ur, "FakeMap");
y(ur, "FakeMap");
ur.prototype = {
  get: /* @__PURE__ */ y(/* @__PURE__ */ c(function(t) {
    return t[this._key];
  }, "get"), "get"),
  set: /* @__PURE__ */ y(/* @__PURE__ */ c(function(t, n) {
    Object.isExtensible(t) && Object.defineProperty(t, this._key, {
      value: n,
      configurable: !0
    });
  }, "set"), "set")
};
var Do = typeof WeakMap == "function" ? WeakMap : ur;
function Qn(e, t, n) {
  if (!n || xe(e) || xe(t))
    return null;
  var i = n.get(e);
  if (i) {
    var o = i.get(t);
    if (typeof o == "boolean")
      return o;
  }
  return null;
}
c(Qn, "memoizeCompare");
y(Qn, "memoizeCompare");
function Ye(e, t, n, i) {
  if (!(!n || xe(e) || xe(t))) {
    var o = n.get(e);
    o ? o.set(t, i) : (o = new Do(), o.set(t, i), n.set(e, o));
  }
}
c(Ye, "memoizeSet");
y(Ye, "memoizeSet");
var Lo = We;
function We(e, t, n) {
  if (n && n.comparator)
    return Zn(e, t, n);
  var i = fr(e, t);
  return i !== null ? i : Zn(e, t, n);
}
c(We, "deepEqual");
y(We, "deepEqual");
function fr(e, t) {
  return e === t ? e !== 0 || 1 / e === 1 / t : e !== e && // eslint-disable-line no-self-compare
  t !== t ? !0 : xe(e) || xe(t) ? !1 : null;
}
c(fr, "simpleEqual");
y(fr, "simpleEqual");
function Zn(e, t, n) {
  n = n || {}, n.memoize = n.memoize === !1 ? !1 : n.memoize || new Do();
  var i = n && n.comparator, o = Qn(e, t, n.memoize);
  if (o !== null)
    return o;
  var s = Qn(t, e, n.memoize);
  if (s !== null)
    return s;
  if (i) {
    var a = i(e, t);
    if (a === !1 || a === !0)
      return Ye(e, t, n.memoize, a), a;
    var l = fr(e, t);
    if (l !== null)
      return l;
  }
  var u = Hn(e);
  if (u !== Hn(t))
    return Ye(e, t, n.memoize, !1), !1;
  Ye(e, t, n.memoize, !0);
  var p = qo(e, t, u, n);
  return Ye(e, t, n.memoize, p), p;
}
c(Zn, "extensiveDeepEqual");
y(Zn, "extensiveDeepEqual");
function qo(e, t, n, i) {
  switch (n) {
    case "String":
    case "Number":
    case "Boolean":
    case "Date":
      return We(e.valueOf(), t.valueOf());
    case "Promise":
    case "Symbol":
    case "function":
    case "WeakMap":
    case "WeakSet":
      return e === t;
    case "Error":
      return dr(e, t, ["name", "message", "code"], i);
    case "Arguments":
    case "Int8Array":
    case "Uint8Array":
    case "Uint8ClampedArray":
    case "Int16Array":
    case "Uint16Array":
    case "Int32Array":
    case "Uint32Array":
    case "Float32Array":
    case "Float64Array":
    case "Array":
      return pe(e, t, i);
    case "RegExp":
      return zo(e, t);
    case "Generator":
      return Bo(e, t, i);
    case "DataView":
      return pe(new Uint8Array(e.buffer), new Uint8Array(t.buffer), i);
    case "ArrayBuffer":
      return pe(new Uint8Array(e), new Uint8Array(t), i);
    case "Set":
      return er(e, t, i);
    case "Map":
      return er(e, t, i);
    case "Temporal.PlainDate":
    case "Temporal.PlainTime":
    case "Temporal.PlainDateTime":
    case "Temporal.Instant":
    case "Temporal.ZonedDateTime":
    case "Temporal.PlainYearMonth":
    case "Temporal.PlainMonthDay":
      return e.equals(t);
    case "Temporal.Duration":
      return e.total("nanoseconds") === t.total("nanoseconds");
    case "Temporal.TimeZone":
    case "Temporal.Calendar":
      return e.toString() === t.toString();
    default:
      return Yo(e, t, i);
  }
}
c(qo, "extensiveDeepEqualByType");
y(qo, "extensiveDeepEqualByType");
function zo(e, t) {
  return e.toString() === t.toString();
}
c(zo, "regexpEqual");
y(zo, "regexpEqual");
function er(e, t, n) {
  try {
    if (e.size !== t.size)
      return !1;
    if (e.size === 0)
      return !0;
  } catch {
    return !1;
  }
  var i = [], o = [];
  return e.forEach(/* @__PURE__ */ y(/* @__PURE__ */ c(function(a, l) {
    i.push([a, l]);
  }, "gatherEntries"), "gatherEntries")), t.forEach(/* @__PURE__ */ y(/* @__PURE__ */ c(function(a, l) {
    o.push([a, l]);
  }, "gatherEntries"), "gatherEntries")), pe(i.sort(), o.sort(), n);
}
c(er, "entriesEqual");
y(er, "entriesEqual");
function pe(e, t, n) {
  var i = e.length;
  if (i !== t.length)
    return !1;
  if (i === 0)
    return !0;
  for (var o = -1; ++o < i; )
    if (We(e[o], t[o], n) === !1)
      return !1;
  return !0;
}
c(pe, "iterableEqual");
y(pe, "iterableEqual");
function Bo(e, t, n) {
  return pe(Ct(e), Ct(t), n);
}
c(Bo, "generatorEqual");
y(Bo, "generatorEqual");
function Uo(e) {
  return typeof Symbol < "u" && typeof e == "object" && typeof Symbol.iterator < "u" && typeof e[Symbol.iterator] == "function";
}
c(Uo, "hasIteratorFunction");
y(Uo, "hasIteratorFunction");
function tr(e) {
  if (Uo(e))
    try {
      return Ct(e[Symbol.iterator]());
    } catch {
      return [];
    }
  return [];
}
c(tr, "getIteratorEntries");
y(tr, "getIteratorEntries");
function Ct(e) {
  for (var t = e.next(), n = [t.value]; t.done === !1; )
    t = e.next(), n.push(t.value);
  return n;
}
c(Ct, "getGeneratorEntries");
y(Ct, "getGeneratorEntries");
function nr(e) {
  var t = [];
  for (var n in e)
    t.push(n);
  return t;
}
c(nr, "getEnumerableKeys");
y(nr, "getEnumerableKeys");
function rr(e) {
  for (var t = [], n = Object.getOwnPropertySymbols(e), i = 0; i < n.length; i += 1) {
    var o = n[i];
    Object.getOwnPropertyDescriptor(e, o).enumerable && t.push(o);
  }
  return t;
}
c(rr, "getEnumerableSymbols");
y(rr, "getEnumerableSymbols");
function dr(e, t, n, i) {
  var o = n.length;
  if (o === 0)
    return !0;
  for (var s = 0; s < o; s += 1)
    if (We(e[n[s]], t[n[s]], i) === !1)
      return !1;
  return !0;
}
c(dr, "keysEqual");
y(dr, "keysEqual");
function Yo(e, t, n) {
  var i = nr(e), o = nr(t), s = rr(e), a = rr(t);
  if (i = i.concat(s), o = o.concat(a), i.length && i.length === o.length)
    return pe(ir(i).sort(), ir(o).sort()) === !1 ? !1 : dr(e, t, i, n);
  var l = tr(e), u = tr(t);
  return l.length && l.length === u.length ? (l.sort(), u.sort(), pe(l, u, n)) : i.length === 0 && l.length === 0 && o.length === 0 && u.length === 0;
}
c(Yo, "objectEqual");
y(Yo, "objectEqual");
function xe(e) {
  return e === null || typeof e != "object";
}
c(xe, "isPrimitive");
y(xe, "isPrimitive");
function ir(e) {
  return e.map(/* @__PURE__ */ y(/* @__PURE__ */ c(function(n) {
    return typeof n == "symbol" ? n.toString() : n;
  }, "mapSymbol"), "mapSymbol"));
}
c(ir, "mapSymbols");
y(ir, "mapSymbols");
function Ft(e, t) {
  return typeof e > "u" || e === null ? !1 : t in Object(e);
}
c(Ft, "hasProperty");
y(Ft, "hasProperty");
function Jo(e) {
  return e.replace(/([^\\])\[/g, "$1.[").match(/(\\\.|[^.]+?)+/g).map((i) => {
    if (i === "constructor" || i === "__proto__" || i === "prototype")
      return {};
    let s = /^\[(\d+)\]$/.exec(i), a = null;
    return s ? a = { i: parseFloat(s[1]) } : a = { p: i.replace(/\\([.[\]])/g, "$1") }, a;
  });
}
c(Jo, "parsePath");
y(Jo, "parsePath");
function or(e, t, n) {
  let i = e, o = null;
  n = typeof n > "u" ? t.length : n;
  for (let s = 0; s < n; s++) {
    let a = t[s];
    i && (typeof a.p > "u" ? i = i[a.i] : i = i[a.p], s === n - 1 && (o = i));
  }
  return o;
}
c(or, "internalGetPathValue");
y(or, "internalGetPathValue");
function pr(e, t) {
  let n = Jo(t), i = n[n.length - 1], o = {
    parent: n.length > 1 ? or(e, n, n.length - 1) : e,
    name: i.p || i.i,
    value: or(e, n)
  };
  return o.exists = Ft(o.parent, o.name), o;
}
c(pr, "getPathInfo");
y(pr, "getPathInfo");
function d(e, t, n, i) {
  return A(this, "ssfi", n || d), A(this, "lockSsfi", i), A(this, "object", e), A(this, "message", t), A(this, "eql", X.deepEqual || Lo), Me(this);
}
c(d, "Assertion");
y(d, "Assertion");
Object.defineProperty(d, "includeStack", {
  get: /* @__PURE__ */ c(function() {
    return console.warn(
      "Assertion.includeStack is deprecated, use chai.config.includeStack instead."
    ), X.includeStack;
  }, "get"),
  set: /* @__PURE__ */ c(function(e) {
    console.warn(
      "Assertion.includeStack is deprecated, use chai.config.includeStack instead."
    ), X.includeStack = e;
  }, "set")
});
Object.defineProperty(d, "showDiff", {
  get: /* @__PURE__ */ c(function() {
    return console.warn(
      "Assertion.showDiff is deprecated, use chai.config.showDiff instead."
    ), X.showDiff;
  }, "get"),
  set: /* @__PURE__ */ c(function(e) {
    console.warn(
      "Assertion.showDiff is deprecated, use chai.config.showDiff instead."
    ), X.showDiff = e;
  }, "set")
});
d.addProperty = function(e, t) {
  hr(this.prototype, e, t);
};
d.addMethod = function(e, t) {
  mr(this.prototype, e, t);
};
d.addChainableMethod = function(e, t, n) {
  br(this.prototype, e, t, n);
};
d.overwriteProperty = function(e, t) {
  gr(this.prototype, e, t);
};
d.overwriteMethod = function(e, t) {
  yr(this.prototype, e, t);
};
d.overwriteChainableMethod = function(e, t, n) {
  _r(this.prototype, e, t, n);
};
d.prototype.assert = function(e, t, n, i, o, s) {
  var a = ar(this, arguments);
  if (s !== !1 && (s = !0), i === void 0 && o === void 0 && (s = !1), X.showDiff !== !0 && (s = !1), !a) {
    t = lr(this, arguments);
    var l = kt(this, arguments), u = {
      actual: l,
      expected: i,
      showDiff: s
    }, p = Tr(this, arguments);
    throw p && (u.operator = p), new O(
      t,
      u,
      X.includeStack ? this.assert : A(this, "ssfi")
    );
  }
};
Object.defineProperty(d.prototype, "_obj", {
  get: /* @__PURE__ */ c(function() {
    return A(this, "object");
  }, "get"),
  set: /* @__PURE__ */ c(function(e) {
    A(this, "object", e);
  }, "set")
});
function Ve() {
  return X.useProxy && typeof Proxy < "u" && typeof Reflect < "u";
}
c(Ve, "isProxyEnabled");
y(Ve, "isProxyEnabled");
function hr(e, t, n) {
  n = n === void 0 ? function() {
  } : n, Object.defineProperty(e, t, {
    get: /* @__PURE__ */ y(/* @__PURE__ */ c(function i() {
      !Ve() && !A(this, "lockSsfi") && A(this, "ssfi", i);
      var o = n.call(this);
      if (o !== void 0)
        return o;
      var s = new d();
      return te(this, s), s;
    }, "propertyGetter"), "propertyGetter"),
    configurable: !0
  });
}
c(hr, "addProperty");
y(hr, "addProperty");
var Hc = Object.getOwnPropertyDescriptor(function() {
}, "length");
function Xe(e, t, n) {
  return Hc.configurable && Object.defineProperty(e, "length", {
    get: /* @__PURE__ */ c(function() {
      throw Error(
        n ? "Invalid Chai property: " + t + '.length. Due to a compatibility issue, "length" cannot directly follow "' + t + '". Use "' + t + '.lengthOf" instead.' : "Invalid Chai property: " + t + '.length. See docs for proper usage of "' + t + '".'
      );
    }, "get")
  }), e;
}
c(Xe, "addLengthGuard");
y(Xe, "addLengthGuard");
function Wo(e) {
  var t = Object.getOwnPropertyNames(e);
  function n(o) {
    t.indexOf(o) === -1 && t.push(o);
  }
  c(n, "addProperty2"), y(n, "addProperty");
  for (var i = Object.getPrototypeOf(e); i !== null; )
    Object.getOwnPropertyNames(i).forEach(n), i = Object.getPrototypeOf(i);
  return t;
}
c(Wo, "getProperties");
y(Wo, "getProperties");
var so = ["__flags", "__methods", "_obj", "assert"];
function Me(e, t) {
  return Ve() ? new Proxy(e, {
    get: /* @__PURE__ */ y(/* @__PURE__ */ c(function n(i, o) {
      if (typeof o == "string" && X.proxyExcludedKeys.indexOf(o) === -1 && !Reflect.has(i, o)) {
        if (t)
          throw Error(
            "Invalid Chai property: " + t + "." + o + '. See docs for proper usage of "' + t + '".'
          );
        var s = null, a = 4;
        throw Wo(i).forEach(function(l) {
          if (
            // we actually mean to check `Object.prototype` here
            // eslint-disable-next-line no-prototype-builtins
            !Object.prototype.hasOwnProperty(l) && so.indexOf(l) === -1
          ) {
            var u = Vo(o, l, a);
            u < a && (s = l, a = u);
          }
        }), Error(
          s !== null ? "Invalid Chai property: " + o + '. Did you mean "' + s + '"?' : "Invalid Chai property: " + o
        );
      }
      return so.indexOf(o) === -1 && !A(i, "lockSsfi") && A(i, "ssfi", n), Reflect.get(i, o);
    }, "proxyGetter"), "proxyGetter")
  }) : e;
}
c(Me, "proxify");
y(Me, "proxify");
function Vo(e, t, n) {
  if (Math.abs(e.length - t.length) >= n)
    return n;
  var i = [];
  for (let s = 0; s <= e.length; s++)
    i[s] = Array(t.length + 1).fill(0), i[s][0] = s;
  for (let s = 0; s < t.length; s++)
    i[0][s] = s;
  for (let s = 1; s <= e.length; s++) {
    var o = e.charCodeAt(s - 1);
    for (let a = 1; a <= t.length; a++) {
      if (Math.abs(s - a) >= n) {
        i[s][a] = n;
        continue;
      }
      i[s][a] = Math.min(
        i[s - 1][a] + 1,
        i[s][a - 1] + 1,
        i[s - 1][a - 1] + (o === t.charCodeAt(a - 1) ? 0 : 1)
      );
    }
  }
  return i[e.length][t.length];
}
c(Vo, "stringDistanceCapped");
y(Vo, "stringDistanceCapped");
function mr(e, t, n) {
  var i = /* @__PURE__ */ y(function() {
    A(this, "lockSsfi") || A(this, "ssfi", i);
    var o = n.apply(this, arguments);
    if (o !== void 0)
      return o;
    var s = new d();
    return te(this, s), s;
  }, "methodWrapper");
  Xe(i, t, !1), e[t] = Me(i, t);
}
c(mr, "addMethod");
y(mr, "addMethod");
function gr(e, t, n) {
  var i = Object.getOwnPropertyDescriptor(e, t), o = /* @__PURE__ */ y(function() {
  }, "_super");
  i && typeof i.get == "function" && (o = i.get), Object.defineProperty(e, t, {
    get: /* @__PURE__ */ y(/* @__PURE__ */ c(function s() {
      !Ve() && !A(this, "lockSsfi") && A(this, "ssfi", s);
      var a = A(this, "lockSsfi");
      A(this, "lockSsfi", !0);
      var l = n(o).call(this);
      if (A(this, "lockSsfi", a), l !== void 0)
        return l;
      var u = new d();
      return te(this, u), u;
    }, "overwritingPropertyGetter"), "overwritingPropertyGetter"),
    configurable: !0
  });
}
c(gr, "overwriteProperty");
y(gr, "overwriteProperty");
function yr(e, t, n) {
  var i = e[t], o = /* @__PURE__ */ y(function() {
    throw new Error(t + " is not a function");
  }, "_super");
  i && typeof i == "function" && (o = i);
  var s = /* @__PURE__ */ y(function() {
    A(this, "lockSsfi") || A(this, "ssfi", s);
    var a = A(this, "lockSsfi");
    A(this, "lockSsfi", !0);
    var l = n(o).apply(this, arguments);
    if (A(this, "lockSsfi", a), l !== void 0)
      return l;
    var u = new d();
    return te(this, u), u;
  }, "overwritingMethodWrapper");
  Xe(s, t, !1), e[t] = Me(s, t);
}
c(yr, "overwriteMethod");
y(yr, "overwriteMethod");
var Qc = typeof Object.setPrototypeOf == "function", ao = /* @__PURE__ */ y(function() {
}, "testFn"), Zc = Object.getOwnPropertyNames(ao).filter(function(e) {
  var t = Object.getOwnPropertyDescriptor(ao, e);
  return typeof t != "object" ? !0 : !t.configurable;
}), el = Function.prototype.call, tl = Function.prototype.apply;
function br(e, t, n, i) {
  typeof i != "function" && (i = /* @__PURE__ */ y(function() {
  }, "chainingBehavior"));
  var o = {
    method: n,
    chainingBehavior: i
  };
  e.__methods || (e.__methods = {}), e.__methods[t] = o, Object.defineProperty(e, t, {
    get: /* @__PURE__ */ y(/* @__PURE__ */ c(function() {
      o.chainingBehavior.call(this);
      var a = /* @__PURE__ */ y(function() {
        A(this, "lockSsfi") || A(this, "ssfi", a);
        var p = o.method.apply(this, arguments);
        if (p !== void 0)
          return p;
        var h = new d();
        return te(this, h), h;
      }, "chainableMethodWrapper");
      if (Xe(a, t, !0), Qc) {
        var l = Object.create(this);
        l.call = el, l.apply = tl, Object.setPrototypeOf(a, l);
      } else {
        var u = Object.getOwnPropertyNames(e);
        u.forEach(function(p) {
          if (Zc.indexOf(p) === -1) {
            var h = Object.getOwnPropertyDescriptor(e, p);
            Object.defineProperty(a, p, h);
          }
        });
      }
      return te(this, a), Me(a);
    }, "chainableMethodGetter"), "chainableMethodGetter"),
    configurable: !0
  });
}
c(br, "addChainableMethod");
y(br, "addChainableMethod");
function _r(e, t, n, i) {
  var o = e.__methods[t], s = o.chainingBehavior;
  o.chainingBehavior = /* @__PURE__ */ y(/* @__PURE__ */ c(function() {
    var u = i(s).call(this);
    if (u !== void 0)
      return u;
    var p = new d();
    return te(this, p), p;
  }, "overwritingChainableMethodGetter"), "overwritingChainableMethodGetter");
  var a = o.method;
  o.method = /* @__PURE__ */ y(/* @__PURE__ */ c(function() {
    var u = n(a).apply(this, arguments);
    if (u !== void 0)
      return u;
    var p = new d();
    return te(this, p), p;
  }, "overwritingChainableMethodWrapper"), "overwritingChainableMethodWrapper");
}
c(_r, "overwriteChainableMethod");
y(_r, "overwriteChainableMethod");
function $t(e, t) {
  return N(e) < N(t) ? -1 : 1;
}
c($t, "compareByInspect");
y($t, "compareByInspect");
function wr(e) {
  return typeof Object.getOwnPropertySymbols != "function" ? [] : Object.getOwnPropertySymbols(e).filter(function(t) {
    return Object.getOwnPropertyDescriptor(e, t).enumerable;
  });
}
c(wr, "getOwnEnumerablePropertySymbols");
y(wr, "getOwnEnumerablePropertySymbols");
function Er(e) {
  return Object.keys(e).concat(wr(e));
}
c(Er, "getOwnEnumerableProperties");
y(Er, "getOwnEnumerableProperties");
var Nt = Number.isNaN;
function Xo(e) {
  var t = j(e), n = ["Array", "Object", "Function"];
  return n.indexOf(t) !== -1;
}
c(Xo, "isObjectType");
y(Xo, "isObjectType");
function Tr(e, t) {
  var n = A(e, "operator"), i = A(e, "negate"), o = t[3], s = i ? t[2] : t[1];
  if (n)
    return n;
  if (typeof s == "function" && (s = s()), s = s || "", !!s && !/\shave\s/.test(s)) {
    var a = Xo(o);
    return /\snot\s/.test(s) ? a ? "notDeepStrictEqual" : "notStrictEqual" : a ? "deepStrictEqual" : "strictEqual";
  }
}
c(Tr, "getOperator");
y(Tr, "getOperator");
function Dt(e) {
  return e.name;
}
c(Dt, "getName");
y(Dt, "getName");
function Ot(e) {
  return Object.prototype.toString.call(e) === "[object RegExp]";
}
c(Ot, "isRegExp2");
y(Ot, "isRegExp");
function Y(e) {
  return ["Number", "BigInt"].includes(j(e));
}
c(Y, "isNumeric");
y(Y, "isNumeric");
var { flag: m } = It;
[
  "to",
  "be",
  "been",
  "is",
  "and",
  "has",
  "have",
  "with",
  "that",
  "which",
  "at",
  "of",
  "same",
  "but",
  "does",
  "still",
  "also"
].forEach(function(e) {
  d.addProperty(e);
});
d.addProperty("not", function() {
  m(this, "negate", !0);
});
d.addProperty("deep", function() {
  m(this, "deep", !0);
});
d.addProperty("nested", function() {
  m(this, "nested", !0);
});
d.addProperty("own", function() {
  m(this, "own", !0);
});
d.addProperty("ordered", function() {
  m(this, "ordered", !0);
});
d.addProperty("any", function() {
  m(this, "any", !0), m(this, "all", !1);
});
d.addProperty("all", function() {
  m(this, "all", !0), m(this, "any", !1);
});
var co = {
  function: [
    "function",
    "asyncfunction",
    "generatorfunction",
    "asyncgeneratorfunction"
  ],
  asyncfunction: ["asyncfunction", "asyncgeneratorfunction"],
  generatorfunction: ["generatorfunction", "asyncgeneratorfunction"],
  asyncgeneratorfunction: ["asyncgeneratorfunction"]
};
function vr(e, t) {
  t && m(this, "message", t), e = e.toLowerCase();
  var n = m(this, "object"), i = ~["a", "e", "i", "o", "u"].indexOf(e.charAt(0)) ? "an " : "a ";
  let o = j(n).toLowerCase();
  co.function.includes(e) ? this.assert(
    co[e].includes(o),
    "expected #{this} to be " + i + e,
    "expected #{this} not to be " + i + e
  ) : this.assert(
    e === o,
    "expected #{this} to be " + i + e,
    "expected #{this} not to be " + i + e
  );
}
c(vr, "an");
y(vr, "an");
d.addChainableMethod("an", vr);
d.addChainableMethod("a", vr);
function Ko(e, t) {
  return Nt(e) && Nt(t) || e === t;
}
c(Ko, "SameValueZero");
y(Ko, "SameValueZero");
function Ke() {
  m(this, "contains", !0);
}
c(Ke, "includeChainingBehavior");
y(Ke, "includeChainingBehavior");
function Ge(e, t) {
  t && m(this, "message", t);
  var n = m(this, "object"), i = j(n).toLowerCase(), o = m(this, "message"), s = m(this, "negate"), a = m(this, "ssfi"), l = m(this, "deep"), u = l ? "deep " : "", p = l ? m(this, "eql") : Ko;
  o = o ? o + ": " : "";
  var h = !1;
  switch (i) {
    case "string":
      h = n.indexOf(e) !== -1;
      break;
    case "weakset":
      if (l)
        throw new O(
          o + "unable to use .deep.include with WeakSet",
          void 0,
          a
        );
      h = n.has(e);
      break;
    case "map":
      n.forEach(function(T) {
        h = h || p(T, e);
      });
      break;
    case "set":
      l ? n.forEach(function(T) {
        h = h || p(T, e);
      }) : h = n.has(e);
      break;
    case "array":
      l ? h = n.some(function(T) {
        return p(T, e);
      }) : h = n.indexOf(e) !== -1;
      break;
    default:
      if (e !== Object(e))
        throw new O(
          o + "the given combination of arguments (" + i + " and " + j(e).toLowerCase() + ") is invalid for this assertion. You can use an array, a map, an object, a set, a string, or a weakset instead of a " + j(e).toLowerCase(),
          void 0,
          a
        );
      var g = Object.keys(e), w = null, _ = 0;
      if (g.forEach(function(T) {
        var b = new d(n);
        if (te(this, b, !0), m(b, "lockSsfi", !0), !s || g.length === 1) {
          b.property(T, e[T]);
          return;
        }
        try {
          b.property(T, e[T]);
        } catch (E) {
          if (!G.compatibleConstructor(E, O))
            throw E;
          w === null && (w = E), _++;
        }
      }, this), s && g.length > 1 && _ === g.length)
        throw w;
      return;
  }
  this.assert(
    h,
    "expected #{this} to " + u + "include " + N(e),
    "expected #{this} to not " + u + "include " + N(e)
  );
}
c(Ge, "include");
y(Ge, "include");
d.addChainableMethod("include", Ge, Ke);
d.addChainableMethod("contain", Ge, Ke);
d.addChainableMethod("contains", Ge, Ke);
d.addChainableMethod("includes", Ge, Ke);
d.addProperty("ok", function() {
  this.assert(
    m(this, "object"),
    "expected #{this} to be truthy",
    "expected #{this} to be falsy"
  );
});
d.addProperty("true", function() {
  this.assert(
    m(this, "object") === !0,
    "expected #{this} to be true",
    "expected #{this} to be false",
    !m(this, "negate")
  );
});
d.addProperty("numeric", function() {
  let e = m(this, "object");
  this.assert(
    ["Number", "BigInt"].includes(j(e)),
    "expected #{this} to be numeric",
    "expected #{this} to not be numeric",
    !m(this, "negate")
  );
});
d.addProperty("callable", function() {
  let e = m(this, "object"), t = m(this, "ssfi"), n = m(this, "message"), i = n ? `${n}: ` : "", o = m(this, "negate"), s = o ? `${i}expected ${N(e)} not to be a callable function` : `${i}expected ${N(e)} to be a callable function`, a = [
    "Function",
    "AsyncFunction",
    "GeneratorFunction",
    "AsyncGeneratorFunction"
  ].includes(j(e));
  if (a && o || !a && !o)
    throw new O(s, void 0, t);
});
d.addProperty("false", function() {
  this.assert(
    m(this, "object") === !1,
    "expected #{this} to be false",
    "expected #{this} to be true",
    !!m(this, "negate")
  );
});
d.addProperty("null", function() {
  this.assert(
    m(this, "object") === null,
    "expected #{this} to be null",
    "expected #{this} not to be null"
  );
});
d.addProperty("undefined", function() {
  this.assert(
    m(this, "object") === void 0,
    "expected #{this} to be undefined",
    "expected #{this} not to be undefined"
  );
});
d.addProperty("NaN", function() {
  this.assert(
    Nt(m(this, "object")),
    "expected #{this} to be NaN",
    "expected #{this} not to be NaN"
  );
});
function xr() {
  var e = m(this, "object");
  this.assert(
    e != null,
    "expected #{this} to exist",
    "expected #{this} to not exist"
  );
}
c(xr, "assertExist");
y(xr, "assertExist");
d.addProperty("exist", xr);
d.addProperty("exists", xr);
d.addProperty("empty", function() {
  var e = m(this, "object"), t = m(this, "ssfi"), n = m(this, "message"), i;
  switch (n = n ? n + ": " : "", j(e).toLowerCase()) {
    case "array":
    case "string":
      i = e.length;
      break;
    case "map":
    case "set":
      i = e.size;
      break;
    case "weakmap":
    case "weakset":
      throw new O(
        n + ".empty was passed a weak collection",
        void 0,
        t
      );
    case "function":
      var o = n + ".empty was passed a function " + Dt(e);
      throw new O(o.trim(), void 0, t);
    default:
      if (e !== Object(e))
        throw new O(
          n + ".empty was passed non-string primitive " + N(e),
          void 0,
          t
        );
      i = Object.keys(e).length;
  }
  this.assert(
    i === 0,
    "expected #{this} to be empty",
    "expected #{this} not to be empty"
  );
});
function Sr() {
  var e = m(this, "object"), t = j(e);
  this.assert(
    t === "Arguments",
    "expected #{this} to be arguments but got " + t,
    "expected #{this} to not be arguments"
  );
}
c(Sr, "checkArguments");
y(Sr, "checkArguments");
d.addProperty("arguments", Sr);
d.addProperty("Arguments", Sr);
function Lt(e, t) {
  t && m(this, "message", t);
  var n = m(this, "object");
  if (m(this, "deep")) {
    var i = m(this, "lockSsfi");
    m(this, "lockSsfi", !0), this.eql(e), m(this, "lockSsfi", i);
  } else
    this.assert(
      e === n,
      "expected #{this} to equal #{exp}",
      "expected #{this} to not equal #{exp}",
      e,
      this._obj,
      !0
    );
}
c(Lt, "assertEqual");
y(Lt, "assertEqual");
d.addMethod("equal", Lt);
d.addMethod("equals", Lt);
d.addMethod("eq", Lt);
function Ir(e, t) {
  t && m(this, "message", t);
  var n = m(this, "eql");
  this.assert(
    n(e, m(this, "object")),
    "expected #{this} to deeply equal #{exp}",
    "expected #{this} to not deeply equal #{exp}",
    e,
    this._obj,
    !0
  );
}
c(Ir, "assertEql");
y(Ir, "assertEql");
d.addMethod("eql", Ir);
d.addMethod("eqls", Ir);
function qt(e, t) {
  t && m(this, "message", t);
  var n = m(this, "object"), i = m(this, "doLength"), o = m(this, "message"), s = o ? o + ": " : "", a = m(this, "ssfi"), l = j(n).toLowerCase(), u = j(e).toLowerCase();
  if (i && l !== "map" && l !== "set" && new d(n, o, a, !0).to.have.property("length"), !i && l === "date" && u !== "date")
    throw new O(
      s + "the argument to above must be a date",
      void 0,
      a
    );
  if (!Y(e) && (i || Y(n)))
    throw new O(
      s + "the argument to above must be a number",
      void 0,
      a
    );
  if (!i && l !== "date" && !Y(n)) {
    var p = l === "string" ? "'" + n + "'" : n;
    throw new O(
      s + "expected " + p + " to be a number or a date",
      void 0,
      a
    );
  }
  if (i) {
    var h = "length", g;
    l === "map" || l === "set" ? (h = "size", g = n.size) : g = n.length, this.assert(
      g > e,
      "expected #{this} to have a " + h + " above #{exp} but got #{act}",
      "expected #{this} to not have a " + h + " above #{exp}",
      e,
      g
    );
  } else
    this.assert(
      n > e,
      "expected #{this} to be above #{exp}",
      "expected #{this} to be at most #{exp}",
      e
    );
}
c(qt, "assertAbove");
y(qt, "assertAbove");
d.addMethod("above", qt);
d.addMethod("gt", qt);
d.addMethod("greaterThan", qt);
function zt(e, t) {
  t && m(this, "message", t);
  var n = m(this, "object"), i = m(this, "doLength"), o = m(this, "message"), s = o ? o + ": " : "", a = m(this, "ssfi"), l = j(n).toLowerCase(), u = j(e).toLowerCase(), p, h = !0;
  if (i && l !== "map" && l !== "set" && new d(n, o, a, !0).to.have.property("length"), !i && l === "date" && u !== "date")
    p = s + "the argument to least must be a date";
  else if (!Y(e) && (i || Y(n)))
    p = s + "the argument to least must be a number";
  else if (!i && l !== "date" && !Y(n)) {
    var g = l === "string" ? "'" + n + "'" : n;
    p = s + "expected " + g + " to be a number or a date";
  } else
    h = !1;
  if (h)
    throw new O(p, void 0, a);
  if (i) {
    var w = "length", _;
    l === "map" || l === "set" ? (w = "size", _ = n.size) : _ = n.length, this.assert(
      _ >= e,
      "expected #{this} to have a " + w + " at least #{exp} but got #{act}",
      "expected #{this} to have a " + w + " below #{exp}",
      e,
      _
    );
  } else
    this.assert(
      n >= e,
      "expected #{this} to be at least #{exp}",
      "expected #{this} to be below #{exp}",
      e
    );
}
c(zt, "assertLeast");
y(zt, "assertLeast");
d.addMethod("least", zt);
d.addMethod("gte", zt);
d.addMethod("greaterThanOrEqual", zt);
function Bt(e, t) {
  t && m(this, "message", t);
  var n = m(this, "object"), i = m(this, "doLength"), o = m(this, "message"), s = o ? o + ": " : "", a = m(this, "ssfi"), l = j(n).toLowerCase(), u = j(e).toLowerCase(), p, h = !0;
  if (i && l !== "map" && l !== "set" && new d(n, o, a, !0).to.have.property("length"), !i && l === "date" && u !== "date")
    p = s + "the argument to below must be a date";
  else if (!Y(e) && (i || Y(n)))
    p = s + "the argument to below must be a number";
  else if (!i && l !== "date" && !Y(n)) {
    var g = l === "string" ? "'" + n + "'" : n;
    p = s + "expected " + g + " to be a number or a date";
  } else
    h = !1;
  if (h)
    throw new O(p, void 0, a);
  if (i) {
    var w = "length", _;
    l === "map" || l === "set" ? (w = "size", _ = n.size) : _ = n.length, this.assert(
      _ < e,
      "expected #{this} to have a " + w + " below #{exp} but got #{act}",
      "expected #{this} to not have a " + w + " below #{exp}",
      e,
      _
    );
  } else
    this.assert(
      n < e,
      "expected #{this} to be below #{exp}",
      "expected #{this} to be at least #{exp}",
      e
    );
}
c(Bt, "assertBelow");
y(Bt, "assertBelow");
d.addMethod("below", Bt);
d.addMethod("lt", Bt);
d.addMethod("lessThan", Bt);
function Ut(e, t) {
  t && m(this, "message", t);
  var n = m(this, "object"), i = m(this, "doLength"), o = m(this, "message"), s = o ? o + ": " : "", a = m(this, "ssfi"), l = j(n).toLowerCase(), u = j(e).toLowerCase(), p, h = !0;
  if (i && l !== "map" && l !== "set" && new d(n, o, a, !0).to.have.property("length"), !i && l === "date" && u !== "date")
    p = s + "the argument to most must be a date";
  else if (!Y(e) && (i || Y(n)))
    p = s + "the argument to most must be a number";
  else if (!i && l !== "date" && !Y(n)) {
    var g = l === "string" ? "'" + n + "'" : n;
    p = s + "expected " + g + " to be a number or a date";
  } else
    h = !1;
  if (h)
    throw new O(p, void 0, a);
  if (i) {
    var w = "length", _;
    l === "map" || l === "set" ? (w = "size", _ = n.size) : _ = n.length, this.assert(
      _ <= e,
      "expected #{this} to have a " + w + " at most #{exp} but got #{act}",
      "expected #{this} to have a " + w + " above #{exp}",
      e,
      _
    );
  } else
    this.assert(
      n <= e,
      "expected #{this} to be at most #{exp}",
      "expected #{this} to be above #{exp}",
      e
    );
}
c(Ut, "assertMost");
y(Ut, "assertMost");
d.addMethod("most", Ut);
d.addMethod("lte", Ut);
d.addMethod("lessThanOrEqual", Ut);
d.addMethod("within", function(e, t, n) {
  n && m(this, "message", n);
  var i = m(this, "object"), o = m(this, "doLength"), s = m(this, "message"), a = s ? s + ": " : "", l = m(this, "ssfi"), u = j(i).toLowerCase(), p = j(e).toLowerCase(), h = j(t).toLowerCase(), g, w = !0, _ = p === "date" && h === "date" ? e.toISOString() + ".." + t.toISOString() : e + ".." + t;
  if (o && u !== "map" && u !== "set" && new d(i, s, l, !0).to.have.property("length"), !o && u === "date" && (p !== "date" || h !== "date"))
    g = a + "the arguments to within must be dates";
  else if ((!Y(e) || !Y(t)) && (o || Y(i)))
    g = a + "the arguments to within must be numbers";
  else if (!o && u !== "date" && !Y(i)) {
    var T = u === "string" ? "'" + i + "'" : i;
    g = a + "expected " + T + " to be a number or a date";
  } else
    w = !1;
  if (w)
    throw new O(g, void 0, l);
  if (o) {
    var b = "length", E;
    u === "map" || u === "set" ? (b = "size", E = i.size) : E = i.length, this.assert(
      E >= e && E <= t,
      "expected #{this} to have a " + b + " within " + _,
      "expected #{this} to not have a " + b + " within " + _
    );
  } else
    this.assert(
      i >= e && i <= t,
      "expected #{this} to be within " + _,
      "expected #{this} to not be within " + _
    );
});
function Pr(e, t) {
  t && m(this, "message", t);
  var n = m(this, "object"), i = m(this, "ssfi"), o = m(this, "message");
  try {
    var s = n instanceof e;
  } catch (l) {
    throw l instanceof TypeError ? (o = o ? o + ": " : "", new O(
      o + "The instanceof assertion needs a constructor but " + j(e) + " was given.",
      void 0,
      i
    )) : l;
  }
  var a = Dt(e);
  a == null && (a = "an unnamed constructor"), this.assert(
    s,
    "expected #{this} to be an instance of " + a,
    "expected #{this} to not be an instance of " + a
  );
}
c(Pr, "assertInstanceOf");
y(Pr, "assertInstanceOf");
d.addMethod("instanceof", Pr);
d.addMethod("instanceOf", Pr);
function Ar(e, t, n) {
  n && m(this, "message", n);
  var i = m(this, "nested"), o = m(this, "own"), s = m(this, "message"), a = m(this, "object"), l = m(this, "ssfi"), u = typeof e;
  if (s = s ? s + ": " : "", i) {
    if (u !== "string")
      throw new O(
        s + "the argument to property must be a string when using nested syntax",
        void 0,
        l
      );
  } else if (u !== "string" && u !== "number" && u !== "symbol")
    throw new O(
      s + "the argument to property must be a string, number, or symbol",
      void 0,
      l
    );
  if (i && o)
    throw new O(
      s + 'The "nested" and "own" flags cannot be combined.',
      void 0,
      l
    );
  if (a == null)
    throw new O(
      s + "Target cannot be null or undefined.",
      void 0,
      l
    );
  var p = m(this, "deep"), h = m(this, "negate"), g = i ? pr(a, e) : null, w = i ? g.value : a[e], _ = p ? m(this, "eql") : (E, v) => E === v, T = "";
  p && (T += "deep "), o && (T += "own "), i && (T += "nested "), T += "property ";
  var b;
  o ? b = Object.prototype.hasOwnProperty.call(a, e) : i ? b = g.exists : b = Ft(a, e), (!h || arguments.length === 1) && this.assert(
    b,
    "expected #{this} to have " + T + N(e),
    "expected #{this} to not have " + T + N(e)
  ), arguments.length > 1 && this.assert(
    b && _(t, w),
    "expected #{this} to have " + T + N(e) + " of #{exp}, but got #{act}",
    "expected #{this} to not have " + T + N(e) + " of #{act}",
    t,
    w
  ), m(this, "object", w);
}
c(Ar, "assertProperty");
y(Ar, "assertProperty");
d.addMethod("property", Ar);
function Cr(e, t, n) {
  m(this, "own", !0), Ar.apply(this, arguments);
}
c(Cr, "assertOwnProperty");
y(Cr, "assertOwnProperty");
d.addMethod("ownProperty", Cr);
d.addMethod("haveOwnProperty", Cr);
function $r(e, t, n) {
  typeof t == "string" && (n = t, t = null), n && m(this, "message", n);
  var i = m(this, "object"), o = Object.getOwnPropertyDescriptor(Object(i), e), s = m(this, "eql");
  o && t ? this.assert(
    s(t, o),
    "expected the own property descriptor for " + N(e) + " on #{this} to match " + N(t) + ", got " + N(o),
    "expected the own property descriptor for " + N(e) + " on #{this} to not match " + N(t),
    t,
    o,
    !0
  ) : this.assert(
    o,
    "expected #{this} to have an own property descriptor for " + N(e),
    "expected #{this} to not have an own property descriptor for " + N(e)
  ), m(this, "object", o);
}
c($r, "assertOwnPropertyDescriptor");
y($r, "assertOwnPropertyDescriptor");
d.addMethod("ownPropertyDescriptor", $r);
d.addMethod("haveOwnPropertyDescriptor", $r);
function Nr() {
  m(this, "doLength", !0);
}
c(Nr, "assertLengthChain");
y(Nr, "assertLengthChain");
function Or(e, t) {
  t && m(this, "message", t);
  var n = m(this, "object"), i = j(n).toLowerCase(), o = m(this, "message"), s = m(this, "ssfi"), a = "length", l;
  switch (i) {
    case "map":
    case "set":
      a = "size", l = n.size;
      break;
    default:
      new d(n, o, s, !0).to.have.property("length"), l = n.length;
  }
  this.assert(
    l == e,
    "expected #{this} to have a " + a + " of #{exp} but got #{act}",
    "expected #{this} to not have a " + a + " of #{act}",
    e,
    l
  );
}
c(Or, "assertLength");
y(Or, "assertLength");
d.addChainableMethod("length", Or, Nr);
d.addChainableMethod("lengthOf", Or, Nr);
function Rr(e, t) {
  t && m(this, "message", t);
  var n = m(this, "object");
  this.assert(
    e.exec(n),
    "expected #{this} to match " + e,
    "expected #{this} not to match " + e
  );
}
c(Rr, "assertMatch");
y(Rr, "assertMatch");
d.addMethod("match", Rr);
d.addMethod("matches", Rr);
d.addMethod("string", function(e, t) {
  t && m(this, "message", t);
  var n = m(this, "object"), i = m(this, "message"), o = m(this, "ssfi");
  new d(n, i, o, !0).is.a("string"), this.assert(
    ~n.indexOf(e),
    "expected #{this} to contain " + N(e),
    "expected #{this} to not contain " + N(e)
  );
});
function Mr(e) {
  var t = m(this, "object"), n = j(t), i = j(e), o = m(this, "ssfi"), s = m(this, "deep"), a, l = "", u, p = !0, h = m(this, "message");
  h = h ? h + ": " : "";
  var g = h + "when testing keys against an object or an array you must give a single Array|Object|String argument or multiple String arguments";
  if (n === "Map" || n === "Set")
    l = s ? "deeply " : "", u = [], t.forEach(function(S, I) {
      u.push(I);
    }), i !== "Array" && (e = Array.prototype.slice.call(arguments));
  else {
    switch (u = Er(t), i) {
      case "Array":
        if (arguments.length > 1)
          throw new O(g, void 0, o);
        break;
      case "Object":
        if (arguments.length > 1)
          throw new O(g, void 0, o);
        e = Object.keys(e);
        break;
      default:
        e = Array.prototype.slice.call(arguments);
    }
    e = e.map(function(S) {
      return typeof S == "symbol" ? S : String(S);
    });
  }
  if (!e.length)
    throw new O(h + "keys required", void 0, o);
  var w = e.length, _ = m(this, "any"), T = m(this, "all"), b = e, E = s ? m(this, "eql") : (S, I) => S === I;
  if (!_ && !T && (T = !0), _ && (p = b.some(function(S) {
    return u.some(function(I) {
      return E(S, I);
    });
  })), T && (p = b.every(function(S) {
    return u.some(function(I) {
      return E(S, I);
    });
  }), m(this, "contains") || (p = p && e.length == u.length)), w > 1) {
    e = e.map(function(S) {
      return N(S);
    });
    var v = e.pop();
    T && (a = e.join(", ") + ", and " + v), _ && (a = e.join(", ") + ", or " + v);
  } else
    a = N(e[0]);
  a = (w > 1 ? "keys " : "key ") + a, a = (m(this, "contains") ? "contain " : "have ") + a, this.assert(
    p,
    "expected #{this} to " + l + a,
    "expected #{this} to not " + l + a,
    b.slice(0).sort($t),
    u.sort($t),
    !0
  );
}
c(Mr, "assertKeys");
y(Mr, "assertKeys");
d.addMethod("keys", Mr);
d.addMethod("key", Mr);
function Yt(e, t, n) {
  n && m(this, "message", n);
  var i = m(this, "object"), o = m(this, "ssfi"), s = m(this, "message"), a = m(this, "negate") || !1;
  new d(i, s, o, !0).is.a("function"), (Ot(e) || typeof e == "string") && (t = e, e = null);
  let l, u = !1;
  try {
    i();
  } catch (S) {
    u = !0, l = S;
  }
  var p = e === void 0 && t === void 0, h = !!(e && t), g = !1, w = !1;
  if (p || !p && !a) {
    var _ = "an error";
    e instanceof Error ? _ = "#{exp}" : e && (_ = G.getConstructorName(e));
    let S = l;
    if (l instanceof Error)
      S = l.toString();
    else if (typeof l == "string")
      S = l;
    else if (l && (typeof l == "object" || typeof l == "function"))
      try {
        S = G.getConstructorName(l);
      } catch {
      }
    this.assert(
      u,
      "expected #{this} to throw " + _,
      "expected #{this} to not throw an error but #{act} was thrown",
      e && e.toString(),
      S
    );
  }
  if (e && l) {
    if (e instanceof Error) {
      var T = G.compatibleInstance(
        l,
        e
      );
      T === a && (h && a ? g = !0 : this.assert(
        a,
        "expected #{this} to throw #{exp} but #{act} was thrown",
        "expected #{this} to not throw #{exp}" + (l && !a ? " but #{act} was thrown" : ""),
        e.toString(),
        l.toString()
      ));
    }
    var b = G.compatibleConstructor(
      l,
      e
    );
    b === a && (h && a ? g = !0 : this.assert(
      a,
      "expected #{this} to throw #{exp} but #{act} was thrown",
      "expected #{this} to not throw #{exp}" + (l ? " but #{act} was thrown" : ""),
      e instanceof Error ? e.toString() : e && G.getConstructorName(e),
      l instanceof Error ? l.toString() : l && G.getConstructorName(l)
    ));
  }
  if (l && t !== void 0 && t !== null) {
    var E = "including";
    Ot(t) && (E = "matching");
    var v = G.compatibleMessage(
      l,
      t
    );
    v === a && (h && a ? w = !0 : this.assert(
      a,
      "expected #{this} to throw error " + E + " #{exp} but got #{act}",
      "expected #{this} to throw error not " + E + " #{exp}",
      t,
      G.getMessage(l)
    ));
  }
  g && w && this.assert(
    a,
    "expected #{this} to throw #{exp} but #{act} was thrown",
    "expected #{this} to not throw #{exp}" + (l ? " but #{act} was thrown" : ""),
    e instanceof Error ? e.toString() : e && G.getConstructorName(e),
    l instanceof Error ? l.toString() : l && G.getConstructorName(l)
  ), m(this, "object", l);
}
c(Yt, "assertThrows");
y(Yt, "assertThrows");
d.addMethod("throw", Yt);
d.addMethod("throws", Yt);
d.addMethod("Throw", Yt);
function jr(e, t) {
  t && m(this, "message", t);
  var n = m(this, "object"), i = m(this, "itself"), o = typeof n == "function" && !i ? n.prototype[e] : n[e];
  this.assert(
    typeof o == "function",
    "expected #{this} to respond to " + N(e),
    "expected #{this} to not respond to " + N(e)
  );
}
c(jr, "respondTo");
y(jr, "respondTo");
d.addMethod("respondTo", jr);
d.addMethod("respondsTo", jr);
d.addProperty("itself", function() {
  m(this, "itself", !0);
});
function kr(e, t) {
  t && m(this, "message", t);
  var n = m(this, "object"), i = e(n);
  this.assert(
    i,
    "expected #{this} to satisfy " + ve(e),
    "expected #{this} to not satisfy" + ve(e),
    !m(this, "negate"),
    i
  );
}
c(kr, "satisfy");
y(kr, "satisfy");
d.addMethod("satisfy", kr);
d.addMethod("satisfies", kr);
function Fr(e, t, n) {
  n && m(this, "message", n);
  var i = m(this, "object"), o = m(this, "message"), s = m(this, "ssfi");
  new d(i, o, s, !0).is.numeric;
  let a = "A `delta` value is required for `closeTo`";
  if (t == null)
    throw new O(
      o ? `${o}: ${a}` : a,
      void 0,
      s
    );
  if (new d(t, o, s, !0).is.numeric, a = "A `expected` value is required for `closeTo`", e == null)
    throw new O(
      o ? `${o}: ${a}` : a,
      void 0,
      s
    );
  new d(e, o, s, !0).is.numeric;
  let l = /* @__PURE__ */ y((p) => p < 0n ? -p : p, "abs"), u = /* @__PURE__ */ y((p) => parseFloat(parseFloat(p).toPrecision(12)), "strip");
  this.assert(
    u(l(i - e)) <= t,
    "expected #{this} to be close to " + e + " +/- " + t,
    "expected #{this} not to be close to " + e + " +/- " + t
  );
}
c(Fr, "closeTo");
y(Fr, "closeTo");
d.addMethod("closeTo", Fr);
d.addMethod("approximately", Fr);
function Go(e, t, n, i, o) {
  let s = Array.from(t), a = Array.from(e);
  if (!i) {
    if (a.length !== s.length)
      return !1;
    s = s.slice();
  }
  return a.every(function(l, u) {
    if (o)
      return n ? n(l, s[u]) : l === s[u];
    if (!n) {
      var p = s.indexOf(l);
      return p === -1 ? !1 : (i || s.splice(p, 1), !0);
    }
    return s.some(function(h, g) {
      return n(l, h) ? (i || s.splice(g, 1), !0) : !1;
    });
  });
}
c(Go, "isSubsetOf");
y(Go, "isSubsetOf");
d.addMethod("members", function(e, t) {
  t && m(this, "message", t);
  var n = m(this, "object"), i = m(this, "message"), o = m(this, "ssfi");
  new d(n, i, o, !0).to.be.iterable, new d(e, i, o, !0).to.be.iterable;
  var s = m(this, "contains"), a = m(this, "ordered"), l, u, p;
  s ? (l = a ? "an ordered superset" : "a superset", u = "expected #{this} to be " + l + " of #{exp}", p = "expected #{this} to not be " + l + " of #{exp}") : (l = a ? "ordered members" : "members", u = "expected #{this} to have the same " + l + " as #{exp}", p = "expected #{this} to not have the same " + l + " as #{exp}");
  var h = m(this, "deep") ? m(this, "eql") : void 0;
  this.assert(
    Go(e, n, h, s, a),
    u,
    p,
    e,
    n,
    !0
  );
});
d.addProperty("iterable", function(e) {
  e && m(this, "message", e);
  var t = m(this, "object");
  this.assert(
    t != null && t[Symbol.iterator],
    "expected #{this} to be an iterable",
    "expected #{this} to not be an iterable",
    t
  );
});
function Ho(e, t) {
  t && m(this, "message", t);
  var n = m(this, "object"), i = m(this, "message"), o = m(this, "ssfi"), s = m(this, "contains"), a = m(this, "deep"), l = m(this, "eql");
  new d(e, i, o, !0).to.be.an("array"), s ? this.assert(
    e.some(function(u) {
      return n.indexOf(u) > -1;
    }),
    "expected #{this} to contain one of #{exp}",
    "expected #{this} to not contain one of #{exp}",
    e,
    n
  ) : a ? this.assert(
    e.some(function(u) {
      return l(n, u);
    }),
    "expected #{this} to deeply equal one of #{exp}",
    "expected #{this} to deeply equal one of #{exp}",
    e,
    n
  ) : this.assert(
    e.indexOf(n) > -1,
    "expected #{this} to be one of #{exp}",
    "expected #{this} to not be one of #{exp}",
    e,
    n
  );
}
c(Ho, "oneOf");
y(Ho, "oneOf");
d.addMethod("oneOf", Ho);
function Dr(e, t, n) {
  n && m(this, "message", n);
  var i = m(this, "object"), o = m(this, "message"), s = m(this, "ssfi");
  new d(i, o, s, !0).is.a("function");
  var a;
  t ? (new d(e, o, s, !0).to.have.property(t), a = e[t]) : (new d(e, o, s, !0).is.a("function"), a = e()), i();
  var l = t == null ? e() : e[t], u = t == null ? a : "." + t;
  m(this, "deltaMsgObj", u), m(this, "initialDeltaValue", a), m(this, "finalDeltaValue", l), m(this, "deltaBehavior", "change"), m(this, "realDelta", l !== a), this.assert(
    a !== l,
    "expected " + u + " to change",
    "expected " + u + " to not change"
  );
}
c(Dr, "assertChanges");
y(Dr, "assertChanges");
d.addMethod("change", Dr);
d.addMethod("changes", Dr);
function Lr(e, t, n) {
  n && m(this, "message", n);
  var i = m(this, "object"), o = m(this, "message"), s = m(this, "ssfi");
  new d(i, o, s, !0).is.a("function");
  var a;
  t ? (new d(e, o, s, !0).to.have.property(t), a = e[t]) : (new d(e, o, s, !0).is.a("function"), a = e()), new d(a, o, s, !0).is.a("number"), i();
  var l = t == null ? e() : e[t], u = t == null ? a : "." + t;
  m(this, "deltaMsgObj", u), m(this, "initialDeltaValue", a), m(this, "finalDeltaValue", l), m(this, "deltaBehavior", "increase"), m(this, "realDelta", l - a), this.assert(
    l - a > 0,
    "expected " + u + " to increase",
    "expected " + u + " to not increase"
  );
}
c(Lr, "assertIncreases");
y(Lr, "assertIncreases");
d.addMethod("increase", Lr);
d.addMethod("increases", Lr);
function qr(e, t, n) {
  n && m(this, "message", n);
  var i = m(this, "object"), o = m(this, "message"), s = m(this, "ssfi");
  new d(i, o, s, !0).is.a("function");
  var a;
  t ? (new d(e, o, s, !0).to.have.property(t), a = e[t]) : (new d(e, o, s, !0).is.a("function"), a = e()), new d(a, o, s, !0).is.a("number"), i();
  var l = t == null ? e() : e[t], u = t == null ? a : "." + t;
  m(this, "deltaMsgObj", u), m(this, "initialDeltaValue", a), m(this, "finalDeltaValue", l), m(this, "deltaBehavior", "decrease"), m(this, "realDelta", a - l), this.assert(
    l - a < 0,
    "expected " + u + " to decrease",
    "expected " + u + " to not decrease"
  );
}
c(qr, "assertDecreases");
y(qr, "assertDecreases");
d.addMethod("decrease", qr);
d.addMethod("decreases", qr);
function Qo(e, t) {
  t && m(this, "message", t);
  var n = m(this, "deltaMsgObj"), i = m(this, "initialDeltaValue"), o = m(this, "finalDeltaValue"), s = m(this, "deltaBehavior"), a = m(this, "realDelta"), l;
  s === "change" ? l = Math.abs(o - i) === Math.abs(e) : l = a === Math.abs(e), this.assert(
    l,
    "expected " + n + " to " + s + " by " + e,
    "expected " + n + " to not " + s + " by " + e
  );
}
c(Qo, "assertDelta");
y(Qo, "assertDelta");
d.addMethod("by", Qo);
d.addProperty("extensible", function() {
  var e = m(this, "object"), t = e === Object(e) && Object.isExtensible(e);
  this.assert(
    t,
    "expected #{this} to be extensible",
    "expected #{this} to not be extensible"
  );
});
d.addProperty("sealed", function() {
  var e = m(this, "object"), t = e === Object(e) ? Object.isSealed(e) : !0;
  this.assert(
    t,
    "expected #{this} to be sealed",
    "expected #{this} to not be sealed"
  );
});
d.addProperty("frozen", function() {
  var e = m(this, "object"), t = e === Object(e) ? Object.isFrozen(e) : !0;
  this.assert(
    t,
    "expected #{this} to be frozen",
    "expected #{this} to not be frozen"
  );
});
d.addProperty("finite", function(e) {
  var t = m(this, "object");
  this.assert(
    typeof t == "number" && isFinite(t),
    "expected #{this} to be a finite number",
    "expected #{this} to not be a finite number"
  );
});
function Rt(e, t) {
  return e === t ? !0 : typeof t != typeof e ? !1 : typeof e != "object" || e === null ? e === t : t ? Array.isArray(e) ? Array.isArray(t) ? e.every(function(n) {
    return t.some(function(i) {
      return Rt(n, i);
    });
  }) : !1 : e instanceof Date ? t instanceof Date ? e.getTime() === t.getTime() : !1 : Object.keys(e).every(function(n) {
    var i = e[n], o = t[n];
    return typeof i == "object" && i !== null && o !== null ? Rt(i, o) : typeof i == "function" ? i(o) : o === i;
  }) : !1;
}
c(Rt, "compareSubset");
y(Rt, "compareSubset");
d.addMethod("containSubset", function(e) {
  let t = A(this, "object"), n = X.showDiff;
  this.assert(
    Rt(e, t),
    "expected #{act} to contain subset #{exp}",
    "expected #{act} to not contain subset #{exp}",
    e,
    t,
    n
  );
});
function Mt(e, t) {
  return new d(e, t);
}
c(Mt, "expect");
y(Mt, "expect");
Mt.fail = function(e, t, n, i) {
  throw arguments.length < 2 && (n = e, e = void 0), n = n || "expect.fail()", new O(
    n,
    {
      actual: e,
      expected: t,
      operator: i
    },
    Mt.fail
  );
};
var Zo = {};
sr(Zo, {
  Should: /* @__PURE__ */ c(() => nl, "Should"),
  should: /* @__PURE__ */ c(() => es, "should")
});
function zr() {
  function e() {
    return this instanceof String || this instanceof Number || this instanceof Boolean || typeof Symbol == "function" && this instanceof Symbol || typeof BigInt == "function" && this instanceof BigInt ? new d(this.valueOf(), null, e) : new d(this, null, e);
  }
  c(e, "shouldGetter"), y(e, "shouldGetter");
  function t(i) {
    Object.defineProperty(this, "should", {
      value: i,
      enumerable: !0,
      configurable: !0,
      writable: !0
    });
  }
  c(t, "shouldSetter"), y(t, "shouldSetter"), Object.defineProperty(Object.prototype, "should", {
    set: t,
    get: e,
    configurable: !0
  });
  var n = {};
  return n.fail = function(i, o, s, a) {
    throw arguments.length < 2 && (s = i, i = void 0), s = s || "should.fail()", new O(
      s,
      {
        actual: i,
        expected: o,
        operator: a
      },
      n.fail
    );
  }, n.equal = function(i, o, s) {
    new d(i, s).to.equal(o);
  }, n.Throw = function(i, o, s, a) {
    new d(i, a).to.Throw(o, s);
  }, n.exist = function(i, o) {
    new d(i, o).to.exist;
  }, n.not = {}, n.not.equal = function(i, o, s) {
    new d(i, s).to.not.equal(o);
  }, n.not.Throw = function(i, o, s, a) {
    new d(i, a).to.not.Throw(o, s);
  }, n.not.exist = function(i, o) {
    new d(i, o).to.not.exist;
  }, n.throw = n.Throw, n.not.throw = n.not.Throw, n;
}
c(zr, "loadShould");
y(zr, "loadShould");
var es = zr, nl = zr;
function f(e, t) {
  var n = new d(null, null, f, !0);
  n.assert(e, t, "[ negation message unavailable ]");
}
c(f, "assert");
y(f, "assert");
f.fail = function(e, t, n, i) {
  throw arguments.length < 2 && (n = e, e = void 0), n = n || "assert.fail()", new O(
    n,
    {
      actual: e,
      expected: t,
      operator: i
    },
    f.fail
  );
};
f.isOk = function(e, t) {
  new d(e, t, f.isOk, !0).is.ok;
};
f.isNotOk = function(e, t) {
  new d(e, t, f.isNotOk, !0).is.not.ok;
};
f.equal = function(e, t, n) {
  var i = new d(e, n, f.equal, !0);
  i.assert(
    t == A(i, "object"),
    "expected #{this} to equal #{exp}",
    "expected #{this} to not equal #{act}",
    t,
    e,
    !0
  );
};
f.notEqual = function(e, t, n) {
  var i = new d(e, n, f.notEqual, !0);
  i.assert(
    t != A(i, "object"),
    "expected #{this} to not equal #{exp}",
    "expected #{this} to equal #{act}",
    t,
    e,
    !0
  );
};
f.strictEqual = function(e, t, n) {
  new d(e, n, f.strictEqual, !0).to.equal(t);
};
f.notStrictEqual = function(e, t, n) {
  new d(e, n, f.notStrictEqual, !0).to.not.equal(t);
};
f.deepEqual = f.deepStrictEqual = function(e, t, n) {
  new d(e, n, f.deepEqual, !0).to.eql(t);
};
f.notDeepEqual = function(e, t, n) {
  new d(e, n, f.notDeepEqual, !0).to.not.eql(t);
};
f.isAbove = function(e, t, n) {
  new d(e, n, f.isAbove, !0).to.be.above(t);
};
f.isAtLeast = function(e, t, n) {
  new d(e, n, f.isAtLeast, !0).to.be.least(t);
};
f.isBelow = function(e, t, n) {
  new d(e, n, f.isBelow, !0).to.be.below(t);
};
f.isAtMost = function(e, t, n) {
  new d(e, n, f.isAtMost, !0).to.be.most(t);
};
f.isTrue = function(e, t) {
  new d(e, t, f.isTrue, !0).is.true;
};
f.isNotTrue = function(e, t) {
  new d(e, t, f.isNotTrue, !0).to.not.equal(!0);
};
f.isFalse = function(e, t) {
  new d(e, t, f.isFalse, !0).is.false;
};
f.isNotFalse = function(e, t) {
  new d(e, t, f.isNotFalse, !0).to.not.equal(!1);
};
f.isNull = function(e, t) {
  new d(e, t, f.isNull, !0).to.equal(null);
};
f.isNotNull = function(e, t) {
  new d(e, t, f.isNotNull, !0).to.not.equal(null);
};
f.isNaN = function(e, t) {
  new d(e, t, f.isNaN, !0).to.be.NaN;
};
f.isNotNaN = function(e, t) {
  new d(e, t, f.isNotNaN, !0).not.to.be.NaN;
};
f.exists = function(e, t) {
  new d(e, t, f.exists, !0).to.exist;
};
f.notExists = function(e, t) {
  new d(e, t, f.notExists, !0).to.not.exist;
};
f.isUndefined = function(e, t) {
  new d(e, t, f.isUndefined, !0).to.equal(void 0);
};
f.isDefined = function(e, t) {
  new d(e, t, f.isDefined, !0).to.not.equal(void 0);
};
f.isCallable = function(e, t) {
  new d(e, t, f.isCallable, !0).is.callable;
};
f.isNotCallable = function(e, t) {
  new d(e, t, f.isNotCallable, !0).is.not.callable;
};
f.isObject = function(e, t) {
  new d(e, t, f.isObject, !0).to.be.a("object");
};
f.isNotObject = function(e, t) {
  new d(e, t, f.isNotObject, !0).to.not.be.a("object");
};
f.isArray = function(e, t) {
  new d(e, t, f.isArray, !0).to.be.an("array");
};
f.isNotArray = function(e, t) {
  new d(e, t, f.isNotArray, !0).to.not.be.an("array");
};
f.isString = function(e, t) {
  new d(e, t, f.isString, !0).to.be.a("string");
};
f.isNotString = function(e, t) {
  new d(e, t, f.isNotString, !0).to.not.be.a("string");
};
f.isNumber = function(e, t) {
  new d(e, t, f.isNumber, !0).to.be.a("number");
};
f.isNotNumber = function(e, t) {
  new d(e, t, f.isNotNumber, !0).to.not.be.a("number");
};
f.isNumeric = function(e, t) {
  new d(e, t, f.isNumeric, !0).is.numeric;
};
f.isNotNumeric = function(e, t) {
  new d(e, t, f.isNotNumeric, !0).is.not.numeric;
};
f.isFinite = function(e, t) {
  new d(e, t, f.isFinite, !0).to.be.finite;
};
f.isBoolean = function(e, t) {
  new d(e, t, f.isBoolean, !0).to.be.a("boolean");
};
f.isNotBoolean = function(e, t) {
  new d(e, t, f.isNotBoolean, !0).to.not.be.a("boolean");
};
f.typeOf = function(e, t, n) {
  new d(e, n, f.typeOf, !0).to.be.a(t);
};
f.notTypeOf = function(e, t, n) {
  new d(e, n, f.notTypeOf, !0).to.not.be.a(t);
};
f.instanceOf = function(e, t, n) {
  new d(e, n, f.instanceOf, !0).to.be.instanceOf(t);
};
f.notInstanceOf = function(e, t, n) {
  new d(e, n, f.notInstanceOf, !0).to.not.be.instanceOf(
    t
  );
};
f.include = function(e, t, n) {
  new d(e, n, f.include, !0).include(t);
};
f.notInclude = function(e, t, n) {
  new d(e, n, f.notInclude, !0).not.include(t);
};
f.deepInclude = function(e, t, n) {
  new d(e, n, f.deepInclude, !0).deep.include(t);
};
f.notDeepInclude = function(e, t, n) {
  new d(e, n, f.notDeepInclude, !0).not.deep.include(t);
};
f.nestedInclude = function(e, t, n) {
  new d(e, n, f.nestedInclude, !0).nested.include(t);
};
f.notNestedInclude = function(e, t, n) {
  new d(e, n, f.notNestedInclude, !0).not.nested.include(
    t
  );
};
f.deepNestedInclude = function(e, t, n) {
  new d(e, n, f.deepNestedInclude, !0).deep.nested.include(
    t
  );
};
f.notDeepNestedInclude = function(e, t, n) {
  new d(
    e,
    n,
    f.notDeepNestedInclude,
    !0
  ).not.deep.nested.include(t);
};
f.ownInclude = function(e, t, n) {
  new d(e, n, f.ownInclude, !0).own.include(t);
};
f.notOwnInclude = function(e, t, n) {
  new d(e, n, f.notOwnInclude, !0).not.own.include(t);
};
f.deepOwnInclude = function(e, t, n) {
  new d(e, n, f.deepOwnInclude, !0).deep.own.include(t);
};
f.notDeepOwnInclude = function(e, t, n) {
  new d(e, n, f.notDeepOwnInclude, !0).not.deep.own.include(
    t
  );
};
f.match = function(e, t, n) {
  new d(e, n, f.match, !0).to.match(t);
};
f.notMatch = function(e, t, n) {
  new d(e, n, f.notMatch, !0).to.not.match(t);
};
f.property = function(e, t, n) {
  new d(e, n, f.property, !0).to.have.property(t);
};
f.notProperty = function(e, t, n) {
  new d(e, n, f.notProperty, !0).to.not.have.property(t);
};
f.propertyVal = function(e, t, n, i) {
  new d(e, i, f.propertyVal, !0).to.have.property(t, n);
};
f.notPropertyVal = function(e, t, n, i) {
  new d(e, i, f.notPropertyVal, !0).to.not.have.property(
    t,
    n
  );
};
f.deepPropertyVal = function(e, t, n, i) {
  new d(e, i, f.deepPropertyVal, !0).to.have.deep.property(
    t,
    n
  );
};
f.notDeepPropertyVal = function(e, t, n, i) {
  new d(
    e,
    i,
    f.notDeepPropertyVal,
    !0
  ).to.not.have.deep.property(t, n);
};
f.ownProperty = function(e, t, n) {
  new d(e, n, f.ownProperty, !0).to.have.own.property(t);
};
f.notOwnProperty = function(e, t, n) {
  new d(e, n, f.notOwnProperty, !0).to.not.have.own.property(
    t
  );
};
f.ownPropertyVal = function(e, t, n, i) {
  new d(e, i, f.ownPropertyVal, !0).to.have.own.property(
    t,
    n
  );
};
f.notOwnPropertyVal = function(e, t, n, i) {
  new d(
    e,
    i,
    f.notOwnPropertyVal,
    !0
  ).to.not.have.own.property(t, n);
};
f.deepOwnPropertyVal = function(e, t, n, i) {
  new d(
    e,
    i,
    f.deepOwnPropertyVal,
    !0
  ).to.have.deep.own.property(t, n);
};
f.notDeepOwnPropertyVal = function(e, t, n, i) {
  new d(
    e,
    i,
    f.notDeepOwnPropertyVal,
    !0
  ).to.not.have.deep.own.property(t, n);
};
f.nestedProperty = function(e, t, n) {
  new d(e, n, f.nestedProperty, !0).to.have.nested.property(
    t
  );
};
f.notNestedProperty = function(e, t, n) {
  new d(
    e,
    n,
    f.notNestedProperty,
    !0
  ).to.not.have.nested.property(t);
};
f.nestedPropertyVal = function(e, t, n, i) {
  new d(
    e,
    i,
    f.nestedPropertyVal,
    !0
  ).to.have.nested.property(t, n);
};
f.notNestedPropertyVal = function(e, t, n, i) {
  new d(
    e,
    i,
    f.notNestedPropertyVal,
    !0
  ).to.not.have.nested.property(t, n);
};
f.deepNestedPropertyVal = function(e, t, n, i) {
  new d(
    e,
    i,
    f.deepNestedPropertyVal,
    !0
  ).to.have.deep.nested.property(t, n);
};
f.notDeepNestedPropertyVal = function(e, t, n, i) {
  new d(
    e,
    i,
    f.notDeepNestedPropertyVal,
    !0
  ).to.not.have.deep.nested.property(t, n);
};
f.lengthOf = function(e, t, n) {
  new d(e, n, f.lengthOf, !0).to.have.lengthOf(t);
};
f.hasAnyKeys = function(e, t, n) {
  new d(e, n, f.hasAnyKeys, !0).to.have.any.keys(t);
};
f.hasAllKeys = function(e, t, n) {
  new d(e, n, f.hasAllKeys, !0).to.have.all.keys(t);
};
f.containsAllKeys = function(e, t, n) {
  new d(e, n, f.containsAllKeys, !0).to.contain.all.keys(
    t
  );
};
f.doesNotHaveAnyKeys = function(e, t, n) {
  new d(e, n, f.doesNotHaveAnyKeys, !0).to.not.have.any.keys(
    t
  );
};
f.doesNotHaveAllKeys = function(e, t, n) {
  new d(e, n, f.doesNotHaveAllKeys, !0).to.not.have.all.keys(
    t
  );
};
f.hasAnyDeepKeys = function(e, t, n) {
  new d(e, n, f.hasAnyDeepKeys, !0).to.have.any.deep.keys(
    t
  );
};
f.hasAllDeepKeys = function(e, t, n) {
  new d(e, n, f.hasAllDeepKeys, !0).to.have.all.deep.keys(
    t
  );
};
f.containsAllDeepKeys = function(e, t, n) {
  new d(
    e,
    n,
    f.containsAllDeepKeys,
    !0
  ).to.contain.all.deep.keys(t);
};
f.doesNotHaveAnyDeepKeys = function(e, t, n) {
  new d(
    e,
    n,
    f.doesNotHaveAnyDeepKeys,
    !0
  ).to.not.have.any.deep.keys(t);
};
f.doesNotHaveAllDeepKeys = function(e, t, n) {
  new d(
    e,
    n,
    f.doesNotHaveAllDeepKeys,
    !0
  ).to.not.have.all.deep.keys(t);
};
f.throws = function(e, t, n, i) {
  (typeof t == "string" || t instanceof RegExp) && (n = t, t = null);
  var o = new d(e, i, f.throws, !0).to.throw(
    t,
    n
  );
  return A(o, "object");
};
f.doesNotThrow = function(e, t, n, i) {
  (typeof t == "string" || t instanceof RegExp) && (n = t, t = null), new d(e, i, f.doesNotThrow, !0).to.not.throw(
    t,
    n
  );
};
f.operator = function(e, t, n, i) {
  var o;
  switch (t) {
    case "==":
      o = e == n;
      break;
    case "===":
      o = e === n;
      break;
    case ">":
      o = e > n;
      break;
    case ">=":
      o = e >= n;
      break;
    case "<":
      o = e < n;
      break;
    case "<=":
      o = e <= n;
      break;
    case "!=":
      o = e != n;
      break;
    case "!==":
      o = e !== n;
      break;
    default:
      throw i = i && i + ": ", new O(
        i + 'Invalid operator "' + t + '"',
        void 0,
        f.operator
      );
  }
  var s = new d(o, i, f.operator, !0);
  s.assert(
    A(s, "object") === !0,
    "expected " + N(e) + " to be " + t + " " + N(n),
    "expected " + N(e) + " to not be " + t + " " + N(n)
  );
};
f.closeTo = function(e, t, n, i) {
  new d(e, i, f.closeTo, !0).to.be.closeTo(t, n);
};
f.approximately = function(e, t, n, i) {
  new d(e, i, f.approximately, !0).to.be.approximately(
    t,
    n
  );
};
f.sameMembers = function(e, t, n) {
  new d(e, n, f.sameMembers, !0).to.have.same.members(t);
};
f.notSameMembers = function(e, t, n) {
  new d(
    e,
    n,
    f.notSameMembers,
    !0
  ).to.not.have.same.members(t);
};
f.sameDeepMembers = function(e, t, n) {
  new d(
    e,
    n,
    f.sameDeepMembers,
    !0
  ).to.have.same.deep.members(t);
};
f.notSameDeepMembers = function(e, t, n) {
  new d(
    e,
    n,
    f.notSameDeepMembers,
    !0
  ).to.not.have.same.deep.members(t);
};
f.sameOrderedMembers = function(e, t, n) {
  new d(
    e,
    n,
    f.sameOrderedMembers,
    !0
  ).to.have.same.ordered.members(t);
};
f.notSameOrderedMembers = function(e, t, n) {
  new d(
    e,
    n,
    f.notSameOrderedMembers,
    !0
  ).to.not.have.same.ordered.members(t);
};
f.sameDeepOrderedMembers = function(e, t, n) {
  new d(
    e,
    n,
    f.sameDeepOrderedMembers,
    !0
  ).to.have.same.deep.ordered.members(t);
};
f.notSameDeepOrderedMembers = function(e, t, n) {
  new d(
    e,
    n,
    f.notSameDeepOrderedMembers,
    !0
  ).to.not.have.same.deep.ordered.members(t);
};
f.includeMembers = function(e, t, n) {
  new d(e, n, f.includeMembers, !0).to.include.members(
    t
  );
};
f.notIncludeMembers = function(e, t, n) {
  new d(
    e,
    n,
    f.notIncludeMembers,
    !0
  ).to.not.include.members(t);
};
f.includeDeepMembers = function(e, t, n) {
  new d(
    e,
    n,
    f.includeDeepMembers,
    !0
  ).to.include.deep.members(t);
};
f.notIncludeDeepMembers = function(e, t, n) {
  new d(
    e,
    n,
    f.notIncludeDeepMembers,
    !0
  ).to.not.include.deep.members(t);
};
f.includeOrderedMembers = function(e, t, n) {
  new d(
    e,
    n,
    f.includeOrderedMembers,
    !0
  ).to.include.ordered.members(t);
};
f.notIncludeOrderedMembers = function(e, t, n) {
  new d(
    e,
    n,
    f.notIncludeOrderedMembers,
    !0
  ).to.not.include.ordered.members(t);
};
f.includeDeepOrderedMembers = function(e, t, n) {
  new d(
    e,
    n,
    f.includeDeepOrderedMembers,
    !0
  ).to.include.deep.ordered.members(t);
};
f.notIncludeDeepOrderedMembers = function(e, t, n) {
  new d(
    e,
    n,
    f.notIncludeDeepOrderedMembers,
    !0
  ).to.not.include.deep.ordered.members(t);
};
f.oneOf = function(e, t, n) {
  new d(e, n, f.oneOf, !0).to.be.oneOf(t);
};
f.isIterable = function(e, t) {
  if (e == null || !e[Symbol.iterator])
    throw t = t ? `${t} expected ${N(e)} to be an iterable` : `expected ${N(e)} to be an iterable`, new O(t, void 0, f.isIterable);
};
f.changes = function(e, t, n, i) {
  arguments.length === 3 && typeof t == "function" && (i = n, n = null), new d(e, i, f.changes, !0).to.change(t, n);
};
f.changesBy = function(e, t, n, i, o) {
  if (arguments.length === 4 && typeof t == "function") {
    var s = i;
    i = n, o = s;
  } else arguments.length === 3 && (i = n, n = null);
  new d(e, o, f.changesBy, !0).to.change(t, n).by(i);
};
f.doesNotChange = function(e, t, n, i) {
  return arguments.length === 3 && typeof t == "function" && (i = n, n = null), new d(e, i, f.doesNotChange, !0).to.not.change(
    t,
    n
  );
};
f.changesButNotBy = function(e, t, n, i, o) {
  if (arguments.length === 4 && typeof t == "function") {
    var s = i;
    i = n, o = s;
  } else arguments.length === 3 && (i = n, n = null);
  new d(e, o, f.changesButNotBy, !0).to.change(t, n).but.not.by(i);
};
f.increases = function(e, t, n, i) {
  return arguments.length === 3 && typeof t == "function" && (i = n, n = null), new d(e, i, f.increases, !0).to.increase(t, n);
};
f.increasesBy = function(e, t, n, i, o) {
  if (arguments.length === 4 && typeof t == "function") {
    var s = i;
    i = n, o = s;
  } else arguments.length === 3 && (i = n, n = null);
  new d(e, o, f.increasesBy, !0).to.increase(t, n).by(i);
};
f.doesNotIncrease = function(e, t, n, i) {
  return arguments.length === 3 && typeof t == "function" && (i = n, n = null), new d(e, i, f.doesNotIncrease, !0).to.not.increase(
    t,
    n
  );
};
f.increasesButNotBy = function(e, t, n, i, o) {
  if (arguments.length === 4 && typeof t == "function") {
    var s = i;
    i = n, o = s;
  } else arguments.length === 3 && (i = n, n = null);
  new d(e, o, f.increasesButNotBy, !0).to.increase(t, n).but.not.by(i);
};
f.decreases = function(e, t, n, i) {
  return arguments.length === 3 && typeof t == "function" && (i = n, n = null), new d(e, i, f.decreases, !0).to.decrease(t, n);
};
f.decreasesBy = function(e, t, n, i, o) {
  if (arguments.length === 4 && typeof t == "function") {
    var s = i;
    i = n, o = s;
  } else arguments.length === 3 && (i = n, n = null);
  new d(e, o, f.decreasesBy, !0).to.decrease(t, n).by(i);
};
f.doesNotDecrease = function(e, t, n, i) {
  return arguments.length === 3 && typeof t == "function" && (i = n, n = null), new d(e, i, f.doesNotDecrease, !0).to.not.decrease(
    t,
    n
  );
};
f.doesNotDecreaseBy = function(e, t, n, i, o) {
  if (arguments.length === 4 && typeof t == "function") {
    var s = i;
    i = n, o = s;
  } else arguments.length === 3 && (i = n, n = null);
  return new d(e, o, f.doesNotDecreaseBy, !0).to.not.decrease(t, n).by(i);
};
f.decreasesButNotBy = function(e, t, n, i, o) {
  if (arguments.length === 4 && typeof t == "function") {
    var s = i;
    i = n, o = s;
  } else arguments.length === 3 && (i = n, n = null);
  new d(e, o, f.decreasesButNotBy, !0).to.decrease(t, n).but.not.by(i);
};
f.ifError = function(e) {
  if (e)
    throw e;
};
f.isExtensible = function(e, t) {
  new d(e, t, f.isExtensible, !0).to.be.extensible;
};
f.isNotExtensible = function(e, t) {
  new d(e, t, f.isNotExtensible, !0).to.not.be.extensible;
};
f.isSealed = function(e, t) {
  new d(e, t, f.isSealed, !0).to.be.sealed;
};
f.isNotSealed = function(e, t) {
  new d(e, t, f.isNotSealed, !0).to.not.be.sealed;
};
f.isFrozen = function(e, t) {
  new d(e, t, f.isFrozen, !0).to.be.frozen;
};
f.isNotFrozen = function(e, t) {
  new d(e, t, f.isNotFrozen, !0).to.not.be.frozen;
};
f.isEmpty = function(e, t) {
  new d(e, t, f.isEmpty, !0).to.be.empty;
};
f.isNotEmpty = function(e, t) {
  new d(e, t, f.isNotEmpty, !0).to.not.be.empty;
};
f.containsSubset = function(e, t, n) {
  new d(e, n).to.containSubset(t);
};
f.doesNotContainSubset = function(e, t, n) {
  new d(e, n).to.not.containSubset(t);
};
var rl = [
  ["isOk", "ok"],
  ["isNotOk", "notOk"],
  ["throws", "throw"],
  ["throws", "Throw"],
  ["isExtensible", "extensible"],
  ["isNotExtensible", "notExtensible"],
  ["isSealed", "sealed"],
  ["isNotSealed", "notSealed"],
  ["isFrozen", "frozen"],
  ["isNotFrozen", "notFrozen"],
  ["isEmpty", "empty"],
  ["isNotEmpty", "notEmpty"],
  ["isCallable", "isFunction"],
  ["isNotCallable", "isNotFunction"],
  ["containsSubset", "containSubset"]
];
for (let [e, t] of rl)
  f[t] = f[e];
var lo = [];
function ts(e) {
  let t = {
    use: ts,
    AssertionError: O,
    util: It,
    config: X,
    expect: Mt,
    assert: f,
    Assertion: d,
    ...Zo
  };
  return ~lo.indexOf(e) || (e(t, It), lo.push(e)), t;
}
c(ts, "use");
y(ts, "use");

// node_modules/@vitest/utils/dist/source-map.js
var ns = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/", ol = new Uint8Array(64), sl = new Uint8Array(128);
for (let e = 0; e < ns.length; e++) {
  let t = ns.charCodeAt(e);
  ol[e] = t, sl[t] = e;
}
var rs;
(function(e) {
  e[e.Empty = 1] = "Empty", e[e.Hash = 2] = "Hash", e[e.Query = 3] = "Query", e[e.RelativePath = 4] = "RelativePath", e[e.AbsolutePath = 5] = "AbsolutePath", e[e.SchemeRelative = 6] = "SchemeRelative", e[e.Absolute = 7] = "Absolute";
})(rs || (rs = {}));
var al = /^[A-Za-z]:\//;
function cl(e = "") {
  return e && e.replace(/\\/g, "/").replace(al, (t) => t.toUpperCase());
}
c(cl, "normalizeWindowsPath");
var ll = /^[/\\](?![/\\])|^[/\\]{2}(?!\.)|^[A-Za-z]:[/\\]/;
function ul() {
  return typeof process < "u" && typeof process.cwd == "function" ? process.cwd().replace(/\\/g, "/") : "/";
}
c(ul, "cwd");
var fl = /* @__PURE__ */ c(function(...e) {
  e = e.map((i) => cl(i));
  let t = "", n = !1;
  for (let i = e.length - 1; i >= -1 && !n; i--) {
    let o = i >= 0 ? e[i] : ul();
    !o || o.length === 0 || (t = `${o}/${t}`, n = is(o));
  }
  return t = dl(t, !n), n && !is(t) ? `/${t}` : t.length > 0 ? t : ".";
}, "resolve");
function dl(e, t) {
  let n = "", i = 0, o = -1, s = 0, a = null;
  for (let l = 0; l <= e.length; ++l) {
    if (l < e.length)
      a = e[l];
    else {
      if (a === "/")
        break;
      a = "/";
    }
    if (a === "/") {
      if (!(o === l - 1 || s === 1)) if (s === 2) {
        if (n.length < 2 || i !== 2 || n[n.length - 1] !== "." || n[n.length - 2] !== ".") {
          if (n.length > 2) {
            let u = n.lastIndexOf("/");
            u === -1 ? (n = "", i = 0) : (n = n.slice(0, u), i = n.length - 1 - n.lastIndexOf("/")), o = l, s = 0;
            continue;
          } else if (n.length > 0) {
            n = "", i = 0, o = l, s = 0;
            continue;
          }
        }
        t && (n += n.length > 0 ? "/.." : "..", i = 2);
      } else
        n.length > 0 ? n += `/${e.slice(o + 1, l)}` : n = e.slice(o + 1, l), i = l - o - 1;
      o = l, s = 0;
    } else a === "." && s !== -1 ? ++s : s = -1;
  }
  return n;
}
c(dl, "normalizeString");
var is = /* @__PURE__ */ c(function(e) {
  return ll.test(e);
}, "isAbsolute"), os = /^\s*at .*(?:\S:\d+|\(native\))/m, pl = /^(?:eval@)?(?:\[native code\])?$/;
function ss(e) {
  if (!e.includes(":"))
    return [e];
  let n = /(.+?)(?::(\d+))?(?::(\d+))?$/.exec(e.replace(/^\(|\)$/g, ""));
  if (!n)
    return [e];
  let i = n[1];
  if (i.startsWith("async ") && (i = i.slice(6)), i.startsWith("http:") || i.startsWith("https:")) {
    let o = new URL(i);
    o.searchParams.delete("import"), o.searchParams.delete("browserv"), i = o.pathname + o.hash + o.search;
  }
  if (i.startsWith("/@fs/")) {
    let o = /^\/@fs\/[a-zA-Z]:\//.test(i);
    i = i.slice(o ? 5 : 4);
  }
  return [
    i,
    n[2] || void 0,
    n[3] || void 0
  ];
}
c(ss, "extractLocation");
function hl(e) {
  let t = e.trim();
  if (pl.test(t) || (t.includes(" > eval") && (t = t.replace(/ line (\d+)(?: > eval line \d+)* > eval:\d+:\d+/g, ":$1")), !t.includes("@") && !t.includes(":")))
    return null;
  let n = /((.*".+"[^@]*)?[^@]*)(@)/, i = t.match(n), o = i && i[1] ? i[1] : void 0, [s, a, l] = ss(t.replace(n, ""));
  return !s || !a || !l ? null : {
    file: s,
    method: o || "",
    line: Number.parseInt(a),
    column: Number.parseInt(l)
  };
}
c(hl, "parseSingleFFOrSafariStack");
function Br(e) {
  let t = e.trim();
  return os.test(t) ? ml(t) : hl(t);
}
c(Br, "parseSingleStack");
function ml(e) {
  let t = e.trim();
  if (!os.test(t))
    return null;
  t.includes("(eval ") && (t = t.replace(/eval code/g, "eval").replace(/(\(eval at [^()]*)|(,.*$)/g, ""));
  let n = t.replace(/^\s+/, "").replace(/\(eval code/g, "(").replace(/^.*?\s+/, ""), i = n.match(/ (\(.+\)$)/);
  n = i ? n.replace(i[0], "") : n;
  let [o, s, a] = ss(i ? i[1] : n), l = i && n || "", u = o && ["eval", "<anonymous>"].includes(o) ? void 0 : o;
  return !u || !s || !a ? null : (l.startsWith("async ") && (l = l.slice(6)), u.startsWith("file://") && (u = u.slice(7)), u = u.startsWith("node:") || u.startsWith("internal:") ? u : fl(u), l && (l = l.replace(/__vite_ssr_import_\d+__\./g, "")), {
    method: l,
    file: u,
    line: Number.parseInt(s),
    column: Number.parseInt(a)
  });
}
c(ml, "parseSingleV8Stack");

// node_modules/strip-literal/dist/index.mjs
var ds = Zr(fs(), 1);
function yl(e, t) {
  let n = t?.fillChar ?? " ", i = " ", o = "", s = t?.filter ?? (() => !0), a = [];
  for (let l of (0, ds.default)(e, { jsx: !1 })) {
    if (a.push(l), l.type === "SingleLineComment") {
      o += i.repeat(l.value.length);
      continue;
    }
    if (l.type === "MultiLineComment") {
      o += l.value.replace(/[^\n]/g, i);
      continue;
    }
    if (l.type === "StringLiteral") {
      if (!l.closed) {
        o += l.value;
        continue;
      }
      let u = l.value.slice(1, -1);
      if (s(u)) {
        o += l.value[0] + n.repeat(u.length) + l.value[l.value.length - 1];
        continue;
      }
    }
    if (l.type === "NoSubstitutionTemplate") {
      let u = l.value.slice(1, -1);
      if (s(u)) {
        o += `\`${u.replace(/[^\n]/g, n)}\``;
        continue;
      }
    }
    if (l.type === "RegularExpressionLiteral") {
      let u = l.value;
      if (s(u)) {
        o += u.replace(/\/(.*)\/(\w?)$/g, (p, h, g) => `/${n.repeat(h.length)}/${g}`);
        continue;
      }
    }
    if (l.type === "TemplateHead") {
      let u = l.value.slice(1, -2);
      if (s(u)) {
        o += `\`${u.replace(/[^\n]/g, n)}\${`;
        continue;
      }
    }
    if (l.type === "TemplateTail") {
      let u = l.value.slice(0, -2);
      if (s(u)) {
        o += `}${u.replace(/[^\n]/g, n)}\``;
        continue;
      }
    }
    if (l.type === "TemplateMiddle") {
      let u = l.value.slice(1, -2);
      if (s(u)) {
        o += `}${u.replace(/[^\n]/g, n)}\${`;
        continue;
      }
    }
    o += l.value;
  }
  return {
    result: o,
    tokens: a
  };
}
c(yl, "stripLiteralJsTokens");
function ps(e, t) {
  return bl(e, t).result;
}
c(ps, "stripLiteral");
function bl(e, t) {
  return yl(e, t);
}
c(bl, "stripLiteralDetailed");

// node_modules/@vitest/runner/dist/chunk-hooks.js
var Wr = class extends Error {
  static {
    c(this, "PendingError");
  }
  code = "VITEST_PENDING";
  taskId;
  constructor(t, n, i) {
    super(t), this.message = t, this.note = i, this.taskId = n.id;
  }
};
var _l = /* @__PURE__ */ new WeakMap(), ws = /* @__PURE__ */ new WeakMap(), Es = /* @__PURE__ */ new WeakMap();
function Ts(e, t) {
  _l.set(e, t);
}
c(Ts, "setFn");
function wl(e, t) {
  ws.set(e, t);
}
c(wl, "setTestFixture");
function El(e) {
  return ws.get(e);
}
c(El, "getTestFixture");
function vs(e, t) {
  Es.set(e, t);
}
c(vs, "setHooks");
function xs(e) {
  return Es.get(e);
}
c(xs, "getHooks");
function Tl(e, t) {
  let n = t.reduce((s, a) => (s[a.prop] = a, s), {}), i = {};
  e.forEach((s) => {
    let a = n[s.prop] || { ...s };
    i[a.prop] = a;
  });
  for (let s in i) {
    var o;
    let a = i[s];
    a.deps = (o = a.deps) === null || o === void 0 ? void 0 : o.map((l) => i[l.prop]);
  }
  return Object.values(i);
}
c(Tl, "mergeScopedFixtures");
function Ss(e, t, n) {
  let i = [
    "auto",
    "injected",
    "scope"
  ], o = Object.entries(e).map(([s, a]) => {
    let l = { value: a };
    if (Array.isArray(a) && a.length >= 2 && vt(a[1]) && Object.keys(a[1]).some((p) => i.includes(p))) {
      var u;
      Object.assign(l, a[1]);
      let p = a[0];
      l.value = l.injected ? ((u = n.injectValue) === null || u === void 0 ? void 0 : u.call(n, s)) ?? p : p;
    }
    return l.scope = l.scope || "test", l.scope === "worker" && !n.getWorkerContext && (l.scope = "file"), l.prop = s, l.isFn = typeof l.value == "function", l;
  });
  return Array.isArray(t.fixtures) ? t.fixtures = t.fixtures.concat(o) : t.fixtures = o, o.forEach((s) => {
    if (s.isFn) {
      let l = Ps(s.value);
      if (l.length && (s.deps = t.fixtures.filter(({ prop: u }) => u !== s.prop && l.includes(u))), s.scope !== "test") {
        var a;
        (a = s.deps) === null || a === void 0 || a.forEach((u) => {
          if (u.isFn && !(s.scope === "worker" && u.scope === "worker") && !(s.scope === "file" && u.scope !== "test"))
            throw new SyntaxError(`cannot use the ${u.scope} fixture "${u.prop}" inside the ${s.scope} fixture "${s.prop}"`);
        });
      }
    }
  }), t;
}
c(Ss, "mergeContextFixtures");
var Yr = /* @__PURE__ */ new Map(), je = /* @__PURE__ */ new Map();
function Xr(e, t, n) {
  return (i) => {
    let o = i || n;
    if (!o)
      return t({});
    let s = El(o);
    if (!s?.length)
      return t(o);
    let a = Ps(t), l = s.some(({ auto: _ }) => _);
    if (!a.length && !l)
      return t(o);
    Yr.get(o) || Yr.set(o, /* @__PURE__ */ new Map());
    let u = Yr.get(o);
    je.has(o) || je.set(o, []);
    let p = je.get(o), h = s.filter(({ prop: _, auto: T }) => T || a.includes(_)), g = Is(h);
    if (!g.length)
      return t(o);
    async function w() {
      for (let _ of g) {
        if (u.has(_))
          continue;
        let T = await vl(e, _, o, p);
        o[_.prop] = T, u.set(_, T), _.scope === "test" && p.unshift(() => {
          u.delete(_);
        });
      }
    }
    return c(w, "resolveFixtures"), w().then(() => t(o));
  };
}
c(Xr, "withFixtures");
var rn = /* @__PURE__ */ new WeakMap();
function vl(e, t, n, i) {
  var o;
  let s = Bl(n.task.file), a = (o = e.getWorkerContext) === null || o === void 0 ? void 0 : o.call(e);
  if (!t.isFn) {
    var l;
    if (s[l = t.prop] ?? (s[l] = t.value), a) {
      var u;
      a[u = t.prop] ?? (a[u] = t.value);
    }
    return t.value;
  }
  if (t.scope === "test")
    return hs(t.value, n, i);
  if (rn.has(t))
    return rn.get(t);
  let p;
  if (t.scope === "worker") {
    if (!a)
      throw new TypeError("[@vitest/runner] The worker context is not available in the current test runner. Please, provide the `getWorkerContext` method when initiating the runner.");
    p = a;
  } else
    p = s;
  if (t.prop in p)
    return p[t.prop];
  je.has(p) || je.set(p, []);
  let h = je.get(p), g = hs(t.value, p, h).then((w) => (p[t.prop] = w, rn.delete(t), w));
  return rn.set(t, g), g;
}
c(vl, "resolveFixtureValue");
async function hs(e, t, n) {
  let i = St(), o = !1, s = e(t, async (a) => {
    o = !0, i.resolve(a);
    let l = St();
    n.push(async () => {
      l.resolve(), await s;
    }), await l;
  }).catch((a) => {
    if (!o) {
      i.reject(a);
      return;
    }
    throw a;
  });
  return i;
}
c(hs, "resolveFixtureFunction");
function Is(e, t = /* @__PURE__ */ new Set(), n = []) {
  return e.forEach((i) => {
    if (!n.includes(i)) {
      if (!i.isFn || !i.deps) {
        n.push(i);
        return;
      }
      if (t.has(i))
        throw new Error(`Circular fixture dependency detected: ${i.prop} <- ${[...t].reverse().map((o) => o.prop).join(" <- ")}`);
      t.add(i), Is(i.deps, t, n), n.push(i), t.clear();
    }
  }), n;
}
c(Is, "resolveDeps");
function Ps(e) {
  let t = ps(e.toString());
  /__async\((?:this|null), (?:null|arguments|\[[_0-9, ]*\]), function\*/.test(t) && (t = t.split(/__async\((?:this|null),/)[1]);
  let n = t.match(/[^(]*\(([^)]*)/);
  if (!n)
    return [];
  let i = ms(n[1]);
  if (!i.length)
    return [];
  let o = i[0];
  if ("__VITEST_FIXTURE_INDEX__" in e && (o = i[e.__VITEST_FIXTURE_INDEX__], !o))
    return [];
  if (!(o.startsWith("{") && o.endsWith("}")))
    throw new Error(`The first argument inside a fixture must use object destructuring pattern, e.g. ({ test } => {}). Instead, received "${o}".`);
  let s = o.slice(1, -1).replace(/\s/g, ""), a = ms(s).map((u) => u.replace(/:.*|=.*/g, "")), l = a.at(-1);
  if (l && l.startsWith("..."))
    throw new Error(`Rest parameters are not supported in fixtures, received "${l}".`);
  return a;
}
c(Ps, "getUsedProps");
function ms(e) {
  let t = [], n = [], i = 0;
  for (let s = 0; s < e.length; s++)
    if (e[s] === "{" || e[s] === "[")
      n.push(e[s] === "{" ? "}" : "]");
    else if (e[s] === n[n.length - 1])
      n.pop();
    else if (!n.length && e[s] === ",") {
      let a = e.substring(i, s).trim();
      a && t.push(a), i = s + 1;
    }
  let o = e.substring(i).trim();
  return o && t.push(o), t;
}
c(ms, "splitByComma");
var xl;
function Kr() {
  return xl;
}
c(Kr, "getCurrentTest");
function Gr(e, t) {
  function n(o) {
    let s = /* @__PURE__ */ c(function(...a) {
      return t.apply(o, a);
    }, "chain");
    Object.assign(s, t), s.withContext = () => s.bind(o), s.setContext = (a, l) => {
      o[a] = l;
    }, s.mergeContext = (a) => {
      Object.assign(o, a);
    };
    for (let a of e)
      Object.defineProperty(s, a, { get() {
        return n({
          ...o,
          [a]: !0
        });
      } });
    return s;
  }
  c(n, "create");
  let i = n({});
  return i.fn = t, i;
}
c(Gr, "createChainable");
var Ie = $l(), As = Hr(function(e, t, n) {
  if (Kr())
    throw new Error('Calling the test function inside another test function is not allowed. Please put it inside "describe" or "suite" so it can be properly collected.');
  ke().test.fn.call(this, he(e), t, n);
});
var D, Cs, Sl;
function $s(e, t) {
  if (!e)
    throw new Error(`Vitest failed to find ${t}. This is a bug in Vitest. Please, open an issue with reproduction.`);
}
c($s, "assert");
function Il() {
  return Sl;
}
c(Il, "getTestFilepath");
function an() {
  return $s(D, "the runner"), D;
}
c(an, "getRunner");
function ke() {
  let e = me.currentSuite || Cs;
  return $s(e, "the current suite"), e;
}
c(ke, "getCurrentSuite");
function Pl() {
  return {
    beforeAll: [],
    afterAll: [],
    beforeEach: [],
    afterEach: []
  };
}
c(Pl, "createSuiteHooks");
function Pe(e, t) {
  let n = {}, i = /* @__PURE__ */ c(() => {
  }, "fn");
  if (typeof t == "object") {
    if (typeof e == "object")
      throw new TypeError("Cannot use two objects as arguments. Please provide options and a function callback in that order.");
    console.warn("Using an object as a third argument is deprecated. Vitest 4 will throw an error if the third argument is not a timeout number. Please use the second argument for options. See more at https://vitest.dev/guide/migration"), n = t;
  } else typeof t == "number" ? n = { timeout: t } : typeof e == "object" && (n = e);
  if (typeof e == "function") {
    if (typeof t == "function")
      throw new TypeError("Cannot use two functions as arguments. Please use the second argument for options.");
    i = e;
  } else typeof t == "function" && (i = t);
  return {
    options: n,
    handler: i
  };
}
c(Pe, "parseArguments");
function Al(e, t = () => {
}, n, i, o, s) {
  let a = [], l;
  _(!0);
  let u = /* @__PURE__ */ c(function(E = "", v = {}) {
    var S;
    let I = v?.timeout ?? D.config.testTimeout, J = {
      id: "",
      name: E,
      suite: (S = me.currentSuite) === null || S === void 0 ? void 0 : S.suite,
      each: v.each,
      fails: v.fails,
      context: void 0,
      type: "test",
      file: void 0,
      timeout: I,
      retry: v.retry ?? D.config.retry,
      repeats: v.repeats,
      mode: v.only ? "only" : v.skip ? "skip" : v.todo ? "todo" : "run",
      meta: v.meta ?? /* @__PURE__ */ Object.create(null),
      annotations: []
    }, K = v.handler;
    (v.concurrent || !v.sequential && D.config.sequence.concurrent) && (J.concurrent = !0), J.shuffle = o?.shuffle;
    let oe = Ll(J, D);
    Object.defineProperty(J, "context", {
      value: oe,
      enumerable: !1
    }), wl(oe, v.fixtures);
    let nt = Error.stackTraceLimit;
    Error.stackTraceLimit = 15;
    let P = new Error("STACK_TRACE_ERROR");
    if (Error.stackTraceLimit = nt, K && Ts(J, Ae(Cl(Xr(D, K, oe), J), I, !1, P, ($, ge) => tt([oe], ge))), D.config.includeTaskLocation) {
      let $ = P.stack, ge = gs($);
      ge && (J.location = ge);
    }
    return a.push(J), J;
  }, "task"), p = Hr(function(E, v, S) {
    let { options: I, handler: J } = Pe(v, S);
    typeof o == "object" && (I = Object.assign({}, o, I)), I.concurrent = this.concurrent || !this.sequential && I?.concurrent, I.sequential = this.sequential || !this.concurrent && I?.sequential;
    let K = u(he(E), {
      ...this,
      ...I,
      handler: J
    });
    K.type = "test";
  }), h = s, g = {
    type: "collector",
    name: e,
    mode: n,
    suite: l,
    options: o,
    test: p,
    tasks: a,
    collect: b,
    task: u,
    clear: T,
    on: w,
    fixtures() {
      return h;
    },
    scoped(E) {
      let v = Ss(E, { fixtures: h }, D);
      v.fixtures && (h = v.fixtures);
    }
  };
  function w(E, ...v) {
    xs(l)[E].push(...v);
  }
  c(w, "addHook");
  function _(E) {
    var v;
    if (typeof o == "number" && (o = { timeout: o }), l = {
      id: "",
      type: "suite",
      name: e,
      suite: (v = me.currentSuite) === null || v === void 0 ? void 0 : v.suite,
      mode: n,
      each: i,
      file: void 0,
      shuffle: o?.shuffle,
      tasks: [],
      meta: /* @__PURE__ */ Object.create(null),
      concurrent: o?.concurrent
    }, D && E && D.config.includeTaskLocation) {
      let S = Error.stackTraceLimit;
      Error.stackTraceLimit = 15;
      let I = new Error("stacktrace").stack;
      Error.stackTraceLimit = S;
      let J = gs(I);
      J && (l.location = J);
    }
    vs(l, Pl());
  }
  c(_, "initSuite");
  function T() {
    a.length = 0, _(!1);
  }
  c(T, "clear");
  async function b(E) {
    if (!E)
      throw new TypeError("File is required to collect tasks.");
    t && await Fl(g, () => t(p));
    let v = [];
    for (let S of a)
      v.push(S.type === "collector" ? await S.collect(E) : S);
    return l.file = E, l.tasks = v, v.forEach((S) => {
      S.file = E;
    }), l;
  }
  return c(b, "collect"), kl(g), g;
}
c(Al, "createSuiteCollector");
function Cl(e, t) {
  return async (...n) => {
    let i = await e(...n);
    if (t.promises) {
      let s = (await Promise.allSettled(t.promises)).map((a) => a.status === "rejected" ? a.reason : void 0).filter(Boolean);
      if (s.length)
        throw s;
    }
    return i;
  };
}
c(Cl, "withAwaitAsyncAssertions");
function $l() {
  function e(t, n, i) {
    var o;
    let s = this.only ? "only" : this.skip ? "skip" : this.todo ? "todo" : "run", a = me.currentSuite || Cs, { options: l, handler: u } = Pe(n, i), p = l.concurrent || this.concurrent || l.sequential === !1, h = l.sequential || this.sequential || l.concurrent === !1;
    l = {
      ...a?.options,
      ...l,
      shuffle: this.shuffle ?? l.shuffle ?? (a == null || (o = a.options) === null || o === void 0 ? void 0 : o.shuffle) ?? D?.config.sequence.shuffle
    };
    let g = p || l.concurrent && !h, w = h || l.sequential && !p;
    return l.concurrent = g && !w, l.sequential = w && !g, Al(he(t), u, s, this.each, l, a?.fixtures());
  }
  return c(e, "suiteFn"), e.each = function(t, ...n) {
    let i = this.withContext();
    return this.setContext("each", !0), Array.isArray(t) && n.length && (t = sn(t, n)), (o, s, a) => {
      let l = he(o), u = t.every(Array.isArray), { options: p, handler: h } = Pe(s, a), g = typeof s == "function" && typeof a == "object";
      t.forEach((w, _) => {
        let T = Array.isArray(w) ? w : [w];
        g ? u ? i(ie(l, T, _), () => h(...T), p) : i(ie(l, T, _), () => h(w), p) : u ? i(ie(l, T, _), p, () => h(...T)) : i(ie(l, T, _), p, () => h(w));
      }), this.setContext("each", void 0);
    };
  }, e.for = function(t, ...n) {
    return Array.isArray(t) && n.length && (t = sn(t, n)), (i, o, s) => {
      let a = he(i), { options: l, handler: u } = Pe(o, s);
      t.forEach((p, h) => {
        Ie(ie(a, Tt(p), h), l, () => u(p));
      });
    };
  }, e.skipIf = (t) => t ? Ie.skip : Ie, e.runIf = (t) => t ? Ie : Ie.skip, Gr([
    "concurrent",
    "sequential",
    "shuffle",
    "skip",
    "only",
    "todo"
  ], e);
}
c($l, "createSuite");
function Ns(e, t) {
  let n = e;
  n.each = function(o, ...s) {
    let a = this.withContext();
    return this.setContext("each", !0), Array.isArray(o) && s.length && (o = sn(o, s)), (l, u, p) => {
      let h = he(l), g = o.every(Array.isArray), { options: w, handler: _ } = Pe(u, p), T = typeof u == "function" && typeof p == "object";
      o.forEach((b, E) => {
        let v = Array.isArray(b) ? b : [b];
        T ? g ? a(ie(h, v, E), () => _(...v), w) : a(ie(h, v, E), () => _(b), w) : g ? a(ie(h, v, E), w, () => _(...v)) : a(ie(h, v, E), w, () => _(b));
      }), this.setContext("each", void 0);
    };
  }, n.for = function(o, ...s) {
    let a = this.withContext();
    return Array.isArray(o) && s.length && (o = sn(o, s)), (l, u, p) => {
      let h = he(l), { options: g, handler: w } = Pe(u, p);
      o.forEach((_, T) => {
        let b = /* @__PURE__ */ c((E) => w(_, E), "handlerWrapper");
        b.__VITEST_FIXTURE_INDEX__ = 1, b.toString = () => w.toString(), a(ie(h, Tt(_), T), g, b);
      });
    };
  }, n.skipIf = function(o) {
    return o ? this.skip : this;
  }, n.runIf = function(o) {
    return o ? this : this.skip;
  }, n.scoped = function(o) {
    ke().scoped(o);
  }, n.extend = function(o) {
    let s = Ss(o, t || {}, D), a = e;
    return Hr(function(l, u, p) {
      let g = ke().fixtures(), w = { ...this };
      g && (w.fixtures = Tl(w.fixtures || [], g));
      let { handler: _, options: T } = Pe(u, p), b = T.timeout ?? D?.config.testTimeout;
      a.call(w, he(l), _, b);
    }, s);
  };
  let i = Gr([
    "concurrent",
    "sequential",
    "skip",
    "only",
    "todo",
    "fails"
  ], n);
  return t && i.mergeContext(t), i;
}
c(Ns, "createTaskCollector");
function Hr(e, t) {
  return Ns(e, t);
}
c(Hr, "createTest");
function he(e) {
  return typeof e == "string" ? e : typeof e == "function" ? e.name || "<anonymous>" : String(e);
}
c(he, "formatName");
function ie(e, t, n) {
  (e.includes("%#") || e.includes("%$")) && (e = e.replace(/%%/g, "__vitest_escaped_%__").replace(/%#/g, `${n}`).replace(/%\$/g, `${n + 1}`).replace(/__vitest_escaped_%__/g, "%%"));
  let i = e.split("%").length - 1;
  e.includes("%f") && (e.match(/%f/g) || []).forEach((l, u) => {
    if (zn(t[u]) || Object.is(t[u], -0)) {
      let p = 0;
      e = e.replace(/%f/g, (h) => (p++, p === u + 1 ? "-%f" : h));
    }
  });
  let o = Ln(e, ...t.slice(0, i)), s = vt(t[0]);
  return o = o.replace(/\$([$\w.]+)/g, (a, l) => {
    var u;
    let p = /^\d+$/.test(l);
    if (!s && !p)
      return `$${l}`;
    let h = p ? xt(t, l) : void 0, g = s ? xt(t[0], l, h) : h;
    return qn(g, { truncate: D == null || (u = D.config) === null || u === void 0 || (u = u.chaiConfig) === null || u === void 0 ? void 0 : u.truncateThreshold });
  }), o;
}
c(ie, "formatTitle");
function sn(e, t) {
  let n = e.join("").trim().replace(/ /g, "").split(`
`).map((o) => o.split("|"))[0], i = [];
  for (let o = 0; o < Math.floor(t.length / n.length); o++) {
    let s = {};
    for (let a = 0; a < n.length; a++)
      s[n[a]] = t[o * n.length + a];
    i.push(s);
  }
  return i;
}
c(sn, "formatTemplateString");
function gs(e) {
  let t = Il(), n = e.split(`
`).slice(1);
  for (let i of n) {
    let o = Br(i);
    if (o && o.file === t)
      return {
        line: o.line,
        column: o.column
      };
  }
}
c(gs, "findTestFileStackTrace");
var Ad = globalThis.performance ? globalThis.performance.now.bind(globalThis.performance) : Date.now;
var Cd = globalThis.performance ? globalThis.performance.now.bind(globalThis.performance) : Date.now, Nl = Date.now, { clearTimeout: Ol, setTimeout: Rl } = Un();
var Jr = /* @__PURE__ */ new Map(), ys = [], on = [];
function Os(e) {
  if (Jr.size) {
    var t;
    let n = Array.from(Jr).map(([o, s]) => [
      o,
      s[0],
      s[1]
    ]), i = (t = e.onTaskUpdate) === null || t === void 0 ? void 0 : t.call(e, n, ys);
    i && (on.push(i), i.then(() => on.splice(on.indexOf(i), 1), () => {
    })), ys.length = 0, Jr.clear();
  }
}
c(Os, "sendTasksUpdate");
async function Ml(e) {
  Os(e), await Promise.all(on);
}
c(Ml, "finishSendTasksUpdate");
function jl(e, t) {
  let n = 0, i;
  return /* @__PURE__ */ c(function o(...s) {
    let a = Nl();
    if (a - n > t)
      return n = a, Ol(i), i = void 0, e.apply(this, s);
    i ?? (i = Rl(() => o.bind(this)(...s), t));
  }, "call");
}
c(jl, "throttle");
var $d = jl(Os, 100);
var bs = Date.now, me = {
  tasks: [],
  currentSuite: null
};
function kl(e) {
  var t;
  (t = me.currentSuite) === null || t === void 0 || t.tasks.push(e);
}
c(kl, "collectTask");
async function Fl(e, t) {
  let n = me.currentSuite;
  me.currentSuite = e, await t(), me.currentSuite = n;
}
c(Fl, "runWithSuite");
function Ae(e, t, n = !1, i, o) {
  if (t <= 0 || t === Number.POSITIVE_INFINITY)
    return e;
  let { setTimeout: s, clearTimeout: a } = Un();
  return /* @__PURE__ */ c(function(...u) {
    let p = bs(), h = an();
    return h._currentTaskStartTime = p, h._currentTaskTimeout = t, new Promise((g, w) => {
      var _;
      let T = s(() => {
        a(T), b();
      }, t);
      (_ = T.unref) === null || _ === void 0 || _.call(T);
      function b() {
        let S = ql(n, t, i);
        o?.(u, S), w(S);
      }
      c(b, "rejectTimeoutError");
      function E(S) {
        if (h._currentTaskStartTime = void 0, h._currentTaskTimeout = void 0, a(T), bs() - p >= t) {
          b();
          return;
        }
        g(S);
      }
      c(E, "resolve");
      function v(S) {
        h._currentTaskStartTime = void 0, h._currentTaskTimeout = void 0, a(T), w(S);
      }
      c(v, "reject");
      try {
        let S = e(...u);
        typeof S == "object" && S != null && typeof S.then == "function" ? S.then(E, v) : E(S);
      } catch (S) {
        v(S);
      }
    });
  }, "runWithTimeout");
}
c(Ae, "withTimeout");
var Vr = /* @__PURE__ */ new WeakMap();
function tt([e], t) {
  e && Dl(e, t);
}
c(tt, "abortIfTimeout");
function Dl(e, t) {
  let n = Vr.get(e);
  n?.abort(t);
}
c(Dl, "abortContextSignal");
function Ll(e, t) {
  var n;
  let i = /* @__PURE__ */ c(function() {
    throw new Error("done() callback is deprecated, use promise instead");
  }, "context"), o = Vr.get(i);
  o || (o = new AbortController(), Vr.set(i, o)), i.signal = o.signal, i.task = e, i.skip = (a, l) => {
    if (a !== !1)
      throw e.result ?? (e.result = { state: "skip" }), e.result.pending = !0, new Wr("test is skipped; abort execution", e, typeof a == "string" ? a : l);
  };
  async function s(a, l, u, p) {
    let h = {
      message: a,
      type: u || "notice"
    };
    if (p) {
      if (!p.body && !p.path)
        throw new TypeError("Test attachment requires body or path to be set. Both are missing.");
      if (p.body && p.path)
        throw new TypeError('Test attachment requires only one of "body" or "path" to be set. Both are specified.');
      h.attachment = p, p.body instanceof Uint8Array && (p.body = Ul(p.body));
    }
    if (l && (h.location = l), !t.onTestAnnotate)
      throw new Error("Test runner doesn't support test annotations.");
    await Ml(t);
    let g = await t.onTestAnnotate(e, h);
    return e.annotations.push(g), g;
  }
  return c(s, "annotate"), i.annotate = (a, l, u) => {
    if (e.result && e.result.state !== "run")
      throw new Error(`Cannot annotate tests outside of the test run. The test "${e.name}" finished running with the "${e.result.state}" state already.`);
    let p, h = new Error("STACK_TRACE").stack, g = h.includes("STACK_TRACE") ? 2 : 1, w = h.split(`
`)[g], _ = Br(w);
    return _ && (p = {
      file: _.file,
      line: _.line,
      column: _.column
    }), typeof l == "object" ? _s(e, s(a, p, void 0, l)) : _s(e, s(a, p, l, u));
  }, i.onTestFailed = (a, l) => {
    e.onFailed || (e.onFailed = []), e.onFailed.push(Ae(a, l ?? t.config.hookTimeout, !0, new Error("STACK_TRACE_ERROR"), (u, p) => o.abort(p)));
  }, i.onTestFinished = (a, l) => {
    e.onFinished || (e.onFinished = []), e.onFinished.push(Ae(a, l ?? t.config.hookTimeout, !0, new Error("STACK_TRACE_ERROR"), (u, p) => o.abort(p)));
  }, ((n = t.extendTaskContext) === null || n === void 0 ? void 0 : n.call(t, i)) || i;
}
c(Ll, "createTestContext");
function ql(e, t, n) {
  let i = `${e ? "Hook" : "Test"} timed out in ${t}ms.
If this is a long-running ${e ? "hook" : "test"}, pass a timeout value as the last argument or configure it globally with "${e ? "hookTimeout" : "testTimeout"}".`, o = new Error(i);
  return n?.stack && (o.stack = n.stack.replace(o.message, n.message)), o;
}
c(ql, "makeTimeoutError");
var zl = /* @__PURE__ */ new WeakMap();
function Bl(e) {
  let t = zl.get(e);
  if (!t)
    throw new Error(`Cannot find file context for ${e.name}`);
  return t;
}
c(Bl, "getFileContext");
var Z = [];
for (let e = 65; e < 91; e++)
  Z.push(String.fromCharCode(e));
for (let e = 97; e < 123; e++)
  Z.push(String.fromCharCode(e));
for (let e = 0; e < 10; e++)
  Z.push(e.toString(10));
function Ul(e) {
  let t = "", n = e.byteLength;
  for (let i = 0; i < n; i += 3)
    if (n === i + 1) {
      let o = (e[i] & 252) >> 2, s = (e[i] & 3) << 4;
      t += Z[o], t += Z[s], t += "==";
    } else if (n === i + 2) {
      let o = (e[i] & 252) >> 2, s = (e[i] & 3) << 4 | (e[i + 1] & 240) >> 4, a = (e[i + 1] & 15) << 2;
      t += Z[o], t += Z[s], t += Z[a], t += "=";
    } else {
      let o = (e[i] & 252) >> 2, s = (e[i] & 3) << 4 | (e[i + 1] & 240) >> 4, a = (e[i + 1] & 15) << 2 | (e[i + 2] & 192) >> 6, l = e[i + 2] & 63;
      t += Z[o], t += Z[s], t += Z[a], t += Z[l];
    }
  return t;
}
c(Ul, "encodeUint8Array");
function _s(e, t) {
  return t = t.finally(() => {
    if (!e.promises)
      return;
    let n = e.promises.indexOf(t);
    n !== -1 && e.promises.splice(n, 1);
  }), e.promises || (e.promises = []), e.promises.push(t), t;
}
c(_s, "recordAsyncAnnotation");
function et() {
  return an().config.hookTimeout;
}
c(et, "getDefaultHookTimeout");
var Yl = Symbol.for("VITEST_CLEANUP_TIMEOUT"), Jl = Symbol.for("VITEST_CLEANUP_STACK_TRACE");
function cn(e, t = et()) {
  Ue(e, '"beforeEach" callback', ["function"]);
  let n = new Error("STACK_TRACE_ERROR"), i = an();
  return ke().on("beforeEach", Object.assign(Ae(Xr(i, e), t ?? et(), !0, n, tt), {
    [Yl]: t,
    [Jl]: n
  }));
}
c(cn, "beforeEach");
function ln(e, t) {
  Ue(e, '"afterEach" callback', ["function"]);
  let n = an();
  return ke().on("afterEach", Ae(Xr(n, e), t ?? et(), !0, new Error("STACK_TRACE_ERROR"), tt));
}
c(ln, "afterEach");
var Rs = js("onTestFailed", (e, t, n) => {
  e.onFailed || (e.onFailed = []), e.onFailed.push(Ae(t, n ?? et(), !0, new Error("STACK_TRACE_ERROR"), tt));
}), Ms = js("onTestFinished", (e, t, n) => {
  e.onFinished || (e.onFinished = []), e.onFinished.push(Ae(t, n ?? et(), !0, new Error("STACK_TRACE_ERROR"), tt));
});
function js(e, t) {
  return (n, i) => {
    Ue(n, `"${e}" callback`, ["function"]);
    let o = Kr();
    if (!o)
      throw new Error(`Hook ${e}() can only be called inside a test`);
    return t(o, n, i);
  };
}
c(js, "createTestHook");

// node_modules/vitest/dist/index.js
var Ql = Zr(Ys(), 1);

// convex/testing/testIntegration.ts
Ws();

// convex/schema.ts
si();
ei();
var Js = oi({
  // 統一ユーザーテーブル（Clerk認証ベース）
  users: C({
    // Clerk認証情報
    clerkUserId: r.string(),
    // Clerkの固有ID
    tokenIdentifier: r.string(),
    // ClerkのJWTの `sub` (subject) claim
    email: r.string(),
    emailVerified: r.boolean(),
    // ユーザープロフィール
    name: r.string(),
    firstName: r.optional(r.string()),
    lastName: r.optional(r.string()),
    imageUrl: r.optional(r.string()),
    // 企業関連情報
    employeeId: r.optional(r.string()),
    department: r.optional(r.string()),
    position: r.optional(r.string()),
    role: r.string(),
    // 'admin', 'trainer', 'employee'
    managerId: r.optional(r.id("users")),
    // 上長のユーザーID（自己参照）
    // アカウント管理
    isActive: r.boolean(),
    joinDate: r.number(),
    lastLoginAt: r.optional(r.number())
    // Removed migration fields: migratedFromBetterAuth, migrationDate, legacyUserId
    // Phase 2 cleanup completed - these fields were safely removed as migration is complete
  }).index("by_clerk_user_id", ["clerkUserId"]).index("by_token", ["tokenIdentifier"]).index("by_email", ["email"]).index("by_employee_id", ["employeeId"]).index("by_department", ["department"]).index("by_role", ["role"]).index("by_is_active", ["isActive"]).index("by_manager_id", ["managerId"]),
  // 従来システム（段階的廃止予定）
  // PHASE 3 COMPLETED: legacy_users table safely deleted
  // All legacy user data migrated to unified 'users' table
  // Migration completed: Authentication system fully unified
  // Clerkセッション管理（統一）
  userSessions: C({
    user_id: r.id("users"),
    // 統一ユーザーテーブル参照
    clerk_session_id: r.string(),
    device_info: r.optional(r.string()),
    ip_address: r.optional(r.string()),
    user_agent: r.optional(r.string()),
    expires_at: r.number(),
    last_activity_at: r.number(),
    is_active: r.boolean()
  }).index("by_user_id", ["user_id"]).index("by_clerk_session_id", ["clerk_session_id"]).index("by_is_active", ["is_active"]),
  // パスキー認証情報（Clerk統合準備）
  // PHASE 1 COMPLETED: passkeyCredentials table safely deleted
  // All passkey authentication now handled through Clerk
  // Migration completed: Authentication system fully unified
  // --- Better Auth Tables (DEPRECATED - 段階的廃止予定) ---
  // PHASE 3 COMPLETED: better_auth_users table safely deleted
  // All references migrated to unified 'users' table
  // Migration completed: All active functionality now uses unified authentication
  // --- 移行管理テーブル ---
  // PHASE 1 COMPLETED: userMigrationLog table safely deleted
  // All migration tracking completed and archived
  // Migration completed: Historical migration logs no longer needed
  // PHASE 3 COMPLETED: userMapping table safely deleted
  // User mapping functionality was unused as auth migration completed
  // Migration completed: User mapping system removed
  trainings: C({
    title: r.string(),
    description: r.optional(r.string()),
    category: r.optional(r.string()),
    duration_minutes: r.optional(r.number()),
    thumbnail_url: r.optional(r.string()),
    priority: r.optional(r.string())
  }),
  // 新しいコース管理システム
  courses: C({
    title: r.string(),
    description: r.string(),
    category: r.string(),
    duration_minutes: r.number(),
    thumbnail_url: r.optional(r.string()),
    is_published: r.boolean(),
    created_by: r.id("users"),
    modules_count: r.number()
  }).index("by_title", ["title"]).index("by_category", ["category"]).index("by_creator", ["created_by"]).index("by_published", ["is_published"]).index("by_category_published", ["category", "is_published"]),
  modules: C({
    course_id: r.id("courses"),
    title: r.string(),
    description: r.string(),
    duration_minutes: r.number(),
    order_index: r.number(),
    content_type: r.string(),
    // "video", "text", "quiz", etc.
    content_url: r.optional(r.string()),
    is_published: r.boolean()
  }).index("by_course", ["course_id"]).index("by_course_order", ["course_id", "order_index"]).index("by_content_type", ["content_type"]),
  trainingModules: C({
    training_id: r.id("trainings"),
    title: r.string(),
    description: r.optional(r.string()),
    duration_minutes: r.optional(r.number()),
    order_index: r.number(),
    quiz_generation_status: r.optional(r.string()),
    quiz_generation_started_at: r.optional(r.number()),
    quiz_generation_completed_at: r.optional(r.number()),
    quiz_generation_error: r.optional(r.string()),
    // Phase2統合用フィールド（trainingModules+moduleContentsマージ）
    content: r.optional(r.string()),
    content_type: r.optional(r.string()),
    file_url: r.optional(r.string()),
    file_type: r.optional(r.string()),
    merged_from_content: r.optional(r.string()),
    // 統合元moduleContentのID
    merge_type: r.optional(r.string()),
    // "1to1", "1toN_main", "1toN_child"
    merge_timestamp: r.optional(r.number()),
    // 階層管理フィールド
    parent_module_id: r.optional(r.id("trainingModules")),
    child_modules_count: r.optional(r.number()),
    original_order_index: r.optional(r.number())
  }).index("by_training_id", ["training_id"]).index("by_parent_module", ["parent_module_id"]),
  moduleContents: C({
    module_id: r.id("trainingModules"),
    title: r.string(),
    content: r.optional(r.string()),
    content_type: r.string(),
    file_url: r.optional(r.string()),
    file_type: r.optional(r.string()),
    order_index: r.number()
  }).index("by_module_id", ["module_id"]),
  trainingProgress: C({
    user_id: r.id("users"),
    training_id: r.id("trainings"),
    module_id: r.optional(r.id("trainingModules")),
    status: r.union(
      r.literal("not_started"),
      r.literal("in_progress"),
      r.literal("completed"),
      r.literal("paused")
    ),
    progress_percentage: r.number(),
    started_at: r.optional(r.number()),
    completed_at: r.optional(r.number())
    // Removed migration field: new_user_id (Phase 2 cleanup - migration complete)
  }).index("by_user_training", ["user_id", "training_id"]).index("by_user_module", ["user_id", "module_id"]),
  videos: C({
    user_id: r.id("users"),
    title: r.string(),
    description: r.optional(r.string()),
    type: r.optional(r.string()),
    url: r.string(),
    thumbnail_url: r.optional(r.string()),
    duration_seconds: r.optional(r.number()),
    // ラベル機能
    labels: r.optional(r.array(r.string())),
    // 面談者情報
    intervieweeName: r.optional(r.string()),
    // 面談者名
    // アップロード関連フィールド
    file_size: r.optional(r.number()),
    content_type: r.optional(r.string()),
    processing_status: r.optional(
      r.union(
        r.literal("pending"),
        r.literal("processing"),
        r.literal("completed"),
        r.literal("failed")
      )
    ),
    error_message: r.optional(r.string()),
    // Convexストレージ関連フィールド
    storage_id: r.optional(r.id("_storage")),
    // GCS関連フィールド
    gcs_file_path: r.optional(r.string()),
    file_upload_id: r.optional(r.id("fileUploads")),
    // ファイルグループ機能
    upload_session_id: r.optional(r.string()),
    // 同一セッションでアップロードされたファイルをグループ化
    is_group_primary: r.optional(r.boolean()),
    // グループの代表ファイル
    // Phase2統合用フィールド（videos+fileUploadsマージ）
    original_filename: r.optional(r.string()),
    view_count: r.optional(r.number()),
    resolution: r.optional(r.string()),
    quality_score: r.optional(r.number()),
    uploaded_at: r.optional(r.number()),
    completed_at: r.optional(r.number()),
    merged_from_file_upload: r.optional(r.string()),
    // 統合元fileUploadのID
    merge_timestamp: r.optional(r.number()),
    group_order: r.optional(r.number())
    // グループ内での順序
    // Removed migration field: new_user_id (Phase 2 cleanup - migration complete)
  }).index("by_user_id", ["user_id"]).index("by_processing_status", ["processing_status"]).index("by_type", ["type"]).index("by_upload_session", ["upload_session_id"]).index("by_user_and_session", ["user_id", "upload_session_id"]).index("by_session_and_primary", ["upload_session_id", "is_group_primary"]).searchIndex("search_title", {
    searchField: "title",
    filterFields: ["type", "user_id"]
  }).searchIndex("search_description", {
    searchField: "description",
    filterFields: ["type", "user_id"]
  }),
  // PHASE 1 COMPLETED: userIdMapping table safely deleted
  // All user ID mapping completed and archived
  // Migration completed: User mapping no longer needed
  evaluations: C({
    transcription_id: r.id("transcriptions"),
    video_id: r.optional(r.id("videos")),
    user_id: r.id("users"),
    // Updated from better_auth_users to users (migration complete)
    external_id: r.optional(r.string()),
    // 外部ID（UUID）
    video_type: r.union(
      r.literal("M&A\u30ED\u30FC\u30EB\u30D7\u30EC\u30A4"),
      r.literal("\u521D\u56DE\u9762\u8AC7"),
      r.literal("AD\u7DE0\u7D50\u63D0\u6848"),
      r.literal("AD\u7DE0\u7D50\u63D0\u6848"),
      r.literal("\u4F01\u696D\u6982\u8981\u66F8\u63D0\u6848"),
      r.literal("\u8B72\u6E21\u67B6\u96FB")
    ),
    status: r.union(
      r.literal("pending"),
      r.literal("processing"),
      r.literal("completed"),
      r.literal("failed")
    ),
    scores: r.optional(r.record(r.string(), r.number())),
    // 型安全なスコア
    total_score: r.optional(r.number()),
    // 総合スコア（0-100）
    comments: r.optional(r.string()),
    // 初回面談評価項目
    hearingAbility: r.optional(r.number()),
    hearingAbility_analysis: r.optional(r.string()),
    hearingAbility_strength: r.optional(r.string()),
    hearingAbility_weakness: r.optional(r.string()),
    problemSetting: r.optional(r.number()),
    problemSetting_analysis: r.optional(r.string()),
    problemSetting_strength: r.optional(r.string()),
    problemSetting_weakness: r.optional(r.string()),
    knowledge: r.optional(r.number()),
    knowledge_analysis: r.optional(r.string()),
    knowledge_strength: r.optional(r.string()),
    knowledge_weakness: r.optional(r.string()),
    negotiation: r.optional(r.number()),
    negotiation_analysis: r.optional(r.string()),
    negotiation_strength: r.optional(r.string()),
    negotiation_weakness: r.optional(r.string()),
    businessManners: r.optional(r.number()),
    businessManners_analysis: r.optional(r.string()),
    businessManners_strength: r.optional(r.string()),
    businessManners_weakness: r.optional(r.string()),
    // AD締結提案評価項目
    adHearingAbility: r.optional(r.number()),
    adHearingAbility_analysis: r.optional(r.string()),
    adHearingAbility_strength: r.optional(r.string()),
    adHearingAbility_weakness: r.optional(r.string()),
    adKnowledge: r.optional(r.number()),
    adKnowledge_analysis: r.optional(r.string()),
    adKnowledge_strength: r.optional(r.string()),
    adKnowledge_weakness: r.optional(r.string()),
    adProposalAbility: r.optional(r.number()),
    adProposalAbility_analysis: r.optional(r.string()),
    adProposalAbility_strength: r.optional(r.string()),
    adProposalAbility_weakness: r.optional(r.string()),
    adNegotiation: r.optional(r.number()),
    adNegotiation_analysis: r.optional(r.string()),
    adNegotiation_strength: r.optional(r.string()),
    adNegotiation_weakness: r.optional(r.string()),
    adRelationshipBuilding: r.optional(r.number()),
    adRelationshipBuilding_analysis: r.optional(r.string()),
    adRelationshipBuilding_strength: r.optional(r.string()),
    adRelationshipBuilding_weakness: r.optional(r.string()),
    // 企業概要書(IM)提案評価項目
    imNeedsHearingProposal: r.optional(r.number()),
    imNeedsHearingProposal_analysis: r.optional(r.string()),
    imNeedsHearingProposal_strength: r.optional(r.string()),
    imNeedsHearingProposal_weakness: r.optional(r.string()),
    imSellerUnderstanding: r.optional(r.number()),
    imSellerUnderstanding_analysis: r.optional(r.string()),
    imSellerUnderstanding_strength: r.optional(r.string()),
    imSellerUnderstanding_weakness: r.optional(r.string()),
    imBuyerUnderstanding: r.optional(r.number()),
    imBuyerUnderstanding_analysis: r.optional(r.string()),
    imBuyerUnderstanding_strength: r.optional(r.string()),
    imBuyerUnderstanding_weakness: r.optional(r.string()),
    imSynergyProposal: r.optional(r.number()),
    imSynergyProposal_analysis: r.optional(r.string()),
    imSynergyProposal_strength: r.optional(r.string()),
    imSynergyProposal_weakness: r.optional(r.string()),
    imTestClosing: r.optional(r.number()),
    imTestClosing_analysis: r.optional(r.string()),
    imTestClosing_strength: r.optional(r.string()),
    imTestClosing_weakness: r.optional(r.string()),
    // 譲渡架電評価項目
    callTone: r.optional(r.number()),
    callTone_analysis: r.optional(r.string()),
    callTone_strength: r.optional(r.string()),
    callTone_weakness: r.optional(r.string()),
    callListening: r.optional(r.number()),
    callListening_analysis: r.optional(r.string()),
    callListening_strength: r.optional(r.string()),
    callListening_weakness: r.optional(r.string()),
    callScheduling: r.optional(r.number()),
    callScheduling_analysis: r.optional(r.string()),
    callScheduling_strength: r.optional(r.string()),
    callScheduling_weakness: r.optional(r.string()),
    callImportantInfo: r.optional(r.number()),
    callImportantInfo_analysis: r.optional(r.string()),
    callImportantInfo_strength: r.optional(r.string()),
    callImportantInfo_weakness: r.optional(r.string()),
    callDeepHearing: r.optional(r.number()),
    callDeepHearing_analysis: r.optional(r.string()),
    callDeepHearing_strength: r.optional(r.string()),
    callDeepHearing_weakness: r.optional(r.string()),
    // 総合評価コメント
    overallComment: r.optional(r.string()),
    improvementSummary: r.optional(r.string()),
    // AI評価メタデータ
    ai_model: r.optional(r.string()),
    processing_duration_ms: r.optional(r.number()),
    retry_count: r.optional(r.number()),
    error_message: r.optional(r.string()),
    evaluation_requested_at: r.optional(r.number()),
    evaluation_completed_at: r.optional(r.number())
  }).index("by_transcription_id", ["transcription_id"]).index("by_video_id", ["video_id"]).index("by_user_id", ["user_id"]).index("by_video_type", ["video_type"]).index("by_status", ["status"]).index("by_status_and_user", ["status", "user_id"]).index("by_video_type_and_status", ["video_type", "status"]).index("by_user_and_video_type", ["user_id", "video_type"]).index("by_created_time", ["evaluation_requested_at"]).index("by_status_and_created", ["status", "evaluation_requested_at"]).index("by_user_and_created", ["user_id", "evaluation_requested_at"]).index("by_external_id", ["external_id"]),
  roleplays: C({
    title: r.string(),
    description: r.optional(r.string()),
    type: r.string(),
    status: r.string(),
    max_participants: r.optional(r.number()),
    scheduled_at: r.optional(r.number()),
    completed_at: r.optional(r.number()),
    created_by: r.id("users")
  }).index("by_created_by", ["created_by"]).index("by_status", ["status"]).index("by_type", ["type"]),
  roleplayParticipants: C({
    roleplay_id: r.id("roleplays"),
    user_id: r.id("users"),
    // Updated from better_auth_users to users (migration complete)
    is_creator: r.boolean(),
    role: r.optional(r.string())
  }).index("by_roleplay_id", ["roleplay_id"]).index("by_user_id", ["user_id"]),
  // PHASE 3 COMPLETED: roleplayMaterials table safely deleted
  // No roleplay materials data existed in the system
  // Migration completed: Roleplay materials system removed
  videoReviews: C({
    video_id: r.id("videos"),
    user_id: r.id("users"),
    rating: r.optional(r.number()),
    comments: r.optional(r.string())
  }).index("by_video_id", ["video_id"]),
  managerReviews: C({
    video_id: r.id("videos"),
    reviewer_id: r.id("users"),
    overall_rating: r.number(),
    comments: r.string(),
    category_scores: r.optional(r.object({
      listening_skills: r.optional(r.number()),
      proposal_design: r.optional(r.number()),
      knowledge: r.optional(r.number()),
      responsiveness: r.optional(r.number()),
      business_manner: r.optional(r.number())
    }))
  }).index("by_video_id", ["video_id"]).index("by_reviewer_id", ["reviewer_id"]).index("by_video_and_reviewer", ["video_id", "reviewer_id"]),
  moduleQuizzes: C({
    module_id: r.id("trainingModules"),
    title: r.string(),
    description: r.optional(r.string())
  }).index("by_module_id", ["module_id"]),
  quizQuestions: C({
    quiz_id: r.id("moduleQuizzes"),
    question_text: r.string(),
    question_type: r.string(),
    options: r.optional(
      r.array(
        r.object({
          value: r.string(),
          label: r.string(),
          isCorrect: r.optional(r.boolean())
        })
      )
    ),
    correct_answer: r.optional(r.string()),
    explanation: r.optional(r.string())
  }).index("by_quiz_id", ["quiz_id"]),
  quizAttempts: C({
    user_id: r.id("users"),
    quiz_id: r.id("moduleQuizzes"),
    answers: r.record(r.string(), r.union(r.string(), r.number(), r.boolean())),
    is_passed: r.boolean()
    // Removed migration field: new_user_id (Phase 2 cleanup - migration complete)
  }).index("by_user_quiz", ["user_id", "quiz_id"]),
  transcriptions: C({
    // Polymorphic relation - strict typing for resource types
    resource_type: r.union(
      r.literal("video"),
      r.literal("training_content"),
      r.literal("quick_transcription")
    ),
    resource_id: r.string(),
    // ID as string to handle both video and moduleContent IDs
    video_id: r.optional(r.id("videos")),
    // For backwards compatibility
    // Basic transcription data
    text: r.string(),
    segments: r.optional(
      r.array(
        r.object({
          start: r.number(),
          end: r.number(),
          text: r.string(),
          speaker: r.optional(r.string()),
          confidence: r.optional(r.number())
        })
      )
    ),
    // Array of transcription segments with timestamps (deprecated for large files)
    segments_url: r.optional(r.string()),
    // Cloud Storage URL for segment data (for large files)
    formatted_text: r.optional(r.string()),
    // Text with speaker labels
    transcript_with_speaker: r.optional(r.string()),
    // Speaker-based transcript
    speaker_analysis_status: r.optional(
      r.union(
        r.literal("pending"),
        r.literal("processing"),
        r.literal("completed"),
        r.literal("failed")
      )
    ),
    // 話者解析の状態
    status: r.union(
      r.literal("pending"),
      r.literal("processing"),
      r.literal("completed"),
      r.literal("failed")
    ),
    // File metadata
    original_file_url: r.optional(r.string()),
    original_file_type: r.optional(r.string()),
    duration_seconds: r.optional(r.number()),
    // Processing options
    enable_speaker_diarization: r.optional(r.boolean()),
    enable_ai_evaluation: r.optional(r.boolean()),
    // For videos
    enable_content_analysis: r.optional(r.boolean()),
    // For training content
    language: r.optional(r.string()),
    // Video-specific AI analysis results
    meeting_minutes: r.optional(r.any()),
    meeting_minutes_status: r.optional(
      r.union(
        r.literal("pending"),
        r.literal("processing"),
        r.literal("completed"),
        r.literal("failed")
      )
    ),
    meeting_minutes_generated_at: r.optional(r.number()),
    case_summary: r.optional(r.any()),
    case_summary_status: r.optional(
      r.union(
        r.literal("pending"),
        r.literal("processing"),
        r.literal("completed"),
        r.literal("failed")
      )
    ),
    case_summary_generated_at: r.optional(r.number()),
    case_summary_processing_started_at: r.optional(r.number()),
    meeting_summary: r.optional(r.any()),
    meeting_summary_status: r.optional(
      r.union(
        r.literal("pending"),
        r.literal("processing"),
        r.literal("completed"),
        r.literal("failed")
      )
    ),
    meeting_summary_generated_at: r.optional(r.number()),
    meeting_summary_processing_started_at: r.optional(r.number()),
    // Training content-specific AI analysis results
    content_summary: r.optional(
      r.object({
        title: r.string(),
        summary: r.string(),
        learningObjectives: r.optional(r.array(r.string())),
        keyTerms: r.optional(r.array(r.string())),
        difficulty: r.optional(r.string())
      })
    ),
    content_summary_status: r.optional(
      r.union(
        r.literal("pending"),
        r.literal("processing"),
        r.literal("completed"),
        r.literal("failed")
      )
    ),
    content_summary_generated_at: r.optional(r.number()),
    key_points: r.optional(
      r.array(
        r.object({
          point: r.string(),
          importance: r.optional(r.string()),
          timestamp: r.optional(r.number()),
          category: r.optional(r.string())
        })
      )
    ),
    key_points_status: r.optional(
      r.union(
        r.literal("pending"),
        r.literal("processing"),
        r.literal("completed"),
        r.literal("failed")
      )
    ),
    key_points_generated_at: r.optional(r.number()),
    quiz_material: r.optional(
      r.object({
        questions: r.array(
          r.object({
            question: r.string(),
            type: r.string(),
            options: r.optional(r.array(r.string())),
            correctAnswer: r.string(),
            explanation: r.optional(r.string()),
            difficulty: r.optional(r.string())
          })
        ),
        totalQuestions: r.number(),
        estimatedTime: r.optional(r.number())
      })
    ),
    quiz_material_status: r.optional(
      r.union(
        r.literal("pending"),
        r.literal("processing"),
        r.literal("completed"),
        r.literal("failed")
      )
    ),
    quiz_material_generated_at: r.optional(r.number()),
    // Evaluation results (for videos using AI workflow)
    evaluation: r.optional(r.any()),
    evaluation_status: r.optional(
      r.union(
        r.literal("pending"),
        r.literal("processing"),
        r.literal("completed"),
        r.literal("failed")
      )
    ),
    evaluation_generated_at: r.optional(r.number()),
    // Quick transcription specific fields
    quick_transcription: r.optional(
      r.object({
        original_filename: r.string(),
        file_size: r.number(),
        duration_seconds: r.optional(r.number()),
        temporary: r.boolean(),
        expires_at: r.optional(r.number()),
        transcription_type: r.string(),
        custom_prompt: r.optional(r.string()),
        // 議事録関連フィールド
        meeting_minutes: r.optional(
          r.object({
            summary: r.string(),
            keyPoints: r.string(),
            actionItems: r.string(),
            participants: r.string(),
            duration: r.string()
          })
        ),
        meeting_minutes_status: r.optional(
          r.union(
            r.literal("pending"),
            r.literal("processing"),
            r.literal("completed"),
            r.literal("failed")
          )
        ),
        meeting_minutes_generated_at: r.optional(r.number()),
        transcript_with_speaker: r.optional(r.string())
      })
    ),
    // Processing metadata
    confidence_score: r.optional(r.string()),
    processing_duration_ms: r.optional(r.number()),
    error_message: r.optional(r.string()),
    retry_count: r.optional(r.number()),
    // Audio file analysis results (for parallel processing)
    evaluation_result: r.optional(r.string()),
    // JSON string of evaluation result
    audio_analysis_completed: r.optional(r.boolean()),
    // Flag for analysis completion
    audio_analysis_processing_time: r.optional(r.number()),
    // Processing time in ms
    analysis_completed_at: r.optional(r.number()),
    // Timestamp when analysis completed
    audio_analysis_error: r.optional(r.string()),
    // エラーメッセージ
    // Storage-based AI analysis results (performAsyncSyscall対策)
    evaluation_file_id: r.optional(r.id("_storage")),
    // 評価結果のストレージファイルID
    meeting_minutes_file_id: r.optional(r.id("_storage")),
    // 議事録のストレージファイルID
    case_summary_file_id: r.optional(r.id("_storage")),
    // 案件化サマリーのストレージファイルID
    meeting_summary_file_id: r.optional(r.id("_storage")),
    // 商談記録サマリーのストレージファイルID
    // Timestamps
    created_at: r.optional(r.number()),
    updated_at: r.optional(r.number())
  }).index("by_resource", ["resource_type", "resource_id"]).index("by_video_id", ["video_id"]).index("by_status", ["status"]).index("by_resource_type", ["resource_type"]).index("by_resource_status", ["resource_type", "status"]).index("by_created_at", ["created_at"]).index("by_updated_at", ["updated_at"]).index("by_status_and_updated", ["status", "updated_at"]),
  evaluationCriteria: C({
    video_type: r.union(
      r.literal("M&A\u30ED\u30FC\u30EB\u30D7\u30EC\u30A4"),
      r.literal("\u521D\u56DE\u9762\u8AC7"),
      r.literal("AD\u7DE0\u7D50\u63D0\u6848"),
      r.literal("AD\u7DE0\u7D50\u63D0\u6848"),
      r.literal("\u4F01\u696D\u6982\u8981\u66F8\u63D0\u6848"),
      r.literal("\u8B72\u6E21\u67B6\u96FB")
    ),
    criterion_key: r.string(),
    criterion_name: r.string(),
    description: r.optional(r.string()),
    scale: r.object({
      minScore: r.number(),
      maxScore: r.number(),
      description: r.string(),
      scales: r.record(r.string(), r.string())
    }),
    is_active: r.boolean(),
    created_by: r.optional(r.id("users")),
    // Updated from better_auth_users to users (migration complete)
    weight: r.optional(r.number())
    // 評価重みの追加
  }).index("by_video_type", ["video_type"]).index("by_video_type_and_active", ["video_type", "is_active"]).index("by_created_by", ["created_by"]),
  evaluationDetails: C({
    evaluation_id: r.id("evaluations"),
    video_type: r.union(
      r.literal("M&A\u30ED\u30FC\u30EB\u30D7\u30EC\u30A4"),
      r.literal("\u521D\u56DE\u9762\u8AC7"),
      r.literal("AD\u7DE0\u7D50\u63D0\u6848"),
      r.literal("AD\u7DE0\u7D50\u63D0\u6848"),
      r.literal("\u4F01\u696D\u6982\u8981\u66F8\u63D0\u6848"),
      r.literal("\u8B72\u6E21\u67B6\u96FB")
    ),
    final_score: r.number(),
    recommendation: r.union(
      r.literal("\u5408\u683C"),
      r.literal("\u8981\u6539\u5584"),
      r.literal("\u4E0D\u5408\u683C"),
      r.literal("\u51E6\u7406\u4E2D"),
      r.literal("\u30A8\u30E9\u30FC")
    ),
    good_points: r.optional(r.array(r.string())),
    improvement_points: r.optional(r.array(r.string())),
    recommended_actions: r.optional(r.array(r.string())),
    evaluation_details: r.optional(
      r.record(
        r.string(),
        r.union(
          r.number(),
          r.string(),
          r.boolean(),
          r.object({
            score: r.number(),
            analysis: r.string(),
            strength: r.optional(r.string()),
            weakness: r.optional(r.string())
          })
        )
      )
    ),
    retry_count: r.number(),
    evaluation_id_external: r.optional(r.string()),
    // 外部システムとの互換性用
    status: r.optional(
      r.union(
        r.literal("pending"),
        r.literal("processing"),
        r.literal("completed"),
        r.literal("failed")
      )
    ),
    manager_review: r.optional(
      r.object({
        comments: r.string(),
        overrideScore: r.optional(r.number()),
        overrideRecommendation: r.optional(r.string()),
        reviewedAt: r.number(),
        reviewerId: r.id("users")
        // Updated from better_auth_users to users (migration complete)
      })
    )
  }).index("by_evaluation_id", ["evaluation_id"]).index("by_external_id", ["evaluation_id_external"]).index("by_video_type", ["video_type"]).index("by_status", ["status"]),
  // PHASE 1 COMPLETED: humanEvaluations table safely deleted
  // Human evaluation functionality was not implemented
  // All evaluation functionality now uses AI-based evaluations only
  // Migration completed: Unused evaluation system removed
  // PHASE 1 COMPLETED: evaluationAccuracyLogs table safely deleted
  // Evaluation accuracy logging was limitedly used in admin functions
  // Statistical functionality can be replaced by alternative methods
  // Migration completed: Accuracy tracking system removed
  userSettings: C({
    user_id: r.id("users"),
    // Migration: Updated to unified users table
    theme: r.string(),
    language: r.string(),
    timezone: r.string(),
    dashboard_layout: r.optional(
      r.object({
        layout: r.string(),
        widgets: r.optional(
          r.array(
            r.object({
              id: r.string(),
              type: r.string(),
              position: r.object({ x: r.number(), y: r.number() }),
              size: r.object({ width: r.number(), height: r.number() }),
              config: r.optional(
                r.record(r.string(), r.union(r.string(), r.number(), r.boolean()))
              )
            })
          )
        )
      })
    ),
    items_per_page: r.number(),
    default_chart_period: r.string(),
    video_quality: r.string(),
    enable_subtitles: r.boolean(),
    learning_reminder: r.boolean(),
    reminder_time: r.optional(r.string()),
    reminder_days: r.optional(
      r.array(
        r.union(
          r.literal("monday"),
          r.literal("tuesday"),
          r.literal("wednesday"),
          r.literal("thursday"),
          r.literal("friday"),
          r.literal("saturday"),
          r.literal("sunday")
        )
      )
    ),
    session_timeout_minutes: r.number(),
    two_factor_enabled: r.boolean(),
    login_notification: r.boolean(),
    auto_save_enabled: r.boolean(),
    auto_save_interval_seconds: r.number(),
    show_tips: r.boolean()
    // Removed migration field: new_user_id (Phase 2 cleanup - migration complete)
  }).index("by_user_id", ["user_id"]),
  trainingSummaries: C({
    training_id: r.id("trainings"),
    summary: r.string(),
    content_hash: r.optional(r.string()),
    last_updated_content_id: r.optional(r.number()),
    ai_model: r.string()
  }).index("by_training_id", ["training_id"]),
  // Unified chat conversations table (enhanced for Convex Agent compatibility)
  chatConversations: C({
    user_id: r.id("users"),
    // Migration: Updated to unified users table
    session_id: r.string(),
    role: r.string(),
    message: r.string(),
    context_training_ids: r.optional(r.array(r.string())),
    ai_model: r.optional(r.string()),
    // Enhanced fields for Convex Agent compatibility
    thread_id: r.optional(r.string()),
    // Convex Agent thread reference
    metadata: r.optional(
      r.object({
        timestamp: r.number(),
        messageLength: r.optional(r.number()),
        generated: r.optional(r.boolean()),
        modelVersion: r.optional(r.string()),
        responseTime: r.optional(r.number()),
        confidence: r.optional(r.number())
      })
    )
    // Structured metadata for AI context
  }).index("by_session_id", ["session_id"]).index("by_thread_id", ["thread_id"]).index("by_user_id", ["user_id"]),
  // Chat sessions table for managing conversation sessions
  chatSessions: C({
    session_id: r.string(),
    user_id: r.optional(r.id("users")),
    // Updated from better_auth_users to users (migration complete)
    legacy_user_id: r.optional(r.string()),
    // Historical legacy user ID (string)
    thread_id: r.optional(r.string()),
    // Convex Agent thread ID
    title: r.optional(r.string()),
    status: r.string(),
    // "active", "completed", "archived"
    last_message_at: r.optional(r.number()),
    context_summary: r.optional(r.string()),
    training_context_ids: r.optional(r.array(r.string()))
  }).index("by_session_id", ["session_id"]).index("by_user_id", ["user_id"]).index("by_thread_id", ["thread_id"]).index("by_status", ["status"]),
  // Chat activity logging for monitoring and analytics (simplified)
  chatActivityLogs: C({
    session_id: r.string(),
    user_id: r.optional(r.id("users")),
    // Updated from better_auth_users to users (migration complete)
    action: r.string(),
    // Simplified from union type
    timestamp: r.number(),
    metadata: r.optional(r.string())
    // JSON string to avoid deep type instantiation
  }).index("by_session_id", ["session_id"]).index("by_user_id", ["user_id"]).index("by_action", ["action"]).index("by_timestamp", ["timestamp"]),
  cases: C({
    title: r.string(),
    company_name: r.string(),
    description: r.optional(r.string()),
    status: r.union(
      r.literal("active"),
      r.literal("completed"),
      r.literal("on_hold"),
      r.literal("cancelled")
    ),
    created_by: r.id("users"),
    assigned_to: r.optional(r.id("users")),
    overall_progress: r.number(),
    priority: r.union(r.literal("high"), r.literal("medium"), r.literal("low")),
    due_date: r.optional(r.number()),
    interview_data: r.optional(
      r.object({
        questions: r.optional(
          r.array(
            r.object({
              question: r.string(),
              answer: r.optional(r.string()),
              category: r.optional(r.string()),
              importance: r.optional(r.string())
            })
          )
        ),
        notes: r.optional(r.string()),
        interviewer: r.optional(r.string()),
        interview_date: r.optional(r.number()),
        follow_up_required: r.optional(r.boolean())
      })
    )
  }).index("by_assigned_to", ["assigned_to"]).index("by_created_by", ["created_by"]).index("by_status", ["status"]).index("by_priority", ["priority"]),
  case_progress: C({
    case_id: r.id("cases"),
    item_id: r.string(),
    category: r.string(),
    label: r.string(),
    description: r.optional(r.string()),
    weight: r.number(),
    priority: r.union(r.literal("high"), r.literal("medium"), r.literal("low")),
    status: r.union(
      r.literal("completed"),
      r.literal("partial"),
      r.literal("missing"),
      r.literal("in_progress")
    ),
    completed_at: r.optional(r.number()),
    notes: r.optional(r.string()),
    collected_data: r.optional(
      r.record(r.string(), r.union(r.string(), r.number(), r.boolean(), r.array(r.string())))
    )
  }).index("by_case_id", ["case_id"]).index("by_status", ["status"]).index("by_priority", ["priority"]).index("by_case_status", ["case_id", "status"]),
  // ファイルアップロード管理（拡張）
  fileUploads: C({
    // ユーザー情報
    user_id: r.id("users"),
    // Updated from better_auth_users to users (migration complete)
    // ファイル基本情報
    original_filename: r.string(),
    content_type: r.string(),
    file_size: r.number(),
    // ストレージ情報（GCS専用）
    gcp_file_path: r.string(),
    // GCP Cloud Storage専用（必須）
    storage_id: r.optional(r.string()),
    // Convex Storage ID（クイック文字起こし用）
    // アップロード種別
    upload_type: r.union(
      r.literal("video"),
      r.literal("training"),
      r.literal("thumbnail"),
      r.literal("course_thumbnail"),
      r.literal("module_content"),
      r.literal("roleplay_material"),
      r.literal("quick_transcription")
    ),
    // ステータス管理（原子的アップロード対応）
    status: r.union(
      r.literal("preparing"),
      // フェーズ1: DB予約レコード作成済み
      r.literal("pending"),
      // フェーズ2: GCS URL生成済み、アップロード待ち
      r.literal("uploading"),
      // アップロード中
      r.literal("completed"),
      // 完了
      r.literal("failed"),
      // 失敗
      r.literal("processing")
      // 後処理中
    ),
    // 関連リソースID（型安全化）
    related_resource_type: r.optional(
      r.union(
        r.literal("video"),
        r.literal("training"),
        r.literal("trainingModule"),
        r.literal("moduleContent"),
        r.literal("roleplay"),
        r.literal("quick_transcription")
      )
    ),
    related_resource_id: r.optional(
      r.union(
        r.id("videos"),
        r.id("trainings"),
        r.id("trainingModules"),
        r.id("moduleContents"),
        r.id("roleplays"),
        r.id("transcriptions")
      )
    ),
    // 処理結果
    public_url: r.optional(r.string()),
    processing_error: r.optional(r.string()),
    // 拡張メタデータ
    duration_seconds: r.optional(r.number()),
    // 動画・音声ファイル用
    resolution: r.optional(
      r.object({
        // 動画・画像ファイル用
        width: r.number(),
        height: r.number()
      })
    ),
    video_codec: r.optional(r.string()),
    // 動画ファイル用
    audio_codec: r.optional(r.string()),
    // 動画・音声ファイル用
    bitrate: r.optional(r.number()),
    // 動画・音声ファイル用
    frame_rate: r.optional(r.number()),
    // 動画ファイル用
    // サムネイル管理（GCS対応）
    thumbnail_generated: r.optional(r.boolean()),
    thumbnail_gcp_paths: r.optional(
      r.array(
        r.object({
          // 複数サイズサムネイル（GCS）
          size: r.string(),
          // "small", "medium", "large", "poster"
          gcp_file_path: r.string(),
          url: r.string(),
          file_size: r.number(),
          width: r.number(),
          height: r.number()
        })
      )
    ),
    // 文字起こし・AI処理
    transcription_started: r.optional(r.boolean()),
    transcription_id: r.optional(r.id("transcriptions")),
    // 品質分析
    quality_score: r.optional(r.number()),
    // 0-100
    quality_analysis: r.optional(
      r.object({
        audio_quality: r.optional(r.number()),
        video_quality: r.optional(r.number()),
        compression_ratio: r.optional(r.number()),
        recommended_settings: r.optional(r.string())
      })
    ),
    // 重複検出
    file_hash: r.optional(r.string()),
    // SHA-256ハッシュ
    duplicate_of: r.optional(r.id("fileUploads")),
    // 重複元ファイル
    // 使用量統計
    view_count: r.optional(r.number()),
    download_count: r.optional(r.number()),
    last_accessed: r.optional(r.number()),
    // タイムスタンプ
    uploaded_at: r.optional(r.number()),
    completed_at: r.optional(r.number()),
    metadata_processed_at: r.optional(r.number())
  }).index("by_user_id", ["user_id"]).index("by_status", ["status"]).index("by_upload_type", ["upload_type"]).index("by_user_status", ["user_id", "status"]).index("by_user_type", ["user_id", "upload_type"]).index("by_status_uploaded", ["status", "uploaded_at"]).index("by_related_resource", ["related_resource_type", "related_resource_id"]).index("by_file_hash", ["file_hash"]).index("by_duplicate_of", ["duplicate_of"]).index("by_quality_score", ["quality_score"]).index("by_last_accessed", ["last_accessed"]),
  // PHASE 3 COMPLETED: uploadProgress table safely deleted
  // Upload progress tracking was unused as fileUploads provides sufficient progress management
  // Migration completed: Upload progress tracking system removed
  // === External Integration Tables ===
  // All external AI integration tables have been removed
  // === 通知システム（簡素化版） ===
  // 複雑な型定義を避けるため、notification.tsから簡素化されたスキーマを使用
  // 基本通知テーブル（既存との互換性を保つため）
  notifications: C({
    user_id: r.id("users"),
    type: r.string(),
    title: r.string(),
    message: r.string(),
    data: r.optional(r.string()),
    // JSON文字列として簡素化
    is_read: r.boolean()
  }).index("by_user_id_and_read", ["user_id", "is_read"]).index("by_type", ["type"]).index("by_user_id_and_type", ["user_id", "type"]),
  // 基本通知設定テーブル（既存との互換性を保つため）
  notificationSettings: C({
    user_id: r.id("users"),
    notification_type: r.string(),
    email_enabled: r.boolean(),
    system_enabled: r.boolean(),
    slack_enabled: r.boolean()
  }).index("by_user_id", ["user_id"]).index("by_user_id_and_type", ["user_id", "notification_type"]),
  // 拡張通知システム（簡素化版）
  ...ai,
  // Slack統合設定（slack.ts用に調整）
  slackIntegrations: C({
    organization_id: r.optional(r.number()),
    webhook_url: r.string(),
    channel_name: r.string(),
    is_active: r.boolean(),
    created_by: r.id("users")
  }).index("by_created_by", ["created_by"]).index("by_created_by_and_active", ["created_by", "is_active"]),
  // OAuth token management for Slack integrations
  slackOAuthTokens: C({
    user_id: r.id("users"),
    team_id: r.string(),
    team_name: r.string(),
    access_token: r.string(),
    bot_user_id: r.optional(r.string()),
    scope: r.string(),
    is_active: r.boolean(),
    expires_at: r.optional(r.number()),
    last_used_at: r.optional(r.number())
  }).index("by_user_id", ["user_id"]).index("by_team_id", ["team_id"]).index("by_user_and_team", ["user_id", "team_id"]).index("by_is_active", ["is_active"]),
  // Slack通知設定（ユーザー別）
  slackNotificationSettings: C({
    // ユーザー参照
    user_id: r.id("users"),
    // Updated from better_auth_users to users (migration complete)
    oauth_token_id: r.id("slackOAuthTokens"),
    // 通知種類別チャンネル設定
    evaluation_complete_channel_id: r.optional(r.string()),
    roleplay_application_channel_id: r.optional(r.string()),
    weekly_report_channel_id: r.optional(r.string()),
    system_notification_channel_id: r.optional(r.string()),
    // デフォルト設定
    default_channel_id: r.string(),
    // 高度な設定
    enable_direct_message: r.boolean(),
    notification_quiet_hours_start: r.optional(r.string()),
    notification_quiet_hours_end: r.optional(r.string())
  }).index("by_user_and_oauth", ["user_id", "oauth_token_id"]),
  // メール送信ログ
  // PHASE 1 COMPLETED: emailLogs table safely deleted
  // Email notification logging can be handled by external email service providers
  // Migration completed: Email logging system removed
  // PHASE 3 COMPLETED: rateLimitRecords table safely deleted
  // Rate limiting can be handled by Clerk authentication system
  // Migration completed: Rate limiting system removed
  // === ファイル管理拡張システム ===
  // PHASE 3 COMPLETED: fileMetadata table safely deleted
  // No metadata data existed - can be consolidated into videos table if needed
  // Migration completed: File metadata system removed
  // サムネイル管理システム（ハイブリッドストレージ対応）
  thumbnails: C({
    // ファイル関連（GCS専用）
    file_upload_id: r.id("fileUploads"),
    // サムネイル情報（GCS）
    gcp_file_path: r.string(),
    // GCS上のサムネイルファイルパス
    thumbnail_url: r.string(),
    // サイズ・品質設定
    width: r.number(),
    height: r.number(),
    size_category: r.union(
      r.literal("small"),
      // 150x150
      r.literal("medium"),
      // 300x300
      r.literal("large"),
      // 640x360
      r.literal("poster"),
      // 1280x720（新追加）
      r.literal("custom")
    ),
    // フィールド名統一（新旧両対応）
    size: r.optional(r.string()),
    // 新システム用
    format: r.union(r.literal("webp"), r.literal("jpeg"), r.literal("png")),
    quality: r.number(),
    // 1-100
    file_size: r.number(),
    // 生成設定
    generation_method: r.union(
      r.literal("frame_extraction"),
      // 動画フレーム抽出
      r.literal("image_resize"),
      // 画像リサイズ
      r.literal("document_preview"),
      // 文書プレビュー
      r.literal("auto_generated")
      // 自動生成
    ),
    frame_time: r.optional(r.number()),
    // 動画の場合、抽出時間（秒）
    // ステータス管理
    generation_status: r.union(
      r.literal("pending"),
      r.literal("processing"),
      r.literal("completed"),
      r.literal("failed")
    ),
    generation_error: r.optional(r.string()),
    generated_at: r.optional(r.number()),
    // 最適化情報
    optimized: r.boolean(),
    compression_ratio: r.optional(r.number())
  }).index("by_file_upload_id", ["file_upload_id"]).index("by_size_category", ["size_category"]).index("by_generation_status", ["generation_status"]).index("by_generated_at", ["generated_at"]),
  // サムネイル生成ジョブ管理
  // PHASE 1 COMPLETED: thumbnailJobs table safely deleted
  // Thumbnail functionality can be consolidated into the main thumbnail processing system
  // Migration completed: Thumbnail job management system removed
  // PHASE 3 COMPLETED: fileQualityAnalysis table safely deleted
  // No quality analysis data existed - can be consolidated into videos table if needed
  // Migration completed: File quality analysis system removed
  // ファイル重複検出
  // PHASE 1 COMPLETED: fileDuplicates table safely deleted
  // Limited usage in metadata.ts can be replaced by file hash-based duplicate detection
  // Migration completed: File duplication detection system removed
  // ファイル使用量統計
  // PHASE 1 COMPLETED: fileUsageStats table safely deleted
  // Statistical functionality can be handled by external analytics services
  // Migration completed: File usage statistics system removed
  // PHASE 3 COMPLETED: processingJobs table safely deleted
  // Generic job processing had alternative implementations available
  // Migration completed: Generic job processing system removed
  // PHASE 3 COMPLETED: encryptionAuditLog table safely deleted
  // No encryption audit data existed - security requirements can be met through alternative methods
  // Migration completed: Encryption audit logging system removed
  // === 議事録の型管理 ===
  // 議事録の型を管理するテーブル（動画アップロード・クイック文字起こし用）
  transcriptionTypes: C({
    // 基本情報
    name: r.string(),
    // 型の名前（例：営業商談用、面接用、研修用）
    description: r.string(),
    // 型の説明
    key: r.string(),
    // 一意のキー（例：business_meeting, interview, training）
    // プロンプトとテンプレート
    prompt: r.string(),
    // AIに送信するプロンプト
    template: r.optional(r.string()),
    // 出力テンプレート（オプション）
    // 分類・管理
    category: r.optional(r.string()),
    // カテゴリ（例：営業、人事、研修）
    is_system: r.boolean(),
    // システム標準の型かどうか
    is_active: r.boolean(),
    // 使用可能かどうか
    // 使用範囲
    available_for_quick_transcription: r.boolean(),
    // クイック文字起こしで使用可能
    available_for_video_upload: r.boolean(),
    // 動画アップロードで使用可能
    // 作成・管理情報
    created_by: r.optional(r.id("users")),
    // 作成者（システムの場合はnull）
    created_at: r.number(),
    updated_at: r.number(),
    // 表示設定
    display_order: r.number(),
    // 表示順序
    icon: r.optional(r.string()),
    // アイコン（オプション）
    color: r.optional(r.string()),
    // カラー（オプション）
    // 統計情報
    usage_count: r.number(),
    // 使用回数
    last_used_at: r.optional(r.number())
    // 最終使用日時
  }).index("by_key", ["key"]).index("by_is_active", ["is_active"]).index("by_category", ["category"]).index("by_created_by", ["created_by"]).index("by_display_order", ["display_order"]).index("by_quick_transcription", ["available_for_quick_transcription", "is_active"]).index("by_video_upload", ["available_for_video_upload", "is_active"]).index("by_usage_count", ["usage_count"]).index("by_last_used", ["last_used_at"]),
  // AI処理ジョブ管理テーブル（Action分割チェーン処理用）
  aiProcessingJobs: C({
    transcription_id: r.id("transcriptions"),
    job_type: r.union(
      r.literal("audio_analysis"),
      // 音声ファイル分析
      r.literal("evaluation"),
      // 評価結果生成
      r.literal("meeting_minutes"),
      // 議事録生成
      r.literal("case_summary"),
      // 案件化サマリー生成
      r.literal("meeting_summary")
      // 商談記録サマリー生成
    ),
    status: r.union(
      r.literal("pending"),
      // 待機中
      r.literal("processing"),
      // 処理中
      r.literal("completed"),
      // 完了
      r.literal("failed"),
      // 失敗
      r.literal("cancelled")
      // キャンセル
    ),
    step: r.optional(r.number()),
    // 現在の処理ステップ（評価→議事録→案件化→商談記録の順）
    total_steps: r.optional(r.number()),
    // 総ステップ数
    current_action: r.optional(r.string()),
    // 現在実行中のAction名
    // 処理結果データ（小さなデータのみ）
    result_data: r.optional(r.string()),
    // JSONストリング（軽量データのみ）
    result_storage_id: r.optional(r.id("_storage")),
    // 大きなデータはストレージに保存
    // エラー情報
    error_message: r.optional(r.string()),
    error_count: r.optional(r.number()),
    last_error_at: r.optional(r.number()),
    // 処理メタデータ
    processing_duration_ms: r.optional(r.number()),
    ai_model: r.optional(r.string()),
    retry_count: r.optional(r.number()),
    max_retries: r.optional(r.number()),
    // 次の処理への引き継ぎ情報
    next_job_id: r.optional(r.id("aiProcessingJobs")),
    // チェーン処理の次のジョブ
    parent_job_id: r.optional(r.id("aiProcessingJobs")),
    // 親ジョブ（全体管理用）
    // タイムスタンプ
    created_at: r.number(),
    started_at: r.optional(r.number()),
    completed_at: r.optional(r.number()),
    updated_at: r.number()
  }).index("by_transcription_id", ["transcription_id"]).index("by_job_type", ["job_type"]).index("by_status", ["status"]).index("by_transcription_status", ["transcription_id", "status"]).index("by_parent_job", ["parent_job_id"]).index("by_created_at", ["created_at"]).index("by_status_created", ["status", "created_at"]),
  // レート制限記録テーブル
  rateLimitRecords: C({
    userId: r.string(),
    action: r.string(),
    count: r.number(),
    windowStart: r.number()
  }).index("by_user_action", ["userId", "action"]).index("by_window_start", ["windowStart"]),
  // セキュリティイベントログテーブル
  securityEvents: C({
    event_type: r.string(),
    // "login_failure", "user_privilege_change", "suspicious_activity", etc.
    severity: r.number(),
    // 1: Low, 2: Medium, 3: High, 4: Critical
    user_id: r.optional(r.id("users")),
    // イベントに関連するユーザー（存在する場合）
    target_user_id: r.optional(r.id("users")),
    // 対象ユーザー（権限変更の場合など）
    ip_address: r.optional(r.string()),
    user_agent: r.optional(r.string()),
    details: r.optional(r.string()),
    // JSON文字列として詳細情報を格納
    created_at: r.number()
  }).index("by_event_type", ["event_type"]).index("by_severity", ["severity"]).index("by_user_id", ["user_id"]).index("by_target_user_id", ["target_user_id"]).index("by_created_at", ["created_at"]).index("by_severity_and_created", ["severity", "created_at"]),
  // マルチパートアップロード管理テーブル
  multipartUploads: C({
    fileUploadId: r.id("fileUploads"),
    // 関連するfileUpload記録
    uploadId: r.string(),
    // マルチパートアップロードの一意ID
    gcpFilePath: r.string(),
    // GCS上のファイルパス
    filename: r.string(),
    // 元のファイル名
    contentType: r.string(),
    // MIMEタイプ
    fileSize: r.number(),
    // ファイルサイズ（バイト）
    totalParts: r.number(),
    // 総パート数
    status: r.string(),
    // "initiated", "in_progress", "completed", "failed"
    // 完了済みパート記録
    completedParts: r.optional(
      r.array(
        r.object({
          partNumber: r.number(),
          etag: r.string(),
          completedAt: r.number()
        })
      )
    ),
    // 再試行記録
    retryAttempts: r.optional(
      r.array(
        r.object({
          partNumber: r.number(),
          attempts: r.number(),
          lastError: r.string(),
          lastAttempt: r.number()
        })
      )
    ),
    // タイムスタンプ
    createdAt: r.optional(r.number()),
    completedAt: r.optional(r.number())
  }).index("by_fileUploadId", ["fileUploadId"]).index("by_fileUploadId_uploadId", ["fileUploadId", "uploadId"]).index("by_status", ["status"]).index("by_created_at", ["createdAt"])
});

// convex/testing/testIntegration.ts
var Bp = {
  ADMIN: "ADMIN",
  TRAINER: "TRAINER",
  EMPLOYEE: "EMPLOYEE",
  VIEWER: "VIEWER"
}, fn = class {
  static {
    c(this, "EnhancedTestHelpers");
  }
  testHelper;
  config;
  sessionId;
  createdUsers = [];
  constructor(t = {}) {
    this.testHelper = yi(Js), this.config = {
      autoCleanup: !0,
      setupUsers: [],
      preserveData: !1,
      ...t
    }, this.sessionId = t.sessionId || `test-session-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
  }
  /**
   * テスト環境のセットアップ
   */
  async setup() {
    if (this.config.autoCleanup && await this.cleanup(), this.config.setupUsers && this.config.setupUsers.length > 0)
      for (let t of this.config.setupUsers) {
        let n = await this.testHelper.mutation(
          fe.testing.authHelpers.createTestUserWithAuth,
          { predefinedUser: t }
        );
        this.createdUsers.push({
          userId: n.userId,
          tokenIdentifier: n.tokenIdentifier
        });
      }
  }
  /**
   * テスト環境のクリーンアップ
   */
  async cleanup() {
    this.config.preserveData || await this.testHelper.mutation(
      fe.testing.cleanupHelpers.cleanupAllTestData,
      {}
    );
  }
  /**
   * 認証付きユーザー作成
   */
  async createUserWithAuth(t, n) {
    let i = await this.testHelper.mutation(
      fe.testing.authHelpers.createTestUserWithAuth,
      {
        predefinedUser: t,
        customTokenIdentifier: n
      }
    );
    return this.createdUsers.push({
      userId: i.userId,
      tokenIdentifier: i.tokenIdentifier
    }), {
      userId: i.userId,
      tokenIdentifier: i.tokenIdentifier
    };
  }
  /**
   * 認証設定の自動化
   */
  async setUserIdentity(t, n) {
    let i = await this.createUserWithAuth(t, n);
    return this.testHelper.withIdentity({
      subject: `test-${t.toLowerCase()}-user`,
      tokenIdentifier: i.tokenIdentifier
    }), i;
  }
  /**
   * マルチユーザー環境の構築
   */
  async setupMultiUserEnvironment(t) {
    let n = [];
    for (let i of t) {
      let o = await this.createUserWithAuth(i.type, i.identifier);
      n.push({
        ...o,
        type: i.type
      });
    }
    return n;
  }
  /**
   * テストデータ生成ヘルパー
   */
  async generateTestVideo(t, n = {}) {
    return await this.testHelper.mutation(
      fe.testing.createTestVideoForId,
      {
        userId: t,
        title: n.title || "Test Video"
      }
    );
  }
  /**
   * テスト評価の生成
   */
  async generateTestEvaluation(t, n, i = {}) {
    return await this.testHelper.mutation(
      fe.testing.createTestEvaluationForId,
      {
        userId: t,
        videoId: n,
        status: i.status || "completed"
      }
    );
  }
  /**
   * 権限テストヘルパー
   */
  async testPermissions(t, n) {
    let i = await this.testHelper.query(
      fe.testing.authHelpers.checkTestUserPermissions,
      {
        userId: t,
        requiredRole: n
      }
    );
    return {
      hasPermission: i.hasPermission,
      userRole: i.userRole
    };
  }
  /**
   * 元のテストヘルパーへのアクセス
   */
  get helper() {
    return this.testHelper;
  }
  /**
   * 統計情報の取得
   */
  async getTestStatistics() {
    return await this.testHelper.query(
      fe.testing.cleanupHelpers.getTestDataStatistics,
      {}
    );
  }
};
function Up(e) {
  return new fn(e);
}
c(Up, "createTestEnvironment");
function Yp(e) {
  cn(async () => {
    await e.setup();
  }), ln(async () => {
    await e.cleanup();
  });
}
c(Yp, "setupAutoCleanup");
function Jp(e) {
  let t = new fn(e);
  return {
    mutation: t.helper.mutation.bind(t.helper),
    query: t.helper.query.bind(t.helper),
    withIdentity: t.helper.withIdentity.bind(t.helper),
    // 拡張機能へのアクセス
    ...t.helper,
    // カスタム拡張メソッド
    enhanced: t,
    setupUser: t.setUserIdentity.bind(t),
    cleanupAll: t.cleanup.bind(t)
  };
}
c(Jp, "createCompatibleTestHelper");
var Wp = {
  /**
   * 管理者権限テストのテンプレート
   */
  adminOperation: /* @__PURE__ */ c(async (e, t) => {
    let { userId: n } = await e.setUserIdentity("ADMIN");
    return await t(n);
  }, "adminOperation"),
  /**
   * 一般ユーザー権限テストのテンプレート
   */
  employeeOperation: /* @__PURE__ */ c(async (e, t) => {
    let { userId: n } = await e.setUserIdentity("EMPLOYEE");
    return await t(n);
  }, "employeeOperation"),
  /**
   * 権限不足エラーテストのテンプレート
   */
  unauthorizedOperation: /* @__PURE__ */ c(async (e, t, n = "\u7BA1\u7406\u8005\u6A29\u9650\u304C\u5FC5\u8981\u3067\u3059") => {
    let { userId: i } = await e.setUserIdentity("VIEWER"), o = null;
    try {
      await t(i);
    } catch (s) {
      o = s;
    }
    if (!o)
      throw new Error("\u6A29\u9650\u30A8\u30E9\u30FC\u304C\u767A\u751F\u3059\u308B\u306F\u305A\u3067\u3057\u305F\u304C\u3001\u6210\u529F\u3057\u307E\u3057\u305F");
    if (!o.message.includes(n))
      throw new Error(`\u671F\u5F85\u3055\u308C\u305F\u30A8\u30E9\u30FC\u30E1\u30C3\u30BB\u30FC\u30B8\u3068\u7570\u306A\u308A\u307E\u3059: ${o.message}`);
  }, "unauthorizedOperation"),
  /**
   * マルチユーザーインタラクションテストのテンプレート
   */
  multiUserInteraction: /* @__PURE__ */ c(async (e, t) => {
    let i = (await e.setupMultiUserEnvironment([
      { type: "ADMIN" },
      { type: "EMPLOYEE" },
      { type: "VIEWER" }
    ])).map((o) => ({ userId: o.userId, role: o.type }));
    return await t(i);
  }, "multiUserInteraction")
};
export {
  fn as EnhancedTestHelpers,
  Bp as PREDEFINED_TEST_USERS,
  Wp as TestScenarios,
  Jp as createCompatibleTestHelper,
  Up as createTestEnvironment,
  Yp as setupAutoCleanup
};
/*! Bundled license information:

@vitest/pretty-format/dist/index.js:
  (**
   * @license React
   * react-is.production.js
   *
   * Copyright (c) Meta Platforms, Inc. and affiliates.
   *
   * This source code is licensed under the MIT license found in the
   * LICENSE file in the root directory of this source tree.
   *)

@vitest/pretty-format/dist/index.js:
  (**
   * @license React
   * react-is.development.js
   *
   * Copyright (c) Meta Platforms, Inc. and affiliates.
   *
   * This source code is licensed under the MIT license found in the
   * LICENSE file in the root directory of this source tree.
   *)

@vitest/pretty-format/dist/index.js:
  (**
   * @license React
   * react-is.production.min.js
   *
   * Copyright (c) Facebook, Inc. and its affiliates.
   *
   * This source code is licensed under the MIT license found in the
   * LICENSE file in the root directory of this source tree.
   *)

@vitest/pretty-format/dist/index.js:
  (**
   * @license React
   * react-is.development.js
   *
   * Copyright (c) Facebook, Inc. and its affiliates.
   *
   * This source code is licensed under the MIT license found in the
   * LICENSE file in the root directory of this source tree.
   *)

chai/chai.js:
  (*!
   * Chai - flag utility
   * Copyright(c) 2012-2014 Jake Luer <jake@alogicalparadox.com>
   * MIT Licensed
   *)
  (*!
   * Chai - test utility
   * Copyright(c) 2012-2014 Jake Luer <jake@alogicalparadox.com>
   * MIT Licensed
   *)
  (*!
   * Chai - expectTypes utility
   * Copyright(c) 2012-2014 Jake Luer <jake@alogicalparadox.com>
   * MIT Licensed
   *)
  (*!
   * Chai - getActual utility
   * Copyright(c) 2012-2014 Jake Luer <jake@alogicalparadox.com>
   * MIT Licensed
   *)
  (*!
   * Chai - message composition utility
   * Copyright(c) 2012-2014 Jake Luer <jake@alogicalparadox.com>
   * MIT Licensed
   *)
  (*!
   * Chai - transferFlags utility
   * Copyright(c) 2012-2014 Jake Luer <jake@alogicalparadox.com>
   * MIT Licensed
   *)
  (*!
   * chai
   * http://chaijs.com
   * Copyright(c) 2011-2014 Jake Luer <jake@alogicalparadox.com>
   * MIT Licensed
   *)
  (*!
   * Chai - isProxyEnabled helper
   * Copyright(c) 2012-2014 Jake Luer <jake@alogicalparadox.com>
   * MIT Licensed
   *)
  (*!
   * Chai - addProperty utility
   * Copyright(c) 2012-2014 Jake Luer <jake@alogicalparadox.com>
   * MIT Licensed
   *)
  (*!
   * Chai - addLengthGuard utility
   * Copyright(c) 2012-2014 Jake Luer <jake@alogicalparadox.com>
   * MIT Licensed
   *)
  (*!
   * Chai - getProperties utility
   * Copyright(c) 2012-2014 Jake Luer <jake@alogicalparadox.com>
   * MIT Licensed
   *)
  (*!
   * Chai - proxify utility
   * Copyright(c) 2012-2014 Jake Luer <jake@alogicalparadox.com>
   * MIT Licensed
   *)
  (*!
   * Chai - addMethod utility
   * Copyright(c) 2012-2014 Jake Luer <jake@alogicalparadox.com>
   * MIT Licensed
   *)
  (*!
   * Chai - overwriteProperty utility
   * Copyright(c) 2012-2014 Jake Luer <jake@alogicalparadox.com>
   * MIT Licensed
   *)
  (*!
   * Chai - overwriteMethod utility
   * Copyright(c) 2012-2014 Jake Luer <jake@alogicalparadox.com>
   * MIT Licensed
   *)
  (*!
   * Chai - addChainingMethod utility
   * Copyright(c) 2012-2014 Jake Luer <jake@alogicalparadox.com>
   * MIT Licensed
   *)
  (*!
   * Chai - overwriteChainableMethod utility
   * Copyright(c) 2012-2014 Jake Luer <jake@alogicalparadox.com>
   * MIT Licensed
   *)
  (*!
   * Chai - compareByInspect utility
   * Copyright(c) 2011-2016 Jake Luer <jake@alogicalparadox.com>
   * MIT Licensed
   *)
  (*!
   * Chai - getOwnEnumerablePropertySymbols utility
   * Copyright(c) 2011-2016 Jake Luer <jake@alogicalparadox.com>
   * MIT Licensed
   *)
  (*!
   * Chai - getOwnEnumerableProperties utility
   * Copyright(c) 2011-2016 Jake Luer <jake@alogicalparadox.com>
   * MIT Licensed
   *)
  (*!
   * Chai - isNaN utility
   * Copyright(c) 2012-2015 Sakthipriyan Vairamani <thechargingvolcano@gmail.com>
   * MIT Licensed
   *)
  (*!
   * chai
   * Copyright(c) 2011 Jake Luer <jake@alogicalparadox.com>
   * MIT Licensed
   *)
  (*!
   * chai
   * Copyright(c) 2011-2014 Jake Luer <jake@alogicalparadox.com>
   * MIT Licensed
   *)
  (*! Bundled license information:
  
  deep-eql/index.js:
    (*!
     * deep-eql
     * Copyright(c) 2013 Jake Luer <jake@alogicalparadox.com>
     * MIT Licensed
     *)
    (*!
     * Check to see if the MemoizeMap has recorded a result of the two operands
     *
     * @param {Mixed} leftHandOperand
     * @param {Mixed} rightHandOperand
     * @param {MemoizeMap} memoizeMap
     * @returns {Boolean|null} result
    *)
    (*!
     * Set the result of the equality into the MemoizeMap
     *
     * @param {Mixed} leftHandOperand
     * @param {Mixed} rightHandOperand
     * @param {MemoizeMap} memoizeMap
     * @param {Boolean} result
    *)
    (*!
     * Primary Export
     *)
    (*!
     * The main logic of the `deepEqual` function.
     *
     * @param {Mixed} leftHandOperand
     * @param {Mixed} rightHandOperand
     * @param {Object} [options] (optional) Additional options
     * @param {Array} [options.comparator] (optional) Override default algorithm, determining custom equality.
     * @param {Array} [options.memoize] (optional) Provide a custom memoization object which will cache the results of
        complex objects for a speed boost. By passing `false` you can disable memoization, but this will cause circular
        references to blow the stack.
     * @return {Boolean} equal match
    *)
    (*!
     * Compare two Regular Expressions for equality.
     *
     * @param {RegExp} leftHandOperand
     * @param {RegExp} rightHandOperand
     * @return {Boolean} result
     *)
    (*!
     * Compare two Sets/Maps for equality. Faster than other equality functions.
     *
     * @param {Set} leftHandOperand
     * @param {Set} rightHandOperand
     * @param {Object} [options] (Optional)
     * @return {Boolean} result
     *)
    (*!
     * Simple equality for flat iterable objects such as Arrays, TypedArrays or Node.js buffers.
     *
     * @param {Iterable} leftHandOperand
     * @param {Iterable} rightHandOperand
     * @param {Object} [options] (Optional)
     * @return {Boolean} result
     *)
    (*!
     * Simple equality for generator objects such as those returned by generator functions.
     *
     * @param {Iterable} leftHandOperand
     * @param {Iterable} rightHandOperand
     * @param {Object} [options] (Optional)
     * @return {Boolean} result
     *)
    (*!
     * Determine if the given object has an @@iterator function.
     *
     * @param {Object} target
     * @return {Boolean} `true` if the object has an @@iterator function.
     *)
    (*!
     * Gets all iterator entries from the given Object. If the Object has no @@iterator function, returns an empty array.
     * This will consume the iterator - which could have side effects depending on the @@iterator implementation.
     *
     * @param {Object} target
     * @returns {Array} an array of entries from the @@iterator function
     *)
    (*!
     * Gets all entries from a Generator. This will consume the generator - which could have side effects.
     *
     * @param {Generator} target
     * @returns {Array} an array of entries from the Generator.
     *)
    (*!
     * Gets all own and inherited enumerable keys from a target.
     *
     * @param {Object} target
     * @returns {Array} an array of own and inherited enumerable keys from the target.
     *)
    (*!
     * Determines if two objects have matching values, given a set of keys. Defers to deepEqual for the equality check of
     * each key. If any value of the given key is not equal, the function will return false (early).
     *
     * @param {Mixed} leftHandOperand
     * @param {Mixed} rightHandOperand
     * @param {Array} keys An array of keys to compare the values of leftHandOperand and rightHandOperand against
     * @param {Object} [options] (Optional)
     * @return {Boolean} result
     *)
    (*!
     * Recursively check the equality of two Objects. Once basic sameness has been established it will defer to `deepEqual`
     * for each enumerable key in the object.
     *
     * @param {Mixed} leftHandOperand
     * @param {Mixed} rightHandOperand
     * @param {Object} [options] (Optional)
     * @return {Boolean} result
     *)
    (*!
     * Returns true if the argument is a primitive.
     *
     * This intentionally returns true for all objects that can be compared by reference,
     * including functions and symbols.
     *
     * @param {Mixed} value
     * @return {Boolean} result
     *)
  *)
*/
//# sourceMappingURL=testIntegration.js.map
