import {
  a as F,
  c as M
} from "./_deps/WR5VDSCU.js";
import {
  c as S,
  h as V,
  i as $
} from "./_deps/OQFRUWLA.js";
import {
  b as h,
  e as X
} from "./_deps/IVQGLTSC.js";
import {
  a as I,
  c as L,
  d as N,
  e as W,
  f as z,
  g as q
} from "./_deps/JHKV5S25.js";
import {
  d as R,
  e as C,
  g as H
} from "./_deps/SMJ6X5F7.js";
import {
  e as O,
  g as P
} from "./_deps/SZVQRWFS.js";
import {
  a as A,
  b as x,
  c as w,
  d as k,
  f as U
} from "./_deps/75JH2J25.js";
import "./_deps/6XQQNYIR.js";
import {
  j as e,
  n as J
} from "./_deps/3TDUHHJO.js";
import {
  a as d
} from "./_deps/RUVYHBJQ.js";

// convex/evaluations.ts
J();
X();
var Ee = k({
  args: {
    videoId: e.optional(e.id("videos")),
    transcriptionId: e.id("transcriptions"),
    videoType: R,
    transcript: e.string(),
    userId: e.optional(e.id("users")),
    autoRetry: e.optional(e.boolean())
  },
  returns: e.object({
    success: e.boolean(),
    evaluationId: e.string(),
    status: C
  }),
  handler: /* @__PURE__ */ d(async (a, o) => {
    let { videoId: n, transcriptionId: t, videoType: i, transcript: s, userId: c, autoRetry: l } = o;
    try {
      if (!s || s.trim().length === 0)
        throw new Error("\u30C8\u30E9\u30F3\u30B9\u30AF\u30EA\u30D7\u30C8\u304C\u7A7A\u3067\u3059");
      let r = c;
      if (!r && n) {
        let m = await a.db.get(n);
        m && (r = m.user_id);
      }
      if (!r)
        throw new Error("\u30E6\u30FC\u30B6\u30FCID\u304C\u53D6\u5F97\u3067\u304D\u307E\u305B\u3093");
      let { evaluationId: g, externalId: u } = await q(a, {
        transcriptionId: t,
        ...n && { videoId: n },
        userId: r,
        videoType: i
      });
      return console.log(`[startEvaluationInternal] \u30B9\u30B1\u30B8\u30E5\u30FC\u30E9\u30FC\u5B9F\u884C\u958B\u59CB: evaluationId=${g}`), await a.scheduler.runAfter(0, h.evaluations.processEvaluation, {
        evaluationId: g,
        transcript: s,
        videoType: i
      }), console.log(`[startEvaluationInternal] \u30B9\u30B1\u30B8\u30E5\u30FC\u30E9\u30FC\u5B9F\u884C\u5B8C\u4E86: evaluationId=${g}`), {
        success: !0,
        evaluationId: u,
        status: "processing"
      };
    } catch (r) {
      throw console.error("\u5185\u90E8\u8A55\u4FA1\u51E6\u7406\u30A8\u30E9\u30FC:", r), new Error(M(r, "\u8A55\u4FA1\u51E6\u7406\u306B\u5931\u6557\u3057\u307E\u3057\u305F"));
    }
  }, "handler")
}), Ae = x({
  args: {
    externalId: e.string()
  },
  returns: e.union(
    e.object({
      _id: e.id("evaluations"),
      external_id: e.string()
    }),
    e.null()
  ),
  handler: /* @__PURE__ */ d(async (a, o) => {
    let n = await a.db.query("evaluations").withIndex("by_external_id", (t) => t.eq("external_id", o.externalId)).unique();
    return !n || !n.external_id ? null : {
      _id: n._id,
      external_id: n.external_id
    };
  }, "handler")
}), Te = w({
  args: {
    videoId: e.optional(e.id("videos")),
    transcriptionId: e.optional(e.id("transcriptions")),
    videoType: e.optional(R),
    transcript: e.optional(e.string()),
    userId: e.optional(e.id("users")),
    // Migration: Updated from better_auth_users to users
    autoRetry: e.optional(e.boolean())
  },
  returns: e.object({
    success: e.boolean(),
    evaluationId: e.string(),
    status: C,
    criteria: e.optional(
      e.object({
        hearingAbility: e.optional(
          e.object({
            minScore: e.number(),
            maxScore: e.number(),
            description: e.string(),
            scales: e.record(e.string(), e.string())
          })
        ),
        problemSetting: e.optional(
          e.object({
            minScore: e.number(),
            maxScore: e.number(),
            description: e.string(),
            scales: e.record(e.string(), e.string())
          })
        ),
        knowledge: e.optional(
          e.object({
            minScore: e.number(),
            maxScore: e.number(),
            description: e.string(),
            scales: e.record(e.string(), e.string())
          })
        ),
        negotiation: e.optional(
          e.object({
            minScore: e.number(),
            maxScore: e.number(),
            description: e.string(),
            scales: e.record(e.string(), e.string())
          })
        ),
        businessManners: e.optional(
          e.object({
            minScore: e.number(),
            maxScore: e.number(),
            description: e.string(),
            scales: e.record(e.string(), e.string())
          })
        )
      })
    )
  }),
  handler: /* @__PURE__ */ d(async (a, o) => {
    let { videoId: n, transcriptionId: t, videoType: i, transcript: s, userId: c } = o;
    try {
      let { identity: l } = await P(a);
      if (s) {
        let T = S(s, {
          type: "content",
          maxLength: 5e4
          // 50KB制限
        });
        if (!T.isValid)
          throw new Error(`\u30C8\u30E9\u30F3\u30B9\u30AF\u30EA\u30D7\u30C8\u304C\u7121\u52B9\u3067\u3059: ${T.error}`);
      }
      L(t, s);
      let r = N(i), g = W(c, l), { transcriptionId: u, transcript: m } = await z(a, t, s, n), { evaluationId: _, externalId: p } = await q(a, {
        transcriptionId: u,
        ...n && { videoId: n },
        userId: g,
        videoType: r
      });
      await a.scheduler.runAfter(0, h.evaluations.processEvaluation, {
        evaluationId: _,
        transcript: m,
        videoType: r
      });
      let f = await D(a, r);
      return {
        success: !0,
        evaluationId: p,
        status: "processing",
        criteria: f
      };
    } catch (l) {
      throw console.error("\u8A55\u4FA1\u51E6\u7406\u30A8\u30E9\u30FC:", l), new Error(M(l, "\u8A55\u4FA1\u51E6\u7406\u306B\u5931\u6557\u3057\u307E\u3057\u305F"));
    }
  }, "handler")
}), ke = A({
  args: {
    evaluationId: e.string()
  },
  returns: e.union(
    e.object({
      success: e.boolean(),
      status: e.literal("processing"),
      evaluationId: e.string(),
      message: e.string()
    }),
    e.object({
      success: e.boolean(),
      status: e.literal("completed"),
      evaluationId: e.string(),
      finalScore: e.number(),
      recommendation: e.union(
        e.literal("\u5408\u683C"),
        e.literal("\u8981\u6539\u5584"),
        e.literal("\u4E0D\u5408\u683C"),
        e.literal("\u51E6\u7406\u4E2D"),
        e.literal("\u30A8\u30E9\u30FC")
      ),
      evaluationDetails: e.optional(
        e.record(
          e.string(),
          e.union(
            e.number(),
            e.string(),
            e.boolean(),
            e.object({
              score: e.number(),
              analysis: e.string(),
              strength: e.optional(e.string()),
              weakness: e.optional(e.string())
            })
          )
        )
      ),
      goodPoints: e.array(e.string()),
      improvementPoints: e.array(e.string()),
      recommendedActions: e.array(e.string())
    }),
    e.object({
      success: e.boolean(),
      status: e.literal("failed"),
      evaluationId: e.string(),
      error: e.string(),
      errorCode: e.optional(e.string())
    })
  ),
  handler: /* @__PURE__ */ d(async (a, o) => {
    let { evaluationId: n } = o;
    try {
      if (await P(a), !S(n, {
        type: "name",
        maxLength: 100
      }).isValid)
        throw new I("Invalid evaluation ID", "INVALID_PARAMETER");
      let i = await a.db.query("evaluationDetails").withIndex("by_external_id", (c) => c.eq("evaluation_id_external", n)).first();
      if (!i)
        return {
          success: !1,
          status: "failed",
          evaluationId: n,
          error: "Evaluation not found",
          errorCode: "EVALUATION_NOT_FOUND"
        };
      let s = await a.db.get(i.evaluation_id);
      return s ? (await O(a, s.user_id), s.status === "processing" ? {
        success: !0,
        status: "processing",
        evaluationId: n,
        message: "Evaluation is still in progress"
      } : s.status === "failed" ? {
        success: !1,
        status: "failed",
        evaluationId: n,
        error: s.error_message || "Evaluation failed",
        errorCode: "EVALUATION_FAILED"
      } : s.status === "completed" ? {
        success: !0,
        status: "completed",
        evaluationId: n,
        finalScore: i.final_score,
        recommendation: i.recommendation,
        evaluationDetails: i.evaluation_details,
        goodPoints: i.good_points || [
          "\u30AF\u30E9\u30A4\u30A2\u30F3\u30C8\u3078\u306E\u50BE\u8074\u59FF\u52E2\u304C\u7D20\u6674\u3089\u3057\u3044",
          "\u5C02\u9580\u77E5\u8B58\u3092\u5206\u304B\u308A\u3084\u3059\u304F\u8AAC\u660E\u3067\u304D\u3066\u3044\u308B",
          "\u30D3\u30B8\u30CD\u30B9\u30DE\u30CA\u30FC\u304C\u5FB9\u5E95\u3055\u308C\u3066\u3044\u308B"
        ],
        improvementPoints: i.improvement_points || [
          "\u5207\u308A\u8FD4\u3057\u306E\u30D0\u30EA\u30A8\u30FC\u30B7\u30E7\u30F3\u3092\u5897\u3084\u3059\u3068\u3088\u308A\u826F\u3044",
          "\u6570\u5B57\u3092\u4F7F\u3063\u305F\u5177\u4F53\u7684\u306A\u63D0\u6848\u3092\u5897\u3084\u3059"
        ],
        recommendedActions: i.recommended_actions || [
          "\u4EA4\u6E09\u8853\u306B\u95A2\u3059\u308B\u7814\u4FEE\u3092\u53D7\u8B1B\u3059\u308B",
          "\u6210\u529F\u4E8B\u4F8B\u306E\u5206\u6790\u3068\u5B9F\u8DF5\u7DF4\u7FD2\u3092\u884C\u3046"
        ]
      } : {
        success: !1,
        status: "failed",
        evaluationId: n,
        error: `Unexpected evaluation status: ${s.status}`,
        errorCode: "UNEXPECTED_STATUS"
      }) : {
        success: !1,
        status: "failed",
        evaluationId: n,
        error: "Evaluation record not found",
        errorCode: "EVALUATION_RECORD_NOT_FOUND"
      };
    } catch (t) {
      if (console.error("Error in getEvaluationResult:", t), t instanceof I)
        throw t;
      return {
        success: !1,
        status: "failed",
        evaluationId: n,
        error: "Internal error occurred",
        errorCode: "INTERNAL_ERROR"
      };
    }
  }, "handler")
}), Me = A({
  args: {
    userId: e.optional(e.id("users")),
    // Migration: Updated from better_auth_users to users
    page: e.optional(e.number()),
    limit: e.optional(e.number()),
    videoType: e.optional(
      e.union(
        e.literal("M&A\u30ED\u30FC\u30EB\u30D7\u30EC\u30A4"),
        e.literal("AD\u7DE0\u7D50\u63D0\u6848"),
        e.literal("\u4F01\u696D\u6982\u8981\u66F8\u63D0\u6848"),
        e.literal("\u8B72\u6E21\u67B6\u96FB")
      )
    ),
    status: e.optional(
      e.union(
        e.literal("pending"),
        e.literal("processing"),
        e.literal("completed"),
        e.literal("failed")
      )
    )
  },
  returns: e.object({
    success: e.boolean(),
    evaluations: e.array(
      e.object({
        evaluationId: e.string(),
        videoType: R,
        finalScore: e.number(),
        recommendation: e.union(
          e.literal("\u5408\u683C"),
          e.literal("\u8981\u6539\u5584"),
          e.literal("\u4E0D\u5408\u683C"),
          e.literal("\u51E6\u7406\u4E2D"),
          e.literal("\u30A8\u30E9\u30FC")
        ),
        createdAt: e.number(),
        status: e.union(
          e.literal("pending"),
          e.literal("processing"),
          e.literal("completed"),
          e.literal("failed")
        ),
        hasManagerReview: e.boolean()
      })
    ),
    pagination: e.object({
      currentPage: e.number(),
      totalPages: e.number(),
      totalItems: e.number(),
      itemsPerPage: e.number()
    }),
    filters: e.object({
      userId: e.optional(e.string()),
      videoType: e.optional(e.string()),
      status: e.optional(e.string())
    })
  }),
  handler: /* @__PURE__ */ d(async (a, o) => {
    let { userId: n, page: t = 1, limit: i = 10, videoType: s, status: c } = o, l = await a.auth.getUserIdentity();
    if (!l)
      throw new I("Authentication required", "UNAUTHORIZED");
    if (t < 1 || i < 1 || i > 100)
      throw new I("Invalid pagination parameters", "INVALID_PAGINATION", {
        page: t,
        limit: i,
        maxLimit: 100
      });
    try {
      let r = n || l.subject;
      if (r !== l.subject)
        throw new I(
          "Access denied: You can only access your own evaluation history",
          "ACCESS_DENIED",
          { requestedUserId: r, currentUserId: l.subject }
        );
      let g;
      r ? s && c ? g = a.db.query("evaluations").withIndex(
        "by_user_and_video_type",
        (p) => p.eq("user_id", r).eq("video_type", s)
      ) : c ? g = a.db.query("evaluations").withIndex(
        "by_status_and_user",
        (p) => p.eq("status", c).eq("user_id", r)
      ) : g = a.db.query("evaluations").withIndex("by_user_id", (p) => p.eq("user_id", r)) : c ? g = a.db.query("evaluations").withIndex("by_status", (p) => p.eq("status", c)) : g = a.db.query("evaluations");
      let u = await g.order("desc").take(i * t), m = u.slice((t - 1) * i, t * i);
      return {
        success: !0,
        evaluations: await Promise.all(
          m.map(async (p) => {
            let f = await a.db.query("evaluationDetails").withIndex("by_evaluation_id", (T) => T.eq("evaluation_id", p._id)).first();
            return {
              evaluationId: f?.evaluation_id_external || p._id,
              videoType: p.video_type,
              finalScore: f?.final_score || 0,
              recommendation: f?.recommendation || "\u51E6\u7406\u4E2D",
              createdAt: p._creationTime,
              status: p.status,
              hasManagerReview: !!f?.manager_review
            };
          })
        ),
        pagination: {
          currentPage: t,
          totalPages: Math.ceil(u.length / i),
          totalItems: u.length,
          itemsPerPage: i
        },
        filters: {
          userId: r,
          videoType: s,
          status: c
        }
      };
    } catch (r) {
      throw console.error("[getEvaluationHistory] \u30A8\u30E9\u30FC:", r), new I(
        "Failed to retrieve evaluation history",
        "HISTORY_RETRIEVAL_ERROR",
        { error: r instanceof Error ? r.message : "Unknown error" }
      );
    }
  }, "handler")
}), Re = A({
  args: {
    videoType: e.optional(e.string())
  },
  returns: e.object({
    success: e.boolean(),
    data: e.record(
      e.string(),
      e.object({
        minScore: e.number(),
        maxScore: e.number(),
        description: e.string(),
        scales: e.record(e.string(), e.string())
      })
    )
  }),
  handler: /* @__PURE__ */ d(async (a, o) => {
    let { videoType: n } = o;
    if (n) {
      let s = await D(a, n);
      return {
        success: !0,
        data: {
          [n]: s
        }
      };
    }
    let t = ["M&A\u30ED\u30FC\u30EB\u30D7\u30EC\u30A4", "AD\u7DE0\u7D50\u63D0\u6848", "\u8B72\u6E21\u67B6\u96FB", "\u4F01\u696D\u6982\u8981\u66F8\u63D0\u6848"], i = {};
    for (let s of t)
      i[s] = await D(a, s);
    return {
      success: !0,
      data: i
    };
  }, "handler")
}), De = w({
  args: {
    videoType: e.string(),
    criteria: e.record(
      e.string(),
      e.object({
        minScore: e.number(),
        maxScore: e.number(),
        description: e.string(),
        scales: e.record(e.string(), e.string())
      })
    )
  },
  returns: e.object({
    success: e.boolean(),
    message: e.string(),
    videoType: e.string(),
    updatedCriteria: e.record(
      e.string(),
      e.object({
        minScore: e.number(),
        maxScore: e.number(),
        description: e.string(),
        scales: e.record(e.string(), e.string())
      })
    )
  }),
  handler: /* @__PURE__ */ d(async (a, o) => {
    let { videoType: n, criteria: t } = o;
    await F(a);
    let i = await a.db.query("evaluationCriteria").withIndex("by_video_type", (l) => l.eq("video_type", n)).collect();
    await Promise.all(i.map((l) => a.db.delete(l._id)));
    let s = /* @__PURE__ */ d((l) => typeof l == "object" && l !== null && "minScore" in l && "maxScore" in l && "scales" in l, "isCriterionObject"), c = Object.entries(t).map(([l, r]) => s(r) ? a.db.insert("evaluationCriteria", {
      video_type: n,
      criterion_key: l,
      criterion_name: l,
      description: r.description || "",
      scale: r,
      is_active: !0
      // created_by field is optional for system-generated criteria
    }) : null);
    return await Promise.all(c.filter((l) => l !== null)), {
      success: !0,
      message: "\u8A55\u4FA1\u57FA\u6E96\u3092\u66F4\u65B0\u3057\u307E\u3057\u305F",
      videoType: n,
      updatedCriteria: t
    };
  }, "handler")
}), Pe = w({
  args: {
    transcript: e.string()
  },
  returns: e.object({
    success: e.boolean(),
    detectedType: e.optional(e.string()),
    confidence: e.number(),
    keywords: e.optional(e.array(e.string())),
    applicableCriteria: e.optional(e.any()),
    message: e.optional(e.string()),
    manualSelection: e.optional(
      e.object({
        required: e.boolean(),
        availableTypes: e.array(e.string()),
        continueUrl: e.string()
      })
    )
  }),
  handler: /* @__PURE__ */ d(async (a, o) => {
    try {
      let n = S(o.transcript, {
        type: "content",
        maxLength: 5e4,
        // 大きなトランスクリプトを許可
        minLength: 10
      });
      if (!n.isValid)
        throw new Error(`Invalid transcript: ${n.error}`);
      let t = n.processed, i = await ee(t);
      if (i.confidence >= 0.5) {
        let c = await D(a, i.type);
        return {
          success: !0,
          detectedType: i.type,
          confidence: i.confidence,
          keywords: i.keywords,
          applicableCriteria: c
        };
      }
      let s = [
        "02. \u521D\u56DE\u8B72\u6E21\u30AA\u30FC\u30CA\u30FC\u9762\u8AC7",
        "M&A\u30ED\u30FC\u30EB\u30D7\u30EC\u30A4",
        "AD\u7DE0\u7D50\u63D0\u6848",
        "\u8B72\u6E21\u67B6\u96FB"
      ];
      return {
        success: !1,
        confidence: i.confidence,
        message: "\u52D5\u753B\u30BF\u30A4\u30D7\u3092\u5224\u5B9A\u3067\u304D\u307E\u305B\u3093\u3067\u3057\u305F",
        manualSelection: {
          required: !0,
          availableTypes: s,
          continueUrl: "/api/evaluate"
        }
      };
    } catch (n) {
      throw console.error("[detectVideoType] Error:", V(n)), new Error(M(n, "\u52D5\u753B\u30BF\u30A4\u30D7\u5224\u5B9A"));
    }
  }, "handler")
}), Ce = w({
  args: {
    videoType: e.string(),
    newCriteria: e.object({
      name: e.string(),
      description: e.string(),
      scales: e.any()
    })
  },
  returns: e.object({
    success: e.boolean(),
    message: e.string(),
    criteriaId: e.string(),
    criteria: e.any()
  }),
  handler: /* @__PURE__ */ d(async (a, o) => {
    let { videoType: n, newCriteria: t } = o, { name: i, description: s, scales: c } = t;
    return {
      success: !0,
      message: "\u65B0\u3057\u3044\u8A55\u4FA1\u9805\u76EE\u3092\u8FFD\u52A0\u3057\u307E\u3057\u305F",
      criteriaId: (await a.db.insert("evaluationCriteria", {
        video_type: n,
        criterion_key: i,
        criterion_name: i,
        description: s,
        scale: c,
        is_active: !0
        // created_by field is optional for system-generated criteria
      })).toString(),
      criteria: t
    };
  }, "handler")
}), qe = A({
  args: {
    userId: e.id("users"),
    settingsType: e.union(
      e.literal("user"),
      e.literal("organization"),
      e.literal("default"),
      e.literal("templates"),
      e.literal("inherited"),
      e.literal("custom_override"),
      e.literal("system_management")
    ),
    organizationId: e.optional(e.string()),
    department: e.optional(e.string()),
    customOverride: e.optional(e.any()),
    includeValidation: e.optional(e.boolean()),
    performDeepValidation: e.optional(e.boolean()),
    includeOptimizationRecommendations: e.optional(e.boolean()),
    adminAccess: e.optional(e.boolean()),
    adminUserId: e.optional(e.id("users")),
    includeChangeHistory: e.optional(e.boolean()),
    includeChangeAnalytics: e.optional(e.boolean()),
    includeFullHistory: e.optional(e.boolean()),
    includeExternalValidation: e.optional(e.boolean()),
    validateOverride: e.optional(e.boolean()),
    enforceRestrictions: e.optional(e.boolean())
  },
  returns: e.any(),
  handler: /* @__PURE__ */ d(async (a, o) => {
    let {
      userId: n,
      settingsType: t,
      organizationId: i,
      department: s,
      customOverride: c,
      includeValidation: l,
      performDeepValidation: r,
      includeOptimizationRecommendations: g,
      adminAccess: u,
      adminUserId: m,
      includeChangeHistory: _,
      includeChangeAnalytics: p,
      includeFullHistory: f,
      includeExternalValidation: T,
      validateOverride: G,
      enforceRestrictions: Y
    } = o;
    try {
      let E = await a.auth.getUserIdentity();
      if (!E)
        throw new Error("\u8A8D\u8A3C\u304C\u5FC5\u8981\u3067\u3059");
      if (!u && n !== E.subject)
        throw new Error("\u30A2\u30AF\u30BB\u30B9\u6A29\u9650\u304C\u3042\u308A\u307E\u305B\u3093");
      if (![
        "user",
        "organization",
        "default",
        "templates",
        "inherited",
        "custom_override",
        "system_management"
      ].includes(t))
        throw new Error("\u4E0D\u6B63\u306A\u8A2D\u5B9A\u30BF\u30A4\u30D7\u3067\u3059");
      let y = {}, v = {
        source: t,
        retrievedAt: Date.now(),
        userId: n
      };
      switch (t) {
        case "user":
          y = await j(a, n), v.source = "user";
          break;
        case "organization":
          if (!i)
            throw new Error("\u7D44\u7E54ID\u304C\u5FC5\u8981\u3067\u3059");
          y = await B(a, i, s), v.source = "organization", v.organizationId = i, s && (v.department = s);
          break;
        case "default":
          y = await te(a), v.source = "system_default", v.isSystemDefault = !0;
          break;
        case "templates":
          y = await K(a), v.source = "templates";
          break;
        case "inherited":
          y = await ne(a, n, i, Y), v.source = "mixed";
          break;
        case "custom_override":
          y = await ae(a, n, c, G), v.source = "custom_override", v.isCustomOverride = !0;
          break;
        case "system_management":
          y = await ie(a, m), v.source = "system_management";
          break;
      }
      return (l || r) && (y.validation = await re(a, y, r)), g && (y.recommendations = await se(a, y), y.suggestedOptimizations = await oe(a, y)), _ && (y.changeHistory = await le(a, n)), p && (y.changeAnalytics = await ce(a, n)), u && (v.adminAccess = !0, v.accessedBy = m, v.accessTimestamp = Date.now()), {
        ...y,
        metadata: v,
        settingsId: y.settingsId || `settings-${Date.now()}`,
        settingsType: t,
        userId: n
      };
    } catch (E) {
      throw console.error("\u8A55\u4FA1\u8A2D\u5B9A\u53D6\u5F97\u30A8\u30E9\u30FC:", E), new Error(E instanceof Error ? E.message : "\u8A2D\u5B9A\u53D6\u5F97\u306B\u5931\u6557\u3057\u307E\u3057\u305F");
    }
  }, "handler")
}), Ve = A({
  args: {
    evaluationId: e.string()
  },
  returns: e.object({
    success: e.boolean(),
    evaluationId: e.string(),
    humanEvaluation: e.optional(e.any()),
    aiEvaluation: e.optional(e.any()),
    accuracyMetrics: e.optional(e.any())
  }),
  handler: /* @__PURE__ */ d(async (a, o) => {
    let { evaluationId: n } = o, t = await a.db.query("evaluationDetails").withIndex("by_external_id", (l) => l.eq("evaluation_id_external", n)).first();
    if (!t)
      throw new Error("Evaluation not found");
    let i = await a.db.get(t.evaluation_id);
    if (!i)
      throw new Error("Evaluation not found");
    let s = {
      evaluatedBy: "ai-system",
      evaluatedAt: i.evaluation_completed_at,
      scores: {
        hearingAbility: i.hearingAbility || 0,
        problemSetting: i.problemSetting || 0,
        knowledge: i.knowledge || 0,
        negotiation: i.negotiation || 0,
        businessManners: i.businessManners || 0
      },
      finalScore: t.final_score,
      recommendation: t.recommendation
    };
    return {
      success: !0,
      evaluationId: n,
      humanEvaluation: void 0,
      // 人間評価は未実装
      aiEvaluation: s,
      accuracyMetrics: null
    };
  }, "handler")
}), je = w({
  args: {
    videoIds: e.array(e.id("videos"))
  },
  returns: e.object({
    success: e.boolean(),
    consistencyMetrics: e.object({
      standardDeviation: e.number(),
      isConsistent: e.boolean(),
      evaluations: e.array(e.any())
    }),
    acceptableDeviation: e.number()
  }),
  handler: /* @__PURE__ */ d(async (a, o) => {
    let { videoIds: n } = o;
    if (n.length < 2)
      throw new Error("2\u3064\u4EE5\u4E0A\u306E\u52D5\u753BID\u304C\u5FC5\u8981\u3067\u3059");
    let t = await Promise.all(
      n.map(async (r) => {
        let g = await a.db.query("evaluations").withIndex("by_video_id", (m) => m.eq("video_id", r)).first();
        if (g) {
          let m = await a.db.query("evaluationDetails").withIndex("by_evaluation_id", (_) => _.eq("evaluation_id", g._id)).first();
          return {
            videoId: r,
            scores: {
              hearingAbility: g.hearingAbility || 0,
              problemSetting: g.problemSetting || 0,
              knowledge: g.knowledge || 0,
              negotiation: g.negotiation || 0,
              businessManners: g.businessManners || 0
            },
            finalScore: m?.final_score || 0,
            recommendation: m?.recommendation || "\u672A\u8A55\u4FA1"
          };
        }
        let u = 8 + Math.random() * 2;
        return {
          videoId: r,
          scores: {
            hearingAbility: u + Math.random() - 0.5,
            problemSetting: u + Math.random() - 0.5,
            knowledge: u + Math.random() - 0.5,
            negotiation: u + Math.random() - 0.5,
            businessManners: u + Math.random() - 0.5
          },
          finalScore: u * 10,
          recommendation: "\u5408\u683C"
        };
      })
    ), i = t.map((r) => r.finalScore), s = i.reduce((r, g) => r + g, 0) / i.length, c = i.reduce((r, g) => r + (g - s) ** 2, 0) / i.length, l = Math.sqrt(c);
    return {
      success: !0,
      consistencyMetrics: {
        standardDeviation: Math.round(l * 100) / 100,
        isConsistent: l < 1,
        evaluations: t
      },
      acceptableDeviation: 1
    };
  }, "handler")
}), xe = w({
  args: {
    evaluationId: e.string()
  },
  returns: e.object({
    success: e.boolean(),
    data: e.object({
      newEvaluationId: e.string(),
      originalEvaluationId: e.string(),
      status: e.string()
    }),
    message: e.string()
  }),
  handler: /* @__PURE__ */ d(async (a, o) => {
    let { evaluationId: n } = o, t = await a.db.query("evaluationDetails").withIndex("by_external_id", (r) => r.eq("evaluation_id_external", n)).first();
    if (!t)
      throw new Error("\u6307\u5B9A\u3055\u308C\u305F\u8A55\u4FA1\u304C\u898B\u3064\u304B\u308A\u307E\u305B\u3093");
    let i = await a.db.get(t.evaluation_id);
    if (!i)
      throw new Error("\u8A55\u4FA1\u30C7\u30FC\u30BF\u304C\u898B\u3064\u304B\u308A\u307E\u305B\u3093");
    let s = await a.db.insert("evaluations", {
      transcription_id: i.transcription_id,
      ...i.video_id && { video_id: i.video_id },
      user_id: i.user_id,
      video_type: i.video_type,
      status: "processing",
      retry_count: (i.retry_count || 0) + 1,
      evaluation_requested_at: Date.now()
    }), c = `eval-${Date.now()}-${s}`;
    await a.db.insert("evaluationDetails", {
      evaluation_id: s,
      video_type: i.video_type || "M&A\u30ED\u30FC\u30EB\u30D7\u30EC\u30A4",
      final_score: 0,
      recommendation: "\u51E6\u7406\u4E2D",
      retry_count: (i.retry_count || 0) + 1,
      evaluation_id_external: c,
      status: "processing"
    });
    let l = await a.db.get(i.transcription_id);
    return await a.scheduler.runAfter(100, h.evaluations.processEvaluation, {
      evaluationId: s,
      transcript: l?.text || "",
      videoType: i.video_type || "M&A\u30ED\u30FC\u30EB\u30D7\u30EC\u30A4"
    }), {
      success: !0,
      data: {
        newEvaluationId: c,
        originalEvaluationId: n,
        status: "processing"
      },
      message: "\u518D\u8A55\u4FA1\u3092\u958B\u59CB\u3057\u307E\u3057\u305F"
    };
  }, "handler")
}), Ue = w({
  args: {
    evaluationId: e.string(),
    managerComments: e.string(),
    overrideScore: e.optional(e.number()),
    overrideRecommendation: e.optional(e.string()),
    reviewerId: e.id("users")
    // Migration: Updated from better_auth_users to users
  },
  returns: e.object({
    success: e.boolean(),
    message: e.string(),
    evaluationId: e.string()
  }),
  handler: /* @__PURE__ */ d(async (a, o) => {
    try {
      let n = S(o.evaluationId, { maxLength: 100 });
      if (!n.isValid)
        throw new Error(`Invalid evaluation ID: ${n.error}`);
      let t = S(o.managerComments, {
        type: "content",
        maxLength: 2e3,
        minLength: 1
      });
      if (!t.isValid)
        throw new Error(`Invalid comments: ${t.error}`);
      let i = $(o.reviewerId, "users");
      if (!i.isValid)
        throw new Error(`Invalid reviewer ID: ${i.message}`);
      if (o.overrideScore !== void 0 && (o.overrideScore < 0 || o.overrideScore > 5 || o.overrideScore * 2 % 1 !== 0))
        throw new Error("Override score must be between 0 and 5 with 0.5 increments");
      let s;
      if (o.overrideRecommendation) {
        let r = S(o.overrideRecommendation, { maxLength: 50 });
        if (!r.isValid)
          throw new Error(`Invalid recommendation: ${r.error}`);
        s = r.processed;
      }
      let c = await a.db.query("evaluationDetails").withIndex(
        "by_external_id",
        (r) => r.eq("evaluation_id_external", n.processed)
      ).first();
      if (!c)
        throw new Error("Evaluation not found");
      let l = {
        comments: t.processed,
        overrideScore: o.overrideScore,
        overrideRecommendation: s,
        reviewedAt: Date.now(),
        reviewerId: o.reviewerId
      };
      return await a.db.patch(c._id, {
        manager_review: l,
        final_score: o.overrideScore || c.final_score,
        recommendation: s || c.recommendation
      }), {
        success: !0,
        message: "\u30DE\u30CD\u30FC\u30B8\u30E3\u30FC\u30EC\u30D3\u30E5\u30FC\u304C\u8FFD\u52A0\u3055\u308C\u307E\u3057\u305F",
        evaluationId: n.processed
      };
    } catch (n) {
      throw console.error("[addManagerReview] Error:", V(n)), new Error(M(n, "\u30DE\u30CD\u30FC\u30B8\u30E3\u30FC\u30EC\u30D3\u30E5\u30FC\u306E\u8FFD\u52A0"));
    }
  }, "handler")
}), Oe = U({
  args: {
    evaluationId: e.id("evaluations"),
    transcript: e.string(),
    videoType: e.string()
  },
  returns: e.null(),
  handler: /* @__PURE__ */ d(async (a, o) => {
    let { evaluationId: n, transcript: t, videoType: i } = o;
    console.log(`[processEvaluation] \u958B\u59CB: evaluationId=${n}, videoType=${i}, transcript\u9577=${t.length}`);
    try {
      console.log("[processEvaluation] AI\u8A55\u4FA1\u30A8\u30F3\u30B8\u30F3\u521D\u671F\u5316...");
      let { HybridEvaluationEngine: s } = await import("./_deps/55KEVOLV.js"), c = new s();
      console.log("[processEvaluation] AI\u8A55\u4FA1\u51E6\u7406\u958B\u59CB...");
      let l = await c.process({
        transcriptionId: n,
        transcript: t,
        videoType: i,
        doAddSpeaker: 0,
        // 話者情報は既に処理済みと仮定
        metadata: {}
      });
      if (console.log("[processEvaluation] AI\u8A55\u4FA1\u51E6\u7406\u5B8C\u4E86"), !l.success)
        throw new Error(`AI\u8A55\u4FA1\u51E6\u7406\u306B\u5931\u6557\u3057\u307E\u3057\u305F: ${l.errors?.[0]?.error?.message || "Unknown error"}`);
      console.log("[processEvaluation] AI\u8A55\u4FA1\u7D50\u679C\u751F\u6210\u5B8C\u4E86:", l.evaluation), console.log("[processEvaluation] AI\u8A55\u4FA1\u7D50\u679C\u306E\u30AD\u30FC:", Object.keys(l.evaluation || {})), console.log("[processEvaluation] \u8A73\u7D30\u306A\u30C7\u30FC\u30BF\u69CB\u9020:", JSON.stringify(l.evaluation, null, 2)), console.log("[processEvaluation] \u8A55\u4FA1\u7D50\u679C\u66F4\u65B0\u958B\u59CB..."), await a.runMutation(h.evaluations.updateEvaluationResultWithAI, {
        evaluationId: n,
        result: l.evaluation,
        videoType: i
      }), console.log("[processEvaluation] \u8A55\u4FA1\u7D50\u679C\u66F4\u65B0\u5B8C\u4E86");
    } catch (s) {
      console.error("[processEvaluation] \u30A8\u30E9\u30FC\u767A\u751F:", s), await a.runMutation(h.evaluations.markEvaluationFailed, {
        evaluationId: n,
        error: s instanceof Error ? s.message : "Unknown error"
      }), console.log("[processEvaluation] \u8A55\u4FA1\u5931\u6557\u3068\u3057\u3066\u8A18\u9332\u5B8C\u4E86");
    }
    return console.log(`[processEvaluation] \u5B8C\u4E86: evaluationId=${n}`), null;
  }, "handler")
}), He = k({
  args: {
    evaluationId: e.id("evaluations"),
    result: e.any()
  },
  returns: e.null(),
  handler: /* @__PURE__ */ d(async (a, o) => {
    let { evaluationId: n, result: t } = o;
    await a.db.patch(n, {
      status: "completed",
      ...t.scores,
      evaluation_completed_at: Date.now()
    });
    let i = await a.db.query("evaluationDetails").withIndex("by_evaluation_id", (s) => s.eq("evaluation_id", n)).first();
    return i && await a.db.patch(i._id, {
      final_score: t.finalScore,
      recommendation: t.recommendation,
      good_points: t.goodPoints,
      improvement_points: t.improvementPoints,
      recommended_actions: t.recommendedActions,
      evaluation_details: t.evaluationDetails,
      status: "completed"
    }), null;
  }, "handler")
}), Le = k({
  args: {
    evaluationId: e.id("evaluations"),
    result: e.any(),
    videoType: e.string()
  },
  returns: e.null(),
  handler: /* @__PURE__ */ d(async (a, o) => {
    let { evaluationId: n, result: t, videoType: i } = o;
    try {
      if (console.log(`[updateEvaluationResultWithAI] \u958B\u59CB: evaluationId=${n}, videoType=${i}`), t.error || !t || typeof t != "object") {
        let u = t?.error || t?.message || "AI\u8A55\u4FA1\u7D50\u679C\u304C\u7121\u52B9\u3067\u3059";
        return console.error(`[updateEvaluationResultWithAI] AI\u8A55\u4FA1\u7D50\u679C\u306B\u30A8\u30E9\u30FC\u3042\u308A: ${u}`), await a.runMutation(h.evaluations.markEvaluationFailed, {
          evaluationId: n,
          error: u
        }), null;
      }
      await a.db.patch(n, {
        status: "completed",
        evaluation_completed_at: Date.now()
      });
      let s = 0, c = 0, l = {}, r = {};
      if (i === "\u8B70\u6E21\u67B6\u96FB" && t.callTone !== void 0)
        l.callTone = t.callTone, l.callListening = t.callListening, l.callScheduling = t.callScheduling, l.callImportantInfo = t.callImportantInfo, l.callDeepHearing = t.callDeepHearing, s = (t.callTone + t.callListening + t.callScheduling + t.callImportantInfo + t.callDeepHearing) / 5, c = 5, r.callTone_analysis = t.callTone_analysis, r.callTone_strength = t.callTone_strength, r.callTone_weakness = t.callTone_weakness, r.callListening_analysis = t.callListening_analysis, r.callListening_strength = t.callListening_strength, r.callListening_weakness = t.callListening_weakness, r.callScheduling_analysis = t.callScheduling_analysis, r.callScheduling_strength = t.callScheduling_strength, r.callScheduling_weakness = t.callScheduling_weakness, r.callImportantInfo_analysis = t.callImportantInfo_analysis, r.callImportantInfo_strength = t.callImportantInfo_strength, r.callImportantInfo_weakness = t.callImportantInfo_weakness, r.callDeepHearing_analysis = t.callDeepHearing_analysis, r.callDeepHearing_strength = t.callDeepHearing_strength, r.callDeepHearing_weakness = t.callDeepHearing_weakness;
      else if (i === "\u521D\u56DE\u9762\u8AC7" && (t.hearingAbility !== void 0 || t.scores || t.evaluation)) {
        let u = /* @__PURE__ */ d((m) => typeof m == "number" ? m : 0, "getScoreValue");
        l.hearingAbility = u(t.hearingAbility), l.problemSetting = u(t.problemSetting), l.knowledge = u(t.knowledge), l.negotiation = u(t.negotiation), l.businessManners = u(t.businessManners), s = (l.hearingAbility + l.problemSetting + l.knowledge + l.negotiation + l.businessManners) / 5, c = 5, console.log("[updateEvaluationResultWithAI] \u521D\u56DE\u9762\u8AC7\u306E\u30B9\u30B3\u30A2:", {
          hearingAbility: l.hearingAbility,
          problemSetting: l.problemSetting,
          knowledge: l.knowledge,
          negotiation: l.negotiation,
          businessManners: l.businessManners,
          avgScore: s
        }), r.hearingAbility_analysis = t.hearingAbility_analysis, r.hearingAbility_strength = t.hearingAbility_strength, r.hearingAbility_weakness = t.hearingAbility_weakness, r.problemSetting_analysis = t.problemSetting_analysis, r.problemSetting_strength = t.problemSetting_strength, r.problemSetting_weakness = t.problemSetting_weakness, r.knowledge_analysis = t.knowledge_analysis, r.knowledge_strength = t.knowledge_strength, r.knowledge_weakness = t.knowledge_weakness, r.negotiation_analysis = t.negotiation_analysis, r.negotiation_strength = t.negotiation_strength, r.negotiation_weakness = t.negotiation_weakness, r.businessManners_analysis = t.businessManners_analysis, r.businessManners_strength = t.businessManners_strength, r.businessManners_weakness = t.businessManners_weakness;
      } else if (i === "AD\u7DE0\u7D50\u63D0\u6848" && t.adHearingAbility !== void 0)
        l.adHearingAbility = t.adHearingAbility, l.adKnowledge = t.adKnowledge, l.adProposalAbility = t.adProposalAbility, l.adNegotiation = t.adNegotiation, l.adRelationshipBuilding = t.adRelationshipBuilding, s = (t.adHearingAbility + t.adKnowledge + t.adProposalAbility + t.adNegotiation + t.adRelationshipBuilding) / 5, c = 5, r.adHearingAbility_analysis = t.adHearingAbility_analysis, r.adHearingAbility_strength = t.adHearingAbility_strength, r.adHearingAbility_weakness = t.adHearingAbility_weakness, r.adKnowledge_analysis = t.adKnowledge_analysis, r.adKnowledge_strength = t.adKnowledge_strength, r.adKnowledge_weakness = t.adKnowledge_weakness, r.adProposalAbility_analysis = t.adProposalAbility_analysis, r.adProposalAbility_strength = t.adProposalAbility_strength, r.adProposalAbility_weakness = t.adProposalAbility_weakness, r.adNegotiation_analysis = t.adNegotiation_analysis, r.adNegotiation_strength = t.adNegotiation_strength, r.adNegotiation_weakness = t.adNegotiation_weakness, r.adRelationshipBuilding_analysis = t.adRelationshipBuilding_analysis, r.adRelationshipBuilding_strength = t.adRelationshipBuilding_strength, r.adRelationshipBuilding_weakness = t.adRelationshipBuilding_weakness;
      else if (i === "\u4F01\u696D\u6982\u8981\u66F8\u63D0\u6848" && t.imNeedsHearingProposal !== void 0)
        l.imNeedsHearingProposal = t.imNeedsHearingProposal, l.imSellerUnderstanding = t.imSellerUnderstanding, l.imBuyerUnderstanding = t.imBuyerUnderstanding, l.imSynergyProposal = t.imSynergyProposal, l.imTestClosing = t.imTestClosing, s = (t.imNeedsHearingProposal + t.imSellerUnderstanding + t.imBuyerUnderstanding + t.imSynergyProposal + t.imTestClosing) / 5, c = 5, r.imNeedsHearingProposal_analysis = t.imNeedsHearingProposal_analysis, r.imNeedsHearingProposal_strength = t.imNeedsHearingProposal_strength, r.imNeedsHearingProposal_weakness = t.imNeedsHearingProposal_weakness, r.imSellerUnderstanding_analysis = t.imSellerUnderstanding_analysis, r.imSellerUnderstanding_strength = t.imSellerUnderstanding_strength, r.imSellerUnderstanding_weakness = t.imSellerUnderstanding_weakness, r.imBuyerUnderstanding_analysis = t.imBuyerUnderstanding_analysis, r.imBuyerUnderstanding_strength = t.imBuyerUnderstanding_strength, r.imBuyerUnderstanding_weakness = t.imBuyerUnderstanding_weakness, r.imSynergyProposal_analysis = t.imSynergyProposal_analysis, r.imSynergyProposal_strength = t.imSynergyProposal_strength, r.imSynergyProposal_weakness = t.imSynergyProposal_weakness, r.imTestClosing_analysis = t.imTestClosing_analysis, r.imTestClosing_strength = t.imTestClosing_strength, r.imTestClosing_weakness = t.imTestClosing_weakness;
      else {
        let u = `\u52D5\u753B\u30BF\u30A4\u30D7\u300C${i}\u300D\u306B\u5BFE\u3059\u308B\u6709\u52B9\u306A\u8A55\u4FA1\u30C7\u30FC\u30BF\u304C\u898B\u3064\u304B\u308A\u307E\u305B\u3093`;
        return console.error(`[updateEvaluationResultWithAI] ${u}`), await a.runMutation(h.evaluations.markEvaluationFailed, {
          evaluationId: n,
          error: u
        }), null;
      }
      c > 0 && (await a.db.patch(n, {
        ...l,
        ...r,
        total_score: s,
        overallComment: t.overallComment,
        improvementSummary: t.improvementSummary
      }), console.log(`[updateEvaluationResultWithAI] \u8A73\u7D30\u60C5\u5831\u3082\u542B\u3081\u3066\u4FDD\u5B58\u5B8C\u4E86: \u30B9\u30B3\u30A2=${s}, \u8A73\u7D30\u30D5\u30A3\u30FC\u30EB\u30C9\u6570=${Object.keys(r).length}`));
      let g = await a.db.query("evaluationDetails").withIndex("by_evaluation_id", (u) => u.eq("evaluation_id", n)).first();
      if (g) {
        let u = t.improvementSummary ? t.improvementSummary.split(`
`).filter((_) => _.trim()) : [], m = "\u8981\u6539\u5584";
        s >= 4 ? m = "\u5408\u683C" : s < 2 && (m = "\u4E0D\u5408\u683C"), await a.db.patch(g._id, {
          final_score: s,
          recommendation: m,
          improvement_points: u,
          status: "completed"
        });
      }
      console.log(`[updateEvaluationResultWithAI] \u5B8C\u4E86: evaluationId=${n}, avgScore=${s}`);
    } catch (s) {
      console.error("[updateEvaluationResultWithAI] \u30A8\u30E9\u30FC:", s);
      try {
        await a.runMutation(h.evaluations.markEvaluationFailed, {
          evaluationId: n,
          error: s instanceof Error ? s.message : String(s)
        });
      } catch (c) {
        console.error("[updateEvaluationResultWithAI] \u5931\u6557\u8A18\u9332\u6642\u306B\u3082\u30A8\u30E9\u30FC:", c);
      }
      throw s;
    }
    return null;
  }, "handler")
}), Ne = k({
  args: {
    evaluationId: e.id("evaluations"),
    error: e.string()
  },
  returns: e.null(),
  handler: /* @__PURE__ */ d(async (a, o) => {
    let { evaluationId: n, error: t } = o;
    await a.db.patch(n, {
      status: "failed",
      error_message: t,
      evaluation_completed_at: Date.now()
    });
    let i = await a.db.query("evaluationDetails").withIndex("by_evaluation_id", (s) => s.eq("evaluation_id", n)).first();
    return i && await a.db.patch(i._id, {
      status: "failed",
      final_score: H.ERROR_DEFAULT_SCORE,
      recommendation: "\u30A8\u30E9\u30FC"
    }), null;
  }, "handler")
});
async function D(a, o) {
  let n = await a.db.query("evaluationCriteria").withIndex(
    "by_video_type_and_active",
    (i) => i.eq("video_type", o).eq("is_active", !0)
  ).collect(), t = {};
  for (let i of n)
    t[i.criterion_key] = i.scale;
  return Object.keys(t).length === 0 ? Z(o) : t;
}
d(D, "getCriteriaForVideoType");
function Z(a) {
  let o = {
    "M&A\u30ED\u30FC\u30EB\u30D7\u30EC\u30A4": {
      hearingAbility: {
        minScore: 1,
        maxScore: 10,
        description: "\u30AF\u30E9\u30A4\u30A2\u30F3\u30C8\u306E\u8A71\u3092\u7684\u78BA\u306B\u805E\u304D\u53D6\u308A\u3001\u7406\u89E3\u3059\u308B\u80FD\u529B",
        scales: {
          1: "\u5168\u304F\u805E\u304D\u53D6\u308C\u3066\u3044\u306A\u3044",
          5: "\u57FA\u672C\u7684\u306A\u5185\u5BB9\u306F\u805E\u304D\u53D6\u308C\u3066\u3044\u308B",
          10: "\u8A73\u7D30\u307E\u3067\u6B63\u78BA\u306B\u805E\u304D\u53D6\u308A\u3001\u6DF1\u304F\u7406\u89E3\u3057\u3066\u3044\u308B"
        }
      },
      problemSetting: {
        minScore: 1,
        maxScore: 10,
        description: "\u8AB2\u984C\u8A2D\u5B9A\u3068\u554F\u984C\u89E3\u6C7A\u80FD\u529B",
        scales: {
          1: "\u8AB2\u984C\u3092\u7406\u89E3\u3067\u304D\u3066\u3044\u306A\u3044",
          5: "\u57FA\u672C\u7684\u306A\u8AB2\u984C\u306F\u7406\u89E3\u3057\u3066\u3044\u308B",
          10: "\u8907\u96D1\u306A\u8AB2\u984C\u3082\u7684\u78BA\u306B\u8A2D\u5B9A\u3057\u89E3\u6C7A\u7B56\u3092\u63D0\u793A\u3067\u304D\u308B"
        }
      },
      knowledge: {
        minScore: 1,
        maxScore: 10,
        description: "\u5C02\u9580\u77E5\u8B58\u3068\u696D\u754C\u7406\u89E3",
        scales: {
          1: "\u57FA\u672C\u7684\u306A\u77E5\u8B58\u304C\u4E0D\u8DB3\u3057\u3066\u3044\u308B",
          5: "\u6A19\u6E96\u7684\u306A\u77E5\u8B58\u3092\u6709\u3057\u3066\u3044\u308B",
          10: "\u9AD8\u5EA6\u306A\u5C02\u9580\u77E5\u8B58\u3092\u6D3B\u7528\u3067\u304D\u308B"
        }
      },
      negotiation: {
        minScore: 1,
        maxScore: 10,
        description: "\u4EA4\u6E09\u529B\u3068\u8AAC\u5F97\u529B",
        scales: {
          1: "\u4EA4\u6E09\u30B9\u30AD\u30EB\u304C\u4E0D\u5341\u5206",
          5: "\u57FA\u672C\u7684\u306A\u4EA4\u6E09\u304C\u3067\u304D\u308B",
          10: "\u9AD8\u5EA6\u306A\u4EA4\u6E09\u8853\u3092\u99C6\u4F7F\u3067\u304D\u308B"
        }
      },
      businessManners: {
        minScore: 1,
        maxScore: 10,
        description: "\u30D3\u30B8\u30CD\u30B9\u30DE\u30CA\u30FC\u3068\u793C\u5100",
        scales: {
          1: "\u30DE\u30CA\u30FC\u304C\u4E0D\u9069\u5207",
          5: "\u57FA\u672C\u7684\u306A\u30DE\u30CA\u30FC\u306F\u8EAB\u306B\u3064\u3044\u3066\u3044\u308B",
          10: "\u5B8C\u74A7\u306A\u30D3\u30B8\u30CD\u30B9\u30DE\u30CA\u30FC\u3092\u5B9F\u8DF5\u3057\u3066\u3044\u308B"
        }
      }
    }
  };
  return o[a] || o["M&A\u30ED\u30FC\u30EB\u30D7\u30EC\u30A4"];
}
d(Z, "getDefaultCriteriaForVideoType");
async function ee(a) {
  let o = {
    "M&A\u30ED\u30FC\u30EB\u30D7\u30EC\u30A4": ["M&A", "\u8CB7\u53CE", "\u58F2\u5374", "\u4F01\u696D\u4FA1\u5024", "\u30C7\u30E5\u30FC\u30C7\u30EA\u30B8\u30A7\u30F3\u30B9"],
    AD\u7DE0\u7D50\u63D0\u6848: ["AD", "\u30A2\u30C9\u30D0\u30A4\u30B6\u30EA\u30FC", "\u5951\u7D04", "\u624B\u6570\u6599", "\u696D\u52D9\u59D4\u8A17"],
    \u8B72\u6E21\u67B6\u96FB: ["\u8B72\u6E21", "\u67B6\u96FB", "\u96FB\u8A71", "\u30AA\u30FC\u30CA\u30FC", "\u521D\u56DE"],
    \u4F01\u696D\u6982\u8981\u66F8\u63D0\u6848: ["\u4F01\u696D\u6982\u8981\u66F8", "IM", "\u8CC7\u6599", "\u63D0\u6848", "\u8CB7\u3044\u624B"]
  }, n = "", t = 0, i = [];
  for (let [s, c] of Object.entries(o)) {
    let l = c.filter((g) => a.includes(g)), r = l.length / c.length;
    r > t && (t = r, n = s, i = l);
  }
  return {
    type: n || "M&A\u30ED\u30FC\u30EB\u30D7\u30EC\u30A4",
    confidence: t,
    keywords: i
  };
}
d(ee, "detectVideoTypeInternal");
async function j(a, o) {
  let n = await a.db.query("evaluationSettings").withIndex("by_user_id", (t) => t.eq("userId", o)).filter((t) => t.eq(t.field("settingsType"), "user")).first();
  return n ? {
    settingsId: n._id,
    criteriaWeights: n.criteriaWeights || b(),
    passingScore: n.passingScore || 70,
    evaluationTimeout: n.evaluationTimeout || 3e5,
    retryLimit: n.retryLimit || 3,
    aiModel: n.aiModel || "gpt-4o",
    qualityThreshold: n.qualityThreshold || 0.85,
    customPrompts: n.customPrompts || {},
    notificationSettings: n.notificationSettings || Q(),
    metadata: {
      createdAt: n.createdAt,
      updatedAt: n.updatedAt,
      version: n.version || 1
    }
  } : await de();
}
d(j, "getUserSettings");
async function B(a, o, n) {
  let t = await a.db.query("organizationSettings").withIndex("by_organization_id", (s) => s.eq("organizationId", o)).first();
  if (!t)
    throw new Error("\u7D44\u7E54\u8A2D\u5B9A\u304C\u898B\u3064\u304B\u308A\u307E\u305B\u3093");
  let i = {
    organizationId: o,
    organizationName: t.organizationName,
    criteriaWeights: t.defaultCriteriaWeights || b(),
    passingScore: t.organizationPassingScore || 75,
    evaluationTimeout: t.evaluationTimeLimit || 6e5,
    retryLimit: t.maxRetries || 5,
    mandatorySettings: t.mandatorySettings || {},
    metadata: {
      source: "organization",
      inheritanceLevel: "organization",
      canOverride: t.inheritanceRules?.allowUserOverride || !0
    }
  };
  if (n && t.departmentSettings?.[n]) {
    let s = t.departmentSettings[n];
    i = {
      ...i,
      ...s,
      metadata: {
        ...i.metadata,
        department: n,
        departmentSpecific: !0
      }
    };
  }
  return i;
}
d(B, "getOrganizationSettings");
async function te(a) {
  return {
    isSystemDefault: !0,
    ...(await a.db.query("systemSettings").withIndex("by_settings_type", (t) => t.eq("settingsType", "default")).first())?.systemDefaults || {
      criteriaWeights: b(),
      passingScore: 60,
      evaluationTimeout: 18e4,
      retryLimit: 2,
      aiModel: "gpt-4o",
      qualityThreshold: 0.85
    },
    metadata: {
      source: "system_default",
      isInherited: !1,
      customizations: []
    }
  };
}
d(te, "getDefaultSettings");
async function K(a) {
  return {
    templates: [
      {
        name: "basic",
        description: "\u30D0\u30E9\u30F3\u30B9\u306E\u53D6\u308C\u305F\u6A19\u6E96\u8A2D\u5B9A",
        criteriaWeights: b(),
        passingScore: 70,
        evaluationTimeout: 3e5,
        retryLimit: 3
      },
      {
        name: "strict",
        description: "\u53B3\u683C\u306A\u8A55\u4FA1\u57FA\u6E96\u8A2D\u5B9A",
        criteriaWeights: {
          hearingAbility: 0.3,
          problemSetting: 0.25,
          knowledge: 0.2,
          negotiation: 0.15,
          businessManners: 0.1
        },
        passingScore: 85,
        evaluationTimeout: 24e4,
        retryLimit: 2
      },
      {
        name: "customizable",
        description: "\u30AB\u30B9\u30BF\u30DE\u30A4\u30BA\u53EF\u80FD\u306A\u8A2D\u5B9A",
        allowCustomization: !0,
        criteriaWeights: b(),
        passingScore: 75,
        evaluationTimeout: 36e4,
        retryLimit: 4
      }
    ]
  };
}
d(K, "getTemplateSettings");
async function ne(a, o, n, t) {
  let i = await j(a, o), s = {};
  if (n)
    try {
      s = await B(a, n);
    } catch {
    }
  let c = {
    ...s,
    ...i,
    settingsType: "inherited",
    metadata: {
      inheritanceInfo: {
        source: "mixed",
        overriddenFields: [],
        inheritedFields: [],
        mandatoryFields: s.mandatorySettings ? Object.keys(s.mandatorySettings) : []
      }
    }
  };
  return Object.keys(i).forEach((l) => {
    l in s && i[l] !== s[l] ? c.metadata.inheritanceInfo.overriddenFields.push(l) : l in s && c.metadata.inheritanceInfo.inheritedFields.push(l);
  }), c;
}
d(ne, "getInheritedSettings");
async function ae(a, o, n, t) {
  let i = await j(a, o);
  if (t && n) {
    let s = await ue(n);
    if (!s.isValid)
      return {
        ...i,
        validation: s,
        fallbackSettings: i
      };
  }
  return {
    ...i,
    ...n,
    metadata: {
      ...i.metadata,
      isCustomOverride: !0,
      baseSettingsId: i.settingsId,
      overriddenAt: Date.now(),
      overrideReason: n?.customNote || "\u30AB\u30B9\u30BF\u30E0\u30AA\u30FC\u30D0\u30FC\u30E9\u30A4\u30C9"
    }
  };
}
d(ae, "getCustomOverrideSettings");
async function ie(a, o) {
  return {
    systemOverview: {
      totalUsers: 100,
      // Mock data
      customizedSettingsCount: 25,
      organizationsCount: 5
    },
    userSettingsStatistics: {
      averagePassingScore: 73.5,
      commonCriteriaWeights: b(),
      settingsDistribution: {
        default: 60,
        customized: 40
      }
    },
    organizationSettings: [],
    defaultTemplates: await K(a),
    adminFeatures: {
      canModifyDefaults: !0,
      canOverrideUserSettings: !0,
      canViewAllSettings: !0
    }
  };
}
d(ie, "getSystemManagementSettings");
async function re(a, o, n) {
  let t = {
    isValid: !0,
    warnings: [],
    recommendations: [],
    criteriaWeightsValid: !0,
    totalWeightSum: 0
  };
  if (o.criteriaWeights) {
    let i = Object.values(o.criteriaWeights);
    t.totalWeightSum = i.reduce((s, c) => s + c, 0), t.criteriaWeightsValid = Math.abs(t.totalWeightSum - 1) < 0.01, t.criteriaWeightsValid || (t.isValid = !1, t.warnings.push("\u91CD\u307F\u914D\u5206\u306E\u5408\u8A08\u304C1.0\u3068\u7570\u306A\u308A\u307E\u3059"));
  }
  return n && (t.criteriaValidation = {
    totalWeightValid: t.criteriaWeightsValid,
    individualWeightsValid: !0,
    balanceScore: ge(o.criteriaWeights)
  }, t.configValidation = {
    passingScoreValid: o.passingScore >= 0 && o.passingScore <= 100,
    timeoutReasonable: o.evaluationTimeout > 0 && o.evaluationTimeout <= 36e5,
    retryLimitValid: o.retryLimit >= 0 && o.retryLimit <= 10
  }, o.customPrompts && (t.promptValidation = {
    warnings: []
  }, Object.entries(o.customPrompts).forEach(([i, s]) => {
    typeof s == "string" && (s.length < 10 && t.promptValidation.warnings.push(`\u30D7\u30ED\u30F3\u30D7\u30C8\u304C\u77ED\u3059\u304E\u307E\u3059: ${i}`), s.length > 2e3 && t.promptValidation.warnings.push(`\u30D7\u30ED\u30F3\u30D7\u30C8\u304C\u9577\u3059\u304E\u307E\u3059: ${i}`));
  })), t.performanceImpact = {
    estimatedProcessingTime: me(o),
    resourceUsage: "medium"
  }), o.qualityThreshold > 0.92 && t.warnings.push("\u9AD8\u54C1\u8CEA\u8A2D\u5B9A\u306B\u3088\u308AAI\u51E6\u7406\u6642\u9593\u304C\u5897\u52A0\u3059\u308B\u53EF\u80FD\u6027\u304C\u3042\u308A\u307E\u3059"), t;
}
d(re, "validateSettings");
async function se(a, o) {
  let n = {
    balance: [],
    performance: [],
    usability: []
  };
  if (o.criteriaWeights) {
    let t = Object.values(o.criteriaWeights), i = Math.max(...t), s = Math.min(...t);
    i - s > 0.3 && n.balance.push("\u91CD\u307F\u914D\u5206\u306E\u504F\u308A\u3092\u6539\u5584\u3059\u308B\u3053\u3068\u3092\u63A8\u5968");
  }
  return o.qualityThreshold > 0.95 && n.performance.push("\u54C1\u8CEA\u95BE\u5024\u3092\u4E0B\u3052\u308B\u3053\u3068\u3067\u51E6\u7406\u901F\u5EA6\u304C\u5411\u4E0A"), o.evaluationTimeout < 18e4 && n.usability.push("\u8A55\u4FA1\u6642\u9593\u5236\u9650\u3092\u5EF6\u9577\u3059\u308B\u3053\u3068\u3092\u63A8\u5968"), n;
}
d(se, "getOptimizationRecommendations");
async function oe(a, o) {
  return {
    balancedWeights: b(),
    recommendedTimeout: Math.max(o.evaluationTimeout * 1.5, 18e4),
    recommendedQualityThreshold: Math.min(o.qualityThreshold * 0.95, 0.9)
  };
}
d(oe, "getSuggestedOptimizations");
async function le(a, o) {
  return [
    {
      version: 3,
      changeReason: "\u53B3\u683C\u5316\uFF1A\u5408\u683C\u57FA\u6E96\u3068\u6642\u9593\u5236\u9650\u3092\u8ABF\u6574",
      changedFields: ["passingScore", "evaluationTimeout"],
      timestamp: Date.now() - 864e5,
      changes: {
        passingScore: { from: 75, to: 80 },
        evaluationTimeout: { from: 3e5, to: 36e4 }
      }
    },
    {
      version: 2,
      changeReason: "\u521D\u56DE\u8ABF\u6574\uFF1A\u805E\u304D\u53D6\u308A\u80FD\u529B\u3092\u91CD\u8996",
      changedFields: ["criteriaWeights", "passingScore"],
      timestamp: Date.now() - 1728e5,
      changes: {
        criteriaWeights: {
          from: b(),
          to: {
            hearingAbility: 0.25,
            problemSetting: 0.25,
            knowledge: 0.2,
            negotiation: 0.2,
            businessManners: 0.1
          }
        }
      }
    },
    {
      version: 1,
      changeType: "initial_creation",
      changeReason: "\u521D\u671F\u8A2D\u5B9A\u4F5C\u6210",
      timestamp: Date.now() - 2592e5
    }
  ];
}
d(le, "getChangeHistory");
async function ce(a, o) {
  return {
    trendAnalysis: {
      passingScoreTrend: "increasing",
      changeFrequency: "high"
    },
    frequencyAnalysis: {
      totalChanges: 4,
      averageTimeBetweenChanges: 864e5,
      mostChangedField: "passingScore"
    },
    stabilityMetrics: {
      stabilityScore: 0.75,
      settingsVolatility: "medium"
    }
  };
}
d(ce, "getChangeAnalytics");
function b() {
  return {
    hearingAbility: 0.2,
    problemSetting: 0.2,
    knowledge: 0.2,
    negotiation: 0.2,
    businessManners: 0.2
  };
}
d(b, "getDefaultCriteriaWeights");
function Q() {
  return {
    emailEnabled: !0,
    systemEnabled: !0,
    slackEnabled: !1
  };
}
d(Q, "getDefaultNotificationSettings");
async function de() {
  return {
    criteriaWeights: b(),
    passingScore: 70,
    evaluationTimeout: 3e5,
    retryLimit: 3,
    aiModel: "gpt-4o",
    qualityThreshold: 0.85,
    customPrompts: {},
    notificationSettings: Q(),
    metadata: {
      createdAt: Date.now(),
      updatedAt: Date.now(),
      version: 1
    }
  };
}
d(de, "getDefaultUserSettings");
async function ue(a) {
  let o = [];
  if (a.criteriaWeights) {
    let t = Object.values(a.criteriaWeights).reduce((i, s) => i + s, 0);
    Math.abs(t - 1) > 0.01 && o.push("\u91CD\u307F\u914D\u5206\u306E\u5408\u8A08\u304C1.0\u3092\u8D85\u3048\u3066\u3044\u307E\u3059");
  }
  return a.passingScore && (a.passingScore < 0 || a.passingScore > 100) && o.push("\u5408\u683C\u70B9\u306F0-100\u306E\u7BC4\u56F2\u3067\u8A2D\u5B9A\u3057\u3066\u304F\u3060\u3055\u3044"), a.evaluationTimeout && a.evaluationTimeout <= 0 && o.push("\u8A55\u4FA1\u5236\u9650\u6642\u9593\u306F\u6B63\u306E\u5024\u3067\u3042\u308B\u5FC5\u8981\u304C\u3042\u308A\u307E\u3059"), {
    isValid: o.length === 0,
    errors: o
  };
}
d(ue, "validateCustomOverride");
function ge(a) {
  if (!a) return 0;
  let o = Object.values(a), n = o.reduce((i, s) => i + s, 0) / o.length, t = o.reduce((i, s) => i + Math.pow(s - n, 2), 0) / o.length;
  return Math.max(0, 1 - t * 5);
}
d(ge, "calculateBalanceScore");
function me(a) {
  let o = 2e3;
  return a.qualityThreshold > 0.9 && (o *= 1.5), a.customPrompts && Object.keys(a.customPrompts).length > 0 && (o *= 1.2), o;
}
d(me, "calculateProcessingTime");
export {
  Ce as addEvaluationCriterion,
  Ue as addManagerReview,
  Pe as detectVideoType,
  Ve as getEvaluationAccuracy,
  Ae as getEvaluationByExternalId,
  Re as getEvaluationCriteria,
  Me as getEvaluationHistory,
  ke as getEvaluationResult,
  qe as getEvaluationSettings,
  Ne as markEvaluationFailed,
  Oe as processEvaluation,
  xe as retryEvaluation,
  je as runConsistencyTest,
  Te as startEvaluation,
  Ee as startEvaluationInternal,
  De as updateEvaluationCriteria,
  He as updateEvaluationResult,
  Le as updateEvaluationResultWithAI
};
//# sourceMappingURL=evaluations.js.map
