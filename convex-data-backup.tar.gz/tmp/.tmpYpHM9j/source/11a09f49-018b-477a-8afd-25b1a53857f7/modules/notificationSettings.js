import {
  a as c,
  e as f
} from "./_deps/IVQGLTSC.js";
import {
  a as d,
  c as l
} from "./_deps/75JH2J25.js";
import "./_deps/6XQQNYIR.js";
import {
  j as e,
  n as b
} from "./_deps/3TDUHHJO.js";
import {
  a as o
} from "./_deps/RUVYHBJQ.js";

// convex/notificationSettings.ts
b();
f();
var _ = e.object({
  _id: e.id("notificationSettings"),
  _creationTime: e.number(),
  user_id: e.id("users"),
  // Migration: Updated from better_auth_users to users
  notification_type: e.string(),
  email_enabled: e.boolean(),
  system_enabled: e.boolean(),
  slack_enabled: e.boolean()
}), h = l({
  args: {
    user_id: e.id("users"),
    // Migration: Updated from better_auth_users to users
    notification_type: e.string(),
    email_enabled: e.boolean(),
    system_enabled: e.boolean(),
    slack_enabled: e.boolean()
  },
  returns: e.id("notificationSettings"),
  handler: /* @__PURE__ */ o(async (i, t) => {
    if (!await i.db.get(t.user_id))
      throw new Error("User not found");
    let n = await i.db.query("notificationSettings").withIndex(
      "by_user_id_and_type",
      (s) => s.eq("user_id", t.user_id).eq("notification_type", t.notification_type)
    ).collect();
    if (n.length > 0) {
      let s = n[0];
      return await i.db.patch(s._id, {
        email_enabled: t.email_enabled,
        system_enabled: t.system_enabled,
        slack_enabled: t.slack_enabled
      }), s._id;
    }
    return await i.db.insert("notificationSettings", {
      user_id: t.user_id,
      notification_type: t.notification_type,
      email_enabled: t.email_enabled,
      system_enabled: t.system_enabled,
      slack_enabled: t.slack_enabled
    });
  }, "handler")
}), w = l({
  args: {
    new_user_id: e.string(),
    notification_type: e.string(),
    email_enabled: e.boolean(),
    system_enabled: e.boolean(),
    slack_enabled: e.boolean()
  },
  returns: e.object({
    success: e.boolean(),
    setting_id: e.optional(e.id("notificationSettings"))
  }),
  handler: /* @__PURE__ */ o(async (i, t) => {
    throw new Error(
      "upsertNotificationSettingByNewUserId is deprecated. Use upsertNotificationSetting with unified user_id instead."
    );
  }, "handler")
}), S = d({
  args: {
    user_id: e.id("users")
    // Migration: Updated from better_auth_users to users - made required
  },
  returns: e.array(_),
  handler: /* @__PURE__ */ o(async (i, t) => await i.db.query("notificationSettings").withIndex("by_user_id", (a) => a.eq("user_id", t.user_id)).collect(), "handler")
}), k = d({
  args: {
    user_id: e.id("users"),
    // Migration: Updated from better_auth_users to users - made required
    notification_type: e.string()
  },
  returns: e.union(_, e.null()),
  handler: /* @__PURE__ */ o(async (i, t) => {
    let a = await i.db.query("notificationSettings").withIndex(
      "by_user_id_and_type",
      (n) => n.eq("user_id", t.user_id).eq("notification_type", t.notification_type)
    ).collect();
    return a.length > 0 ? a[0] : null;
  }, "handler")
}), N = l({
  args: {
    user_id: e.id("users"),
    // Migration: Updated from better_auth_users to users
    settings: e.array(
      e.object({
        notification_type: e.string(),
        email_enabled: e.boolean(),
        system_enabled: e.boolean(),
        slack_enabled: e.boolean()
      })
    )
  },
  returns: e.object({
    success: e.boolean(),
    updated_count: e.number()
  }),
  handler: /* @__PURE__ */ o(async (i, t) => {
    if (!await i.db.get(t.user_id))
      throw new Error("User not found");
    let n = 0;
    for (let s of t.settings)
      try {
        await i.runMutation(c.notificationSettings.upsertNotificationSetting, {
          user_id: t.user_id,
          notification_type: s.notification_type,
          email_enabled: s.email_enabled,
          system_enabled: s.system_enabled,
          slack_enabled: s.slack_enabled
        }), n++;
      } catch (r) {
        console.error(`Failed to update setting for ${s.notification_type}:`, r);
      }
    return {
      success: n === t.settings.length,
      updated_count: n
    };
  }, "handler")
}), q = l({
  args: {
    setting_id: e.id("notificationSettings"),
    user_id: e.id("users")
    // Migration: Updated from better_auth_users to users // 権限チェック用
  },
  returns: e.object({
    success: e.boolean()
  }),
  handler: /* @__PURE__ */ o(async (i, t) => {
    let a = await i.db.get(t.setting_id);
    if (!a)
      throw new Error("Notification setting not found");
    if (a.user_id !== t.user_id)
      throw new Error("Notification setting does not belong to user");
    return await i.db.delete(t.setting_id), { success: !0 };
  }, "handler")
}), x = l({
  args: {
    user_id: e.id("users")
    // Migration: Updated from better_auth_users to users
  },
  returns: e.object({
    success: e.boolean(),
    created_count: e.number()
  }),
  handler: /* @__PURE__ */ o(async (i, t) => {
    if (!await i.db.get(t.user_id))
      throw new Error("User not found");
    let n = [
      {
        notification_type: "evaluation_complete",
        email_enabled: !1,
        // メール通知は無効
        system_enabled: !0,
        slack_enabled: !1
      },
      {
        notification_type: "roleplay_application",
        email_enabled: !1,
        // メール通知は無効
        system_enabled: !0,
        slack_enabled: !1
      },
      {
        notification_type: "system",
        email_enabled: !1,
        // メール通知は無効
        system_enabled: !0,
        slack_enabled: !1
      },
      {
        notification_type: "training_reminder",
        email_enabled: !1,
        // メール通知は無効
        system_enabled: !0,
        slack_enabled: !1
      }
    ], s = 0;
    for (let r of n)
      try {
        await i.runMutation(c.notificationSettings.upsertNotificationSetting, {
          user_id: t.user_id,
          notification_type: r.notification_type,
          email_enabled: r.email_enabled,
          system_enabled: r.system_enabled,
          slack_enabled: r.slack_enabled
        }), s++;
      } catch (u) {
        console.error(
          `Failed to create default setting for ${r.notification_type}:`,
          u
        );
      }
    return {
      success: s === n.length,
      created_count: s
    };
  }, "handler")
}), j = d({
  args: {
    user_id: e.id("users"),
    // Migration: Updated from better_auth_users to users - made required
    notification_type: e.string(),
    channel: e.union(e.literal("email"), e.literal("system"), e.literal("slack"))
  },
  returns: e.object({
    enabled: e.boolean(),
    setting_exists: e.boolean()
  }),
  handler: /* @__PURE__ */ o(async (i, t) => {
    let a = await i.db.query("notificationSettings").withIndex(
      "by_user_id_and_type",
      (r) => r.eq("user_id", t.user_id).eq("notification_type", t.notification_type)
    ).collect(), n = a.length > 0 ? a[0] : null;
    if (!n)
      return {
        enabled: t.channel === "system",
        // システム通知はデフォルトで有効
        setting_exists: !1
      };
    let s = !1;
    switch (t.channel) {
      case "email":
        s = n.email_enabled;
        break;
      case "system":
        s = n.system_enabled;
        break;
      case "slack":
        s = n.slack_enabled;
        break;
    }
    return {
      enabled: s,
      setting_exists: !0
    };
  }, "handler")
}), I = d({
  args: {
    user_id: e.id("users")
    // Migration: Updated from better_auth_users to users - made required
  },
  returns: e.object({
    total_settings: e.number(),
    email_enabled_count: e.number(),
    system_enabled_count: e.number(),
    slack_enabled_count: e.number(),
    notification_types: e.array(e.string())
  }),
  handler: /* @__PURE__ */ o(async (i, t) => {
    let a = await i.db.query("notificationSettings").withIndex("by_user_id", (n) => n.eq("user_id", t.user_id)).collect();
    return {
      total_settings: a.length,
      email_enabled_count: a.filter((n) => n.email_enabled).length,
      system_enabled_count: a.filter((n) => n.system_enabled).length,
      slack_enabled_count: a.filter((n) => n.slack_enabled).length,
      notification_types: a.map((n) => n.notification_type)
    };
  }, "handler")
});
export {
  N as bulkUpdateNotificationSettings,
  x as createDefaultNotificationSettings,
  q as deleteNotificationSetting,
  k as getNotificationSetting,
  S as getNotificationSettings,
  I as getNotificationStats,
  j as isNotificationEnabled,
  h as upsertNotificationSetting,
  w as upsertNotificationSettingByNewUserId
};
//# sourceMappingURL=notificationSettings.js.map
