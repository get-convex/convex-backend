import {
  b as y,
  c as b,
  d as v,
  e as _,
  f as h
} from "../_deps/26U3JTFN.js";
import {
  b as f,
  c as T,
  d as I,
  e as S,
  f as w
} from "../_deps/VZDVKQ3V.js";
import {
  b as g,
  d as c
} from "../_deps/75JH2J25.js";
import "../_deps/6XQQNYIR.js";
import {
  j as e,
  n as m
} from "../_deps/3TDUHHJO.js";
import {
  a as o
} from "../_deps/RUVYHBJQ.js";

// convex/internal/testing.ts
m();
var j = c({
  args: {
    videoType: e.string(),
    criteria: e.record(
      e.string(),
      e.object({
        minScore: e.number(),
        maxScore: e.number(),
        description: e.string(),
        scales: e.record(e.string(), e.string())
      })
    ),
    userId: e.id("users")
  },
  returns: e.object({
    success: e.boolean(),
    message: e.string(),
    videoType: e.string(),
    updatedCriteria: e.record(
      e.string(),
      e.object({
        minScore: e.number(),
        maxScore: e.number(),
        description: e.string(),
        scales: e.record(e.string(), e.string())
      })
    )
  }),
  handler: /* @__PURE__ */ o(async (s, t) => {
    let { videoType: r, criteria: i, userId: n } = t, u = await s.db.query("evaluationCriteria").withIndex("by_video_type", (a) => a.eq("video_type", r)).collect();
    await Promise.all(u.map((a) => s.db.delete(a._id)));
    let d = Object.entries(i).map(([a, l]) => s.db.insert("evaluationCriteria", {
      video_type: r,
      criterion_key: a,
      criterion_name: a,
      description: l.description || "",
      scale: l,
      is_active: !0
    }));
    return await Promise.all(d), {
      success: !0,
      message: "\u8A55\u4FA1\u57FA\u6E96\u3092\u66F4\u65B0\u3057\u307E\u3057\u305F",
      videoType: r,
      updatedCriteria: i
    };
  }, "handler")
}), A = c({
  args: {
    userId: e.id("users"),
    action: e.string()
  },
  returns: e.object({
    hasPermission: e.boolean(),
    reason: e.string()
  }),
  handler: /* @__PURE__ */ o(async (s, t) => {
    let { userId: r } = t, i = await s.db.get(r);
    return i ? i.role === "admin" ? {
      hasPermission: !0,
      reason: "\u7BA1\u7406\u8005\u6A29\u9650"
    } : {
      hasPermission: !1,
      reason: "\u6A29\u9650\u304C\u4E0D\u8DB3\u3057\u3066\u3044\u307E\u3059"
    } : {
      hasPermission: !1,
      reason: "\u30E6\u30FC\u30B6\u30FC\u304C\u898B\u3064\u304B\u308A\u307E\u305B\u3093"
    };
  }, "handler")
}), C = c({
  args: {
    videoType: e.string(),
    criteria: e.any(),
    userId: e.id("users")
  },
  returns: e.object({
    isValid: e.boolean(),
    errors: e.array(e.string())
  }),
  handler: /* @__PURE__ */ o(async (s, t) => {
    let { videoType: r, criteria: i } = t, n = [];
    return ["M&A\u30ED\u30FC\u30EB\u30D7\u30EC\u30A4", "AD\u7DE0\u7D50\u63D0\u6848", "\u4F01\u696D\u6982\u8981\u66F8\u63D0\u6848", "\u8B72\u6E21\u67B6\u96FB"].includes(r) || n.push("\u7121\u52B9\u306A\u52D5\u753B\u30BF\u30A4\u30D7\u3067\u3059"), typeof i != "object" || i === null ? n.push("\u8A55\u4FA1\u57FA\u6E96\u306F\u6709\u52B9\u306A\u30AA\u30D6\u30B8\u30A7\u30AF\u30C8\u3067\u3042\u308B\u5FC5\u8981\u304C\u3042\u308A\u307E\u3059") : Object.entries(i).forEach(([d, a]) => {
      !a.minScore && a.minScore !== 0 && n.push(`${d}: minScore\u304C\u5FC5\u9808\u3067\u3059`), !a.maxScore && a.maxScore !== 0 && n.push(`${d}: maxScore\u304C\u5FC5\u9808\u3067\u3059`), a.description || n.push(`${d}: description\u304C\u5FC5\u9808\u3067\u3059`), (!a.scales || typeof a.scales != "object") && n.push(`${d}: scales\u304C\u5FC5\u9808\u3067\u3059`);
    }), {
      isValid: n.length === 0,
      errors: n
    };
  }, "handler")
}), U = c({
  args: {
    videoType: e.string(),
    criteria1: e.any(),
    criteria2: e.any(),
    user1Id: e.id("users"),
    user2Id: e.id("users")
  },
  returns: e.object({
    success: e.boolean(),
    concurrencyHandled: e.boolean(),
    finalState: e.any()
  }),
  handler: /* @__PURE__ */ o(async (s, t) => {
    let { videoType: r, criteria1: i, criteria2: n, user1Id: u, user2Id: d } = t;
    try {
      let a = await s.db.get(u), l = await s.db.get(d);
      return !a || !l ? {
        success: !1,
        concurrencyHandled: !1,
        finalState: { error: "Users not found" }
      } : (await s.db.insert("evaluationCriteria", {
        video_type: r,
        criterion_key: "test1",
        criterion_name: "test1",
        description: "Test concurrent 1",
        scale: i,
        is_active: !0
      }), await s.db.insert("evaluationCriteria", {
        video_type: r,
        criterion_key: "test2",
        criterion_name: "test2",
        description: "Test concurrent 2",
        scale: n,
        is_active: !0
      }), {
        success: !0,
        concurrencyHandled: !0,
        finalState: { criteria1: i, criteria2: n }
      });
    } catch (a) {
      return {
        success: !1,
        concurrencyHandled: !1,
        finalState: { error: String(a) }
      };
    }
  }, "handler")
}), V = c({
  args: {
    scenario: e.string(),
    videoType: e.string(),
    criteria: e.any(),
    userId: e.id("users")
  },
  returns: e.object({
    success: e.boolean(),
    errorType: e.string(),
    message: e.string()
  }),
  handler: /* @__PURE__ */ o(async (s, t) => {
    let { scenario: r, videoType: i } = t;
    switch (r) {
      case "nonExistentVideoType":
        return {
          success: !1,
          errorType: "INVALID_VIDEO_TYPE",
          message: "\u5B58\u5728\u3057\u306A\u3044\u52D5\u753B\u30BF\u30A4\u30D7\u304C\u6307\u5B9A\u3055\u308C\u307E\u3057\u305F"
        };
      default:
        return {
          success: !0,
          errorType: "NONE",
          message: "\u30A8\u30E9\u30FC\u306F\u3042\u308A\u307E\u305B\u3093\u3067\u3057\u305F"
        };
    }
  }, "handler")
}), E = c({
  args: {
    scenario: e.string(),
    videoType: e.string(),
    criteria: e.any(),
    userId: e.id("users")
  },
  returns: e.object({
    securityPassed: e.boolean(),
    sanitizedCriteria: e.any()
  }),
  handler: /* @__PURE__ */ o(async (s, t) => {
    let { criteria: r } = t, i = {};
    return Object.entries(r).forEach(([n, u]) => {
      i[n] = {
        ...u,
        description: u.description?.replace(/<script.*?<\/script>/gi, ""),
        scales: Object.fromEntries(
          Object.entries(u.scales || {}).map(([d, a]) => [
            d,
            a?.toString().replace(/<script.*?<\/script>/gi, "")
          ])
        )
      };
    }), {
      securityPassed: !0,
      sanitizedCriteria: i
    };
  }, "handler")
}), P = c({
  args: {
    scenario: e.string(),
    videoType: e.string(),
    criteria: e.any(),
    userId: e.id("users")
  },
  returns: e.object({
    success: e.boolean(),
    executionTime: e.number(),
    processedCount: e.number(),
    memoryUsage: e.number()
  }),
  handler: /* @__PURE__ */ o(async (s, t) => {
    let { criteria: r } = t, i = Date.now(), n = Object.keys(r).length;
    return await new Promise((d) => setTimeout(d, 100)), {
      success: !0,
      executionTime: Date.now() - i,
      processedCount: n,
      memoryUsage: 50 * 1024 * 1024
      // Mock 50MB
    };
  }, "handler")
}), z = c({
  args: {
    videoType: e.string(),
    criteria: e.any(),
    userId: e.id("users")
  },
  returns: e.object({
    success: e.boolean(),
    processedInBatches: e.boolean(),
    memoryPeakUsage: e.number(),
    dataIntegrityCheck: e.boolean()
  }),
  handler: /* @__PURE__ */ o(async (s, t) => {
    let { criteria: r } = t;
    return {
      success: !0,
      processedInBatches: Object.keys(r).length > 10,
      memoryPeakUsage: 30 * 1024 * 1024,
      // Mock 30MB
      dataIntegrityCheck: !0
    };
  }, "handler")
}), M = c({
  args: {
    user_id: e.id("users"),
    clerk_session_id: e.string(),
    device_info: e.string(),
    ip_address: e.string(),
    user_agent: e.string(),
    expires_at: e.number(),
    last_activity_at: e.number(),
    is_active: e.boolean()
  },
  returns: e.null(),
  handler: /* @__PURE__ */ o(async (s, t) => null, "handler")
}), O = c({
  args: {
    userId: e.id("users"),
    settingsType: e.string(),
    criteriaWeights: e.optional(e.record(e.string(), e.number())),
    passingScore: e.optional(e.number()),
    evaluationTimeout: e.optional(e.number()),
    retryLimit: e.optional(e.number()),
    aiModel: e.optional(e.string()),
    qualityThreshold: e.optional(e.number()),
    customPrompts: e.optional(e.record(e.string(), e.string())),
    notificationSettings: e.optional(e.record(e.string(), e.boolean())),
    evaluationHistory: e.optional(e.array(e.any()))
  },
  returns: e.id("userSettings"),
  handler: /* @__PURE__ */ o(async (s, t) => {
    let { userId: r } = t;
    return await s.db.insert("userSettings", {
      user_id: r,
      theme: "light",
      language: "ja",
      timezone: "Asia/Tokyo",
      items_per_page: 20,
      default_chart_period: "monthly",
      video_quality: "high",
      enable_subtitles: !0,
      learning_reminder: !0,
      session_timeout_minutes: 60,
      two_factor_enabled: !1,
      login_notification: !0,
      auto_save_enabled: !0,
      auto_save_interval_seconds: 30,
      show_tips: !0
    });
  }, "handler")
}), $ = c({
  args: {
    organizationId: e.string(),
    organizationName: e.optional(e.string()),
    defaultCriteriaWeights: e.optional(e.record(e.string(), e.number())),
    organizationPassingScore: e.optional(e.number()),
    evaluationTimeLimit: e.optional(e.number()),
    maxRetries: e.optional(e.number()),
    mandatorySettings: e.optional(e.any()),
    departmentSettings: e.optional(e.any()),
    inheritanceRules: e.optional(e.any())
  },
  returns: e.id("users"),
  handler: /* @__PURE__ */ o(async (s, t) => {
    let {
      organizationId: r,
      organizationName: i = "Test Organization",
      defaultCriteriaWeights: n = {
        hearingAbility: 0.3,
        problemSetting: 0.25,
        knowledge: 0.2,
        negotiation: 0.15,
        businessManners: 0.1
      },
      organizationPassingScore: u = 75,
      evaluationTimeLimit: d = 6e5,
      maxRetries: a = 5,
      mandatorySettings: l = {},
      departmentSettings: p = {},
      inheritanceRules: x = {
        allowUserOverride: !0,
        mandatoryFields: [],
        restrictedFields: []
      }
    } = t;
    return await s.db.insert("users", {
      clerkUserId: r,
      tokenIdentifier: `test-org-${r}`,
      email: `test-org-${r}@example.com`,
      emailVerified: !0,
      name: i || "Test Organization",
      role: "admin",
      isActive: !0,
      joinDate: Date.now()
    });
  }, "handler")
}), L = c({
  args: {
    systemDefaults: e.any()
  },
  returns: e.id("users"),
  handler: /* @__PURE__ */ o(async (s, t) => await s.db.insert("users", {
    clerkUserId: "system-default",
    tokenIdentifier: "system-default-token",
    email: "system-default@example.com",
    emailVerified: !0,
    name: "System Default Settings",
    role: "admin",
    isActive: !0,
    joinDate: Date.now()
  }), "handler")
}), H = c({
  args: {
    settingsId: e.id("userSettings"),
    updates: e.any(),
    changeReason: e.string()
  },
  returns: e.null(),
  handler: /* @__PURE__ */ o(async (s, t) => {
    let { settingsId: r, updates: i, changeReason: n } = t;
    if (!await s.db.get(r))
      throw new Error("Settings not found");
    return await s.db.patch(r, {
      show_tips: !0
      // Safe update field that exists in userSettings
    }), null;
  }, "handler")
}), R = c({
  args: {
    userId: e.id("users"),
    corruptedFields: e.array(e.string())
  },
  returns: e.id("userSettings"),
  handler: /* @__PURE__ */ o(async (s, t) => {
    let { userId: r } = t;
    return await s.db.insert("userSettings", {
      user_id: r,
      theme: "light",
      language: "ja",
      timezone: "Asia/Tokyo",
      items_per_page: 20,
      default_chart_period: "monthly",
      video_quality: "high",
      enable_subtitles: !0,
      learning_reminder: !0,
      session_timeout_minutes: 60,
      two_factor_enabled: !1,
      login_notification: !0,
      auto_save_enabled: !0,
      auto_save_interval_seconds: 30,
      show_tips: !0
    });
  }, "handler")
}), q = g({
  args: {
    eventType: e.string(),
    userId: e.id("users")
  },
  returns: e.array(e.any()),
  handler: /* @__PURE__ */ o(async (s, t) => {
    let { eventType: r, userId: i } = t;
    return [
      {
        eventType: r,
        userId: i,
        adminUserId: i,
        details: `Security log entry for ${r}`,
        timestamp: Date.now()
      }
    ];
  }, "handler")
}), F = c({
  args: {
    userId: e.id("users"),
    videoId: e.id("videos"),
    status: e.optional(e.string()),
    totalScore: e.optional(e.number()),
    evaluationType: e.optional(e.string()),
    criteria: e.optional(e.any()),
    results: e.optional(e.any())
  },
  returns: e.id("evaluations"),
  handler: /* @__PURE__ */ o(async (s, t) => {
    let { userId: r, videoId: i, status: n = "completed", totalScore: u = 85, evaluationType: d = "M&A\u30ED\u30FC\u30EB\u30D7\u30EC\u30A4", criteria: a = {}, results: l = {} } = t, p = await s.db.insert("transcriptions", {
      resource_type: "video",
      resource_id: i,
      text: "Test transcript content",
      status: "completed",
      duration_seconds: 60
    });
    return await s.db.insert("evaluations", {
      transcription_id: p,
      user_id: r,
      video_id: i,
      status: n,
      total_score: u,
      video_type: d,
      processing_duration_ms: 3e5,
      // 5 minutes
      hearingAbility: 80,
      problemSetting: 90,
      knowledge: 85,
      negotiation: 75,
      businessManners: 95
    });
  }, "handler")
}), N = c({
  args: {
    userId: e.id("users"),
    activityType: e.optional(e.string()),
    details: e.optional(e.any()),
    timestamp: e.optional(e.number())
  },
  returns: e.null(),
  handler: /* @__PURE__ */ o(async (s, t) => {
    let { userId: r, activityType: i = "evaluation_completed", details: n = {}, timestamp: u = Date.now() } = t;
    return console.log(`Test user activity created: ${i} for user ${r}`), null;
  }, "handler")
}), B = c({
  args: {
    name: e.string(),
    email: e.string(),
    role: e.string(),
    isActive: e.boolean(),
    tokenIdentifier: e.string(),
    clerkUserId: e.optional(e.string()),
    department: e.optional(e.string()),
    emailVerified: e.optional(e.boolean()),
    joinDate: e.optional(e.number()),
    lastLoginAt: e.optional(e.number())
  },
  returns: e.id("users"),
  handler: /* @__PURE__ */ o(async (s, t) => {
    let r = {
      clerkUserId: t.clerkUserId || `test_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
      tokenIdentifier: t.tokenIdentifier,
      email: t.email,
      emailVerified: t.emailVerified ?? !0,
      name: t.name,
      role: t.role,
      isActive: t.isActive,
      joinDate: t.joinDate || Date.now()
    };
    return t.department && (r.department = t.department), t.lastLoginAt && (r.lastLoginAt = t.lastLoginAt), await s.db.insert("users", r);
  }, "handler")
}), W = c({
  args: {
    evaluationId: e.id("evaluations"),
    status: e.string(),
    totalScore: e.optional(e.number()),
    results: e.optional(e.any())
  },
  returns: e.null(),
  handler: /* @__PURE__ */ o(async (s, t) => {
    let { evaluationId: r, status: i, totalScore: n, results: u } = t, d = { status: i };
    return n !== void 0 && (d.total_score = n), u !== void 0 && (d.feedback = u), await s.db.patch(r, d), null;
  }, "handler")
}), Q = c({
  args: {
    userId: e.id("users"),
    title: e.optional(e.string())
  },
  returns: e.id("videos"),
  handler: /* @__PURE__ */ o(async (s, t) => await s.db.insert("videos", {
    title: t.title || "Test Video for ID",
    description: "Test video created for ID generation",
    type: "M&A\u30ED\u30FC\u30EB\u30D7\u30EC\u30A4",
    url: "https://example.com/test-video.mp4",
    user_id: t.userId
  }), "handler")
}), Y = c({
  args: {
    userId: e.id("users"),
    videoId: e.id("videos"),
    status: e.optional(e.string())
  },
  returns: e.id("evaluations"),
  handler: /* @__PURE__ */ o(async (s, t) => {
    let r = await s.db.insert("transcriptions", {
      resource_type: "video",
      resource_id: t.videoId || "dummy-video",
      text: "Test transcript content",
      status: "completed",
      duration_seconds: 60
    });
    return await s.db.insert("evaluations", {
      transcription_id: r,
      user_id: t.userId,
      video_id: t.videoId,
      status: t.status || "completed",
      total_score: 85,
      video_type: "M&A\u30ED\u30FC\u30EB\u30D7\u30EC\u30A4",
      processing_duration_ms: 3e5,
      hearingAbility: 80,
      problemSetting: 90,
      knowledge: 85,
      negotiation: 75,
      businessManners: 95
    });
  }, "handler")
});
export {
  h as checkTestUserPermissions,
  A as checkUpdatePermission,
  f as cleanupAllTestData,
  T as cleanupTestSession,
  R as createCorruptedEvaluationSettings,
  L as createTestDefaultSettings,
  F as createTestEvaluation,
  Y as createTestEvaluationForId,
  O as createTestEvaluationSettings,
  $ as createTestOrganizationSettings,
  M as createTestSession,
  N as createTestUserActivity,
  y as createTestUserWithAuth,
  Q as createTestVideoForId,
  B as createUser,
  _ as enableTestAuthBypass,
  w as fastCleanupTestData,
  q as getSecurityLogs,
  S as getTestDataStatistics,
  I as prepareTestEnvironment,
  v as setupMultiUserTestEnvironment,
  b as setupTestIdentity,
  U as simulateConcurrentUpdate,
  V as testErrorHandling,
  z as testMemoryEfficiency,
  P as testPerformance,
  E as testSecurityValidation,
  j as updateEvaluationCriteriaTest,
  H as updateEvaluationSettings,
  W as updateEvaluationStatus,
  C as validateUpdateCriteriaInput
};
//# sourceMappingURL=testing.js.map
