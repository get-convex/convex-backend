import {
  b as l,
  d as y
} from "./_deps/SZVQRWFS.js";
import {
  a as T,
  c as g,
  e as j
} from "./_deps/75JH2J25.js";
import "./_deps/6XQQNYIR.js";
import {
  j as e,
  l as u,
  n as w
} from "./_deps/3TDUHHJO.js";
import {
  a as s
} from "./_deps/RUVYHBJQ.js";

// convex/evaluation.ts
w();
w();
var C = e.object({
  success: e.boolean(),
  detectedType: e.string(),
  confidence: e.number(),
  keywords: e.array(e.string()),
  applicableCriteria: e.record(
    e.string(),
    e.object({
      description: e.string()
    })
  ),
  message: e.optional(e.string()),
  manualSelection: e.optional(
    e.object({
      required: e.boolean(),
      availableTypes: e.array(e.string()),
      continueUrl: e.string()
    })
  )
}), h = e.object({
  name: e.string(),
  description: e.string(),
  scoreDescriptions: e.record(e.string(), e.string())
}), k = j({
  args: {
    transcript: e.string()
  },
  returns: C,
  handler: /* @__PURE__ */ s(async (t, r) => {
    await l(t);
    let c = {
      "M&A\u30ED\u30FC\u30EB\u30D7\u30EC\u30A4": ["\u4F01\u696D\u8CB7\u53CE", "M&A", "\u8CB7\u53CE\u63D0\u6848", "\u4E8B\u696D\u627F\u7D99", "\u8B72\u6E21"],
      AD\u7DE0\u7D50\u63D0\u6848: ["\u30A2\u30C9\u30D0\u30A4\u30B6\u30EA\u30FC\u5951\u7D04", "AD\u7DE0\u7D50", "\u5C02\u5C5E\u5951\u7D04", "\u5951\u7D04\u7DE0\u7D50"],
      \u8B72\u6E21\u67B6\u96FB: ["\u4F01\u696D\u8B72\u6E21", "\u8B72\u6E21", "\u4E8B\u696D\u627F\u7D99", "\u304A\u96FB\u8A71", "\u67B6\u96FB"],
      \u4F01\u696D\u6982\u8981\u66F8\u63D0\u6848: ["\u4F01\u696D\u6982\u8981\u66F8", "IM", "\u6982\u8981\u66F8", "\u60C5\u5831\u30E1\u30E2\u30E9\u30F3\u30C0\u30E0"]
    }, a = {
      "M&A\u30ED\u30FC\u30EB\u30D7\u30EC\u30A4": {
        \u30D2\u30A2\u30EA\u30F3\u30B0\u80FD\u529B: { description: "\u9867\u5BA2\u306E\u30CB\u30FC\u30BA\u3084\u8AB2\u984C\u3092\u7684\u78BA\u306B\u805E\u304D\u51FA\u3059\u80FD\u529B" },
        \u8AB2\u984C\u8A2D\u5B9A\u80FD\u529B: { description: "\u9867\u5BA2\u306E\u672C\u8CEA\u7684\u306A\u8AB2\u984C\u3092\u7279\u5B9A\u3057\u3001\u8A2D\u5B9A\u3059\u308B\u80FD\u529B" },
        \u77E5\u8B58\u529B: { description: "M&A\u306B\u95A2\u3059\u308B\u5C02\u9580\u77E5\u8B58\u306E\u6DF1\u3055\u3068\u6B63\u78BA\u6027" },
        \u5207\u308A\u8FD4\u3057\u529B: { description: "\u9867\u5BA2\u306E\u53CD\u8AD6\u3084\u7591\u554F\u306B\u5BFE\u3057\u3066\u9069\u5207\u306B\u5BFE\u5FDC\u3059\u308B\u80FD\u529B" },
        \u30D3\u30B8\u30CD\u30B9\u30DE\u30CA\u30FC: { description: "\u30D3\u30B8\u30CD\u30B9\u30B7\u30FC\u30F3\u306B\u304A\u3051\u308B\u9069\u5207\u306A\u632F\u308B\u821E\u3044" }
      },
      AD\u7DE0\u7D50\u63D0\u6848: {
        \u30D2\u30A2\u30EA\u30F3\u30B0\u80FD\u529B: { description: "\u9867\u5BA2\u306E\u30CB\u30FC\u30BA\u3084\u8AB2\u984C\u3092\u7684\u78BA\u306B\u805E\u304D\u51FA\u3059\u80FD\u529B" },
        \u77E5\u8B58\u529B: { description: "\u5951\u7D04\u306B\u95A2\u3059\u308B\u5C02\u9580\u77E5\u8B58\u306E\u6DF1\u3055\u3068\u6B63\u78BA\u6027" },
        \u63D0\u6848\u529B: { description: "\u9867\u5BA2\u306E\u30CB\u30FC\u30BA\u306B\u5408\u3063\u305F\u63D0\u6848\u3092\u884C\u3046\u80FD\u529B" },
        \u4EA4\u6E09\u529B: { description: "Win-Win\u306E\u95A2\u4FC2\u3092\u7BC9\u304F\u4EA4\u6E09\u80FD\u529B" },
        \u30EA\u30EC\u30FC\u30B7\u30E7\u30F3\u69CB\u7BC9\u529B: { description: "\u9867\u5BA2\u3068\u306E\u4FE1\u983C\u95A2\u4FC2\u3092\u69CB\u7BC9\u3059\u308B\u80FD\u529B" }
      },
      \u8B72\u6E21\u67B6\u96FB: {
        \u58F0\u306E\u30C8\u30FC\u30F3: { description: "\u96FB\u8A71\u3067\u306E\u9069\u5207\u306A\u58F0\u306E\u8ABF\u5B50\u3068\u8A71\u3057\u65B9" },
        \u3042\u3044\u3065\u3061: { description: "\u76F8\u624B\u306E\u8A71\u3092\u805E\u3044\u3066\u3044\u308B\u3053\u3068\u3092\u793A\u3059\u9069\u5207\u306A\u76F8\u69CC" },
        \u65E5\u7A0B\u78BA\u5B9A: { description: "\u9762\u8AC7\u65E5\u7A0B\u3092\u52B9\u7387\u7684\u306B\u78BA\u5B9A\u3055\u305B\u308B\u80FD\u529B" },
        \u91CD\u8981\u4E8B\u9805\u30D2\u30A2\u30EA\u30F3\u30B0: { description: "\u5FC5\u8981\u306A\u60C5\u5831\u3092\u6F0F\u308C\u306A\u304F\u805E\u304D\u51FA\u3059\u80FD\u529B" },
        \u6DF1\u6398\u308A\u30D2\u30A2\u30EA\u30F3\u30B0: { description: "\u8868\u9762\u7684\u306A\u60C5\u5831\u304B\u3089\u672C\u8CEA\u7684\u306A\u60C5\u5831\u3092\u5F15\u304D\u51FA\u3059\u80FD\u529B" }
      },
      \u4F01\u696D\u6982\u8981\u66F8\u63D0\u6848: {
        \u30CB\u30FC\u30BA\u30D2\u30A2\u30EA\u30F3\u30B0\u3068\u63D0\u6848\u529B: { description: "\u9867\u5BA2\u30CB\u30FC\u30BA\u3092\u7406\u89E3\u3057\u9069\u5207\u306A\u63D0\u6848\u3092\u884C\u3046\u80FD\u529B" },
        \u8B72\u6E21\u4F01\u696D\u306E\u4E8B\u696D\u7406\u89E3: { description: "\u8B72\u6E21\u4F01\u696D\u306E\u4E8B\u696D\u5185\u5BB9\u3092\u6DF1\u304F\u7406\u89E3\u3059\u308B\u80FD\u529B" },
        \u8B72\u53D7\u4F01\u696D\u306E\u4E8B\u696D\u7406\u89E3: { description: "\u8B72\u53D7\u4F01\u696D\u306E\u4E8B\u696D\u5185\u5BB9\u3092\u6DF1\u304F\u7406\u89E3\u3059\u308B\u80FD\u529B" },
        \u60F3\u5B9A\u30B7\u30CA\u30B8\u30FC\u52B9\u679C\u63D0\u6848: { description: "M&A\u306B\u3088\u308B\u30B7\u30CA\u30B8\u30FC\u52B9\u679C\u3092\u5177\u4F53\u7684\u306B\u63D0\u6848\u3059\u308B\u80FD\u529B" },
        \u30C6\u30B9\u30C8\u30AF\u30ED\u30FC\u30B8\u30F3\u30B0: { description: "\u5546\u8AC7\u3092\u30AF\u30ED\u30FC\u30B8\u30F3\u30B0\u306B\u5C0E\u304F\u80FD\u529B" }
      }
    }, i = {}, o = [];
    for (let [d, p] of Object.entries(c)) {
      let v = 0;
      for (let f of p)
        r.transcript.includes(f) && (v++, o.push(f));
      i[d] = v;
    }
    let n = Object.entries(i).reduce(
      (d, p) => i[d[0]] > i[p[0]] ? d : p
    )[0], m = i[n] / c[n].length, A = a[n] || {}, b = m < 0.3;
    return {
      success: !0,
      detectedType: n,
      confidence: m,
      keywords: o,
      applicableCriteria: A,
      message: b ? "\u81EA\u52D5\u691C\u51FA\u306E\u4FE1\u983C\u5EA6\u304C\u4F4E\u3044\u305F\u3081\u3001\u624B\u52D5\u3067\u30BF\u30A4\u30D7\u3092\u9078\u629E\u3057\u3066\u304F\u3060\u3055\u3044\u3002" : void 0,
      manualSelection: b ? {
        required: !0,
        availableTypes: Object.keys(c),
        continueUrl: "/evaluation/manual-selection"
      } : void 0
    };
  }, "handler")
}), q = T({
  args: {
    videoType: e.string()
  },
  returns: e.record(e.string(), h),
  handler: /* @__PURE__ */ s(async (t, r) => {
    await l(t);
    let a = {
      "M&A\u30ED\u30FC\u30EB\u30D7\u30EC\u30A4": {
        \u30D2\u30A2\u30EA\u30F3\u30B0\u80FD\u529B: { description: "\u9867\u5BA2\u306E\u30CB\u30FC\u30BA\u3084\u8AB2\u984C\u3092\u7684\u78BA\u306B\u805E\u304D\u51FA\u3059\u80FD\u529B" },
        \u8AB2\u984C\u8A2D\u5B9A\u80FD\u529B: { description: "\u9867\u5BA2\u306E\u672C\u8CEA\u7684\u306A\u8AB2\u984C\u3092\u7279\u5B9A\u3057\u3001\u8A2D\u5B9A\u3059\u308B\u80FD\u529B" },
        \u77E5\u8B58\u529B: { description: "M&A\u306B\u95A2\u3059\u308B\u5C02\u9580\u77E5\u8B58\u306E\u6DF1\u3055\u3068\u6B63\u78BA\u6027" },
        \u5207\u308A\u8FD4\u3057\u529B: { description: "\u9867\u5BA2\u306E\u53CD\u8AD6\u3084\u7591\u554F\u306B\u5BFE\u3057\u3066\u9069\u5207\u306B\u5BFE\u5FDC\u3059\u308B\u80FD\u529B" },
        \u30D3\u30B8\u30CD\u30B9\u30DE\u30CA\u30FC: { description: "\u30D3\u30B8\u30CD\u30B9\u30B7\u30FC\u30F3\u306B\u304A\u3051\u308B\u9069\u5207\u306A\u632F\u308B\u821E\u3044" }
      },
      AD\u7DE0\u7D50\u63D0\u6848: {
        \u30D2\u30A2\u30EA\u30F3\u30B0\u80FD\u529B: { description: "\u9867\u5BA2\u306E\u30CB\u30FC\u30BA\u3084\u8AB2\u984C\u3092\u7684\u78BA\u306B\u805E\u304D\u51FA\u3059\u80FD\u529B" },
        \u77E5\u8B58\u529B: { description: "\u5951\u7D04\u306B\u95A2\u3059\u308B\u5C02\u9580\u77E5\u8B58\u306E\u6DF1\u3055\u3068\u6B63\u78BA\u6027" },
        \u63D0\u6848\u529B: { description: "\u9867\u5BA2\u306E\u30CB\u30FC\u30BA\u306B\u5408\u3063\u305F\u63D0\u6848\u3092\u884C\u3046\u80FD\u529B" },
        \u4EA4\u6E09\u529B: { description: "Win-Win\u306E\u95A2\u4FC2\u3092\u7BC9\u304F\u4EA4\u6E09\u80FD\u529B" },
        \u30EA\u30EC\u30FC\u30B7\u30E7\u30F3\u69CB\u7BC9\u529B: { description: "\u9867\u5BA2\u3068\u306E\u4FE1\u983C\u95A2\u4FC2\u3092\u69CB\u7BC9\u3059\u308B\u80FD\u529B" }
      },
      \u8B72\u6E21\u67B6\u96FB: {
        \u58F0\u306E\u30C8\u30FC\u30F3: { description: "\u96FB\u8A71\u3067\u306E\u9069\u5207\u306A\u58F0\u306E\u8ABF\u5B50\u3068\u8A71\u3057\u65B9" },
        \u3042\u3044\u3065\u3061: { description: "\u76F8\u624B\u306E\u8A71\u3092\u805E\u3044\u3066\u3044\u308B\u3053\u3068\u3092\u793A\u3059\u9069\u5207\u306A\u76F8\u69CC" },
        \u65E5\u7A0B\u78BA\u5B9A: { description: "\u9762\u8AC7\u65E5\u7A0B\u3092\u52B9\u7387\u7684\u306B\u78BA\u5B9A\u3055\u305B\u308B\u80FD\u529B" },
        \u91CD\u8981\u4E8B\u9805\u30D2\u30A2\u30EA\u30F3\u30B0: { description: "\u5FC5\u8981\u306A\u60C5\u5831\u3092\u6F0F\u308C\u306A\u304F\u805E\u304D\u51FA\u3059\u80FD\u529B" },
        \u6DF1\u6398\u308A\u30D2\u30A2\u30EA\u30F3\u30B0: { description: "\u8868\u9762\u7684\u306A\u60C5\u5831\u304B\u3089\u672C\u8CEA\u7684\u306A\u60C5\u5831\u3092\u5F15\u304D\u51FA\u3059\u80FD\u529B" }
      },
      \u4F01\u696D\u6982\u8981\u66F8\u63D0\u6848: {
        \u30CB\u30FC\u30BA\u30D2\u30A2\u30EA\u30F3\u30B0\u3068\u63D0\u6848\u529B: { description: "\u9867\u5BA2\u30CB\u30FC\u30BA\u3092\u7406\u89E3\u3057\u9069\u5207\u306A\u63D0\u6848\u3092\u884C\u3046\u80FD\u529B" },
        \u8B72\u6E21\u4F01\u696D\u306E\u4E8B\u696D\u7406\u89E3: { description: "\u8B72\u6E21\u4F01\u696D\u306E\u4E8B\u696D\u5185\u5BB9\u3092\u6DF1\u304F\u7406\u89E3\u3059\u308B\u80FD\u529B" },
        \u8B72\u53D7\u4F01\u696D\u306E\u4E8B\u696D\u7406\u89E3: { description: "\u8B72\u53D7\u4F01\u696D\u306E\u4E8B\u696D\u5185\u5BB9\u3092\u6DF1\u304F\u7406\u89E3\u3059\u308B\u80FD\u529B" },
        \u60F3\u5B9A\u30B7\u30CA\u30B8\u30FC\u52B9\u679C\u63D0\u6848: { description: "M&A\u306B\u3088\u308B\u30B7\u30CA\u30B8\u30FC\u52B9\u679C\u3092\u5177\u4F53\u7684\u306B\u63D0\u6848\u3059\u308B\u80FD\u529B" },
        \u30C6\u30B9\u30C8\u30AF\u30ED\u30FC\u30B8\u30F3\u30B0: { description: "\u5546\u8AC7\u3092\u30AF\u30ED\u30FC\u30B8\u30F3\u30B0\u306B\u5C0E\u304F\u80FD\u529B" }
      }
    }[r.videoType];
    if (!a)
      throw new u(`Unknown video type: ${r.videoType}`);
    let i = {};
    for (let [o, n] of Object.entries(a))
      i[o] = {
        name: o,
        description: n.description,
        scoreDescriptions: {
          1: "\u975E\u5E38\u306B\u4F4E\u3044\u8A55\u4FA1",
          5: "\u6A19\u6E96\u7684\u306A\u8A55\u4FA1",
          10: "\u975E\u5E38\u306B\u9AD8\u3044\u8A55\u4FA1"
        }
      };
    return i;
  }, "handler")
}), E = g({
  args: {
    videoType: e.string(),
    criteria: e.array(
      e.object({
        id: e.string(),
        name: e.string(),
        description: e.string(),
        criteria: e.record(e.string(), e.string())
      })
    )
  },
  returns: e.object({
    success: e.boolean(),
    message: e.string()
  }),
  handler: /* @__PURE__ */ s(async (t) => {
    await y(t);
    try {
      return {
        success: !0,
        message: "\u8A55\u4FA1\u57FA\u6E96\u304C\u66F4\u65B0\u3055\u308C\u307E\u3057\u305F"
      };
    } catch (r) {
      throw console.error("Evaluation criteria update error:", r), new u("\u8A55\u4FA1\u57FA\u6E96\u306E\u66F4\u65B0\u306B\u5931\u6557\u3057\u307E\u3057\u305F");
    }
  }, "handler")
}), O = g({
  args: {
    videoType: e.string(),
    newCriteria: e.object({
      name: e.string(),
      description: e.string(),
      scales: e.record(e.string(), e.string())
    })
  },
  returns: e.object({
    success: e.boolean(),
    message: e.string()
  }),
  handler: /* @__PURE__ */ s(async (t) => {
    await y(t);
    try {
      return {
        success: !0,
        message: "\u8A55\u4FA1\u57FA\u6E96\u304C\u8FFD\u52A0\u3055\u308C\u307E\u3057\u305F"
      };
    } catch (r) {
      throw console.error("Evaluation criteria add error:", r), new u("\u8A55\u4FA1\u57FA\u6E96\u306E\u8FFD\u52A0\u306B\u5931\u6557\u3057\u307E\u3057\u305F");
    }
  }, "handler")
});
export {
  O as addEvaluationCriteria,
  k as detectVideoType,
  h as evaluationCriteriaValidator,
  q as getEvaluationCriteria,
  E as updateEvaluationCriteria,
  C as videoTypeDetectionResultValidator
};
//# sourceMappingURL=evaluation.js.map
