import {
  a as b
} from "./_deps/75JH2J25.js";
import "./_deps/6XQQNYIR.js";
import {
  j as e,
  n as D
} from "./_deps/3TDUHHJO.js";
import {
  a as y
} from "./_deps/RUVYHBJQ.js";

// convex/dashboard.ts
D();
var M = b({
  args: {
    person: e.optional(e.string()),
    scoreRange: e.optional(e.string()),
    company: e.optional(e.string()),
    searchQuery: e.optional(e.string())
  },
  returns: e.object({
    totalHours: e.string(),
    hoursDifference: e.string(),
    completedCourses: e.number(),
    coursesDifference: e.number(),
    roleplayCount: e.number(),
    roleplayDifference: e.number(),
    avgScore: e.string(),
    scoreDifference: e.string()
  }),
  handler: /* @__PURE__ */ y(async (i, p) => {
    let g = await i.auth.getUserIdentity();
    if (!g)
      throw new Error("\u8A8D\u8A3C\u304C\u5FC5\u8981\u3067\u3059");
    let d = await i.db.query("users").withIndex("by_token", (n) => n.eq("tokenIdentifier", g.tokenIdentifier)).unique();
    if (!d)
      throw new Error("\u30E6\u30FC\u30B6\u30FC\u304C\u898B\u3064\u304B\u308A\u307E\u305B\u3093\u3002\u30DA\u30FC\u30B8\u3092\u518D\u8AAD\u307F\u8FBC\u307F\u3057\u3066\u304F\u3060\u3055\u3044\u3002");
    try {
      let n = await i.db.query("trainingProgress").withIndex("by_user_training", (a) => a.eq("user_id", d._id)).collect(), c = await i.db.query("roleplayParticipants").withIndex("by_user_id", (a) => a.eq("user_id", d._id)).collect(), u = await i.db.query("evaluations").withIndex("by_user_id", (a) => a.eq("user_id", d._id)).collect(), l = n.filter((a) => a.status === "completed").length, m = c.length, s = "0.0";
      if (u.length > 0) {
        let a = u.map((f) => f._id), h = (await i.db.query("evaluationDetails").collect()).filter(
          (f) => a.includes(f.evaluation_id)
        ).filter((f) => f.final_score && f.final_score > 0).map((f) => f.final_score);
        h.length > 0 && (s = (h.reduce((v, _) => v + _, 0) / h.length).toFixed(1));
      }
      return {
        totalHours: (n.length * 0.5).toFixed(1),
        hoursDifference: "+0.0",
        // 新規ユーザーなので差分なし
        completedCourses: l,
        coursesDifference: 0,
        // 新規ユーザーなので差分なし
        roleplayCount: m,
        roleplayDifference: 0,
        // 新規ユーザーなので差分なし
        avgScore: s,
        scoreDifference: "+0.0"
        // 新規ユーザーなので差分なし
      };
    } catch (n) {
      return console.error("Dashboard stats calculation error:", n), {
        totalHours: "0.0",
        hoursDifference: "+0.0",
        completedCourses: 0,
        coursesDifference: 0,
        roleplayCount: 0,
        roleplayDifference: 0,
        avgScore: "0.0",
        scoreDifference: "+0.0"
      };
    }
  }, "handler")
}), C = b({
  args: {
    person: e.optional(e.string()),
    scoreRange: e.optional(e.string()),
    company: e.optional(e.string()),
    searchQuery: e.optional(e.string())
  },
  returns: e.object({
    skillEvaluations: e.array(
      e.object({
        skill: e.string(),
        score: e.number(),
        trend: e.string(),
        feedback: e.string()
      })
    )
  }),
  handler: /* @__PURE__ */ y(async (i, p) => {
    let g = await i.auth.getUserIdentity();
    if (!g)
      throw new Error("\u8A8D\u8A3C\u304C\u5FC5\u8981\u3067\u3059");
    let d = await i.db.query("users").withIndex("by_token", (n) => n.eq("tokenIdentifier", g.tokenIdentifier)).unique();
    if (!d)
      throw new Error("\u30E6\u30FC\u30B6\u30FC\u304C\u898B\u3064\u304B\u308A\u307E\u305B\u3093");
    try {
      let n = await i.db.query("evaluations").withIndex("by_user_id", (u) => u.eq("user_id", d._id)).collect();
      return n.length === 0 ? { skillEvaluations: [] } : { skillEvaluations: [
        {
          skill: "\u30D2\u30A2\u30EA\u30F3\u30B0\u529B",
          score: n.length > 0 ? Math.round(
            n.reduce(
              (u, l) => u + (l.hearingAbility || 0),
              0
            ) / n.length
          ) : 0,
          trend: "stable",
          feedback: "\u7D99\u7D9A\u7684\u306A\u7DF4\u7FD2\u3067\u5411\u4E0A\u304C\u671F\u5F85\u3067\u304D\u307E\u3059\u3002"
        },
        {
          skill: "\u8AB2\u984C\u8A2D\u5B9A\u529B",
          score: n.length > 0 ? Math.round(
            n.reduce(
              (u, l) => u + (l.problemSetting || 0),
              0
            ) / n.length
          ) : 0,
          trend: "stable",
          feedback: "\u9867\u5BA2\u30CB\u30FC\u30BA\u306E\u7406\u89E3\u3092\u6DF1\u3081\u308B\u3053\u3068\u3067\u6539\u5584\u3067\u304D\u307E\u3059\u3002"
        },
        {
          skill: "\u77E5\u8B58\u529B",
          score: n.length > 0 ? Math.round(
            n.reduce(
              (u, l) => u + (l.knowledge || 0),
              0
            ) / n.length
          ) : 0,
          trend: "stable",
          feedback: "\u88FD\u54C1\u77E5\u8B58\u3068\u696D\u754C\u77E5\u8B58\u306E\u5411\u4E0A\u306B\u53D6\u308A\u7D44\u307F\u307E\u3057\u3087\u3046\u3002"
        },
        {
          skill: "\u5207\u308A\u8FD4\u3057\u529B",
          score: n.length > 0 ? Math.round(
            n.reduce(
              (u, l) => u + (l.negotiation || 0),
              0
            ) / n.length
          ) : 0,
          trend: "stable",
          feedback: "\u60F3\u5B9A\u3055\u308C\u308B\u8CEA\u554F\u3078\u306E\u6E96\u5099\u304C\u91CD\u8981\u3067\u3059\u3002"
        },
        {
          skill: "\u30D3\u30B8\u30CD\u30B9\u30DE\u30CA\u30FC",
          score: n.length > 0 ? Math.round(
            n.reduce(
              (u, l) => u + (l.businessManners || 0),
              0
            ) / n.length
          ) : 0,
          trend: "stable",
          feedback: "\u57FA\u672C\u7684\u306A\u30DE\u30CA\u30FC\u304B\u3089\u4E01\u5BE7\u306B\u8EAB\u306B\u3064\u3051\u307E\u3057\u3087\u3046\u3002"
        }
      ] };
    } catch (n) {
      return console.error("Skill evaluations calculation error:", n), { skillEvaluations: [] };
    }
  }, "handler")
}), P = b({
  args: {},
  returns: e.object({
    people: e.array(
      e.object({
        id: e.string(),
        name: e.string()
      })
    ),
    companies: e.array(e.string())
  }),
  handler: /* @__PURE__ */ y(async (i, p) => {
    if (!await i.auth.getUserIdentity())
      throw new Error("\u8A8D\u8A3C\u304C\u5FC5\u8981\u3067\u3059");
    let n = (await i.db.query("users").collect()).map((l) => ({
      id: l._id,
      name: l.name
    })), c = await i.db.query("cases").collect(), u = Array.from(new Set(c.map((l) => l.company_name)));
    return {
      people: n,
      companies: u
    };
  }, "handler")
}), T = b({
  args: {
    userId: e.optional(e.id("users")),
    limit: e.optional(e.number())
  },
  returns: e.array(
    e.object({
      _id: e.id("trainingProgress"),
      trainingId: e.id("trainings"),
      title: e.string(),
      category: e.optional(e.string()),
      status: e.union(e.literal("not_started"), e.literal("in_progress"), e.literal("completed")),
      progress: e.number(),
      startedAt: e.optional(e.number()),
      completedAt: e.optional(e.number())
    })
  ),
  handler: /* @__PURE__ */ y(async (i, p) => {
    let g = await i.auth.getUserIdentity();
    if (!g)
      throw new Error("\u8A8D\u8A3C\u304C\u5FC5\u8981\u3067\u3059");
    let d = await i.db.query("users").withIndex("by_token", (t) => t.eq("tokenIdentifier", g.tokenIdentifier)).unique();
    if (!d)
      throw new Error("\u30E6\u30FC\u30B6\u30FC\u304C\u898B\u3064\u304B\u308A\u307E\u305B\u3093");
    let n = p.userId || d._id, c = await i.db.query("trainingProgress").withIndex("by_user_training", (t) => t.eq("user_id", n)).collect(), u = [...new Set(c.map((t) => t.training_id))], l = await Promise.all(u.map((t) => i.db.get(t))), m = /* @__PURE__ */ new Map();
    l.forEach((t) => {
      t && m.set(t._id, t);
    });
    let s = [];
    for (let t of c) {
      let a = m.get(t.training_id);
      a && s.push({
        _id: t._id,
        trainingId: t.training_id,
        title: a.title,
        category: a.category,
        status: t.status,
        progress: t.progress_percentage,
        startedAt: t.started_at,
        completedAt: t.completed_at
      });
    }
    return p.limit ? s.slice(0, p.limit) : s;
  }, "handler")
}), U = b({
  args: {
    limit: e.optional(e.number())
  },
  returns: e.array(
    e.object({
      _id: e.id("courses"),
      title: e.string(),
      description: e.string(),
      category: e.string(),
      durationMinutes: e.number(),
      difficulty: e.union(e.literal("beginner"), e.literal("intermediate"), e.literal("advanced")),
      relevanceScore: e.number(),
      thumbnailUrl: e.optional(e.string())
    })
  ),
  handler: /* @__PURE__ */ y(async (i, p) => {
    if (!await i.auth.getUserIdentity())
      throw new Error("\u8A8D\u8A3C\u304C\u5FC5\u8981\u3067\u3059");
    let n = (await i.db.query("courses").withIndex("by_published", (c) => c.eq("is_published", !0)).collect()).map((c) => ({
      _id: c._id,
      title: c.title,
      description: c.description,
      category: c.category,
      durationMinutes: c.duration_minutes,
      difficulty: "beginner",
      // デフォルト値
      relevanceScore: 80,
      // デフォルト値
      thumbnailUrl: c.thumbnail_url
    }));
    return p.limit ? n.slice(0, p.limit) : n;
  }, "handler")
}), j = b({
  args: {
    limit: e.optional(e.number())
  },
  returns: e.array(
    e.object({
      _id: e.string(),
      type: e.union(
        e.literal("course_started"),
        e.literal("course_completed"),
        e.literal("module_completed"),
        e.literal("quiz_passed"),
        e.literal("content_viewed")
      ),
      title: e.string(),
      description: e.string(),
      courseId: e.optional(e.id("trainings")),
      courseTitle: e.optional(e.string()),
      moduleId: e.optional(e.id("modules")),
      moduleTitle: e.optional(e.string()),
      timestamp: e.number(),
      metadata: e.optional(
        e.object({
          score: e.optional(e.number()),
          contentType: e.optional(e.string()),
          durationMinutes: e.optional(e.number())
        })
      )
    })
  ),
  handler: /* @__PURE__ */ y(async (i, p) => {
    let g = await i.auth.getUserIdentity();
    if (!g)
      throw new Error("\u8A8D\u8A3C\u304C\u5FC5\u8981\u3067\u3059");
    let d = await i.db.query("users").withIndex("by_token", (s) => s.eq("tokenIdentifier", g.tokenIdentifier)).unique();
    if (!d)
      throw new Error("\u30E6\u30FC\u30B6\u30FC\u304C\u898B\u3064\u304B\u308A\u307E\u305B\u3093");
    let n = await i.db.query("trainingProgress").withIndex("by_user_training", (s) => s.eq("user_id", d._id)).collect(), c = [...new Set(n.map((s) => s.training_id))], u = await Promise.all(c.map((s) => i.db.get(s))), l = /* @__PURE__ */ new Map();
    u.forEach((s) => {
      s && l.set(s._id, s);
    });
    let m = [];
    for (let s of n) {
      let t = l.get(s.training_id);
      t && (s.started_at && m.push({
        _id: `start_${s._id}`,
        type: "course_started",
        title: "\u30B3\u30FC\u30B9\u958B\u59CB",
        description: `${t.title}\u3092\u958B\u59CB\u3057\u307E\u3057\u305F`,
        courseId: t._id,
        courseTitle: t.title,
        moduleId: void 0,
        moduleTitle: void 0,
        timestamp: s.started_at,
        metadata: void 0
      }), s.completed_at && m.push({
        _id: `complete_${s._id}`,
        type: "course_completed",
        title: "\u30B3\u30FC\u30B9\u5B8C\u4E86",
        description: `${t.title}\u3092\u5B8C\u4E86\u3057\u307E\u3057\u305F`,
        courseId: t._id,
        courseTitle: t.title,
        moduleId: void 0,
        moduleTitle: void 0,
        timestamp: s.completed_at,
        metadata: void 0
      }));
    }
    return m.sort((s, t) => t.timestamp - s.timestamp), p.limit ? m.slice(0, p.limit) : m;
  }, "handler")
}), R = b({
  args: {},
  returns: e.object({
    stats: e.object({
      totalHours: e.string(),
      hoursDifference: e.string(),
      completedCourses: e.number(),
      coursesDifference: e.number(),
      roleplayCount: e.number(),
      roleplayDifference: e.number(),
      avgScore: e.string(),
      scoreDifference: e.string()
    }),
    skillEvaluations: e.array(
      e.object({
        skill: e.string(),
        score: e.number(),
        trend: e.string(),
        feedback: e.string()
      })
    ),
    userProgress: e.array(
      e.object({
        _id: e.id("trainingProgress"),
        trainingId: e.id("trainings"),
        title: e.string(),
        category: e.optional(e.string()),
        status: e.union(e.literal("not_started"), e.literal("in_progress"), e.literal("completed")),
        progress: e.number(),
        startedAt: e.optional(e.number()),
        completedAt: e.optional(e.number())
      })
    ),
    recommendedCourses: e.array(
      e.object({
        _id: e.id("courses"),
        title: e.string(),
        description: e.string(),
        category: e.string(),
        durationMinutes: e.number(),
        difficulty: e.union(
          e.literal("beginner"),
          e.literal("intermediate"),
          e.literal("advanced")
        ),
        relevanceScore: e.number(),
        thumbnailUrl: e.optional(e.string())
      })
    ),
    learningTimeline: e.array(
      e.object({
        _id: e.string(),
        type: e.union(
          e.literal("course_started"),
          e.literal("course_completed"),
          e.literal("module_completed"),
          e.literal("quiz_passed"),
          e.literal("content_viewed")
        ),
        title: e.string(),
        description: e.string(),
        courseId: e.optional(e.id("trainings")),
        courseTitle: e.optional(e.string()),
        moduleId: e.optional(e.id("modules")),
        moduleTitle: e.optional(e.string()),
        timestamp: e.number(),
        metadata: e.optional(
          e.object({
            score: e.optional(e.number()),
            contentType: e.optional(e.string()),
            durationMinutes: e.optional(e.number())
          })
        )
      })
    )
  }),
  handler: /* @__PURE__ */ y(async (i, p) => {
    let g = await i.auth.getUserIdentity();
    if (!g)
      throw new Error("\u8A8D\u8A3C\u304C\u5FC5\u8981\u3067\u3059");
    let d = await i.db.query("users").withIndex("by_token", (t) => t.eq("tokenIdentifier", g.tokenIdentifier)).unique();
    if (!d)
      throw new Error("\u30E6\u30FC\u30B6\u30FC\u304C\u898B\u3064\u304B\u308A\u307E\u305B\u3093\u3002\u30DA\u30FC\u30B8\u3092\u518D\u8AAD\u307F\u8FBC\u307F\u3057\u3066\u304F\u3060\u3055\u3044\u3002");
    let n = await Promise.allSettled([
      // 統計情報を取得
      (async () => {
        try {
          let t = await i.db.query("trainingProgress").withIndex("by_user_training", (_) => _.eq("user_id", d._id)).collect(), a = await i.db.query("roleplayParticipants").withIndex("by_user_id", (_) => _.eq("user_id", d._id)).collect(), r = await i.db.query("evaluations").withIndex("by_user_id", (_) => _.eq("user_id", d._id)).collect(), o = t.filter((_) => _.status === "completed").length, h = a.length, f = "0.0";
          if (r.length > 0) {
            let _ = 0, w = 0;
            for (let k of r) {
              let I = await i.db.query("evaluationDetails").withIndex("by_evaluation_id", (q) => q.eq("evaluation_id", k._id)).first();
              I && I.final_score && (_ += I.final_score, w++);
            }
            w > 0 && (f = (_ / w).toFixed(1));
          }
          return {
            totalHours: (t.length * 0.5).toFixed(1),
            hoursDifference: "+0.0",
            // 新規ユーザーなので差分なし
            completedCourses: o,
            coursesDifference: 0,
            // 新規ユーザーなので差分なし
            roleplayCount: h,
            roleplayDifference: 0,
            // 新規ユーザーなので差分なし
            avgScore: f,
            scoreDifference: "+0.0"
            // 新規ユーザーなので差分なし
          };
        } catch (t) {
          return console.error("Stats calculation error:", t), {
            totalHours: "0.0",
            hoursDifference: "+0.0",
            completedCourses: 0,
            coursesDifference: 0,
            roleplayCount: 0,
            roleplayDifference: 0,
            avgScore: "0.0",
            scoreDifference: "+0.0"
          };
        }
      })(),
      // スキル評価データを取得
      (async () => {
        try {
          let t = await i.db.query("evaluations").withIndex("by_user_id", (r) => r.eq("user_id", d._id)).collect();
          return t.length === 0 ? [] : [
            {
              skill: "\u30D2\u30A2\u30EA\u30F3\u30B0\u529B",
              score: t.length > 0 ? Math.round(
                t.reduce(
                  (r, o) => r + (o.hearingAbility || 0),
                  0
                ) / t.length
              ) : 0,
              trend: "stable",
              feedback: "\u7D99\u7D9A\u7684\u306A\u7DF4\u7FD2\u3067\u5411\u4E0A\u304C\u671F\u5F85\u3067\u304D\u307E\u3059\u3002"
            },
            {
              skill: "\u8AB2\u984C\u8A2D\u5B9A\u529B",
              score: t.length > 0 ? Math.round(
                t.reduce(
                  (r, o) => r + (o.problemSetting || 0),
                  0
                ) / t.length
              ) : 0,
              trend: "stable",
              feedback: "\u9867\u5BA2\u30CB\u30FC\u30BA\u306E\u7406\u89E3\u3092\u6DF1\u3081\u308B\u3053\u3068\u3067\u6539\u5584\u3067\u304D\u307E\u3059\u3002"
            },
            {
              skill: "\u77E5\u8B58\u529B",
              score: t.length > 0 ? Math.round(
                t.reduce(
                  (r, o) => r + (o.knowledge || 0),
                  0
                ) / t.length
              ) : 0,
              trend: "stable",
              feedback: "\u88FD\u54C1\u77E5\u8B58\u3068\u696D\u754C\u77E5\u8B58\u306E\u5411\u4E0A\u306B\u53D6\u308A\u7D44\u307F\u307E\u3057\u3087\u3046\u3002"
            },
            {
              skill: "\u5207\u308A\u8FD4\u3057\u529B",
              score: t.length > 0 ? Math.round(
                t.reduce(
                  (r, o) => r + (o.negotiation || 0),
                  0
                ) / t.length
              ) : 0,
              trend: "stable",
              feedback: "\u60F3\u5B9A\u3055\u308C\u308B\u8CEA\u554F\u3078\u306E\u6E96\u5099\u304C\u91CD\u8981\u3067\u3059\u3002"
            },
            {
              skill: "\u30D3\u30B8\u30CD\u30B9\u30DE\u30CA\u30FC",
              score: t.length > 0 ? Math.round(
                t.reduce(
                  (r, o) => r + (o.businessManners || 0),
                  0
                ) / t.length
              ) : 0,
              trend: "stable",
              feedback: "\u57FA\u672C\u7684\u306A\u30DE\u30CA\u30FC\u304B\u3089\u4E01\u5BE7\u306B\u8EAB\u306B\u3064\u3051\u307E\u3057\u3087\u3046\u3002"
            }
          ];
        } catch (t) {
          return console.error("Skill evaluations calculation error:", t), [];
        }
      })(),
      // ユーザー進捗データを取得
      (async () => {
        try {
          let t = await i.db.query("trainingProgress").withIndex("by_user_training", (r) => r.eq("user_id", d._id)).collect(), a = [];
          for (let r of t) {
            let o = await i.db.get(r.training_id);
            o && a.push({
              _id: r._id,
              trainingId: r.training_id,
              title: o.title,
              category: o.category,
              status: r.status,
              progress: r.progress_percentage,
              startedAt: r.started_at,
              completedAt: r.completed_at
            });
          }
          return a;
        } catch (t) {
          return console.error("User progress calculation error:", t), [];
        }
      })(),
      // 推奨コースを取得
      (async () => {
        try {
          return (await i.db.query("courses").withIndex("by_published", (r) => r.eq("is_published", !0)).collect()).map((r) => ({
            _id: r._id,
            title: r.title,
            description: r.description,
            category: r.category,
            durationMinutes: r.duration_minutes,
            difficulty: "beginner",
            // BDD仕様書のデフォルト値
            relevanceScore: 80,
            // BDD仕様書のデフォルト値
            thumbnailUrl: r.thumbnail_url
          }));
        } catch (t) {
          return console.error("Recommended courses calculation error:", t), [];
        }
      })(),
      // 学習タイムラインを取得
      (async () => {
        try {
          let t = await i.db.query("trainingProgress").withIndex("by_user_training", (r) => r.eq("user_id", d._id)).collect(), a = [];
          for (let r of t) {
            let o = await i.db.get(r.training_id);
            o && (r.started_at && a.push({
              _id: `start_${r._id}`,
              type: "course_started",
              title: "\u30B3\u30FC\u30B9\u958B\u59CB",
              description: `${o.title}\u3092\u958B\u59CB\u3057\u307E\u3057\u305F`,
              courseId: o._id,
              courseTitle: o.title,
              moduleId: void 0,
              moduleTitle: void 0,
              timestamp: r.started_at,
              metadata: void 0
            }), r.completed_at && a.push({
              _id: `complete_${r._id}`,
              type: "course_completed",
              title: "\u30B3\u30FC\u30B9\u5B8C\u4E86",
              description: `${o.title}\u3092\u5B8C\u4E86\u3057\u307E\u3057\u305F`,
              courseId: o._id,
              courseTitle: o.title,
              moduleId: void 0,
              moduleTitle: void 0,
              timestamp: r.completed_at,
              metadata: void 0
            }));
          }
          return a.sort((r, o) => o.timestamp - r.timestamp), a;
        } catch (t) {
          return console.error("Learning timeline calculation error:", t), [];
        }
      })()
    ]), [
      c,
      u,
      l,
      m,
      s
    ] = n;
    return {
      stats: c.status === "fulfilled" ? c.value : {
        totalHours: "0.0",
        hoursDifference: "+0.0",
        completedCourses: 0,
        coursesDifference: 0,
        roleplayCount: 0,
        roleplayDifference: 0,
        avgScore: "0.0",
        scoreDifference: "+0.0"
      },
      skillEvaluations: u.status === "fulfilled" ? u.value : [],
      userProgress: l.status === "fulfilled" ? l.value : [],
      recommendedCourses: m.status === "fulfilled" ? m.value : [],
      learningTimeline: s.status === "fulfilled" ? s.value : []
    };
  }, "handler")
});
export {
  R as getDashboardData,
  P as getFilterOptions,
  j as getLearningTimeline,
  U as getRecommendedCourses,
  C as getSkillEvaluations,
  M as getStats,
  T as getUserProgress
};
//# sourceMappingURL=dashboard.js.map
