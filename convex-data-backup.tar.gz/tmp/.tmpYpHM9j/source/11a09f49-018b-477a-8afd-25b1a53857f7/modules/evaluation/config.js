import {
  a,
  b,
  c
} from "../_deps/BAAP5EPW.js";
import "../_deps/RUVYHBJQ.js";
export {
  a as defaultProcessingConfig,
  b as getProcessingConfig,
  c as validateConfig
};
//# sourceMappingURL=config.js.map
