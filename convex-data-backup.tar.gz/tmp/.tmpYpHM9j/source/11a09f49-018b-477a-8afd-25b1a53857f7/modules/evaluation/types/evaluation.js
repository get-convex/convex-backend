"use node";
import "../../_deps/node/V7X2J7BI.js";

// convex/evaluation/types/evaluation.ts
var n = {
  type: "object",
  properties: {
    callTone: { type: "number", minimum: 0.5, maximum: 5, multipleOf: 0.5 },
    callTone_analysis: { type: "string" },
    callTone_strength: { type: "string" },
    callTone_weakness: { type: "string" },
    callListening: { type: "number", minimum: 0.5, maximum: 5, multipleOf: 0.5 },
    callListening_analysis: { type: "string" },
    callListening_strength: { type: "string" },
    callListening_weakness: { type: "string" },
    callScheduling: { type: "number", minimum: 0.5, maximum: 5, multipleOf: 0.5 },
    callScheduling_analysis: { type: "string" },
    callScheduling_strength: { type: "string" },
    callScheduling_weakness: { type: "string" },
    callImportantInfo: { type: "number", minimum: 0.5, maximum: 5, multipleOf: 0.5 },
    callImportantInfo_analysis: { type: "string" },
    callImportantInfo_strength: { type: "string" },
    callImportantInfo_weakness: { type: "string" },
    callDeepHearing: { type: "number", minimum: 0.5, maximum: 5, multipleOf: 0.5 },
    callDeepHearing_analysis: { type: "string" },
    callDeepHearing_strength: { type: "string" },
    callDeepHearing_weakness: { type: "string" },
    overallComment: { type: "string" },
    improvementSummary: { type: "string" }
  },
  required: [
    "callTone",
    "callTone_analysis",
    "callTone_strength",
    "callTone_weakness",
    "callListening",
    "callListening_analysis",
    "callListening_strength",
    "callListening_weakness",
    "callScheduling",
    "callScheduling_analysis",
    "callScheduling_strength",
    "callScheduling_weakness",
    "callImportantInfo",
    "callImportantInfo_analysis",
    "callImportantInfo_strength",
    "callImportantInfo_weakness",
    "callDeepHearing",
    "callDeepHearing_analysis",
    "callDeepHearing_strength",
    "callDeepHearing_weakness",
    "overallComment",
    "improvementSummary"
  ],
  additionalProperties: !1
};
export {
  n as CallEvaluationSchema
};
//# sourceMappingURL=evaluation.js.map
