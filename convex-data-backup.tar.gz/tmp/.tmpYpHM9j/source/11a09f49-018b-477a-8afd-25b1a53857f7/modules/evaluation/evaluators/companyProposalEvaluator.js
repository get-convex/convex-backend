import {
  a
} from "../../_deps/FYH65NAL.js";
import "../../_deps/RUVYHBJQ.js";
export {
  a as CompanyProposalEvaluator
};
//# sourceMappingURL=companyProposalEvaluator.js.map
