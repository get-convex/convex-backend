import {
  b as f
} from "./_deps/SZVQRWFS.js";
import {
  a as h,
  c as P
} from "./_deps/75JH2J25.js";
import "./_deps/6XQQNYIR.js";
import {
  j as e,
  l as y,
  n as M
} from "./_deps/3TDUHHJO.js";
import {
  a as b
} from "./_deps/RUVYHBJQ.js";

// convex/progressManagement.ts
M();
M();
var w = e.union(
  e.literal("not_started"),
  e.literal("in_progress"),
  e.literal("completed"),
  e.literal("paused")
), D = e.object({
  _id: e.id("trainingProgress"),
  user_id: e.id("users"),
  training_id: e.optional(e.id("trainings")),
  module_id: e.optional(e.id("trainingModules")),
  status: w,
  progress_percentage: e.number(),
  started_at: e.optional(e.number()),
  completed_at: e.optional(e.number()),
  _creationTime: e.number()
}), k = h({
  args: {
    courseId: e.string()
    // training_id として扱う
  },
  returns: e.object({
    course_progress: e.object({
      _id: e.optional(e.id("trainingProgress")),
      status: w,
      progress: e.number(),
      started_at: e.optional(e.number()),
      completed_at: e.optional(e.number())
    }),
    modules: e.array(
      e.object({
        _id: e.optional(e.id("trainingProgress")),
        module_id: e.id("trainingModules"),
        status: w,
        progress: e.number(),
        started_at: e.optional(e.number()),
        completed_at: e.optional(e.number())
      })
    ),
    overall_progress: e.number()
  }),
  handler: /* @__PURE__ */ b(async (t, s) => {
    let a = await f(t);
    if (!await t.db.get(s.courseId))
      throw new y("\u30B3\u30FC\u30B9\u304C\u898B\u3064\u304B\u308A\u307E\u305B\u3093");
    let r = await t.db.query("trainingProgress").withIndex(
      "by_user_training",
      (l) => l.eq("user_id", a.unifiedUserId).eq("training_id", s.courseId)
    ).filter((l) => l.eq(l.field("module_id"), void 0)).first(), _ = await t.db.query("trainingModules").withIndex("by_training_id", (l) => l.eq("training_id", s.courseId)).collect(), n = await Promise.all(
      _.map(async (l) => {
        let c = await t.db.query("trainingProgress").withIndex(
          "by_user_module",
          (i) => i.eq("user_id", a.unifiedUserId).eq("module_id", l._id)
        ).first();
        return {
          _id: c?._id,
          module_id: l._id,
          status: c?.status || "not_started",
          progress: c?.progress_percentage || 0,
          started_at: c?.started_at,
          completed_at: c?.completed_at
        };
      })
    ), u = _.length, m = n.filter((l) => l.status === "completed").length, g = u > 0 ? Math.round(m / u * 100) : 0;
    return {
      course_progress: {
        _id: r?._id,
        status: r?.status || "not_started",
        progress: r?.progress_percentage || g,
        started_at: r?.started_at,
        completed_at: r?.completed_at
      },
      modules: n,
      overall_progress: g
    };
  }, "handler")
}), R = h({
  args: {
    moduleId: e.id("trainingModules")
  },
  returns: e.union(
    e.object({
      _id: e.id("trainingProgress"),
      module_id: e.id("trainingModules"),
      status: w,
      progress: e.number(),
      started_at: e.optional(e.number()),
      completed_at: e.optional(e.number())
    }),
    e.null()
  ),
  handler: /* @__PURE__ */ b(async (t, s) => {
    let a = await f(t), d = await t.db.query("trainingProgress").withIndex(
      "by_user_module",
      (r) => r.eq("user_id", a.unifiedUserId).eq("module_id", s.moduleId)
    ).first();
    return d ? {
      _id: d._id,
      module_id: s.moduleId,
      status: d.status,
      progress: d.progress_percentage,
      started_at: d.started_at,
      completed_at: d.completed_at
    } : null;
  }, "handler")
}), T = P({
  args: {
    moduleId: e.id("trainingModules"),
    status: w,
    progress_percentage: e.number()
  },
  returns: e.object({
    success: e.boolean(),
    message: e.string(),
    overall_progress: e.optional(e.number())
  }),
  handler: /* @__PURE__ */ b(async (t, s) => {
    let a = await f(t), d = await t.db.get(s.moduleId);
    if (!d)
      throw new y("\u30E2\u30B8\u30E5\u30FC\u30EB\u304C\u898B\u3064\u304B\u308A\u307E\u305B\u3093");
    let r = Date.now(), _ = await t.db.query("trainingProgress").withIndex(
      "by_user_module",
      (i) => i.eq("user_id", a.unifiedUserId).eq("module_id", s.moduleId)
    ).first();
    if (_) {
      let i = {
        status: s.status,
        progress_percentage: s.progress_percentage
      };
      s.status === "in_progress" && !_.started_at ? i.started_at = r : s.status === "completed" && (i.completed_at = r, i.progress_percentage = 100), await t.db.patch(_._id, i);
    } else {
      let i = {
        user_id: a.unifiedUserId,
        training_id: d.training_id,
        module_id: s.moduleId,
        status: s.status,
        progress_percentage: s.progress_percentage
      };
      s.status === "in_progress" ? i.started_at = r : s.status === "completed" && (i.started_at = r, i.completed_at = r, i.progress_percentage = 100), await t.db.insert("trainingProgress", i);
    }
    let n = await t.db.query("trainingModules").withIndex("by_training_id", (i) => i.eq("training_id", d.training_id)).collect(), m = (await Promise.all(
      n.map(async (i) => (await t.db.query("trainingProgress").withIndex(
        "by_user_module",
        (p) => p.eq("user_id", a.unifiedUserId).eq("module_id", i._id)
      ).first())?.status || "not_started")
    )).filter((i) => i === "completed").length, g = Math.round(m / n.length * 100), l = await t.db.query("trainingProgress").withIndex(
      "by_user_training",
      (i) => i.eq("user_id", a.unifiedUserId).eq("training_id", d.training_id)
    ).filter((i) => i.eq(i.field("module_id"), void 0)).first(), c = g === 100 ? "completed" : g > 0 ? "in_progress" : "not_started";
    if (l) {
      let i = {
        status: c,
        progress_percentage: g
      };
      c === "completed" && !l.completed_at ? i.completed_at = r : c === "in_progress" && !l.started_at && (i.started_at = r), await t.db.patch(l._id, i);
    } else {
      let i = {
        user_id: a.unifiedUserId,
        training_id: d.training_id,
        status: c,
        progress_percentage: g
      };
      c === "in_progress" ? i.started_at = r : c === "completed" && (i.started_at = r, i.completed_at = r), await t.db.insert("trainingProgress", i);
    }
    return {
      success: !0,
      message: "\u9032\u6357\u304C\u66F4\u65B0\u3055\u308C\u307E\u3057\u305F",
      overall_progress: g
    };
  }, "handler")
}), S = P({
  args: {
    courseId: e.string(),
    // training_id として扱う
    status: w,
    progress_percentage: e.number()
  },
  returns: e.object({
    success: e.boolean(),
    message: e.string()
  }),
  handler: /* @__PURE__ */ b(async (t, s) => {
    let a = await f(t);
    if (!await t.db.get(s.courseId))
      throw new y("\u30B3\u30FC\u30B9\u304C\u898B\u3064\u304B\u308A\u307E\u305B\u3093");
    let r = Date.now(), _ = await t.db.query("trainingProgress").withIndex(
      "by_user_training",
      (n) => n.eq("user_id", a.unifiedUserId).eq("training_id", s.courseId)
    ).filter((n) => n.eq(n.field("module_id"), void 0)).first();
    if (_) {
      let n = {
        status: s.status,
        progress_percentage: s.progress_percentage
      };
      s.status === "in_progress" && !_.started_at ? n.started_at = r : s.status === "completed" && (n.completed_at = r, n.progress_percentage = 100), await t.db.patch(_._id, n);
    } else {
      let n = {
        user_id: a.unifiedUserId,
        training_id: s.courseId,
        status: s.status,
        progress_percentage: s.progress_percentage
      };
      s.status === "in_progress" ? n.started_at = r : s.status === "completed" && (n.started_at = r, n.completed_at = r, n.progress_percentage = 100), await t.db.insert("trainingProgress", n);
    }
    return {
      success: !0,
      message: "\u30B3\u30FC\u30B9\u9032\u6357\u304C\u66F4\u65B0\u3055\u308C\u307E\u3057\u305F"
    };
  }, "handler")
}), x = P({
  args: {
    moduleId: e.id("trainingModules")
  },
  returns: e.object({
    success: e.boolean(),
    message: e.string()
  }),
  handler: /* @__PURE__ */ b(async (t, s) => {
    let a = await f(t), d = await t.db.get(s.moduleId);
    if (!d)
      throw new y("Module not found");
    let r = Date.now(), _ = await t.db.query("trainingProgress").withIndex(
      "by_user_module",
      (n) => n.eq("user_id", a.unifiedUserId).eq("module_id", s.moduleId)
    ).first();
    return _ ? await t.db.patch(_._id, {
      status: "completed",
      progress_percentage: 100,
      completed_at: r,
      ..._.started_at ? {} : { started_at: r }
    }) : await t.db.insert("trainingProgress", {
      user_id: a.unifiedUserId,
      training_id: d.training_id,
      module_id: s.moduleId,
      status: "completed",
      progress_percentage: 100,
      started_at: r,
      completed_at: r
    }), {
      success: !0,
      message: "\u30E2\u30B8\u30E5\u30FC\u30EB\u304C\u5B8C\u4E86\u3057\u307E\u3057\u305F"
    };
  }, "handler")
}), V = h({
  args: {
    userId: e.optional(e.string()),
    limit: e.optional(e.number())
  },
  returns: e.object({
    courseProgress: e.array(
      e.object({
        _id: e.id("trainingProgress"),
        courseId: e.id("trainings"),
        status: w,
        progress_percentage: e.number(),
        started_at: e.optional(e.number()),
        completed_at: e.optional(e.number()),
        _creationTime: e.number()
      })
    )
  }),
  handler: /* @__PURE__ */ b(async (t, s) => {
    let a = await f(t), d = s.userId || a.identity.subject, r;
    if (s.userId && s.userId !== a.identity.subject) {
      let u = await t.db.query("users").withIndex("by_clerk_user_id", (m) => m.eq("clerkUserId", d)).first();
      if (u)
        r = u._id;
      else {
        let m = await t.db.query("users").withIndex("by_token", (g) => g.eq("tokenIdentifier", d)).first();
        if (!m)
          return { courseProgress: [] };
        r = m._id;
      }
    } else
      r = a.unifiedUserId;
    return {
      courseProgress: (await t.db.query("trainingProgress").withIndex("by_user_training", (u) => u.eq("user_id", r)).filter((u) => u.eq(u.field("module_id"), void 0)).order("desc").take(s.limit || 50)).map((u) => ({
        _id: u._id,
        courseId: u.training_id,
        status: u.status,
        progress_percentage: u.progress_percentage,
        started_at: u.started_at,
        completed_at: u.completed_at,
        _creationTime: u._creationTime
      }))
    };
  }, "handler")
}), A = h({
  args: {},
  returns: e.object({
    total_courses: e.number(),
    completed_courses: e.number(),
    in_progress_courses: e.number(),
    total_modules: e.number(),
    completed_modules: e.number(),
    overall_completion_rate: e.number(),
    recent_activity: e.array(
      e.object({
        type: e.string(),
        // "course_started", "module_completed", "course_completed"
        training_id: e.optional(e.id("trainings")),
        module_id: e.optional(e.id("trainingModules")),
        timestamp: e.number(),
        title: e.string()
      })
    )
  }),
  handler: /* @__PURE__ */ b(async (t) => {
    let s = await f(t), a = await t.db.query("trainingProgress").withIndex("by_user_training", (o) => o.eq("user_id", s.unifiedUserId)).collect(), d = a.filter((o) => !o.module_id), r = a.filter((o) => o.module_id), _ = d.length, n = d.filter((o) => o.status === "completed").length, u = d.filter((o) => o.status === "in_progress").length, m = r.length, g = r.filter((o) => o.status === "completed").length, l = m > 0 ? Math.round(g / m * 100) : 0, c = a.filter((o) => o.started_at || o.completed_at).sort((o, p) => {
      let I = Math.max(o.started_at || 0, o.completed_at || 0);
      return Math.max(p.started_at || 0, p.completed_at || 0) - I;
    }).slice(0, 10), i = await Promise.all(
      c.map(async (o) => {
        let p = "course_started", I = "Unknown";
        return o.module_id ? (I = (await t.db.get(o.module_id))?.title || "Unknown Module", p = o.status === "completed" ? "module_completed" : "module_started") : o.training_id && (I = (await t.db.get(o.training_id))?.title || "Unknown Course", p = o.status === "completed" ? "course_completed" : "course_started"), {
          type: p,
          training_id: o.training_id,
          module_id: o.module_id,
          timestamp: Math.max(o.started_at || 0, o.completed_at || 0),
          title: I
        };
      })
    );
    return {
      total_courses: _,
      completed_courses: n,
      in_progress_courses: u,
      total_modules: m,
      completed_modules: g,
      overall_completion_rate: l,
      recent_activity: i
    };
  }, "handler")
});
export {
  k as getCourseProgress,
  R as getModuleProgress,
  A as getUserLearningStats,
  V as getUserProgress,
  x as markModuleCompleted,
  D as moduleProgressValidator,
  w as progressStatusValidator,
  S as updateCourseProgress,
  T as updateModuleProgress
};
//# sourceMappingURL=progressManagement.js.map
