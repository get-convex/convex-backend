"use node";
import {
  a as h
} from "./_deps/node/4BJOKGGA.js";
import {
  a as f,
  b as _
} from "./_deps/node/VTOLWO7E.js";
import {
  b as k,
  c as m
} from "./_deps/node/PDGHC3PS.js";
import {
  a as e,
  b as p
} from "./_deps/node/UDHF6CTX.js";
import {
  a as c
} from "./_deps/node/V7X2J7BI.js";

// convex/rateLimiting.ts
async function v(s, r, t, n) {
  let a = Date.now(), i = Math.floor(a / n.windowMs) * n.windowMs, o = await s.db.query("rateLimitRecords").withIndex("by_user_action", (d) => d.eq("userId", r).eq("action", t)).collect(), l = o.find((d) => d.windowStart === i);
  if (l) {
    if (l.count >= n.maxRequests)
      return !1;
    await s.db.patch(l._id, {
      count: l.count + 1
    });
  } else
    await s.db.insert("rateLimitRecords", {
      userId: r,
      action: t,
      count: 1,
      windowStart: i
    });
  let u = a - n.windowMs * 2, w = o.filter((d) => d.windowStart < u);
  for (let d of w)
    await s.db.delete(d._id);
  return !0;
}
c(v, "checkRateLimit");
async function b(s, r, t, n) {
  let { internal: a } = await import("./_deps/node/JZKOKGEQ.js");
  return await s.runMutation(a.rateLimiting.checkRateLimitInternal, {
    userId: r,
    action: t,
    windowMs: n.windowMs,
    maxRequests: n.maxRequests
  });
}
c(b, "checkRateLimitFromAction");
function y(s, r) {
  let t = Math.ceil(r / 6e4);
  throw new p(
    `Rate limit exceeded for ${s}. Please try again in ${t} minute(s).`
  );
}
c(y, "throwRateLimitError");
var g = {
  // 通知作成: 1分間に10回まで
  createNotification: {
    windowMs: 60 * 1e3,
    maxRequests: 10,
    keyPrefix: "create_notification"
  },
  // Slack通知: 1分間に5回まで
  slackNotification: {
    windowMs: 60 * 1e3,
    maxRequests: 5,
    keyPrefix: "slack_notification"
  },
  // Webhook検証: 1分間に3回まで
  webhookValidation: {
    windowMs: 60 * 1e3,
    maxRequests: 3,
    keyPrefix: "webhook_validation"
  },
  // 一括操作: 10分間に3回まで
  bulkOperations: {
    windowMs: 10 * 60 * 1e3,
    maxRequests: 3,
    keyPrefix: "bulk_operations"
  }
};
var E = k({
  args: {
    userId: e.string(),
    action: e.string(),
    windowMs: e.number(),
    maxRequests: e.number()
  },
  returns: e.boolean(),
  handler: /* @__PURE__ */ c(async (s, r) => {
    let t = {
      windowMs: r.windowMs,
      maxRequests: r.maxRequests
    };
    return await v(s, r.userId, r.action, t);
  }, "handler")
});

// convex/slackActions.ts
var R = e.object({
  color: e.optional(e.string()),
  title: e.optional(e.string()),
  text: e.optional(e.string()),
  fields: e.optional(
    e.array(
      e.object({
        title: e.string(),
        value: e.string(),
        short: e.optional(e.boolean())
      })
    )
  )
}), x = e.object({
  channel: e.optional(e.string()),
  text: e.string(),
  attachments: e.optional(e.array(R))
}), S = e.object({
  success: e.boolean(),
  error: e.optional(e.string())
}), j = m({
  args: {
    webhook_url: e.string()
  },
  returns: e.object({
    valid: e.boolean(),
    error: e.optional(e.string())
  }),
  handler: /* @__PURE__ */ c(async (s, r) => {
    try {
      let t = await h(s);
      if (await b(
        s,
        t.user._id,
        "webhook_validation",
        g.webhookValidation
      ) || y(
        "webhook validation",
        g.webhookValidation.windowMs
      ), !/^https:\/\/hooks\.slack\.com\/services\/T[A-Z0-9]{8,}\/B[A-Z0-9]{8,}\/[a-zA-Z0-9]{24}$/.test(r.webhook_url))
        return {
          valid: !1,
          error: "Invalid Slack webhook URL format. Please use a valid Slack incoming webhook URL."
        };
      if (r.webhook_url.length > 200)
        return {
          valid: !1,
          error: "Webhook URL is too long"
        };
      let i = {
        text: "\u{1F9EA} Webhook URL validation test from AI Sales Training Hub",
        attachments: [
          {
            color: "good",
            text: "If you see this message, your webhook URL is working correctly!",
            footer: "AI Sales Training Hub",
            ts: Math.floor(Date.now() / 1e3)
          }
        ]
      }, o = new AbortController(), l = setTimeout(() => o.abort(), 1e4);
      try {
        let u = await fetch(r.webhook_url, {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            "User-Agent": "AI-Sales-Training-Hub/1.0"
          },
          body: JSON.stringify(i),
          signal: o.signal
        });
        if (clearTimeout(l), !u.ok) {
          let w = await u.text();
          return {
            valid: !1,
            error: `Webhook validation failed: ${u.status} ${w}`
          };
        }
        return { valid: !0 };
      } catch (u) {
        if (clearTimeout(l), u instanceof Error && u.name === "AbortError")
          return {
            valid: !1,
            error: "Webhook validation timeout. Please check your Slack webhook URL."
          };
        throw u;
      }
    } catch (t) {
      return console.error("Webhook validation error:", t), {
        valid: !1,
        error: t instanceof Error ? t.message : "Unknown validation error"
      };
    }
  }, "handler")
}), D = m({
  args: {
    webhook_url: e.string(),
    message: x
  },
  returns: S,
  handler: /* @__PURE__ */ c(async (s, r) => {
    try {
      let t = await fetch(r.webhook_url, {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify(r.message)
      });
      if (!t.ok) {
        let n = await t.text();
        return {
          success: !1,
          error: `Slack API error: ${t.status} ${n}`
        };
      }
      return { success: !0 };
    } catch (t) {
      return console.error("Slack send error:", t), {
        success: !1,
        error: t instanceof Error ? t.message : "Unknown error"
      };
    }
  }, "handler")
}), V = m({
  args: {
    user_id: e.id("users"),
    // Migration: Updated from better_auth_users to users
    notification_type: e.string(),
    // evaluation_complete, roleplay_application, system, etc
    title: e.string(),
    message: e.string(),
    data: e.optional(e.any())
    // 追加データ
  },
  returns: e.object({
    success: e.boolean(),
    sent_count: e.number(),
    errors: e.array(e.string())
  }),
  handler: /* @__PURE__ */ c(async (s, r) => {
    try {
      let t = await s.runQuery(f.slack.getSlackIntegrations, {
        created_by: r.user_id,
        is_active: !0
      });
      if (t.length === 0)
        return {
          success: !1,
          sent_count: 0,
          errors: ["No active Slack integrations found for user"]
        };
      let n = 0, a = [];
      for (let i of t)
        try {
          let o = A(
            r.notification_type,
            r.title,
            r.message,
            r.data
          ), l = await s.runAction(f.slackActions.sendSlackNotification, {
            webhook_url: i.webhook_url,
            message: {
              ...o,
              channel: i.channel_name
            }
          });
          l.success ? n++ : a.push(`Failed to send to ${i.channel_name}: ${l.error}`);
        } catch (o) {
          a.push(
            `Error sending to ${i.channel_name}: ${o instanceof Error ? o.message : "Unknown error"}`
          );
        }
      return {
        success: n > 0,
        sent_count: n,
        errors: a
      };
    } catch (t) {
      return console.error("Typed Slack notification error:", t), {
        success: !1,
        sent_count: 0,
        errors: [t instanceof Error ? t.message : "Unknown error"]
      };
    }
  }, "handler")
});
function A(s, r, t, n) {
  let a = {
    text: `\u{1F514} ${r}`,
    attachments: [
      {
        color: T(s),
        text: t,
        footer: "AI\u55B6\u696D\u30C8\u30EC\u30FC\u30CB\u30F3\u30B0\u30CF\u30D6",
        ts: Math.floor(Date.now() / 1e3)
      }
    ]
  };
  if (n && typeof n == "object") {
    let i = [];
    s === "evaluation_complete" && n.score && i.push({
      title: "\u30B9\u30B3\u30A2",
      value: `${n.score}\u70B9`,
      short: !0
    }), s === "roleplay_application" && n.applicantName && i.push({
      title: "\u7533\u8ACB\u8005",
      value: n.applicantName,
      short: !0
    }), n.videoTitle && i.push({
      title: "\u52D5\u753B",
      value: n.videoTitle,
      short: !0
    }), n.link && i.push({
      title: "\u8A73\u7D30",
      value: `<${n.link}|\u3053\u3061\u3089\u3092\u30AF\u30EA\u30C3\u30AF>`,
      short: !1
    }), i.length > 0 && (a.attachments[0].fields = i);
  }
  return a;
}
c(A, "buildSlackMessage");
function T(s) {
  switch (s) {
    case "evaluation_complete":
      return "good";
    case "roleplay_application":
      return "warning";
    case "system":
      return "danger";
    case "training_reminder":
      return "#36a64f";
    default:
      return "#3AA3E3";
  }
}
c(T, "getColorForNotificationType");
var W = m({
  args: {
    redirect_uri: e.string(),
    state: e.optional(e.string())
  },
  returns: e.object({
    authorization_url: e.string()
  }),
  handler: /* @__PURE__ */ c(async (s, r) => {
    let t = await h(s), n = process.env.SLACK_CLIENT_ID;
    if (!n)
      throw new Error("Slack OAuth is not configured");
    let a = ["channels:read", "chat:write", "users:read", "team:read"], i = r.state || String(t.user._id), o = new URL("https://slack.com/oauth/v2/authorize");
    return o.searchParams.set("client_id", n), o.searchParams.set("scope", a.join(",")), o.searchParams.set("redirect_uri", r.redirect_uri), o.searchParams.set("state", i), {
      authorization_url: o.toString()
    };
  }, "handler")
}), F = m({
  args: {
    code: e.string(),
    state: e.optional(e.string()),
    redirect_uri: e.string()
  },
  returns: e.object({
    success: e.boolean(),
    team_id: e.optional(e.string()),
    team_name: e.optional(e.string())
  }),
  handler: /* @__PURE__ */ c(async (s, r) => {
    let t = await h(s), n = process.env.SLACK_CLIENT_ID, a = process.env.SLACK_CLIENT_SECRET;
    if (!n || !a)
      throw new Error("Slack OAuth is not configured");
    try {
      let o = await (await fetch("https://slack.com/api/oauth.v2.access", {
        method: "POST",
        headers: {
          "Content-Type": "application/x-www-form-urlencoded"
        },
        body: new URLSearchParams({
          client_id: n,
          client_secret: a,
          code: r.code,
          redirect_uri: r.redirect_uri
        })
      })).json();
      if (!o.ok)
        throw new Error(`Slack OAuth error: ${o.error}`);
      if (!o.team || !o.access_token || !o.bot_user_id || !o.scope)
        throw new Error("Invalid token response from Slack");
      return await s.runMutation(_.slack.upsertSlackOAuthToken, {
        user_id: t.user._id,
        team_id: o.team.id,
        team_name: o.team.name,
        access_token: o.access_token,
        bot_user_id: o.bot_user_id,
        scope: o.scope,
        is_active: !0,
        expires_at: o.expires_in ? Date.now() + o.expires_in * 1e3 : void 0
      }), {
        success: !0,
        team_id: o.team.id,
        team_name: o.team.name
      };
    } catch (i) {
      throw console.error("Slack OAuth completion error:", i), new Error(
        `OAuth completion failed: ${i instanceof Error ? i.message : "Unknown error"}`
      );
    }
  }, "handler")
});
export {
  F as completeSlackOAuth,
  W as initiateSlackOAuth,
  D as sendSlackNotification,
  V as sendTypedSlackNotification,
  j as validateWebhookUrl
};
//# sourceMappingURL=slackActions.js.map
