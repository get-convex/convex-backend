import {
  f as b
} from "./_deps/RYP3LOHW.js";
import "./_deps/MNKTBR2W.js";
import {
  d as _,
  g as m
} from "./_deps/OQRPCOVT.js";
import "./_deps/SZVQRWFS.js";
import {
  a as c,
  c as d,
  d as u
} from "./_deps/75JH2J25.js";
import "./_deps/6XQQNYIR.js";
import {
  j as e,
  l as o,
  n as h
} from "./_deps/3TDUHHJO.js";
import {
  a as s
} from "./_deps/RUVYHBJQ.js";

// convex/slack.ts
h();
h();
var g = u({
  args: {
    organization_id: e.optional(e.number()),
    webhook_url: e.string(),
    channel_name: e.string(),
    is_active: e.boolean(),
    created_by: e.id("users")
    // Migration: Updated from better_auth_users to users
  },
  returns: e.id("slackIntegrations"),
  handler: /* @__PURE__ */ s(async (n, t) => {
    if (!await n.db.get(t.created_by))
      throw new o("User not found");
    return await n.db.insert("slackIntegrations", {
      organization_id: t.organization_id,
      webhook_url: t.webhook_url,
      channel_name: t.channel_name,
      is_active: t.is_active,
      created_by: t.created_by
    });
  }, "handler")
}), I = c({
  args: {
    is_active: e.optional(e.boolean())
  },
  returns: e.array(
    e.object({
      _id: e.id("slackIntegrations"),
      _creationTime: e.number(),
      organization_id: e.optional(e.number()),
      webhook_url: e.string(),
      channel_name: e.string(),
      is_active: e.boolean()
    })
  ),
  handler: /* @__PURE__ */ s(async (n, t) => {
    let { betterAuthUser: r } = await _(n);
    if (!r)
      throw new o("Authentication required");
    return t.is_active !== void 0 ? await n.db.query("slackIntegrations").withIndex(
      "by_created_by_and_active",
      (a) => a.eq("created_by", r._id).eq("is_active", t.is_active ?? !1)
    ).collect() : (await n.db.query("slackIntegrations").withIndex("by_created_by", (a) => a.eq("created_by", r._id)).collect()).map((a) => ({
      _id: a._id,
      _creationTime: a._creationTime,
      organization_id: a.organization_id,
      webhook_url: a.webhook_url,
      channel_name: a.channel_name,
      is_active: a.is_active
    }));
  }, "handler")
}), A = c({
  args: {
    created_by: e.optional(e.id("users")),
    // Migration: Updated from better_auth_users to users
    is_active: e.optional(e.boolean())
  },
  returns: e.array(
    e.object({
      _id: e.id("slackIntegrations"),
      _creationTime: e.number(),
      organization_id: e.optional(e.number()),
      webhook_url: e.string(),
      channel_name: e.string(),
      is_active: e.boolean(),
      created_by: e.id("users")
      // Migration: Updated from better_auth_users to users
    })
  ),
  handler: /* @__PURE__ */ s(async (n, t) => {
    if (t.is_active !== void 0 && t.created_by)
      return await n.db.query("slackIntegrations").withIndex(
        "by_created_by_and_active",
        (i) => i.eq("created_by", t.created_by).eq("is_active", t.is_active ?? !1)
      ).collect();
    if (t.created_by) {
      let i = await n.db.query("slackIntegrations").withIndex("by_created_by", (a) => a.eq("created_by", t.created_by)).collect();
      return t.is_active !== void 0 ? i.filter(
        (a) => a.is_active === (t.is_active ?? !1)
      ) : i;
    }
    let r = await n.db.query("slackIntegrations").collect();
    return t.is_active !== void 0 ? r.filter((i) => i.is_active === t.is_active) : r;
  }, "handler")
}), T = u({
  args: {
    integration_id: e.id("slackIntegrations"),
    webhook_url: e.optional(e.string()),
    channel_name: e.optional(e.string()),
    is_active: e.optional(e.boolean()),
    user_id: e.id("users")
    // Migration: Updated from better_auth_users to users
  },
  returns: e.object({
    success: e.boolean()
  }),
  handler: /* @__PURE__ */ s(async (n, t) => {
    let r = await n.db.get(t.integration_id);
    if (!r)
      throw new o("Slack integration not found");
    if (r.created_by !== t.user_id)
      throw new o("Unauthorized: Not the owner of this integration");
    let i = {};
    return t.webhook_url && (i.webhook_url = t.webhook_url), t.channel_name && (i.channel_name = t.channel_name), t.is_active !== void 0 && (i.is_active = t.is_active), await n.db.patch(t.integration_id, i), { success: !0 };
  }, "handler")
}), q = u({
  args: {
    integration_id: e.id("slackIntegrations"),
    user_id: e.id("users")
    // Migration: Updated from better_auth_users to users
  },
  returns: e.object({
    success: e.boolean()
  }),
  handler: /* @__PURE__ */ s(async (n, t) => {
    let r = await n.db.get(t.integration_id);
    if (!r)
      throw new o("Slack integration not found");
    if (r.created_by !== t.user_id)
      throw new o("Unauthorized: Not the owner of this integration");
    return await n.db.delete(t.integration_id), { success: !0 };
  }, "handler")
}), x = u({
  args: {
    user_id: e.id("users"),
    // Migration: Updated from better_auth_users to users
    team_id: e.string(),
    team_name: e.string(),
    access_token: e.string(),
    bot_user_id: e.optional(e.string()),
    scope: e.string(),
    is_active: e.boolean(),
    expires_at: e.optional(e.number())
  },
  returns: e.id("slackOAuthTokens"),
  handler: /* @__PURE__ */ s(async (n, t) => {
    let i = (await n.db.query("slackOAuthTokens").withIndex("by_user_id", (a) => a.eq("user_id", t.user_id)).collect()).find((a) => a.team_id === t.team_id);
    return i ? (await n.db.patch(i._id, {
      team_name: t.team_name,
      access_token: t.access_token,
      bot_user_id: t.bot_user_id,
      scope: t.scope,
      is_active: t.is_active,
      expires_at: t.expires_at,
      last_used_at: Date.now()
    }), i._id) : await n.db.insert("slackOAuthTokens", {
      user_id: t.user_id,
      team_id: t.team_id,
      team_name: t.team_name,
      access_token: t.access_token,
      bot_user_id: t.bot_user_id,
      scope: t.scope,
      is_active: t.is_active,
      expires_at: t.expires_at,
      last_used_at: Date.now()
    });
  }, "handler")
}), S = c({
  args: {
    is_active: e.optional(e.boolean())
  },
  returns: e.array(
    e.object({
      _id: e.id("slackOAuthTokens"),
      _creationTime: e.number(),
      team_id: e.string(),
      team_name: e.string(),
      bot_user_id: e.optional(e.string()),
      scope: e.string(),
      is_active: e.boolean(),
      expires_at: e.optional(e.number()),
      last_used_at: e.optional(e.number())
    })
  ),
  handler: /* @__PURE__ */ s(async (n, t) => {
    let { betterAuthUser: r } = await _(n);
    if (!r)
      throw new o("Authentication required");
    let i = await n.db.query("slackOAuthTokens").withIndex("by_user_id", (a) => a.eq("user_id", r._id)).collect();
    return t.is_active !== void 0 ? i.filter((a) => a.is_active === t.is_active).map((a) => ({
      _id: a._id,
      _creationTime: a._creationTime,
      team_id: a.team_id,
      team_name: a.team_name,
      bot_user_id: a.bot_user_id,
      scope: a.scope,
      is_active: a.is_active,
      expires_at: a.expires_at,
      last_used_at: a.last_used_at
    })) : i.map((a) => ({
      _id: a._id,
      _creationTime: a._creationTime,
      team_id: a.team_id,
      team_name: a.team_name,
      bot_user_id: a.bot_user_id,
      scope: a.scope,
      is_active: a.is_active,
      expires_at: a.expires_at,
      last_used_at: a.last_used_at
    }));
  }, "handler")
}), O = c({
  args: {
    user_id: e.id("users"),
    // Migration: Updated from better_auth_users to users
    is_active: e.optional(e.boolean())
  },
  returns: e.array(
    e.object({
      _id: e.id("slackOAuthTokens"),
      _creationTime: e.number(),
      user_id: e.id("users"),
      // Migration: Updated from better_auth_users to users
      team_id: e.string(),
      team_name: e.string(),
      bot_user_id: e.optional(e.string()),
      scope: e.string(),
      is_active: e.boolean(),
      expires_at: e.optional(e.number()),
      last_used_at: e.optional(e.number())
    })
  ),
  handler: /* @__PURE__ */ s(async (n, t) => {
    let r = await n.db.query("slackOAuthTokens").withIndex("by_user_id", (i) => i.eq("user_id", t.user_id)).collect();
    return t.is_active !== void 0 ? r.filter((i) => i.is_active === t.is_active).map((i) => ({
      _id: i._id,
      _creationTime: i._creationTime,
      user_id: i.user_id,
      team_id: i.team_id,
      team_name: i.team_name,
      bot_user_id: i.bot_user_id,
      scope: i.scope,
      is_active: i.is_active,
      expires_at: i.expires_at,
      last_used_at: i.last_used_at
    })) : r.map((i) => ({
      _id: i._id,
      _creationTime: i._creationTime,
      user_id: i.user_id,
      team_id: i.team_id,
      team_name: i.team_name,
      bot_user_id: i.bot_user_id,
      scope: i.scope,
      is_active: i.is_active,
      expires_at: i.expires_at,
      last_used_at: i.last_used_at
    }));
  }, "handler")
}), U = d({
  args: {
    webhook_url: e.string(),
    channel_name: e.string(),
    is_active: e.optional(e.boolean())
  },
  returns: e.object({
    success: e.boolean(),
    integration_id: e.optional(e.id("slackIntegrations"))
  }),
  handler: /* @__PURE__ */ s(async (n, t) => {
    let { betterAuthUser: r } = await _(n);
    if (!r)
      throw new o("Authentication required");
    if (!b(t.webhook_url))
      throw new o("Invalid Slack webhook URL format");
    return {
      success: !0,
      integration_id: await n.db.insert("slackIntegrations", {
        webhook_url: t.webhook_url,
        channel_name: t.channel_name,
        is_active: t.is_active ?? !0,
        created_by: r._id
      })
    };
  }, "handler")
}), j = d({
  args: {
    integration_id: e.id("slackIntegrations"),
    webhook_url: e.optional(e.string()),
    channel_name: e.optional(e.string()),
    is_active: e.optional(e.boolean())
  },
  returns: e.object({
    success: e.boolean()
  }),
  handler: /* @__PURE__ */ s(async (n, t) => {
    let { betterAuthUser: r } = await _(n);
    if (!r)
      throw new o("Authentication required");
    if (await m(n, t.integration_id, r._id), t.webhook_url && !b(t.webhook_url))
      throw new o("Invalid Slack webhook URL format");
    let i = {};
    return t.webhook_url && (i.webhook_url = t.webhook_url), t.channel_name && (i.channel_name = t.channel_name), t.is_active !== void 0 && (i.is_active = t.is_active), await n.db.patch(t.integration_id, i), { success: !0 };
  }, "handler")
}), z = d({
  args: {
    integration_id: e.id("slackIntegrations")
  },
  returns: e.object({
    success: e.boolean()
  }),
  handler: /* @__PURE__ */ s(async (n, t) => {
    let { betterAuthUser: r } = await _(n);
    if (!r)
      throw new o("Authentication required");
    let i = await n.db.get(t.integration_id);
    if (!i)
      throw new o("Slack integration not found");
    if (i.created_by !== r._id)
      throw new o("Access denied. You can only delete your own integrations.");
    return await n.db.delete(t.integration_id), { success: !0 };
  }, "handler")
}), M = d({
  args: {
    team_id: e.string()
  },
  returns: e.object({
    success: e.boolean()
  }),
  handler: /* @__PURE__ */ s(async (n, t) => {
    let { betterAuthUser: r } = await _(n);
    if (!r)
      throw new o("Authentication required");
    let a = (await n.db.query("slackOAuthTokens").withIndex("by_user_id", (l) => l.eq("user_id", r._id)).collect()).find((l) => l.team_id === t.team_id);
    if (!a)
      throw new o("Slack OAuth token not found");
    return await n.db.patch(a._id, {
      is_active: !1
    }), { success: !0 };
  }, "handler")
});
export {
  U as createMySlackIntegration,
  g as createSlackIntegration,
  z as deleteMySlackIntegration,
  q as deleteSlackIntegration,
  I as getMySlackIntegrations,
  S as getMySlackOAuthTokens,
  A as getSlackIntegrations,
  O as getSlackOAuthTokens,
  M as revokeSlackOAuth,
  j as updateMySlackIntegration,
  T as updateSlackIntegration,
  x as upsertSlackOAuthToken
};
//# sourceMappingURL=slack.js.map
