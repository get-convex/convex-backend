"use node";
import {
  b as f
} from "./_deps/node/VTOLWO7E.js";
import {
  c as p
} from "./_deps/node/PDGHC3PS.js";
import {
  a as e
} from "./_deps/node/UDHF6CTX.js";
import {
  a as u
} from "./_deps/node/V7X2J7BI.js";

// convex/userActions.ts
var y = p({
  args: {
    name: e.string(),
    email: e.string(),
    password: e.string(),
    department: e.optional(e.string()),
    role: e.string()
  },
  returns: e.object({
    success: e.boolean(),
    userId: e.optional(e.id("users")),
    error: e.optional(e.string())
  }),
  handler: /* @__PURE__ */ u(async (d, s) => {
    try {
      let r = process.env.CLERK_SECRET_KEY;
      if (!r)
        throw new Error("CLERK_SECRET_KEY environment variable is not set");
      let o = await fetch("https://api.clerk.com/v1/users", {
        method: "POST",
        headers: {
          Authorization: `Bearer ${r}`,
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          email_address: [s.email],
          password: s.password,
          first_name: s.name.split(" ")[1] || s.name,
          // 名前の後半部分
          last_name: s.name.split(" ")[0] || "",
          // 名前の前半部分
          skip_password_checks: !1,
          skip_password_requirement: !1
        })
      });
      if (!o.ok) {
        let n = await o.json();
        if (console.error("Clerk API error:", n), n.errors && n.errors.length > 0) {
          let i = n.errors[0];
          if (i.code === "form_identifier_exists")
            throw new Error(
              "\u3053\u306E\u30E1\u30FC\u30EB\u30A2\u30C9\u30EC\u30B9\u306F\u65E2\u306B\u767B\u9332\u3055\u308C\u3066\u3044\u307E\u3059\u3002\u5225\u306E\u30E1\u30FC\u30EB\u30A2\u30C9\u30EC\u30B9\u3092\u4F7F\u7528\u3057\u3066\u304F\u3060\u3055\u3044\u3002"
            );
          if (i.code === "form_password_pwned" || i.code === "form_password_too_common" || i.code === "form_password_insufficient")
            throw new Error(
              "\u30D1\u30B9\u30EF\u30FC\u30C9\u304C\u5B89\u5168\u3067\u3042\u308A\u307E\u305B\u3093\u3002\u3088\u308A\u8907\u96D1\u3067\u4E00\u610F\u306A\u30D1\u30B9\u30EF\u30FC\u30C9\u3092\u4F7F\u7528\u3057\u3066\u304F\u3060\u3055\u3044\u3002"
            );
        }
        throw new Error(
          `Clerk API error: ${n.message || n.errors?.[0]?.message || o.statusText}`
        );
      }
      let a = await o.json();
      console.log("Clerk user created successfully, now creating Convex user...");
      let c = await d.runMutation(f.users.createConvexUser, {
        clerkUserId: a.id,
        tokenIdentifier: `clerk_${a.id}`,
        email: s.email,
        name: s.name,
        firstName: s.name.split(" ")[1] || "",
        // 名前の後半部分
        lastName: s.name.split(" ")[0] || "",
        // 名前の前半部分
        role: s.role,
        department: s.department,
        emailVerified: !0,
        // Clerkで作成されたユーザーは確認済みとする
        imageUrl: ""
      });
      return console.log("Convex user created successfully with ID:", c), {
        success: !0,
        userId: c
      };
    } catch (r) {
      return console.error("User creation error:", r), {
        success: !1,
        error: r instanceof Error ? r.message : "\u30E6\u30FC\u30B6\u30FC\u4F5C\u6210\u306B\u5931\u6557\u3057\u307E\u3057\u305F"
      };
    }
  }, "handler")
}), v = p({
  args: {
    clerkUserId: e.string(),
    newPassword: e.string()
  },
  returns: e.object({
    success: e.boolean(),
    error: e.optional(e.string())
  }),
  handler: /* @__PURE__ */ u(async (d, s) => {
    try {
      let r = process.env.CLERK_SECRET_KEY;
      if (!r)
        throw new Error("CLERK_SECRET_KEY environment variable is not set");
      let o = await fetch(`https://api.clerk.com/v1/users/${s.clerkUserId}`, {
        method: "PATCH",
        headers: {
          Authorization: `Bearer ${r}`,
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          password: s.newPassword
        })
      });
      if (!o.ok) {
        let a = await o.json();
        throw console.error("Clerk password update error:", a), new Error(`Clerk API error: ${a.message || o.statusText}`);
      }
      return {
        success: !0
      };
    } catch (r) {
      return console.error("Password update error:", r), {
        success: !1,
        error: r instanceof Error ? r.message : "\u30D1\u30B9\u30EF\u30FC\u30C9\u66F4\u65B0\u306B\u5931\u6557\u3057\u307E\u3057\u305F"
      };
    }
  }, "handler")
}), U = p({
  args: {},
  returns: e.object({
    success: e.boolean(),
    syncedCount: e.number(),
    skippedCount: e.number(),
    errors: e.array(e.string())
  }),
  handler: /* @__PURE__ */ u(async (d, s) => {
    try {
      let r = process.env.CLERK_SECRET_KEY;
      if (!r)
        throw new Error("CLERK_SECRET_KEY environment variable is not set");
      let o = 0, a = 0, c = [], n = 0, i = 100;
      for (; ; ) {
        let m = await fetch(
          `https://api.clerk.com/v1/users?limit=${i}&offset=${n}`,
          {
            method: "GET",
            headers: {
              Authorization: `Bearer ${r}`,
              "Content-Type": "application/json"
            }
          }
        );
        if (!m.ok) {
          let t = await m.json();
          throw new Error(
            `Clerk API error: ${t.message || m.statusText}`
          );
        }
        let _ = await m.json();
        if (_.length === 0)
          break;
        for (let t of _)
          try {
            if (await d.runQuery(f.users.getUserByClerkId, {
              clerkUserId: t.id
            })) {
              a++;
              continue;
            }
            let l = t.email_addresses.find(
              (k) => k.verification?.status === "verified"
            ) || t.email_addresses[0];
            if (!l) {
              c.push(`User ${t.id}: No email address found`);
              continue;
            }
            let w = [t.first_name, t.last_name].filter(Boolean).join(" ") || l.email_address;
            await d.runMutation(f.users.createConvexUser, {
              clerkUserId: t.id,
              tokenIdentifier: `clerk_${t.id}`,
              email: l.email_address,
              name: w,
              firstName: t.first_name,
              lastName: t.last_name,
              imageUrl: t.image_url,
              role: "employee",
              // デフォルトロール
              emailVerified: l.verification?.status === "verified"
            }), o++;
          } catch (g) {
            let l = g instanceof Error ? g.message : "Unknown error";
            c.push(`User ${t.id}: ${l}`);
          }
        if (n += i, _.length < i)
          break;
      }
      return {
        success: !0,
        syncedCount: o,
        skippedCount: a,
        errors: c
      };
    } catch (r) {
      return console.error("User sync error:", r), {
        success: !1,
        syncedCount: 0,
        skippedCount: 0,
        errors: [r instanceof Error ? r.message : "\u540C\u671F\u306B\u5931\u6557\u3057\u307E\u3057\u305F"]
      };
    }
  }, "handler")
});
export {
  y as createUserWithClerk,
  U as syncAllClerkUsersToConvex,
  v as updateUserPasswordWithClerk
};
//# sourceMappingURL=userActions.js.map
