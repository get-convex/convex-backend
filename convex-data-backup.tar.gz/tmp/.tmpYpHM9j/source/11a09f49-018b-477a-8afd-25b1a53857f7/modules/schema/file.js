import {
  a
} from "../_deps/6WC7OENA.js";
import "../_deps/6XQQNYIR.js";
import "../_deps/3TDUHHJO.js";
import "../_deps/RUVYHBJQ.js";
export {
  a as fileSchema
};
//# sourceMappingURL=file.js.map
