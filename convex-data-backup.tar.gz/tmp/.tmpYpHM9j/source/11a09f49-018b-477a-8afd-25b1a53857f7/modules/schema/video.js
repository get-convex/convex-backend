import {
  a
} from "../_deps/3AEAHL7V.js";
import "../_deps/6XQQNYIR.js";
import "../_deps/3TDUHHJO.js";
import "../_deps/RUVYHBJQ.js";
export {
  a as videoSchema
};
//# sourceMappingURL=video.js.map
