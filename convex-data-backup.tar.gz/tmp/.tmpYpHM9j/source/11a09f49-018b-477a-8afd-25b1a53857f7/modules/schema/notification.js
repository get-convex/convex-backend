import {
  a
} from "../_deps/LQPOT665.js";
import "../_deps/6XQQNYIR.js";
import "../_deps/3TDUHHJO.js";
import "../_deps/RUVYHBJQ.js";
export {
  a as notificationSchema
};
//# sourceMappingURL=notification.js.map
