import {
  a
} from "../_deps/M2X5BZC5.js";
import "../_deps/6XQQNYIR.js";
import "../_deps/3TDUHHJO.js";
import "../_deps/RUVYHBJQ.js";
export {
  a as evaluationSchema
};
//# sourceMappingURL=evaluation.js.map
