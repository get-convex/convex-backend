import {
  a as t
} from "../_deps/6734VT7R.js";
import {
  a
} from "../_deps/LQPOT665.js";
import {
  a as f
} from "../_deps/XWLI6SKB.js";
import {
  a as c
} from "../_deps/3AEAHL7V.js";
import {
  a as o
} from "../_deps/VPLOFYF2.js";
import {
  a as r
} from "../_deps/U43NR3PR.js";
import {
  a as i
} from "../_deps/M2X5BZC5.js";
import {
  a as e
} from "../_deps/6WC7OENA.js";
import {
  o as m,
  p
} from "../_deps/6XQQNYIR.js";
import "../_deps/3TDUHHJO.js";
import "../_deps/RUVYHBJQ.js";

// convex/schema/index.ts
p();
var y = m({
  // コアシステム（認証・ユーザー管理）
  ...o,
  // 動画・メディア関連
  ...c,
  // 評価システム
  ...i,
  // トレーニング・学習システム
  ...f,
  // ファイル管理・ストレージシステム
  ...e,
  // 通知・コミュニケーションシステム
  ...a,
  // 外部統合・監視システム
  ...t,
  // セキュリティ・暗号化システム
  ...r
});
export {
  y as default
};
//# sourceMappingURL=index.js.map
