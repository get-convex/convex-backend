import {
  a
} from "../_deps/XWLI6SKB.js";
import "../_deps/6XQQNYIR.js";
import "../_deps/3TDUHHJO.js";
import "../_deps/RUVYHBJQ.js";
export {
  a as trainingSchema
};
//# sourceMappingURL=training.js.map
