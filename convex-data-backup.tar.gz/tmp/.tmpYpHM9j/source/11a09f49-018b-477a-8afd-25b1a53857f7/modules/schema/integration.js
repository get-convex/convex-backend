import {
  a
} from "../_deps/6734VT7R.js";
import "../_deps/6XQQNYIR.js";
import "../_deps/3TDUHHJO.js";
import "../_deps/RUVYHBJQ.js";
export {
  a as integrationSchema
};
//# sourceMappingURL=integration.js.map
