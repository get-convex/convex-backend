import {
  a
} from "../_deps/VPLOFYF2.js";
import "../_deps/6XQQNYIR.js";
import "../_deps/3TDUHHJO.js";
import "../_deps/RUVYHBJQ.js";
export {
  a as coreSchema
};
//# sourceMappingURL=core.js.map
