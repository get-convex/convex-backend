import {
  b as i
} from "./_deps/75JH2J25.js";
import "./_deps/6XQQNYIR.js";
import {
  j as r,
  n
} from "./_deps/3TDUHHJO.js";
import {
  a
} from "./_deps/RUVYHBJQ.js";

// convex/debug.ts
n();
var _ = i({
  args: {
    videoId: r.string()
  },
  returns: r.any(),
  handler: /* @__PURE__ */ a(async (t, s) => {
    if (!await t.db.get(s.videoId))
      return { error: "Video not found" };
    let e = await t.db.query("transcriptions").withIndex(
      "by_resource",
      (m) => m.eq("resource_type", "video").eq("resource_id", s.videoId)
    ).first();
    return e ? {
      id: e._id,
      meeting_summary: e.meeting_summary,
      meeting_summary_status: e.meeting_summary_status,
      case_summary: e.case_summary,
      case_summary_status: e.case_summary_status,
      // データ構造の詳細
      meeting_summary_structure: typeof e.meeting_summary,
      meeting_summary_keys: e.meeting_summary ? Object.keys(e.meeting_summary) : null
    } : { error: "Transcription not found", videoExists: !0 };
  }, "handler")
});
export {
  _ as debugTranscriptionData
};
//# sourceMappingURL=debug.js.map
