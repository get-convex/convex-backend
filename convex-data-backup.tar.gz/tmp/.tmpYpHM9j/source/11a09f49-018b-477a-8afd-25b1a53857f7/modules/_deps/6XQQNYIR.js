import {
  a as S,
  b as z,
  c as y,
  d,
  e as w,
  f as Ie,
  g as q,
  h as $e,
  i as oe,
  j as a,
  k as se,
  l as Re,
  m as Ct,
  n as A
} from "./3TDUHHJO.js";
import {
  a as n,
  b as p
} from "./RUVYHBJQ.js";

// node_modules/convex/dist/esm/server/functionName.js
var C, ie = p(() => {
  "use strict";
  C = Symbol.for("functionName");
});

// node_modules/convex/dist/esm/server/components/paths.js
function Et(t) {
  return t[ae] ?? null;
}
function Pt(t) {
  return t.startsWith("function://");
}
function g(t) {
  let e;
  if (typeof t == "string")
    Pt(t) ? e = { functionHandle: t } : e = { name: t };
  else if (t[C])
    e = { name: t[C] };
  else {
    let r = Et(t);
    if (!r)
      throw new Error(`${t} is not a functionReference`);
    e = { reference: r };
  }
  return e;
}
var ae, E = p(() => {
  "use strict";
  ie();
  ae = Symbol.for("toReferencePath");
  n(Et, "extractReferencePath");
  n(Pt, "isFunctionHandle");
  n(g, "getFunctionAddress");
});

// node_modules/convex/dist/esm/server/api.js
function ue(t) {
  let e = g(t);
  if (e.name === void 0)
    throw e.functionHandle !== void 0 ? new Error(
      `Expected function reference like "api.file.func" or "internal.file.func", but received function handle ${e.functionHandle}`
    ) : e.reference !== void 0 ? new Error(
      `Expected function reference in the current component like "api.file.func" or "internal.file.func", but received reference ${e.reference}`
    ) : new Error(
      `Expected function reference like "api.file.func" or "internal.file.func", but received ${JSON.stringify(e)}`
    );
  if (typeof t == "string") return t;
  let r = t[C];
  if (!r)
    throw new Error(`${t} is not a functionReference`);
  return r;
}
function Tt(t) {
  return { [C]: t };
}
function Oe(t = []) {
  let e = {
    get(r, o) {
      if (typeof o == "string") {
        let s = [...t, o];
        return Oe(s);
      } else if (o === C) {
        if (t.length < 2) {
          let u = ["api", ...t].join(".");
          throw new Error(
            `API path is expected to be of the form \`api.moduleName.functionName\`. Found: \`${u}\``
          );
        }
        let s = t.slice(0, -1).join("/"), i = t[t.length - 1];
        return i === "default" ? s : s + ":" + i;
      } else return o === Symbol.toStringTag ? "FunctionReference" : void 0;
    }
  };
  return new Proxy({}, e);
}
var Nt, ce = p(() => {
  "use strict";
  ie();
  E();
  n(ue, "getFunctionName");
  n(Tt, "makeFunctionReference");
  n(Oe, "createApi");
  Nt = Oe();
});

// node_modules/convex/dist/esm/server/cron.js
function le(t) {
  if (!Number.isInteger(t) || t <= 0)
    throw new Error("Interval must be an integer greater than 0");
}
function qt(t) {
  if (!Number.isInteger(t) || t < 1 || t > 31)
    throw new Error("Day of month must be an integer from 1 to 31");
  return t;
}
function Ft(t) {
  if (!Rt.includes(t))
    throw new Error('Day of week must be a string like "monday".');
  return t;
}
function pe(t) {
  if (!Number.isInteger(t) || t < 0 || t > 23)
    throw new Error("Hour of day must be an integer from 0 to 23");
  return t;
}
function B(t) {
  if (!Number.isInteger(t) || t < 0 || t > 59)
    throw new Error("Minute of hour must be an integer from 0 to 59");
  return t;
}
function Mt(t) {
  if (!t.match(/^[ -~]*$/))
    throw new Error(
      `Invalid cron identifier ${t}: use ASCII letters that are not control characters`
    );
  return t;
}
var It, $t, qe, Rt, Ot, fe, Fe = p(() => {
  "use strict";
  ce();
  z();
  A();
  It = Object.defineProperty, $t = /* @__PURE__ */ n((t, e, r) => e in t ? It(t, e, { enumerable: !0, configurable: !0, writable: !0, value: r }) : t[e] = r, "__defNormalProp"), qe = /* @__PURE__ */ n((t, e, r) => $t(t, typeof e != "symbol" ? e + "" : e, r), "__publicField"), Rt = [
    "sunday",
    "monday",
    "tuesday",
    "wednesday",
    "thursday",
    "friday",
    "saturday"
  ], Ot = /* @__PURE__ */ n(() => new fe(), "cronJobs");
  n(le, "validateIntervalNumber");
  n(qt, "validatedDayOfMonth");
  n(Ft, "validatedDayOfWeek");
  n(pe, "validatedHourOfDay");
  n(B, "validatedMinuteOfHour");
  n(Mt, "validatedCronIdentifier");
  fe = class {
    static {
      n(this, "Crons");
    }
    constructor() {
      qe(this, "crons"), qe(this, "isCrons"), this.isCrons = !0, this.crons = {};
    }
    /** @internal */
    schedule(e, r, o, s) {
      let i = S(s);
      if (Mt(e), e in this.crons)
        throw new Error(`Cron identifier registered twice: ${e}`);
      this.crons[e] = {
        name: ue(o),
        args: [d(i)],
        schedule: r
      };
    }
    /**
     * Schedule a mutation or action to run at some interval.
     *
     * ```js
     * crons.interval("Clear presence data", {seconds: 30}, api.presence.clear);
     * ```
     *
     * @param identifier - A unique name for this scheduled job.
     * @param schedule - The time between runs for this scheduled job.
     * @param functionReference - A {@link FunctionReference} for the function
     * to schedule.
     * @param args - The arguments to the function.
     */
    interval(e, r, o, ...s) {
      let i = r, u = +("seconds" in i && i.seconds !== void 0), h = +("minutes" in i && i.minutes !== void 0), b = +("hours" in i && i.hours !== void 0);
      if (u + h + b !== 1)
        throw new Error("Must specify one of seconds, minutes, or hours");
      u ? le(r.seconds) : h ? le(r.minutes) : b && le(r.hours), this.schedule(
        e,
        { ...r, type: "interval" },
        o,
        ...s
      );
    }
    /**
     * Schedule a mutation or action to run on an hourly basis.
     *
     * ```js
     * crons.hourly(
     *   "Reset high scores",
     *   {
     *     minuteUTC: 30,
     *   },
     *   api.scores.reset
     * )
     * ```
     *
     * @param cronIdentifier - A unique name for this scheduled job.
     * @param schedule - What time (UTC) each day to run this function.
     * @param functionReference - A {@link FunctionReference} for the function
     * to schedule.
     * @param args - The arguments to the function.
     */
    hourly(e, r, o, ...s) {
      let i = B(r.minuteUTC);
      this.schedule(
        e,
        { minuteUTC: i, type: "hourly" },
        o,
        ...s
      );
    }
    /**
     * Schedule a mutation or action to run on a daily basis.
     *
     * ```js
     * crons.daily(
     *   "Reset high scores",
     *   {
     *     hourUTC: 17, // (9:30am Pacific/10:30am Daylight Savings Pacific)
     *     minuteUTC: 30,
     *   },
     *   api.scores.reset
     * )
     * ```
     *
     * @param cronIdentifier - A unique name for this scheduled job.
     * @param schedule - What time (UTC) each day to run this function.
     * @param functionReference - A {@link FunctionReference} for the function
     * to schedule.
     * @param args - The arguments to the function.
     */
    daily(e, r, o, ...s) {
      let i = pe(r.hourUTC), u = B(r.minuteUTC);
      this.schedule(
        e,
        { hourUTC: i, minuteUTC: u, type: "daily" },
        o,
        ...s
      );
    }
    /**
     * Schedule a mutation or action to run on a weekly basis.
     *
     * ```js
     * crons.weekly(
     *   "Weekly re-engagement email",
     *   {
     *     dayOfWeek: "Tuesday",
     *     hourUTC: 17, // (9:30am Pacific/10:30am Daylight Savings Pacific)
     *     minuteUTC: 30,
     *   },
     *   api.emails.send
     * )
     * ```
     *
     * @param cronIdentifier - A unique name for this scheduled job.
     * @param schedule - What day and time (UTC) each week to run this function.
     * @param functionReference - A {@link FunctionReference} for the function
     * to schedule.
     */
    weekly(e, r, o, ...s) {
      let i = Ft(r.dayOfWeek), u = pe(r.hourUTC), h = B(r.minuteUTC);
      this.schedule(
        e,
        { dayOfWeek: i, hourUTC: u, minuteUTC: h, type: "weekly" },
        o,
        ...s
      );
    }
    /**
     * Schedule a mutation or action to run on a monthly basis.
     *
     * Note that some months have fewer days than others, so e.g. a function
     * scheduled to run on the 30th will not run in February.
     *
     * ```js
     * crons.monthly(
     *   "Bill customers at ",
     *   {
     *     hourUTC: 17, // (9:30am Pacific/10:30am Daylight Savings Pacific)
     *     minuteUTC: 30,
     *     day: 1,
     *   },
     *   api.billing.billCustomers
     * )
     * ```
     *
     * @param cronIdentifier - A unique name for this scheduled job.
     * @param schedule - What day and time (UTC) each month to run this function.
     * @param functionReference - A {@link FunctionReference} for the function
     * to schedule.
     * @param args - The arguments to the function.
     */
    monthly(e, r, o, ...s) {
      let i = qt(r.day), u = pe(r.hourUTC), h = B(r.minuteUTC);
      this.schedule(
        e,
        { day: i, hourUTC: u, minuteUTC: h, type: "monthly" },
        o,
        ...s
      );
    }
    /**
     * Schedule a mutation or action to run on a recurring basis.
     *
     * Like the unix command `cron`, Sunday is 0, Monday is 1, etc.
     *
     * ```
     *  ┌─ minute (0 - 59)
     *  │ ┌─ hour (0 - 23)
     *  │ │ ┌─ day of the month (1 - 31)
     *  │ │ │ ┌─ month (1 - 12)
     *  │ │ │ │ ┌─ day of the week (0 - 6) (Sunday to Saturday)
     * "* * * * *"
     * ```
     *
     * @param cronIdentifier - A unique name for this scheduled job.
     * @param cron - Cron string like `"15 7 * * *"` (Every day at 7:15 UTC)
     * @param functionReference - A {@link FunctionReference} for the function
     * to schedule.
     * @param args - The arguments to the function.
     */
    cron(e, r, o, ...s) {
      let i = r;
      this.schedule(
        e,
        { cron: i, type: "cron" },
        o,
        ...s
      );
    }
    /** @internal */
    export() {
      return JSON.stringify(this.crons);
    }
  };
});

// node_modules/convex/dist/esm/server/impl/syscall.js
function Q(t, e) {
  if (typeof Convex > "u" || Convex.syscall === void 0)
    throw new Error(
      "The Convex database and auth objects are being used outside of a Convex backend. Did you mean to use `useQuery` or `useMutation` to call a Convex function?"
    );
  let r = Convex.syscall(t, JSON.stringify(e));
  return JSON.parse(r);
}
async function l(t, e) {
  if (typeof Convex > "u" || Convex.asyncSyscall === void 0)
    throw new Error(
      "The Convex database and auth objects are being used outside of a Convex backend. Did you mean to use `useQuery` or `useMutation` to call a Convex function?"
    );
  let r;
  try {
    r = await Convex.asyncSyscall(t, JSON.stringify(e));
  } catch (o) {
    if (o.data !== void 0) {
      let s = new Re(o.message);
      throw s.data = y(o.data), s;
    }
    throw new Error(o.message);
  }
  return JSON.parse(r);
}
function P(t, e) {
  if (typeof Convex > "u" || Convex.jsSyscall === void 0)
    throw new Error(
      "The Convex database and auth objects are being used outside of a Convex backend. Did you mean to use `useQuery` or `useMutation` to call a Convex function?"
    );
  return Convex.jsSyscall(t, e);
}
var v = p(() => {
  "use strict";
  Ct();
  q();
  n(Q, "performSyscall");
  n(l, "performAsyncSyscall");
  n(P, "performJsSyscall");
});

// node_modules/convex/dist/esm/server/router.js
function jt(t) {
  return t === "HEAD" ? "GET" : t;
}
var Jt, Ut, T, Me, Qt, W, Je = p(() => {
  "use strict";
  v();
  Jt = Object.defineProperty, Ut = /* @__PURE__ */ n((t, e, r) => e in t ? Jt(t, e, { enumerable: !0, configurable: !0, writable: !0, value: r }) : t[e] = r, "__defNormalProp"), T = /* @__PURE__ */ n((t, e, r) => Ut(t, typeof e != "symbol" ? e + "" : e, r), "__publicField"), Me = [
    "GET",
    "POST",
    "PUT",
    "DELETE",
    "OPTIONS",
    "PATCH"
  ];
  n(jt, "normalizeMethod");
  Qt = /* @__PURE__ */ n(() => new W(), "httpRouter"), W = class {
    static {
      n(this, "HttpRouter");
    }
    constructor() {
      T(this, "exactRoutes", /* @__PURE__ */ new Map()), T(this, "prefixRoutes", /* @__PURE__ */ new Map()), T(this, "isRouter", !0), T(this, "route", (e) => {
        if (!e.handler) throw new Error("route requires handler");
        if (!e.method) throw new Error("route requires method");
        let { method: r, handler: o } = e;
        if (!Me.includes(r))
          throw new Error(
            `'${r}' is not an allowed HTTP method (like GET, POST, PUT etc.)`
          );
        if ("path" in e) {
          if ("pathPrefix" in e)
            throw new Error(
              "Invalid httpRouter route: cannot contain both 'path' and 'pathPrefix'"
            );
          if (!e.path.startsWith("/"))
            throw new Error(`path '${e.path}' does not start with a /`);
          let s = this.exactRoutes.has(e.path) ? this.exactRoutes.get(e.path) : /* @__PURE__ */ new Map();
          if (s.has(r))
            throw new Error(
              `Path '${e.path}' for method ${r} already in use`
            );
          s.set(r, o), this.exactRoutes.set(e.path, s);
        } else if ("pathPrefix" in e) {
          if (!e.pathPrefix.startsWith("/"))
            throw new Error(
              `pathPrefix '${e.pathPrefix}' does not start with a /`
            );
          if (!e.pathPrefix.endsWith("/"))
            throw new Error(`pathPrefix ${e.pathPrefix} must end with a /`);
          let s = this.prefixRoutes.get(r) || /* @__PURE__ */ new Map();
          if (s.has(e.pathPrefix))
            throw new Error(
              `${e.method} pathPrefix ${e.pathPrefix} is already defined`
            );
          s.set(e.pathPrefix, o), this.prefixRoutes.set(r, s);
        } else
          throw new Error(
            "Invalid httpRouter route entry: must contain either field 'path' or 'pathPrefix'"
          );
      }), T(this, "getRoutes", () => {
        let r = [...this.exactRoutes.keys()].sort().flatMap(
          (i) => [...this.exactRoutes.get(i).keys()].sort().map(
            (u) => [i, u, this.exactRoutes.get(i).get(u)]
          )
        ), s = [...this.prefixRoutes.keys()].sort().flatMap(
          (i) => [...this.prefixRoutes.get(i).keys()].sort().map(
            (u) => [
              `${u}*`,
              i,
              this.prefixRoutes.get(i).get(u)
            ]
          )
        );
        return [...r, ...s];
      }), T(this, "lookup", (e, r) => {
        r = jt(r);
        let o = this.exactRoutes.get(e)?.get(r);
        if (o) return [o, r, e];
        let i = [...(this.prefixRoutes.get(r) || /* @__PURE__ */ new Map()).entries()].sort(
          ([u, h], [b, j]) => b.length - u.length
        );
        for (let [u, h] of i)
          if (e.startsWith(u))
            return [h, r, `${u}*`];
        return null;
      }), T(this, "runRequest", async (e, r) => {
        let o = P("requestFromConvexJson", {
          convexJson: JSON.parse(e)
        }), s = r;
        (!s || typeof s != "string") && (s = new URL(o.url).pathname);
        let i = o.method, u = this.lookup(s, i);
        if (!u) {
          let ne = new Response(`No HttpAction routed for ${s}`, {
            status: 404
          });
          return JSON.stringify(
            P("convexJsonFromResponse", { response: ne })
          );
        }
        let [h, b, j] = u, re = await h.invokeHttpAction(o);
        return JSON.stringify(
          P("convexJsonFromResponse", { response: re })
        );
      });
    }
  };
});

// node_modules/convex/dist/esm/index.js
var m, _ = p(() => {
  "use strict";
  m = "1.25.0";
});

// node_modules/convex/dist/esm/server/components/index.js
function Ue(t, e) {
  let r = {
    get(o, s) {
      if (typeof s == "string") {
        let i = [...e, s];
        return Ue(t, i);
      } else if (s === ae) {
        if (e.length < 1) {
          let i = [t, ...e].join(".");
          throw new Error(
            `API path is expected to be of the form \`${t}.childComponent.functionName\`. Found: \`${i}\``
          );
        }
        return "_reference/childComponent/" + e.join("/");
      } else
        return;
    }
  };
  return new Proxy({}, r);
}
var Gt, V = p(() => {
  "use strict";
  A();
  _();
  v();
  E();
  E();
  n(Ue, "createChildComponents");
  Gt = /* @__PURE__ */ n(() => Ue("components", []), "componentsGeneric");
});

// node_modules/convex/dist/esm/server/schema.js
function de(t) {
  return $e(t) ? new k(t) : new k(a.object(t));
}
function je(t, e) {
  return new he(t, e);
}
var Ht, zt, N, k, he, Zr, Qe = p(() => {
  "use strict";
  se();
  Ht = Object.defineProperty, zt = /* @__PURE__ */ n((t, e, r) => e in t ? Ht(t, e, { enumerable: !0, configurable: !0, writable: !0, value: r }) : t[e] = r, "__defNormalProp"), N = /* @__PURE__ */ n((t, e, r) => zt(t, typeof e != "symbol" ? e + "" : e, r), "__publicField"), k = class {
    static {
      n(this, "TableDefinition");
    }
    /**
     * @internal
     */
    constructor(e) {
      N(this, "indexes"), N(this, "searchIndexes"), N(this, "vectorIndexes"), N(this, "validator"), this.indexes = [], this.searchIndexes = [], this.vectorIndexes = [], this.validator = e;
    }
    /**
     * This API is experimental: it may change or disappear.
     *
     * Returns indexes defined on this table.
     * Intended for the advanced use cases of dynamically deciding which index to use for a query.
     * If you think you need this, please chime in on ths issue in the Convex JS GitHub repo.
     * https://github.com/get-convex/convex-js/issues/49
     */
    " indexes"() {
      return this.indexes;
    }
    /**
     * Define an index on this table.
     *
     * To learn about indexes, see [Defining Indexes](https://docs.convex.dev/using/indexes).
     *
     * @param name - The name of the index.
     * @param fields - The fields to index, in order. Must specify at least one
     * field.
     * @returns A {@link TableDefinition} with this index included.
     */
    index(e, r) {
      return this.indexes.push({ indexDescriptor: e, fields: r }), this;
    }
    /**
     * Define a search index on this table.
     *
     * To learn about search indexes, see [Search](https://docs.convex.dev/text-search).
     *
     * @param name - The name of the index.
     * @param indexConfig - The search index configuration object.
     * @returns A {@link TableDefinition} with this search index included.
     */
    searchIndex(e, r) {
      return this.searchIndexes.push({
        indexDescriptor: e,
        searchField: r.searchField,
        filterFields: r.filterFields || []
      }), this;
    }
    /**
     * Define a vector index on this table.
     *
     * To learn about vector indexes, see [Vector Search](https://docs.convex.dev/vector-search).
     *
     * @param name - The name of the index.
     * @param indexConfig - The vector index configuration object.
     * @returns A {@link TableDefinition} with this vector index included.
     */
    vectorIndex(e, r) {
      return this.vectorIndexes.push({
        indexDescriptor: e,
        vectorField: r.vectorField,
        dimensions: r.dimensions,
        filterFields: r.filterFields || []
      }), this;
    }
    /**
     * Work around for https://github.com/microsoft/TypeScript/issues/57035
     */
    self() {
      return this;
    }
    /**
     * Export the contents of this definition.
     *
     * This is called internally by the Convex framework.
     * @internal
     */
    export() {
      let e = this.validator.json;
      if (typeof e != "object")
        throw new Error(
          "Invalid validator: please make sure that the parameter of `defineTable` is valid (see https://docs.convex.dev/database/schemas)"
        );
      return {
        indexes: this.indexes,
        searchIndexes: this.searchIndexes,
        vectorIndexes: this.vectorIndexes,
        documentType: e
      };
    }
  };
  n(de, "defineTable");
  he = class {
    static {
      n(this, "SchemaDefinition");
    }
    /**
     * @internal
     */
    constructor(e, r) {
      N(this, "tables"), N(this, "strictTableNameTypes"), N(this, "schemaValidation"), this.tables = e, this.schemaValidation = r?.schemaValidation === void 0 ? !0 : r.schemaValidation;
    }
    /**
     * Export the contents of this definition.
     *
     * This is called internally by the Convex framework.
     * @internal
     */
    export() {
      return JSON.stringify({
        tables: Object.entries(this.tables).map(([e, r]) => {
          let { indexes: o, searchIndexes: s, vectorIndexes: i, documentType: u } = r.export();
          return {
            tableName: e,
            indexes: o,
            searchIndexes: s,
            vectorIndexes: i,
            documentType: u
          };
        }),
        schemaValidation: this.schemaValidation
      });
    }
  };
  n(je, "defineSchema");
  Zr = je({
    _scheduled_functions: de({
      name: a.string(),
      args: a.array(a.any()),
      scheduledTime: a.float64(),
      completedTime: a.optional(a.float64()),
      state: a.union(
        a.object({ kind: a.literal("pending") }),
        a.object({ kind: a.literal("inProgress") }),
        a.object({ kind: a.literal("success") }),
        a.object({ kind: a.literal("failed"), error: a.string() }),
        a.object({ kind: a.literal("canceled") })
      )
    }),
    _storage: de({
      sha256: a.string(),
      size: a.float64(),
      contentType: a.optional(a.string())
    })
  });
});

// node_modules/convex/dist/esm/server/database.js
var Ge = p(() => {
  "use strict";
});

// node_modules/convex/dist/esm/server/impl/actions_impl.js
function me(t, e, r) {
  return {
    ...g(e),
    args: d(S(r)),
    version: m,
    requestId: t
  };
}
function ye(t) {
  return {
    runQuery: /* @__PURE__ */ n(async (e, r) => {
      let o = await l(
        "1.0/actions/query",
        me(t, e, r)
      );
      return y(o);
    }, "runQuery"),
    runMutation: /* @__PURE__ */ n(async (e, r) => {
      let o = await l(
        "1.0/actions/mutation",
        me(t, e, r)
      );
      return y(o);
    }, "runMutation"),
    runAction: /* @__PURE__ */ n(async (e, r) => {
      let o = await l(
        "1.0/actions/action",
        me(t, e, r)
      );
      return y(o);
    }, "runAction")
  };
}
var He = p(() => {
  "use strict";
  A();
  _();
  v();
  z();
  E();
  n(me, "syscallArgs");
  n(ye, "setupActionCalls");
});

// node_modules/convex/dist/esm/server/vector_search.js
var Bt, Wt, ze, L, Be = p(() => {
  "use strict";
  Bt = Object.defineProperty, Wt = /* @__PURE__ */ n((t, e, r) => e in t ? Bt(t, e, { enumerable: !0, configurable: !0, writable: !0, value: r }) : t[e] = r, "__defNormalProp"), ze = /* @__PURE__ */ n((t, e, r) => Wt(t, typeof e != "symbol" ? e + "" : e, r), "__publicField"), L = class {
    static {
      n(this, "FilterExpression");
    }
    /**
     * @internal
     */
    constructor() {
      ze(this, "_isExpression"), ze(this, "_value");
    }
  };
});

// node_modules/convex/dist/esm/server/impl/validate.js
function c(t, e, r, o) {
  if (t === void 0)
    throw new TypeError(
      `Must provide arg ${e} \`${o}\` to \`${r}\``
    );
}
function We(t, e, r, o) {
  if (!Number.isInteger(t) || t < 0)
    throw new TypeError(
      `Arg ${e} \`${o}\` to \`${r}\` must be a non-negative integer`
    );
}
var I = p(() => {
  "use strict";
  n(c, "validateArg");
  n(We, "validateArgIsNonNegativeInteger");
});

// node_modules/convex/dist/esm/server/impl/vector_search_impl.js
function ge(t) {
  return async (e, r, o) => {
    if (c(e, 1, "vectorSearch", "tableName"), c(r, 2, "vectorSearch", "indexName"), c(o, 3, "vectorSearch", "query"), !o.vector || !Array.isArray(o.vector) || o.vector.length === 0)
      throw Error("`vector` must be a non-empty Array in vectorSearch");
    return await new we(
      t,
      e + "." + r,
      o
    ).collect();
  };
}
function Y(t) {
  return t instanceof F ? t.serialize() : { $literal: w(t) };
}
var Vt, kt, xe, we, F, Lt, Ve = p(() => {
  "use strict";
  v();
  _();
  Be();
  I();
  q();
  Vt = Object.defineProperty, kt = /* @__PURE__ */ n((t, e, r) => e in t ? Vt(t, e, { enumerable: !0, configurable: !0, writable: !0, value: r }) : t[e] = r, "__defNormalProp"), xe = /* @__PURE__ */ n((t, e, r) => kt(t, typeof e != "symbol" ? e + "" : e, r), "__publicField");
  n(ge, "setupActionVectorSearch");
  we = class {
    static {
      n(this, "VectorQueryImpl");
    }
    constructor(e, r, o) {
      xe(this, "requestId"), xe(this, "state"), this.requestId = e;
      let s = o.filter ? Y(o.filter(Lt)) : null;
      this.state = {
        type: "preparing",
        query: {
          indexName: r,
          limit: o.limit,
          vector: o.vector,
          expressions: s
        }
      };
    }
    async collect() {
      if (this.state.type === "consumed")
        throw new Error("This query is closed and can't emit any more values.");
      let e = this.state.query;
      this.state = { type: "consumed" };
      let { results: r } = await l("1.0/actions/vectorSearch", {
        requestId: this.requestId,
        version: m,
        query: e
      });
      return r;
    }
  }, F = class extends L {
    static {
      n(this, "ExpressionImpl");
    }
    constructor(e) {
      super(), xe(this, "inner"), this.inner = e;
    }
    serialize() {
      return this.inner;
    }
  };
  n(Y, "serializeExpression");
  Lt = {
    //  Comparisons  /////////////////////////////////////////////////////////////
    eq(t, e) {
      if (typeof t != "string")
        throw new Error("The first argument to `q.eq` must be a field name.");
      return new F({
        $eq: [
          Y(new F({ $field: t })),
          Y(e)
        ]
      });
    },
    //  Logic  ///////////////////////////////////////////////////////////////////
    or(...t) {
      return new F({ $or: t.map(Y) });
    }
  };
});

// node_modules/convex/dist/esm/server/impl/authentication_impl.js
function G(t) {
  return {
    getUserIdentity: /* @__PURE__ */ n(async () => await l("1.0/getUserIdentity", {
      requestId: t
    }), "getUserIdentity")
  };
}
var ke = p(() => {
  "use strict";
  v();
  n(G, "setupAuth");
});

// node_modules/convex/dist/esm/server/filter_builder.js
var Yt, Kt, Le, K, Ye = p(() => {
  "use strict";
  Yt = Object.defineProperty, Kt = /* @__PURE__ */ n((t, e, r) => e in t ? Yt(t, e, { enumerable: !0, configurable: !0, writable: !0, value: r }) : t[e] = r, "__defNormalProp"), Le = /* @__PURE__ */ n((t, e, r) => Kt(t, typeof e != "symbol" ? e + "" : e, r), "__publicField"), K = class {
    static {
      n(this, "Expression");
    }
    /**
     * @internal
     */
    constructor() {
      Le(this, "_isExpression"), Le(this, "_value");
    }
  };
});

// node_modules/convex/dist/esm/server/impl/filter_builder_impl.js
function f(t) {
  return t instanceof x ? t.serialize() : { $literal: w(t) };
}
var Xt, Zt, Dt, x, Ke, Xe = p(() => {
  "use strict";
  q();
  Ye();
  Xt = Object.defineProperty, Zt = /* @__PURE__ */ n((t, e, r) => e in t ? Xt(t, e, { enumerable: !0, configurable: !0, writable: !0, value: r }) : t[e] = r, "__defNormalProp"), Dt = /* @__PURE__ */ n((t, e, r) => Zt(t, typeof e != "symbol" ? e + "" : e, r), "__publicField"), x = class extends K {
    static {
      n(this, "ExpressionImpl");
    }
    constructor(e) {
      super(), Dt(this, "inner"), this.inner = e;
    }
    serialize() {
      return this.inner;
    }
  };
  n(f, "serializeExpression");
  Ke = {
    //  Comparisons  /////////////////////////////////////////////////////////////
    eq(t, e) {
      return new x({
        $eq: [f(t), f(e)]
      });
    },
    neq(t, e) {
      return new x({
        $neq: [f(t), f(e)]
      });
    },
    lt(t, e) {
      return new x({
        $lt: [f(t), f(e)]
      });
    },
    lte(t, e) {
      return new x({
        $lte: [f(t), f(e)]
      });
    },
    gt(t, e) {
      return new x({
        $gt: [f(t), f(e)]
      });
    },
    gte(t, e) {
      return new x({
        $gte: [f(t), f(e)]
      });
    },
    //  Arithmetic  //////////////////////////////////////////////////////////////
    add(t, e) {
      return new x({
        $add: [f(t), f(e)]
      });
    },
    sub(t, e) {
      return new x({
        $sub: [f(t), f(e)]
      });
    },
    mul(t, e) {
      return new x({
        $mul: [f(t), f(e)]
      });
    },
    div(t, e) {
      return new x({
        $div: [f(t), f(e)]
      });
    },
    mod(t, e) {
      return new x({
        $mod: [f(t), f(e)]
      });
    },
    neg(t) {
      return new x({ $neg: f(t) });
    },
    //  Logic  ///////////////////////////////////////////////////////////////////
    and(...t) {
      return new x({ $and: t.map(f) });
    },
    or(...t) {
      return new x({ $or: t.map(f) });
    },
    not(t) {
      return new x({ $not: f(t) });
    },
    //  Other  ///////////////////////////////////////////////////////////////////
    field(t) {
      return new x({ $field: t });
    }
  };
});

// node_modules/convex/dist/esm/server/index_range_builder.js
var er, tr, rr, X, Ze = p(() => {
  "use strict";
  er = Object.defineProperty, tr = /* @__PURE__ */ n((t, e, r) => e in t ? er(t, e, { enumerable: !0, configurable: !0, writable: !0, value: r }) : t[e] = r, "__defNormalProp"), rr = /* @__PURE__ */ n((t, e, r) => tr(t, typeof e != "symbol" ? e + "" : e, r), "__publicField"), X = class {
    static {
      n(this, "IndexRange");
    }
    /**
     * @internal
     */
    constructor() {
      rr(this, "_isIndexRange");
    }
  };
});

// node_modules/convex/dist/esm/server/impl/index_range_builder_impl.js
var nr, or, De, Z, et = p(() => {
  "use strict";
  q();
  Ze();
  nr = Object.defineProperty, or = /* @__PURE__ */ n((t, e, r) => e in t ? nr(t, e, { enumerable: !0, configurable: !0, writable: !0, value: r }) : t[e] = r, "__defNormalProp"), De = /* @__PURE__ */ n((t, e, r) => or(t, typeof e != "symbol" ? e + "" : e, r), "__publicField"), Z = class t extends X {
    static {
      n(this, "IndexRangeBuilderImpl");
    }
    constructor(e) {
      super(), De(this, "rangeExpressions"), De(this, "isConsumed"), this.rangeExpressions = e, this.isConsumed = !1;
    }
    static new() {
      return new t([]);
    }
    consume() {
      if (this.isConsumed)
        throw new Error(
          "IndexRangeBuilder has already been used! Chain your method calls like `q => q.eq(...).eq(...)`. See https://docs.convex.dev/using/indexes"
        );
      this.isConsumed = !0;
    }
    eq(e, r) {
      return this.consume(), new t(
        this.rangeExpressions.concat({
          type: "Eq",
          fieldPath: e,
          value: w(r)
        })
      );
    }
    gt(e, r) {
      return this.consume(), new t(
        this.rangeExpressions.concat({
          type: "Gt",
          fieldPath: e,
          value: w(r)
        })
      );
    }
    gte(e, r) {
      return this.consume(), new t(
        this.rangeExpressions.concat({
          type: "Gte",
          fieldPath: e,
          value: w(r)
        })
      );
    }
    lt(e, r) {
      return this.consume(), new t(
        this.rangeExpressions.concat({
          type: "Lt",
          fieldPath: e,
          value: w(r)
        })
      );
    }
    lte(e, r) {
      return this.consume(), new t(
        this.rangeExpressions.concat({
          type: "Lte",
          fieldPath: e,
          value: w(r)
        })
      );
    }
    export() {
      return this.consume(), this.rangeExpressions;
    }
  };
});

// node_modules/convex/dist/esm/server/search_filter_builder.js
var sr, ir, ar, D, ve = p(() => {
  "use strict";
  sr = Object.defineProperty, ir = /* @__PURE__ */ n((t, e, r) => e in t ? sr(t, e, { enumerable: !0, configurable: !0, writable: !0, value: r }) : t[e] = r, "__defNormalProp"), ar = /* @__PURE__ */ n((t, e, r) => ir(t, typeof e != "symbol" ? e + "" : e, r), "__publicField"), D = class {
    static {
      n(this, "SearchFilter");
    }
    /**
     * @internal
     */
    constructor() {
      ar(this, "_isSearchFilter");
    }
  };
});

// node_modules/convex/dist/esm/server/impl/search_filter_builder_impl.js
var ur, cr, tt, ee, rt = p(() => {
  "use strict";
  q();
  ve();
  I();
  ur = Object.defineProperty, cr = /* @__PURE__ */ n((t, e, r) => e in t ? ur(t, e, { enumerable: !0, configurable: !0, writable: !0, value: r }) : t[e] = r, "__defNormalProp"), tt = /* @__PURE__ */ n((t, e, r) => cr(t, typeof e != "symbol" ? e + "" : e, r), "__publicField"), ee = class t extends D {
    static {
      n(this, "SearchFilterBuilderImpl");
    }
    constructor(e) {
      super(), tt(this, "filters"), tt(this, "isConsumed"), this.filters = e, this.isConsumed = !1;
    }
    static new() {
      return new t([]);
    }
    consume() {
      if (this.isConsumed)
        throw new Error(
          "SearchFilterBuilder has already been used! Chain your method calls like `q => q.search(...).eq(...)`."
        );
      this.isConsumed = !0;
    }
    search(e, r) {
      return c(e, 1, "search", "fieldName"), c(r, 2, "search", "query"), this.consume(), new t(
        this.filters.concat({
          type: "Search",
          fieldPath: e,
          value: r
        })
      );
    }
    eq(e, r) {
      return c(e, 1, "eq", "fieldName"), arguments.length !== 2 && c(r, 2, "search", "value"), this.consume(), new t(
        this.filters.concat({
          type: "Eq",
          fieldPath: e,
          value: w(r)
        })
      );
    }
    export() {
      return this.consume(), this.filters;
    }
  };
});

// node_modules/convex/dist/esm/server/impl/query_impl.js
function ot(t) {
  throw new Error(
    t === "consumed" ? "This query is closed and can't emit any more values." : "This query has been chained with another operator and can't be reused."
  );
}
var lr, pr, be, nt, M, $, Se = p(() => {
  "use strict";
  A();
  v();
  Xe();
  et();
  rt();
  I();
  _();
  lr = Object.defineProperty, pr = /* @__PURE__ */ n((t, e, r) => e in t ? lr(t, e, { enumerable: !0, configurable: !0, writable: !0, value: r }) : t[e] = r, "__defNormalProp"), be = /* @__PURE__ */ n((t, e, r) => pr(t, typeof e != "symbol" ? e + "" : e, r), "__publicField"), nt = 256, M = class {
    static {
      n(this, "QueryInitializerImpl");
    }
    constructor(e) {
      be(this, "tableName"), this.tableName = e;
    }
    withIndex(e, r) {
      c(e, 1, "withIndex", "indexName");
      let o = Z.new();
      return r !== void 0 && (o = r(o)), new $({
        source: {
          type: "IndexRange",
          indexName: this.tableName + "." + e,
          range: o.export(),
          order: null
        },
        operators: []
      });
    }
    withSearchIndex(e, r) {
      c(e, 1, "withSearchIndex", "indexName"), c(r, 2, "withSearchIndex", "searchFilter");
      let o = ee.new();
      return new $({
        source: {
          type: "Search",
          indexName: this.tableName + "." + e,
          filters: r(o).export()
        },
        operators: []
      });
    }
    fullTableScan() {
      return new $({
        source: {
          type: "FullTableScan",
          tableName: this.tableName,
          order: null
        },
        operators: []
      });
    }
    order(e) {
      return this.fullTableScan().order(e);
    }
    // This is internal API and should not be exposed to developers yet.
    async count() {
      let e = await l("1.0/count", {
        table: this.tableName
      });
      return y(e);
    }
    filter(e) {
      return this.fullTableScan().filter(e);
    }
    limit(e) {
      return this.fullTableScan().limit(e);
    }
    collect() {
      return this.fullTableScan().collect();
    }
    take(e) {
      return this.fullTableScan().take(e);
    }
    paginate(e) {
      return this.fullTableScan().paginate(e);
    }
    first() {
      return this.fullTableScan().first();
    }
    unique() {
      return this.fullTableScan().unique();
    }
    [Symbol.asyncIterator]() {
      return this.fullTableScan()[Symbol.asyncIterator]();
    }
  };
  n(ot, "throwClosedError");
  $ = class t {
    static {
      n(this, "QueryImpl");
    }
    constructor(e) {
      be(this, "state"), be(this, "tableNameForErrorMessages"), this.state = { type: "preparing", query: e }, e.source.type === "FullTableScan" ? this.tableNameForErrorMessages = e.source.tableName : this.tableNameForErrorMessages = e.source.indexName.split(".")[0];
    }
    takeQuery() {
      if (this.state.type !== "preparing")
        throw new Error(
          "A query can only be chained once and can't be chained after iteration begins."
        );
      let e = this.state.query;
      return this.state = { type: "closed" }, e;
    }
    startQuery() {
      if (this.state.type === "executing")
        throw new Error("Iteration can only begin on a query once.");
      (this.state.type === "closed" || this.state.type === "consumed") && ot(this.state.type);
      let e = this.state.query, { queryId: r } = Q("1.0/queryStream", { query: e, version: m });
      return this.state = { type: "executing", queryId: r }, r;
    }
    closeQuery() {
      if (this.state.type === "executing") {
        let e = this.state.queryId;
        Q("1.0/queryCleanup", { queryId: e });
      }
      this.state = { type: "consumed" };
    }
    order(e) {
      c(e, 1, "order", "order");
      let r = this.takeQuery();
      if (r.source.type === "Search")
        throw new Error(
          "Search queries must always be in relevance order. Can not set order manually."
        );
      if (r.source.order !== null)
        throw new Error("Queries may only specify order at most once");
      return r.source.order = e, new t(r);
    }
    filter(e) {
      c(e, 1, "filter", "predicate");
      let r = this.takeQuery();
      if (r.operators.length >= nt)
        throw new Error(
          `Can't construct query with more than ${nt} operators`
        );
      return r.operators.push({
        filter: f(e(Ke))
      }), new t(r);
    }
    limit(e) {
      c(e, 1, "limit", "n");
      let r = this.takeQuery();
      return r.operators.push({ limit: e }), new t(r);
    }
    [Symbol.asyncIterator]() {
      return this.startQuery(), this;
    }
    async next() {
      (this.state.type === "closed" || this.state.type === "consumed") && ot(this.state.type);
      let e = this.state.type === "preparing" ? this.startQuery() : this.state.queryId, { value: r, done: o } = await l("1.0/queryStreamNext", {
        queryId: e
      });
      return o && this.closeQuery(), { value: y(r), done: o };
    }
    return() {
      return this.closeQuery(), Promise.resolve({ done: !0, value: void 0 });
    }
    async paginate(e) {
      if (c(e, 1, "paginate", "options"), typeof e?.numItems != "number" || e.numItems < 0)
        throw new Error(
          `\`options.numItems\` must be a positive number. Received \`${e?.numItems}\`.`
        );
      let r = this.takeQuery(), o = e.numItems, s = e.cursor, i = e?.endCursor ?? null, u = e.maximumRowsRead ?? null, { page: h, isDone: b, continueCursor: j, splitCursor: re, pageStatus: ne } = await l("1.0/queryPage", {
        query: r,
        cursor: s,
        endCursor: i,
        pageSize: o,
        maximumRowsRead: u,
        maximumBytesRead: e.maximumBytesRead,
        version: m
      });
      return {
        page: h.map((At) => y(At)),
        isDone: b,
        continueCursor: j,
        splitCursor: re,
        pageStatus: ne
      };
    }
    async collect() {
      let e = [];
      for await (let r of this)
        e.push(r);
      return e;
    }
    async take(e) {
      return c(e, 1, "take", "n"), We(e, 1, "take", "n"), this.limit(e).collect();
    }
    async first() {
      let e = await this.take(1);
      return e.length === 0 ? null : e[0];
    }
    async unique() {
      let e = await this.take(2);
      if (e.length === 0)
        return null;
      if (e.length === 2)
        throw new Error(`unique() query returned more than one result from table ${this.tableNameForErrorMessages}:
 [${e[0]._id}, ${e[1]._id}, ...]`);
      return e[0];
    }
  };
});

// node_modules/convex/dist/esm/server/impl/database_impl.js
async function st(t, e) {
  if (c(t, 1, "get", "id"), typeof t != "string")
    throw new Error(
      `Invalid argument \`id\` for \`db.get\`, expected string but got '${typeof t}': ${t}`
    );
  let r = {
    id: d(t),
    isSystem: e,
    version: m
  }, o = await l("1.0/get", r);
  return y(o);
}
function Ae() {
  let t = /* @__PURE__ */ n((s = !1) => ({
    get: /* @__PURE__ */ n(async (i) => await st(i, s), "get"),
    query: /* @__PURE__ */ n((i) => new H(i, s).query(), "query"),
    normalizeId: /* @__PURE__ */ n((i, u) => {
      c(i, 1, "normalizeId", "tableName"), c(u, 2, "normalizeId", "id");
      let h = i.startsWith("_");
      if (h !== s)
        throw new Error(
          `${h ? "System" : "User"} tables can only be accessed from db.${s ? "" : "system."}normalizeId().`
        );
      let b = Q("1.0/db/normalizeId", {
        table: i,
        idString: u
      });
      return y(b).id;
    }, "normalizeId"),
    // We set the system reader on the next line
    system: null,
    table: /* @__PURE__ */ n((i) => new H(i, s), "table")
  }), "reader"), { system: e, ...r } = t(!0), o = t();
  return o.system = r, o;
}
async function it(t, e) {
  if (t.startsWith("_"))
    throw new Error("System tables (prefixed with `_`) are read-only.");
  c(t, 1, "insert", "table"), c(e, 2, "insert", "value");
  let r = await l("1.0/insert", {
    table: t,
    value: d(e)
  });
  return y(r)._id;
}
async function at(t, e) {
  c(t, 1, "patch", "id"), c(e, 2, "patch", "value"), await l("1.0/shallowMerge", {
    id: d(t),
    value: Ie(e)
  });
}
async function ut(t, e) {
  c(t, 1, "replace", "id"), c(e, 2, "replace", "value"), await l("1.0/replace", {
    id: d(t),
    value: d(e)
  });
}
async function ct(t) {
  c(t, 1, "delete", "id"), await l("1.0/remove", { id: d(t) });
}
function lt() {
  let t = Ae();
  return {
    get: t.get,
    query: t.query,
    normalizeId: t.normalizeId,
    system: t.system,
    insert: /* @__PURE__ */ n(async (e, r) => await it(e, r), "insert"),
    patch: /* @__PURE__ */ n(async (e, r) => await at(e, r), "patch"),
    replace: /* @__PURE__ */ n(async (e, r) => await ut(e, r), "replace"),
    delete: /* @__PURE__ */ n(async (e) => await ct(e), "delete"),
    table: /* @__PURE__ */ n((e) => new _e(e, !1), "table")
  };
}
var H, _e, pt = p(() => {
  "use strict";
  A();
  v();
  Se();
  I();
  _();
  q();
  n(st, "get");
  n(Ae, "setupReader");
  n(it, "insert");
  n(at, "patch");
  n(ut, "replace");
  n(ct, "delete_");
  n(lt, "setupWriter");
  H = class {
    static {
      n(this, "TableReader");
    }
    constructor(e, r) {
      this.tableName = e, this.isSystem = r;
    }
    async get(e) {
      return st(e, this.isSystem);
    }
    query() {
      let e = this.tableName.startsWith("_");
      if (e !== this.isSystem)
        throw new Error(
          `${e ? "System" : "User"} tables can only be accessed from db.${this.isSystem ? "" : "system."}query().`
        );
      return new M(this.tableName);
    }
  }, _e = class extends H {
    static {
      n(this, "TableWriter");
    }
    async insert(e) {
      return it(this.tableName, e);
    }
    async patch(e, r) {
      return at(e, r);
    }
    async replace(e, r) {
      return ut(e, r);
    }
    async delete(e) {
      return ct(e);
    }
  };
});

// node_modules/convex/dist/esm/server/impl/scheduler_impl.js
function ft() {
  return {
    runAfter: /* @__PURE__ */ n(async (t, e, r) => {
      let o = dt(t, e, r);
      return await l("1.0/schedule", o);
    }, "runAfter"),
    runAt: /* @__PURE__ */ n(async (t, e, r) => {
      let o = ht(
        t,
        e,
        r
      );
      return await l("1.0/schedule", o);
    }, "runAt"),
    cancel: /* @__PURE__ */ n(async (t) => {
      c(t, 1, "cancel", "id");
      let e = { id: d(t) };
      await l("1.0/cancel_job", e);
    }, "cancel")
  };
}
function Ce(t) {
  return {
    runAfter: /* @__PURE__ */ n(async (e, r, o) => {
      let s = {
        requestId: t,
        ...dt(e, r, o)
      };
      return await l("1.0/actions/schedule", s);
    }, "runAfter"),
    runAt: /* @__PURE__ */ n(async (e, r, o) => {
      let s = {
        requestId: t,
        ...ht(e, r, o)
      };
      return await l("1.0/actions/schedule", s);
    }, "runAt"),
    cancel: /* @__PURE__ */ n(async (e) => {
      c(e, 1, "cancel", "id");
      let r = { id: d(e) };
      return await l("1.0/actions/cancel_job", r);
    }, "cancel")
  };
}
function dt(t, e, r) {
  if (typeof t != "number")
    throw new Error("`delayMs` must be a number");
  if (!isFinite(t))
    throw new Error("`delayMs` must be a finite number");
  if (t < 0)
    throw new Error("`delayMs` must be non-negative");
  let o = S(r), s = g(e), i = (Date.now() + t) / 1e3;
  return {
    ...s,
    ts: i,
    args: d(o),
    version: m
  };
}
function ht(t, e, r) {
  let o;
  if (t instanceof Date)
    o = t.valueOf() / 1e3;
  else if (typeof t == "number")
    o = t / 1e3;
  else
    throw new Error("The invoke time must a Date or a timestamp");
  let s = g(e), i = S(r);
  return {
    ...s,
    ts: o,
    args: d(i),
    version: m
  };
}
var mt = p(() => {
  "use strict";
  A();
  _();
  v();
  z();
  I();
  E();
  n(ft, "setupMutationScheduler");
  n(Ce, "setupActionScheduler");
  n(dt, "runAfterSyscallArgs");
  n(ht, "runAtSyscallArgs");
});

// node_modules/convex/dist/esm/server/impl/storage_impl.js
function Ee(t) {
  return {
    getUrl: /* @__PURE__ */ n(async (e) => (c(e, 1, "getUrl", "storageId"), await l("1.0/storageGetUrl", {
      requestId: t,
      version: m,
      storageId: e
    })), "getUrl"),
    getMetadata: /* @__PURE__ */ n(async (e) => await l("1.0/storageGetMetadata", {
      requestId: t,
      version: m,
      storageId: e
    }), "getMetadata")
  };
}
function Pe(t) {
  let e = Ee(t);
  return {
    generateUploadUrl: /* @__PURE__ */ n(async () => await l("1.0/storageGenerateUploadUrl", {
      requestId: t,
      version: m
    }), "generateUploadUrl"),
    delete: /* @__PURE__ */ n(async (r) => {
      await l("1.0/storageDelete", {
        requestId: t,
        version: m,
        storageId: r
      });
    }, "delete"),
    getUrl: e.getUrl,
    getMetadata: e.getMetadata
  };
}
function Te(t) {
  return {
    ...Pe(t),
    store: /* @__PURE__ */ n(async (r, o) => await P("storage/storeBlob", {
      requestId: t,
      version: m,
      blob: r,
      options: o
    }), "store"),
    get: /* @__PURE__ */ n(async (r) => await P("storage/getBlob", {
      requestId: t,
      version: m,
      storageId: r
    }), "get")
  };
}
var yt = p(() => {
  "use strict";
  _();
  v();
  I();
  n(Ee, "setupStorageReader");
  n(Pe, "setupStorageWriter");
  n(Te, "setupStorageActionWriter");
});

// node_modules/convex/dist/esm/server/impl/registration_impl.js
async function xt(t, e) {
  let r = "", o = y(JSON.parse(e)), s = {
    db: lt(),
    auth: G(r),
    storage: Pe(r),
    scheduler: ft(),
    runQuery: /* @__PURE__ */ n((u, h) => Ne("query", u, h), "runQuery"),
    runMutation: /* @__PURE__ */ n((u, h) => Ne("mutation", u, h), "runMutation")
  }, i = await te(t, s, o);
  return wt(i), JSON.stringify(d(i === void 0 ? null : i));
}
function wt(t) {
  if (t instanceof M || t instanceof $)
    throw new Error(
      "Return value is a Query. Results must be retrieved with `.collect()`, `.take(n), `.unique()`, or `.first()`."
    );
}
async function te(t, e, r) {
  let o;
  try {
    o = await Promise.resolve(t(e, ...r));
  } catch (s) {
    throw fr(s);
  }
  return o;
}
function R(t, e) {
  return (r, o) => (globalThis.console.warn(
    `Convex functions should not directly call other Convex functions. Consider calling a helper function instead. e.g. \`export const foo = ${t}(...); await foo(ctx);\` is not supported. See https://docs.convex.dev/production/best-practices/#use-helper-functions-to-write-shared-code`
  ), e(r, o));
}
function fr(t) {
  if (typeof t == "object" && t !== null && Symbol.for("ConvexError") in t) {
    let e = t;
    return e.data = JSON.stringify(
      d(e.data === void 0 ? null : e.data)
    ), e.ConvexErrorSymbol = Symbol.for("ConvexError"), e;
  } else
    return t;
}
function O() {
  if (typeof window > "u" || window.__convexAllowFunctionsInBrowser)
    return;
  (Object.getOwnPropertyDescriptor(globalThis, "window")?.get?.toString().includes("[native code]") ?? !1) && console.error(
    "Convex functions should not be imported in the browser. This will throw an error in future versions of `convex`. If this is a false negative, please report it to Convex support."
  );
}
function J(t) {
  return () => {
    let e = a.any();
    return typeof t == "object" && t.args !== void 0 && (e = oe(t.args)), JSON.stringify(e.json);
  };
}
function U(t) {
  return () => {
    let e;
    return typeof t == "object" && t.returns !== void 0 && (e = oe(t.returns)), JSON.stringify(e ? e.json : null);
  };
}
async function gt(t, e) {
  let r = "", o = y(JSON.parse(e)), s = {
    db: Ae(),
    auth: G(r),
    storage: Ee(r),
    runQuery: /* @__PURE__ */ n((u, h) => Ne("query", u, h), "runQuery")
  }, i = await te(t, s, o);
  return wt(i), JSON.stringify(d(i === void 0 ? null : i));
}
async function vt(t, e, r) {
  let o = y(JSON.parse(r)), i = {
    ...ye(e),
    auth: G(e),
    scheduler: Ce(e),
    storage: Te(e),
    vectorSearch: ge(e)
  }, u = await te(t, i, o);
  return JSON.stringify(d(u === void 0 ? null : u));
}
async function gr(t, e) {
  let r = "", s = {
    ...ye(r),
    auth: G(r),
    storage: Te(r),
    scheduler: Ce(r),
    vectorSearch: ge(r)
  };
  return await te(t, s, [e]);
}
async function Ne(t, e, r) {
  let o = S(r), s = {
    udfType: t,
    args: d(o),
    ...g(e)
  }, i = await l("1.0/runUdf", s);
  return y(i);
}
var dr, hr, mr, yr, xr, wr, vr, bt = p(() => {
  "use strict";
  A();
  He();
  Ve();
  ke();
  pt();
  Se();
  mt();
  yt();
  z();
  v();
  se();
  E();
  n(xt, "invokeMutation");
  n(wt, "validateReturnValue");
  n(te, "invokeFunction");
  n(R, "dontCallDirectly");
  n(fr, "serializeConvexErrorData");
  n(O, "assertNotBrowser");
  n(J, "exportArgs");
  n(U, "exportReturns");
  dr = /* @__PURE__ */ n((t) => {
    let e = typeof t == "function" ? t : t.handler, r = R("mutation", e);
    return O(), r.isMutation = !0, r.isPublic = !0, r.invokeMutation = (o) => xt(e, o), r.exportArgs = J(t), r.exportReturns = U(t), r._handler = e, r;
  }, "mutationGeneric"), hr = /* @__PURE__ */ n((t) => {
    let e = typeof t == "function" ? t : t.handler, r = R(
      "internalMutation",
      e
    );
    return O(), r.isMutation = !0, r.isInternal = !0, r.invokeMutation = (o) => xt(e, o), r.exportArgs = J(t), r.exportReturns = U(t), r._handler = e, r;
  }, "internalMutationGeneric");
  n(gt, "invokeQuery");
  mr = /* @__PURE__ */ n((t) => {
    let e = typeof t == "function" ? t : t.handler, r = R("query", e);
    return O(), r.isQuery = !0, r.isPublic = !0, r.invokeQuery = (o) => gt(e, o), r.exportArgs = J(t), r.exportReturns = U(t), r._handler = e, r;
  }, "queryGeneric"), yr = /* @__PURE__ */ n((t) => {
    let e = typeof t == "function" ? t : t.handler, r = R("internalQuery", e);
    return O(), r.isQuery = !0, r.isInternal = !0, r.invokeQuery = (o) => gt(e, o), r.exportArgs = J(t), r.exportReturns = U(t), r._handler = e, r;
  }, "internalQueryGeneric");
  n(vt, "invokeAction");
  xr = /* @__PURE__ */ n((t) => {
    let e = typeof t == "function" ? t : t.handler, r = R("action", e);
    return O(), r.isAction = !0, r.isPublic = !0, r.invokeAction = (o, s) => vt(e, o, s), r.exportArgs = J(t), r.exportReturns = U(t), r._handler = e, r;
  }, "actionGeneric"), wr = /* @__PURE__ */ n((t) => {
    let e = typeof t == "function" ? t : t.handler, r = R("internalAction", e);
    return O(), r.isAction = !0, r.isInternal = !0, r.invokeAction = (o, s) => vt(e, o, s), r.exportArgs = J(t), r.exportReturns = U(t), r._handler = e, r;
  }, "internalActionGeneric");
  n(gr, "invokeHttpAction");
  vr = /* @__PURE__ */ n((t) => {
    let e = R("httpAction", t);
    return O(), e.isHttp = !0, e.invokeHttpAction = (r) => gr(t, r), e._handler = t, e;
  }, "httpActionGeneric");
  n(Ne, "runUdf");
});

// node_modules/convex/dist/esm/server/pagination.js
var qo, St = p(() => {
  "use strict";
  se();
  qo = a.object({
    numItems: a.number(),
    cursor: a.union(a.string(), a.null()),
    endCursor: a.optional(a.union(a.string(), a.null())),
    id: a.optional(a.number()),
    maximumRowsRead: a.optional(a.number()),
    maximumBytesRead: a.optional(a.number())
  });
});

// node_modules/convex/dist/esm/server/storage.js
var _t = p(() => {
  "use strict";
});

// node_modules/convex/dist/esm/server/index.js
var br = p(() => {
  "use strict";
  Ge();
  bt();
  St();
  ve();
  _t();
  Fe();
  Je();
  ce();
  V();
  V();
  V();
  Qe();
});

export {
  g as a,
  dr as b,
  hr as c,
  mr as d,
  yr as e,
  xr as f,
  wr as g,
  vr as h,
  Tt as i,
  Nt as j,
  Ot as k,
  Qt as l,
  Gt as m,
  de as n,
  je as o,
  br as p
};
//# sourceMappingURL=6XQQNYIR.js.map
