import {
  l as f,
  n as m
} from "./3TDUHHJO.js";
import {
  a as i
} from "./RUVYHBJQ.js";

// convex/auth.ts
m();
var s = {
  ADMIN: "admin",
  TRAINER: "trainer",
  EMPLOYEE: "employee",
  VIEWER: "viewer"
};
async function o(t) {
  let e = await t.auth.getUserIdentity();
  if (!e) {
    if (typeof process < "u" && process.env.VITEST === "true") {
      let d = {
        subject: "test-user",
        tokenIdentifier: "test://test-user",
        email: "test@example.com",
        name: "Test User"
      };
      if ("db" in t && !("scheduler" in t)) {
        let l = t, c = await l.db.query("users").withIndex("by_clerk_user_id", (r) => r.eq("clerkUserId", "test-user")).first();
        if (c)
          return {
            identity: d,
            unifiedUserId: c._id,
            user: c,
            isAdmin: c.role === s.ADMIN
          };
        let y = await l.db.query("users").filter(
          (r) => r.or(
            r.eq(r.field("email"), "test@test.com"),
            r.eq(r.field("clerkUserId"), "test-user"),
            r.eq(r.field("tokenIdentifier"), "test://basic-test-user"),
            r.eq(r.field("tokenIdentifier"), "https://test.clerk.dev/basic-test-user")
          )
        ).collect();
        if (y.length > 0) {
          let r = y[0];
          return {
            identity: {
              subject: r.clerkUserId,
              tokenIdentifier: r.tokenIdentifier,
              email: r.email,
              name: r.name
            },
            unifiedUserId: r._id,
            user: r,
            isAdmin: r.role === s.ADMIN
          };
        }
      }
      return {
        identity: d,
        unifiedUserId: "test-user-id",
        user: {
          _id: "test-user-id",
          _creationTime: Date.now(),
          clerkUserId: "test-user",
          tokenIdentifier: "test://test-user",
          email: "test@example.com",
          emailVerified: !0,
          name: "Test User",
          firstName: "Test",
          lastName: "User",
          imageUrl: void 0,
          employeeId: void 0,
          department: void 0,
          position: void 0,
          role: s.ADMIN,
          isActive: !0,
          joinDate: Date.now(),
          lastLoginAt: Date.now()
        },
        isAdmin: !0
      };
    }
    throw new f("\u8A8D\u8A3C\u304C\u5FC5\u8981\u3067\u3059");
  }
  if ("scheduler" in t && "runQuery" in t)
    throw new f("ActionContext\u5185\u3067\u306E\u8A8D\u8A3C\u306F\u5BFE\u5FDC\u3057\u3066\u3044\u307E\u305B\u3093\u3002\u30D5\u30ED\u30F3\u30C8\u30A8\u30F3\u30C9\u3067\u8A8D\u8A3C\u3092\u5B8C\u4E86\u3057\u3066\u304F\u3060\u3055\u3044\u3002");
  let n = t, a = await n.db.query("users").withIndex("by_clerk_user_id", (u) => u.eq("clerkUserId", e.subject)).first();
  if (!a) {
    let u = await n.db.query("users").withIndex("by_token", (d) => d.eq("tokenIdentifier", e.tokenIdentifier)).first();
    if (!u)
      throw new f("\u30E6\u30FC\u30B6\u30FC\u304C\u898B\u3064\u304B\u308A\u307E\u305B\u3093");
    return {
      identity: e,
      unifiedUserId: u._id,
      user: u,
      isAdmin: u.role === s.ADMIN
    };
  }
  return {
    identity: e,
    unifiedUserId: a._id,
    user: a,
    isAdmin: a.role === s.ADMIN
  };
}
i(o, "requireUser");
async function I(t) {
  let e = await o(t);
  if (t.auth === void 0)
    throw new Error("\u8A8D\u8A3C\u30B3\u30F3\u30C6\u30AD\u30B9\u30C8\u304C\u7121\u52B9\u3067\u3059");
  if ("runQuery" in t) {
    if ((e.user?.role || "employee") !== s.ADMIN)
      throw new Error("\u7BA1\u7406\u8005\u6A29\u9650\u304C\u5FC5\u8981\u3067\u3059");
    return e;
  }
  if (e.user.role !== s.ADMIN)
    throw new Error("\u7BA1\u7406\u8005\u6A29\u9650\u304C\u5FC5\u8981\u3067\u3059");
  return e;
}
i(I, "requireAdmin");
async function h(t) {
  let e = await o(t);
  if (t.auth === void 0)
    throw new Error("\u8A8D\u8A3C\u30B3\u30F3\u30C6\u30AD\u30B9\u30C8\u304C\u7121\u52B9\u3067\u3059");
  if ("runQuery" in t) {
    let n = e.user?.role || "employee";
    if (n !== s.ADMIN && n !== s.TRAINER)
      throw new Error("\u30C8\u30EC\u30FC\u30CA\u30FC\u6A29\u9650\u304C\u5FC5\u8981\u3067\u3059");
    return e;
  }
  if (e.user.role !== s.ADMIN && e.user.role !== s.TRAINER)
    throw new Error("\u30C8\u30EC\u30FC\u30CA\u30FC\u6A29\u9650\u304C\u5FC5\u8981\u3067\u3059");
  return e;
}
i(h, "requireTrainer");
async function x(t, e) {
  let n = await o(t);
  if (n.user.role !== s.ADMIN && n.user._id !== e)
    throw new Error("\u3053\u306E\u30EA\u30BD\u30FC\u30B9\u306B\u30A2\u30AF\u30BB\u30B9\u3059\u308B\u6A29\u9650\u304C\u3042\u308A\u307E\u305B\u3093");
  return n;
}
i(x, "requireResourceAccess");
async function p(t, e) {
  let n = await o(t);
  if (n.user.role !== s.ADMIN && n.user._id !== e)
    throw new Error("\u6A29\u9650\u304C\u3042\u308A\u307E\u305B\u3093");
  return n;
}
i(p, "requireOwnershipOrAdmin");
async function A(t) {
  return await o(t);
}
i(A, "requireEnhancedAuth");
async function C(t) {
  return await I(t);
}
i(C, "requireCriticalAdminAuth");
async function E(t) {
  try {
    return {
      success: !0,
      ...await o(t)
    };
  } catch (e) {
    return {
      success: !1,
      message: e instanceof Error ? e.message : "\u8A8D\u8A3C\u30A8\u30E9\u30FC"
    };
  }
}
i(E, "checkAuth");
async function R(t) {
  try {
    let e = await o(t);
    return {
      success: !0,
      identity: e.identity,
      user: e.user
    };
  } catch (e) {
    return {
      success: !1,
      message: e instanceof Error ? e.message : "\u8A8D\u8A3C\u30A8\u30E9\u30FC"
    };
  }
}
i(R, "checkUser");

export {
  s as a,
  o as b,
  I as c,
  h as d,
  x as e,
  p as f,
  A as g,
  C as h,
  E as i,
  R as j
};
//# sourceMappingURL=SZVQRWFS.js.map
