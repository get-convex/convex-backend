import {
  a as p,
  c as pt,
  e as mt
} from "./RUVYHBJQ.js";

// node_modules/@jridgewell/sourcemap-codec/dist/sourcemap-codec.umd.js
var V = pt((U, Z) => {
  (function(g, t) {
    typeof U == "object" && typeof Z < "u" ? t(U) : typeof define == "function" && define.amd ? define(["exports"], t) : (g = typeof globalThis < "u" ? globalThis : g || self, t(g.sourcemapCodec = {}));
  })(U, function(g) {
    "use strict";
    let n = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/", i = new Uint8Array(64), s = new Uint8Array(128);
    for (let c = 0; c < n.length; c++) {
      let u = n.charCodeAt(c);
      i[c] = u, s[u] = c;
    }
    function o(c, u) {
      let r = 0, a = 0, d = 0;
      do {
        let S = c.next();
        d = s[S], r |= (d & 31) << a, a += 5;
      } while (d & 32);
      let m = r & 1;
      return r >>>= 1, m && (r = -2147483648 | -r), u + r;
    }
    p(o, "decodeInteger");
    function h(c, u, r) {
      let a = u - r;
      a = a < 0 ? -a << 1 | 1 : a << 1;
      do {
        let d = a & 31;
        a >>>= 5, a > 0 && (d |= 32), c.write(i[d]);
      } while (a > 0);
      return u;
    }
    p(h, "encodeInteger");
    function l(c, u) {
      return c.pos >= u ? !1 : c.peek() !== 44;
    }
    p(l, "hasMoreVlq");
    let f = 1024 * 16, y = typeof TextDecoder < "u" ? /* @__PURE__ */ new TextDecoder() : typeof Buffer < "u" ? {
      decode(c) {
        return Buffer.from(c.buffer, c.byteOffset, c.byteLength).toString();
      }
    } : {
      decode(c) {
        let u = "";
        for (let r = 0; r < c.length; r++)
          u += String.fromCharCode(c[r]);
        return u;
      }
    };
    class I {
      static {
        p(this, "StringWriter");
      }
      constructor() {
        this.pos = 0, this.out = "", this.buffer = new Uint8Array(f);
      }
      write(u) {
        let { buffer: r } = this;
        r[this.pos++] = u, this.pos === f && (this.out += y.decode(r), this.pos = 0);
      }
      flush() {
        let { buffer: u, out: r, pos: a } = this;
        return a > 0 ? r + y.decode(u.subarray(0, a)) : r;
      }
    }
    class z {
      static {
        p(this, "StringReader");
      }
      constructor(u) {
        this.pos = 0, this.buffer = u;
      }
      next() {
        return this.buffer.charCodeAt(this.pos++);
      }
      peek() {
        return this.buffer.charCodeAt(this.pos);
      }
      indexOf(u) {
        let { buffer: r, pos: a } = this, d = r.indexOf(u, a);
        return d === -1 ? r.length : d;
      }
    }
    let W = [];
    function st(c) {
      let { length: u } = c, r = new z(c), a = [], d = [], m = 0;
      for (; r.pos < u; r.pos++) {
        m = o(r, m);
        let S = o(r, 0);
        if (!l(r, u)) {
          let L = d.pop();
          L[2] = m, L[3] = S;
          continue;
        }
        let b = o(r, 0), C = o(r, 0) & 1 ? [m, S, 0, 0, b, o(r, 0)] : [m, S, 0, 0, b], v = W;
        if (l(r, u)) {
          v = [];
          do {
            let L = o(r, 0);
            v.push(L);
          } while (l(r, u));
        }
        C.vars = v, a.push(C), d.push(C);
      }
      return a;
    }
    p(st, "decodeOriginalScopes");
    function ot(c) {
      let u = new I();
      for (let r = 0; r < c.length; )
        r = Y(c, r, u, [0]);
      return u.flush();
    }
    p(ot, "encodeOriginalScopes");
    function Y(c, u, r, a) {
      let d = c[u], { 0: m, 1: S, 2: b, 3: E, 4: x, vars: C } = d;
      u > 0 && r.write(44), a[0] = h(r, m, a[0]), h(r, S, 0), h(r, x, 0);
      let v = d.length === 6 ? 1 : 0;
      h(r, v, 0), d.length === 6 && h(r, d[5], 0);
      for (let L of C)
        h(r, L, 0);
      for (u++; u < c.length; ) {
        let L = c[u], { 0: w, 1: k } = L;
        if (w > b || w === b && k >= E)
          break;
        u = Y(c, u, r, a);
      }
      return r.write(44), a[0] = h(r, b, a[0]), h(r, E, 0), u;
    }
    p(Y, "_encodeOriginalScopes");
    function ht(c) {
      let { length: u } = c, r = new z(c), a = [], d = [], m = 0, S = 0, b = 0, E = 0, x = 0, C = 0, v = 0, L = 0;
      do {
        let w = r.indexOf(";"), k = 0;
        for (; r.pos < w; r.pos++) {
          if (k = o(r, k), !l(r, w)) {
            let R = d.pop();
            R[2] = m, R[3] = k;
            continue;
          }
          let O = o(r, 0), B = O & 1, j = O & 2, $ = O & 4, X = null, H = W, _;
          if (B) {
            let R = o(r, S);
            b = o(r, S === R ? b : 0), S = R, _ = [m, k, 0, 0, R, b];
          } else
            _ = [m, k, 0, 0];
          if (_.isScope = !!$, j) {
            let R = E, N = x;
            E = o(r, E);
            let T = R === E;
            x = o(r, T ? x : 0), C = o(r, T && N === x ? C : 0), X = [E, x, C];
          }
          if (_.callsite = X, l(r, w)) {
            H = [];
            do {
              v = m, L = k;
              let R = o(r, 0), N;
              if (R < -1) {
                N = [[o(r, 0)]];
                for (let T = -1; T > R; T--) {
                  let dt = v;
                  v = o(r, v), L = o(r, v === dt ? L : 0);
                  let gt = o(r, 0);
                  N.push([gt, v, L]);
                }
              } else
                N = [[R]];
              H.push(N);
            } while (l(r, w));
          }
          _.bindings = H, a.push(_), d.push(_);
        }
        m++, r.pos = w + 1;
      } while (r.pos < u);
      return a;
    }
    p(ht, "decodeGeneratedRanges");
    function lt(c) {
      if (c.length === 0)
        return "";
      let u = new I();
      for (let r = 0; r < c.length; )
        r = K(c, r, u, [0, 0, 0, 0, 0, 0, 0]);
      return u.flush();
    }
    p(lt, "encodeGeneratedRanges");
    function K(c, u, r, a) {
      let d = c[u], { 0: m, 1: S, 2: b, 3: E, isScope: x, callsite: C, bindings: v } = d;
      a[0] < m ? (Q(r, a[0], m), a[0] = m, a[1] = 0) : u > 0 && r.write(44), a[1] = h(r, d[1], a[1]);
      let L = (d.length === 6 ? 1 : 0) | (C ? 2 : 0) | (x ? 4 : 0);
      if (h(r, L, 0), d.length === 6) {
        let { 4: w, 5: k } = d;
        w !== a[2] && (a[3] = 0), a[2] = h(r, w, a[2]), a[3] = h(r, k, a[3]);
      }
      if (C) {
        let { 0: w, 1: k, 2: O } = d.callsite;
        w !== a[4] ? (a[5] = 0, a[6] = 0) : k !== a[5] && (a[6] = 0), a[4] = h(r, w, a[4]), a[5] = h(r, k, a[5]), a[6] = h(r, O, a[6]);
      }
      if (v)
        for (let w of v) {
          w.length > 1 && h(r, -w.length, 0);
          let k = w[0][0];
          h(r, k, 0);
          let O = m, B = S;
          for (let j = 1; j < w.length; j++) {
            let $ = w[j];
            O = h(r, $[1], O), B = h(r, $[2], B), h(r, $[0], 0);
          }
        }
      for (u++; u < c.length; ) {
        let w = c[u], { 0: k, 1: O } = w;
        if (k > b || k === b && O >= E)
          break;
        u = K(c, u, r, a);
      }
      return a[0] < b ? (Q(r, a[0], b), a[0] = b, a[1] = 0) : r.write(44), a[1] = h(r, E, a[1]), u;
    }
    p(K, "_encodeGeneratedRanges");
    function Q(c, u, r) {
      do
        c.write(59);
      while (++u < r);
    }
    p(Q, "catchupLine");
    function ut(c) {
      let { length: u } = c, r = new z(c), a = [], d = 0, m = 0, S = 0, b = 0, E = 0;
      do {
        let x = r.indexOf(";"), C = [], v = !0, L = 0;
        for (d = 0; r.pos < x; ) {
          let w;
          d = o(r, d), d < L && (v = !1), L = d, l(r, x) ? (m = o(r, m), S = o(r, S), b = o(r, b), l(r, x) ? (E = o(r, E), w = [d, m, S, b, E]) : w = [d, m, S, b]) : w = [d], C.push(w), r.pos++;
        }
        v || at(C), a.push(C), r.pos = x + 1;
      } while (r.pos <= u);
      return a;
    }
    p(ut, "decode");
    function at(c) {
      c.sort(ct);
    }
    p(at, "sort");
    function ct(c, u) {
      return c[0] - u[0];
    }
    p(ct, "sortComparator");
    function ft(c) {
      let u = new I(), r = 0, a = 0, d = 0, m = 0;
      for (let S = 0; S < c.length; S++) {
        let b = c[S];
        if (S > 0 && u.write(59), b.length === 0)
          continue;
        let E = 0;
        for (let x = 0; x < b.length; x++) {
          let C = b[x];
          x > 0 && u.write(44), E = h(u, C[0], E), C.length !== 1 && (r = h(u, C[1], r), a = h(u, C[2], a), d = h(u, C[3], d), C.length !== 4 && (m = h(u, C[4], m)));
        }
      }
      return u.flush();
    }
    p(ft, "encode"), g.decode = ut, g.decodeGeneratedRanges = ht, g.decodeOriginalScopes = st, g.encode = ft, g.encodeGeneratedRanges = lt, g.encodeOriginalScopes = ot, Object.defineProperty(g, "__esModule", { value: !0 });
  });
});

// node_modules/magic-string/dist/magic-string.es.mjs
var nt = mt(V(), 1);
var M = class g {
  static {
    p(this, "BitSet");
  }
  constructor(t) {
    this.bits = t instanceof g ? t.bits.slice() : [];
  }
  add(t) {
    this.bits[t >> 5] |= 1 << (t & 31);
  }
  has(t) {
    return !!(this.bits[t >> 5] & 1 << (t & 31));
  }
}, P = class g {
  static {
    p(this, "Chunk");
  }
  constructor(t, e, n) {
    this.start = t, this.end = e, this.original = n, this.intro = "", this.outro = "", this.content = n, this.storeName = !1, this.edited = !1, this.previous = null, this.next = null;
  }
  appendLeft(t) {
    this.outro += t;
  }
  appendRight(t) {
    this.intro = this.intro + t;
  }
  clone() {
    let t = new g(this.start, this.end, this.original);
    return t.intro = this.intro, t.outro = this.outro, t.content = this.content, t.storeName = this.storeName, t.edited = this.edited, t;
  }
  contains(t) {
    return this.start < t && t < this.end;
  }
  eachNext(t) {
    let e = this;
    for (; e; )
      t(e), e = e.next;
  }
  eachPrevious(t) {
    let e = this;
    for (; e; )
      t(e), e = e.previous;
  }
  edit(t, e, n) {
    return this.content = t, n || (this.intro = "", this.outro = ""), this.storeName = e, this.edited = !0, this;
  }
  prependLeft(t) {
    this.outro = t + this.outro;
  }
  prependRight(t) {
    this.intro = t + this.intro;
  }
  reset() {
    this.intro = "", this.outro = "", this.edited && (this.content = this.original, this.storeName = !1, this.edited = !1);
  }
  split(t) {
    let e = t - this.start, n = this.original.slice(0, e), i = this.original.slice(e);
    this.original = n;
    let s = new g(t, this.end, i);
    return s.outro = this.outro, this.outro = "", this.end = t, this.edited ? (s.edit("", !1), this.content = "") : this.content = n, s.next = this.next, s.next && (s.next.previous = s), s.previous = this, this.next = s, s;
  }
  toString() {
    return this.intro + this.content + this.outro;
  }
  trimEnd(t) {
    if (this.outro = this.outro.replace(t, ""), this.outro.length) return !0;
    let e = this.content.replace(t, "");
    if (e.length)
      return e !== this.content && (this.split(this.start + e.length).edit("", void 0, !0), this.edited && this.edit(e, this.storeName, !0)), !0;
    if (this.edit("", void 0, !0), this.intro = this.intro.replace(t, ""), this.intro.length) return !0;
  }
  trimStart(t) {
    if (this.intro = this.intro.replace(t, ""), this.intro.length) return !0;
    let e = this.content.replace(t, "");
    if (e.length) {
      if (e !== this.content) {
        let n = this.split(this.end - e.length);
        this.edited && n.edit(e, this.storeName, !0), this.edit("", void 0, !0);
      }
      return !0;
    } else if (this.edit("", void 0, !0), this.outro = this.outro.replace(t, ""), this.outro.length) return !0;
  }
};
function wt() {
  return typeof globalThis < "u" && typeof globalThis.btoa == "function" ? (g) => globalThis.btoa(unescape(encodeURIComponent(g))) : typeof Buffer == "function" ? (g) => Buffer.from(g, "utf-8").toString("base64") : () => {
    throw new Error("Unsupported environment: `window.btoa` or `Buffer` should be supported.");
  };
}
p(wt, "getBtoa");
var bt = /* @__PURE__ */ wt(), D = class {
  static {
    p(this, "SourceMap");
  }
  constructor(t) {
    this.version = 3, this.file = t.file, this.sources = t.sources, this.sourcesContent = t.sourcesContent, this.names = t.names, this.mappings = (0, nt.encode)(t.mappings), typeof t.x_google_ignoreList < "u" && (this.x_google_ignoreList = t.x_google_ignoreList), typeof t.debugId < "u" && (this.debugId = t.debugId);
  }
  toString() {
    return JSON.stringify(this);
  }
  toUrl() {
    return "data:application/json;charset=utf-8;base64," + bt(this.toString());
  }
};
function Ct(g) {
  let t = g.split(`
`), e = t.filter((s) => /^\t+/.test(s)), n = t.filter((s) => /^ {2,}/.test(s));
  if (e.length === 0 && n.length === 0)
    return null;
  if (e.length >= n.length)
    return "	";
  let i = n.reduce((s, o) => {
    let h = /^ +/.exec(o)[0].length;
    return Math.min(h, s);
  }, 1 / 0);
  return new Array(i + 1).join(" ");
}
p(Ct, "guessIndent");
function it(g, t) {
  let e = g.split(/[/\\]/), n = t.split(/[/\\]/);
  for (e.pop(); e[0] === n[0]; )
    e.shift(), n.shift();
  if (e.length) {
    let i = e.length;
    for (; i--; ) e[i] = "..";
  }
  return e.concat(n).join("/");
}
p(it, "getRelativePath");
var St = Object.prototype.toString;
function rt(g) {
  return St.call(g) === "[object Object]";
}
p(rt, "isObject");
function J(g) {
  let t = g.split(`
`), e = [];
  for (let n = 0, i = 0; n < t.length; n++)
    e.push(i), i += t[n].length + 1;
  return /* @__PURE__ */ p(function(i) {
    let s = 0, o = e.length;
    for (; s < o; ) {
      let f = s + o >> 1;
      i < e[f] ? o = f : s = f + 1;
    }
    let h = s - 1, l = i - e[h];
    return { line: h, column: l };
  }, "locate");
}
p(J, "getLocator");
var yt = /\w/, F = class {
  static {
    p(this, "Mappings");
  }
  constructor(t) {
    this.hires = t, this.generatedCodeLine = 0, this.generatedCodeColumn = 0, this.raw = [], this.rawSegments = this.raw[this.generatedCodeLine] = [], this.pending = null;
  }
  addEdit(t, e, n, i) {
    if (e.length) {
      let s = e.length - 1, o = e.indexOf(`
`, 0), h = -1;
      for (; o >= 0 && s > o; ) {
        let f = [this.generatedCodeColumn, t, n.line, n.column];
        i >= 0 && f.push(i), this.rawSegments.push(f), this.generatedCodeLine += 1, this.raw[this.generatedCodeLine] = this.rawSegments = [], this.generatedCodeColumn = 0, h = o, o = e.indexOf(`
`, o + 1);
      }
      let l = [this.generatedCodeColumn, t, n.line, n.column];
      i >= 0 && l.push(i), this.rawSegments.push(l), this.advance(e.slice(h + 1));
    } else this.pending && (this.rawSegments.push(this.pending), this.advance(e));
    this.pending = null;
  }
  addUneditedChunk(t, e, n, i, s) {
    let o = e.start, h = !0, l = !1;
    for (; o < e.end; ) {
      if (n[o] === `
`)
        i.line += 1, i.column = 0, this.generatedCodeLine += 1, this.raw[this.generatedCodeLine] = this.rawSegments = [], this.generatedCodeColumn = 0, h = !0, l = !1;
      else {
        if (this.hires || h || s.has(o)) {
          let f = [this.generatedCodeColumn, t, i.line, i.column];
          this.hires === "boundary" ? yt.test(n[o]) ? l || (this.rawSegments.push(f), l = !0) : (this.rawSegments.push(f), l = !1) : this.rawSegments.push(f);
        }
        i.column += 1, this.generatedCodeColumn += 1, h = !1;
      }
      o += 1;
    }
    this.pending = null;
  }
  advance(t) {
    if (!t) return;
    let e = t.split(`
`);
    if (e.length > 1) {
      for (let n = 0; n < e.length - 1; n++)
        this.generatedCodeLine++, this.raw[this.generatedCodeLine] = this.rawSegments = [];
      this.generatedCodeColumn = 0;
    }
    this.generatedCodeColumn += e[e.length - 1].length;
  }
}, q = `
`, A = {
  insertLeft: !1,
  insertRight: !1,
  storeName: !1
}, G = class g {
  static {
    p(this, "MagicString");
  }
  constructor(t, e = {}) {
    let n = new P(0, t.length, t);
    Object.defineProperties(this, {
      original: { writable: !0, value: t },
      outro: { writable: !0, value: "" },
      intro: { writable: !0, value: "" },
      firstChunk: { writable: !0, value: n },
      lastChunk: { writable: !0, value: n },
      lastSearchedChunk: { writable: !0, value: n },
      byStart: { writable: !0, value: {} },
      byEnd: { writable: !0, value: {} },
      filename: { writable: !0, value: e.filename },
      indentExclusionRanges: { writable: !0, value: e.indentExclusionRanges },
      sourcemapLocations: { writable: !0, value: new M() },
      storedNames: { writable: !0, value: {} },
      indentStr: { writable: !0, value: void 0 },
      ignoreList: { writable: !0, value: e.ignoreList },
      offset: { writable: !0, value: e.offset || 0 }
    }), this.byStart[0] = n, this.byEnd[t.length] = n;
  }
  addSourcemapLocation(t) {
    this.sourcemapLocations.add(t);
  }
  append(t) {
    if (typeof t != "string") throw new TypeError("outro content must be a string");
    return this.outro += t, this;
  }
  appendLeft(t, e) {
    if (t = t + this.offset, typeof e != "string") throw new TypeError("inserted content must be a string");
    this._split(t);
    let n = this.byEnd[t];
    return n ? n.appendLeft(e) : this.intro += e, this;
  }
  appendRight(t, e) {
    if (t = t + this.offset, typeof e != "string") throw new TypeError("inserted content must be a string");
    this._split(t);
    let n = this.byStart[t];
    return n ? n.appendRight(e) : this.outro += e, this;
  }
  clone() {
    let t = new g(this.original, { filename: this.filename, offset: this.offset }), e = this.firstChunk, n = t.firstChunk = t.lastSearchedChunk = e.clone();
    for (; e; ) {
      t.byStart[n.start] = n, t.byEnd[n.end] = n;
      let i = e.next, s = i && i.clone();
      s && (n.next = s, s.previous = n, n = s), e = i;
    }
    return t.lastChunk = n, this.indentExclusionRanges && (t.indentExclusionRanges = this.indentExclusionRanges.slice()), t.sourcemapLocations = new M(this.sourcemapLocations), t.intro = this.intro, t.outro = this.outro, t;
  }
  generateDecodedMap(t) {
    t = t || {};
    let e = 0, n = Object.keys(this.storedNames), i = new F(t.hires), s = J(this.original);
    return this.intro && i.advance(this.intro), this.firstChunk.eachNext((o) => {
      let h = s(o.start);
      o.intro.length && i.advance(o.intro), o.edited ? i.addEdit(
        e,
        o.content,
        h,
        o.storeName ? n.indexOf(o.original) : -1
      ) : i.addUneditedChunk(e, o, this.original, h, this.sourcemapLocations), o.outro.length && i.advance(o.outro);
    }), {
      file: t.file ? t.file.split(/[/\\]/).pop() : void 0,
      sources: [
        t.source ? it(t.file || "", t.source) : t.file || ""
      ],
      sourcesContent: t.includeContent ? [this.original] : void 0,
      names: n,
      mappings: i.raw,
      x_google_ignoreList: this.ignoreList ? [e] : void 0
    };
  }
  generateMap(t) {
    return new D(this.generateDecodedMap(t));
  }
  _ensureindentStr() {
    this.indentStr === void 0 && (this.indentStr = Ct(this.original));
  }
  _getRawIndentString() {
    return this._ensureindentStr(), this.indentStr;
  }
  getIndentString() {
    return this._ensureindentStr(), this.indentStr === null ? "	" : this.indentStr;
  }
  indent(t, e) {
    let n = /^[^\r\n]/gm;
    if (rt(t) && (e = t, t = void 0), t === void 0 && (this._ensureindentStr(), t = this.indentStr || "	"), t === "") return this;
    e = e || {};
    let i = {};
    e.exclude && (typeof e.exclude[0] == "number" ? [e.exclude] : e.exclude).forEach((y) => {
      for (let I = y[0]; I < y[1]; I += 1)
        i[I] = !0;
    });
    let s = e.indentStart !== !1, o = /* @__PURE__ */ p((f) => s ? `${t}${f}` : (s = !0, f), "replacer");
    this.intro = this.intro.replace(n, o);
    let h = 0, l = this.firstChunk;
    for (; l; ) {
      let f = l.end;
      if (l.edited)
        i[h] || (l.content = l.content.replace(n, o), l.content.length && (s = l.content[l.content.length - 1] === `
`));
      else
        for (h = l.start; h < f; ) {
          if (!i[h]) {
            let y = this.original[h];
            y === `
` ? s = !0 : y !== "\r" && s && (s = !1, h === l.start || (this._splitChunk(l, h), l = l.next), l.prependRight(t));
          }
          h += 1;
        }
      h = l.end, l = l.next;
    }
    return this.outro = this.outro.replace(n, o), this;
  }
  insert() {
    throw new Error(
      "magicString.insert(...) is deprecated. Use prependRight(...) or appendLeft(...)"
    );
  }
  insertLeft(t, e) {
    return A.insertLeft || (console.warn(
      "magicString.insertLeft(...) is deprecated. Use magicString.appendLeft(...) instead"
    ), A.insertLeft = !0), this.appendLeft(t, e);
  }
  insertRight(t, e) {
    return A.insertRight || (console.warn(
      "magicString.insertRight(...) is deprecated. Use magicString.prependRight(...) instead"
    ), A.insertRight = !0), this.prependRight(t, e);
  }
  move(t, e, n) {
    if (t = t + this.offset, e = e + this.offset, n = n + this.offset, n >= t && n <= e) throw new Error("Cannot move a selection inside itself");
    this._split(t), this._split(e), this._split(n);
    let i = this.byStart[t], s = this.byEnd[e], o = i.previous, h = s.next, l = this.byStart[n];
    if (!l && s === this.lastChunk) return this;
    let f = l ? l.previous : this.lastChunk;
    return o && (o.next = h), h && (h.previous = o), f && (f.next = i), l && (l.previous = s), i.previous || (this.firstChunk = s.next), s.next || (this.lastChunk = i.previous, this.lastChunk.next = null), i.previous = f, s.next = l || null, f || (this.firstChunk = i), l || (this.lastChunk = s), this;
  }
  overwrite(t, e, n, i) {
    return i = i || {}, this.update(t, e, n, { ...i, overwrite: !i.contentOnly });
  }
  update(t, e, n, i) {
    if (t = t + this.offset, e = e + this.offset, typeof n != "string") throw new TypeError("replacement content must be a string");
    if (this.original.length !== 0) {
      for (; t < 0; ) t += this.original.length;
      for (; e < 0; ) e += this.original.length;
    }
    if (e > this.original.length) throw new Error("end is out of bounds");
    if (t === e)
      throw new Error(
        "Cannot overwrite a zero-length range \u2013 use appendLeft or prependRight instead"
      );
    this._split(t), this._split(e), i === !0 && (A.storeName || (console.warn(
      "The final argument to magicString.overwrite(...) should be an options object. See https://github.com/rich-harris/magic-string"
    ), A.storeName = !0), i = { storeName: !0 });
    let s = i !== void 0 ? i.storeName : !1, o = i !== void 0 ? i.overwrite : !1;
    if (s) {
      let f = this.original.slice(t, e);
      Object.defineProperty(this.storedNames, f, {
        writable: !0,
        value: !0,
        enumerable: !0
      });
    }
    let h = this.byStart[t], l = this.byEnd[e];
    if (h) {
      let f = h;
      for (; f !== l; ) {
        if (f.next !== this.byStart[f.end])
          throw new Error("Cannot overwrite across a split point");
        f = f.next, f.edit("", !1);
      }
      h.edit(n, s, !o);
    } else {
      let f = new P(t, e, "").edit(n, s);
      l.next = f, f.previous = l;
    }
    return this;
  }
  prepend(t) {
    if (typeof t != "string") throw new TypeError("outro content must be a string");
    return this.intro = t + this.intro, this;
  }
  prependLeft(t, e) {
    if (t = t + this.offset, typeof e != "string") throw new TypeError("inserted content must be a string");
    this._split(t);
    let n = this.byEnd[t];
    return n ? n.prependLeft(e) : this.intro = e + this.intro, this;
  }
  prependRight(t, e) {
    if (t = t + this.offset, typeof e != "string") throw new TypeError("inserted content must be a string");
    this._split(t);
    let n = this.byStart[t];
    return n ? n.prependRight(e) : this.outro = e + this.outro, this;
  }
  remove(t, e) {
    if (t = t + this.offset, e = e + this.offset, this.original.length !== 0) {
      for (; t < 0; ) t += this.original.length;
      for (; e < 0; ) e += this.original.length;
    }
    if (t === e) return this;
    if (t < 0 || e > this.original.length) throw new Error("Character is out of bounds");
    if (t > e) throw new Error("end must be greater than start");
    this._split(t), this._split(e);
    let n = this.byStart[t];
    for (; n; )
      n.intro = "", n.outro = "", n.edit(""), n = e > n.end ? this.byStart[n.end] : null;
    return this;
  }
  reset(t, e) {
    if (t = t + this.offset, e = e + this.offset, this.original.length !== 0) {
      for (; t < 0; ) t += this.original.length;
      for (; e < 0; ) e += this.original.length;
    }
    if (t === e) return this;
    if (t < 0 || e > this.original.length) throw new Error("Character is out of bounds");
    if (t > e) throw new Error("end must be greater than start");
    this._split(t), this._split(e);
    let n = this.byStart[t];
    for (; n; )
      n.reset(), n = e > n.end ? this.byStart[n.end] : null;
    return this;
  }
  lastChar() {
    if (this.outro.length) return this.outro[this.outro.length - 1];
    let t = this.lastChunk;
    do {
      if (t.outro.length) return t.outro[t.outro.length - 1];
      if (t.content.length) return t.content[t.content.length - 1];
      if (t.intro.length) return t.intro[t.intro.length - 1];
    } while (t = t.previous);
    return this.intro.length ? this.intro[this.intro.length - 1] : "";
  }
  lastLine() {
    let t = this.outro.lastIndexOf(q);
    if (t !== -1) return this.outro.substr(t + 1);
    let e = this.outro, n = this.lastChunk;
    do {
      if (n.outro.length > 0) {
        if (t = n.outro.lastIndexOf(q), t !== -1) return n.outro.substr(t + 1) + e;
        e = n.outro + e;
      }
      if (n.content.length > 0) {
        if (t = n.content.lastIndexOf(q), t !== -1) return n.content.substr(t + 1) + e;
        e = n.content + e;
      }
      if (n.intro.length > 0) {
        if (t = n.intro.lastIndexOf(q), t !== -1) return n.intro.substr(t + 1) + e;
        e = n.intro + e;
      }
    } while (n = n.previous);
    return t = this.intro.lastIndexOf(q), t !== -1 ? this.intro.substr(t + 1) + e : this.intro + e;
  }
  slice(t = 0, e = this.original.length - this.offset) {
    if (t = t + this.offset, e = e + this.offset, this.original.length !== 0) {
      for (; t < 0; ) t += this.original.length;
      for (; e < 0; ) e += this.original.length;
    }
    let n = "", i = this.firstChunk;
    for (; i && (i.start > t || i.end <= t); ) {
      if (i.start < e && i.end >= e)
        return n;
      i = i.next;
    }
    if (i && i.edited && i.start !== t)
      throw new Error(`Cannot use replaced character ${t} as slice start anchor.`);
    let s = i;
    for (; i; ) {
      i.intro && (s !== i || i.start === t) && (n += i.intro);
      let o = i.start < e && i.end >= e;
      if (o && i.edited && i.end !== e)
        throw new Error(`Cannot use replaced character ${e} as slice end anchor.`);
      let h = s === i ? t - i.start : 0, l = o ? i.content.length + e - i.end : i.content.length;
      if (n += i.content.slice(h, l), i.outro && (!o || i.end === e) && (n += i.outro), o)
        break;
      i = i.next;
    }
    return n;
  }
  // TODO deprecate this? not really very useful
  snip(t, e) {
    let n = this.clone();
    return n.remove(0, t), n.remove(e, n.original.length), n;
  }
  _split(t) {
    if (this.byStart[t] || this.byEnd[t]) return;
    let e = this.lastSearchedChunk, n = t > e.end;
    for (; e; ) {
      if (e.contains(t)) return this._splitChunk(e, t);
      e = n ? this.byStart[e.end] : this.byEnd[e.start];
    }
  }
  _splitChunk(t, e) {
    if (t.edited && t.content.length) {
      let i = J(this.original)(e);
      throw new Error(
        `Cannot split a chunk that has already been edited (${i.line}:${i.column} \u2013 "${t.original}")`
      );
    }
    let n = t.split(e);
    return this.byEnd[e] = t, this.byStart[e] = n, this.byEnd[n.end] = n, t === this.lastChunk && (this.lastChunk = n), this.lastSearchedChunk = t, !0;
  }
  toString() {
    let t = this.intro, e = this.firstChunk;
    for (; e; )
      t += e.toString(), e = e.next;
    return t + this.outro;
  }
  isEmpty() {
    let t = this.firstChunk;
    do
      if (t.intro.length && t.intro.trim() || t.content.length && t.content.trim() || t.outro.length && t.outro.trim())
        return !1;
    while (t = t.next);
    return !0;
  }
  length() {
    let t = this.firstChunk, e = 0;
    do
      e += t.intro.length + t.content.length + t.outro.length;
    while (t = t.next);
    return e;
  }
  trimLines() {
    return this.trim("[\\r\\n]");
  }
  trim(t) {
    return this.trimStart(t).trimEnd(t);
  }
  trimEndAborted(t) {
    let e = new RegExp((t || "\\s") + "+$");
    if (this.outro = this.outro.replace(e, ""), this.outro.length) return !0;
    let n = this.lastChunk;
    do {
      let i = n.end, s = n.trimEnd(e);
      if (n.end !== i && (this.lastChunk === n && (this.lastChunk = n.next), this.byEnd[n.end] = n, this.byStart[n.next.start] = n.next, this.byEnd[n.next.end] = n.next), s) return !0;
      n = n.previous;
    } while (n);
    return !1;
  }
  trimEnd(t) {
    return this.trimEndAborted(t), this;
  }
  trimStartAborted(t) {
    let e = new RegExp("^" + (t || "\\s") + "+");
    if (this.intro = this.intro.replace(e, ""), this.intro.length) return !0;
    let n = this.firstChunk;
    do {
      let i = n.end, s = n.trimStart(e);
      if (n.end !== i && (n === this.lastChunk && (this.lastChunk = n.next), this.byEnd[n.end] = n, this.byStart[n.next.start] = n.next, this.byEnd[n.next.end] = n.next), s) return !0;
      n = n.next;
    } while (n);
    return !1;
  }
  trimStart(t) {
    return this.trimStartAborted(t), this;
  }
  hasChanged() {
    return this.original !== this.toString();
  }
  _replaceRegexp(t, e) {
    function n(s, o) {
      return typeof e == "string" ? e.replace(/\$(\$|&|\d+)/g, (h, l) => l === "$" ? "$" : l === "&" ? s[0] : +l < s.length ? s[+l] : `$${l}`) : e(...s, s.index, o, s.groups);
    }
    p(n, "getReplacement");
    function i(s, o) {
      let h, l = [];
      for (; h = s.exec(o); )
        l.push(h);
      return l;
    }
    if (p(i, "matchAll"), t.global)
      i(t, this.original).forEach((o) => {
        if (o.index != null) {
          let h = n(o, this.original);
          h !== o[0] && this.overwrite(o.index, o.index + o[0].length, h);
        }
      });
    else {
      let s = this.original.match(t);
      if (s && s.index != null) {
        let o = n(s, this.original);
        o !== s[0] && this.overwrite(s.index, s.index + s[0].length, o);
      }
    }
    return this;
  }
  _replaceString(t, e) {
    let { original: n } = this, i = n.indexOf(t);
    return i !== -1 && this.overwrite(i, i + t.length, e), this;
  }
  replace(t, e) {
    return typeof t == "string" ? this._replaceString(t, e) : this._replaceRegexp(t, e);
  }
  _replaceAllString(t, e) {
    let { original: n } = this, i = t.length;
    for (let s = n.indexOf(t); s !== -1; s = n.indexOf(t, s + i))
      n.slice(s, s + i) !== e && this.overwrite(s, s + i, e);
    return this;
  }
  replaceAll(t, e) {
    if (typeof t == "string")
      return this._replaceAllString(t, e);
    if (!t.global)
      throw new TypeError(
        "MagicString.prototype.replaceAll called with a non-global RegExp argument"
      );
    return this._replaceRegexp(t, e);
  }
}, tt = Object.prototype.hasOwnProperty, et = class g {
  static {
    p(this, "Bundle");
  }
  constructor(t = {}) {
    this.intro = t.intro || "", this.separator = t.separator !== void 0 ? t.separator : `
`, this.sources = [], this.uniqueSources = [], this.uniqueSourceIndexByFilename = {};
  }
  addSource(t) {
    if (t instanceof G)
      return this.addSource({
        content: t,
        filename: t.filename,
        separator: this.separator
      });
    if (!rt(t) || !t.content)
      throw new Error(
        "bundle.addSource() takes an object with a `content` property, which should be an instance of MagicString, and an optional `filename`"
      );
    if (["filename", "ignoreList", "indentExclusionRanges", "separator"].forEach((e) => {
      tt.call(t, e) || (t[e] = t.content[e]);
    }), t.separator === void 0 && (t.separator = this.separator), t.filename)
      if (!tt.call(this.uniqueSourceIndexByFilename, t.filename))
        this.uniqueSourceIndexByFilename[t.filename] = this.uniqueSources.length, this.uniqueSources.push({ filename: t.filename, content: t.content.original });
      else {
        let e = this.uniqueSources[this.uniqueSourceIndexByFilename[t.filename]];
        if (t.content.original !== e.content)
          throw new Error(`Illegal source: same filename (${t.filename}), different contents`);
      }
    return this.sources.push(t), this;
  }
  append(t, e) {
    return this.addSource({
      content: new G(t),
      separator: e && e.separator || ""
    }), this;
  }
  clone() {
    let t = new g({
      intro: this.intro,
      separator: this.separator
    });
    return this.sources.forEach((e) => {
      t.addSource({
        filename: e.filename,
        content: e.content.clone(),
        separator: e.separator
      });
    }), t;
  }
  generateDecodedMap(t = {}) {
    let e = [], n;
    this.sources.forEach((s) => {
      Object.keys(s.content.storedNames).forEach((o) => {
        ~e.indexOf(o) || e.push(o);
      });
    });
    let i = new F(t.hires);
    return this.intro && i.advance(this.intro), this.sources.forEach((s, o) => {
      o > 0 && i.advance(this.separator);
      let h = s.filename ? this.uniqueSourceIndexByFilename[s.filename] : -1, l = s.content, f = J(l.original);
      l.intro && i.advance(l.intro), l.firstChunk.eachNext((y) => {
        let I = f(y.start);
        y.intro.length && i.advance(y.intro), s.filename ? y.edited ? i.addEdit(
          h,
          y.content,
          I,
          y.storeName ? e.indexOf(y.original) : -1
        ) : i.addUneditedChunk(
          h,
          y,
          l.original,
          I,
          l.sourcemapLocations
        ) : i.advance(y.content), y.outro.length && i.advance(y.outro);
      }), l.outro && i.advance(l.outro), s.ignoreList && h !== -1 && (n === void 0 && (n = []), n.push(h));
    }), {
      file: t.file ? t.file.split(/[/\\]/).pop() : void 0,
      sources: this.uniqueSources.map((s) => t.file ? it(t.file, s.filename) : s.filename),
      sourcesContent: this.uniqueSources.map((s) => t.includeContent ? s.content : null),
      names: e,
      mappings: i.raw,
      x_google_ignoreList: n
    };
  }
  generateMap(t) {
    return new D(this.generateDecodedMap(t));
  }
  getIndentString() {
    let t = {};
    return this.sources.forEach((e) => {
      let n = e.content._getRawIndentString();
      n !== null && (t[n] || (t[n] = 0), t[n] += 1);
    }), Object.keys(t).sort((e, n) => t[e] - t[n])[0] || "	";
  }
  indent(t) {
    if (arguments.length || (t = this.getIndentString()), t === "") return this;
    let e = !this.intro || this.intro.slice(-1) === `
`;
    return this.sources.forEach((n, i) => {
      let s = n.separator !== void 0 ? n.separator : this.separator, o = e || i > 0 && /\r?\n$/.test(s);
      n.content.indent(t, {
        exclude: n.indentExclusionRanges,
        indentStart: o
        //: trailingNewline || /\r?\n$/.test( separator )  //true///\r?\n/.test( separator )
      }), e = n.content.lastChar() === `
`;
    }), this.intro && (this.intro = t + this.intro.replace(/^[^\n]/gm, (n, i) => i > 0 ? t + n : n)), this;
  }
  prepend(t) {
    return this.intro = t + this.intro, this;
  }
  toString() {
    let t = this.sources.map((e, n) => {
      let i = e.separator !== void 0 ? e.separator : this.separator;
      return (n > 0 ? i : "") + e.content.toString();
    }).join("");
    return this.intro + t;
  }
  isEmpty() {
    return !(this.intro.length && this.intro.trim() || this.sources.some((t) => !t.content.isEmpty()));
  }
  length() {
    return this.sources.reduce(
      (t, e) => t + e.content.length(),
      this.intro.length
    );
  }
  trimLines() {
    return this.trim("[\\r\\n]");
  }
  trim(t) {
    return this.trimStart(t).trimEnd(t);
  }
  trimStart(t) {
    let e = new RegExp("^" + (t || "\\s") + "+");
    if (this.intro = this.intro.replace(e, ""), !this.intro) {
      let n, i = 0;
      do
        if (n = this.sources[i++], !n)
          break;
      while (!n.content.trimStartAborted(t));
    }
    return this;
  }
  trimEnd(t) {
    let e = new RegExp((t || "\\s") + "+$"), n, i = this.sources.length - 1;
    do
      if (n = this.sources[i--], !n) {
        this.intro = this.intro.replace(e, "");
        break;
      }
    while (!n.content.trimEndAborted(t));
    return this;
  }
};
export {
  et as Bundle,
  D as SourceMap,
  G as default
};
//# sourceMappingURL=Z7S7OD3X.js.map
