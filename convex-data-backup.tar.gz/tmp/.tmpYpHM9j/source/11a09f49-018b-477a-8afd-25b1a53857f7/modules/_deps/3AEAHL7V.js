import {
  n as t,
  p as n
} from "./6XQQNYIR.js";
import {
  j as e,
  n as i
} from "./3TDUHHJO.js";

// convex/schema/video.ts
n();
i();
var a = {
  videos: t({
    userId: e.id("users"),
    title: e.string(),
    description: e.optional(e.string()),
    type: e.optional(
      e.union(
        e.literal("M&A\u30ED\u30FC\u30EB\u30D7\u30EC\u30A4"),
        e.literal("AD\u7DE0\u7D50\u63D0\u6848"),
        e.literal("\u4F01\u696D\u6982\u8981\u66F8\u63D0\u6848"),
        e.literal("\u8B72\u6E21\u67B6\u96FB")
      )
    ),
    url: e.string(),
    thumbnailUrl: e.optional(e.string()),
    durationSeconds: e.optional(e.number()),
    labels: e.optional(e.array(e.string())),
    fileSize: e.optional(e.number()),
    contentType: e.optional(e.string()),
    processingStatus: e.optional(
      e.union(
        e.literal("pending"),
        e.literal("processing"),
        e.literal("completed"),
        e.literal("failed")
      )
    ),
    errorMessage: e.optional(e.string()),
    // 追加フィールド
    case_summary_status: e.optional(
      e.union(
        e.literal("pending"),
        e.literal("processing"),
        e.literal("completed"),
        e.literal("failed")
      )
    ),
    case_summary_generated_at: e.optional(e.string()),
    meeting_summary: e.optional(
      e.object({
        attendees: e.string(),
        businessContent: e.string(),
        companyOverview: e.string(),
        maRelatedInfo: e.string(),
        ownerInfo: e.string(),
        stockPriceExpectation: e.string(),
        transferIntention: e.string(),
        financialContent: e.string(),
        intervieweeInfo: e.string(),
        personalCharacteristics: e.string(),
        brokerMeetingHistory: e.string(),
        shareholderInfo: e.string(),
        nextActions: e.string(),
        todos: e.string(),
        confidenceLevel: e.string(),
        dataQuality: e.object({
          clarity: e.number(),
          completeness: e.number()
        }),
        clientSide: e.string(),
        ourSide: e.string()
      })
    ),
    meeting_summary_status: e.optional(
      e.union(
        e.literal("pending"),
        e.literal("processing"),
        e.literal("completed"),
        e.literal("failed")
      )
    ),
    meeting_summary_generated_at: e.optional(e.string()),
    transcript_with_speaker: e.optional(e.string()),
    upload_session_id: e.optional(e.string()),
    is_group_primary: e.optional(e.boolean()),
    file_count: e.optional(e.number())
  }).index("by_user_id", ["userId"]).index("by_processing_status", ["processingStatus"]).index("by_type", ["type"]).index("by_user_type", ["userId", "type"]).index("by_type_status", ["type", "processingStatus"]).searchIndex("search_title", {
    searchField: "title",
    filterFields: ["type", "userId"]
  }).searchIndex("search_description", {
    searchField: "description",
    filterFields: ["type", "userId"]
  }),
  transcriptions: t({
    resourceType: e.union(e.literal("video"), e.literal("training_content")),
    resourceId: e.string(),
    videoId: e.optional(e.id("videos")),
    text: e.string(),
    segments: e.optional(
      e.array(
        e.object({
          start: e.number(),
          end: e.number(),
          text: e.string(),
          speaker: e.optional(e.string()),
          confidence: e.optional(e.number())
        })
      )
    ),
    formattedText: e.optional(e.string()),
    status: e.union(
      e.literal("pending"),
      e.literal("processing"),
      e.literal("completed"),
      e.literal("failed")
    ),
    originalFileUrl: e.optional(e.string()),
    originalFileType: e.optional(e.string()),
    durationSeconds: e.optional(e.number()),
    enableSpeakerDiarization: e.optional(e.boolean()),
    enableAiEvaluation: e.optional(e.boolean()),
    language: e.optional(e.string()),
    confidenceScore: e.optional(e.number()),
    // 修正: number型に変更
    processingDurationMs: e.optional(e.number()),
    errorMessage: e.optional(e.string()),
    retryCount: e.optional(e.number()),
    createdAt: e.optional(e.number()),
    updatedAt: e.optional(e.number())
  }).index("by_resource", ["resourceType", "resourceId"]).index("by_video_id", ["videoId"]).index("by_status", ["status"]).index("by_created_at", ["createdAt"]).index("by_updated_at", ["updatedAt"]).index("by_resource_status", ["resourceType", "status"]).index("by_video_status", ["videoId", "status"]).index("by_status_updated", ["status", "updatedAt"])
};

export {
  a
};
//# sourceMappingURL=3AEAHL7V.js.map
