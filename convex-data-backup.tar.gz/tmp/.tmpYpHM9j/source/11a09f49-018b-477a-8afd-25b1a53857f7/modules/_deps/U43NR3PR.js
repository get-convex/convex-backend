import {
  n as i,
  p as a
} from "./6XQQNYIR.js";
import {
  j as e,
  n as t
} from "./3TDUHHJO.js";

// convex/schema/encryption.ts
a();
t();
var l = {
  // 暗号化キー管理
  encryptionKeys: i({
    key_id: e.string(),
    key_alias: e.string(),
    key_type: e.union(e.literal("aes-256-gcm"), e.literal("rsa-2048"), e.literal("ecdsa-p256")),
    purpose: e.union(
      e.literal("data_encryption"),
      e.literal("file_encryption"),
      e.literal("api_signing"),
      e.literal("jwt_signing")
    ),
    encrypted_key: e.string(),
    // 暗号化されたキー
    iv: e.optional(e.string()),
    // 初期化ベクター
    salt: e.optional(e.string()),
    // ソルト
    key_derivation: e.optional(
      e.object({
        algorithm: e.string(),
        iterations: e.number(),
        memory: e.optional(e.number()),
        parallelism: e.optional(e.number())
      })
    ),
    status: e.union(e.literal("active"), e.literal("deprecated"), e.literal("revoked")),
    created_by: e.id("users"),
    expires_at: e.optional(e.number()),
    rotation_schedule: e.optional(
      e.object({
        interval_days: e.number(),
        next_rotation: e.number(),
        auto_rotate: e.boolean()
      })
    ),
    usage_count: e.optional(e.number()),
    last_used_at: e.optional(e.number())
  }).index("by_key_id", ["key_id"]).index("by_alias", ["key_alias"]).index("by_purpose", ["purpose"]).index("by_status", ["status"]).index("by_created_by", ["created_by"]).index("by_expires_at", ["expires_at"]),
  // 暗号化データ管理
  encryptedData: i({
    data_id: e.string(),
    data_type: e.union(
      e.literal("user_data"),
      e.literal("file_content"),
      e.literal("api_credentials"),
      e.literal("config_data"),
      e.literal("sensitive_logs")
    ),
    encrypted_content: e.string(),
    key_id: e.string(),
    // 使用した暗号化キーのID
    algorithm: e.string(),
    iv: e.string(),
    auth_tag: e.optional(e.string()),
    // GCMモード用
    compression: e.optional(
      e.object({
        algorithm: e.string(),
        original_size: e.number(),
        compressed_size: e.number()
      })
    ),
    metadata: e.optional(
      e.object({
        content_type: e.optional(e.string()),
        encoding: e.optional(e.string()),
        checksum: e.optional(e.string()),
        custom_attributes: e.optional(e.record(e.string(), e.string()))
      })
    ),
    access_control: e.object({
      owner_id: e.id("users"),
      access_level: e.union(e.literal("private"), e.literal("shared"), e.literal("public")),
      allowed_users: e.optional(e.array(e.id("users"))),
      allowed_roles: e.optional(e.array(e.string()))
    }),
    retention_policy: e.optional(
      e.object({
        expires_at: e.optional(e.number()),
        auto_delete: e.boolean(),
        backup_required: e.boolean()
      })
    ),
    audit_trail: e.optional(
      e.object({
        created_at: e.number(),
        created_by: e.id("users"),
        last_accessed_at: e.optional(e.number()),
        last_accessed_by: e.optional(e.id("users")),
        access_count: e.number()
      })
    )
  }).index("by_data_id", ["data_id"]).index("by_data_type", ["data_type"]).index("by_key_id", ["key_id"]).index("by_owner", ["access_control.owner_id"]).index("by_access_level", ["access_control.access_level"]),
  // セキュリティイベントログ
  securityEventLogs: i({
    event_id: e.string(),
    event_type: e.union(
      e.literal("key_created"),
      e.literal("key_rotated"),
      e.literal("key_revoked"),
      e.literal("data_encrypted"),
      e.literal("data_decrypted"),
      e.literal("unauthorized_access"),
      e.literal("encryption_failure"),
      e.literal("key_exposure_risk"),
      e.literal("audit_log_access")
    ),
    severity: e.union(
      e.literal("low"),
      e.literal("medium"),
      e.literal("high"),
      e.literal("critical")
    ),
    user_id: e.optional(e.id("users")),
    resource_id: e.optional(e.string()),
    resource_type: e.optional(e.string()),
    event_data: e.object({
      description: e.string(),
      details: e.optional(e.record(e.string(), e.any())),
      ip_address: e.optional(e.string()),
      user_agent: e.optional(e.string()),
      session_id: e.optional(e.string()),
      request_id: e.optional(e.string())
    }),
    detection_method: e.optional(
      e.union(
        e.literal("system_monitor"),
        e.literal("user_report"),
        e.literal("automated_scan"),
        e.literal("manual_audit")
      )
    ),
    response_actions: e.optional(
      e.array(
        e.object({
          action: e.string(),
          taken_by: e.optional(e.id("users")),
          taken_at: e.number(),
          result: e.optional(e.string())
        })
      )
    ),
    investigation_status: e.optional(
      e.union(
        e.literal("open"),
        e.literal("investigating"),
        e.literal("resolved"),
        e.literal("false_positive")
      )
    ),
    tags: e.optional(e.array(e.string()))
  }).index("by_event_type", ["event_type"]).index("by_severity", ["severity"]).index("by_user_id", ["user_id"]).index("by_resource", ["resource_type", "resource_id"]).index("by_investigation_status", ["investigation_status"]),
  // データ分類・ラベリング
  dataClassifications: i({
    classification_id: e.string(),
    data_id: e.string(),
    data_type: e.string(),
    classification_level: e.union(
      e.literal("public"),
      e.literal("internal"),
      e.literal("confidential"),
      e.literal("restricted"),
      e.literal("top_secret")
    ),
    sensitivity_labels: e.array(
      e.union(
        e.literal("pii"),
        e.literal("financial"),
        e.literal("medical"),
        e.literal("legal"),
        e.literal("intellectual_property"),
        e.literal("business_critical")
      )
    ),
    compliance_requirements: e.optional(
      e.array(
        e.union(
          e.literal("gdpr"),
          e.literal("hipaa"),
          e.literal("pci_dss"),
          e.literal("sox"),
          e.literal("iso27001"),
          e.literal("custom")
        )
      )
    ),
    encryption_required: e.boolean(),
    backup_required: e.boolean(),
    audit_required: e.boolean(),
    retention_period_days: e.optional(e.number()),
    geographic_restrictions: e.optional(e.array(e.string())),
    classified_by: e.id("users"),
    approved_by: e.optional(e.id("users")),
    review_schedule: e.optional(
      e.object({
        interval_days: e.number(),
        next_review: e.number()
      })
    ),
    override_reason: e.optional(e.string())
  }).index("by_data_id", ["data_id"]).index("by_classification_level", ["classification_level"]).index("by_classified_by", ["classified_by"]).index("by_encryption_required", ["encryption_required"]),
  // セキュリティポリシー
  securityPolicies: i({
    policy_id: e.string(),
    policy_name: e.string(),
    policy_type: e.union(
      e.literal("encryption"),
      e.literal("access_control"),
      e.literal("data_retention"),
      e.literal("audit_logging"),
      e.literal("incident_response")
    ),
    version: e.string(),
    status: e.union(
      e.literal("draft"),
      e.literal("active"),
      e.literal("deprecated"),
      e.literal("archived")
    ),
    policy_document: e.object({
      description: e.string(),
      scope: e.string(),
      requirements: e.array(
        e.object({
          requirement_id: e.string(),
          description: e.string(),
          mandatory: e.boolean(),
          implementation_guide: e.optional(e.string())
        })
      ),
      exceptions: e.optional(
        e.array(
          e.object({
            condition: e.string(),
            alternative_control: e.string(),
            approval_required: e.boolean()
          })
        )
      )
    }),
    created_by: e.id("users"),
    approved_by: e.optional(e.id("users")),
    effective_date: e.number(),
    review_date: e.optional(e.number()),
    compliance_mapping: e.optional(
      e.record(
        e.string(),
        // コンプライアンス標準名
        e.array(e.string())
        // 対応する要求事項
      )
    )
  }).index("by_policy_type", ["policy_type"]).index("by_status", ["status"]).index("by_created_by", ["created_by"]).index("by_effective_date", ["effective_date"])
};

export {
  l as a
};
//# sourceMappingURL=U43NR3PR.js.map
