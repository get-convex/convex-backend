import {
  c as C,
  d as E,
  e as c,
  g as x,
  j as A
} from "./ISHYXYGN.js";
import {
  b as U,
  c as m
} from "./OQFRUWLA.js";
import {
  a as L,
  e as $
} from "./SZVQRWFS.js";
import {
  a as D,
  b as w
} from "./6HNJFR7B.js";
import {
  a as b,
  b as j,
  c as q
} from "./75JH2J25.js";
import {
  j as e,
  n as O
} from "./3TDUHHJO.js";
import {
  a as v
} from "./RUVYHBJQ.js";

// convex/videos/core.ts
O();
var ee = b({
  args: {
    page: e.optional(e.number()),
    limit: e.optional(e.number()),
    type: e.optional(e.union(e.string(), e.array(e.string()))),
    sort: e.optional(e.string()),
    order: e.optional(e.string()),
    showAll: e.optional(e.boolean()),
    person: e.optional(e.string()),
    scoreRange: e.optional(e.string()),
    company: e.optional(e.string()),
    searchQuery: e.optional(e.string())
  },
  returns: e.object({
    success: e.boolean(),
    data: e.array(
      e.object({
        _id: e.id("videos"),
        title: e.string(),
        date: e.string(),
        duration: e.string(),
        type: e.optional(e.string()),
        description: e.optional(e.string()),
        url: e.string(),
        thumbnail_url: e.optional(e.string()),
        user_id: e.id("users"),
        username: e.optional(e.string()),
        status: e.string(),
        views: e.number(),
        comments: e.number(),
        likes: e.number(),
        labels: e.optional(e.array(e.string())),
        // 面談者情報
        intervieweeName: e.optional(e.string()),
        uploaderName: e.optional(e.string()),
        // グループ情報
        upload_session_id: e.optional(e.string()),
        is_group_primary: e.optional(e.boolean()),
        file_count: e.number()
      })
    ),
    error: e.optional(e.string()),
    meta: e.object({
      pagination: e.object({
        page: e.number(),
        limit: e.number(),
        total: e.number(),
        totalPages: e.number()
      }),
      timestamp: e.optional(e.number()),
      version: e.optional(e.string()),
      errorCode: e.optional(e.string()),
      statusCode: e.optional(e.number()),
      details: e.optional(e.any()),
      correlationId: e.optional(e.string())
    })
  }),
  handler: /* @__PURE__ */ v(async (i, t) => {
    try {
      let { user: n } = await w(i), s;
      if (t.searchQuery) {
        let o = m(t.searchQuery, {
          type: "content",
          maxLength: 200,
          minLength: 1
        });
        if (!o.isValid)
          throw new Error(`Invalid search query: ${o.error}`);
        s = o.processed;
      }
      let a;
      if (t.type)
        if (Array.isArray(t.type)) {
          let o = [];
          for (let r of t.type) {
            let u = m(r, { maxLength: 50 });
            if (!u.isValid)
              throw new Error(`Invalid type: ${u.error}`);
            o.push(u.processed);
          }
          a = o;
        } else {
          let o = m(t.type, { maxLength: 50 });
          if (!o.isValid)
            throw new Error(`Invalid type: ${o.error}`);
          a = o.processed;
        }
      if (t.person) {
        let o = m(t.person, { type: "name", maxLength: 100 });
        if (!o.isValid)
          throw new Error(`Invalid person: ${o.error}`);
      }
      if (t.company) {
        let o = m(t.company, { type: "name", maxLength: 200 });
        if (!o.isValid)
          throw new Error(`Invalid company: ${o.error}`);
      }
      let d = t.page && t.page > 0 ? t.page : 1, p = t.limit && t.limit > 0 && t.limit <= 100 ? t.limit : 12, y = t.order === "asc" ? "asc" : "desc", _ = (d - 1) * p, l;
      if (s)
        l = await i.db.query("videos").withSearchIndex("search_title", (o) => {
          let r = o.search("title", s);
          return a ? Array.isArray(a) ? r.eq("type", a[0]) : r.eq("type", a) : r;
        }).collect();
      else {
        let o = i.db.query("videos");
        a ? Array.isArray(a) ? l = await o.filter((r) => r.eq(r.field("type"), a[0])).order(y).collect() : l = await o.filter((r) => r.eq(r.field("type"), a)).order(y).collect() : l = await o.order(y).collect();
      }
      s && l.sort((o, r) => {
        let u = o._creationTime, h = r._creationTime;
        return y === "desc" ? h - u : u - h;
      });
      let f = /* @__PURE__ */ new Map(), N = [];
      for (let o of l)
        if (o.upload_session_id) {
          let r = o.upload_session_id;
          (!f.get(r) || o.is_group_primary) && f.set(r, o);
        } else
          N.push(o);
      let M = [...Array.from(f.values()), ...N], V = M.slice(_, _ + p), I = M.length;
      if (_ >= I && I > 0) {
        let o = A(d, p, I), r = E([], o);
        return {
          success: r.success,
          data: r.data || [],
          error: r.error,
          meta: {
            pagination: r.meta?.pagination || o,
            timestamp: r.meta?.timestamp,
            version: r.meta?.version,
            errorCode: r.meta?.errorCode,
            statusCode: r.meta?.statusCode,
            details: r.meta?.details,
            correlationId: r.meta?.correlationId
          }
        };
      }
      if (I === 0) {
        let o = A(1, p, 0), r = E([], o);
        return {
          success: r.success,
          data: r.data || [],
          error: r.error,
          meta: {
            pagination: r.meta?.pagination || o,
            timestamp: r.meta?.timestamp,
            version: r.meta?.version,
            errorCode: r.meta?.errorCode,
            statusCode: r.meta?.statusCode,
            details: r.meta?.details,
            correlationId: r.meta?.correlationId
          }
        };
      }
      let P = Array.from(new Set(V.map((o) => o.user_id))), Q = await Promise.all(
        P.map(async (o) => {
          try {
            let r = await i.db.get(o);
            return { id: o, user: r };
          } catch (r) {
            return console.warn("\u30E6\u30FC\u30B6\u30FC\u60C5\u5831\u53D6\u5F97\u30A8\u30E9\u30FC:", r), { id: o, user: null };
          }
        })
      ), T = new Map(
        Q.map(({ id: o, user: r }) => [
          o,
          r && r.name || "\u4E0D\u660E\u306A\u30E6\u30FC\u30B6\u30FC"
        ])
      ), z = await Promise.all(
        V.map(async (o) => {
          try {
            let r = await i.db.query("transcriptions").withIndex("by_resource", (u) => u.eq("resource_type", "video").eq("resource_id", o._id)).first();
            return { videoId: o._id, transcription: r };
          } catch (r) {
            return console.warn("\u8A55\u4FA1\u30B9\u30C6\u30FC\u30BF\u30B9\u53D6\u5F97\u30A8\u30E9\u30FC:", r), { videoId: o._id, transcription: null };
          }
        })
      ), B = new Map(
        z.map(({ videoId: o, transcription: r }) => {
          if (!r)
            return [o, "\u51E6\u7406\u6E96\u5099\u4E2D"];
          let u = r.evaluation_status || "pending", h = r.speaker_analysis_status || "pending";
          return u === "completed" && r.evaluation ? [o, "\u8A55\u4FA1\u6E08\u307F"] : u === "processing" ? [o, "\u8A55\u4FA1\u51E6\u7406\u4E2D"] : h === "processing" ? [o, "\u8A71\u8005\u60C5\u5831\u89E3\u6790\u4E2D"] : r.status === "completed" && h === "pending" ? [o, "\u8A71\u8005\u60C5\u5831\u89E3\u6790\u4E2D"] : r.status === "processing" ? [o, "\u6587\u5B57\u8D77\u3053\u3057\u4E2D"] : r.status === "pending" ? [o, "\u6587\u5B57\u8D77\u3053\u3057\u4E2D"] : r.status === "failed" ? [o, "\u51E6\u7406\u5931\u6557"] : u === "failed" ? [o, "\u8A55\u4FA1\u5931\u6557"] : [o, "\u51E6\u7406\u6E96\u5099\u4E2D"];
        })
      ), S = /* @__PURE__ */ new Map(), R = Array.from(
        new Set(
          V.map((o) => o.upload_session_id).filter((o) => !!o)
        )
      );
      if (R.length > 0)
        try {
          let o = await i.db.query("videos").collect(), r = /* @__PURE__ */ new Map();
          o.forEach((u) => {
            if (u.upload_session_id && R.includes(u.upload_session_id)) {
              let h = r.get(u.upload_session_id) || 0;
              r.set(u.upload_session_id, h + 1);
            }
          }), R.forEach((u) => {
            S.set(u, r.get(u) || 1);
          });
        } catch (o) {
          console.warn("\u30BB\u30C3\u30B7\u30E7\u30F3\u30D5\u30A1\u30A4\u30EB\u6570\u53D6\u5F97\u30A8\u30E9\u30FC:", o), R.forEach((r) => {
            S.set(r, 1);
          });
        }
      let F = V.map((o) => {
        let r = o.upload_session_id && S.get(o.upload_session_id) || 1;
        return {
          _id: o._id,
          title: o.title,
          date: new Date(o._creationTime).toISOString().split("T")[0],
          duration: o.duration_seconds ? `${Math.floor(o.duration_seconds / 60)}:${(o.duration_seconds % 60).toString().padStart(2, "0")}` : "00:00",
          type: o.type,
          description: o.description,
          url: o.url,
          thumbnail_url: o.thumbnail_url,
          user_id: o.user_id,
          username: T.get(o.user_id),
          status: B.get(o._id) || "\u8A55\u4FA1\u767B\u9332\u5F85\u3061",
          views: 0,
          comments: 0,
          likes: 0,
          labels: o.labels,
          // 面談者情報
          intervieweeName: o.intervieweeName,
          uploaderName: T.get(o.user_id),
          // グループ情報
          upload_session_id: o.upload_session_id,
          is_group_primary: o.is_group_primary,
          file_count: r
        };
      }), k = A(d, p, I), g = E(F, k);
      return {
        success: g.success,
        data: g.data || [],
        error: g.error,
        meta: {
          pagination: g.meta?.pagination || k,
          timestamp: g.meta?.timestamp,
          version: g.meta?.version,
          errorCode: g.meta?.errorCode,
          statusCode: g.meta?.statusCode,
          details: g.meta?.details,
          correlationId: g.meta?.correlationId
        }
      };
    } catch (n) {
      console.error("\u52D5\u753B\u4E00\u89A7\u53D6\u5F97\u30A8\u30E9\u30FC:", n);
      let s = n instanceof Error ? n : new Error(String(n));
      throw new Error(U(s, "\u52D5\u753B\u4E00\u89A7\u306E\u53D6\u5F97"));
    }
  }, "handler")
}), G = b({
  args: {
    videoId: e.id("videos")
  },
  returns: e.object({
    success: e.boolean(),
    data: e.optional(e.any()),
    error: e.optional(e.string()),
    meta: e.optional(e.object({
      timestamp: e.optional(e.number()),
      version: e.optional(e.string()),
      errorCode: e.optional(e.string()),
      statusCode: e.optional(e.number()),
      details: e.optional(e.any()),
      correlationId: e.optional(e.string())
    }))
  }),
  handler: /* @__PURE__ */ v(async (i, t) => {
    try {
      let { user: n } = await w(i), s = await i.db.get(t.videoId);
      if (!s)
        return c("\u52D5\u753B\u304C\u898B\u3064\u304B\u308A\u307E\u305B\u3093");
      try {
        n.role === L.ADMIN || n.role === L.TRAINER || await $(i, s.user_id);
      } catch {
        return c("\u52D5\u753B\u3078\u306E\u30A2\u30AF\u30BB\u30B9\u6A29\u9650\u304C\u3042\u308A\u307E\u305B\u3093");
      }
      return C(s);
    } catch (n) {
      return console.error("\u52D5\u753B\u53D6\u5F97\u30A8\u30E9\u30FC:", n), c("\u52D5\u753B\u306E\u53D6\u5F97\u4E2D\u306B\u30A8\u30E9\u30FC\u304C\u767A\u751F\u3057\u307E\u3057\u305F");
    }
  }, "handler")
}), te = q({
  args: {
    title: e.string(),
    description: e.optional(e.string()),
    type: e.optional(e.string()),
    url: e.string(),
    thumbnail_url: e.optional(e.string()),
    duration_seconds: e.optional(e.number()),
    labels: e.optional(e.array(e.string())),
    // 面談者情報
    intervieweeName: e.optional(e.string()),
    // グループ機能
    upload_session_id: e.optional(e.string()),
    is_group_primary: e.optional(e.boolean()),
    group_order: e.optional(e.number())
  },
  returns: e.object({
    success: e.boolean(),
    data: e.optional(e.any()),
    error: e.optional(e.string()),
    message: e.optional(e.string())
  }),
  handler: /* @__PURE__ */ v(async (i, t) => {
    try {
      let { user: n } = await w(i), s = m(t.title, {
        type: "title",
        maxLength: 200,
        minLength: 1
      });
      if (!s.isValid)
        return c(`\u30BF\u30A4\u30C8\u30EB\u304C\u7121\u52B9\u3067\u3059: ${s.error}`);
      let a = m(t.url, { type: "url" });
      if (!a.isValid)
        return c(`URL\u304C\u7121\u52B9\u3067\u3059: ${a.error}`);
      let d;
      if (t.description) {
        let f = m(t.description, {
          type: "description",
          maxLength: 2e3
        });
        if (!f.isValid)
          return c(`\u8AAC\u660E\u304C\u7121\u52B9\u3067\u3059: ${f.error}`);
        d = f.processed;
      }
      let p;
      if (t.type) {
        let f = m(t.type, {
          type: "name",
          maxLength: 100
        });
        f.isValid && (p = f.processed);
      }
      let y;
      if (t.thumbnail_url) {
        let f = m(t.thumbnail_url, { type: "url" });
        f.isValid && (y = f.processed);
      }
      if (t.duration_seconds !== void 0 && (t.duration_seconds < 0 || t.duration_seconds > 86400))
        return c("\u52D5\u753B\u306E\u9577\u3055\u304C\u7121\u52B9\u3067\u3059\uFF080\u79D2\u301C24\u6642\u9593\u4EE5\u5185\uFF09");
      let _ = {
        title: s.processed,
        url: a.processed,
        user_id: n._id,
        // グループ情報
        upload_session_id: t.upload_session_id,
        is_group_primary: t.is_group_primary,
        group_order: t.group_order
      };
      d !== void 0 && (_.description = d), p !== void 0 && (_.type = p), y !== void 0 && (_.thumbnail_url = y), t.duration_seconds !== void 0 && (_.duration_seconds = t.duration_seconds), t.labels !== void 0 && (_.labels = t.labels), t.intervieweeName !== void 0 && (_.intervieweeName = t.intervieweeName);
      let l = await i.db.insert("videos", _);
      return x(l, "\u52D5\u753B\u304C\u6B63\u5E38\u306B\u4F5C\u6210\u3055\u308C\u307E\u3057\u305F");
    } catch (n) {
      return console.error("\u52D5\u753B\u4F5C\u6210\u30A8\u30E9\u30FC:", n), c("\u52D5\u753B\u306E\u4F5C\u6210\u4E2D\u306B\u30A8\u30E9\u30FC\u304C\u767A\u751F\u3057\u307E\u3057\u305F");
    }
  }, "handler")
}), oe = q({
  args: {
    videoId: e.id("videos"),
    title: e.optional(e.string()),
    description: e.optional(e.string()),
    type: e.optional(e.string()),
    labels: e.optional(e.array(e.string())),
    intervieweeName: e.optional(e.string())
  },
  returns: e.object({
    success: e.boolean(),
    data: e.optional(e.any()),
    error: e.optional(e.string()),
    message: e.optional(e.string())
  }),
  handler: /* @__PURE__ */ v(async (i, t) => {
    try {
      let { user: n } = await w(i), s = await i.db.get(t.videoId);
      if (!s)
        return c("\u52D5\u753B\u304C\u898B\u3064\u304B\u308A\u307E\u305B\u3093");
      await $(i, s.user_id);
      let a = {};
      if (t.title !== void 0) {
        let d = m(t.title, {
          type: "title",
          maxLength: 200,
          minLength: 1
        });
        if (!d.isValid)
          return c(`\u30BF\u30A4\u30C8\u30EB\u304C\u7121\u52B9\u3067\u3059: ${d.error}`);
        a.title = d.processed;
      }
      if (t.description !== void 0) {
        let d = m(t.description, {
          type: "description",
          maxLength: 2e3
        });
        if (!d.isValid)
          return c(`\u8AAC\u660E\u304C\u7121\u52B9\u3067\u3059: ${d.error}`);
        a.description = d.processed;
      }
      if (t.type !== void 0) {
        let d = m(t.type, {
          type: "name",
          maxLength: 100
        });
        d.isValid && (a.type = d.processed);
      }
      return t.labels !== void 0 && (a.labels = t.labels), t.intervieweeName !== void 0 && (a.intervieweeName = t.intervieweeName), await i.db.patch(t.videoId, a), C({
        message: "\u52D5\u753B\u60C5\u5831\u304C\u6B63\u5E38\u306B\u66F4\u65B0\u3055\u308C\u307E\u3057\u305F"
      });
    } catch (n) {
      return console.error("\u52D5\u753B\u66F4\u65B0\u30A8\u30E9\u30FC:", n), c("\u52D5\u753B\u306E\u66F4\u65B0\u4E2D\u306B\u30A8\u30E9\u30FC\u304C\u767A\u751F\u3057\u307E\u3057\u305F");
    }
  }, "handler")
}), re = q({
  args: {
    videoId: e.id("videos")
  },
  returns: e.object({
    success: e.boolean(),
    data: e.optional(e.any()),
    error: e.optional(e.string()),
    message: e.optional(e.string())
  }),
  handler: /* @__PURE__ */ v(async (i, t) => {
    let n = Date.now();
    console.log(`[deleteVideo] \u958B\u59CB - videoId: ${t.videoId}, timestamp: ${n}`);
    try {
      console.log(`[deleteVideo] \u8A8D\u8A3C\u30C1\u30A7\u30C3\u30AF\u958B\u59CB - videoId: ${t.videoId}`);
      let { user: s } = await w(i);
      console.log(`[deleteVideo] \u8A8D\u8A3C\u6210\u529F - userId: ${s._id}, videoId: ${t.videoId}`), console.log(`[deleteVideo] \u52D5\u753B\u5B58\u5728\u78BA\u8A8D - videoId: ${t.videoId}`);
      let a = await i.db.get(t.videoId);
      if (!a)
        return console.warn(`[deleteVideo] \u52D5\u753B\u304C\u898B\u3064\u304B\u308A\u307E\u305B\u3093 - videoId: ${t.videoId}`), {
          success: !1,
          error: "\u52D5\u753B\u304C\u898B\u3064\u304B\u308A\u307E\u305B\u3093"
        };
      console.log(
        `[deleteVideo] \u52D5\u753B\u5B58\u5728\u78BA\u8A8D\u5B8C\u4E86 - videoId: ${t.videoId}, owner: ${a.user_id}`
      ), console.log(
        `[deleteVideo] \u6A29\u9650\u30C1\u30A7\u30C3\u30AF\u958B\u59CB - videoId: ${t.videoId}, requestUser: ${s._id}, owner: ${a.user_id}`
      ), await $(i, a.user_id), console.log(`[deleteVideo] \u6A29\u9650\u30C1\u30A7\u30C3\u30AF\u5B8C\u4E86 - videoId: ${t.videoId}`), console.log(`[deleteVideo] \u95A2\u9023\u30C7\u30FC\u30BF\u691C\u7D22\u958B\u59CB - videoId: ${t.videoId}`);
      let [d, p, y] = await Promise.all([
        i.db.query("transcriptions").withIndex("by_video_id", (l) => l.eq("video_id", t.videoId)).take(100),
        // 通常1動画につき関連データは少数のため制限
        i.db.query("evaluations").withIndex("by_video_id", (l) => l.eq("video_id", t.videoId)).take(100),
        // fileUploadsテーブルにはvideo_idフィールドが存在しないため、
        // related_resource_type="video"とrelated_resource_id=videoIdで検索
        i.db.query("fileUploads").withIndex(
          "by_related_resource",
          (l) => l.eq("related_resource_type", "video").eq("related_resource_id", t.videoId)
        ).take(100)
      ]);
      console.log(
        `[deleteVideo] \u95A2\u9023\u30C7\u30FC\u30BF\u767A\u898B - videoId: ${t.videoId}, transcriptions: ${d.length}, evaluations: ${p.length}, fileUploads: ${y.length}`
      ), console.log(`[deleteVideo] \u95A2\u9023\u30C7\u30FC\u30BF\u524A\u9664\u958B\u59CB - videoId: ${t.videoId}`), await Promise.all([
        ...d.map((l) => (console.log(
          `[deleteVideo] \u6587\u5B57\u8D77\u3053\u3057\u524A\u9664 - transcriptionId: ${l._id}, videoId: ${t.videoId}`
        ), i.db.delete(l._id))),
        ...p.map((l) => (console.log(
          `[deleteVideo] \u8A55\u4FA1\u524A\u9664 - evaluationId: ${l._id}, videoId: ${t.videoId}`
        ), i.db.delete(l._id))),
        ...y.map((l) => (console.log(`[deleteVideo] \u30D5\u30A1\u30A4\u30EB\u524A\u9664 - fileId: ${l._id}, videoId: ${t.videoId}`), i.db.delete(l._id)))
      ]), console.log(`[deleteVideo] \u95A2\u9023\u30C7\u30FC\u30BF\u524A\u9664\u5B8C\u4E86 - videoId: ${t.videoId}`), console.log(`[deleteVideo] \u52D5\u753B\u672C\u4F53\u524A\u9664\u958B\u59CB - videoId: ${t.videoId}`), await i.db.delete(t.videoId), console.log(`[deleteVideo] \u52D5\u753B\u672C\u4F53\u524A\u9664\u5B8C\u4E86 - videoId: ${t.videoId}`);
      let _ = Date.now();
      return console.log(
        `[deleteVideo] \u524A\u9664\u6210\u529F - videoId: ${t.videoId}, \u51E6\u7406\u6642\u9593: ${_ - n}ms`
      ), {
        success: !0,
        data: { message: "\u52D5\u753B\u304C\u6B63\u5E38\u306B\u524A\u9664\u3055\u308C\u307E\u3057\u305F" },
        message: "\u52D5\u753B\u304C\u6B63\u5E38\u306B\u524A\u9664\u3055\u308C\u307E\u3057\u305F"
      };
    } catch (s) {
      let a = Date.now();
      throw console.error(
        `[deleteVideo] \u30A8\u30E9\u30FC\u767A\u751F - videoId: ${t.videoId}, \u51E6\u7406\u6642\u9593: ${a - n}ms, \u30A8\u30E9\u30FC\u8A73\u7D30:`,
        s
      ), s instanceof Error && (console.error(
        `[deleteVideo] \u30A8\u30E9\u30FC\u30BF\u30A4\u30D7: ${s.constructor.name}, \u30E1\u30C3\u30BB\u30FC\u30B8: ${s.message}, videoId: ${t.videoId}`
      ), s.stack && console.error(`[deleteVideo] \u30B9\u30BF\u30C3\u30AF\u30C8\u30EC\u30FC\u30B9 - videoId: ${t.videoId}:`, s.stack)), s;
    }
  }, "handler")
}), ie = b({
  args: {
    upload_session_id: e.string()
  },
  returns: e.object({
    success: e.boolean(),
    data: e.optional(e.array(e.any())),
    error: e.optional(e.string())
  }),
  handler: /* @__PURE__ */ v(async (i, t) => {
    try {
      await D(i);
      let n = await i.db.query("videos").withIndex("by_upload_session", (a) => a.eq("upload_session_id", t.upload_session_id)).collect();
      if (n.length === 0)
        return c("\u6307\u5B9A\u3055\u308C\u305F\u30B0\u30EB\u30FC\u30D7\u306B\u30D5\u30A1\u30A4\u30EB\u304C\u898B\u3064\u304B\u308A\u307E\u305B\u3093");
      try {
        await $(i, n[0].user_id);
      } catch {
        return c("\u30B0\u30EB\u30FC\u30D7\u30D5\u30A1\u30A4\u30EB\u3078\u306E\u30A2\u30AF\u30BB\u30B9\u6A29\u9650\u304C\u3042\u308A\u307E\u305B\u3093");
      }
      let s = n.sort((a, d) => {
        let p = a.group_order || 0, y = d.group_order || 0;
        return p - y;
      });
      return C(s);
    } catch (n) {
      return console.error("\u30B0\u30EB\u30FC\u30D7\u30D5\u30A1\u30A4\u30EB\u53D6\u5F97\u30A8\u30E9\u30FC:", n), c("\u30B0\u30EB\u30FC\u30D7\u30D5\u30A1\u30A4\u30EB\u306E\u53D6\u5F97\u4E2D\u306B\u30A8\u30E9\u30FC\u304C\u767A\u751F\u3057\u307E\u3057\u305F");
    }
  }, "handler")
}), ne = G, se = j({
  args: {
    videoId: e.id("videos")
  },
  returns: e.union(e.any(), e.null()),
  handler: /* @__PURE__ */ v(async (i, t) => {
    try {
      return await i.db.get(t.videoId);
    } catch (n) {
      return console.error("\u5185\u90E8\u52D5\u753B\u53D6\u5F97\u30A8\u30E9\u30FC:", n), null;
    }
  }, "handler")
}), ae = b({
  args: {
    userId: e.id("users")
  },
  returns: e.number(),
  handler: /* @__PURE__ */ v(async (i, t) => 0, "handler")
}), de = b({
  args: {
    videoId: e.id("videos"),
    userId: e.id("users")
  },
  returns: e.boolean(),
  handler: /* @__PURE__ */ v(async (i, t) => {
    try {
      let n = await i.db.get(t.videoId);
      if (!n)
        return !1;
      let s = await i.db.get(t.userId);
      return s ? n.user_id === t.userId || s.role === "admin" || s.role === "trainer" : !1;
    } catch (n) {
      return console.error("checkVideoAccess error:", n), !1;
    }
  }, "handler")
});

export {
  ee as a,
  G as b,
  te as c,
  oe as d,
  re as e,
  ie as f,
  ne as g,
  se as h,
  ae as i,
  de as j
};
//# sourceMappingURL=A5PSBHJ6.js.map
