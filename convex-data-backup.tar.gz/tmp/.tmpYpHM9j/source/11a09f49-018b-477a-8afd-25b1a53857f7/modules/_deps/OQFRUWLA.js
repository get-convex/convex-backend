import {
  a as i
} from "./RUVYHBJQ.js";

// convex/lib/inputValidation.ts
function d(e, s = 0, t = 1e3, n = "\u5165\u529B\u5024") {
  return e.length < s ? {
    isValid: !1,
    message: `${n}\u306F${s}\u6587\u5B57\u4EE5\u4E0A\u3067\u3042\u308B\u5FC5\u8981\u304C\u3042\u308A\u307E\u3059`
  } : e.length > t ? {
    isValid: !1,
    message: `${n}\u306F${t}\u6587\u5B57\u4EE5\u5185\u3067\u3042\u308B\u5FC5\u8981\u304C\u3042\u308A\u307E\u3059`
  } : { isValid: !0 };
}
i(d, "validateStringLength");
function f(e, s, t = !1) {
  let n = s ? `${s}\u3067\u30A8\u30E9\u30FC\u304C\u767A\u751F\u3057\u307E\u3057\u305F` : "\u30A8\u30E9\u30FC\u304C\u767A\u751F\u3057\u307E\u3057\u305F";
  return t && e.message ? `${n}: ${e.message}` : n;
}
i(f, "createSafeErrorMessage");
function m(e, s) {
  if (typeof e != "string")
    return s ? {
      isValid: !1,
      processed: "",
      error: "Input must be a string"
    } : "";
  let t = e.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#x27;").replace(/\//g, "&#x2F;").trim();
  if (!s)
    return t;
  let n = g(t, s);
  return {
    isValid: n.isValid,
    processed: t,
    error: n.message
  };
}
i(m, "processInput");
function g(e, s) {
  let { type: t = "content", maxLength: n = 1e3, minLength: r = 0, allowEmpty: a = !0 } = s;
  if (!a && e.length === 0)
    return {
      isValid: !1,
      message: "Input cannot be empty"
    };
  if (e.length < r)
    return {
      isValid: !1,
      message: `Input must be at least ${r} characters`
    };
  if (e.length > n)
    return {
      isValid: !1,
      message: `Input must not exceed ${n} characters`
    };
  switch (t) {
    case "email":
      return o(e);
    case "url":
      return u(e);
    case "name":
    case "title":
    case "description":
    case "content":
    default:
      return c(e);
  }
}
i(g, "validateInputWithOptions");
function u(e) {
  try {
    return new URL(e), { isValid: !0 };
  } catch {
    return {
      isValid: !1,
      message: "Invalid URL format"
    };
  }
}
i(u, "validateURL");
function o(e) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(e) ? { isValid: !0 } : {
    isValid: !1,
    message: "\u6709\u52B9\u306A\u30E1\u30FC\u30EB\u30A2\u30C9\u30EC\u30B9\u3092\u5165\u529B\u3057\u3066\u304F\u3060\u3055\u3044"
  };
}
i(o, "validateEmail");
function V(e, s, t, n = "\u5024") {
  return e < s ? {
    isValid: !1,
    message: `${n}\u306F${s}\u4EE5\u4E0A\u3067\u3042\u308B\u5FC5\u8981\u304C\u3042\u308A\u307E\u3059`
  } : e > t ? {
    isValid: !1,
    message: `${n}\u306F${t}\u4EE5\u4E0B\u3067\u3042\u308B\u5FC5\u8981\u304C\u3042\u308A\u307E\u3059`
  } : { isValid: !0 };
}
i(V, "validateNumberRange");
function b(e) {
  let s = e.filter((t) => !t.isValid && t.message).map((t) => t.message);
  return {
    isValid: e.every((t) => t.isValid),
    messages: s
  };
}
i(b, "combineValidationResults");
function c(e) {
  let s = [
    /<script/i,
    /javascript:/i,
    /on\w+\s*=/i,
    /eval\s*\(/i,
    /expression\s*\(/i
  ];
  for (let t of s)
    if (t.test(e))
      return {
        isValid: !1,
        message: "Dangerous pattern detected in input"
      };
  return {
    isValid: !0
  };
}
i(c, "checkDangerousPatterns");
function p(e) {
  if (typeof e == "string") {
    if (e.length > 100)
      return e.substring(0, 100) + "...";
    if (o(e).isValid) {
      let [s, t] = e.split("@");
      return `${s.substring(0, 2)}***@${t}`;
    }
    return e;
  }
  if (typeof e == "object" && e !== null) {
    let s = ["password", "token", "key", "secret", "api_key"], t = {};
    for (let [n, r] of Object.entries(e)) {
      let a = n.toLowerCase();
      s.some((l) => a.includes(l)) ? t[n] = "***MASKED***" : t[n] = p(r);
    }
    return t;
  }
  return e;
}
i(p, "createSafeLogValue");
function y(e, s) {
  return !e || typeof e != "string" ? {
    isValid: !1,
    message: "ID\u304C\u6307\u5B9A\u3055\u308C\u3066\u3044\u307E\u305B\u3093"
  } : e.length < 10 ? {
    isValid: !1,
    message: "\u7121\u52B9\u306AID\u5F62\u5F0F\u3067\u3059"
  } : { isValid: !0 };
}
i(y, "validateConvexId");

export {
  d as a,
  f as b,
  m as c,
  o as d,
  V as e,
  b as f,
  c as g,
  p as h,
  y as i
};
//# sourceMappingURL=OQFRUWLA.js.map
