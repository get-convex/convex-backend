import {
  a as o
} from "./RUVYHBJQ.js";

// convex/evaluation/config.ts
var i = {
  vertexAI: {
    projectId: process.env.VERTEX_AI_PROJECT_ID || "",
    location: process.env.VERTEX_AI_LOCATION || "us-central1",
    model: process.env.VERTEX_AI_MODEL || "gemini-1.5-pro",
    temperature: 0.1,
    maxOutputTokens: 32768,
    topK: 40,
    topP: 0.95
  },
  retry: {
    maxRetries: 3,
    initialDelay: 1e3,
    maxDelay: 1e4,
    exponentialBase: 2
  },
  timeout: {
    preprocessing: 45e3,
    // 45秒
    evaluation: 3e5,
    // 5分 (複雑なAI評価に対応)
    summaries: 18e4,
    // 3分
    meetingMinutes: 18e4,
    // 3分
    consolidation: 6e4
    // 1分
  },
  parallelProcessing: {
    enabled: !0,
    maxConcurrentJobs: 3
  },
  fallback: {
    enabled: !0,
    mockDataOnFailure: !0
  }
};
function a(t) {
  let e = { ...i };
  if (process.env.VERTEX_AI_PROJECT_ID && (e.vertexAI.projectId = process.env.VERTEX_AI_PROJECT_ID), process.env.VERTEX_AI_LOCATION && (e.vertexAI.location = process.env.VERTEX_AI_LOCATION), process.env.VERTEX_AI_MODEL ? e.vertexAI.model = process.env.VERTEX_AI_MODEL : process.env.GEMINI_MODEL && (e.vertexAI.model = process.env.GEMINI_MODEL), process.env.EVALUATION_TIMEOUT_MS) {
    let r = Number.parseInt(process.env.EVALUATION_TIMEOUT_MS, 10);
    !isNaN(r) && r > 0 && (e.timeout.evaluation = r);
  }
  return t === "development" && (e.timeout.evaluation = 42e4, e.retry.maxRetries = 2), t === "production" && (e.timeout.evaluation = 36e4, e.retry.maxRetries = 3), e;
}
o(a, "getProcessingConfig");
function u(t) {
  let e = [];
  t.vertexAI.projectId || e.push("Vertex AI project ID is required"), t.vertexAI.model || e.push("Vertex AI model is required"), t.vertexAI.temperature !== void 0 && (t.vertexAI.temperature < 0 || t.vertexAI.temperature > 2) && e.push("Temperature must be between 0 and 2"), t.vertexAI.maxOutputTokens !== void 0 && t.vertexAI.maxOutputTokens <= 0 && e.push("Max output tokens must be positive"), t.retry.maxRetries < 0 && e.push("Max retries must be non-negative");
  let r = Object.keys(t.timeout);
  for (let s of r)
    t.timeout[s] <= 0 && e.push(`Timeout for ${s} must be positive`);
  return {
    valid: e.length === 0,
    errors: e
  };
}
o(u, "validateConfig");

export {
  i as a,
  a as b,
  u as c
};
//# sourceMappingURL=BAAP5EPW.js.map
