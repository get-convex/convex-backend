import {
  b as w,
  d as y
} from "./75JH2J25.js";
import {
  j as t,
  n as m
} from "./3TDUHHJO.js";
import {
  a as E
} from "./RUVYHBJQ.js";

// convex/testing/cleanupHelpers.ts
m();
var _ = [
  // 依存される側から削除（外部キー制約を考慮）
  "evaluations",
  "transcriptions",
  "videos",
  "userActivities",
  "userSettings",
  "notifications",
  "evaluationCriteria",
  "users"
  // 最後に削除（多くのテーブルから参照される）
], f = {
  EMAIL_SUFFIX: "@test.com",
  NAME_PREFIX: "Test",
  CLERK_ID_PREFIX: "test-",
  TOKEN_PREFIX: "test://"
}, v = y({
  args: {
    force: t.optional(t.boolean())
  },
  returns: t.object({
    success: t.boolean(),
    deletedCounts: t.any(),
    totalDeleted: t.number(),
    errors: t.array(t.string())
  }),
  handler: /* @__PURE__ */ E(async (s, a) => {
    if (process.env.VITEST !== "true" && !a.force)
      throw new Error("\u3053\u306E\u6A5F\u80FD\u306F\u30C6\u30B9\u30C8\u74B0\u5883\u3067\u306E\u307F\u4F7F\u7528\u53EF\u80FD\u3067\u3059");
    let r = {}, l = [], n = 0;
    for (let c of _)
      try {
        let i = await g(s, c);
        r[c] = i, n += i;
      } catch (i) {
        let b = `${c}\u306E\u30AF\u30EA\u30FC\u30F3\u30A2\u30C3\u30D7\u306B\u5931\u6557: ${i}`;
        l.push(b), console.error(b);
      }
    return {
      success: l.length === 0,
      deletedCounts: r,
      totalDeleted: n,
      errors: l
    };
  }, "handler")
});
async function g(s, a) {
  let r = 0;
  switch (a) {
    case "users":
      let l = await s.db.query("users").filter(
        (e) => e.or(
          e.like(e.field("email"), `%${f.EMAIL_SUFFIX}`),
          e.like(e.field("clerkUserId"), `${f.CLERK_ID_PREFIX}%`),
          e.like(e.field("tokenIdentifier"), `${f.TOKEN_PREFIX}%`),
          e.like(e.field("name"), `${f.NAME_PREFIX}%`)
        )
      ).collect();
      for (let e of l)
        await s.db.delete(e._id), r++;
      break;
    case "videos":
      let n = await s.db.query("videos").filter(
        (e) => e.or(
          e.like(e.field("title"), `${f.NAME_PREFIX}%`),
          e.like(e.field("url"), "%test%"),
          e.like(e.field("description"), "%\u30C6\u30B9\u30C8%")
        )
      ).collect();
      for (let e of n)
        await s.db.delete(e._id), r++;
      break;
    case "evaluations":
      let c = await s.db.query("evaluations").filter(
        (e) => e.or(
          e.eq(e.field("videoType"), "M&A\u30ED\u30FC\u30EB\u30D7\u30EC\u30A4"),
          // テスト用デフォルト
          e.like(e.field("feedback.overall"), "%\u30C6\u30B9\u30C8%")
        )
      ).collect();
      for (let e of c)
        await s.db.delete(e._id), r++;
      break;
    case "transcriptions":
      let i = await s.db.query("transcriptions").filter(
        (e) => e.like(e.field("text"), "%\u30C6\u30B9\u30C8%")
      ).collect();
      for (let e of i)
        await s.db.delete(e._id), r++;
      break;
    case "userActivities":
      let b = await s.db.query("userActivities").filter(
        (e) => e.or(
          e.eq(e.field("session_id"), "test-session"),
          e.eq(e.field("ip_address"), "127.0.0.1"),
          e.eq(e.field("user_agent"), "test-agent")
        )
      ).collect();
      for (let e of b)
        await s.db.delete(e._id), r++;
      break;
    case "userSettings":
      let p = await s.db.query("userSettings").collect();
      for (let e of p)
        try {
          let u = await s.db.get(e.user_id);
          u && (u.email?.includes(f.EMAIL_SUFFIX) || u.clerkUserId?.startsWith(f.CLERK_ID_PREFIX)) && (await s.db.delete(e._id), r++);
        } catch {
          await s.db.delete(e._id), r++;
        }
      break;
    case "notifications":
      let d = await s.db.query("notifications").collect();
      for (let e of d)
        try {
          let u = await s.db.get(e.user_id);
          u && (u.email?.includes(f.EMAIL_SUFFIX) || u.clerkUserId?.startsWith(f.CLERK_ID_PREFIX)) && (await s.db.delete(e._id), r++);
        } catch {
          await s.db.delete(e._id), r++;
        }
      break;
    case "evaluationCriteria":
      let o = await s.db.query("evaluationCriteria").filter(
        (e) => e.or(
          e.like(e.field("criterion_key"), "test%"),
          e.like(e.field("description"), "%\u30C6\u30B9\u30C8%"),
          e.like(e.field("description"), "%Test%")
        )
      ).collect();
      for (let e of o)
        await s.db.delete(e._id), r++;
      break;
    default:
      console.warn(`\u672A\u5BFE\u5FDC\u306E\u30C6\u30FC\u30D6\u30EB: ${a}`);
  }
  return r;
}
E(g, "cleanupTableTestData");
var k = y({
  args: {
    sessionId: t.string(),
    preserveUsers: t.optional(t.boolean())
  },
  returns: t.object({
    success: t.boolean(),
    deletedCounts: t.any(),
    message: t.string()
  }),
  handler: /* @__PURE__ */ E(async (s, a) => {
    if (process.env.VITEST !== "true")
      throw new Error("\u3053\u306E\u6A5F\u80FD\u306F\u30C6\u30B9\u30C8\u74B0\u5883\u3067\u306E\u307F\u4F7F\u7528\u53EF\u80FD\u3067\u3059");
    let r = {};
    if (r.userActivities = 0, !a.preserveUsers) {
      let l = await s.db.query("users").filter((n) => n.like(n.field("clerkUserId"), `${a.sessionId}%`)).collect();
      for (let n of l)
        await s.db.delete(n._id);
      r.users = l.length;
    }
    return {
      success: !0,
      deletedCounts: r,
      message: `\u30BB\u30C3\u30B7\u30E7\u30F3 ${a.sessionId} \u306E\u30C7\u30FC\u30BF\u3092\u30AF\u30EA\u30FC\u30F3\u30A2\u30C3\u30D7\u3057\u307E\u3057\u305F`
    };
  }, "handler")
}), h = y({
  args: {
    cleanFirst: t.optional(t.boolean()),
    setupUsers: t.optional(t.array(t.string()))
  },
  returns: t.object({
    success: t.boolean(),
    cleanupResults: t.any(),
    setupResults: t.any(),
    message: t.string()
  }),
  handler: /* @__PURE__ */ E(async (s, a) => {
    if (process.env.VITEST !== "true")
      throw new Error("\u3053\u306E\u6A5F\u80FD\u306F\u30C6\u30B9\u30C8\u74B0\u5883\u3067\u306E\u307F\u4F7F\u7528\u53EF\u80FD\u3067\u3059");
    let r = null, l = null;
    if (a.cleanFirst) {
      let n = {}, c = [], i = 0, b = /* @__PURE__ */ E(async (d) => {
        let o = await s.db.query(d).collect(), e = 0;
        for (let u of o)
          await s.db.delete(u._id), e++;
        return e;
      }, "cleanupTableTestData"), p = ["users", "videos", "transcriptions", "evaluations"];
      for (let d of p)
        try {
          let o = await b(d);
          n[d] = o, i += o;
        } catch (o) {
          let e = `${d}\u306E\u30AF\u30EA\u30FC\u30F3\u30A2\u30C3\u30D7\u306B\u5931\u6557: ${o}`;
          c.push(e), console.error(e);
        }
      r = {
        success: c.length === 0,
        deletedCounts: n,
        totalDeleted: i,
        errors: c
      };
    }
    return a.setupUsers && a.setupUsers.length > 0 && (l = [], console.log("\u30E6\u30FC\u30B6\u30FC\u30BB\u30C3\u30C8\u30A2\u30C3\u30D7\u306F\u30B9\u30AD\u30C3\u30D7\u3055\u308C\u307E\u3057\u305F\uFF08\u5FAA\u74B0\u53C2\u7167\u56DE\u907F\u306E\u305F\u3081\uFF09")), {
      success: !0,
      cleanupResults: r,
      setupResults: l,
      message: "\u30C6\u30B9\u30C8\u74B0\u5883\u306E\u6E96\u5099\u304C\u5B8C\u4E86\u3057\u307E\u3057\u305F"
    };
  }, "handler")
}), R = w({
  args: {},
  returns: t.object({
    tableCounts: t.any(),
    totalTestRecords: t.number(),
    estimatedCleanupTime: t.string()
  }),
  handler: /* @__PURE__ */ E(async (s) => {
    if (process.env.VITEST !== "true")
      throw new Error("\u3053\u306E\u6A5F\u80FD\u306F\u30C6\u30B9\u30C8\u74B0\u5883\u3067\u306E\u307F\u4F7F\u7528\u53EF\u80FD\u3067\u3059");
    let a = {}, r = 0;
    for (let c of _) {
      let i = 0;
      switch (c) {
        case "users":
          i = (await s.db.query("users").filter(
            (o) => o.or(
              o.like(o.field("email"), `%${f.EMAIL_SUFFIX}`),
              o.like(o.field("clerkUserId"), `${f.CLERK_ID_PREFIX}%`)
            )
          ).collect()).length;
          break;
        case "videos":
          i = (await s.db.query("videos").filter((o) => o.like(o.field("title"), `${f.NAME_PREFIX}%`)).collect()).length;
          break;
        // 他のテーブルも同様に実装
        default:
          i = (await s.db.query(c).collect()).length;
      }
      a[c] = i, r += i;
    }
    let l = r * 1, n = `\u7D04${Math.ceil(l / 1e3)}\u79D2`;
    return {
      tableCounts: a,
      totalTestRecords: r,
      estimatedCleanupTime: n
    };
  }, "handler")
}), A = y({
  args: {
    batchSize: t.optional(t.number())
  },
  returns: t.object({
    success: t.boolean(),
    totalDeleted: t.number(),
    executionTime: t.number()
  }),
  handler: /* @__PURE__ */ E(async (s, a) => {
    if (process.env.VITEST !== "true")
      throw new Error("\u3053\u306E\u6A5F\u80FD\u306F\u30C6\u30B9\u30C8\u74B0\u5883\u3067\u306E\u307F\u4F7F\u7528\u53EF\u80FD\u3067\u3059");
    let r = Date.now(), l = a.batchSize || 100, n = 0, c = _.map(async (p) => {
      let d = 0, o = !0;
      for (; o; ) {
        let e = await s.db.query(p).take(l);
        if (e.length === 0) {
          o = !1;
          break;
        }
        await Promise.all(e.map((u) => s.db.delete(u._id))), d += e.length;
      }
      return d;
    });
    n = (await Promise.all(c)).reduce((p, d) => p + d, 0);
    let b = Date.now() - r;
    return {
      success: !0,
      totalDeleted: n,
      executionTime: b
    };
  }, "handler")
});

export {
  f as a,
  v as b,
  k as c,
  h as d,
  R as e,
  A as f
};
//# sourceMappingURL=VZDVKQ3V.js.map
