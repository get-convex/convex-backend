import {
  n as i,
  p as a
} from "./6XQQNYIR.js";
import {
  j as e,
  n as t
} from "./3TDUHHJO.js";

// convex/schema/file.ts
a();
t();
var o = {
  // === Core File Management ===
  // ファイルアップロード管理（拡張）
  fileUploads: i({
    // ユーザー情報
    userId: e.id("users"),
    // ファイル基本情報
    originalFilename: e.string(),
    contentType: e.string(),
    fileSize: e.number(),
    // ストレージ情報（GCS専用）
    gcpFilePath: e.string(),
    // GCP Cloud Storage専用（必須）
    // アップロード種別
    uploadType: e.union(
      e.literal("video"),
      e.literal("training"),
      e.literal("thumbnail"),
      e.literal("courseThumbnail"),
      e.literal("moduleContent"),
      e.literal("roleplayMaterial")
    ),
    // ステータス管理（原子的アップロード対応）
    status: e.union(
      e.literal("preparing"),
      // フェーズ1: DB予約レコード作成済み
      e.literal("pending"),
      // フェーズ2: GCS URL生成済み、アップロード待ち
      e.literal("uploading"),
      // アップロード中
      e.literal("completed"),
      // 完了
      e.literal("failed"),
      // 失敗
      e.literal("processing")
      // 後処理中
    ),
    // 関連リソースID（型安全化）
    relatedResourceType: e.optional(
      e.union(
        e.literal("video"),
        e.literal("training"),
        e.literal("trainingModule"),
        e.literal("moduleContent"),
        e.literal("roleplay")
      )
    ),
    relatedResourceId: e.optional(e.string()),
    // 処理結果
    publicUrl: e.optional(e.string()),
    processingError: e.optional(e.string()),
    // 拡張メタデータ
    durationSeconds: e.optional(e.number()),
    // 動画・音声ファイル用
    resolution: e.optional(
      e.object({
        // 動画・画像ファイル用
        width: e.number(),
        height: e.number()
      })
    ),
    videoCodec: e.optional(e.string()),
    // 動画ファイル用
    audioCodec: e.optional(e.string()),
    // 動画・音声ファイル用
    bitrate: e.optional(e.number()),
    // 動画・音声ファイル用
    frameRate: e.optional(e.number()),
    // 動画ファイル用
    // サムネイル管理（GCS対応）
    thumbnailGenerated: e.optional(e.boolean()),
    thumbnailGcpPaths: e.optional(
      e.array(
        e.object({
          // 複数サイズサムネイル（GCS）
          size: e.union(
            e.literal("small"),
            e.literal("medium"),
            e.literal("large"),
            e.literal("poster")
          ),
          gcpFilePath: e.string(),
          url: e.string(),
          fileSize: e.number(),
          width: e.number(),
          height: e.number()
        })
      )
    ),
    // 文字起こし・AI処理
    transcriptionStarted: e.optional(e.boolean()),
    transcriptionId: e.optional(e.id("transcriptions")),
    // 品質分析
    qualityScore: e.optional(e.number()),
    // 0-100
    qualityAnalysis: e.optional(
      e.object({
        audioQuality: e.optional(e.number()),
        videoQuality: e.optional(e.number()),
        compressionRatio: e.optional(e.number()),
        recommendedSettings: e.optional(e.string())
      })
    ),
    // 重複検出
    fileHash: e.optional(e.string()),
    // SHA-256ハッシュ
    duplicateOf: e.optional(e.id("fileUploads")),
    // 重複元ファイル
    // 使用量統計
    viewCount: e.optional(e.number()),
    downloadCount: e.optional(e.number()),
    lastAccessed: e.optional(e.number()),
    // タイムスタンプ
    uploadedAt: e.optional(e.number()),
    completedAt: e.optional(e.number()),
    metadataProcessedAt: e.optional(e.number())
  }).index("by_user_id", ["userId"]).index("by_status", ["status"]).index("by_upload_type", ["uploadType"]).index("by_user_status", ["userId", "status"]).index("by_user_type", ["userId", "uploadType"]).index("by_status_uploaded", ["status", "uploadedAt"]).index("by_related_resource", ["relatedResourceType", "relatedResourceId"]).index("by_file_hash", ["fileHash"]).index("by_duplicate_of", ["duplicateOf"]).index("by_quality_score", ["qualityScore"]).index("by_last_accessed", ["lastAccessed"]),
  // === Upload Progress Tracking ===
  // アップロード進行状況追跡
  uploadProgress: i({
    fileUploadId: e.id("fileUploads"),
    userId: e.id("users"),
    // 進行状況
    progressPercentage: e.number(),
    bytesUploaded: e.number(),
    totalBytes: e.number(),
    // ステータス
    stage: e.union(
      e.literal("generatingUrl"),
      e.literal("uploading"),
      e.literal("processing"),
      e.literal("completed"),
      e.literal("failed")
    ),
    // エラー情報
    errorMessage: e.optional(e.string()),
    retryCount: e.optional(e.number()),
    // マルチパートアップロード関連情報（JSON文字列で格納）
    chunkInfo: e.optional(e.string()),
    // JSON: {uploadId, totalParts, partSize, completedParts, parts}
    uploadSpeedBps: e.optional(e.number()),
    // bytes per second
    estimatedCompletionTime: e.optional(e.number()),
    // timestamp
    // 最終更新時刻
    lastUpdated: e.number()
  }).index("by_file_upload_id", ["fileUploadId"]).index("by_user_id", ["userId"]).index("by_stage", ["stage"]),
  // === File Metadata & Analysis ===
  // ファイルメタデータ詳細
  fileMetadata: i({
    fileUploadId: e.id("fileUploads"),
    storageId: e.id("_storage"),
    // 技術的メタデータ
    fileFormat: e.optional(e.string()),
    containerFormat: e.optional(e.string()),
    // 動画メタデータ
    videoStreams: e.optional(
      e.array(
        e.object({
          codec: e.string(),
          width: e.number(),
          height: e.number(),
          frameRate: e.number(),
          bitrate: e.number(),
          duration: e.number(),
          aspectRatio: e.optional(e.string()),
          colorSpace: e.optional(e.string())
        })
      )
    ),
    // 音声メタデータ
    audioStreams: e.optional(
      e.array(
        e.object({
          codec: e.string(),
          sampleRate: e.number(),
          channels: e.number(),
          bitrate: e.number(),
          duration: e.number(),
          language: e.optional(e.string())
        })
      )
    ),
    // 画像メタデータ
    imageMetadata: e.optional(
      e.object({
        width: e.number(),
        height: e.number(),
        colorDepth: e.optional(e.number()),
        dpi: e.optional(e.number()),
        orientation: e.optional(e.string()),
        cameraMake: e.optional(e.string()),
        cameraModel: e.optional(e.string()),
        exifData: e.optional(e.string())
        // JSON string for EXIF data
      })
    ),
    // 文書メタデータ
    documentMetadata: e.optional(
      e.object({
        pages: e.optional(e.number()),
        author: e.optional(e.string()),
        title: e.optional(e.string()),
        subject: e.optional(e.string()),
        creator: e.optional(e.string()),
        producer: e.optional(e.string()),
        creationDate: e.optional(e.number()),
        modificationDate: e.optional(e.number()),
        encrypted: e.optional(e.boolean())
      })
    ),
    // 処理ステータス
    extractionStatus: e.union(
      e.literal("pending"),
      e.literal("processing"),
      e.literal("completed"),
      e.literal("failed")
    ),
    extractionError: e.optional(e.string()),
    extractedAt: e.optional(e.number())
  }).index("by_file_upload_id", ["fileUploadId"]).index("by_storage_id", ["storageId"]).index("by_extraction_status", ["extractionStatus"]),
  // === Thumbnail Management ===
  // サムネイル管理システム（ハイブリッドストレージ対応）
  thumbnails: i({
    // ファイル関連（GCS専用）
    fileUploadId: e.id("fileUploads"),
    // サムネイル情報（GCS）
    gcpFilePath: e.string(),
    // GCS上のサムネイルファイルパス
    thumbnailUrl: e.string(),
    // サイズ・品質設定
    width: e.number(),
    height: e.number(),
    sizeCategory: e.union(
      e.literal("small"),
      // 150x150
      e.literal("medium"),
      // 300x300
      e.literal("large"),
      // 640x360
      e.literal("poster"),
      // 1280x720（新追加）
      e.literal("custom")
    ),
    format: e.union(e.literal("webp"), e.literal("jpeg"), e.literal("png")),
    quality: e.number(),
    // 1-100
    fileSize: e.number(),
    // 生成設定
    generationMethod: e.union(
      e.literal("frameExtraction"),
      // 動画フレーム抽出
      e.literal("imageResize"),
      // 画像リサイズ
      e.literal("documentPreview"),
      // 文書プレビュー
      e.literal("autoGenerated")
      // 自動生成
    ),
    frameTime: e.optional(e.number()),
    // 動画の場合、抽出時間（秒）
    // ステータス管理
    generationStatus: e.union(
      e.literal("pending"),
      e.literal("processing"),
      e.literal("completed"),
      e.literal("failed")
    ),
    generationError: e.optional(e.string()),
    generatedAt: e.optional(e.number()),
    // 最適化情報
    optimized: e.boolean(),
    compressionRatio: e.optional(e.number())
  }).index("by_file_upload_id", ["fileUploadId"]).index("by_size_category", ["sizeCategory"]).index("by_generation_status", ["generationStatus"]).index("by_generated_at", ["generatedAt"]),
  // サムネイル生成ジョブ管理
  thumbnailJobs: i({
    fileUploadId: e.id("fileUploads"),
    gcpFilePath: e.string(),
    // GCS上の元ファイルパス
    contentType: e.string(),
    originalFilename: e.string(),
    // ジョブステータス
    status: e.union(
      e.literal("pending"),
      e.literal("processing"),
      e.literal("completed"),
      e.literal("failed")
    ),
    priority: e.union(e.literal("low"), e.literal("normal"), e.literal("high")),
    // 結果情報
    thumbnailId: e.optional(e.id("thumbnails")),
    error: e.optional(e.string()),
    // タイムスタンプ
    createdAt: e.number(),
    updatedAt: e.optional(e.number())
  }).index("by_file_upload_id", ["fileUploadId"]).index("by_status", ["status"]).index("by_priority", ["priority"]).index("by_created_at", ["createdAt"]),
  // === Quality Analysis & Optimization ===
  // ファイル品質分析
  fileQualityAnalysis: i({
    fileUploadId: e.id("fileUploads"),
    // 総合品質スコア
    overallScore: e.number(),
    // 0-100
    // 動画品質分析
    videoQuality: e.optional(
      e.object({
        resolutionScore: e.number(),
        bitrateScore: e.number(),
        frameRateScore: e.number(),
        codecEfficiencyScore: e.number(),
        visualQualityScore: e.optional(e.number()),
        motionAnalysis: e.optional(
          e.object({
            averageMotion: e.number(),
            sceneChanges: e.number(),
            stabilityScore: e.number()
          })
        )
      })
    ),
    // 音声品質分析
    audioQuality: e.optional(
      e.object({
        sampleRateScore: e.number(),
        bitrateScore: e.number(),
        dynamicRangeScore: e.number(),
        noiseLevel: e.optional(e.number()),
        speechClarity: e.optional(e.number())
      })
    ),
    // 圧縮効率分析
    compressionAnalysis: e.object({
      currentRatio: e.number(),
      optimalRatio: e.number(),
      potentialSavingsBytes: e.number(),
      potentialSavingsPercentage: e.number()
    }),
    // 推奨設定
    recommendations: e.array(
      e.object({
        type: e.union(
          e.literal("resolution"),
          e.literal("bitrate"),
          e.literal("codec"),
          e.literal("format"),
          e.literal("compression")
        ),
        currentValue: e.string(),
        recommendedValue: e.string(),
        impact: e.union(e.literal("high"), e.literal("medium"), e.literal("low")),
        description: e.string()
      })
    ),
    // 分析メタデータ
    analysisVersion: e.string(),
    analyzedAt: e.number(),
    analysisDurationMs: e.number()
  }).index("by_file_upload_id", ["fileUploadId"]).index("by_overall_score", ["overallScore"]).index("by_analyzed_at", ["analyzedAt"]),
  // === Duplicate Detection ===
  // ファイル重複検出
  fileDuplicates: i({
    primaryFileId: e.id("fileUploads"),
    duplicateFileId: e.id("fileUploads"),
    // 類似度分析
    similarityScore: e.number(),
    // 0-100
    hashMatch: e.boolean(),
    sizeMatch: e.boolean(),
    nameSimilarity: e.number(),
    // 重複種別
    duplicateType: e.union(
      e.literal("exactMatch"),
      // 完全一致
      e.literal("nearDuplicate"),
      // 類似
      e.literal("differentFormat"),
      // 異なる形式
      e.literal("differentQuality")
      // 異なる品質
    ),
    // 推奨アクション
    recommendedAction: e.union(
      e.literal("keepPrimary"),
      e.literal("mergeMetadata"),
      e.literal("keepBoth"),
      e.literal("manualReview")
    ),
    // 検出情報
    detectedAt: e.number(),
    detectionMethod: e.string(),
    // 処理状況
    resolutionStatus: e.union(e.literal("pending"), e.literal("resolved"), e.literal("ignored")),
    resolvedAt: e.optional(e.number()),
    resolutionAction: e.optional(e.string())
  }).index("by_primary_file_id", ["primaryFileId"]).index("by_duplicate_file_id", ["duplicateFileId"]).index("by_similarity_score", ["similarityScore"]).index("by_duplicate_type", ["duplicateType"]).index("by_resolution_status", ["resolutionStatus"]),
  // === Usage Statistics ===
  // ファイル使用量統計
  fileUsageStats: i({
    fileUploadId: e.id("fileUploads"),
    date: e.string(),
    // YYYY-MM-DD
    // アクセス統計
    viewCount: e.number(),
    downloadCount: e.number(),
    streamCount: e.number(),
    // 帯域幅使用量
    bytesServed: e.number(),
    bandwidthCost: e.optional(e.number()),
    // ユーザー分析
    uniqueViewers: e.number(),
    totalWatchTime: e.optional(e.number()),
    // 秒
    averageWatchTime: e.optional(e.number()),
    // 秒
    // 地理的分析
    geographicDistribution: e.optional(e.string()),
    // JSON string for geographic data
    // デバイス分析
    deviceTypes: e.optional(e.string()),
    // JSON string for device data
    // パフォーマンス指標
    averageLoadTime: e.optional(e.number()),
    errorRate: e.optional(e.number()),
    updatedAt: e.number()
  }).index("by_file_upload_id", ["fileUploadId"]).index("by_date", ["date"]).index("by_file_and_date", ["fileUploadId", "date"]).index("by_view_count", ["viewCount"]),
  // === Background Processing ===
  // バックグラウンド処理ジョブ
  processingJobs: i({
    fileUploadId: e.id("fileUploads"),
    jobType: e.union(
      e.literal("metadataExtraction"),
      e.literal("thumbnailGeneration"),
      e.literal("qualityAnalysis"),
      e.literal("duplicateDetection"),
      e.literal("transcription"),
      e.literal("compressionOptimization")
    ),
    // ジョブ設定
    priority: e.union(e.literal("high"), e.literal("medium"), e.literal("low")),
    parameters: e.optional(e.string()),
    // JSON string for parameters
    // ステータス管理
    status: e.union(
      e.literal("queued"),
      e.literal("processing"),
      e.literal("completed"),
      e.literal("failed"),
      e.literal("cancelled")
    ),
    // 実行情報
    startedAt: e.optional(e.number()),
    completedAt: e.optional(e.number()),
    durationMs: e.optional(e.number()),
    // 進行状況
    progressPercentage: e.number(),
    currentStep: e.optional(e.string()),
    totalSteps: e.optional(e.number()),
    // エラー情報
    errorMessage: e.optional(e.string()),
    errorCode: e.optional(e.string()),
    retryCount: e.number(),
    maxRetries: e.number(),
    // 結果データ
    resultData: e.optional(e.string()),
    // JSON string for result data
    // スケジューリング
    scheduledAt: e.optional(e.number()),
    dependencies: e.optional(e.array(e.id("processingJobs"))),
    createdAt: e.number()
  }).index("by_file_upload_id", ["fileUploadId"]).index("by_job_type", ["jobType"]).index("by_status", ["status"]).index("by_priority", ["priority"]).index("by_scheduled_at", ["scheduledAt"]).index("by_status_and_priority", ["status", "priority"]).index("by_created_at", ["createdAt"])
};

export {
  o as a
};
//# sourceMappingURL=6WC7OENA.js.map
