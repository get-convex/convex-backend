import {
  j as e,
  n as p
} from "./3TDUHHJO.js";
import {
  a as t,
  c as R
} from "./RUVYHBJQ.js";

// convex/data/evaluation-criteria.json
var s = R((I, _) => {
  _.exports = {
    "M&A\u30ED\u30FC\u30EB\u30D7\u30EC\u30A4": {
      hearingAbility: {
        minScore: 0,
        maxScore: 5,
        weight: 0.25,
        description: "\u30AF\u30E9\u30A4\u30A2\u30F3\u30C8\u306E\u30CB\u30FC\u30BA\u3084\u72B6\u6CC1\u3092\u6B63\u78BA\u306B\u805E\u304D\u53D6\u308B\u80FD\u529B"
      },
      problemSetting: {
        minScore: 0,
        maxScore: 5,
        weight: 0.2,
        description: "\u8AB2\u984C\u3092\u660E\u78BA\u306B\u8A2D\u5B9A\u3057\u3001\u89E3\u6C7A\u7B56\u3092\u63D0\u793A\u3059\u308B\u80FD\u529B"
      },
      knowledge: {
        minScore: 0,
        maxScore: 5,
        weight: 0.25,
        description: "M&A\u306B\u95A2\u3059\u308B\u57FA\u672C\u77E5\u8B58\u3068\u305D\u306E\u6D3B\u7528\u80FD\u529B"
      },
      negotiation: {
        minScore: 0,
        maxScore: 5,
        weight: 0.2,
        description: "\u52B9\u679C\u7684\u306A\u30B3\u30DF\u30E5\u30CB\u30B1\u30FC\u30B7\u30E7\u30F3\u3068\u63D0\u6848\u6280\u8853"
      },
      businessManners: {
        minScore: 0,
        maxScore: 5,
        weight: 0.1,
        description: "\u30D3\u30B8\u30CD\u30B9\u30DE\u30CA\u30FC\u3068\u5C02\u9580\u6027\u306E\u3042\u308B\u7ACB\u3061\u632F\u308B\u821E\u3044"
      }
    },
    \u521D\u56DE\u9762\u8AC7: {
      hearingAbility: {
        minScore: 0,
        maxScore: 5,
        weight: 0.25,
        description: "\u30AF\u30E9\u30A4\u30A2\u30F3\u30C8\u306E\u30CB\u30FC\u30BA\u3084\u72B6\u6CC1\u3092\u6B63\u78BA\u306B\u805E\u304D\u53D6\u308B\u80FD\u529B"
      },
      problemSetting: {
        minScore: 0,
        maxScore: 5,
        weight: 0.2,
        description: "\u8AB2\u984C\u3092\u660E\u78BA\u306B\u8A2D\u5B9A\u3057\u3001\u89E3\u6C7A\u7B56\u3092\u63D0\u793A\u3059\u308B\u80FD\u529B"
      },
      knowledge: {
        minScore: 0,
        maxScore: 5,
        weight: 0.25,
        description: "M&A\u306B\u95A2\u3059\u308B\u57FA\u672C\u77E5\u8B58\u3068\u305D\u306E\u6D3B\u7528\u80FD\u529B"
      },
      negotiation: {
        minScore: 0,
        maxScore: 5,
        weight: 0.2,
        description: "\u52B9\u679C\u7684\u306A\u30B3\u30DF\u30E5\u30CB\u30B1\u30FC\u30B7\u30E7\u30F3\u3068\u63D0\u6848\u6280\u8853"
      },
      businessManners: {
        minScore: 0,
        maxScore: 5,
        weight: 0.1,
        description: "\u30D3\u30B8\u30CD\u30B9\u30DE\u30CA\u30FC\u3068\u5C02\u9580\u6027\u306E\u3042\u308B\u7ACB\u3061\u632F\u308B\u821E\u3044"
      }
    },
    AD\u7DE0\u7D50\u63D0\u6848: {
      adHearingAbility: {
        minScore: 0,
        maxScore: 5,
        weight: 0.2,
        description: "\u30AF\u30E9\u30A4\u30A2\u30F3\u30C8\u306EAD\u7DE0\u7D50\u30CB\u30FC\u30BA\u306E\u7406\u89E3"
      },
      adKnowledge: {
        minScore: 0,
        maxScore: 5,
        weight: 0.25,
        description: "\u30A2\u30C9\u30D0\u30A4\u30B6\u30EA\u30FC\u5951\u7D04\u306B\u95A2\u3059\u308B\u5C02\u9580\u77E5\u8B58"
      },
      adProposalAbility: {
        minScore: 0,
        maxScore: 5,
        weight: 0.25,
        description: "\u52B9\u679C\u7684\u306A\u63D0\u6848\u66F8\u4F5C\u6210\u3068\u8AAC\u660E\u80FD\u529B"
      },
      adNegotiation: {
        minScore: 0,
        maxScore: 5,
        weight: 0.2,
        description: "\u5951\u7D04\u6761\u4EF6\u306E\u4EA4\u6E09\u529B"
      },
      adRelationshipBuilding: {
        minScore: 0,
        maxScore: 5,
        weight: 0.1,
        description: "\u9577\u671F\u7684\u306A\u95A2\u4FC2\u69CB\u7BC9\u3078\u306E\u914D\u616E"
      }
    },
    \u4F01\u696D\u6982\u8981\u66F8\u63D0\u6848: {
      needsHearing: {
        minScore: 0,
        maxScore: 5,
        weight: 0.2,
        description: "\u30CB\u30FC\u30BA\u30D2\u30A2\u30EA\u30F3\u30B0\u3068\u63D0\u6848\u529B"
      },
      transferCompanyUnderstanding: {
        minScore: 0,
        maxScore: 5,
        weight: 0.25,
        description: "\u8B72\u6E21\u4F01\u696D\u306E\u4E8B\u696D\u7406\u89E3"
      },
      acquirerCompanyUnderstanding: {
        minScore: 0,
        maxScore: 5,
        weight: 0.25,
        description: "\u8B72\u53D7\u4F01\u696D\u306E\u4E8B\u696D\u7406\u89E3"
      },
      synergyProposal: {
        minScore: 0,
        maxScore: 5,
        weight: 0.2,
        description: "\u60F3\u5B9A\u30B7\u30CA\u30B8\u30FC\u52B9\u679C\u63D0\u6848"
      },
      testClosing: {
        minScore: 0,
        maxScore: 5,
        weight: 0.1,
        description: "\u30C6\u30B9\u30C8\u30AF\u30ED\u30FC\u30B8\u30F3\u30B0"
      }
    },
    \u8B72\u6E21\u67B6\u96FB: {
      voiceTone: {
        minScore: 0,
        maxScore: 5,
        weight: 0.2,
        description: "\u58F0\u306E\u30C8\u30FC\u30F3"
      },
      backChanneling: {
        minScore: 0,
        maxScore: 5,
        weight: 0.15,
        description: "\u3042\u3044\u3065\u3061"
      },
      scheduleConfirmation: {
        minScore: 0,
        maxScore: 5,
        weight: 0.25,
        description: "\u65E5\u7A0B\u78BA\u5B9A"
      },
      keyInformationHearing: {
        minScore: 0,
        maxScore: 5,
        weight: 0.25,
        description: "\u91CD\u8981\u4E8B\u9805\u30D2\u30A2\u30EA\u30F3\u30B0"
      },
      deepHearing: {
        minScore: 0,
        maxScore: 5,
        weight: 0.15,
        description: "\u6DF1\u6398\u308A\u30D2\u30A2\u30EA\u30F3\u30B0"
      }
    }
  };
});

// convex/evaluationConstants.ts
p();
var m = ["M&A\u30ED\u30FC\u30EB\u30D7\u30EC\u30A4", "\u521D\u56DE\u9762\u8AC7", "AD\u7DE0\u7D50\u63D0\u6848", "AD\u7DE0\u7D50\u63D0\u6848", "\u4F01\u696D\u6982\u8981\u66F8\u63D0\u6848", "\u8B72\u6E21\u67B6\u96FB"], l = ["pending", "processing", "completed", "failed"], d = ["\u5408\u683C", "\u8981\u6539\u5584", "\u4E0D\u5408\u683C", "\u51E6\u7406\u4E2D", "\u30A8\u30E9\u30FC"], g = e.union(
  e.literal("M&A\u30ED\u30FC\u30EB\u30D7\u30EC\u30A4"),
  e.literal("\u521D\u56DE\u9762\u8AC7"),
  e.literal("AD\u7DE0\u7D50\u63D0\u6848"),
  e.literal("AD\u7DE0\u7D50\u63D0\u6848"),
  e.literal("\u4F01\u696D\u6982\u8981\u66F8\u63D0\u6848"),
  e.literal("\u8B72\u6E21\u67B6\u96FB")
), C = e.union(
  e.literal("pending"),
  e.literal("processing"),
  e.literal("completed"),
  e.literal("failed")
), D = e.union(
  e.literal("\u5408\u683C"),
  e.literal("\u8981\u6539\u5584"),
  e.literal("\u4E0D\u5408\u683C"),
  e.literal("\u51E6\u7406\u4E2D"),
  e.literal("\u30A8\u30E9\u30FC")
), A = {
  // タイムアウト設定
  DEFAULT_TIMEOUT_MS: 3e5,
  // 5分
  SCHEDULER_DELAY_MS: 0,
  // リトライ設定
  MAX_RETRY_COUNT: 3,
  RETRY_DELAY_MS: 5e3,
  // バッチ処理設定
  BATCH_SIZE: 100,
  MAX_CONCURRENT_EVALUATIONS: 10,
  // スコア設定（5点満点、0.5点刻み）
  MIN_SCORE: 0,
  MAX_SCORE: 5,
  PASSING_SCORE: 3.5,
  ERROR_DEFAULT_SCORE: 0,
  // エラー時のデフォルト評価値
  // パフォーマンス設定
  QUERY_LIMIT: 1e3,
  PAGINATION_SIZE: 50
}, x = {
  // 認証エラー
  UNAUTHORIZED: "UNAUTHORIZED",
  ACCESS_DENIED: "ACCESS_DENIED",
  // パラメータエラー
  MISSING_REQUIRED_PARAMS: "MISSING_REQUIRED_PARAMS",
  INVALID_VIDEO_TYPE: "INVALID_VIDEO_TYPE",
  // データエラー
  TRANSCRIPTION_NOT_FOUND: "TRANSCRIPTION_NOT_FOUND",
  TRANSCRIPTION_ERROR: "TRANSCRIPTION_ERROR",
  EVALUATION_NOT_FOUND: "EVALUATION_NOT_FOUND",
  EVALUATION_RECORD_NOT_FOUND: "EVALUATION_RECORD_NOT_FOUND",
  // 処理エラー
  SCHEDULER_ERROR: "SCHEDULER_ERROR",
  EVALUATION_FAILED: "EVALUATION_FAILED",
  PROCESSING_ERROR: "PROCESSING_ERROR",
  // システムエラー
  USER_ID_ERROR: "USER_ID_ERROR",
  DATABASE_ERROR: "DATABASE_ERROR",
  INTERNAL_ERROR: "INTERNAL_ERROR"
}, a = null;
function T() {
  return a || (a = s()), a;
}
t(T, "loadEvaluationCriteria");
var u = T(), y = {
  // インデックス使用優先順位
  INDEX_PRIORITIES: [
    "by_status_and_user",
    "by_video_type_and_status",
    "by_user_and_video_type",
    "by_status_and_created",
    "by_user_and_created"
  ],
  // クエリ最適化
  PREFER_INDEX_SCAN: !0,
  ENABLE_PARALLEL_QUERIES: !0,
  // キャッシュ設定
  CACHE_TTL_SECONDS: 300,
  // 5分
  ENABLE_RESULT_CACHING: !0
};
function U(i) {
  return typeof i == "string" && m.includes(i);
}
t(U, "isValidVideoType");
function h(i) {
  return typeof i == "string" && l.includes(i);
}
t(h, "isValidEvaluationStatus");
function w(i) {
  return typeof i == "string" && d.includes(i);
}
t(w, "isValidRecommendation");
function O(i) {
  return u[i];
}
t(O, "getEvaluationCriteriaForType");
function L(i, n) {
  let r = O(n);
  if (!r) return 0;
  let o = 0, c = 0;
  return Object.entries(r).forEach(([E, S]) => {
    i[E] !== void 0 && (c += i[E] * S.weight, o += S.weight);
  }), o > 0 ? Math.round(c / o * 2) / 2 : 0;
}
t(L, "calculateWeightedScore");
function f(i) {
  let n = Date.now(), r = i.replace(/[^a-zA-Z0-9]/g, "");
  return `eval-${n}-${r}`;
}
t(f, "generateExternalEvaluationId");
function V(i) {
  return i >= A.PASSING_SCORE ? "\u5408\u683C" : i >= 2.5 ? "\u8981\u6539\u5584" : "\u4E0D\u5408\u683C";
}
t(V, "getRecommendationFromScore");

export {
  m as a,
  l as b,
  d as c,
  g as d,
  C as e,
  D as f,
  A as g,
  x as h,
  u as i,
  y as j,
  U as k,
  h as l,
  w as m,
  O as n,
  L as o,
  f as p,
  V as q
};
//# sourceMappingURL=SMJ6X5F7.js.map
