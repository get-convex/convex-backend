import {
  n as e,
  p as a
} from "./6XQQNYIR.js";
import {
  j as i,
  n as o
} from "./3TDUHHJO.js";

// convex/schema/training.ts
a();
o();
var t = i.union(
  i.literal("pending"),
  i.literal("in_progress"),
  i.literal("completed"),
  i.literal("failed")
), n = i.union(i.literal("high"), i.literal("medium"), i.literal("low")), r = i.union(
  i.literal("markdown"),
  i.literal("word"),
  i.literal("pdf"),
  i.literal("powerpoint"),
  i.literal("video"),
  i.literal("audio"),
  i.literal("quiz"),
  i.literal("interactive")
), d = {
  // === Core Training Management ===
  trainings: e({
    title: i.string(),
    description: i.optional(i.string()),
    category: i.optional(i.string()),
    durationMinutes: i.optional(i.number()),
    thumbnailUrl: i.optional(i.string()),
    priority: i.optional(n)
  }),
  courses: e({
    title: i.string(),
    description: i.string(),
    category: i.string(),
    durationMinutes: i.number(),
    thumbnailUrl: i.optional(i.string()),
    isPublished: i.boolean(),
    createdBy: i.id("users"),
    modulesCount: i.number()
  }).index("by_title", ["title"]).index("by_category", ["category"]).index("by_creator", ["createdBy"]).index("by_published", ["isPublished"]).index("by_category_published", ["category", "isPublished"]),
  modules: e({
    courseId: i.id("courses"),
    title: i.string(),
    description: i.string(),
    durationMinutes: i.number(),
    orderIndex: i.number(),
    contentType: r,
    contentUrl: i.optional(i.string()),
    isPublished: i.boolean()
  }).index("by_course", ["courseId"]).index("by_course_order", ["courseId", "orderIndex"]).index("by_content_type", ["contentType"]),
  trainingModules: e({
    trainingId: i.id("trainings"),
    title: i.string(),
    description: i.optional(i.string()),
    content: i.optional(i.string()),
    contentType: r,
    fileUrl: i.optional(i.string()),
    fileType: i.optional(i.string()),
    durationMinutes: i.optional(i.number()),
    orderIndex: i.number(),
    quizGenerationStatus: i.optional(t),
    quizGenerationStartedAt: i.optional(i.number()),
    quizGenerationCompletedAt: i.optional(i.number()),
    quizGenerationError: i.optional(i.string()),
    transcriptionStatus: i.optional(t),
    transcriptionStartedAt: i.optional(i.number()),
    transcriptionCompletedAt: i.optional(i.number()),
    transcriptionError: i.optional(i.string())
  }).index("by_training_id", ["trainingId"]),
  // === Progress Tracking ===
  trainingProgress: e({
    userId: i.id("users"),
    trainingId: i.id("trainings"),
    moduleId: i.optional(i.id("trainingModules")),
    status: t,
    progressPercentage: i.number(),
    startedAt: i.optional(i.number()),
    completedAt: i.optional(i.number())
  }).index("by_user_training", ["userId", "trainingId"]).index("by_user_module", ["userId", "moduleId"]),
  // === Roleplay System ===
  roleplays: e({
    title: i.string(),
    description: i.optional(i.string()),
    type: i.string(),
    status: i.union(
      i.literal("draft"),
      i.literal("scheduled"),
      i.literal("active"),
      i.literal("completed"),
      i.literal("cancelled")
    ),
    maxParticipants: i.optional(i.number()),
    scheduledAt: i.optional(i.number()),
    completedAt: i.optional(i.number())
  }),
  roleplayParticipants: e({
    roleplayId: i.id("roleplays"),
    userId: i.id("users"),
    isCreator: i.boolean(),
    role: i.optional(i.string())
  }).index("by_roleplay_id", ["roleplayId"]),
  // PHASE 3 COMPLETED: roleplayMaterials table safely deleted
  // No roleplay materials data existed in the system
  // Migration completed: Roleplay materials system removed
  // === Quiz System ===
  moduleQuizzes: e({
    moduleId: i.id("trainingModules"),
    title: i.string(),
    description: i.optional(i.string())
  }).index("by_module_id", ["moduleId"]),
  quizQuestions: e({
    quizId: i.id("moduleQuizzes"),
    questionText: i.string(),
    questionType: i.union(
      i.literal("multiple_choice"),
      i.literal("true_false"),
      i.literal("short_answer"),
      i.literal("essay")
    ),
    options: i.optional(
      i.array(
        i.object({
          value: i.string(),
          label: i.string(),
          isCorrect: i.optional(i.boolean())
        })
      )
    ),
    correctAnswer: i.optional(i.string()),
    explanation: i.optional(i.string())
  }).index("by_quiz_id", ["quizId"]),
  quizAttempts: e({
    userId: i.id("users"),
    quizId: i.id("moduleQuizzes"),
    answers: i.string(),
    isPassed: i.boolean(),
    score: i.optional(i.number()),
    attemptedAt: i.optional(i.number())
  }).index("by_user_quiz", ["userId", "quizId"]),
  // === Reviews & Feedback ===
  videoReviews: e({
    videoId: i.id("videos"),
    userId: i.id("users"),
    rating: i.optional(i.number()),
    comments: i.optional(i.string()),
    reviewedAt: i.optional(i.number())
  }).index("by_video_id", ["videoId"]),
  // === User Settings ===
  userSettings: e({
    userId: i.id("users"),
    theme: i.union(i.literal("light"), i.literal("dark"), i.literal("system")),
    language: i.string(),
    timezone: i.string(),
    dashboardLayout: i.optional(i.string()),
    itemsPerPage: i.number(),
    defaultChartPeriod: i.string(),
    videoQuality: i.union(i.literal("high"), i.literal("medium"), i.literal("low")),
    enableSubtitles: i.boolean(),
    learningReminder: i.boolean(),
    reminderTime: i.optional(i.string()),
    reminderDays: i.optional(
      i.array(
        i.union(
          i.literal("monday"),
          i.literal("tuesday"),
          i.literal("wednesday"),
          i.literal("thursday"),
          i.literal("friday"),
          i.literal("saturday"),
          i.literal("sunday")
        )
      )
    ),
    sessionTimeoutMinutes: i.number(),
    twoFactorEnabled: i.boolean(),
    loginNotification: i.boolean(),
    autoSaveEnabled: i.boolean(),
    autoSaveIntervalSeconds: i.number(),
    showTips: i.boolean()
  }).index("by_user_id", ["userId"]),
  // === Case Management ===
  cases: e({
    title: i.string(),
    companyName: i.string(),
    description: i.optional(i.string()),
    status: i.union(
      i.literal("active"),
      i.literal("completed"),
      i.literal("on_hold"),
      i.literal("cancelled")
    ),
    createdBy: i.id("users"),
    assignedTo: i.optional(i.id("users")),
    overallProgress: i.number(),
    priority: n,
    dueDate: i.optional(i.number()),
    interviewData: i.optional(i.string())
  }).index("by_assigned_to", ["assignedTo"]).index("by_created_by", ["createdBy"]).index("by_status", ["status"]).index("by_priority", ["priority"]),
  caseProgress: e({
    caseId: i.id("cases"),
    itemId: i.string(),
    category: i.string(),
    label: i.string(),
    description: i.optional(i.string()),
    weight: i.number(),
    priority: n,
    status: i.union(
      i.literal("completed"),
      i.literal("partial"),
      i.literal("missing"),
      i.literal("in_progress")
    ),
    completedAt: i.optional(i.number()),
    notes: i.optional(i.string()),
    collectedData: i.optional(i.string())
  }).index("by_case_id", ["caseId"]).index("by_status", ["status"]).index("by_priority", ["priority"]).index("by_case_status", ["caseId", "status"]),
  // === Content Summaries ===
  trainingSummaries: e({
    trainingId: i.id("trainings"),
    summary: i.string(),
    contentHash: i.optional(i.string()),
    lastUpdatedContentId: i.optional(i.number()),
    aiModel: i.string(),
    generatedAt: i.optional(i.number())
  }).index("by_training_id", ["trainingId"]),
  rateLimitRecords: e({
    userId: i.string(),
    action: i.string(),
    count: i.number(),
    windowStart: i.number()
  }).index("by_user_action", ["userId", "action"]).index("by_window_start", ["windowStart"])
};

export {
  d as a
};
//# sourceMappingURL=XWLI6SKB.js.map
