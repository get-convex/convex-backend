import {
  j as a
} from "./MNKTBR2W.js";
import {
  a as n
} from "./RUVYHBJQ.js";

// convex/lib/chatUtils.ts
function o() {
  return Date.now();
}
n(o, "createTimestamp");
function m(t, e = 1e4) {
  return t.trim().length === 0 ? { isValid: !1, error: "\u30E1\u30C3\u30BB\u30FC\u30B8\u3092\u5165\u529B\u3057\u3066\u304F\u3060\u3055\u3044\u3002" } : t.length > e ? {
    isValid: !1,
    error: `\u30E1\u30C3\u30BB\u30FC\u30B8\u306F${e.toLocaleString()}\u6587\u5B57\u4EE5\u5185\u3067\u5165\u529B\u3057\u3066\u304F\u3060\u3055\u3044\u3002`
  } : { isValid: !0 };
}
n(m, "validateMessageLength");
function u(t, e = "\u64CD\u4F5C") {
  let r = t instanceof Error ? t.message : `${e}\u306B\u5931\u6557\u3057\u307E\u3057\u305F\u3002`, s = "INTERNAL_ERROR";
  if (t instanceof Error) {
    let i = t.message.toLowerCase();
    i.includes("\u8A8D\u8A3C") ? s = "AUTHENTICATION_REQUIRED" : i.includes("\u30E6\u30FC\u30B6\u30FC") ? s = "USER_NOT_FOUND" : i.includes("\u6A29\u9650") || i.includes("access denied") ? s = "PERMISSION_DENIED" : i.includes("\u30BB\u30C3\u30B7\u30E7\u30F3") ? s = "SESSION_NOT_FOUND" : i.includes("\u30E1\u30C3\u30BB\u30FC\u30B8") ? i.includes("\u9577\u3059\u304E") || i.includes("\u6587\u5B57\u4EE5\u5185") ? s = "MESSAGE_TOO_LONG" : i.includes("\u5165\u529B\u3057\u3066") ? s = "MESSAGE_EMPTY" : s = "MESSAGE_SEND_FAILED" : e.includes("\u30BB\u30C3\u30B7\u30E7\u30F3") && i.includes("\u5931\u6557") && (s = "SESSION_CREATION_FAILED");
  }
  return { errorCode: s, errorMessage: r };
}
n(u, "standardErrorHandler");
async function c(t, e) {
  try {
    await t.db.insert("chatActivityLogs", {
      session_id: e.sessionId,
      user_id: e.userId,
      action: e.action,
      timestamp: Date.now(),
      metadata: e.metadata ? JSON.stringify(e.metadata) : void 0
    });
  } catch (r) {
    console.warn("Failed to log activity:", r);
  }
}
n(c, "scheduleLogActivity");
async function f(t, e) {
  let r = await t.db.query("chatSessions").withIndex("by_session_id", (s) => s.eq("session_id", e)).unique();
  r && await t.db.patch(r._id, {
    last_message_at: o()
  });
}
n(f, "updateSessionLastMessage");
function p(t) {
  return /^https:\/\/hooks\.slack\.com\/services\/T[A-Z0-9]+\/B[A-Z0-9]+\/[a-zA-Z0-9]+$/.test(t);
}
n(p, "validateSlackWebhookUrl");
function E(t, e = 50, r = 100) {
  return Math.min(t || e, r);
}
n(E, "applyLimit");
function l(t, e) {
  return {
    timestamp: o(),
    messageLength: t.length,
    ...e
  };
}
n(l, "createMessageMetadata");
function I(t, e, r) {
  return l(t, {
    generated: !0,
    modelVersion: e,
    responseTime: r
  });
}
n(I, "createAIResponseMetadata");
async function h(t, e, r) {
  console.error(`Error in ${r.operation}:`, e);
  let { errorCode: s, errorMessage: i } = u(e, r.operation);
  return r.sessionId && "scheduler" in t && await c(t, {
    sessionId: r.sessionId,
    userId: r.userId,
    action: "error",
    metadata: { errorCode: s, operation: r.operation }
  }), a(s, i);
}
n(h, "handleErrorWithLogging");
var d = class {
  static {
    n(this, "ResponseTimer");
  }
  startTime;
  constructor() {
    this.startTime = o();
  }
  getElapsedTime() {
    return o() - this.startTime;
  }
  createMetadataWithTime(e) {
    return {
      responseTime: this.getElapsedTime(),
      ...e
    };
  }
};

export {
  o as a,
  m as b,
  u as c,
  c as d,
  f as e,
  p as f,
  E as g,
  l as h,
  I as i,
  h as j,
  d as k
};
//# sourceMappingURL=RYP3LOHW.js.map
