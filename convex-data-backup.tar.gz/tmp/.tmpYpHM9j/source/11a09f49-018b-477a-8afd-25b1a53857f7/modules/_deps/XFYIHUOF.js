import {
  b as u
} from "./K6BAPRLZ.js";
import {
  b as o
} from "./SZVQRWFS.js";
import {
  a as m,
  c
} from "./75JH2J25.js";
import {
  j as e,
  n as g
} from "./3TDUHHJO.js";
import {
  a as n
} from "./RUVYHBJQ.js";

// convex/videos/summary.ts
g();
var p = m({
  args: {
    videoId: e.id("videos")
  },
  returns: e.union(
    e.object({
      success: e.literal(!0),
      data: e.object({
        video: e.object({
          id: e.id("videos"),
          title: e.string(),
          type: e.optional(e.string())
        }),
        transcription: e.object({
          id: e.id("transcriptions"),
          hasText: e.boolean()
        }),
        caseSummary: e.object({
          data: e.any(),
          status: e.string(),
          generatedAt: e.union(e.number(), e.null()),
          isAvailable: e.boolean()
        })
      })
    }),
    e.object({
      success: e.literal(!1),
      message: e.string()
    })
  ),
  handler: /* @__PURE__ */ n(async (a, r) => {
    await o(a);
    try {
      let t = await a.db.get(r.videoId);
      if (!t)
        return {
          success: !1,
          message: "\u6307\u5B9A\u3055\u308C\u305F\u52D5\u753B\u304C\u898B\u3064\u304B\u308A\u307E\u305B\u3093"
        };
      let s = await a.db.query("transcriptions").withIndex("by_video_id", (d) => d.eq("video_id", r.videoId)).first();
      if (!s)
        return {
          success: !1,
          message: "\u6587\u5B57\u8D77\u3053\u3057\u30C7\u30FC\u30BF\u304C\u898B\u3064\u304B\u308A\u307E\u305B\u3093\u3002\u5148\u306B\u6587\u5B57\u8D77\u3053\u3057\u3092\u5B9F\u884C\u3057\u3066\u304F\u3060\u3055\u3044"
        };
      let i = u(
        s.case_summary,
        s.case_summary_status,
        s.case_summary_generated_at
      );
      return {
        success: !0,
        data: {
          video: {
            id: t._id,
            title: t.title,
            type: t.type
          },
          transcription: {
            id: s._id,
            hasText: !!s.text
          },
          caseSummary: i
        }
      };
    } catch (t) {
      return console.error("[getCaseSummary] \u30A8\u30E9\u30FC:", t), {
        success: !1,
        message: "\u6848\u4EF6\u5316\u60C5\u5831\u30B5\u30DE\u30EA\u30FC\u306E\u53D6\u5F97\u4E2D\u306B\u30A8\u30E9\u30FC\u304C\u767A\u751F\u3057\u307E\u3057\u305F"
      };
    }
  }, "handler")
}), b = c({
  args: {
    videoId: e.id("videos"),
    forceRegenerate: e.optional(e.boolean())
  },
  returns: e.union(
    e.object({
      success: e.literal(!0),
      message: e.string(),
      data: e.optional(
        e.object({
          caseSummary: e.any(),
          isRegenerated: e.boolean()
        })
      )
    }),
    e.object({
      success: e.literal(!1),
      message: e.string()
    })
  ),
  handler: /* @__PURE__ */ n(async (a, r) => {
    await o(a);
    try {
      if (!await a.db.get(r.videoId))
        return {
          success: !1,
          message: "\u6307\u5B9A\u3055\u308C\u305F\u52D5\u753B\u304C\u898B\u3064\u304B\u308A\u307E\u305B\u3093"
        };
      let s = await a.db.query("transcriptions").withIndex("by_video_id", (i) => i.eq("video_id", r.videoId)).first();
      if (!s)
        return {
          success: !1,
          message: "\u6587\u5B57\u8D77\u3053\u3057\u30C7\u30FC\u30BF\u304C\u898B\u3064\u304B\u308A\u307E\u305B\u3093\u3002\u5148\u306B\u6587\u5B57\u8D77\u3053\u3057\u3092\u5B9F\u884C\u3057\u3066\u304F\u3060\u3055\u3044"
        };
      if (s.case_summary_status === "completed" && s.case_summary && !r.forceRegenerate) {
        let i = u(
          s.case_summary,
          s.case_summary_status,
          s.case_summary_generated_at
        );
        if (i.data)
          return {
            success: !0,
            message: "\u6848\u4EF6\u5316\u60C5\u5831\u30B5\u30DE\u30EA\u30FC\u306F\u65E2\u306B\u751F\u6210\u6E08\u307F\u3067\u3059",
            data: {
              caseSummary: i.data,
              isRegenerated: !1
            }
          };
      }
      return !s.text || s.text.trim().length < 10 ? {
        success: !1,
        message: "\u6587\u5B57\u8D77\u3053\u3057\u30C6\u30AD\u30B9\u30C8\u304C\u4E0D\u5341\u5206\u3067\u3059\u3002\u5341\u5206\u306A\u9577\u3055\u306E\u4F1A\u8A71\u304C\u5FC5\u8981\u3067\u3059"
      } : (await a.db.patch(s._id, {
        case_summary_status: "processing",
        case_summary_processing_started_at: Date.now()
      }), console.log(
        `[generateCaseSummary] \u6848\u4EF6\u30B5\u30DE\u30EA\u30FC\u751F\u6210\u958B\u59CB (Transcription ID: ${s._id})`
      ), {
        success: !0,
        message: "\u6848\u4EF6\u5316\u60C5\u5831\u30B5\u30DE\u30EA\u30FC\u306E\u751F\u6210\u3092\u958B\u59CB\u3057\u307E\u3057\u305F"
      });
    } catch (t) {
      return console.error("[generateCaseSummary] \u30A8\u30E9\u30FC:", t), {
        success: !1,
        message: "\u6848\u4EF6\u5316\u60C5\u5831\u30B5\u30DE\u30EA\u30FC\u306E\u751F\u6210\u4E2D\u306B\u30A8\u30E9\u30FC\u304C\u767A\u751F\u3057\u307E\u3057\u305F"
      };
    }
  }, "handler")
}), v = c({
  args: {
    videoId: e.id("videos")
  },
  returns: e.union(
    e.object({
      success: e.literal(!0),
      message: e.string()
    }),
    e.object({
      success: e.literal(!1),
      message: e.string()
    })
  ),
  handler: /* @__PURE__ */ n(async (a, r) => {
    await o(a);
    try {
      let t = await a.db.query("transcriptions").withIndex("by_video_id", (s) => s.eq("video_id", r.videoId)).first();
      return t ? (await a.db.patch(t._id, {
        case_summary_status: "pending"
      }), {
        success: !0,
        message: "\u6848\u4EF6\u5316\u60C5\u5831\u30B5\u30DE\u30EA\u30FC\u3092\u524A\u9664\u3057\u307E\u3057\u305F"
      }) : {
        success: !1,
        message: "\u6587\u5B57\u8D77\u3053\u3057\u30C7\u30FC\u30BF\u304C\u898B\u3064\u304B\u308A\u307E\u305B\u3093"
      };
    } catch (t) {
      return console.error("[deleteCaseSummary] \u30A8\u30E9\u30FC:", t), {
        success: !1,
        message: "\u6848\u4EF6\u5316\u60C5\u5831\u30B5\u30DE\u30EA\u30FC\u306E\u524A\u9664\u4E2D\u306B\u30A8\u30E9\u30FC\u304C\u767A\u751F\u3057\u307E\u3057\u305F"
      };
    }
  }, "handler")
}), h = m({
  args: {
    videoId: e.id("videos")
  },
  returns: e.union(
    e.object({
      success: e.literal(!0),
      data: e.object({
        video: e.object({
          id: e.id("videos"),
          title: e.string(),
          type: e.optional(e.string())
        }),
        transcription: e.object({
          id: e.id("transcriptions"),
          hasText: e.boolean()
        }),
        meetingSummary: e.object({
          data: e.any(),
          status: e.string(),
          generatedAt: e.union(e.number(), e.null()),
          isAvailable: e.boolean()
        })
      })
    }),
    e.object({
      success: e.literal(!1),
      message: e.string()
    })
  ),
  handler: /* @__PURE__ */ n(async (a, r) => {
    await o(a);
    try {
      let t = await a.db.get(r.videoId);
      if (!t)
        return {
          success: !1,
          message: "\u6307\u5B9A\u3055\u308C\u305F\u52D5\u753B\u304C\u898B\u3064\u304B\u308A\u307E\u305B\u3093"
        };
      let s = await a.db.query("transcriptions").withIndex("by_video_id", (d) => d.eq("video_id", r.videoId)).first();
      if (!s)
        return {
          success: !1,
          message: "\u6587\u5B57\u8D77\u3053\u3057\u30C7\u30FC\u30BF\u304C\u898B\u3064\u304B\u308A\u307E\u305B\u3093\u3002\u5148\u306B\u6587\u5B57\u8D77\u3053\u3057\u3092\u5B9F\u884C\u3057\u3066\u304F\u3060\u3055\u3044"
        };
      let i = u(
        s.meeting_summary,
        s.meeting_summary_status,
        s.meeting_summary_generated_at
      );
      return {
        success: !0,
        data: {
          video: {
            id: t._id,
            title: t.title,
            type: t.type
          },
          transcription: {
            id: s._id,
            hasText: !!s.text
          },
          meetingSummary: i
        }
      };
    } catch (t) {
      return console.error("[getMeetingSummary] \u30A8\u30E9\u30FC:", t), {
        success: !1,
        message: "\u5546\u8AC7\u8A18\u9332\u30B5\u30DE\u30EA\u30FC\u306E\u53D6\u5F97\u4E2D\u306B\u30A8\u30E9\u30FC\u304C\u767A\u751F\u3057\u307E\u3057\u305F"
      };
    }
  }, "handler")
}), w = c({
  args: {
    videoId: e.id("videos"),
    forceRegenerate: e.optional(e.boolean())
  },
  returns: e.union(
    e.object({
      success: e.literal(!0),
      message: e.string(),
      data: e.optional(
        e.object({
          meetingSummary: e.any(),
          isRegenerated: e.boolean()
        })
      )
    }),
    e.object({
      success: e.literal(!1),
      message: e.string()
    })
  ),
  handler: /* @__PURE__ */ n(async (a, r) => {
    await o(a);
    try {
      if (!await a.db.get(r.videoId))
        return {
          success: !1,
          message: "\u6307\u5B9A\u3055\u308C\u305F\u52D5\u753B\u304C\u898B\u3064\u304B\u308A\u307E\u305B\u3093"
        };
      let s = await a.db.query("transcriptions").withIndex("by_video_id", (i) => i.eq("video_id", r.videoId)).first();
      if (!s)
        return {
          success: !1,
          message: "\u6587\u5B57\u8D77\u3053\u3057\u30C7\u30FC\u30BF\u304C\u898B\u3064\u304B\u308A\u307E\u305B\u3093\u3002\u5148\u306B\u6587\u5B57\u8D77\u3053\u3057\u3092\u5B9F\u884C\u3057\u3066\u304F\u3060\u3055\u3044"
        };
      if (s.meeting_summary_status === "completed" && s.meeting_summary && !r.forceRegenerate) {
        let i = u(
          s.meeting_summary,
          s.meeting_summary_status,
          s.meeting_summary_generated_at
        );
        if (i.data)
          return {
            success: !0,
            message: "\u5546\u8AC7\u8A18\u9332\u30B5\u30DE\u30EA\u30FC\u306F\u65E2\u306B\u751F\u6210\u6E08\u307F\u3067\u3059",
            data: {
              meetingSummary: i.data,
              isRegenerated: !1
            }
          };
      }
      return !s.text || s.text.trim().length < 10 ? {
        success: !1,
        message: "\u6587\u5B57\u8D77\u3053\u3057\u30C6\u30AD\u30B9\u30C8\u304C\u4E0D\u5341\u5206\u3067\u3059\u3002\u5341\u5206\u306A\u9577\u3055\u306E\u4F1A\u8A71\u304C\u5FC5\u8981\u3067\u3059"
      } : (await a.db.patch(s._id, {
        meeting_summary_status: "processing",
        meeting_summary_processing_started_at: Date.now()
      }), console.log(
        `[generateMeetingSummary] \u5546\u8AC7\u30B5\u30DE\u30EA\u30FC\u751F\u6210\u958B\u59CB (Transcription ID: ${s._id})`
      ), {
        success: !0,
        message: "\u5546\u8AC7\u8A18\u9332\u30B5\u30DE\u30EA\u30FC\u306E\u751F\u6210\u3092\u958B\u59CB\u3057\u307E\u3057\u305F"
      });
    } catch (t) {
      return console.error("[generateMeetingSummary] \u30A8\u30E9\u30FC:", t), {
        success: !1,
        message: "\u5546\u8AC7\u8A18\u9332\u30B5\u30DE\u30EA\u30FC\u306E\u751F\u6210\u4E2D\u306B\u30A8\u30E9\u30FC\u304C\u767A\u751F\u3057\u307E\u3057\u305F"
      };
    }
  }, "handler")
}), I = c({
  args: {
    videoId: e.id("videos")
  },
  returns: e.union(
    e.object({
      success: e.literal(!0),
      message: e.string()
    }),
    e.object({
      success: e.literal(!1),
      message: e.string()
    })
  ),
  handler: /* @__PURE__ */ n(async (a, r) => {
    await o(a);
    try {
      let t = await a.db.query("transcriptions").withIndex("by_video_id", (s) => s.eq("video_id", r.videoId)).first();
      return t ? (await a.db.patch(t._id, {
        meeting_summary_status: "pending"
      }), {
        success: !0,
        message: "\u5546\u8AC7\u8A18\u9332\u30B5\u30DE\u30EA\u30FC\u3092\u524A\u9664\u3057\u307E\u3057\u305F"
      }) : {
        success: !1,
        message: "\u6587\u5B57\u8D77\u3053\u3057\u30C7\u30FC\u30BF\u304C\u898B\u3064\u304B\u308A\u307E\u305B\u3093"
      };
    } catch (t) {
      return console.error("[deleteMeetingSummary] \u30A8\u30E9\u30FC:", t), {
        success: !1,
        message: "\u5546\u8AC7\u8A18\u9332\u30B5\u30DE\u30EA\u30FC\u306E\u524A\u9664\u4E2D\u306B\u30A8\u30E9\u30FC\u304C\u767A\u751F\u3057\u307E\u3057\u305F"
      };
    }
  }, "handler")
});

export {
  p as a,
  b,
  v as c,
  h as d,
  w as e,
  I as f
};
//# sourceMappingURL=XFYIHUOF.js.map
