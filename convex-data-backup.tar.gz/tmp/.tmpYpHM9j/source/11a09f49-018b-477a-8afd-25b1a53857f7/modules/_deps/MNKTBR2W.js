import {
  j as e,
  n as r
} from "./3TDUHHJO.js";
import {
  a as s
} from "./RUVYHBJQ.js";

// convex/lib/chatTypes.ts
r();
var a = e.object({
  success: e.literal(!0),
  data: e.record(e.string(), e.union(e.string(), e.number(), e.boolean())),
  // Flexible but type-safe
  timestamp: e.number()
}), m = /* @__PURE__ */ s((t) => e.object({
  success: e.literal(!0),
  data: t,
  timestamp: e.number()
}), "ChatSuccessResponseTyped"), c = e.object({
  success: e.literal(!1),
  error: e.object({
    code: e.string(),
    message: e.string(),
    details: e.optional(e.string())
  }),
  timestamp: e.number()
}), p = e.union(a, c), u = e.object({
  sessionId: e.string(),
  welcomeMessage: e.string()
}), N = e.object({
  message: e.string(),
  sessionId: e.string(),
  contextInfo: e.object({
    timestamp: e.number(),
    messageLength: e.number()
  })
}), i = e.object({
  timestamp: e.number(),
  messageLength: e.optional(e.number()),
  generated: e.optional(e.boolean()),
  modelVersion: e.optional(e.string()),
  responseTime: e.optional(e.number()),
  confidence: e.optional(e.number())
}), _ = e.object({
  _id: e.id("chatConversations"),
  _creationTime: e.number(),
  role: e.string(),
  message: e.string(),
  metadata: e.optional(i)
}), E = {
  AUTHENTICATION_REQUIRED: "AUTHENTICATION_REQUIRED",
  USER_NOT_FOUND: "USER_NOT_FOUND",
  SESSION_NOT_FOUND: "SESSION_NOT_FOUND",
  PERMISSION_DENIED: "PERMISSION_DENIED",
  MESSAGE_TOO_LONG: "MESSAGE_TOO_LONG",
  MESSAGE_EMPTY: "MESSAGE_EMPTY",
  SESSION_CREATION_FAILED: "SESSION_CREATION_FAILED",
  MESSAGE_SEND_FAILED: "MESSAGE_SEND_FAILED",
  INTERNAL_ERROR: "INTERNAL_ERROR"
};
function I(t, o, n) {
  return {
    success: !1,
    error: {
      code: E[t],
      message: o,
      details: n
    },
    timestamp: Date.now()
  };
}
s(I, "createErrorResponse");
function g(t) {
  return {
    success: !0,
    data: t,
    timestamp: Date.now()
  };
}
s(g, "createSuccessResponse");

export {
  a,
  m as b,
  c,
  p as d,
  u as e,
  N as f,
  i as g,
  _ as h,
  E as i,
  I as j,
  g as k
};
//# sourceMappingURL=MNKTBR2W.js.map
