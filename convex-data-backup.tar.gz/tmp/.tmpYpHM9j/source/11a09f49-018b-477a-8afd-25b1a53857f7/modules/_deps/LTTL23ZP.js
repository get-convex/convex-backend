import {
  a as t
} from "./RUVYHBJQ.js";

// convex/lib/hybridStorage.ts
var o = {
  CONVEX: "convex",
  GCS: "gcs",
  HYBRID: "hybrid"
};
function s(e) {
  return {
    sizes: ["small", "medium", "large", "poster"],
    formats: ["webp", "jpeg"],
    quality: 85,
    frameSelection: "optimal",
    analysisEnabled: !0
  };
}
t(s, "getDefaultThumbnailConfig");
function u(e, r, n = {}) {
  return e < 10 * 1024 * 1024 ? "convex" : e > 100 * 1024 * 1024 ? "gcs" : n.costOptimize ? "hybrid" : "convex";
}
t(u, "determineStorageStrategy");
function m(e) {
  return {
    totalCost: e.fileSize / 1024 / 1024 * 1e-3
  };
}
t(m, "estimateProcessingCost");
function l(e, r = {}) {
  let a = { ...{
    maxSize: 104857600,
    // 100MB
    allowedTypes: [
      "video/mp4",
      "video/webm",
      "video/mov",
      "audio/mp3",
      "audio/wav",
      "audio/m4a",
      "image/jpeg",
      "image/png"
    ],
    compressionEnabled: !0
  }, ...r }, i = [];
  return e.size > a.maxSize ? {
    valid: !1,
    error: `\u30D5\u30A1\u30A4\u30EB\u30B5\u30A4\u30BA\u304C\u4E0A\u9650\uFF08${Math.round(a.maxSize / 1024 / 1024)}MB\uFF09\u3092\u8D85\u3048\u3066\u3044\u307E\u3059`
  } : a.allowedTypes.includes(e.type) ? (e.size > 50 * 1024 * 1024 && i.push("\u5927\u304D\u306A\u30D5\u30A1\u30A4\u30EB\u3067\u3059\u3002\u30A2\u30C3\u30D7\u30ED\u30FC\u30C9\u306B\u6642\u9593\u304C\u304B\u304B\u308B\u5834\u5408\u304C\u3042\u308A\u307E\u3059"), e.type.startsWith("video/") && e.size > 200 * 1024 * 1024 && i.push("\u52D5\u753B\u30D5\u30A1\u30A4\u30EB\u304C\u5927\u304D\u3059\u304E\u307E\u3059\u3002\u51E6\u7406\u306B\u6642\u9593\u304C\u304B\u304B\u308B\u53EF\u80FD\u6027\u304C\u3042\u308A\u307E\u3059"), {
    valid: !0,
    warnings: i.length > 0 ? i : void 0
  }) : {
    valid: !1,
    error: `\u30B5\u30DD\u30FC\u30C8\u3055\u308C\u3066\u3044\u306A\u3044\u30D5\u30A1\u30A4\u30EB\u5F62\u5F0F\u3067\u3059: ${e.type}`
  };
}
t(l, "validateFileUpload");
function g() {
  return {
    video: {
      quality: 80,
      bitrate: 2e3,
      resolution: "1280x720"
    },
    audio: {
      quality: 80,
      bitrate: 128,
      sampleRate: 44100
    },
    image: {
      quality: 85,
      maxWidth: 1920,
      maxHeight: 1080
    }
  };
}
t(g, "getDefaultCompressionConfig");

export {
  o as a,
  s as b,
  u as c,
  m as d,
  l as e,
  g as f
};
//# sourceMappingURL=LTTL23ZP.js.map
