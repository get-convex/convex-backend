import {
  n as i,
  p as n
} from "./6XQQNYIR.js";
import {
  j as e,
  n as t
} from "./3TDUHHJO.js";

// convex/schema/core.ts
n();
t();
var o = {
  // 統一ユーザーテーブル（Clerk認証ベース）
  users: i({
    // Clerk認証情報
    clerkUserId: e.string(),
    tokenIdentifier: e.string(),
    email: e.string(),
    emailVerified: e.boolean(),
    // ユーザープロフィール
    name: e.string(),
    firstName: e.optional(e.string()),
    lastName: e.optional(e.string()),
    imageUrl: e.optional(e.string()),
    // 企業関連情報
    employeeId: e.optional(e.string()),
    department: e.optional(e.string()),
    position: e.optional(e.string()),
    role: e.union(e.literal("admin"), e.literal("trainer"), e.literal("employee")),
    // アカウント管理
    isActive: e.boolean(),
    joinDate: e.number(),
    lastLoginAt: e.optional(e.number())
  }).index("by_clerk_user_id", ["clerkUserId"]).index("by_token", ["tokenIdentifier"]).index("by_email", ["email"]).index("by_role", ["role"]).index("by_is_active", ["isActive"]).index("by_department", ["department"]).index("by_employee_id", ["employeeId"]).index("by_role_active", ["role", "isActive"]).index("by_department_active", ["department", "isActive"]).searchIndex("search_users", {
    searchField: "name",
    filterFields: ["role", "department", "isActive"]
  }),
  // Clerkセッション管理
  userSessions: i({
    userId: e.id("users"),
    clerkSessionId: e.string(),
    deviceInfo: e.optional(e.string()),
    ipAddress: e.optional(e.string()),
    userAgent: e.optional(e.string()),
    expiresAt: e.number(),
    lastActivityAt: e.number(),
    isActive: e.boolean()
  }).index("by_user_id", ["userId"]).index("by_clerk_session_id", ["clerkSessionId"]).index("by_is_active", ["isActive"]).index("by_user_active", ["userId", "isActive"]).index("by_expires_at", ["expiresAt"]).index("by_last_activity", ["lastActivityAt"])
};

export {
  o as a
};
//# sourceMappingURL=VPLOFYF2.js.map
