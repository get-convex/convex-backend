import {
  a as s
} from "./RUVYHBJQ.js";

// convex/videos/auth.ts
async function a(t) {
  let r = await t.auth.getUserIdentity();
  if (!r)
    throw new Error("\u8A8D\u8A3C\u304C\u5FC5\u8981\u3067\u3059");
  return r;
}
s(a, "requireAuth");
async function o(t) {
  let r = await a(t), e = await t.db.query("users").withIndex("by_token", (n) => n.eq("tokenIdentifier", r.tokenIdentifier)).unique();
  if (!e)
    throw new Error("\u30E6\u30FC\u30B6\u30FC\u304C\u898B\u3064\u304B\u308A\u307E\u305B\u3093");
  return { identity: r, user: e };
}
s(o, "requireUser");
async function u(t, r) {
  let { user: e } = await o(t), n = await t.db.get(r);
  if (!n)
    throw new Error("\u52D5\u753B\u304C\u898B\u3064\u304B\u308A\u307E\u305B\u3093");
  if (n.user_id !== e._id)
    throw new Error("\u3053\u306E\u52D5\u753B\u306B\u30A2\u30AF\u30BB\u30B9\u3059\u308B\u6A29\u9650\u304C\u3042\u308A\u307E\u305B\u3093");
  return { video: n, user: e };
}
s(u, "requireVideoOwner");
async function y(t) {
  try {
    return {
      success: !0,
      identity: await t.auth.getUserIdentity()
    };
  } catch {
    return {
      success: !1,
      message: "\u8A8D\u8A3C\u304C\u5FC5\u8981\u3067\u3059"
    };
  }
}
s(y, "checkAuth");
async function w(t) {
  try {
    let { identity: r, user: e } = await o(t);
    return {
      success: !0,
      identity: r,
      user: e
    };
  } catch (r) {
    return {
      success: !1,
      message: r instanceof Error ? r.message : "\u8A8D\u8A3C\u30A8\u30E9\u30FC"
    };
  }
}
s(w, "checkUser");
async function x(t, r) {
  try {
    let { video: e, user: n } = await u(t, r);
    return {
      success: !0,
      video: e,
      user: n
    };
  } catch (e) {
    return {
      success: !1,
      message: e instanceof Error ? e.message : "\u6A29\u9650\u30A8\u30E9\u30FC"
    };
  }
}
s(x, "checkVideoOwner");
async function c(t, r, e) {
  if (r === e)
    return !1;
  let n = await t.db.get(e);
  for (let i = 0; i < 10 && n?.managerId; i++) {
    if (n.managerId === r)
      return !0;
    n = await t.db.get(n.managerId);
  }
  return !1;
}
s(c, "isManagerOf");
async function d(t, r) {
  let { user: e } = await o(t), n = await t.db.get(r);
  if (!n)
    throw new Error("\u52D5\u753B\u304C\u898B\u3064\u304B\u308A\u307E\u305B\u3093");
  let i = await t.db.get(n.user_id);
  if (!i)
    throw new Error("\u52D5\u753B\u30A2\u30C3\u30D7\u30ED\u30FC\u30C9\u8005\u304C\u898B\u3064\u304B\u308A\u307E\u305B\u3093");
  if (e.role === "admin")
    return { video: n, uploader: i, user: e };
  if (!await c(t, e._id, i._id))
    throw new Error("\u3053\u306E\u52D5\u753B\u306B\u30EC\u30D3\u30E5\u30FC\u3059\u308B\u6A29\u9650\u304C\u3042\u308A\u307E\u305B\u3093\u3002\u52D5\u753B\u30A2\u30C3\u30D7\u30ED\u30FC\u30C9\u8005\u306E\u4E0A\u9577\u307E\u305F\u306F\u7BA1\u7406\u8005\u3067\u3042\u308B\u5FC5\u8981\u304C\u3042\u308A\u307E\u3059\u3002");
  return { video: n, uploader: i, user: e };
}
s(d, "requireManagerOrAdmin");
async function h(t, r) {
  try {
    let { video: e, uploader: n, user: i } = await d(t, r);
    return {
      success: !0,
      video: e,
      uploader: n,
      user: i
    };
  } catch (e) {
    return {
      success: !1,
      message: e instanceof Error ? e.message : "\u6A29\u9650\u30A8\u30E9\u30FC"
    };
  }
}
s(h, "checkManagerOrAdmin");

export {
  a,
  o as b,
  u as c,
  y as d,
  w as e,
  x as f,
  d as g,
  h
};
//# sourceMappingURL=6HNJFR7B.js.map
