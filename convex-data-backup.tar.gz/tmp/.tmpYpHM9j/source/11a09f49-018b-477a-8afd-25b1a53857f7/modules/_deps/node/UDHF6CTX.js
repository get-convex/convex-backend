import {
  a as n
} from "./V7X2J7BI.js";

// node_modules/convex/dist/esm/values/base64.js
var E = [], b = [], bt = Uint8Array, he = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
for (C = 0, Re = he.length; C < Re; ++C)
  E[C] = he[C], b[he.charCodeAt(C)] = C;
var C, Re;
b[45] = 62;
b[95] = 63;
function vt(e) {
  var t = e.length;
  if (t % 4 > 0)
    throw new Error("Invalid string. Length must be a multiple of 4");
  var r = e.indexOf("=");
  r === -1 && (r = t);
  var o = r === t ? 0 : 4 - r % 4;
  return [r, o];
}
n(vt, "getLens");
function At(e, t, r) {
  return (t + r) * 3 / 4 - r;
}
n(At, "_byteLength");
function P(e) {
  var t, r = vt(e), o = r[0], s = r[1], i = new bt(At(e, o, s)), a = 0, p = s > 0 ? o - 4 : o, w;
  for (w = 0; w < p; w += 4)
    t = b[e.charCodeAt(w)] << 18 | b[e.charCodeAt(w + 1)] << 12 | b[e.charCodeAt(w + 2)] << 6 | b[e.charCodeAt(w + 3)], i[a++] = t >> 16 & 255, i[a++] = t >> 8 & 255, i[a++] = t & 255;
  return s === 2 && (t = b[e.charCodeAt(w)] << 2 | b[e.charCodeAt(w + 1)] >> 4, i[a++] = t & 255), s === 1 && (t = b[e.charCodeAt(w)] << 10 | b[e.charCodeAt(w + 1)] << 4 | b[e.charCodeAt(w + 2)] >> 2, i[a++] = t >> 8 & 255, i[a++] = t & 255), i;
}
n(P, "toByteArray");
function Et(e) {
  return E[e >> 18 & 63] + E[e >> 12 & 63] + E[e >> 6 & 63] + E[e & 63];
}
n(Et, "tripletToBase64");
function St(e, t, r) {
  for (var o, s = [], i = t; i < r; i += 3)
    o = (e[i] << 16 & 16711680) + (e[i + 1] << 8 & 65280) + (e[i + 2] & 255), s.push(Et(o));
  return s.join("");
}
n(St, "encodeChunk");
function B(e) {
  for (var t, r = e.length, o = r % 3, s = [], i = 16383, a = 0, p = r - o; a < p; a += i)
    s.push(
      St(
        e,
        a,
        a + i > p ? p : a + i
      )
    );
  return o === 1 ? (t = e[r - 1], s.push(E[t >> 2] + E[t << 4 & 63] + "==")) : o === 2 && (t = (e[r - 2] << 8) + e[r - 1], s.push(
    E[t >> 10] + E[t >> 4 & 63] + E[t << 2 & 63] + "="
  )), s.join("");
}
n(B, "fromByteArray");

// node_modules/convex/dist/esm/common/index.js
function S(e) {
  if (e === void 0)
    return {};
  if (!me(e))
    throw new Error(
      `The arguments to a Convex function must be an object. Received: ${e}`
    );
  return e;
}
n(S, "parseArgs");
function me(e) {
  let t = typeof e == "object", r = Object.getPrototypeOf(e), o = r === null || r === Object.prototype || // Objects generated from other contexts (e.g. across Node.js `vm` modules) will not satisfy the previous
  // conditions but are still simple objects.
  r?.constructor?.name === "Object";
  return t && o;
}
n(me, "isSimpleObject");

// node_modules/convex/dist/esm/values/value.js
var Me = !0, $ = BigInt("-9223372036854775808"), xe = BigInt("9223372036854775807"), we = BigInt("0"), Ct = BigInt("8"), Tt = BigInt("256");
function Ue(e) {
  return Number.isNaN(e) || !Number.isFinite(e) || Object.is(e, -0);
}
n(Ue, "isSpecial");
function _t(e) {
  e < we && (e -= $ + $);
  let t = e.toString(16);
  t.length % 2 === 1 && (t = "0" + t);
  let r = new Uint8Array(new ArrayBuffer(8)), o = 0;
  for (let s of t.match(/.{2}/g).reverse())
    r.set([parseInt(s, 16)], o++), e >>= Ct;
  return B(r);
}
n(_t, "slowBigIntToBase64");
function Ot(e) {
  let t = P(e);
  if (t.byteLength !== 8)
    throw new Error(
      `Received ${t.byteLength} bytes, expected 8 for $integer`
    );
  let r = we, o = we;
  for (let s of t)
    r += BigInt(s) * Tt ** o, o++;
  return r > xe && (r += $ + $), r;
}
n(Ot, "slowBase64ToBigInt");
function $t(e) {
  if (e < $ || xe < e)
    throw new Error(
      `BigInt ${e} does not fit into a 64-bit signed integer.`
    );
  let t = new ArrayBuffer(8);
  return new DataView(t).setBigInt64(0, e, !0), B(new Uint8Array(t));
}
n($t, "modernBigIntToBase64");
function It(e) {
  let t = P(e);
  if (t.byteLength !== 8)
    throw new Error(
      `Received ${t.byteLength} bytes, expected 8 for $integer`
    );
  return new DataView(t.buffer).getBigInt64(0, !0);
}
n(It, "modernBase64ToBigInt");
var Nt = DataView.prototype.setBigInt64 ? $t : _t, Pt = DataView.prototype.getBigInt64 ? It : Ot, qe = 1024;
function ge(e) {
  if (e.length > qe)
    throw new Error(
      `Field name ${e} exceeds maximum field name length ${qe}.`
    );
  if (e.startsWith("$"))
    throw new Error(`Field name ${e} starts with a '$', which is reserved.`);
  for (let t = 0; t < e.length; t += 1) {
    let r = e.charCodeAt(t);
    if (r < 32 || r >= 127)
      throw new Error(
        `Field name ${e} has invalid character '${e[t]}': Field names can only contain non-control ASCII characters`
      );
  }
}
n(ge, "validateObjectField");
function m(e) {
  if (e === null || typeof e == "boolean" || typeof e == "number" || typeof e == "string")
    return e;
  if (Array.isArray(e))
    return e.map((o) => m(o));
  if (typeof e != "object")
    throw new Error(`Unexpected type of ${e}`);
  let t = Object.entries(e);
  if (t.length === 1) {
    let o = t[0][0];
    if (o === "$bytes") {
      if (typeof e.$bytes != "string")
        throw new Error(`Malformed $bytes field on ${e}`);
      return P(e.$bytes).buffer;
    }
    if (o === "$integer") {
      if (typeof e.$integer != "string")
        throw new Error(`Malformed $integer field on ${e}`);
      return Pt(e.$integer);
    }
    if (o === "$float") {
      if (typeof e.$float != "string")
        throw new Error(`Malformed $float field on ${e}`);
      let s = P(e.$float);
      if (s.byteLength !== 8)
        throw new Error(
          `Received ${s.byteLength} bytes, expected 8 for $float`
        );
      let a = new DataView(s.buffer).getFloat64(0, Me);
      if (!Ue(a))
        throw new Error(`Float ${a} should be encoded as a number`);
      return a;
    }
    if (o === "$set")
      throw new Error(
        "Received a Set which is no longer supported as a Convex type."
      );
    if (o === "$map")
      throw new Error(
        "Received a Map which is no longer supported as a Convex type."
      );
  }
  let r = {};
  for (let [o, s] of Object.entries(e))
    ge(o), r[o] = m(s);
  return r;
}
n(m, "jsonToConvex");
function T(e) {
  return JSON.stringify(e, (t, r) => r === void 0 ? "undefined" : typeof r == "bigint" ? `${r.toString()}n` : r);
}
n(T, "stringifyValueForError");
function F(e, t, r, o) {
  if (e === void 0) {
    let a = r && ` (present at path ${r} in original object ${T(
      t
    )})`;
    throw new Error(
      `undefined is not a valid Convex value${a}. To learn about Convex's supported types, see https://docs.convex.dev/using/types.`
    );
  }
  if (e === null)
    return e;
  if (typeof e == "bigint") {
    if (e < $ || xe < e)
      throw new Error(
        `BigInt ${e} does not fit into a 64-bit signed integer.`
      );
    return { $integer: Nt(e) };
  }
  if (typeof e == "number")
    if (Ue(e)) {
      let a = new ArrayBuffer(8);
      return new DataView(a).setFloat64(0, e, Me), { $float: B(new Uint8Array(a)) };
    } else
      return e;
  if (typeof e == "boolean" || typeof e == "string")
    return e;
  if (e instanceof ArrayBuffer)
    return { $bytes: B(new Uint8Array(e)) };
  if (Array.isArray(e))
    return e.map(
      (a, p) => F(a, t, r + `[${p}]`, !1)
    );
  if (e instanceof Set)
    throw new Error(
      ye(r, "Set", [...e], t)
    );
  if (e instanceof Map)
    throw new Error(
      ye(r, "Map", [...e], t)
    );
  if (!me(e)) {
    let a = e?.constructor?.name, p = a ? `${a} ` : "";
    throw new Error(
      ye(r, p, e, t)
    );
  }
  let s = {}, i = Object.entries(e);
  i.sort(([a, p], [w, de]) => a === w ? 0 : a < w ? -1 : 1);
  for (let [a, p] of i)
    p !== void 0 ? (ge(a), s[a] = F(p, t, r + `.${a}`, !1)) : o && (ge(a), s[a] = Je(
      p,
      t,
      r + `.${a}`
    ));
  return s;
}
n(F, "convexToJsonInternal");
function ye(e, t, r, o) {
  return e ? `${t}${T(
    r
  )} is not a supported Convex type (present at path ${e} in original object ${T(
    o
  )}). To learn about Convex's supported types, see https://docs.convex.dev/using/types.` : `${t}${T(
    r
  )} is not a supported Convex type.`;
}
n(ye, "errorMessageForUnsupportedType");
function Je(e, t, r) {
  if (e === void 0)
    return { $undefined: null };
  if (t === void 0)
    throw new Error(
      `Programming error. Current value is ${T(
        e
      )} but original value is undefined`
    );
  return F(e, t, r, !1);
}
n(Je, "convexOrUndefinedToJsonInternal");
function d(e) {
  return F(e, e, "", !1);
}
n(d, "convexToJson");
function v(e) {
  return Je(e, e, "");
}
n(v, "convexOrUndefinedToJson");
function ke(e) {
  return F(e, e, "", !0);
}
n(ke, "patchValueToJson");

// node_modules/convex/dist/esm/values/validators.js
var Bt = Object.defineProperty, Ft = /* @__PURE__ */ n((e, t, r) => t in e ? Bt(e, t, { enumerable: !0, configurable: !0, writable: !0, value: r }) : e[t] = r, "__defNormalProp"), h = /* @__PURE__ */ n((e, t, r) => Ft(e, typeof t != "symbol" ? t + "" : t, r), "__publicField"), x = class {
  static {
    n(this, "BaseValidator");
  }
  constructor({ isOptional: t }) {
    h(this, "type"), h(this, "fieldPaths"), h(this, "isOptional"), h(this, "isConvexValidator"), this.isOptional = t, this.isConvexValidator = !0;
  }
  /** @deprecated - use isOptional instead */
  get optional() {
    return this.isOptional === "optional";
  }
}, J = class e extends x {
  static {
    n(this, "VId");
  }
  /**
   * Usually you'd use `v.id(tableName)` instead.
   */
  constructor({
    isOptional: t,
    tableName: r
  }) {
    super({ isOptional: t }), h(this, "tableName"), h(this, "kind", "id"), this.tableName = r;
  }
  /** @internal */
  get json() {
    return { type: "id", tableName: this.tableName };
  }
  /** @internal */
  asOptional() {
    return new e({
      isOptional: "optional",
      tableName: this.tableName
    });
  }
}, R = class e extends x {
  static {
    n(this, "VFloat64");
  }
  constructor() {
    super(...arguments), h(this, "kind", "float64");
  }
  /** @internal */
  get json() {
    return { type: "number" };
  }
  /** @internal */
  asOptional() {
    return new e({
      isOptional: "optional"
    });
  }
}, j = class e extends x {
  static {
    n(this, "VInt64");
  }
  constructor() {
    super(...arguments), h(this, "kind", "int64");
  }
  /** @internal */
  get json() {
    return { type: "bigint" };
  }
  /** @internal */
  asOptional() {
    return new e({ isOptional: "optional" });
  }
}, k = class e extends x {
  static {
    n(this, "VBoolean");
  }
  constructor() {
    super(...arguments), h(this, "kind", "boolean");
  }
  /** @internal */
  get json() {
    return { type: this.kind };
  }
  /** @internal */
  asOptional() {
    return new e({
      isOptional: "optional"
    });
  }
}, L = class e extends x {
  static {
    n(this, "VBytes");
  }
  constructor() {
    super(...arguments), h(this, "kind", "bytes");
  }
  /** @internal */
  get json() {
    return { type: this.kind };
  }
  /** @internal */
  asOptional() {
    return new e({ isOptional: "optional" });
  }
}, V = class e extends x {
  static {
    n(this, "VString");
  }
  constructor() {
    super(...arguments), h(this, "kind", "string");
  }
  /** @internal */
  get json() {
    return { type: this.kind };
  }
  /** @internal */
  asOptional() {
    return new e({
      isOptional: "optional"
    });
  }
}, Q = class e extends x {
  static {
    n(this, "VNull");
  }
  constructor() {
    super(...arguments), h(this, "kind", "null");
  }
  /** @internal */
  get json() {
    return { type: this.kind };
  }
  /** @internal */
  asOptional() {
    return new e({ isOptional: "optional" });
  }
}, H = class e extends x {
  static {
    n(this, "VAny");
  }
  constructor() {
    super(...arguments), h(this, "kind", "any");
  }
  /** @internal */
  get json() {
    return {
      type: this.kind
    };
  }
  /** @internal */
  asOptional() {
    return new e({
      isOptional: "optional"
    });
  }
}, G = class e extends x {
  static {
    n(this, "VObject");
  }
  /**
   * Usually you'd use `v.object({ ... })` instead.
   */
  constructor({
    isOptional: t,
    fields: r
  }) {
    super({ isOptional: t }), h(this, "fields"), h(this, "kind", "object"), this.fields = r;
  }
  /** @internal */
  get json() {
    return {
      type: this.kind,
      value: globalThis.Object.fromEntries(
        globalThis.Object.entries(this.fields).map(([t, r]) => [
          t,
          {
            fieldType: r.json,
            optional: r.isOptional === "optional"
          }
        ])
      )
    };
  }
  /** @internal */
  asOptional() {
    return new e({
      isOptional: "optional",
      fields: this.fields
    });
  }
}, W = class e extends x {
  static {
    n(this, "VLiteral");
  }
  /**
   * Usually you'd use `v.literal(value)` instead.
   */
  constructor({ isOptional: t, value: r }) {
    super({ isOptional: t }), h(this, "value"), h(this, "kind", "literal"), this.value = r;
  }
  /** @internal */
  get json() {
    return {
      type: this.kind,
      value: d(this.value)
    };
  }
  /** @internal */
  asOptional() {
    return new e({
      isOptional: "optional",
      value: this.value
    });
  }
}, z = class e extends x {
  static {
    n(this, "VArray");
  }
  /**
   * Usually you'd use `v.array(element)` instead.
   */
  constructor({
    isOptional: t,
    element: r
  }) {
    super({ isOptional: t }), h(this, "element"), h(this, "kind", "array"), this.element = r;
  }
  /** @internal */
  get json() {
    return {
      type: this.kind,
      value: this.element.json
    };
  }
  /** @internal */
  asOptional() {
    return new e({
      isOptional: "optional",
      element: this.element
    });
  }
}, D = class e extends x {
  static {
    n(this, "VRecord");
  }
  /**
   * Usually you'd use `v.record(key, value)` instead.
   */
  constructor({
    isOptional: t,
    key: r,
    value: o
  }) {
    if (super({ isOptional: t }), h(this, "key"), h(this, "value"), h(this, "kind", "record"), r.isOptional === "optional")
      throw new Error("Record validator cannot have optional keys");
    if (o.isOptional === "optional")
      throw new Error("Record validator cannot have optional values");
    this.key = r, this.value = o;
  }
  /** @internal */
  get json() {
    return {
      type: this.kind,
      // This cast is needed because TypeScript thinks the key type is too wide
      keys: this.key.json,
      values: {
        fieldType: this.value.json,
        optional: !1
      }
    };
  }
  /** @internal */
  asOptional() {
    return new e({
      isOptional: "optional",
      key: this.key,
      value: this.value
    });
  }
}, X = class e extends x {
  static {
    n(this, "VUnion");
  }
  /**
   * Usually you'd use `v.union(...members)` instead.
   */
  constructor({ isOptional: t, members: r }) {
    super({ isOptional: t }), h(this, "members"), h(this, "kind", "union"), this.members = r;
  }
  /** @internal */
  get json() {
    return {
      type: this.kind,
      value: this.members.map((t) => t.json)
    };
  }
  /** @internal */
  asOptional() {
    return new e({
      isOptional: "optional",
      members: this.members
    });
  }
};

// node_modules/convex/dist/esm/values/validator.js
function be(e) {
  return !!e.isConvexValidator;
}
n(be, "isValidator");
function Y(e) {
  return be(e) ? e : u.object(e);
}
n(Y, "asObjectValidator");
var u = {
  /**
   * Validates that the value corresponds to an ID of a document in given table.
   * @param tableName The name of the table.
   */
  id: /* @__PURE__ */ n((e) => new J({
    isOptional: "required",
    tableName: e
  }), "id"),
  /**
   * Validates that the value is of type Null.
   */
  null: /* @__PURE__ */ n(() => new Q({ isOptional: "required" }), "null"),
  /**
   * Validates that the value is of Convex type Float64 (Number in JS).
   *
   * Alias for `v.float64()`
   */
  number: /* @__PURE__ */ n(() => new R({ isOptional: "required" }), "number"),
  /**
   * Validates that the value is of Convex type Float64 (Number in JS).
   */
  float64: /* @__PURE__ */ n(() => new R({ isOptional: "required" }), "float64"),
  /**
   * @deprecated Use `v.int64()` instead
   */
  bigint: /* @__PURE__ */ n(() => new j({ isOptional: "required" }), "bigint"),
  /**
   * Validates that the value is of Convex type Int64 (BigInt in JS).
   */
  int64: /* @__PURE__ */ n(() => new j({ isOptional: "required" }), "int64"),
  /**
   * Validates that the value is of type Boolean.
   */
  boolean: /* @__PURE__ */ n(() => new k({ isOptional: "required" }), "boolean"),
  /**
   * Validates that the value is of type String.
   */
  string: /* @__PURE__ */ n(() => new V({ isOptional: "required" }), "string"),
  /**
   * Validates that the value is of Convex type Bytes (constructed in JS via `ArrayBuffer`).
   */
  bytes: /* @__PURE__ */ n(() => new L({ isOptional: "required" }), "bytes"),
  /**
   * Validates that the value is equal to the given literal value.
   * @param literal The literal value to compare against.
   */
  literal: /* @__PURE__ */ n((e) => new W({ isOptional: "required", value: e }), "literal"),
  /**
   * Validates that the value is an Array of the given element type.
   * @param element The validator for the elements of the array.
   */
  array: /* @__PURE__ */ n((e) => new z({ isOptional: "required", element: e }), "array"),
  /**
   * Validates that the value is an Object with the given properties.
   * @param fields An object specifying the validator for each property.
   */
  object: /* @__PURE__ */ n((e) => new G({ isOptional: "required", fields: e }), "object"),
  /**
   * Validates that the value is a Record with keys and values that match the given types.
   * @param keys The validator for the keys of the record. This cannot contain string literals.
   * @param values The validator for the values of the record.
   */
  record: /* @__PURE__ */ n((e, t) => new D({
    isOptional: "required",
    key: e,
    value: t
  }), "record"),
  /**
   * Validates that the value matches one of the given validators.
   * @param members The validators to match against.
   */
  union: /* @__PURE__ */ n((...e) => new X({
    isOptional: "required",
    members: e
  }), "union"),
  /**
   * Does not validate the value.
   */
  any: /* @__PURE__ */ n(() => new H({ isOptional: "required" }), "any"),
  /**
   * Allows not specifying a value for a property in an Object.
   * @param value The property value validator to make optional.
   *
   * ```typescript
   * const objectWithOptionalFields = v.object({
   *   requiredField: v.string(),
   *   optionalField: v.optional(v.string()),
   * });
   * ```
   */
  optional: /* @__PURE__ */ n((e) => e.asOptional(), "optional")
};

// node_modules/convex/dist/esm/values/errors.js
var Rt = Object.defineProperty, jt = /* @__PURE__ */ n((e, t, r) => t in e ? Rt(e, t, { enumerable: !0, configurable: !0, writable: !0, value: r }) : e[t] = r, "__defNormalProp"), ve = /* @__PURE__ */ n((e, t, r) => jt(e, typeof t != "symbol" ? t + "" : t, r), "__publicField"), Le, Ve, qt = Symbol.for("ConvexError"), K = class extends (Ve = Error, Le = qt, Ve) {
  static {
    n(this, "ConvexError");
  }
  constructor(t) {
    super(typeof t == "string" ? t : T(t)), ve(this, "name", "ConvexError"), ve(this, "data"), ve(this, Le, !0), this.data = t;
  }
};

// node_modules/convex/dist/esm/values/compare_utf8.js
var Qe = /* @__PURE__ */ n(() => Array.from({ length: 4 }, () => 0), "arr"), Rr = Qe(), jr = Qe();

// node_modules/convex/dist/esm/server/functionName.js
var q = Symbol.for("functionName");

// node_modules/convex/dist/esm/server/components/paths.js
var Ae = Symbol.for("toReferencePath");
function Mt(e) {
  return e[Ae] ?? null;
}
n(Mt, "extractReferencePath");
function Ut(e) {
  return e.startsWith("function://");
}
n(Ut, "isFunctionHandle");
function A(e) {
  let t;
  if (typeof e == "string")
    Ut(e) ? t = { functionHandle: e } : t = { name: e };
  else if (e[q])
    t = { name: e[q] };
  else {
    let r = Mt(e);
    if (!r)
      throw new Error(`${e} is not a functionReference`);
    t = { reference: r };
  }
  return t;
}
n(A, "getFunctionAddress");

// node_modules/convex/dist/esm/server/api.js
function He(e = []) {
  let t = {
    get(r, o) {
      if (typeof o == "string") {
        let s = [...e, o];
        return He(s);
      } else if (o === q) {
        if (e.length < 2) {
          let a = ["api", ...e].join(".");
          throw new Error(
            `API path is expected to be of the form \`api.moduleName.functionName\`. Found: \`${a}\``
          );
        }
        let s = e.slice(0, -1).join("/"), i = e[e.length - 1];
        return i === "default" ? s : s + ":" + i;
      } else return o === Symbol.toStringTag ? "FunctionReference" : void 0;
    }
  };
  return new Proxy({}, t);
}
n(He, "createApi");
var Jt = He();

// node_modules/convex/dist/esm/index.js
var y = "1.25.0";

// node_modules/convex/dist/esm/server/impl/syscall.js
function M(e, t) {
  if (typeof Convex > "u" || Convex.syscall === void 0)
    throw new Error(
      "The Convex database and auth objects are being used outside of a Convex backend. Did you mean to use `useQuery` or `useMutation` to call a Convex function?"
    );
  let r = Convex.syscall(e, JSON.stringify(t));
  return JSON.parse(r);
}
n(M, "performSyscall");
async function l(e, t) {
  if (typeof Convex > "u" || Convex.asyncSyscall === void 0)
    throw new Error(
      "The Convex database and auth objects are being used outside of a Convex backend. Did you mean to use `useQuery` or `useMutation` to call a Convex function?"
    );
  let r;
  try {
    r = await Convex.asyncSyscall(e, JSON.stringify(t));
  } catch (o) {
    if (o.data !== void 0) {
      let s = new K(o.message);
      throw s.data = m(o.data), s;
    }
    throw new Error(o.message);
  }
  return JSON.parse(r);
}
n(l, "performAsyncSyscall");
function Z(e, t) {
  if (typeof Convex > "u" || Convex.jsSyscall === void 0)
    throw new Error(
      "The Convex database and auth objects are being used outside of a Convex backend. Did you mean to use `useQuery` or `useMutation` to call a Convex function?"
    );
  return Convex.jsSyscall(e, t);
}
n(Z, "performJsSyscall");

// node_modules/convex/dist/esm/server/components/index.js
function Ge(e, t) {
  let r = {
    get(o, s) {
      if (typeof s == "string") {
        let i = [...t, s];
        return Ge(e, i);
      } else if (s === Ae) {
        if (t.length < 1) {
          let i = [e, ...t].join(".");
          throw new Error(
            `API path is expected to be of the form \`${e}.childComponent.functionName\`. Found: \`${i}\``
          );
        }
        return "_reference/childComponent/" + t.join("/");
      } else
        return;
    }
  };
  return new Proxy({}, r);
}
n(Ge, "createChildComponents");
var kt = /* @__PURE__ */ n(() => Ge("components", []), "componentsGeneric");

// node_modules/convex/dist/esm/server/impl/actions_impl.js
function Ee(e, t, r) {
  return {
    ...A(t),
    args: d(S(r)),
    version: y,
    requestId: e
  };
}
n(Ee, "syscallArgs");
function We(e) {
  return {
    runQuery: /* @__PURE__ */ n(async (t, r) => {
      let o = await l(
        "1.0/actions/query",
        Ee(e, t, r)
      );
      return m(o);
    }, "runQuery"),
    runMutation: /* @__PURE__ */ n(async (t, r) => {
      let o = await l(
        "1.0/actions/mutation",
        Ee(e, t, r)
      );
      return m(o);
    }, "runMutation"),
    runAction: /* @__PURE__ */ n(async (t, r) => {
      let o = await l(
        "1.0/actions/action",
        Ee(e, t, r)
      );
      return m(o);
    }, "runAction")
  };
}
n(We, "setupActionCalls");

// node_modules/convex/dist/esm/server/vector_search.js
var Lt = Object.defineProperty, Vt = /* @__PURE__ */ n((e, t, r) => t in e ? Lt(e, t, { enumerable: !0, configurable: !0, writable: !0, value: r }) : e[t] = r, "__defNormalProp"), ze = /* @__PURE__ */ n((e, t, r) => Vt(e, typeof t != "symbol" ? t + "" : t, r), "__publicField"), ee = class {
  static {
    n(this, "FilterExpression");
  }
  /**
   * @internal
   */
  constructor() {
    ze(this, "_isExpression"), ze(this, "_value");
  }
};

// node_modules/convex/dist/esm/server/impl/validate.js
function c(e, t, r, o) {
  if (e === void 0)
    throw new TypeError(
      `Must provide arg ${t} \`${o}\` to \`${r}\``
    );
}
n(c, "validateArg");
function De(e, t, r, o) {
  if (!Number.isInteger(e) || e < 0)
    throw new TypeError(
      `Arg ${t} \`${o}\` to \`${r}\` must be a non-negative integer`
    );
}
n(De, "validateArgIsNonNegativeInteger");

// node_modules/convex/dist/esm/server/impl/vector_search_impl.js
var Qt = Object.defineProperty, Ht = /* @__PURE__ */ n((e, t, r) => t in e ? Qt(e, t, { enumerable: !0, configurable: !0, writable: !0, value: r }) : e[t] = r, "__defNormalProp"), Se = /* @__PURE__ */ n((e, t, r) => Ht(e, typeof t != "symbol" ? t + "" : t, r), "__publicField");
function Xe(e) {
  return async (t, r, o) => {
    if (c(t, 1, "vectorSearch", "tableName"), c(r, 2, "vectorSearch", "indexName"), c(o, 3, "vectorSearch", "query"), !o.vector || !Array.isArray(o.vector) || o.vector.length === 0)
      throw Error("`vector` must be a non-empty Array in vectorSearch");
    return await new Ce(
      e,
      t + "." + r,
      o
    ).collect();
  };
}
n(Xe, "setupActionVectorSearch");
var Ce = class {
  static {
    n(this, "VectorQueryImpl");
  }
  constructor(t, r, o) {
    Se(this, "requestId"), Se(this, "state"), this.requestId = t;
    let s = o.filter ? te(o.filter(Gt)) : null;
    this.state = {
      type: "preparing",
      query: {
        indexName: r,
        limit: o.limit,
        vector: o.vector,
        expressions: s
      }
    };
  }
  async collect() {
    if (this.state.type === "consumed")
      throw new Error("This query is closed and can't emit any more values.");
    let t = this.state.query;
    this.state = { type: "consumed" };
    let { results: r } = await l("1.0/actions/vectorSearch", {
      requestId: this.requestId,
      version: y,
      query: t
    });
    return r;
  }
}, I = class extends ee {
  static {
    n(this, "ExpressionImpl");
  }
  constructor(t) {
    super(), Se(this, "inner"), this.inner = t;
  }
  serialize() {
    return this.inner;
  }
};
function te(e) {
  return e instanceof I ? e.serialize() : { $literal: v(e) };
}
n(te, "serializeExpression");
var Gt = {
  //  Comparisons  /////////////////////////////////////////////////////////////
  eq(e, t) {
    if (typeof e != "string")
      throw new Error("The first argument to `q.eq` must be a field name.");
    return new I({
      $eq: [
        te(new I({ $field: e })),
        te(t)
      ]
    });
  },
  //  Logic  ///////////////////////////////////////////////////////////////////
  or(...e) {
    return new I({ $or: e.map(te) });
  }
};

// node_modules/convex/dist/esm/server/impl/authentication_impl.js
function re(e) {
  return {
    getUserIdentity: /* @__PURE__ */ n(async () => await l("1.0/getUserIdentity", {
      requestId: e
    }), "getUserIdentity")
  };
}
n(re, "setupAuth");

// node_modules/convex/dist/esm/server/filter_builder.js
var Wt = Object.defineProperty, zt = /* @__PURE__ */ n((e, t, r) => t in e ? Wt(e, t, { enumerable: !0, configurable: !0, writable: !0, value: r }) : e[t] = r, "__defNormalProp"), Ye = /* @__PURE__ */ n((e, t, r) => zt(e, typeof t != "symbol" ? t + "" : t, r), "__publicField"), ne = class {
  static {
    n(this, "Expression");
  }
  /**
   * @internal
   */
  constructor() {
    Ye(this, "_isExpression"), Ye(this, "_value");
  }
};

// node_modules/convex/dist/esm/server/impl/filter_builder_impl.js
var Dt = Object.defineProperty, Xt = /* @__PURE__ */ n((e, t, r) => t in e ? Dt(e, t, { enumerable: !0, configurable: !0, writable: !0, value: r }) : e[t] = r, "__defNormalProp"), Yt = /* @__PURE__ */ n((e, t, r) => Xt(e, typeof t != "symbol" ? t + "" : t, r), "__publicField"), g = class extends ne {
  static {
    n(this, "ExpressionImpl");
  }
  constructor(t) {
    super(), Yt(this, "inner"), this.inner = t;
  }
  serialize() {
    return this.inner;
  }
};
function f(e) {
  return e instanceof g ? e.serialize() : { $literal: v(e) };
}
n(f, "serializeExpression");
var Ke = {
  //  Comparisons  /////////////////////////////////////////////////////////////
  eq(e, t) {
    return new g({
      $eq: [f(e), f(t)]
    });
  },
  neq(e, t) {
    return new g({
      $neq: [f(e), f(t)]
    });
  },
  lt(e, t) {
    return new g({
      $lt: [f(e), f(t)]
    });
  },
  lte(e, t) {
    return new g({
      $lte: [f(e), f(t)]
    });
  },
  gt(e, t) {
    return new g({
      $gt: [f(e), f(t)]
    });
  },
  gte(e, t) {
    return new g({
      $gte: [f(e), f(t)]
    });
  },
  //  Arithmetic  //////////////////////////////////////////////////////////////
  add(e, t) {
    return new g({
      $add: [f(e), f(t)]
    });
  },
  sub(e, t) {
    return new g({
      $sub: [f(e), f(t)]
    });
  },
  mul(e, t) {
    return new g({
      $mul: [f(e), f(t)]
    });
  },
  div(e, t) {
    return new g({
      $div: [f(e), f(t)]
    });
  },
  mod(e, t) {
    return new g({
      $mod: [f(e), f(t)]
    });
  },
  neg(e) {
    return new g({ $neg: f(e) });
  },
  //  Logic  ///////////////////////////////////////////////////////////////////
  and(...e) {
    return new g({ $and: e.map(f) });
  },
  or(...e) {
    return new g({ $or: e.map(f) });
  },
  not(e) {
    return new g({ $not: f(e) });
  },
  //  Other  ///////////////////////////////////////////////////////////////////
  field(e) {
    return new g({ $field: e });
  }
};

// node_modules/convex/dist/esm/server/index_range_builder.js
var Kt = Object.defineProperty, Zt = /* @__PURE__ */ n((e, t, r) => t in e ? Kt(e, t, { enumerable: !0, configurable: !0, writable: !0, value: r }) : e[t] = r, "__defNormalProp"), er = /* @__PURE__ */ n((e, t, r) => Zt(e, typeof t != "symbol" ? t + "" : t, r), "__publicField"), oe = class {
  static {
    n(this, "IndexRange");
  }
  /**
   * @internal
   */
  constructor() {
    er(this, "_isIndexRange");
  }
};

// node_modules/convex/dist/esm/server/impl/index_range_builder_impl.js
var tr = Object.defineProperty, rr = /* @__PURE__ */ n((e, t, r) => t in e ? tr(e, t, { enumerable: !0, configurable: !0, writable: !0, value: r }) : e[t] = r, "__defNormalProp"), Ze = /* @__PURE__ */ n((e, t, r) => rr(e, typeof t != "symbol" ? t + "" : t, r), "__publicField"), se = class e extends oe {
  static {
    n(this, "IndexRangeBuilderImpl");
  }
  constructor(t) {
    super(), Ze(this, "rangeExpressions"), Ze(this, "isConsumed"), this.rangeExpressions = t, this.isConsumed = !1;
  }
  static new() {
    return new e([]);
  }
  consume() {
    if (this.isConsumed)
      throw new Error(
        "IndexRangeBuilder has already been used! Chain your method calls like `q => q.eq(...).eq(...)`. See https://docs.convex.dev/using/indexes"
      );
    this.isConsumed = !0;
  }
  eq(t, r) {
    return this.consume(), new e(
      this.rangeExpressions.concat({
        type: "Eq",
        fieldPath: t,
        value: v(r)
      })
    );
  }
  gt(t, r) {
    return this.consume(), new e(
      this.rangeExpressions.concat({
        type: "Gt",
        fieldPath: t,
        value: v(r)
      })
    );
  }
  gte(t, r) {
    return this.consume(), new e(
      this.rangeExpressions.concat({
        type: "Gte",
        fieldPath: t,
        value: v(r)
      })
    );
  }
  lt(t, r) {
    return this.consume(), new e(
      this.rangeExpressions.concat({
        type: "Lt",
        fieldPath: t,
        value: v(r)
      })
    );
  }
  lte(t, r) {
    return this.consume(), new e(
      this.rangeExpressions.concat({
        type: "Lte",
        fieldPath: t,
        value: v(r)
      })
    );
  }
  export() {
    return this.consume(), this.rangeExpressions;
  }
};

// node_modules/convex/dist/esm/server/search_filter_builder.js
var nr = Object.defineProperty, or = /* @__PURE__ */ n((e, t, r) => t in e ? nr(e, t, { enumerable: !0, configurable: !0, writable: !0, value: r }) : e[t] = r, "__defNormalProp"), sr = /* @__PURE__ */ n((e, t, r) => or(e, typeof t != "symbol" ? t + "" : t, r), "__publicField"), ie = class {
  static {
    n(this, "SearchFilter");
  }
  /**
   * @internal
   */
  constructor() {
    sr(this, "_isSearchFilter");
  }
};

// node_modules/convex/dist/esm/server/impl/search_filter_builder_impl.js
var ir = Object.defineProperty, ar = /* @__PURE__ */ n((e, t, r) => t in e ? ir(e, t, { enumerable: !0, configurable: !0, writable: !0, value: r }) : e[t] = r, "__defNormalProp"), et = /* @__PURE__ */ n((e, t, r) => ar(e, typeof t != "symbol" ? t + "" : t, r), "__publicField"), ae = class e extends ie {
  static {
    n(this, "SearchFilterBuilderImpl");
  }
  constructor(t) {
    super(), et(this, "filters"), et(this, "isConsumed"), this.filters = t, this.isConsumed = !1;
  }
  static new() {
    return new e([]);
  }
  consume() {
    if (this.isConsumed)
      throw new Error(
        "SearchFilterBuilder has already been used! Chain your method calls like `q => q.search(...).eq(...)`."
      );
    this.isConsumed = !0;
  }
  search(t, r) {
    return c(t, 1, "search", "fieldName"), c(r, 2, "search", "query"), this.consume(), new e(
      this.filters.concat({
        type: "Search",
        fieldPath: t,
        value: r
      })
    );
  }
  eq(t, r) {
    return c(t, 1, "eq", "fieldName"), arguments.length !== 2 && c(r, 2, "search", "value"), this.consume(), new e(
      this.filters.concat({
        type: "Eq",
        fieldPath: t,
        value: v(r)
      })
    );
  }
  export() {
    return this.consume(), this.filters;
  }
};

// node_modules/convex/dist/esm/server/impl/query_impl.js
var ur = Object.defineProperty, cr = /* @__PURE__ */ n((e, t, r) => t in e ? ur(e, t, { enumerable: !0, configurable: !0, writable: !0, value: r }) : e[t] = r, "__defNormalProp"), Te = /* @__PURE__ */ n((e, t, r) => cr(e, typeof t != "symbol" ? t + "" : t, r), "__publicField"), tt = 256, N = class {
  static {
    n(this, "QueryInitializerImpl");
  }
  constructor(t) {
    Te(this, "tableName"), this.tableName = t;
  }
  withIndex(t, r) {
    c(t, 1, "withIndex", "indexName");
    let o = se.new();
    return r !== void 0 && (o = r(o)), new _({
      source: {
        type: "IndexRange",
        indexName: this.tableName + "." + t,
        range: o.export(),
        order: null
      },
      operators: []
    });
  }
  withSearchIndex(t, r) {
    c(t, 1, "withSearchIndex", "indexName"), c(r, 2, "withSearchIndex", "searchFilter");
    let o = ae.new();
    return new _({
      source: {
        type: "Search",
        indexName: this.tableName + "." + t,
        filters: r(o).export()
      },
      operators: []
    });
  }
  fullTableScan() {
    return new _({
      source: {
        type: "FullTableScan",
        tableName: this.tableName,
        order: null
      },
      operators: []
    });
  }
  order(t) {
    return this.fullTableScan().order(t);
  }
  // This is internal API and should not be exposed to developers yet.
  async count() {
    let t = await l("1.0/count", {
      table: this.tableName
    });
    return m(t);
  }
  filter(t) {
    return this.fullTableScan().filter(t);
  }
  limit(t) {
    return this.fullTableScan().limit(t);
  }
  collect() {
    return this.fullTableScan().collect();
  }
  take(t) {
    return this.fullTableScan().take(t);
  }
  paginate(t) {
    return this.fullTableScan().paginate(t);
  }
  first() {
    return this.fullTableScan().first();
  }
  unique() {
    return this.fullTableScan().unique();
  }
  [Symbol.asyncIterator]() {
    return this.fullTableScan()[Symbol.asyncIterator]();
  }
};
function rt(e) {
  throw new Error(
    e === "consumed" ? "This query is closed and can't emit any more values." : "This query has been chained with another operator and can't be reused."
  );
}
n(rt, "throwClosedError");
var _ = class e {
  static {
    n(this, "QueryImpl");
  }
  constructor(t) {
    Te(this, "state"), Te(this, "tableNameForErrorMessages"), this.state = { type: "preparing", query: t }, t.source.type === "FullTableScan" ? this.tableNameForErrorMessages = t.source.tableName : this.tableNameForErrorMessages = t.source.indexName.split(".")[0];
  }
  takeQuery() {
    if (this.state.type !== "preparing")
      throw new Error(
        "A query can only be chained once and can't be chained after iteration begins."
      );
    let t = this.state.query;
    return this.state = { type: "closed" }, t;
  }
  startQuery() {
    if (this.state.type === "executing")
      throw new Error("Iteration can only begin on a query once.");
    (this.state.type === "closed" || this.state.type === "consumed") && rt(this.state.type);
    let t = this.state.query, { queryId: r } = M("1.0/queryStream", { query: t, version: y });
    return this.state = { type: "executing", queryId: r }, r;
  }
  closeQuery() {
    if (this.state.type === "executing") {
      let t = this.state.queryId;
      M("1.0/queryCleanup", { queryId: t });
    }
    this.state = { type: "consumed" };
  }
  order(t) {
    c(t, 1, "order", "order");
    let r = this.takeQuery();
    if (r.source.type === "Search")
      throw new Error(
        "Search queries must always be in relevance order. Can not set order manually."
      );
    if (r.source.order !== null)
      throw new Error("Queries may only specify order at most once");
    return r.source.order = t, new e(r);
  }
  filter(t) {
    c(t, 1, "filter", "predicate");
    let r = this.takeQuery();
    if (r.operators.length >= tt)
      throw new Error(
        `Can't construct query with more than ${tt} operators`
      );
    return r.operators.push({
      filter: f(t(Ke))
    }), new e(r);
  }
  limit(t) {
    c(t, 1, "limit", "n");
    let r = this.takeQuery();
    return r.operators.push({ limit: t }), new e(r);
  }
  [Symbol.asyncIterator]() {
    return this.startQuery(), this;
  }
  async next() {
    (this.state.type === "closed" || this.state.type === "consumed") && rt(this.state.type);
    let t = this.state.type === "preparing" ? this.startQuery() : this.state.queryId, { value: r, done: o } = await l("1.0/queryStreamNext", {
      queryId: t
    });
    return o && this.closeQuery(), { value: m(r), done: o };
  }
  return() {
    return this.closeQuery(), Promise.resolve({ done: !0, value: void 0 });
  }
  async paginate(t) {
    if (c(t, 1, "paginate", "options"), typeof t?.numItems != "number" || t.numItems < 0)
      throw new Error(
        `\`options.numItems\` must be a positive number. Received \`${t?.numItems}\`.`
      );
    let r = this.takeQuery(), o = t.numItems, s = t.cursor, i = t?.endCursor ?? null, a = t.maximumRowsRead ?? null, { page: p, isDone: w, continueCursor: de, splitCursor: wt, pageStatus: gt } = await l("1.0/queryPage", {
      query: r,
      cursor: s,
      endCursor: i,
      pageSize: o,
      maximumRowsRead: a,
      maximumBytesRead: t.maximumBytesRead,
      version: y
    });
    return {
      page: p.map((xt) => m(xt)),
      isDone: w,
      continueCursor: de,
      splitCursor: wt,
      pageStatus: gt
    };
  }
  async collect() {
    let t = [];
    for await (let r of this)
      t.push(r);
    return t;
  }
  async take(t) {
    return c(t, 1, "take", "n"), De(t, 1, "take", "n"), this.limit(t).collect();
  }
  async first() {
    let t = await this.take(1);
    return t.length === 0 ? null : t[0];
  }
  async unique() {
    let t = await this.take(2);
    if (t.length === 0)
      return null;
    if (t.length === 2)
      throw new Error(`unique() query returned more than one result from table ${this.tableNameForErrorMessages}:
 [${t[0]._id}, ${t[1]._id}, ...]`);
    return t[0];
  }
};

// node_modules/convex/dist/esm/server/impl/database_impl.js
async function nt(e, t) {
  if (c(e, 1, "get", "id"), typeof e != "string")
    throw new Error(
      `Invalid argument \`id\` for \`db.get\`, expected string but got '${typeof e}': ${e}`
    );
  let r = {
    id: d(e),
    isSystem: t,
    version: y
  }, o = await l("1.0/get", r);
  return m(o);
}
n(nt, "get");
function Oe() {
  let e = /* @__PURE__ */ n((s = !1) => ({
    get: /* @__PURE__ */ n(async (i) => await nt(i, s), "get"),
    query: /* @__PURE__ */ n((i) => new U(i, s).query(), "query"),
    normalizeId: /* @__PURE__ */ n((i, a) => {
      c(i, 1, "normalizeId", "tableName"), c(a, 2, "normalizeId", "id");
      let p = i.startsWith("_");
      if (p !== s)
        throw new Error(
          `${p ? "System" : "User"} tables can only be accessed from db.${s ? "" : "system."}normalizeId().`
        );
      let w = M("1.0/db/normalizeId", {
        table: i,
        idString: a
      });
      return m(w).id;
    }, "normalizeId"),
    // We set the system reader on the next line
    system: null,
    table: /* @__PURE__ */ n((i) => new U(i, s), "table")
  }), "reader"), { system: t, ...r } = e(!0), o = e();
  return o.system = r, o;
}
n(Oe, "setupReader");
async function ot(e, t) {
  if (e.startsWith("_"))
    throw new Error("System tables (prefixed with `_`) are read-only.");
  c(e, 1, "insert", "table"), c(t, 2, "insert", "value");
  let r = await l("1.0/insert", {
    table: e,
    value: d(t)
  });
  return m(r)._id;
}
n(ot, "insert");
async function st(e, t) {
  c(e, 1, "patch", "id"), c(t, 2, "patch", "value"), await l("1.0/shallowMerge", {
    id: d(e),
    value: ke(t)
  });
}
n(st, "patch");
async function it(e, t) {
  c(e, 1, "replace", "id"), c(t, 2, "replace", "value"), await l("1.0/replace", {
    id: d(e),
    value: d(t)
  });
}
n(it, "replace");
async function at(e) {
  c(e, 1, "delete", "id"), await l("1.0/remove", { id: d(e) });
}
n(at, "delete_");
function ut() {
  let e = Oe();
  return {
    get: e.get,
    query: e.query,
    normalizeId: e.normalizeId,
    system: e.system,
    insert: /* @__PURE__ */ n(async (t, r) => await ot(t, r), "insert"),
    patch: /* @__PURE__ */ n(async (t, r) => await st(t, r), "patch"),
    replace: /* @__PURE__ */ n(async (t, r) => await it(t, r), "replace"),
    delete: /* @__PURE__ */ n(async (t) => await at(t), "delete"),
    table: /* @__PURE__ */ n((t) => new _e(t, !1), "table")
  };
}
n(ut, "setupWriter");
var U = class {
  static {
    n(this, "TableReader");
  }
  constructor(t, r) {
    this.tableName = t, this.isSystem = r;
  }
  async get(t) {
    return nt(t, this.isSystem);
  }
  query() {
    let t = this.tableName.startsWith("_");
    if (t !== this.isSystem)
      throw new Error(
        `${t ? "System" : "User"} tables can only be accessed from db.${this.isSystem ? "" : "system."}query().`
      );
    return new N(this.tableName);
  }
}, _e = class extends U {
  static {
    n(this, "TableWriter");
  }
  async insert(t) {
    return ot(this.tableName, t);
  }
  async patch(t, r) {
    return st(t, r);
  }
  async replace(t, r) {
    return it(t, r);
  }
  async delete(t) {
    return at(t);
  }
};

// node_modules/convex/dist/esm/server/impl/scheduler_impl.js
function ct() {
  return {
    runAfter: /* @__PURE__ */ n(async (e, t, r) => {
      let o = ft(e, t, r);
      return await l("1.0/schedule", o);
    }, "runAfter"),
    runAt: /* @__PURE__ */ n(async (e, t, r) => {
      let o = pt(
        e,
        t,
        r
      );
      return await l("1.0/schedule", o);
    }, "runAt"),
    cancel: /* @__PURE__ */ n(async (e) => {
      c(e, 1, "cancel", "id");
      let t = { id: d(e) };
      await l("1.0/cancel_job", t);
    }, "cancel")
  };
}
n(ct, "setupMutationScheduler");
function lt(e) {
  return {
    runAfter: /* @__PURE__ */ n(async (t, r, o) => {
      let s = {
        requestId: e,
        ...ft(t, r, o)
      };
      return await l("1.0/actions/schedule", s);
    }, "runAfter"),
    runAt: /* @__PURE__ */ n(async (t, r, o) => {
      let s = {
        requestId: e,
        ...pt(t, r, o)
      };
      return await l("1.0/actions/schedule", s);
    }, "runAt"),
    cancel: /* @__PURE__ */ n(async (t) => {
      c(t, 1, "cancel", "id");
      let r = { id: d(t) };
      return await l("1.0/actions/cancel_job", r);
    }, "cancel")
  };
}
n(lt, "setupActionScheduler");
function ft(e, t, r) {
  if (typeof e != "number")
    throw new Error("`delayMs` must be a number");
  if (!isFinite(e))
    throw new Error("`delayMs` must be a finite number");
  if (e < 0)
    throw new Error("`delayMs` must be non-negative");
  let o = S(r), s = A(t), i = (Date.now() + e) / 1e3;
  return {
    ...s,
    ts: i,
    args: d(o),
    version: y
  };
}
n(ft, "runAfterSyscallArgs");
function pt(e, t, r) {
  let o;
  if (e instanceof Date)
    o = e.valueOf() / 1e3;
  else if (typeof e == "number")
    o = e / 1e3;
  else
    throw new Error("The invoke time must a Date or a timestamp");
  let s = A(t), i = S(r);
  return {
    ...s,
    ts: o,
    args: d(i),
    version: y
  };
}
n(pt, "runAtSyscallArgs");

// node_modules/convex/dist/esm/server/impl/storage_impl.js
function $e(e) {
  return {
    getUrl: /* @__PURE__ */ n(async (t) => (c(t, 1, "getUrl", "storageId"), await l("1.0/storageGetUrl", {
      requestId: e,
      version: y,
      storageId: t
    })), "getUrl"),
    getMetadata: /* @__PURE__ */ n(async (t) => await l("1.0/storageGetMetadata", {
      requestId: e,
      version: y,
      storageId: t
    }), "getMetadata")
  };
}
n($e, "setupStorageReader");
function Ie(e) {
  let t = $e(e);
  return {
    generateUploadUrl: /* @__PURE__ */ n(async () => await l("1.0/storageGenerateUploadUrl", {
      requestId: e,
      version: y
    }), "generateUploadUrl"),
    delete: /* @__PURE__ */ n(async (r) => {
      await l("1.0/storageDelete", {
        requestId: e,
        version: y,
        storageId: r
      });
    }, "delete"),
    getUrl: t.getUrl,
    getMetadata: t.getMetadata
  };
}
n(Ie, "setupStorageWriter");
function dt(e) {
  return {
    ...Ie(e),
    store: /* @__PURE__ */ n(async (r, o) => await Z("storage/storeBlob", {
      requestId: e,
      version: y,
      blob: r,
      options: o
    }), "store"),
    get: /* @__PURE__ */ n(async (r) => await Z("storage/getBlob", {
      requestId: e,
      version: y,
      storageId: r
    }), "get")
  };
}
n(dt, "setupStorageActionWriter");

// node_modules/convex/dist/esm/server/impl/registration_impl.js
async function lr(e, t) {
  let r = "", o = m(JSON.parse(t)), s = {
    db: ut(),
    auth: re(r),
    storage: Ie(r),
    scheduler: ct(),
    runQuery: /* @__PURE__ */ n((a, p) => Ne("query", a, p), "runQuery"),
    runMutation: /* @__PURE__ */ n((a, p) => Ne("mutation", a, p), "runMutation")
  }, i = await Pe(e, s, o);
  return ht(i), JSON.stringify(d(i === void 0 ? null : i));
}
n(lr, "invokeMutation");
function ht(e) {
  if (e instanceof N || e instanceof _)
    throw new Error(
      "Return value is a Query. Results must be retrieved with `.collect()`, `.take(n), `.unique()`, or `.first()`."
    );
}
n(ht, "validateReturnValue");
async function Pe(e, t, r) {
  let o;
  try {
    o = await Promise.resolve(e(t, ...r));
  } catch (s) {
    throw fr(s);
  }
  return o;
}
n(Pe, "invokeFunction");
function ue(e, t) {
  return (r, o) => (globalThis.console.warn(
    `Convex functions should not directly call other Convex functions. Consider calling a helper function instead. e.g. \`export const foo = ${e}(...); await foo(ctx);\` is not supported. See https://docs.convex.dev/production/best-practices/#use-helper-functions-to-write-shared-code`
  ), t(r, o));
}
n(ue, "dontCallDirectly");
function fr(e) {
  if (typeof e == "object" && e !== null && Symbol.for("ConvexError") in e) {
    let t = e;
    return t.data = JSON.stringify(
      d(t.data === void 0 ? null : t.data)
    ), t.ConvexErrorSymbol = Symbol.for("ConvexError"), t;
  } else
    return e;
}
n(fr, "serializeConvexErrorData");
function ce() {
  if (typeof window > "u" || window.__convexAllowFunctionsInBrowser)
    return;
  (Object.getOwnPropertyDescriptor(globalThis, "window")?.get?.toString().includes("[native code]") ?? !1) && console.error(
    "Convex functions should not be imported in the browser. This will throw an error in future versions of `convex`. If this is a false negative, please report it to Convex support."
  );
}
n(ce, "assertNotBrowser");
function le(e) {
  return () => {
    let t = u.any();
    return typeof e == "object" && e.args !== void 0 && (t = Y(e.args)), JSON.stringify(t.json);
  };
}
n(le, "exportArgs");
function fe(e) {
  return () => {
    let t;
    return typeof e == "object" && e.returns !== void 0 && (t = Y(e.returns)), JSON.stringify(t ? t.json : null);
  };
}
n(fe, "exportReturns");
var pr = /* @__PURE__ */ n((e) => {
  let t = typeof e == "function" ? e : e.handler, r = ue(
    "internalMutation",
    t
  );
  return ce(), r.isMutation = !0, r.isInternal = !0, r.invokeMutation = (o) => lr(t, o), r.exportArgs = le(e), r.exportReturns = fe(e), r._handler = t, r;
}, "internalMutationGeneric");
async function dr(e, t) {
  let r = "", o = m(JSON.parse(t)), s = {
    db: Oe(),
    auth: re(r),
    storage: $e(r),
    runQuery: /* @__PURE__ */ n((a, p) => Ne("query", a, p), "runQuery")
  }, i = await Pe(e, s, o);
  return ht(i), JSON.stringify(d(i === void 0 ? null : i));
}
n(dr, "invokeQuery");
var hr = /* @__PURE__ */ n((e) => {
  let t = typeof e == "function" ? e : e.handler, r = ue("internalQuery", t);
  return ce(), r.isQuery = !0, r.isInternal = !0, r.invokeQuery = (o) => dr(t, o), r.exportArgs = le(e), r.exportReturns = fe(e), r._handler = t, r;
}, "internalQueryGeneric");
async function mt(e, t, r) {
  let o = m(JSON.parse(r)), i = {
    ...We(t),
    auth: re(t),
    scheduler: lt(t),
    storage: dt(t),
    vectorSearch: Xe(t)
  }, a = await Pe(e, i, o);
  return JSON.stringify(d(a === void 0 ? null : a));
}
n(mt, "invokeAction");
var mr = /* @__PURE__ */ n((e) => {
  let t = typeof e == "function" ? e : e.handler, r = ue("action", t);
  return ce(), r.isAction = !0, r.isPublic = !0, r.invokeAction = (o, s) => mt(t, o, s), r.exportArgs = le(e), r.exportReturns = fe(e), r._handler = t, r;
}, "actionGeneric"), yr = /* @__PURE__ */ n((e) => {
  let t = typeof e == "function" ? e : e.handler, r = ue("internalAction", t);
  return ce(), r.isAction = !0, r.isInternal = !0, r.invokeAction = (o, s) => mt(t, o, s), r.exportArgs = le(e), r.exportReturns = fe(e), r._handler = t, r;
}, "internalActionGeneric");
async function Ne(e, t, r) {
  let o = S(r), s = {
    udfType: e,
    args: d(o),
    ...A(t)
  }, i = await l("1.0/runUdf", s);
  return m(i);
}
n(Ne, "runUdf");

// node_modules/convex/dist/esm/server/pagination.js
var Do = u.object({
  numItems: u.number(),
  cursor: u.union(u.string(), u.null()),
  endCursor: u.optional(u.union(u.string(), u.null())),
  id: u.optional(u.number()),
  maximumRowsRead: u.optional(u.number()),
  maximumBytesRead: u.optional(u.number())
});

// node_modules/convex/dist/esm/server/schema.js
var gr = Object.defineProperty, xr = /* @__PURE__ */ n((e, t, r) => t in e ? gr(e, t, { enumerable: !0, configurable: !0, writable: !0, value: r }) : e[t] = r, "__defNormalProp"), O = /* @__PURE__ */ n((e, t, r) => xr(e, typeof t != "symbol" ? t + "" : t, r), "__publicField"), pe = class {
  static {
    n(this, "TableDefinition");
  }
  /**
   * @internal
   */
  constructor(t) {
    O(this, "indexes"), O(this, "searchIndexes"), O(this, "vectorIndexes"), O(this, "validator"), this.indexes = [], this.searchIndexes = [], this.vectorIndexes = [], this.validator = t;
  }
  /**
   * This API is experimental: it may change or disappear.
   *
   * Returns indexes defined on this table.
   * Intended for the advanced use cases of dynamically deciding which index to use for a query.
   * If you think you need this, please chime in on ths issue in the Convex JS GitHub repo.
   * https://github.com/get-convex/convex-js/issues/49
   */
  " indexes"() {
    return this.indexes;
  }
  /**
   * Define an index on this table.
   *
   * To learn about indexes, see [Defining Indexes](https://docs.convex.dev/using/indexes).
   *
   * @param name - The name of the index.
   * @param fields - The fields to index, in order. Must specify at least one
   * field.
   * @returns A {@link TableDefinition} with this index included.
   */
  index(t, r) {
    return this.indexes.push({ indexDescriptor: t, fields: r }), this;
  }
  /**
   * Define a search index on this table.
   *
   * To learn about search indexes, see [Search](https://docs.convex.dev/text-search).
   *
   * @param name - The name of the index.
   * @param indexConfig - The search index configuration object.
   * @returns A {@link TableDefinition} with this search index included.
   */
  searchIndex(t, r) {
    return this.searchIndexes.push({
      indexDescriptor: t,
      searchField: r.searchField,
      filterFields: r.filterFields || []
    }), this;
  }
  /**
   * Define a vector index on this table.
   *
   * To learn about vector indexes, see [Vector Search](https://docs.convex.dev/vector-search).
   *
   * @param name - The name of the index.
   * @param indexConfig - The vector index configuration object.
   * @returns A {@link TableDefinition} with this vector index included.
   */
  vectorIndex(t, r) {
    return this.vectorIndexes.push({
      indexDescriptor: t,
      vectorField: r.vectorField,
      dimensions: r.dimensions,
      filterFields: r.filterFields || []
    }), this;
  }
  /**
   * Work around for https://github.com/microsoft/TypeScript/issues/57035
   */
  self() {
    return this;
  }
  /**
   * Export the contents of this definition.
   *
   * This is called internally by the Convex framework.
   * @internal
   */
  export() {
    let t = this.validator.json;
    if (typeof t != "object")
      throw new Error(
        "Invalid validator: please make sure that the parameter of `defineTable` is valid (see https://docs.convex.dev/database/schemas)"
      );
    return {
      indexes: this.indexes,
      searchIndexes: this.searchIndexes,
      vectorIndexes: this.vectorIndexes,
      documentType: t
    };
  }
};
function Be(e) {
  return be(e) ? new pe(e) : new pe(u.object(e));
}
n(Be, "defineTable");
var Fe = class {
  static {
    n(this, "SchemaDefinition");
  }
  /**
   * @internal
   */
  constructor(t, r) {
    O(this, "tables"), O(this, "strictTableNameTypes"), O(this, "schemaValidation"), this.tables = t, this.schemaValidation = r?.schemaValidation === void 0 ? !0 : r.schemaValidation;
  }
  /**
   * Export the contents of this definition.
   *
   * This is called internally by the Convex framework.
   * @internal
   */
  export() {
    return JSON.stringify({
      tables: Object.entries(this.tables).map(([t, r]) => {
        let { indexes: o, searchIndexes: s, vectorIndexes: i, documentType: a } = r.export();
        return {
          tableName: t,
          indexes: o,
          searchIndexes: s,
          vectorIndexes: i,
          documentType: a
        };
      }),
      schemaValidation: this.schemaValidation
    });
  }
};
function yt(e, t) {
  return new Fe(e, t);
}
n(yt, "defineSchema");
var is = yt({
  _scheduled_functions: Be({
    name: u.string(),
    args: u.array(u.any()),
    scheduledTime: u.float64(),
    completedTime: u.optional(u.float64()),
    state: u.union(
      u.object({ kind: u.literal("pending") }),
      u.object({ kind: u.literal("inProgress") }),
      u.object({ kind: u.literal("success") }),
      u.object({ kind: u.literal("failed"), error: u.string() }),
      u.object({ kind: u.literal("canceled") })
    )
  }),
  _storage: Be({
    sha256: u.string(),
    size: u.float64(),
    contentType: u.optional(u.string())
  })
});

export {
  u as a,
  K as b,
  pr as c,
  hr as d,
  mr as e,
  yr as f,
  Jt as g,
  kt as h
};
//# sourceMappingURL=UDHF6CTX.js.map
