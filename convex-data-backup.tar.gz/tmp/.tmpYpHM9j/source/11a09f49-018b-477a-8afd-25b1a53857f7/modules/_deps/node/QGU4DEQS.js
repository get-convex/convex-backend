import {
  c as h
} from "./PDGHC3PS.js";
import {
  a as o
} from "./UDHF6CTX.js";
import {
  a as f
} from "./V7X2J7BI.js";

// convex/lib/gcpChirpCommon.ts
function A() {
  return {
    project: process.env.GOOGLE_CLOUD_PROJECT || "ai-sales-hub-dev-new",
    sttLocation: "asia-southeast1",
    // Chirp 2が使えるリージョン
    llmLocation: "us-central1",
    // Gemini-1.0-proがいるリージョン
    recognizer: `projects/${process.env.GOOGLE_CLOUD_PROJECT || "ai-sales-hub-dev-new"}/locations/asia-southeast1/recognizers/default`,
    defaultLanguage: "ja-JP"
  };
}
f(A, "getGcpConfig");
async function w(n, t, r = {}) {
  try {
    n.startsWith("https://storage.googleapis.com/") && (n = n.replace("https://storage.googleapis.com/", "gs://"), console.log(`[performGcpChirpTranscriptionInternal] URL\u5909\u63DB: ${n}`)), console.log(`[performGcpChirpTranscriptionInternal] GCE\u76F4\u63A5\u547C\u3073\u51FA\u3057\u3067\u958B\u59CB: ${n}`), console.log(`[performGcpChirpTranscriptionInternal] \u30D5\u30A1\u30A4\u30EB\u30BF\u30A4\u30D7: ${t}`), console.log("[performGcpChirpTranscriptionInternal] \u30AA\u30D7\u30B7\u30E7\u30F3:", r), (t.includes("m4a") || t.includes("aac") || t.includes("mp4")) && (console.warn("\u26A0\uFE0F [M4A\u5BFE\u5FDC\u8B66\u544A] GCP Speech API v2\u3067M4A\uFF08AAC\uFF09\u306F\u73FE\u5728\u672A\u5BFE\u5FDC\u3067\u3059"), console.warn("\u26A0\uFE0F [M4A\u5BFE\u5FDC\u8B66\u544A] API\u306F\u6210\u529F\u3057\u307E\u3059\u304C\u3001\u7D50\u679C\u304C0\u6587\u5B57\u306B\u306A\u308B\u53EF\u80FD\u6027\u304C\u3042\u308A\u307E\u3059"), console.warn("\u26A0\uFE0F [M4A\u5BFE\u5FDC\u8B66\u544A] \u63A8\u5968\u5BFE\u7B56\uFF1A\u4E8B\u524D\u306BFLAC/WAV\u5F62\u5F0F\u306B\u5909\u63DB\u3057\u3066\u304F\u3060\u3055\u3044"), console.warn("\u26A0\uFE0F [M4A\u5BFE\u5FDC\u8B66\u544A] \u8A73\u7D30: https://issuetracker.google.com/issues/166478543"));
    let c = await import("./65SZIU7D.js");
    console.log("[performGcpChirpTranscriptionInternal] GCP Speech API v2\u30AF\u30E9\u30A4\u30A2\u30F3\u30C8\u521D\u671F\u5316"), console.log("[performGcpChirpTranscriptionInternal] SpeechModule:", Object.keys(c));
    let l = A(), s = c.default?.v2?.SpeechClient;
    if (console.log("[performGcpChirpTranscriptionInternal] v2.SpeechClient:", typeof s), !s)
      throw new Error("v2.SpeechClient\u304C\u898B\u3064\u304B\u308A\u307E\u305B\u3093");
    let d = new s({
      projectId: l.project,
      apiEndpoint: "asia-southeast1-speech.googleapis.com"
      // リージョン最適化
    }), u = {
      ja: "ja-JP",
      en: "en-US",
      zh: "zh-CN",
      ko: "ko-KR",
      es: "es-ES",
      fr: "fr-FR",
      de: "de-DE"
    }, e = r.language ? u[r.language] || r.language : "ja-JP";
    console.log(`[performGcpChirpTranscriptionInternal] \u51E6\u7406\u958B\u59CB - \u30D5\u30A1\u30A4\u30EB: ${n}, \u8A00\u8A9E: ${e}`), console.log(`[performGcpChirpTranscriptionInternal] \u30D7\u30ED\u30B8\u30A7\u30AF\u30C8: ${l.project}`), console.log(`[performGcpChirpTranscriptionInternal] \u30EA\u30FC\u30B8\u30E7\u30F3: ${l.sttLocation}`), console.log("[performGcpChirpTranscriptionInternal] autoDecodingConfig\u4F7F\u7528\uFF08M4A\u4EE5\u5916\u3067\u63A8\u5968\uFF09");
    let i = {
      enableAutomaticPunctuation: !0,
      enableSpeakerDiarization: r.enableSpeakerDiarization || !1,
      diarizationSpeakerCount: r.enableSpeakerDiarization ? 6 : void 0,
      enableWordTimeOffsets: !0,
      enableWordConfidence: !0
    }, g = {
      recognizer: `projects/${l.project}/locations/${l.sttLocation}/recognizers/_`,
      config: {
        autoDecodingConfig: {},
        // 自動判別（FLAC/WAV/OGG_OPUSで推奨）
        model: "chirp_2",
        languageCodes: [e],
        features: i
      },
      files: [{
        uri: n
      }],
      recognitionOutputConfig: {
        inlineResponseConfig: {}
      }
    };
    console.log("[performGcpChirpTranscriptionInternal] batchRecognize API\u547C\u3073\u51FA\u3057\u958B\u59CB (autoDecoding)"), console.log("[performGcpChirpTranscriptionInternal] batchRequest:", JSON.stringify(g, null, 2));
    try {
      let [a] = await d.batchRecognize(g);
      console.log(`[performGcpChirpTranscriptionInternal] batchRecognize operation\u958B\u59CB: ${a.name}`);
      let [p] = await a.promise();
      return console.log("[performGcpChirpTranscriptionInternal] batchRecognize\u5B8C\u4E86 (autoDecoding)"), console.log("[performGcpChirpTranscriptionInternal] response keys:", Object.keys(p || {})), await R(p, n, t, e);
    } catch (a) {
      if (console.warn("[performGcpChirpTranscriptionInternal] autoDecoding\u5931\u6557\u3001FLAC/WAV\u63A8\u5968\u8B66\u544A:", a?.message), t.includes("m4a") || t.includes("aac") || t.includes("mp4"))
        return console.error("\u274C [M4A\u672A\u5BFE\u5FDC\u78BA\u8A8D] GCP Speech API v2\u3067M4A\u30D5\u30A1\u30A4\u30EB\u306E\u51E6\u7406\u306B\u5931\u6557\u3057\u307E\u3057\u305F"), console.error("\u274C [\u89E3\u6C7A\u7B56] M4A\u30D5\u30A1\u30A4\u30EB\u3092FLAC/WAV\u5F62\u5F0F\u306B\u5909\u63DB\u3057\u3066\u304B\u3089\u518D\u8A66\u884C\u3057\u3066\u304F\u3060\u3055\u3044"), console.error("\u274C [\u5909\u63DB\u4F8B] ffmpeg -i input.m4a -ac 1 -ar 16000 -c:a flac output.flac"), {
          text: "",
          segments: [],
          confidence: 0,
          duration_seconds: 0,
          error: "M4A\u5F62\u5F0F\u306F\u73FE\u5728\u672A\u5BFE\u5FDC\u3067\u3059\u3002FLAC/WAV\u5F62\u5F0F\u306B\u5909\u63DB\u3057\u3066\u304F\u3060\u3055\u3044\u3002"
        };
      throw a;
    }
  } catch (c) {
    return console.error("[performGcpChirpTranscriptionInternal] \u30A8\u30E9\u30FC:", c), console.error("[performGcpChirpTranscriptionInternal] \u30A8\u30E9\u30FC\u30BF\u30A4\u30D7:", typeof c), console.error("[performGcpChirpTranscriptionInternal] \u30A8\u30E9\u30FC\u30E1\u30C3\u30BB\u30FC\u30B8:", c?.message), console.error("[performGcpChirpTranscriptionInternal] \u30A8\u30E9\u30FC\u30B9\u30BF\u30C3\u30AF:", c?.stack), {
      text: "",
      segments: [],
      confidence: 0,
      duration_seconds: 0,
      error: c?.message || "Unknown error"
    };
  }
}
f(w, "performGcpChirpTranscriptionInternal");
async function R(n, t, r, c) {
  let l = "", s = [], d = 0;
  if (n && n.results) {
    console.log("[processTranscriptionResponse] response.results:", Object.keys(n.results));
    for (let e of Object.values(n.results)) {
      if (console.log("[processTranscriptionResponse] fileResult keys:", Object.keys(e || {})), console.log("[processTranscriptionResponse] fileResult.error:", e.error), console.log("[processTranscriptionResponse] fileResult.transcript:", e.transcript), console.log("[processTranscriptionResponse] fileResult.inlineResult:", !!e.inlineResult), e.error)
        throw console.error("[processTranscriptionResponse] \u30D5\u30A1\u30A4\u30EB\u51E6\u7406\u30A8\u30E9\u30FC:", e.error), new Error(`GCP Speech API\u51E6\u7406\u30A8\u30E9\u30FC: ${e.error.message || "Unknown error"}`);
      let i = null;
      if (e.inlineResult && e.inlineResult.results ? (i = e.inlineResult.results, console.log("[processTranscriptionResponse] inlineResult.results length:", i.length)) : e.transcript && e.transcript.results && (i = e.transcript.results, console.log("[processTranscriptionResponse] transcript.results length:", i.length)), (!i || i.length === 0) && (console.warn("[processTranscriptionResponse] \u8EE2\u5199\u7D50\u679C\u304C\u7A7A\u3067\u3059"), console.warn("[processTranscriptionResponse] \u53EF\u80FD\u306A\u539F\u56E0\u5206\u6790:"), console.warn(`- \u30D5\u30A1\u30A4\u30EBURL: ${t}`), console.warn(`- \u30D5\u30A1\u30A4\u30EB\u5F62\u5F0F: ${r}`), console.warn(`- \u8A00\u8A9E\u8A2D\u5B9A: ${c}`), r.includes("m4a") || r.includes("aac") || r.includes("mp4") ? (console.warn("- \u26A0\uFE0F M4A\uFF08AAC\uFF09\u30D5\u30A1\u30A4\u30EB\u306FGCP Speech API v2\u3067\u73FE\u5728\u672A\u5BFE\u5FDC\u3067\u3059"), console.warn("- \u26A0\uFE0F \u63A8\u5968\u89E3\u6C7A\u7B56\uFF1AFLAC/WAV\u5F62\u5F0F\u3078\u306E\u5909\u63DB"), console.warn("- \u26A0\uFE0F \u5909\u63DB\u30B3\u30DE\u30F3\u30C9\u4F8B\uFF1Affmpeg -i input.m4a -ac 1 -ar 16000 -c:a flac output.flac"), console.warn("- \u26A0\uFE0F \u8A73\u7D30\uFF1Ahttps://issuetracker.google.com/issues/166478543")) : (console.warn("- \u97F3\u58F0\u30D5\u30A1\u30A4\u30EB\u304C\u7121\u97F3\u58F0\u306E\u53EF\u80FD\u6027"), console.warn("- \u30B5\u30F3\u30D7\u30EB\u30EC\u30FC\u30C8/\u30C1\u30E3\u30F3\u30CD\u30EB\u8A2D\u5B9A\u304C\u4E0D\u4E00\u81F4\u306E\u53EF\u80FD\u6027")), e.metadata && console.log("[processTranscriptionResponse] \u30D5\u30A1\u30A4\u30EB\u30E1\u30BF\u30C7\u30FC\u30BF:", e.metadata)), i && i.length > 0) {
        for (let g of i)
          if (g.alternatives && g.alternatives.length > 0) {
            let a = g.alternatives[0];
            if (a.transcript && (l += a.transcript + `
`), a.words && a.words.length > 0)
              for (let p of a.words) {
                let m = parseFloat(p.startOffset?.seconds || "0") + parseFloat(p.startOffset?.nanos || "0") / 1e9, C = parseFloat(p.endOffset?.seconds || "0") + parseFloat(p.endOffset?.nanos || "0") / 1e9;
                s.push({
                  start: m,
                  end: C,
                  text: p.word || "",
                  confidence: a.confidence || 0.8,
                  speaker: p.speakerTag ? `Speaker ${p.speakerTag}` : void 0
                });
              }
            else
              s.push({
                start: 0,
                end: 0,
                text: a.transcript || "",
                confidence: a.confidence || 0.8
              });
          }
      }
    }
  }
  if (n.totalBilledDuration && (console.log("[processTranscriptionResponse] \u8ACB\u6C42\u5BFE\u8C61\u6642\u9593:", n.totalBilledDuration), d = parseFloat(n.totalBilledDuration.seconds || "0"), d === 0 && (console.warn("[processTranscriptionResponse] \u8ACB\u6C42\u6642\u9593\u304C0\u79D2 - \u30D5\u30A1\u30A4\u30EB\u306B\u97F3\u58F0\u304C\u542B\u307E\u308C\u3066\u3044\u306A\u3044\u53EF\u80FD\u6027"), r.includes("m4a") || r.includes("aac") || r.includes("mp4"))))
    return console.error("\u274C [M4A\u672A\u5BFE\u5FDC\u78BA\u8A8D] totalBilledDuration=0\u79D2\u3067M4A\u672A\u5BFE\u5FDC\u304C\u78BA\u5B9A\u3057\u307E\u3057\u305F"), {
      text: "",
      segments: [],
      confidence: 0,
      duration_seconds: 0,
      error: "M4A\uFF08AAC\uFF09\u5F62\u5F0F\u306F\u73FE\u5728GCP Speech API v2\u3067\u672A\u5BFE\u5FDC\u3067\u3059\u3002FLAC/WAV\u5F62\u5F0F\u306B\u5909\u63DB\u3057\u3066\u304F\u3060\u3055\u3044\u3002"
    };
  s.length === 0 && l && s.push({
    start: 0,
    end: 0,
    text: l.trim(),
    confidence: 0.8
  });
  let u = {
    text: l.trim(),
    segments: s,
    confidence: s.length > 0 ? s.reduce((e, i) => e + (i.confidence || 0), 0) / s.length : 0.8,
    duration_seconds: s.length > 0 ? Math.max(...s.map((e) => e.end)) : 0
  };
  if (console.log("[processTranscriptionResponse] \u6587\u5B57\u8D77\u3053\u3057\u5B8C\u4E86:"), console.log(`- \u30C6\u30AD\u30B9\u30C8\u9577: ${u.text.length}\u6587\u5B57`), console.log(`- \u30BB\u30B0\u30E1\u30F3\u30C8\u6570: ${u.segments?.length || 0}\u500B`), console.log(`- \u4FE1\u983C\u5EA6: ${u.confidence}`), console.log(`- \u6301\u7D9A\u6642\u9593: ${u.duration_seconds}\u79D2`), u.text.length === 0 && !r.includes("m4a") && !r.includes("aac") && !r.includes("mp4"))
    throw new Error("GCP Chirp 2 API\u304B\u3089\u97F3\u58F0\u8EE2\u5199\u7D50\u679C\u304C\u5F97\u3089\u308C\u307E\u305B\u3093\u3067\u3057\u305F\u3002\u97F3\u58F0\u30D5\u30A1\u30A4\u30EB\u307E\u305F\u306F\u8A2D\u5B9A\u3092\u78BA\u8A8D\u3057\u3066\u304F\u3060\u3055\u3044\u3002");
  return u;
}
f(R, "processTranscriptionResponse");
var b = h({
  args: {
    fileUrl: o.string(),
    fileType: o.string(),
    options: o.object({
      enableSpeakerDiarization: o.optional(o.boolean()),
      language: o.optional(o.string())
    })
  },
  returns: o.object({
    text: o.string(),
    segments: o.optional(o.any()),
    confidence: o.optional(o.number()),
    duration_seconds: o.optional(o.number())
  }),
  handler: /* @__PURE__ */ f(async (n, t) => await w(t.fileUrl, t.fileType, t.options), "handler")
});

export {
  w as a,
  b
};
//# sourceMappingURL=QGU4DEQS.js.map
