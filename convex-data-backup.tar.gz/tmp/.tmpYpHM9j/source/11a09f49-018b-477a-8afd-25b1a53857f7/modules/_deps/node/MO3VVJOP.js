import {
  a
} from "./SEHFPZI7.js";
import "./V7X2J7BI.js";
export {
  a as CompanyProposalEvaluator
};
//# sourceMappingURL=MO3VVJOP.js.map
