import {
  c as v
} from "./PDGHC3PS.js";
import {
  a as r
} from "./UDHF6CTX.js";
import {
  a as u
} from "./V7X2J7BI.js";

// convex/lib/transcriptionConfig.ts
function I() {
  return {
    enabled: process.env.TRANSCRIPTION_ENABLED === "true",
    enabledForVideos: process.env.TRANSCRIPTION_VIDEOS_ENABLED === "true",
    enabledForTraining: process.env.TRANSCRIPTION_TRAINING_ENABLED === "true",
    gcpChirpEnabled: !!process.env.GOOGLE_APPLICATION_CREDENTIALS && !!process.env.GOOGLE_CLOUD_PROJECT,
    geminiEnabled: !!process.env.GEMINI_API_KEY,
    environment: "production",
    gcpProject: process.env.GOOGLE_CLOUD_PROJECT || "mezame-ai",
    defaultLanguage: process.env.DEFAULT_TRANSCRIPTION_LANGUAGE || "ja"
  };
}
u(I, "getTranscriptionConfig");

// convex/lib/elevenLabsCommon.ts
async function _(d, a, l = {}) {
  try {
    console.log(`[performElevenLabsTranscriptionInternal] \u958B\u59CB: ${d}`), console.log(`[performElevenLabsTranscriptionInternal] \u30D5\u30A1\u30A4\u30EB\u30BF\u30A4\u30D7: ${a}`), console.log("[performElevenLabsTranscriptionInternal] \u30AA\u30D7\u30B7\u30E7\u30F3:", l);
    let o = process.env.ELEVENLABS_API_KEY;
    if (console.log(`[performElevenLabsTranscriptionInternal] API\u30AD\u30FC\u78BA\u8A8D: ${o ? "\u8A2D\u5B9A\u6E08\u307F" : "\u672A\u8A2D\u5B9A"} (\u9577\u3055: ${o?.length || 0})`), !o)
      throw new Error("ELEVENLABS_API_KEY is not configured");
    console.log(`[performElevenLabsTranscriptionInternal] \u97F3\u58F0\u30D5\u30A1\u30A4\u30EB\u3092\u30C0\u30A6\u30F3\u30ED\u30FC\u30C9\u4E2D: ${d}`);
    let n, s;
    try {
      if (n = await fetch(d), console.log(`[performElevenLabsTranscriptionInternal] fetch\u5B8C\u4E86: status=${n.status}, ok=${n.ok}`), !n.ok) {
        let e = await n.text().catch(() => "\u30EC\u30B9\u30DD\u30F3\u30B9\u30C6\u30AD\u30B9\u30C8\u53D6\u5F97\u4E0D\u53EF");
        throw new Error(`\u97F3\u58F0\u30D5\u30A1\u30A4\u30EB\u306E\u53D6\u5F97\u306B\u5931\u6557: ${n.status} ${n.statusText} - ${e}`);
      }
      if (s = await n.arrayBuffer(), console.log(`[performElevenLabsTranscriptionInternal] \u97F3\u58F0\u30D5\u30A1\u30A4\u30EB\u30B5\u30A4\u30BA: ${s.byteLength} bytes`), s.byteLength === 0)
        throw new Error(`\u97F3\u58F0\u30D5\u30A1\u30A4\u30EB\u304C\u7A7A\u3067\u3059: ${d}`);
      if (s.byteLength > 2 * 1024 * 1024 * 1024)
        throw new Error(`\u97F3\u58F0\u30D5\u30A1\u30A4\u30EB\u304C\u5927\u304D\u3059\u304E\u307E\u3059 (${Math.round(s.byteLength / 1024 / 1024)}MB): 2GB\u4EE5\u4E0B\u306B\u3057\u3066\u304F\u3060\u3055\u3044`);
    } catch (e) {
      throw console.error("[performElevenLabsTranscriptionInternal] \u30C0\u30A6\u30F3\u30ED\u30FC\u30C9\u30A8\u30E9\u30FC:", e), new Error(`\u97F3\u58F0\u30D5\u30A1\u30A4\u30EB\u306E\u30C0\u30A6\u30F3\u30ED\u30FC\u30C9\u306B\u5931\u6557\u3057\u307E\u3057\u305F: ${e instanceof Error ? e.message : String(e)}`);
    }
    let h = I(), x = {
      ja: "jpn",
      // 日本語
      en: "eng",
      // 英語  
      zh: "zho",
      // 中国語
      ko: "kor",
      // 韓国語
      es: "spa",
      // スペイン語
      fr: "fra",
      // フランス語
      de: "deu"
      // ドイツ語
    }, E = l.language ? x[l.language] || l.language : h.defaultLanguage, T = "scribe_v1";
    console.log(`[performElevenLabsTranscriptionInternal] \u6587\u5B57\u8D77\u3053\u3057\u958B\u59CB - \u8A00\u8A9E: ${E}, \u30E2\u30C7\u30EB: ${T}`);
    let f = a, L = {
      "audio/x-m4a": "audio/m4a",
      "audio/x-mp3": "audio/mp3",
      "audio/mpeg": "audio/mp3",
      "audio/x-wav": "audio/wav",
      "audio/wave": "audio/wav",
      "audio/x-flac": "audio/flac",
      "audio/x-ogg": "audio/ogg",
      "audio/ogg-vorbis": "audio/ogg",
      "audio/mp4": "audio/m4a",
      "audio/aac": "audio/m4a",
      "audio/x-aac": "audio/m4a",
      "audio/webm": "audio/webm",
      "audio/opus": "audio/ogg"
    };
    L[a] && (f = L[a]), console.log(`[performElevenLabsTranscriptionInternal] \u30D5\u30A1\u30A4\u30EB\u30BF\u30A4\u30D7\u6B63\u898F\u5316: ${a} -> ${f}`);
    let c;
    try {
      c = new FormData(), console.log("[performElevenLabsTranscriptionInternal] FormData \u30AA\u30D6\u30B8\u30A7\u30AF\u30C8\u4F5C\u6210\u5B8C\u4E86");
      let e = new Uint8Array(s);
      console.log(`[performElevenLabsTranscriptionInternal] Uint8Array\u5909\u63DB\u5B8C\u4E86: ${e.length} bytes`);
      let t = new Blob([e], { type: f });
      console.log(`[performElevenLabsTranscriptionInternal] Blob\u4F5C\u6210\u5B8C\u4E86: ${t.size} bytes, type: ${t.type}`), c.append("file", t), c.append("model_id", T), c.append("language", E), l.enableSpeakerDiarization && c.append("speaker_boost", "true"), console.log("[performElevenLabsTranscriptionInternal] FormData prepared:", {
        fileSize: s.byteLength,
        fileType: f,
        model_id: T,
        language: E,
        speakerBoost: l.enableSpeakerDiarization
      });
    } catch (e) {
      throw console.error("[performElevenLabsTranscriptionInternal] FormData\u69CB\u7BC9\u30A8\u30E9\u30FC:", e), new Error(`FormData\u306E\u69CB\u7BC9\u306B\u5931\u6557\u3057\u307E\u3057\u305F: ${e instanceof Error ? e.message : String(e)}`);
    }
    let i = await fetch("https://api.elevenlabs.io/v1/speech-to-text", {
      method: "POST",
      headers: {
        "xi-api-key": o
      },
      body: c
    });
    if (!i.ok) {
      let e = await i.text(), t = `ElevenLabs API error: ${i.status} ${i.statusText}`;
      console.error("[performElevenLabsTranscriptionInternal] API Error Response:", {
        status: i.status,
        statusText: i.statusText,
        headers: {},
        errorText: e
      });
      try {
        let b = JSON.parse(e);
        b.detail && (t += ` - ${b.detail}`), b.message && (t += ` - ${b.message}`);
      } catch {
        t += ` - ${e}`;
      }
      throw new Error(t);
    }
    let p = await i.json();
    console.log("[performElevenLabsTranscriptionInternal] API\u5FDC\u7B54\u3092\u53D7\u4FE1:", {
      textLength: p.text?.length || 0,
      segmentsCount: p.segments?.length || 0
    });
    let g = p.segments?.map((e) => ({
      start: e.start_time || 0,
      end: e.end_time || 0,
      text: e.text || "",
      speaker: e.speaker ? `Speaker ${e.speaker}` : void 0,
      confidence: e.confidence || 0.8
    })) || [
      {
        start: 0,
        end: 0,
        text: p.text || "",
        confidence: p.confidence || 0.8
      }
    ], m = {
      text: p.text || "",
      segments: g,
      confidence: g.length > 0 ? g.reduce((e, t) => e + (t.confidence || 0), 0) / g.length : 0.8,
      duration_seconds: g.length > 0 ? Math.max(...g.map((e) => e.end)) : 0
    };
    return console.log(`[performElevenLabsTranscriptionInternal] \u5B8C\u4E86: ${m.text.length}\u6587\u5B57`), console.log(`[performElevenLabsTranscriptionInternal] \u30BB\u30B0\u30E1\u30F3\u30C8\u6570: ${m.segments?.length || 0}`), console.log(`[performElevenLabsTranscriptionInternal] \u4FE1\u983C\u5EA6: ${m.confidence}`), m;
  } catch (o) {
    console.error("[performElevenLabsTranscriptionInternal] \u30A8\u30E9\u30FC:", o), console.error("[performElevenLabsTranscriptionInternal] \u30A8\u30E9\u30FC\u30B9\u30BF\u30C3\u30AF:", o instanceof Error ? o.stack : "No stack trace");
    let n = "\u4E0D\u660E\u306A\u30A8\u30E9\u30FC";
    throw o instanceof Error && (n = o.message, console.error("[performElevenLabsTranscriptionInternal] \u30A8\u30E9\u30FC\u30E1\u30C3\u30BB\u30FC\u30B8:", n), n.includes("401") ? n = "API\u30AD\u30FC\u304C\u7121\u52B9\u3067\u3059\u3002ELEVENLABS_API_KEY\u3092\u78BA\u8A8D\u3057\u3066\u304F\u3060\u3055\u3044\u3002" : n.includes("429") ? n = "API\u30EC\u30FC\u30C8\u5236\u9650\u306B\u9054\u3057\u307E\u3057\u305F\u3002\u3057\u3070\u3089\u304F\u5F85\u3063\u3066\u304B\u3089\u518D\u8A66\u884C\u3057\u3066\u304F\u3060\u3055\u3044\u3002" : n.includes("400") ? n = "\u97F3\u58F0\u30D5\u30A1\u30A4\u30EB\u306E\u5F62\u5F0F\u307E\u305F\u306F\u30B5\u30A4\u30BA\u304C\u7121\u52B9\u3067\u3059\u3002" : n.includes("413") && (n = "\u97F3\u58F0\u30D5\u30A1\u30A4\u30EB\u304C\u5927\u304D\u3059\u304E\u307E\u3059\u30022GB\u4EE5\u4E0B\u306E\u30D5\u30A1\u30A4\u30EB\u3092\u4F7F\u7528\u3057\u3066\u304F\u3060\u3055\u3044\u3002")), new Error(`ElevenLabs\u6587\u5B57\u8D77\u3053\u3057\u51E6\u7406\u30A8\u30E9\u30FC: ${n}`);
  }
}
u(_, "performElevenLabsTranscriptionInternal");
var P = v({
  args: {
    fileUrl: r.string(),
    fileType: r.string(),
    options: r.object({
      enableSpeakerDiarization: r.optional(r.boolean()),
      language: r.optional(r.string())
    })
  },
  returns: r.object({
    text: r.string(),
    segments: r.optional(r.any()),
    confidence: r.optional(r.number()),
    duration_seconds: r.optional(r.number())
  }),
  handler: /* @__PURE__ */ u(async (d, a) => await _(a.fileUrl, a.fileType, a.options), "handler")
});

export {
  _ as a,
  P as b
};
//# sourceMappingURL=N4BEONGG.js.map
