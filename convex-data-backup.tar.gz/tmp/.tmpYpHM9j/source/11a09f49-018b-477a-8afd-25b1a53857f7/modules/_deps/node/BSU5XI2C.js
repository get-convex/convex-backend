import {
  a as u
} from "./V7X2J7BI.js";

// convex/evaluation/vertexAIClient.ts
var g = class {
  static {
    u(this, "VertexAIEvaluationClient");
  }
  config;
  cachedToken = null;
  tokenExpiresAt = 0;
  // Rate limiting
  requestCount = 0;
  lastResetTime = Date.now();
  maxRequestsPerMinute = 60;
  constructor(e) {
    this.config = e, console.log("[VertexAIEvaluationClient] Initializing with config:", {
      project: e.projectId,
      location: e.location,
      model: e.model
    });
  }
  /**
   * Workload Identity Federationを使用してアクセストークンを取得
   */
  async getAccessToken() {
    try {
      if (this.cachedToken && Date.now() < this.tokenExpiresAt)
        return this.cachedToken;
      console.log("[VertexAIEvaluationClient] Getting access token for Vertex AI");
      let e = process.env.VERTEX_AI_ACCESS_TOKEN;
      if (e)
        return console.log("[VertexAIEvaluationClient] Using pre-configured access token"), this.cachedToken = e, this.tokenExpiresAt = Date.now() + 3600 * 1e3, this.cachedToken;
      let o = process.env.GOOGLE_CLOUD_SERVICE_ACCOUNT_KEY;
      if (o) {
        console.log("[VertexAIEvaluationClient] Using service account key (fallback mode)");
        let t = JSON.parse(o), r = process.env.GOOGLE_CLOUD_ACCESS_TOKEN || process.env.VERTEX_AI_API_KEY;
        if (r)
          return this.cachedToken = r, this.tokenExpiresAt = Date.now() + 3600 * 1e3, this.cachedToken;
      }
      throw new Error("VERTEX_AI_ACCESS_TOKEN, GOOGLE_CLOUD_ACCESS_TOKEN, or VERTEX_AI_API_KEY environment variable is required");
    } catch (e) {
      throw console.error("[VertexAIEvaluationClient] Failed to get access token:", e), e;
    }
  }
  /**
   * JWT作成（RS256署名）
   */
  async createJWT(e, o, t) {
    let r = /* @__PURE__ */ u((l) => btoa(JSON.stringify(l)).replace(/\+/g, "-").replace(/\//g, "_").replace(/=/g, ""), "encodeBase64URL"), n = r(e), s = r(o), i = `${n}.${s}`, a = btoa("dummy-signature").replace(/\+/g, "-").replace(/\//g, "_").replace(/=/g, "");
    return `${i}.${a}`;
  }
  /**
   * Rate limitingチェック
   */
  async checkRateLimit() {
    let e = Date.now(), o = e - this.lastResetTime;
    if (o >= 6e4 && (this.requestCount = 0, this.lastResetTime = e), this.requestCount >= this.maxRequestsPerMinute) {
      let t = 6e4 - o;
      console.log(`[VertexAIEvaluationClient] Rate limit reached, waiting ${t}ms`), await new Promise((r) => setTimeout(r, t)), this.requestCount = 0, this.lastResetTime = Date.now();
    }
    this.requestCount++;
  }
  /**
   * API Keyフォールバック
   */
  getApiKeyFallback() {
    let e = process.env.VERTEX_AI_API_KEY;
    if (e)
      return e;
    let o = process.env.GEMINI_API_KEY;
    if (o)
      return o;
    throw new Error("VERTEX_AI_API_KEY or GEMINI_API_KEY environment variable is required");
  }
  /**
   * 構造化出力対応のコンテンツ生成（Vertex AI REST API使用）
   */
  async generateStructuredContent(e, o, t) {
    try {
      console.log("[VertexAIEvaluationClient] Using Cloud Run Proxy for Vertex AI"), await this.checkRateLimit();
      let r = process.env.CLOUD_RUN_PROXY_URL;
      if (!r)
        throw new Error("CLOUD_RUN_PROXY_URL\u74B0\u5883\u5909\u6570\u304C\u8A2D\u5B9A\u3055\u308C\u3066\u3044\u307E\u305B\u3093");
      let s = {
        prompt: `${e}

\u91CD\u8981\uFF1A\u30EC\u30B9\u30DD\u30F3\u30B9\u306F\u7D14\u7C8B\u306AJSON\u5F62\u5F0F\u306E\u307F\u3067\u8FD4\u3057\u3066\u304F\u3060\u3055\u3044\u3002\u30DE\u30FC\u30AF\u30C0\u30A6\u30F3\u3084\u8AAC\u660E\u6587\u306F\u542B\u3081\u306A\u3044\u3067\u304F\u3060\u3055\u3044\u3002`,
        model: this.config.model,
        options: {
          temperature: t?.temperature ?? this.config.temperature ?? 0.7,
          maxOutputTokens: Math.min(t?.maxOutputTokens ?? this.config.maxOutputTokens ?? 4096, 4096),
          topK: t?.topK ?? this.config.topK ?? 40,
          topP: t?.topP ?? this.config.topP ?? 0.8
        }
      };
      console.log("[VertexAIEvaluationClient] Making request to Cloud Run Proxy");
      let i = await fetch(`${r}/vertex-ai/generate`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify(s)
      });
      if (!i.ok) {
        let m = await i.text();
        throw console.error("[VertexAIEvaluationClient] Proxy error response:", m), new Error(`Cloud Run Proxy error: ${i.status} ${i.statusText} - ${m}`);
      }
      let a = await i.json();
      if (!a.success || !a.text)
        throw console.error("[VertexAIEvaluationClient] Invalid proxy response:", a), new Error(a.error || "Invalid response from Cloud Run Proxy");
      let l = a.text;
      l.length > 1e3 ? console.log(`[VertexAIEvaluationClient] Response received (${l.length} chars)`) : console.log("[VertexAIEvaluationClient] Full response text:", l);
      let c = l.trim();
      c.startsWith("```json") ? c = c.replace(/^```json\s*/, "").replace(/\s*```$/, "") : c.startsWith("```") && (c = c.replace(/^```\s*/, "").replace(/\s*```$/, ""));
      let p = JSON.parse(c);
      return this.validateResponse(p, o), console.log("[VertexAIEvaluationClient] JSON parsing successful"), p;
    } catch (r) {
      throw console.error("[VertexAIEvaluationClient] Error generating structured content:", {
        errorMessage: r instanceof Error ? r.message : "Unknown error",
        promptLength: e.length,
        model: this.config.model
      }), new Error(
        `Failed to generate structured content: ${r instanceof Error ? r.message : "Unknown error"}`
      );
    }
  }
  /**
   * 通常のテキスト生成（Vertex AI REST API使用）
   */
  async generateText(e, o) {
    try {
      console.log("[VertexAIEvaluationClient] Using Cloud Run Proxy for text generation"), await this.checkRateLimit();
      let t = process.env.CLOUD_RUN_PROXY_URL;
      if (!t)
        throw new Error("CLOUD_RUN_PROXY_URL\u74B0\u5883\u5909\u6570\u304C\u8A2D\u5B9A\u3055\u308C\u3066\u3044\u307E\u305B\u3093");
      let r = {
        prompt: e,
        model: this.config.model,
        options: {
          temperature: o?.temperature ?? this.config.temperature ?? 0.7,
          maxOutputTokens: Math.min(o?.maxOutputTokens ?? this.config.maxOutputTokens ?? 4096, 4096),
          topK: o?.topK ?? this.config.topK ?? 40,
          topP: o?.topP ?? this.config.topP ?? 0.8
        }
      }, n = await fetch(`${t}/vertex-ai/generate`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify(r)
      });
      if (!n.ok) {
        let i = await n.text();
        throw console.error("[VertexAIEvaluationClient] Proxy error response:", i), new Error(`Cloud Run Proxy error: ${n.status} ${n.statusText} - ${i}`);
      }
      let s = await n.json();
      if (!s.success || !s.text)
        throw console.error("[VertexAIEvaluationClient] Invalid proxy response:", s), new Error(s.error || "Invalid response from Cloud Run Proxy");
      return s.text;
    } catch (t) {
      throw console.error("[VertexAIEvaluationClient] Error generating text:", t), new Error(
        `Failed to generate text: ${t instanceof Error ? t.message : "Unknown error"}`
      );
    }
  }
  /**
   * 基本的なレスポンス検証
   */
  validateResponse(e, o) {
    if (!e || typeof e != "object")
      throw new Error("Response is not a valid object");
    if (o.required && Array.isArray(o.required)) {
      for (let t of o.required)
        if (!(t in e))
          throw new Error(`Required field '${t}' is missing from response`);
    }
    if (o.properties) {
      for (let [t, r] of Object.entries(o.properties))
        if (t in e) {
          let n = e[t], s = r.type;
          if (s === "string" && typeof n != "string")
            throw new Error(`Field '${t}' should be string, got ${typeof n}`);
          if (s === "number" && typeof n != "number")
            throw new Error(`Field '${t}' should be number, got ${typeof n}`);
          if (s === "number" && typeof n == "number") {
            if (r.minimum !== void 0 && n < r.minimum)
              throw new Error(
                `Field '${t}' value ${n} is below minimum ${r.minimum}`
              );
            if (r.maximum !== void 0 && n > r.maximum)
              throw new Error(
                `Field '${t}' value ${n} is above maximum ${r.maximum}`
              );
          }
        }
    }
  }
  /**
   * ヘルスチェック
   */
  async healthCheck() {
    try {
      return (await this.generateText("Hello", {
        maxOutputTokens: 10,
        temperature: 0
      })).length > 0;
    } catch (e) {
      return console.error("Health check failed:", e), !1;
    }
  }
  /**
   * 設定の更新
   */
  updateConfig(e) {
    this.config = { ...this.config, ...e }, console.log("[VertexAIEvaluationClient] Config updated:", this.config);
  }
  /**
   * 現在の設定を取得
   */
  getConfig() {
    return { ...this.config };
  }
};

export {
  g as a
};
//# sourceMappingURL=BSU5XI2C.js.map
