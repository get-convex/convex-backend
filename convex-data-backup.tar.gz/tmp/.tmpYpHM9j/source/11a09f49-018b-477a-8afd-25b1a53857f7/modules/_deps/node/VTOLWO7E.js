import {
  g as o,
  h as n
} from "./UDHF6CTX.js";

// convex/_generated/api.js
var e = o, p = o, r = n();

export {
  e as a,
  p as b,
  r as c
};
//# sourceMappingURL=VTOLWO7E.js.map
