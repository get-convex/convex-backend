import {
  b as a
} from "./UDHF6CTX.js";
import {
  a as l
} from "./V7X2J7BI.js";

// convex/auth.ts
var s = {
  ADMIN: "admin",
  TRAINER: "trainer",
  EMPLOYEE: "employee",
  VIEWER: "viewer"
};
async function m(t) {
  let n = await t.auth.getUserIdentity();
  if (!n) {
    if (typeof process < "u" && process.env.VITEST === "true") {
      let u = {
        subject: "test-user",
        tokenIdentifier: "test://test-user",
        email: "test@example.com",
        name: "Test User"
      };
      if ("db" in t && !("scheduler" in t)) {
        let c = t, o = await c.db.query("users").withIndex("by_clerk_user_id", (e) => e.eq("clerkUserId", "test-user")).first();
        if (o)
          return {
            identity: u,
            unifiedUserId: o._id,
            user: o,
            isAdmin: o.role === s.ADMIN
          };
        let f = await c.db.query("users").filter(
          (e) => e.or(
            e.eq(e.field("email"), "test@test.com"),
            e.eq(e.field("clerkUserId"), "test-user"),
            e.eq(e.field("tokenIdentifier"), "test://basic-test-user"),
            e.eq(e.field("tokenIdentifier"), "https://test.clerk.dev/basic-test-user")
          )
        ).collect();
        if (f.length > 0) {
          let e = f[0];
          return {
            identity: {
              subject: e.clerkUserId,
              tokenIdentifier: e.tokenIdentifier,
              email: e.email,
              name: e.name
            },
            unifiedUserId: e._id,
            user: e,
            isAdmin: e.role === s.ADMIN
          };
        }
      }
      return {
        identity: u,
        unifiedUserId: "test-user-id",
        user: {
          _id: "test-user-id",
          _creationTime: Date.now(),
          clerkUserId: "test-user",
          tokenIdentifier: "test://test-user",
          email: "test@example.com",
          emailVerified: !0,
          name: "Test User",
          firstName: "Test",
          lastName: "User",
          imageUrl: void 0,
          employeeId: void 0,
          department: void 0,
          position: void 0,
          role: s.ADMIN,
          isActive: !0,
          joinDate: Date.now(),
          lastLoginAt: Date.now()
        },
        isAdmin: !0
      };
    }
    throw new a("\u8A8D\u8A3C\u304C\u5FC5\u8981\u3067\u3059");
  }
  if ("scheduler" in t && "runQuery" in t)
    throw new a("ActionContext\u5185\u3067\u306E\u8A8D\u8A3C\u306F\u5BFE\u5FDC\u3057\u3066\u3044\u307E\u305B\u3093\u3002\u30D5\u30ED\u30F3\u30C8\u30A8\u30F3\u30C9\u3067\u8A8D\u8A3C\u3092\u5B8C\u4E86\u3057\u3066\u304F\u3060\u3055\u3044\u3002");
  let d = t, i = await d.db.query("users").withIndex("by_clerk_user_id", (r) => r.eq("clerkUserId", n.subject)).first();
  if (!i) {
    let r = await d.db.query("users").withIndex("by_token", (u) => u.eq("tokenIdentifier", n.tokenIdentifier)).first();
    if (!r)
      throw new a("\u30E6\u30FC\u30B6\u30FC\u304C\u898B\u3064\u304B\u308A\u307E\u305B\u3093");
    return {
      identity: n,
      unifiedUserId: r._id,
      user: r,
      isAdmin: r.role === s.ADMIN
    };
  }
  return {
    identity: n,
    unifiedUserId: i._id,
    user: i,
    isAdmin: i.role === s.ADMIN
  };
}
l(m, "requireUser");

export {
  m as a
};
//# sourceMappingURL=4BJOKGGA.js.map
