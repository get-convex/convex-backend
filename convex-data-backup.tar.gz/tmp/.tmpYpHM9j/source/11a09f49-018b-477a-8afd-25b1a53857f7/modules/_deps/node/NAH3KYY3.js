import {
  a as A
} from "./SEHFPZI7.js";
import {
  a as x
} from "./27HPQ4GU.js";
import {
  a as v
} from "./WLMMRF4U.js";
import {
  a as I
} from "./YKKTZAAP.js";
import {
  a as u
} from "./2SFASJNQ.js";
import {
  a as h
} from "./BSU5XI2C.js";
import {
  a as o
} from "./V7X2J7BI.js";

// convex/evaluation/config.ts
var E = {
  vertexAI: {
    projectId: process.env.VERTEX_AI_PROJECT_ID || "",
    location: process.env.VERTEX_AI_LOCATION || "us-central1",
    model: process.env.VERTEX_AI_MODEL || "gemini-1.5-pro",
    temperature: 0.1,
    maxOutputTokens: 32768,
    topK: 40,
    topP: 0.95
  },
  retry: {
    maxRetries: 3,
    initialDelay: 1e3,
    maxDelay: 1e4,
    exponentialBase: 2
  },
  timeout: {
    preprocessing: 45e3,
    // 45秒
    evaluation: 3e5,
    // 5分 (複雑なAI評価に対応)
    summaries: 18e4,
    // 3分
    meetingMinutes: 18e4,
    // 3分
    consolidation: 6e4
    // 1分
  },
  parallelProcessing: {
    enabled: !0,
    maxConcurrentJobs: 3
  },
  fallback: {
    enabled: !0,
    mockDataOnFailure: !0
  }
};
function p(i) {
  let e = { ...E };
  if (process.env.VERTEX_AI_PROJECT_ID && (e.vertexAI.projectId = process.env.VERTEX_AI_PROJECT_ID), process.env.VERTEX_AI_LOCATION && (e.vertexAI.location = process.env.VERTEX_AI_LOCATION), process.env.VERTEX_AI_MODEL ? e.vertexAI.model = process.env.VERTEX_AI_MODEL : process.env.GEMINI_MODEL && (e.vertexAI.model = process.env.GEMINI_MODEL), process.env.EVALUATION_TIMEOUT_MS) {
    let t = Number.parseInt(process.env.EVALUATION_TIMEOUT_MS, 10);
    !isNaN(t) && t > 0 && (e.timeout.evaluation = t);
  }
  return i === "development" && (e.timeout.evaluation = 42e4, e.retry.maxRetries = 2), i === "production" && (e.timeout.evaluation = 36e4, e.retry.maxRetries = 3), e;
}
o(p, "getProcessingConfig");
function w(i) {
  let e = [];
  i.vertexAI.projectId || e.push("Vertex AI project ID is required"), i.vertexAI.model || e.push("Vertex AI model is required"), i.vertexAI.temperature !== void 0 && (i.vertexAI.temperature < 0 || i.vertexAI.temperature > 2) && e.push("Temperature must be between 0 and 2"), i.vertexAI.maxOutputTokens !== void 0 && i.vertexAI.maxOutputTokens <= 0 && e.push("Max output tokens must be positive"), i.retry.maxRetries < 0 && e.push("Max retries must be non-negative");
  let t = Object.keys(i.timeout);
  for (let r of t)
    i.timeout[r] <= 0 && e.push(`Timeout for ${r} must be positive`);
  return {
    valid: e.length === 0,
    errors: e
  };
}
o(w, "validateConfig");

// convex/evaluation/evaluationEngine.ts
var m = class {
  static {
    o(this, "EvaluationEngine");
  }
  config;
  client;
  evaluators;
  constructor(e) {
    this.config = p(e);
    let t = w(this.config);
    if (!t.valid)
      throw new Error(`Invalid configuration: ${t.errors.join(", ")}`);
    this.client = new c(this.config), this.evaluators = {
      \u8B72\u6E21\u67B6\u96FB: new I(this.client),
      \u521D\u56DE\u9762\u8AC7: new x(this.client),
      AD\u7DE0\u7D50\u63D0\u6848: new v(this.client),
      \u4F01\u696D\u6982\u8981\u66F8\u63D0\u6848: new A(this.client)
    };
  }
  /**
   * メイン処理 - Dify互換インターフェース
   */
  async process(e) {
    let t = Date.now(), r = {
      transcriptionId: e.transcriptionId,
      videoType: e.videoType,
      startTime: t,
      phases: {},
      success: !1,
      errors: [],
      hasPartialFailure: !1
    };
    try {
      console.log(`Starting evaluation for ${e.transcriptionId}, type: ${e.videoType}`);
      let n = await this.executePhase("preprocessing", r, async () => await this.preprocessTranscript(e)), s = await this.executePhase("evaluation", r, async () => await this.evaluateVideo(n)), a = await this.executePhase("consolidation", r, async () => this.consolidateResults({
        evaluation: s,
        transcript_with_speaker: n.transcript
      }));
      return r.success = !0, r.totalDuration = Date.now() - t, console.log(
        `Evaluation completed for ${e.transcriptionId} in ${r.totalDuration}ms`
      ), {
        ...a,
        success: !0,
        metrics: r
      };
    } catch (n) {
      if (console.error(`Evaluation failed for ${e.transcriptionId}:`, n), r.success = !1, r.totalDuration = Date.now() - t, r.errors.push({
        phase: "evaluation",
        error: n instanceof Error ? n : new Error(String(n)),
        timestamp: Date.now()
      }), this.config.fallback.enabled)
        return {
          ...await this.generateFallbackResponse(e, n),
          success: !1,
          errors: r.errors,
          metrics: r
        };
      throw n;
    }
  }
  /**
   * フェーズ実行ヘルパー（メトリクス付き）
   */
  async executePhase(e, t, r) {
    let n = Date.now();
    t.phases[e] = {
      startTime: n,
      success: !1,
      retryCount: 0
    };
    try {
      let s = await this.executeWithTimeout(
        r,
        this.config.timeout[e],
        `${e} phase timeout`
      );
      return t.phases[e].endTime = Date.now(), t.phases[e].duration = Date.now() - n, t.phases[e].success = !0, s;
    } catch (s) {
      throw t.phases[e].endTime = Date.now(), t.phases[e].duration = Date.now() - n, t.phases[e].success = !1, t.phases[e].error = s instanceof Error ? s.message : String(s), t.errors.push({
        phase: e,
        error: s instanceof Error ? s : new Error(String(s)),
        timestamp: Date.now()
      }), s;
    }
  }
  /**
   * タイムアウト付き実行
   */
  async executeWithTimeout(e, t, r) {
    return Promise.race([
      e(),
      new Promise(
        (n, s) => setTimeout(() => s(new Error(r)), t)
      )
    ]);
  }
  /**
   * Phase 1: 前処理
   */
  async preprocessTranscript(e) {
    return {
      transcript: e.transcript,
      videoType: e.videoType,
      transcriptionId: e.transcriptionId,
      metadata: e.metadata || {}
    };
  }
  /**
   * Phase 2: 動画評価
   */
  async evaluateVideo(e) {
    let t = this.evaluators[e.videoType];
    t || (console.warn(`No evaluator found for video type: ${e.videoType}, using default evaluator (\u8B72\u6E21\u67B6\u96FB)`), t = this.evaluators.\u8B72\u6E21\u67B6\u96FB);
    let r = await t.evaluate(e);
    return {
      videoType: e.videoType,
      result: r
    };
  }
  /**
   * Phase 3: 結果統合
   */
  async consolidateResults(e) {
    return {
      evaluation: e.evaluation.result,
      transcript_with_speaker: e.transcript_with_speaker,
      // 将来的にここでサマリー・議事録も統合
      caseSummary: void 0,
      meetingSummary: void 0,
      meetingMinutes: void 0
    };
  }
  /**
   * フォールバック処理
   */
  async generateFallbackResponse(e, t) {
    return console.log(`Generating fallback response for ${e.videoType}`), {
      evaluation: this.generateMockEvaluation(e.videoType),
      transcript_with_speaker: e.transcript,
      caseSummary: void 0,
      meetingSummary: void 0,
      meetingMinutes: void 0
    };
  }
  /**
   * モック評価データ生成
   */
  generateMockEvaluation(e) {
    let r = "\u30B7\u30B9\u30C6\u30E0\u30A8\u30E9\u30FC\u306E\u305F\u3081\u3001\u66AB\u5B9A\u7684\u306A\u8A55\u4FA1\u3092\u8868\u793A\u3057\u3066\u3044\u307E\u3059\u3002\u8A73\u7D30\u306A\u5206\u6790\u306B\u3064\u3044\u3066\u306F\u3001\u518D\u5EA6\u8A55\u4FA1\u3092\u5B9F\u884C\u3057\u3066\u304F\u3060\u3055\u3044\u3002";
    switch (e) {
      case "\u8B72\u6E21\u67B6\u96FB":
        return {
          callTone: 2.5,
          callTone_analysis: r,
          callTone_strength: "\u8A55\u4FA1\u51E6\u7406\u4E2D\u306B\u30A8\u30E9\u30FC\u304C\u767A\u751F\u3057\u307E\u3057\u305F",
          callTone_weakness: "\u30B7\u30B9\u30C6\u30E0\u30A8\u30E9\u30FC\u306E\u305F\u3081\u8A73\u7D30\u5206\u6790\u4E0D\u53EF",
          callListening: 2.5,
          callListening_analysis: r,
          callListening_strength: "\u8A55\u4FA1\u51E6\u7406\u4E2D\u306B\u30A8\u30E9\u30FC\u304C\u767A\u751F\u3057\u307E\u3057\u305F",
          callListening_weakness: "\u30B7\u30B9\u30C6\u30E0\u30A8\u30E9\u30FC\u306E\u305F\u3081\u8A73\u7D30\u5206\u6790\u4E0D\u53EF",
          callScheduling: 2.5,
          callScheduling_analysis: r,
          callScheduling_strength: "\u8A55\u4FA1\u51E6\u7406\u4E2D\u306B\u30A8\u30E9\u30FC\u304C\u767A\u751F\u3057\u307E\u3057\u305F",
          callScheduling_weakness: "\u30B7\u30B9\u30C6\u30E0\u30A8\u30E9\u30FC\u306E\u305F\u3081\u8A73\u7D30\u5206\u6790\u4E0D\u53EF",
          callImportantInfo: 2.5,
          callImportantInfo_analysis: r,
          callImportantInfo_strength: "\u8A55\u4FA1\u51E6\u7406\u4E2D\u306B\u30A8\u30E9\u30FC\u304C\u767A\u751F\u3057\u307E\u3057\u305F",
          callImportantInfo_weakness: "\u30B7\u30B9\u30C6\u30E0\u30A8\u30E9\u30FC\u306E\u305F\u3081\u8A73\u7D30\u5206\u6790\u4E0D\u53EF",
          callDeepHearing: 2.5,
          callDeepHearing_analysis: r,
          callDeepHearing_strength: "\u8A55\u4FA1\u51E6\u7406\u4E2D\u306B\u30A8\u30E9\u30FC\u304C\u767A\u751F\u3057\u307E\u3057\u305F",
          callDeepHearing_weakness: "\u30B7\u30B9\u30C6\u30E0\u30A8\u30E9\u30FC\u306E\u305F\u3081\u8A73\u7D30\u5206\u6790\u4E0D\u53EF",
          overallComment: "\u30B7\u30B9\u30C6\u30E0\u30A8\u30E9\u30FC\u306E\u305F\u3081\u3001\u8A73\u7D30\u306A\u8A55\u4FA1\u3092\u5B9F\u884C\u3067\u304D\u307E\u305B\u3093\u3067\u3057\u305F\u3002\u518D\u5EA6\u304A\u8A66\u3057\u304F\u3060\u3055\u3044\u3002",
          improvementSummary: "\u30B7\u30B9\u30C6\u30E0\u30A8\u30E9\u30FC\u304C\u767A\u751F\u3057\u305F\u305F\u3081\u3001\u6539\u5584\u30DD\u30A4\u30F3\u30C8\u306E\u5206\u6790\u304C\u3067\u304D\u307E\u305B\u3093\u3067\u3057\u305F\u3002"
        };
      // 他のタイプも同様にモック生成（省略）
      default:
        return {
          overallComment: r,
          improvementSummary: "\u30B7\u30B9\u30C6\u30E0\u30A8\u30E9\u30FC\u304C\u767A\u751F\u3057\u307E\u3057\u305F\u3002"
        };
    }
  }
  /**
   * ヘルスチェック
   */
  async healthCheck() {
    try {
      return await this.client.healthCheck();
    } catch (e) {
      return console.error("Health check failed:", e), !1;
    }
  }
  /**
   * 設定更新
   */
  updateConfig(e) {
    this.config = { ...this.config, ...e }, e.vertexAI && this.client.updateConfig(e.vertexAI);
  }
};

// convex/evaluation/evaluationEngineV2.ts
var l = class {
  static {
    o(this, "HybridEvaluationEngine");
  }
  vertexAIClient;
  googleGenAIClient;
  config;
  useVertexAI;
  vertexAIFailed = !1;
  // フォールバック状態を記録
  constructor(e) {
    this.config = p(), e && (this.config = { ...this.config, ...e }), this.useVertexAI = process.env.USE_VERTEX_AI === "true", this.initializeClients();
  }
  initializeClients() {
    if (console.log(`[HybridEvaluationEngine] USE_VERTEX_AI=${process.env.USE_VERTEX_AI}, useVertexAI=${this.useVertexAI}`), this.useVertexAI && !this.vertexAIFailed) {
      let e = {
        projectId: process.env.VERTEX_AI_PROJECT_ID || process.env.GOOGLE_CLOUD_PROJECT_ID || "",
        location: process.env.VERTEX_AI_LOCATION || "asia-northeast1",
        model: process.env.VERTEX_AI_MODEL || "gemini-1.5-pro",
        temperature: this.config.vertexAI.temperature ?? 0.7,
        maxOutputTokens: this.config.vertexAI.maxOutputTokens ?? 8192,
        topK: this.config.vertexAI.topK ?? 40,
        topP: this.config.vertexAI.topP ?? 0.95
      };
      console.log("[HybridEvaluationEngine] Vertex AI config:", e);
      try {
        this.vertexAIClient = new h(e);
      } catch (t) {
        console.warn("[HybridEvaluationEngine] Vertex AI client initialization failed:", t), this.vertexAIFailed = !0, this.initializeFallbackClient();
      }
    } else
      this.initializeFallbackClient();
  }
  initializeFallbackClient() {
    this.googleGenAIClient || (console.log("[HybridEvaluationEngine] Using Google GenAI fallback"), this.googleGenAIClient = new c(this.config.vertexAI));
  }
  /**
   * 構造化出力対応のコンテンツ生成
   */
  async generateStructuredContent(e, t, r) {
    if (this.useVertexAI && this.vertexAIClient && !this.vertexAIFailed)
      try {
        return console.log("[HybridEvaluationEngine] Attempting Vertex AI generation"), await this.vertexAIClient.generateStructuredContent(e, t, r);
      } catch (n) {
        return console.warn("[HybridEvaluationEngine] Vertex AI failed, switching to fallback permanently:", n), this.vertexAIFailed = !0, this.initializeFallbackClient(), await this.googleGenAIClient.generateStructuredContent(e, t, r);
      }
    else
      return this.googleGenAIClient || this.initializeFallbackClient(), await this.googleGenAIClient.generateStructuredContent(e, t, r);
  }
  /**
   * テキスト生成
   */
  async generateText(e, t) {
    if (this.useVertexAI && this.vertexAIClient && !this.vertexAIFailed)
      try {
        return console.log("[HybridEvaluationEngine] Attempting Vertex AI text generation"), await this.vertexAIClient.generateText(e, t);
      } catch (r) {
        return console.warn("[HybridEvaluationEngine] Vertex AI text generation failed, switching to fallback permanently:", r), this.vertexAIFailed = !0, this.initializeFallbackClient(), await this.googleGenAIClient.generateText(e, t);
      }
    else
      return this.googleGenAIClient || this.initializeFallbackClient(), await this.googleGenAIClient.generateText(e, t);
  }
  /**
   * ヘルスチェック
   */
  async healthCheck() {
    try {
      return this.useVertexAI && this.vertexAIClient && !this.vertexAIFailed ? await this.vertexAIClient.healthCheck() : this.googleGenAIClient ? await this.googleGenAIClient.healthCheck() : !1;
    } catch (e) {
      return console.error("Health check failed:", e), !1;
    }
  }
  /**
   * 設定の更新
   */
  updateConfig(e) {
    if (this.config = { ...this.config, ...e }, this.useVertexAI && this.vertexAIClient && e.vertexAI && !this.vertexAIFailed) {
      let t = {};
      e.vertexAI.temperature !== void 0 && (t.temperature = e.vertexAI.temperature), e.vertexAI.maxOutputTokens !== void 0 && (t.maxOutputTokens = e.vertexAI.maxOutputTokens), e.vertexAI.topK !== void 0 && (t.topK = e.vertexAI.topK), e.vertexAI.topP !== void 0 && (t.topP = e.vertexAI.topP), this.vertexAIClient.updateConfig(t);
    } else this.googleGenAIClient && e.vertexAI && this.googleGenAIClient.updateConfig(e.vertexAI);
  }
  /**
   * 現在の設定を取得
   */
  getConfig() {
    return { ...this.config };
  }
  /**
   * 使用中のクライアント情報を取得
   */
  getClientInfo() {
    if (this.useVertexAI && this.vertexAIClient && !this.vertexAIFailed) {
      let e = this.vertexAIClient.getConfig();
      return {
        type: "Vertex AI",
        model: e.model,
        location: e.location
      };
    } else return this.googleGenAIClient ? {
      type: "Google GenAI",
      model: this.googleGenAIClient.getConfig().model
    } : {
      type: "None",
      model: "N/A"
    };
  }
  /**
   * 評価処理のメインエントリーポイント
   */
  async process(e) {
    let t = Date.now(), r = {
      transcriptionId: e.transcriptionId,
      videoType: e.videoType,
      startTime: t,
      phases: {},
      success: !1,
      errors: [],
      hasPartialFailure: !1
    };
    try {
      console.log(`Starting evaluation for ${e.transcriptionId}, type: ${e.videoType}`);
      let n = new m("production"), s = await this.executePhase("preprocessing", r, async () => await n.preprocessTranscript(e)), a = await this.executePhase("evaluation", r, async () => await this.evaluateVideo(s)), f = await this.executePhase("consolidation", r, async () => n.consolidateResults({
        evaluation: a,
        transcript_with_speaker: s.transcript
      }));
      return r.success = !0, r.totalDuration = Date.now() - t, console.log(
        `Evaluation completed for ${e.transcriptionId} in ${r.totalDuration}ms`
      ), {
        ...f,
        success: !0,
        metrics: r
      };
    } catch (n) {
      if (console.error(`Evaluation failed for ${e.transcriptionId}:`, n), r.success = !1, r.totalDuration = Date.now() - t, r.errors.push({
        phase: "evaluation",
        error: n instanceof Error ? n : new Error(String(n)),
        timestamp: Date.now()
      }), this.config.fallback.enabled)
        return {
          ...await new m("production").generateFallbackResponse(e, n),
          success: !1,
          errors: r.errors,
          metrics: r
        };
      throw n;
    }
  }
  /**
   * フェーズ実行のヘルパー
   */
  async executePhase(e, t, r) {
    let n = Date.now();
    try {
      let s = await r(), a = Date.now();
      return t.phases[e] = {
        startTime: n,
        endTime: a,
        duration: a - n,
        success: !0,
        retryCount: 0
      }, s;
    } catch (s) {
      let a = Date.now();
      throw t.phases[e] = {
        startTime: n,
        endTime: a,
        duration: a - n,
        success: !1,
        error: s instanceof Error ? s.message : String(s),
        retryCount: 0
      }, s;
    }
  }
  /**
   * 動画評価（AI処理部分）
   */
  async evaluateVideo(e) {
    console.log(`[HybridEvaluationEngine] Evaluating video type: ${e.videoType}`);
    let t = e.videoType;
    ["\u8B70\u984C\u67B6\u96FB", "\u521D\u56DE\u9762\u8AC7", "AD\u7DE0\u7D50\u63D0\u6848", "\u4F01\u696D\u6982\u8981\u66F8\u63D0\u6848"].includes(t) || (console.warn(`No evaluator found for video type: ${t}, using default evaluator (\u8B70\u984C\u67B6\u96FB)`), t = "\u8B70\u984C\u67B6\u96FB");
    let n, s;
    if (this.useVertexAI && this.vertexAIClient && !this.vertexAIFailed)
      try {
        console.log("[HybridEvaluationEngine] Using Vertex AI for evaluation"), n = await this.createEvaluatorWithClient(t, this.vertexAIClient), s = await n.evaluate(e);
      } catch (a) {
        console.warn("[HybridEvaluationEngine] Vertex AI evaluation failed, switching to fallback permanently:", a), this.vertexAIFailed = !0, this.initializeFallbackClient(), n = await this.createEvaluatorWithClient(t, this.googleGenAIClient), s = await n.evaluate(e);
      }
    else
      console.log("[HybridEvaluationEngine] Using Google GenAI for evaluation"), this.googleGenAIClient || this.initializeFallbackClient(), n = await this.createEvaluatorWithClient(t, this.googleGenAIClient), s = await n.evaluate(e);
    return {
      videoType: e.videoType,
      result: s
    };
  }
  /**
   * 指定されたクライアントでevaluatorを作成
   */
  async createEvaluatorWithClient(e, t) {
    switch (e) {
      case "\u8B70\u984C\u67B6\u96FB": {
        let { CallEvaluator: r } = await import("./QXO3XMPQ.js");
        return new r(t);
      }
      case "\u521D\u56DE\u9762\u8AC7": {
        let { InitialMeetingEvaluator: r } = await import("./6KOHP6F2.js");
        return new r(t);
      }
      case "AD\u7DE0\u7D50\u63D0\u6848": {
        let { AdSigningEvaluator: r } = await import("./TL3ZVORQ.js");
        return new r(t);
      }
      case "\u4F01\u696D\u6982\u8981\u66F8\u63D0\u6848": {
        let { CompanyProposalEvaluator: r } = await import("./MO3VVJOP.js");
        return new r(t);
      }
      default: {
        let { CallEvaluator: r } = await import("./QXO3XMPQ.js");
        return new r(t);
      }
    }
  }
};

// convex/lib/vertexAI.ts
function Q(i) {
  let e = [], t = /"([^"]+)"\s*:/g, r;
  for (; (r = t.exec(i)) !== null; )
    e.push(r[1]);
  return [...new Set(e)];
}
o(Q, "extractJsonKeys");
async function P() {
  console.log("[checkVertexAIAvailability] \u958B\u59CB");
  try {
    let i = new l({
      vertexAI: {
        projectId: process.env.VERTEX_AI_PROJECT_ID || process.env.GOOGLE_CLOUD_PROJECT_ID || "",
        location: process.env.VERTEX_AI_LOCATION || "asia-northeast1",
        model: process.env.VERTEX_AI_MODEL || "gemini-1.5-pro",
        temperature: 0.1,
        maxOutputTokens: 100
      }
    });
    console.log("[checkVertexAIAvailability] Vertex AI\u63A5\u7D9A\u30C6\u30B9\u30C8\u958B\u59CB");
    let t = (await i.generateText("\u30C6\u30B9\u30C8", { maxOutputTokens: 10 })).length > 0;
    return console.log(`[checkVertexAIAvailability] \u5B8C\u4E86 - \u5229\u7528\u53EF\u80FD: ${t}`), t;
  } catch (i) {
    return console.error("[checkVertexAIAvailability] \u63A5\u7D9A\u30C6\u30B9\u30C8\u30A8\u30E9\u30FC:", i), console.error(`[checkVertexAIAvailability] \u30A8\u30E9\u30FC\u8A73\u7D30 - name: ${i instanceof Error ? i.name : "Unknown"}`), console.error(`[checkVertexAIAvailability] \u30A8\u30E9\u30FC\u8A73\u7D30 - message: ${i instanceof Error ? i.message : "Unknown"}`), !1;
  }
}
o(P, "checkVertexAIAvailability");
async function Y() {
  let i = process.env.GEMINI_API_KEY;
  if (!i)
    return console.error("[checkGeminiAvailability] API key\u672A\u8A2D\u5B9A"), !1;
  console.log("[checkGeminiAvailability] API key\u78BA\u8A8D\u6E08\u307F - \u63A5\u7D9A\u30C6\u30B9\u30C8\u958B\u59CB"), console.log("[checkGeminiAvailability] API key\u78BA\u8A8D\u6E08\u307F - \u63A5\u7D9A\u30C6\u30B9\u30C8\u958B\u59CB");
  try {
    let e = await fetch(
      `https://generativelanguage.googleapis.com/v1/models?key=${i}`,
      {
        headers: {
          "Content-Type": "application/json"
        }
      }
    );
    console.log(`[checkGeminiAvailability] \u30EC\u30B9\u30DD\u30F3\u30B9\u53D7\u4FE1 - \u30B9\u30C6\u30FC\u30BF\u30B9: ${e.status}`);
    let t = e.ok;
    return console.log(`[checkGeminiAvailability] \u5B8C\u4E86 - \u5229\u7528\u53EF\u80FD: ${t}`), t;
  } catch (e) {
    return console.error("[checkGeminiAvailability] \u63A5\u7D9A\u30C6\u30B9\u30C8\u30A8\u30E9\u30FC:", e), console.error(`[checkGeminiAvailability] \u30A8\u30E9\u30FC\u8A73\u7D30 - name: ${e instanceof Error ? e.name : "Unknown"}`), console.error(`[checkGeminiAvailability] \u30A8\u30E9\u30FC\u8A73\u7D30 - message: ${e instanceof Error ? e.message : "Unknown"}`), !1;
  }
}
o(Y, "checkGeminiAvailability");
async function K(i) {
  try {
    console.log("[addSpeakersToTranscript] Starting speaker diarization with Vertex AI");
    let e = new l(), t = `
\u3042\u306A\u305F\u306F\u55B6\u696D\u30FB\u5546\u8AC7\u306E\u6587\u5B57\u8D77\u3053\u3057\u5C02\u9580\u5BB6\u3067\u3059\u3002\u4EE5\u4E0B\u306E\u6587\u5B57\u8D77\u3053\u3057\u30C6\u30AD\u30B9\u30C8\u3092\u5206\u6790\u3057\u3001\u8A71\u8005\u3092\u8B58\u5225\u3057\u3066\u975E\u5E38\u306B\u898B\u3084\u3059\u304F\u69CB\u9020\u5316\u3055\u308C\u305FMarkdown\u5F62\u5F0F\u3067\u6574\u7406\u3057\u3066\u304F\u3060\u3055\u3044\u3002

## \u5206\u6790\u6307\u91DD
1. **\u8A71\u8005\u306E\u5F79\u5272\u8B58\u5225**: \u767A\u8A00\u5185\u5BB9\u304B\u3089\u8A71\u8005\u306E\u7ACB\u5834\uFF08\u55B6\u696D\u62C5\u5F53\u3001\u9867\u5BA2\u3001\u610F\u601D\u6C7A\u5B9A\u8005\u3001\u6280\u8853\u8005\u306A\u3069\uFF09\u3092\u63A8\u6E2C
2. **\u767A\u8A00\u306E\u6587\u8108\u7406\u89E3**: \u6328\u62F6\u3001\u30D2\u30A2\u30EA\u30F3\u30B0\u3001\u63D0\u6848\u3001\u4EA4\u6E09\u3001\u78BA\u8A8D\u7B49\u306E\u6BB5\u968E\u3092\u628A\u63E1
3. **\u91CD\u8981\u60C5\u5831\u306E\u62BD\u51FA**: \u4F01\u696D\u540D\u3001\u6570\u5B57\u3001\u56FA\u6709\u540D\u8A5E\u3001\u91CD\u8981\u306A\u6C7A\u5B9A\u4E8B\u9805\u3092\u7279\u5B9A

## \u51FA\u529B\u30D5\u30A9\u30FC\u30DE\u30C3\u30C8\u8981\u4EF6

### \u8A71\u8005\u898B\u51FA\u3057\uFF08\u5FC5\u9808\uFF09
- \u5F62\u5F0F: \\\`## \u{1F464} \u8A71\u8005A\uFF08\u63A8\u5B9A\u5F79\u5272\uFF09\\\`
- \u5F79\u5272\u4F8B: \u55B6\u696D\u62C5\u5F53\u3001\u9867\u5BA2\u4F01\u696D\u4EE3\u8868\u3001\u610F\u601D\u6C7A\u5B9A\u8005\u3001\u6280\u8853\u8CAC\u4EFB\u8005\u3001\u8CA1\u52D9\u62C5\u5F53\u306A\u3069
- \u30A2\u30A4\u30B3\u30F3: \u{1F464}\uFF08\u55B6\u696D\uFF09\u3001\u{1F454}\uFF08\u9867\u5BA2\uFF09\u3001\u2B50\uFF08\u610F\u601D\u6C7A\u5B9A\u8005\uFF09\u3001\u{1F527}\uFF08\u6280\u8853\u8005\uFF09\u3001\u{1F4B0}\uFF08\u8CA1\u52D9\uFF09

### \u767A\u8A00\u69CB\u9020\u5316\uFF08\u5FC5\u9808\uFF09
1. **\u8A71\u984C\u5225\u306E\u5C0F\u898B\u51FA\u3057**: \u767A\u8A00\u5185\u5BB9\u306B\u5FDC\u3058\u3066\u9069\u5207\u306A\u30B5\u30D6\u30BF\u30A4\u30C8\u30EB\u3092\u4ED8\u4E0E
2. **\u91CD\u8981\u60C5\u5831\u306E\u30CF\u30A4\u30E9\u30A4\u30C8**: 
   - **\u592A\u5B57**: \u4F01\u696D\u540D\u3001\u91CD\u8981\u306A\u6570\u5B57\u3001\u30AD\u30FC\u30EF\u30FC\u30C9
   - \\\`\u30B3\u30FC\u30C9\u5F62\u5F0F\\\`: \u5C02\u9580\u7528\u8A9E\u3001\u30B7\u30B9\u30C6\u30E0\u540D\u3001\u5177\u4F53\u7684\u306A\u6761\u4EF6
3. **\u6BB5\u843D\u5206\u3051**: \u9577\u3044\u767A\u8A00\u306F\u8A71\u984C\u3054\u3068\u306B\u9069\u5207\u306B\u5206\u5272
4. **\u30D6\u30ED\u30C3\u30AF\u30AF\u30A9\u30FC\u30C8**: \u5404\u767A\u8A00\u306F \\\`>\\\` \u3067\u56F2\u3080

### \u69CB\u9020\u4F8B
\\\`\\\`\\\`markdown
## \u{1F464} \u8A71\u8005A\uFF08\u55B6\u696D\u62C5\u5F53\uFF09

### \u{1F4DD} \u3054\u6328\u62F6\u3068\u30A2\u30D7\u30ED\u30FC\u30C1
> \u304A\u9858\u3044\u3057\u307E\u3059\u3002\u3088\u308D\u3057\u304F\u304A\u9858\u3044\u3044\u305F\u3057\u307E\u3059\u3002**\u65E5\u672C\u7D4C\u55B6**\u306E\u5185\u85E4\u3068\u7533\u3057\u307E\u3059\u3002
> 
> \u305D\u308C\u3067\u306F\u672C\u65E5\u304A\u6642\u9593\u3042\u308A\u304C\u3068\u3046\u3054\u3056\u3044\u307E\u3059\u3002\u3061\u3087\u3063\u3068\u4ECA\u56DE\\\`\u30D0\u30C8\u30F3\u30BA\u3055\u3093\u7D4C\u7531\\\`\u3067\u304A\u554F\u3044\u5408\u308F\u305B\u3092\u3044\u305F\u3060\u3044\u3066...

### \u{1F3AF} \u72B6\u6CC1\u78BA\u8A8D\u3068\u30D2\u30A2\u30EA\u30F3\u30B0
> \u3042\u306E\u3001\u4F1A\u793E\u306B\u5BFE\u3057\u3066\u3053\u3046\u3044\u3063\u305F\u6848\u4EF6\u306E\u304A\u6301\u3061\u8FBC\u307F\u3063\u3066\u3044\u3046\u306E\u3082\u5404\u4EF2\u4ECB\u4F1A\u793E\u304B\u3089\u3088\u304F\u6765\u3066\u304A\u308B\u304B\u306A\u3068...

---

## \u{1F454} \u8A71\u8005B\uFF08\u9867\u5BA2\u4F01\u696D\u4EE3\u8868\uFF09

### \u{1F4BC} \u4F1A\u793E\u72B6\u6CC1\u306E\u8AAC\u660E
> \u306F\u3044\u3001\u627F\u77E5\u3044\u305F\u3057\u307E\u3057\u305F\u3002\u3053\u3061\u3089\u3053\u305D\u3088\u308D\u3057\u304F\u304A\u9858\u3044\u3044\u305F\u3057\u307E\u3059\u3002
> 
> \u5F0A\u793E\u306E\u65B9\u3067\u3082\u69D8\u3005\u306A**\u4EF2\u4ECB\u4F1A\u793E**\u3068\u306E\u3054\u9762\u8AC7\u3068\u3044\u3046\u5F62\u3067\u9032\u3081\u3055\u305B\u3066\u3044\u305F\u3060\u3044\u3066\u304A\u308A\u307E\u3059...
\\\`\\\`\\\`

## \u5B9F\u884C\u6307\u793A
1. \u4F1A\u8A71\u306E\u6D41\u308C\u3092\u5206\u6790\u3057\u3001\u8A71\u8005\u304C\u5909\u308F\u308B\u30BF\u30A4\u30DF\u30F3\u30B0\u3092\u6B63\u78BA\u306B\u7279\u5B9A
2. \u5404\u8A71\u8005\u306E\u767A\u8A00\u304B\u3089\u5F79\u5272\u30FB\u7ACB\u5834\u3092\u63A8\u6E2C\u3057\u3001\u9069\u5207\u306A\u30A2\u30A4\u30B3\u30F3\u3068\u5F79\u5272\u540D\u3092\u4ED8\u4E0E
3. \u767A\u8A00\u5185\u5BB9\u3092\u8A71\u984C\u5225\u306B\u6574\u7406\u3057\u3001\u5C0F\u898B\u51FA\u3057\u3092\u8FFD\u52A0
4. \u91CD\u8981\u306A\u60C5\u5831\uFF08\u4F01\u696D\u540D\u3001\u6570\u5B57\u3001\u5C02\u9580\u7528\u8A9E\u306A\u3069\uFF09\u3092\u9069\u5207\u306B\u30CF\u30A4\u30E9\u30A4\u30C8
5. \u9577\u3044\u767A\u8A00\u306F\u81EA\u7136\u306A\u533A\u5207\u308A\u3067\u6BB5\u843D\u5206\u3051\u3092\u5B9F\u65BD
6. \u8A71\u8005\u9593\u306E\u5207\u308A\u66FF\u3048\u306B\u306F \\\`---\\\` \u3067\u660E\u78BA\u306B\u533A\u5207\u308B

## \u91CD\u8981\u306A\u5236\u7D04
- \u5143\u306E\u30C6\u30AD\u30B9\u30C8\u5185\u5BB9\u306F\u7D76\u5BFE\u306B\u5909\u66F4\u305B\u305A\u3001\u69CB\u9020\u5316\u3068\u30D5\u30A9\u30FC\u30DE\u30C3\u30C8\u306E\u307F\u5B9F\u884C
- \u81EA\u7136\u306A\u4F1A\u8A71\u306E\u6D41\u308C\u3092\u7DAD\u6301\u3057\u3001\u6587\u8108\u3092\u640D\u306A\u308F\u306A\u3044
- \u63A8\u6E2C\u3057\u305F\u5F79\u5272\u306F\u63A7\u3048\u3081\u306B\u8868\u73FE\uFF08\u300C\u63A8\u5B9A\u300D\u300C\u3068\u601D\u308F\u308C\u308B\u300D\u306A\u3069\u4E0D\u8981\uFF09

\u5165\u529B\u30C6\u30AD\u30B9\u30C8:
${i}

\u69CB\u9020\u5316\u3055\u308C\u305FMarkdown\u6587\u5B57\u8D77\u3053\u3057:`, r = Math.ceil(i.length / 2), n = Math.max(8192, Math.min(r * 3, 20480)), s = await e.generateText(t, {
      temperature: 0.1,
      maxOutputTokens: n
    });
    return console.log("[addSpeakersToTranscript] Success with Vertex AI"), s || i;
  } catch (e) {
    return console.error("[addSpeakersToTranscript] Vertex AI error:", e), i;
  }
}
o(K, "addSpeakersToTranscript");
async function d(i, e = {}) {
  console.log("[generateMeetingMinutes] Starting with Vertex AI"), console.log(`[generateMeetingMinutes] Transcript length: ${i.length} characters`);
  let t = `
Please create structured meeting minutes from the following meeting audio transcript.

## \u91CD\u8981: \u65E5\u672C\u8A9E\u3067\u5FDC\u7B54\u3057\u3001\u30B9\u30AD\u30FC\u30DE\u306B\u5F93\u3063\u305F\u6B63\u78BA\u306AJSON\u69CB\u9020\u3092\u4F7F\u7528\u3057\u3066\u304F\u3060\u3055\u3044\u3002

Meeting Transcript Text:
${i}

Please create meeting minutes with the following items:
1. summary: Meeting overview (3-4 sentences)
2. participants: Participants (comma-separated string)
3. actionItems: Action items (newline-separated string)
4. keyPoints: Main topics and decisions (newline-separated string)
5. duration: Meeting duration (estimated, e.g., "30 minutes")

IMPORTANT: Please respond with valid JSON format only. Do not use code blocks or markdown formatting. Return only a pure JSON object.`;
  try {
    console.log("[generateMeetingMinutes] Initializing Vertex AI engine");
    let r = new l(), n = {
      type: "object",
      properties: {
        summary: {
          type: "string",
          description: "Meeting overview (3-4 sentences)"
        },
        participants: {
          type: "string",
          description: "Participants (comma-separated string)"
        },
        actionItems: {
          type: "string",
          description: "Action items (newline-separated string)"
        },
        keyPoints: {
          type: "string",
          description: "Main topics and decisions (newline-separated string)"
        },
        duration: {
          type: "string",
          description: "Meeting duration (estimated, e.g., '30 minutes')"
        }
      },
      required: ["summary", "participants", "actionItems", "keyPoints", "duration"]
    };
    console.log("[generateMeetingMinutes] Starting Vertex AI structured content generation");
    let a = await r.generateStructuredContent(
      t,
      n,
      {
        temperature: 0.2,
        maxOutputTokens: 8192,
        ...e
      }
    ) || {
      summary: "Failed to generate meeting minutes",
      participants: "",
      actionItems: "",
      keyPoints: "",
      duration: ""
    };
    return console.log("[generateMeetingMinutes] Success with Vertex AI"), a;
  } catch (r) {
    return console.error("[generateMeetingMinutes] Vertex AI error:", r), {
      summary: "Failed to generate meeting minutes",
      participants: "",
      actionItems: "",
      keyPoints: "",
      duration: ""
    };
  }
}
o(d, "generateMeetingMinutes");
async function B(i, e = {}) {
  try {
    let t = await g(i, {
      temperature: 0.2,
      maxTokens: 6144,
      ...e
    });
    if (!t)
      throw new Error("Empty response from Gemini API");
    console.log("[generateCustomMeetingMinutes] Raw response:", t);
    let r = t, n = {
      "\u51FA\u5E2D\u8005\uFF08\u5168\u54E1\u306E\u540D\u524D\u3068\u6240\u5C5E\uFF09": "attendees",
      "\u5148\u65B9\uFF08\u30AF\u30E9\u30A4\u30A2\u30F3\u30C8\u5074\u306E\u51FA\u5E2D\u8005\uFF09": "clientSide",
      "\u5F53\u65B9\uFF08\u81EA\u793E\u5074\u306E\u51FA\u5E2D\u8005\uFF09": "ourSide",
      "\u4F1A\u793E\u6982\u8981\uFF08\u4F01\u696D\u306E\u57FA\u672C\u60C5\u5831\uFF09": "companyOverview",
      "\u4E8B\u696D\u5185\u5BB9\uFF08\u30D3\u30B8\u30CD\u30B9\u30E2\u30C7\u30EB\u30FB\u30B5\u30FC\u30D3\u30B9\u8A73\u7D30\uFF09": "businessContent",
      "\u8CA1\u52D9\u5185\u5BB9\uFF08\u58F2\u4E0A\u30FB\u5229\u76CA\u30FB\u8CA1\u52D9\u72B6\u6CC1\uFF09": "financialContent",
      "\u30AA\u30FC\u30CA\u30FC\u60C5\u5831\uFF08\u7D4C\u55B6\u8005\u30FB\u30AA\u30FC\u30CA\u30FC\u306E\u8A73\u7D30\uFF09": "ownerInfo",
      "\u9762\u8AC7\u8005\u60C5\u5831\uFF08\u4ECA\u56DE\u306E\u9762\u8AC7\u8005\u306E\u8A73\u7D30\uFF09": "intervieweeInfo",
      "\u682A\u4E3B\u60C5\u5831\uFF08\u682A\u4E3B\u69CB\u6210\u30FB\u8B70\u6C7A\u6A29\u306A\u3069\uFF09": "shareholderInfo",
      "\u793E\u9577\u306E\u6027\u683C\u30FB\u8DA3\u5473\u30FB\u597D\u304D\u306A\u304A\u9152\u306A\u3069\uFF08\u30D1\u30FC\u30BD\u30CA\u30EB\u60C5\u5831\uFF09": "personalCharacteristics",
      "M&A\u95A2\u9023\u60C5\u5831\uFF08\u691C\u8A0E\u80CC\u666F\u30FB\u6761\u4EF6\u30FB\u5E0C\u671B\uFF09": "maRelatedInfo",
      "\u4EF2\u4ECB\u4F1A\u793E\u9762\u8AC7\u5B9F\u7E3E\uFF08\u904E\u53BB\u306E\u76F8\u8AC7\u72B6\u6CC1\uFF09": "brokerMeetingHistory",
      "\u8B72\u6E21\u610F\u601D\uFF08\u672C\u6C17\u5EA6\u30FB\u52D5\u6A5F\u30FB\u30BF\u30A4\u30DF\u30F3\u30B0\uFF09": "transferIntention",
      "\u682A\u4FA1\u76EE\u7DDA\uFF08\u5E0C\u671B\u4FA1\u683C\u30FB\u4F01\u696D\u4FA1\u5024\u671F\u5F85\uFF09": "stockPriceExpectation",
      "\u30CD\u30AF\u30B9\u30C8\u30A2\u30AF\u30B7\u30E7\u30F3\uFF08\u6B21\u56DE\u9762\u8AC7\u30FB\u63D0\u51FA\u8CC7\u6599\uFF09": "nextActions",
      "ToDo\uFF08\u5177\u4F53\u7684\u306A\u30A2\u30AF\u30B7\u30E7\u30F3\u9805\u76EE\uFF09": "todos"
    };
    for (let [s, a] of Object.entries(n)) {
      let f = s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&"), b = new RegExp(`"${f}"`, "g");
      r = r.replace(b, `"${a}"`);
    }
    return console.log("[generateCustomMeetingMinutes] Cleaned result with English field names"), u(r, {
      summary: "\u8B70\u4E8B\u9332\u306E\u751F\u6210\u306B\u5931\u6557\u3057\u307E\u3057\u305F",
      participants: "",
      actionItems: "",
      keyPoints: "",
      duration: ""
    });
  } catch (t) {
    return console.error("[Gemini] Custom meeting minutes generation error:", t), {
      summary: "\u8B70\u4E8B\u9332\u306E\u751F\u6210\u306B\u5931\u6557\u3057\u307E\u3057\u305F",
      participants: "",
      actionItems: "",
      keyPoints: "",
      duration: ""
    };
  }
}
o(B, "generateCustomMeetingMinutes");
async function C(i, e = {}) {
  console.log("[generateCaseSummary] Starting with Vertex AI");
  let t = `
You are an M&A case analysis expert. Please extract important information for case development from the following business meeting transcript and create a structured summary.

## Information to Extract
1. Transfer reason
2. Successor availability
3. Desired stock price
4. Understanding of success fee
5. Shareholder structure
6. Disclosure status to other shareholders
7. Number of employees (full-time, part-time)
8. Family structure
9. Business overview
10. Current year performance (revenue, gross profit, operating profit)
11. Next year forecast (revenue, gross profit, operating profit)
12. Three company strengths
13. Three company challenges
14. Buyer preferences (if any)
15. Personality profile

## Important Notes
- Record information not clearly mentioned as "\u672A\u78BA\u8A8D" (unconfirmed)
- Avoid speculation and extract only content actually mentioned in the conversation
- Record financial figures accurately, include expressions like "approximately" or "estimated" for ambiguous figures
- Clearly distinguish between full-time, part-time, and total employee counts
- Record company strengths and challenges specifically
- Infer management personality from conversation atmosphere and expressions
- Objectively evaluate information reliability and completeness

## \u91CD\u8981: \u65E5\u672C\u8A9E\u3067\u5FDC\u7B54\u3057\u3001\u4EE5\u4E0B\u306EJSON\u69CB\u9020\u3092\u6B63\u78BA\u306B\u4F7F\u7528\u3057\u3066\u304F\u3060\u3055\u3044:
{
  "transferReason": "string",
  "hasSuccessor": "string", 
  "desiredStockPrice": {"value": number, "unit": "string"},
  "successFeeUnderstanding": "\u5341\u5206\u306B\u7406\u89E3\u3057\u3066\u3044\u308B|\u8AAC\u660E\u304C\u5FC5\u8981|\u672A\u78BA\u8A8D",
  "shareholderStructure": "string",
  "shareholderDisclosureStatus": "\u958B\u793A\u53EF\u80FD|\u4E00\u90E8\u306E\u307F\u958B\u793A\u53EF\u80FD|\u6761\u4EF6\u4ED8\u304D\u3067\u958B\u793A\u53EF\u80FD|\u958B\u793A\u4E0D\u53EF",
  "employeeCount": {"fullTime": number, "partTime": number, "total": number},
  "familyStructure": "string",
  "personalityProfile": "string",
  "businessOverview": "string",
  "financials": {
    "unit": "string",
    "currentYear": {"revenue": number, "grossProfit": number, "operatingProfit": number},
    "nextYearForecast": {"revenue": number, "grossProfit": number, "operatingProfit": number}
  },
  "companyStrengths": ["string", "string", "string"],
  "companyChallenges": ["string", "string", "string"],
  "buyerPreferences": "string",
  "confidenceLevel": "\u9AD8|\u4E2D|\u4F4E",
  "dataQuality": {"completeness": number, "clarity": number}
}

IMPORTANT: Please respond with valid JSON format only. Do not use code blocks or markdown formatting. Return only a pure JSON object.

## Transcript Content
${i}`;
  try {
    console.log("[generateCaseSummary] Initializing Vertex AI engine");
    let r = new l(), n = {
      type: "object",
      properties: {
        transferReason: { type: "string" },
        hasSuccessor: { type: "string" },
        desiredStockPrice: {
          type: "object",
          properties: {
            value: { type: "number" },
            unit: { type: "string" }
          },
          required: ["value", "unit"]
        },
        successFeeUnderstanding: {
          type: "string",
          enum: ["\u5341\u5206\u306B\u7406\u89E3\u3057\u3066\u3044\u308B", "\u8AAC\u660E\u304C\u5FC5\u8981", "\u672A\u78BA\u8A8D"]
        },
        shareholderStructure: { type: "string" },
        shareholderDisclosureStatus: {
          type: "string",
          enum: ["\u958B\u793A\u53EF\u80FD", "\u4E00\u90E8\u306E\u307F\u958B\u793A\u53EF\u80FD", "\u6761\u4EF6\u4ED8\u304D\u3067\u958B\u793A\u53EF\u80FD", "\u958B\u793A\u4E0D\u53EF"]
        },
        employeeCount: {
          type: "object",
          properties: {
            fullTime: { type: "number" },
            partTime: { type: "number" },
            total: { type: "number" }
          },
          required: ["fullTime", "partTime", "total"]
        },
        familyStructure: { type: "string" },
        personalityProfile: { type: "string" },
        businessOverview: { type: "string" },
        financials: {
          type: "object",
          properties: {
            unit: { type: "string" },
            currentYear: {
              type: "object",
              properties: {
                revenue: { type: "number" },
                grossProfit: { type: "number" },
                operatingProfit: { type: "number" }
              },
              required: ["revenue", "grossProfit", "operatingProfit"]
            },
            nextYearForecast: {
              type: "object",
              properties: {
                revenue: { type: "number" },
                grossProfit: { type: "number" },
                operatingProfit: { type: "number" }
              },
              required: ["revenue", "grossProfit", "operatingProfit"]
            }
          },
          required: ["unit", "currentYear", "nextYearForecast"]
        },
        companyStrengths: {
          type: "array",
          items: { type: "string" }
        },
        companyChallenges: {
          type: "array",
          items: { type: "string" }
        },
        buyerPreferences: { type: "string" },
        confidenceLevel: {
          type: "string",
          enum: ["\u9AD8", "\u4E2D", "\u4F4E"]
        },
        dataQuality: {
          type: "object",
          properties: {
            completeness: { type: "number" },
            clarity: { type: "number" }
          },
          required: ["completeness", "clarity"]
        }
      },
      required: [
        "transferReason",
        "hasSuccessor",
        "desiredStockPrice",
        "successFeeUnderstanding",
        "shareholderStructure",
        "shareholderDisclosureStatus",
        "employeeCount",
        "familyStructure",
        "personalityProfile",
        "businessOverview",
        "financials",
        "companyStrengths",
        "companyChallenges",
        "buyerPreferences",
        "confidenceLevel",
        "dataQuality"
      ]
    };
    console.log("[generateCaseSummary] Starting Vertex AI structured content generation");
    let a = await r.generateStructuredContent(
      t,
      n,
      {
        temperature: 0.3,
        maxOutputTokens: 6144,
        ...e
      }
    ) || {
      transferReason: "\u672A\u78BA\u8A8D",
      hasSuccessor: "\u672A\u78BA\u8A8D",
      desiredStockPrice: { value: 0, unit: "\u672A\u78BA\u8A8D" },
      successFeeUnderstanding: "\u672A\u78BA\u8A8D",
      shareholderStructure: "\u672A\u78BA\u8A8D",
      shareholderDisclosureStatus: "\u958B\u793A\u4E0D\u53EF",
      employeeCount: { fullTime: 0, partTime: 0, total: 0 },
      familyStructure: "\u672A\u78BA\u8A8D",
      personalityProfile: "\u672A\u78BA\u8A8D",
      businessOverview: "\u6848\u4EF6\u30B5\u30DE\u30EA\u30FC\u306E\u751F\u6210\u306B\u5931\u6557\u3057\u307E\u3057\u305F",
      financials: {
        unit: "\u5186",
        currentYear: { revenue: 0, grossProfit: 0, operatingProfit: 0 },
        nextYearForecast: { revenue: 0, grossProfit: 0, operatingProfit: 0 }
      },
      companyStrengths: [],
      companyChallenges: [],
      buyerPreferences: "\u672A\u78BA\u8A8D",
      confidenceLevel: "\u4F4E",
      dataQuality: { completeness: 0, clarity: 0 }
    };
    return console.log("[generateCaseSummary] Success with Vertex AI"), a;
  } catch (r) {
    return console.error("[generateCaseSummary] Vertex AI error:", r), {
      transferReason: "\u672A\u78BA\u8A8D",
      hasSuccessor: "\u672A\u78BA\u8A8D",
      desiredStockPrice: { value: 0, unit: "\u672A\u78BA\u8A8D" },
      successFeeUnderstanding: "\u672A\u78BA\u8A8D",
      shareholderStructure: "\u672A\u78BA\u8A8D",
      shareholderDisclosureStatus: "\u958B\u793A\u4E0D\u53EF",
      employeeCount: { fullTime: 0, partTime: 0, total: 0 },
      familyStructure: "\u672A\u78BA\u8A8D",
      personalityProfile: "\u672A\u78BA\u8A8D",
      businessOverview: "\u6848\u4EF6\u30B5\u30DE\u30EA\u30FC\u306E\u751F\u6210\u306B\u5931\u6557\u3057\u307E\u3057\u305F",
      financials: {
        unit: "\u5186",
        currentYear: { revenue: 0, grossProfit: 0, operatingProfit: 0 },
        nextYearForecast: { revenue: 0, grossProfit: 0, operatingProfit: 0 }
      },
      companyStrengths: [],
      companyChallenges: [],
      buyerPreferences: "\u672A\u78BA\u8A8D",
      confidenceLevel: "\u4F4E",
      dataQuality: { completeness: 0, clarity: 0 }
    };
  }
}
o(C, "generateCaseSummary");
async function T(i, e = {}) {
  console.log("[generateMeetingSummary] Starting with Vertex AI");
  let t = `
You are an M&A business meeting record analysis expert. Please extract a structured 16-item business meeting summary from the following business meeting transcript.

## \u91CD\u8981: \u65E5\u672C\u8A9E\u3067\u5FDC\u7B54\u3057\u3001\u4EE5\u4E0B\u306E\u6B63\u78BA\u306AJSON\u69CB\u9020\u3092\u4F7F\u7528\u3057\u3066\u304F\u3060\u3055\u3044\u3002

## Required JSON Structure
You MUST return a JSON object with exactly these field names (case-sensitive):
{
  "attendees": "string - all attendees with names and affiliations",
  "clientSide": "string - client-side attendees", 
  "ourSide": "string - our company's attendees",
  "companyOverview": "string - basic company information",
  "businessContent": "string - business model and service details", 
  "financialContent": "string - revenue, profit, financial status",
  "ownerInfo": "string - management/owner details",
  "intervieweeInfo": "string - details of today's interviewee",
  "shareholderInfo": "string - shareholder structure, voting rights, etc.",
  "personalCharacteristics": "string - CEO's personality, hobbies, favorite drinks, etc.",
  "maRelatedInfo": "string - M&A review background, conditions, requests",
  "brokerMeetingHistory": "string - past consultation status",
  "transferIntention": "string - seriousness, motivation, timing", 
  "stockPriceExpectation": "string - desired price, enterprise valuation expectations",
  "nextActions": "string - next meeting, materials to submit",
  "todos": "string - specific action items",
  "confidenceLevel": "string - confidence level",
  "dataQuality": {"completeness": number, "clarity": number}
}

## Important Notes
- Record information not clearly mentioned as "unconfirmed" or "not mentioned"
- Avoid speculation and inference; extract only actual conversation content
- Record numbers and dates accurately; when ambiguous, clearly mark as "approximately" or "estimated"
- Record personality and hobbies based on conversation atmosphere where reasonably inferable
- Extract M&A-related information in particular detail (review stage, conditions, concerns, etc.)
- Organize action items as specific and actionable content
- Use the EXACT field names shown above - do not capitalize differently or use spaces

IMPORTANT: Please respond with valid JSON format only. Do not use code blocks or markdown formatting. Return only a pure JSON object with the exact field names specified above.

## Meeting Transcript
${i}`;
  try {
    console.log("[generateMeetingSummary] Initializing Vertex AI engine");
    let r = new l(), n = {
      type: "object",
      properties: {
        attendees: { type: "string" },
        clientSide: { type: "string" },
        ourSide: { type: "string" },
        companyOverview: { type: "string" },
        businessContent: { type: "string" },
        financialContent: { type: "string" },
        ownerInfo: { type: "string" },
        intervieweeInfo: { type: "string" },
        shareholderInfo: { type: "string" },
        personalCharacteristics: { type: "string" },
        maRelatedInfo: { type: "string" },
        brokerMeetingHistory: { type: "string" },
        transferIntention: { type: "string" },
        stockPriceExpectation: { type: "string" },
        nextActions: { type: "string" },
        todos: { type: "string" },
        confidenceLevel: { type: "string" },
        dataQuality: {
          type: "object",
          properties: {
            completeness: { type: "number" },
            clarity: { type: "number" }
          },
          required: ["completeness", "clarity"]
        }
      },
      required: [
        "attendees",
        "clientSide",
        "ourSide",
        "companyOverview",
        "businessContent",
        "financialContent",
        "ownerInfo",
        "intervieweeInfo",
        "shareholderInfo",
        "personalCharacteristics",
        "maRelatedInfo",
        "brokerMeetingHistory",
        "transferIntention",
        "stockPriceExpectation",
        "nextActions",
        "todos",
        "confidenceLevel",
        "dataQuality"
      ]
    };
    console.log("[generateMeetingSummary] Starting Vertex AI structured content generation");
    let s = await r.generateStructuredContent(
      t,
      n,
      {
        temperature: 0.3,
        maxOutputTokens: 6144,
        ...e
      }
    );
    console.log("[generateMeetingSummary] Vertex AI result:", JSON.stringify(s, null, 2));
    let a = s || {
      attendees: "Failed to generate business meeting summary",
      brokerMeetingHistory: "",
      businessContent: "",
      clientSide: "",
      companyOverview: "",
      confidenceLevel: "low",
      dataQuality: { completeness: 0, clarity: 0 },
      financialContent: "",
      intervieweeInfo: "",
      maRelatedInfo: "",
      nextActions: "",
      ourSide: "",
      ownerInfo: "",
      personalCharacteristics: "",
      shareholderInfo: "",
      stockPriceExpectation: "",
      todos: "",
      transferIntention: ""
    };
    return console.log("[generateMeetingSummary] Success with Vertex AI"), a;
  } catch (r) {
    return console.error("[generateMeetingSummary] Vertex AI error:", r), console.error("[generateMeetingSummary] Error stack:", r instanceof Error ? r.stack : "No stack trace"), {
      attendees: "Failed to generate business meeting summary",
      brokerMeetingHistory: "",
      businessContent: "",
      clientSide: "",
      companyOverview: "",
      confidenceLevel: "low",
      dataQuality: { completeness: 0, clarity: 0 },
      financialContent: "",
      intervieweeInfo: "",
      maRelatedInfo: "",
      nextActions: "",
      ourSide: "",
      ownerInfo: "",
      personalCharacteristics: "",
      shareholderInfo: "",
      stockPriceExpectation: "",
      todos: "",
      transferIntention: ""
    };
  }
}
o(T, "generateMeetingSummary");
async function k(i, e = {}) {
  let t = `
\u4EE5\u4E0B\u306E\u7814\u4FEE\u30FB\u6559\u80B2\u30B3\u30F3\u30C6\u30F3\u30C4\u306E\u6587\u5B57\u8D77\u3053\u3057\u3092\u5206\u6790\u3057\u3001\u5B66\u7FD2\u5185\u5BB9\u3092\u69CB\u9020\u5316\u3057\u3066\u304F\u3060\u3055\u3044\u3002

\u6587\u5B57\u8D77\u3053\u3057\u30C6\u30AD\u30B9\u30C8:
${i}

\u4EE5\u4E0B\u306EJSON\u5F62\u5F0F\u3067\u56DE\u7B54\u3057\u3066\u304F\u3060\u3055\u3044:
{
  "title": "\u30B3\u30F3\u30C6\u30F3\u30C4\u306E\u30BF\u30A4\u30C8\u30EB",
  "summary": "\u30B3\u30F3\u30C6\u30F3\u30C4\u306E\u8981\u7D04\uFF08200\u6587\u5B57\u7A0B\u5EA6\uFF09",
  "learningObjectives": ["\u5B66\u7FD2\u76EE\u6A191", "\u5B66\u7FD2\u76EE\u6A192"],
  "keyTerms": ["\u91CD\u8981\u7528\u8A9E1", "\u91CD\u8981\u7528\u8A9E2"],
  "difficulty": "beginner|intermediate|advanced"
}`;
  try {
    let r = await g(t, {
      model: process.env.GEMINI_MODEL_NAME || "gemini-2.5-flash",
      temperature: 0.2,
      ...e
    });
    return u(r, {
      title: "\u7814\u4FEE\u30B3\u30F3\u30C6\u30F3\u30C4\u5206\u6790",
      summary: "\u7814\u4FEE\u30B3\u30F3\u30C6\u30F3\u30C4\u306E\u5206\u6790\u7D50\u679C\u3067\u3059\u3002",
      learningObjectives: [],
      keyTerms: [],
      difficulty: "intermediate"
    });
  } catch (r) {
    return console.error("[Gemini] Content analysis error:", r), {
      title: "\u7814\u4FEE\u30B3\u30F3\u30C6\u30F3\u30C4\u5206\u6790",
      summary: "\u5206\u6790\u51E6\u7406\u4E2D\u306B\u30A8\u30E9\u30FC\u304C\u767A\u751F\u3057\u307E\u3057\u305F\u3002",
      learningObjectives: [],
      keyTerms: [],
      difficulty: "intermediate"
    };
  }
}
o(k, "generateContentAnalysis");
async function S(i, e = {}) {
  let t = `
\u4EE5\u4E0B\u306E\u6559\u80B2\u30B3\u30F3\u30C6\u30F3\u30C4\u306E\u6587\u5B57\u8D77\u3053\u3057\u304B\u3089\u3001\u7406\u89E3\u5EA6\u78BA\u8A8D\u7528\u306E\u30AF\u30A4\u30BA\u3092\u4F5C\u6210\u3057\u3066\u304F\u3060\u3055\u3044\u3002

\u6587\u5B57\u8D77\u3053\u3057\u30C6\u30AD\u30B9\u30C8:
${i}

\u4EE5\u4E0B\u306EJSON\u5F62\u5F0F\u30675\u554F\u306E\u30AF\u30A4\u30BA\u3092\u4F5C\u6210\u3057\u3066\u304F\u3060\u3055\u3044:
{
  "questions": [
    {
      "question": "\u8CEA\u554F\u6587",
      "type": "multiple_choice|true_false|short_answer",
      "options": ["\u9078\u629E\u80A21", "\u9078\u629E\u80A22", "\u9078\u629E\u80A23", "\u9078\u629E\u80A24"],
      "correct_answer": "\u6B63\u89E3",
      "explanation": "\u89E3\u8AAC",
      "difficulty": "easy|medium|hard"
    }
  ],
  "learning_points": ["\u5B66\u7FD2\u30DD\u30A4\u30F3\u30C81", "\u5B66\u7FD2\u30DD\u30A4\u30F3\u30C82"]
}`;
  try {
    let r = await g(t, {
      model: process.env.GEMINI_MODEL_NAME || "gemini-2.5-flash",
      temperature: 0.4,
      ...e
    });
    return u(r, {
      questions: [],
      learning_points: []
    });
  } catch (r) {
    return console.error("[Gemini] Quiz generation error:", r), {
      questions: [],
      learning_points: []
    };
  }
}
o(S, "generateQuizMaterial");
async function O(i, e, t = {}) {
  let r = `
\u4EE5\u4E0B\u306E${e}\u30ED\u30FC\u30EB\u30D7\u30EC\u30A4\u97F3\u58F0\u3092\u8A55\u4FA1\u3057\u3066\u304F\u3060\u3055\u3044\u3002

\u6587\u5B57\u8D77\u3053\u3057\u30C6\u30AD\u30B9\u30C8:
${i}

\u8A55\u4FA1\u9805\u76EE\u306B\u57FA\u3065\u3044\u3066\u3001JSON\u5F62\u5F0F\u3067\u8A73\u7D30\u306A\u8A55\u4FA1\u3092\u8FD4\u3057\u3066\u304F\u3060\u3055\u3044\u3002
\u5404\u9805\u76EE\u306F1-5\u306E\u70B9\u6570\u3067\u8A55\u4FA1\u3057\u3001\u5206\u6790\u30B3\u30E1\u30F3\u30C8\u3001\u5F37\u307F\u3001\u6539\u5584\u70B9\u3092\u542B\u3081\u3066\u304F\u3060\u3055\u3044\u3002`;
  try {
    let n = await g(r, {
      model: process.env.GEMINI_MODEL_NAME || "gemini-2.5-flash",
      temperature: 0.3,
      ...t
    });
    return u(n, {
      error: "\u8A55\u4FA1\u306E\u751F\u6210\u306B\u5931\u6557\u3057\u307E\u3057\u305F",
      message: "JSON parse error",
      scores: {},
      final_score: 0,
      recommendation: "\u51E6\u7406\u4E2D"
    });
  } catch (n) {
    return console.error("[Gemini] Evaluation generation error:", n), {
      error: "\u8A55\u4FA1\u306E\u751F\u6210\u306B\u5931\u6557\u3057\u307E\u3057\u305F",
      message: n instanceof Error ? n.message : "Unknown error"
    };
  }
}
o(O, "generateEvaluation");
async function g(i, e = {}) {
  console.log("[callVertexAI] Starting"), console.log(`[callVertexAI] Prompt length: ${i.length} characters`);
  let t = e.model || process.env.VERTEX_AI_MODEL || "gemini-1.5-pro", r = e.temperature || 0.2, n = e.maxTokens || 8192;
  console.log(`[callVertexAI] Settings - model: ${t}, temperature: ${r}, maxTokens: ${n}`);
  try {
    let s = new l({
      vertexAI: {
        projectId: process.env.VERTEX_AI_PROJECT_ID || process.env.GOOGLE_CLOUD_PROJECT_ID || "",
        location: process.env.VERTEX_AI_LOCATION || "asia-northeast1",
        model: t,
        temperature: r,
        maxOutputTokens: n
      }
    });
    console.log("[callVertexAI] Generating content with Vertex AI");
    let a = await s.generateText(i, {
      temperature: r,
      maxOutputTokens: n
    });
    return console.log(`[callVertexAI] Success - response text length: ${a.length} characters`), a;
  } catch (s) {
    throw console.error("[callVertexAI] Error:", s), console.error(`[callVertexAI] Error details - name: ${s instanceof Error ? s.name : "Unknown"}`), console.error(`[callVertexAI] Error details - message: ${s instanceof Error ? s.message : "Unknown"}`), s;
  }
}
o(g, "callVertexAI");
async function y(i, e) {
  switch (console.log(`[Gemini Mock] Processing ${i} analysis`), await new Promise((t) => setTimeout(t, 1e3 + Math.random() * 2e3)), i) {
    case "meeting_minutes":
      return {
        summary: "\u6A21\u64EC\u7684\u306A\u4F1A\u8B70\u306E\u8981\u7D04\u3067\u3059\u3002\u4E3B\u8981\u306A\u8B70\u984C\u306B\u3064\u3044\u3066\u8B70\u8AD6\u3057\u3001\u91CD\u8981\u306A\u6C7A\u5B9A\u4E8B\u9805\u304C\u78BA\u8A8D\u3055\u308C\u307E\u3057\u305F\u3002",
        participants: "\u53C2\u52A0\u8005A, \u53C2\u52A0\u8005B, \u53C2\u52A0\u8005C",
        actionItems: `\u6B21\u56DE\u307E\u3067\u306B\u8CC7\u6599\u3092\u6E96\u5099\u3059\u308B
\u9867\u5BA2\u3078\u306E\u30D5\u30A9\u30ED\u30FC\u30A2\u30C3\u30D7\u3092\u5B9F\u65BD\u3059\u308B
\u63D0\u6848\u66F8\u306E\u30C9\u30E9\u30D5\u30C8\u3092\u4F5C\u6210\u3059\u308B`,
        keyPoints: `\u30D7\u30ED\u30B8\u30A7\u30AF\u30C8\u306E\u9032\u884C\u3092\u627F\u8A8D
\u6B21\u56DE\u4F1A\u8B70\u306E\u65E5\u7A0B\u3092\u8ABF\u6574
\u30D7\u30ED\u30B8\u30A7\u30AF\u30C8\u9032\u6357
\u4E88\u7B97\u627F\u8A8D
\u30B9\u30B1\u30B8\u30E5\u30FC\u30EB\u8ABF\u6574`,
        duration: "60\u5206"
      };
    case "case_summary":
      return {
        transferReason: "\u5F8C\u7D99\u8005\u4E0D\u5728\u306B\u3088\u308B\u4E8B\u696D\u627F\u7D99\u8AB2\u984C",
        hasSuccessor: "\u3044\u306A\u3044",
        desiredStockPrice: { value: 3, unit: "\u5104\u5186" },
        successFeeUnderstanding: "\u8AAC\u660E\u304C\u5FC5\u8981",
        shareholderStructure: "\u30AA\u30FC\u30CA\u30FC\u7D4C\u55B6\u8005100%",
        shareholderDisclosureStatus: "\u6761\u4EF6\u4ED8\u304D\u3067\u958B\u793A\u53EF\u80FD",
        employeeCount: { fullTime: 45, partTime: 8, total: 53 },
        familyStructure: "\u914D\u5076\u8005\u3068\u5B50\u4F9B2\u540D\uFF08\u72EC\u7ACB\u6E08\u307F\uFF09",
        personalityProfile: "\u5805\u5B9F\u306A\u7D4C\u55B6\u8005\u3001\u5F93\u696D\u54E1\u601D\u3044\u306E\u4EBA\u67C4",
        businessOverview: "IT\u30B3\u30F3\u30B5\u30EB\u30C6\u30A3\u30F3\u30B0\u4E8B\u696D\u3001\u30AF\u30E9\u30A6\u30C9\u79FB\u884C\u652F\u63F4\u304C\u4E3B\u529B",
        financials: {
          unit: "\u4E07\u5186",
          currentYear: { revenue: 5e4, grossProfit: 2e4, operatingProfit: 8e3 },
          nextYearForecast: { revenue: 55e3, grossProfit: 22e3, operatingProfit: 9e3 }
        },
        companyStrengths: ["\u512A\u79C0\u306A\u6280\u8853\u9663", "\u9577\u671F\u9867\u5BA2\u3068\u306E\u4FE1\u983C\u95A2\u4FC2", "\u6210\u9577\u5E02\u5834\u3067\u306E\u30DD\u30B8\u30B7\u30E7\u30F3"],
        companyChallenges: ["\u4EBA\u6750\u63A1\u7528\u96E3", "\u30C7\u30B8\u30BF\u30EB\u5316\u306E\u9045\u308C", "\u7AF6\u5408\u6FC0\u5316"],
        buyerPreferences: "\u5F93\u696D\u54E1\u306E\u96C7\u7528\u7DAD\u6301\u3092\u91CD\u8996\u3059\u308B\u4F01\u696D",
        confidenceLevel: "\u4E2D",
        dataQuality: { completeness: 75, clarity: 80 }
      };
    case "meeting_summary":
      return {
        attendees: "\u4EE3\u8868\u53D6\u7DE0\u5F79 \u7530\u4E2D\u592A\u90CE\u3001\u55B6\u696D\u90E8\u9577 \u4F50\u85E4\u82B1\u5B50\u3001M&A\u30A2\u30C9\u30D0\u30A4\u30B6\u30FC \u5C71\u7530\u6B21\u90CE",
        brokerMeetingHistory: "3\u30F6\u6708\u524D\u306B\u521D\u56DE\u9762\u8AC7\u5B9F\u65BD\u3001\u4ECA\u56DE\u304C2\u56DE\u76EE\u306E\u6B63\u5F0F\u9762\u8AC7",
        businessContent: "IT\u30B3\u30F3\u30B5\u30EB\u30C6\u30A3\u30F3\u30B0\u4E8B\u696D\u3001\u5F93\u696D\u54E150\u540D\u3001\u5E74\u55465\u5104\u5186",
        clientSide: "\u4EE3\u8868\u53D6\u7DE0\u5F79\uFF08\u610F\u601D\u6C7A\u5B9A\u8005\uFF09\u3001\u55B6\u696D\u90E8\u9577\uFF08\u4E8B\u696D\u8CAC\u4EFB\u8005\uFF09",
        companyOverview: "\u5275\u696D15\u5E74\u306EIT\u30B3\u30F3\u30B5\u30EB\u30C6\u30A3\u30F3\u30B0\u4F1A\u793E\u3001\u30AF\u30E9\u30A6\u30C9\u79FB\u884C\u652F\u63F4\u304C\u4E3B\u529B\u4E8B\u696D",
        confidenceLevel: "\u9AD8",
        dataQuality: { completeness: 0.85, clarity: 0.9 },
        financialContent: "\u58F2\u4E0A5\u5104\u5186\u3001\u55B6\u696D\u5229\u76CA8000\u4E07\u5186\u3001\u501F\u5165\u91D11\u5104\u5186",
        intervieweeInfo: "\u4EE3\u8868\u53D6\u7DE0\u5F79 \u7530\u4E2D\u592A\u90CE\u6C0F\uFF0845\u6B73\uFF09\u3001\u6280\u8853\u7CFB\u51FA\u8EAB\u306E\u7D4C\u55B6\u8005",
        maRelatedInfo: "\u5F8C\u7D99\u8005\u4E0D\u5728\u306E\u305F\u3081\u4E8B\u696D\u627F\u7D99\u3092\u691C\u8A0E\u30015\u5E74\u4EE5\u5185\u306E\u8B72\u6E21\u3092\u5E0C\u671B",
        nextActions: "\u8CA1\u52D9\u8CC7\u6599\u306E\u6E96\u5099\u3001\u4F01\u696D\u8A55\u4FA1\u306E\u5B9F\u65BD\u3001\u8CB7\u3044\u624B\u5019\u88DC\u30EA\u30B9\u30C8\u306E\u4F5C\u6210",
        ourSide: "M&A\u30A2\u30C9\u30D0\u30A4\u30B6\u30FC \u5C71\u7530\u6B21\u90CE\u3001\u30A2\u30CA\u30EA\u30B9\u30C8 \u9234\u6728\u4E00\u90CE",
        ownerInfo: "\u5275\u696D\u8005\u517C\u4EE3\u8868\u53D6\u7DE0\u5F79\u3001\u682A\u5F0F100%\u4FDD\u6709\u3001\u5F8C\u7D99\u8005\u9078\u5B9A\u306B\u8AB2\u984C",
        personalCharacteristics: "\u5805\u5B9F\u306A\u7D4C\u55B6\u8005\u3001\u5F93\u696D\u54E1\u601D\u3044\u306E\u4EBA\u67C4\u3001\u6C7A\u65AD\u529B\u304C\u3042\u308B",
        shareholderInfo: "\u4EE3\u8868\u53D6\u7DE0\u5F79\u304C100%\u682A\u5F0F\u4FDD\u6709\u3001\u5F93\u696D\u54E1\u6301\u682A\u5236\u5EA6\u306A\u3057",
        stockPriceExpectation: "\u7D14\u8CC7\u7523\u30D9\u30FC\u30B9\u30673-4\u5104\u5186\u7A0B\u5EA6\u3092\u671F\u5F85",
        todos: "\u6765\u6708\u307E\u3067\u306B3\u671F\u5206\u306E\u8CA1\u52D9\u8AF8\u8868\u63D0\u51FA\u3001\u5F93\u696D\u54E1\u8AAC\u660E\u4F1A\u306E\u691C\u8A0E",
        transferIntention: "\u7A4D\u6975\u7684\uFF08\u7DCA\u6025\u5EA6\uFF1A\u4E2D\u3001\u672C\u6C17\u5EA6\uFF1A\u9AD8\uFF09"
      };
    case "content_analysis":
      return {
        title: "\u55B6\u696D\u7814\u4FEE\u30B3\u30F3\u30C6\u30F3\u30C4\u5206\u6790",
        summary: "\u55B6\u696D\u30B9\u30AD\u30EB\u5411\u4E0A\u306B\u95A2\u3059\u308B\u7814\u4FEE\u30B3\u30F3\u30C6\u30F3\u30C4\u306E\u5206\u6790\u7D50\u679C\u3067\u3059\u3002\u52B9\u679C\u7684\u306A\u30D2\u30A2\u30EA\u30F3\u30B0\u6280\u8853\u3068\u9867\u5BA2\u5BFE\u5FDC\u306E\u6539\u5584\u70B9\u306B\u3064\u3044\u3066\u8A73\u7D30\u306B\u89E3\u8AAC\u3055\u308C\u3066\u3044\u307E\u3059\u3002",
        learningObjectives: [
          "\u52B9\u679C\u7684\u306A\u30D2\u30A2\u30EA\u30F3\u30B0\u65B9\u6CD5\u3092\u7FD2\u5F97\u3059\u308B",
          "\u9867\u5BA2\u30CB\u30FC\u30BA\u306B\u5FDC\u3058\u305F\u63D0\u6848\u304C\u3067\u304D\u308B",
          "\u9069\u5207\u306A\u30BF\u30A4\u30DF\u30F3\u30B0\u3067\u30AF\u30ED\u30FC\u30B8\u30F3\u30B0\u3067\u304D\u308B"
        ],
        keyTerms: ["\u30D2\u30A2\u30EA\u30F3\u30B0\u6280\u8853", "\u63D0\u6848\u529B", "\u30AF\u30ED\u30FC\u30B8\u30F3\u30B0", "\u9867\u5BA2\u5BFE\u5FDC"],
        difficulty: "intermediate"
      };
    case "quiz_material":
      return {
        questions: [
          {
            question: "\u52B9\u679C\u7684\u306A\u30D2\u30A2\u30EA\u30F3\u30B0\u3067\u6700\u3082\u91CD\u8981\u306A\u3053\u3068\u306F\uFF1F",
            type: "multiple_choice",
            options: [
              "\u591A\u304F\u306E\u8CEA\u554F\u3092\u3059\u308B\u3053\u3068",
              "\u76F8\u624B\u306E\u8A71\u3092\u3088\u304F\u805E\u304F\u3053\u3068",
              "\u5546\u54C1\u8AAC\u660E\u3092\u8A73\u3057\u304F\u3059\u308B\u3053\u3068",
              "\u4FA1\u683C\u4EA4\u6E09\u3092\u3059\u308B\u3053\u3068"
            ],
            correct_answer: "\u76F8\u624B\u306E\u8A71\u3092\u3088\u304F\u805E\u304F\u3053\u3068",
            explanation: "\u30D2\u30A2\u30EA\u30F3\u30B0\u3067\u306F\u76F8\u624B\u306E\u30CB\u30FC\u30BA\u3092\u6B63\u78BA\u306B\u628A\u63E1\u3059\u308B\u305F\u3081\u306B\u3001\u7A4D\u6975\u7684\u306A\u50BE\u8074\u304C\u91CD\u8981\u3067\u3059\u3002",
            difficulty: "medium"
          }
        ],
        learning_points: ["\u50BE\u8074\u306E\u91CD\u8981\u6027", "\u9069\u5207\u306A\u8CEA\u554F\u306E\u4ED5\u65B9", "\u9867\u5BA2\u30CB\u30FC\u30BA\u306E\u628A\u63E1\u65B9\u6CD5"]
      };
    default:
      return {
        analysis: `${i}\u306E\u6A21\u64EC\u89E3\u6790\u7D50\u679C`,
        timestamp: (/* @__PURE__ */ new Date()).toISOString(),
        confidence: 0.9
      };
  }
}
o(y, "mockAnalysis");
async function Z(i, e = {}) {
  try {
    let t = await g(i, e);
    if (!t)
      throw new Error("Empty response from Gemini API");
    return t;
  } catch (t) {
    throw console.error("[Gemini] Chat response generation error:", t), new Error(`AI API \u30A8\u30E9\u30FC: ${t instanceof Error ? t.message : "\u4E0D\u660E\u306A\u30A8\u30E9\u30FC"}`);
  }
}
o(Z, "generateChatResponse");
async function ee(i, e, t = {}) {
  console.log(`[performAnalysis] ${i}\u5206\u6790\u958B\u59CB - \u30C6\u30AD\u30B9\u30C8\u9577: ${e.length}\u6587\u5B57`), console.log(`[performAnalysis] \u30E1\u30E2\u30EA\u4F7F\u7528\u91CF: ${Math.round(process.memoryUsage().rss / 1024 / 1024)}MB`);
  try {
    console.log("[performAnalysis] Vertex AI\u5229\u7528\u53EF\u80FD\u6027\u30C1\u30A7\u30C3\u30AF\u958B\u59CB");
    let r = await P();
    if (console.log(`[performAnalysis] Vertex AI\u5229\u7528\u53EF\u80FD: ${r}`), r) {
      console.log(`[performAnalysis] Vertex AI\u4F7F\u7528 - ${i}\u5B9F\u884C\u958B\u59CB`);
      try {
        let n;
        switch (i) {
          case "meeting_minutes":
            return console.log("[performAnalysis] generateMeetingMinutes\u547C\u3073\u51FA\u3057\u958B\u59CB"), n = await d(e, t), console.log("[performAnalysis] generateMeetingMinutes\u5B8C\u4E86:", n ? "\u6210\u529F" : "\u5931\u6557"), n;
          case "case_summary":
            return console.log("[performAnalysis] generateCaseSummary\u547C\u3073\u51FA\u3057\u958B\u59CB"), n = await C(e, t), console.log("[performAnalysis] generateCaseSummary\u5B8C\u4E86:", n ? "\u6210\u529F" : "\u5931\u6557"), n;
          case "meeting_summary":
            return console.log("[performAnalysis] generateMeetingSummary\u547C\u3073\u51FA\u3057\u958B\u59CB"), n = await T(e, t), console.log("[performAnalysis] generateMeetingSummary\u5B8C\u4E86:", n ? "\u6210\u529F" : "\u5931\u6557"), n;
          case "content_analysis":
            return console.log("[performAnalysis] generateContentAnalysis\u547C\u3073\u51FA\u3057\u958B\u59CB"), n = await k(e, t), console.log("[performAnalysis] generateContentAnalysis\u5B8C\u4E86:", n ? "\u6210\u529F" : "\u5931\u6557"), n;
          case "quiz_material":
            return console.log("[performAnalysis] generateQuizMaterial\u547C\u3073\u51FA\u3057\u958B\u59CB"), n = await S(e, t), console.log("[performAnalysis] generateQuizMaterial\u5B8C\u4E86:", n ? "\u6210\u529F" : "\u5931\u6557"), n;
          case "evaluation":
            return console.log("[performAnalysis] generateEvaluation\u547C\u3073\u51FA\u3057\u958B\u59CB"), n = await O(e, "general", t), console.log("[performAnalysis] generateEvaluation\u5B8C\u4E86:", n ? "\u6210\u529F" : "\u5931\u6557"), n;
          default:
            throw new Error(`Unsupported analysis type: ${i}`);
        }
      } catch (n) {
        return console.error(`[performAnalysis] Gemini API\u5B9F\u884C\u30A8\u30E9\u30FC (${i}):`, n), console.error(`[performAnalysis] \u30A8\u30E9\u30FC\u8A73\u7D30 - name: ${n instanceof Error ? n.name : "Unknown"}`), console.error(`[performAnalysis] \u30A8\u30E9\u30FC\u8A73\u7D30 - message: ${n instanceof Error ? n.message : "Unknown"}`), console.error(`[performAnalysis] \u30A8\u30E9\u30FC\u8A73\u7D30 - stack: ${n instanceof Error ? n.stack : "Unknown"}`), console.log(`[performAnalysis] \u30E2\u30C3\u30AF\u5206\u6790\u306B\u30D5\u30A9\u30FC\u30EB\u30D0\u30C3\u30AF: ${i}`), y(i, e);
      }
    } else
      return console.log(`[performAnalysis] Gemini API\u5229\u7528\u4E0D\u53EF - \u30E2\u30C3\u30AF\u5206\u6790\u4F7F\u7528: ${i}`), y(i, e);
  } catch (r) {
    return console.error(`[performAnalysis] \u5916\u5074\u306Etry-catch\u3067\u30A8\u30E9\u30FC\u6355\u6349 (${i}):`, r), console.error(`[performAnalysis] \u5916\u5074\u30A8\u30E9\u30FC\u8A73\u7D30 - name: ${r instanceof Error ? r.name : "Unknown"}`), console.error(`[performAnalysis] \u5916\u5074\u30A8\u30E9\u30FC\u8A73\u7D30 - message: ${r instanceof Error ? r.message : "Unknown"}`), console.log(`[performAnalysis] \u5916\u5074\u30A8\u30E9\u30FC\u306E\u305F\u3081\u30E2\u30C3\u30AF\u5206\u6790\u5B9F\u884C: ${i}`), y(i, e);
  }
}
o(ee, "performAnalysis");

// convex/evaluation/client.ts
var c = class {
  static {
    o(this, "EvaluationClient");
  }
  engine;
  config;
  constructor(e) {
    this.config = e, this.engine = new l(e);
  }
  async generateStructuredContent(e, t, r) {
    try {
      return e.includes("\u4F1A\u8B70") || e.includes("\u8B70\u4E8B\u9332") || e.includes("\u6587\u5B57\u8D77\u3053\u3057") ? await d(e) : await this.engine.generateStructuredContent(e, t, {
        temperature: r?.temperature ?? this.config?.vertexAI?.temperature ?? 0.1,
        maxOutputTokens: r?.maxOutputTokens ?? this.config?.vertexAI?.maxOutputTokens ?? 32768
        // topK: options?.topK ?? this.config?.vertexAI?.topK ?? 40, // topK は現在サポートされていません
        // topP: options?.topP ?? this.config?.vertexAI?.topP ?? 0.95, // HybridEvaluationEngineのgenerateTextの型でサポートされていません
      });
    } catch (n) {
      throw new Error(`EvaluationClient error: ${n instanceof Error ? n.message : "Unknown error"}`);
    }
  }
  async generateText(e, t) {
    try {
      return e.includes("\u4F1A\u8B70") || e.includes("\u8B70\u4E8B\u9332") || e.includes("\u6587\u5B57\u8D77\u3053\u3057") ? (await d(e)).summary || "\u751F\u6210\u306B\u5931\u6557\u3057\u307E\u3057\u305F" : await this.engine.generateText(e, {
        temperature: t?.temperature ?? this.config?.vertexAI?.temperature ?? 0.1,
        maxOutputTokens: t?.maxOutputTokens ?? this.config?.vertexAI?.maxOutputTokens ?? 32768
        // topK: options?.topK ?? this.config?.vertexAI?.topK ?? 40, // topK は現在サポートされていません
        // topP: options?.topP ?? this.config?.vertexAI?.topP ?? 0.95, // HybridEvaluationEngineのgenerateTextの型でサポートされていません
      });
    } catch (r) {
      throw new Error(`EvaluationClient error: ${r instanceof Error ? r.message : "Unknown error"}`);
    }
  }
  // 旧バージョンのsafeJsonParseは削除（改良版を使用）
  async healthCheck() {
    try {
      return (await this.engine.generateText("\u30C6\u30B9\u30C8", { maxOutputTokens: 100 })).length > 0;
    } catch {
      return !1;
    }
  }
  updateConfig(e) {
    this.config = { ...this.config, ...e };
  }
  getConfig() {
    return this.config;
  }
};

export {
  c as a,
  l as b,
  Q as c,
  P as d,
  Y as e,
  K as f,
  d as g,
  B as h,
  C as i,
  T as j,
  k,
  S as l,
  O as m,
  y as n,
  Z as o,
  ee as p
};
//# sourceMappingURL=NAH3KYY3.js.map
