import {
  a as W,
  b as rn,
  c as nn,
  d as sn,
  e as an,
  f as Oe,
  g as on,
  i as cn,
  m as Zt,
  n as ln
} from "./J5HCNIZW.js";
import {
  a as d,
  b as tn,
  d as E,
  f as v
} from "./V7X2J7BI.js";

// node_modules/@google-cloud/storage/package.json
var ci = E((ao, An) => {
  An.exports = {
    name: "@google-cloud/storage",
    description: "Cloud Storage Client Library for Node.js",
    version: "7.16.0",
    license: "Apache-2.0",
    author: "Google Inc.",
    engines: {
      node: ">=14"
    },
    repository: "googleapis/nodejs-storage",
    main: "./build/cjs/src/index.js",
    types: "./build/cjs/src/index.d.ts",
    type: "module",
    exports: {
      ".": {
        import: {
          types: "./build/esm/src/index.d.ts",
          default: "./build/esm/src/index.js"
        },
        require: {
          types: "./build/cjs/src/index.d.ts",
          default: "./build/cjs/src/index.js"
        }
      }
    },
    files: [
      "build/cjs/src",
      "build/cjs/package.json",
      "!build/cjs/src/**/*.map",
      "build/esm/src",
      "!build/esm/src/**/*.map"
    ],
    keywords: [
      "google apis client",
      "google api client",
      "google apis",
      "google api",
      "google",
      "google cloud platform",
      "google cloud",
      "cloud",
      "google storage",
      "storage"
    ],
    scripts: {
      "all-test": "npm test && npm run system-test && npm run samples-test",
      benchwrapper: "node bin/benchwrapper.js",
      check: "gts check",
      clean: "rm -rf build/",
      "compile:cjs": "tsc -p ./tsconfig.cjs.json",
      "compile:esm": "tsc -p .",
      compile: "npm run compile:cjs && npm run compile:esm",
      "conformance-test": "mocha --parallel build/cjs/conformance-test/ --require build/cjs/conformance-test/globalHooks.js",
      "docs-test": "linkinator docs",
      docs: "jsdoc -c .jsdoc.json",
      fix: "gts fix",
      lint: "gts check",
      postcompile: "cp ./src/package-json-helper.cjs ./build/cjs/src && cp ./src/package-json-helper.cjs ./build/esm/src",
      "postcompile:cjs": "babel --plugins gapic-tools/build/src/replaceImportMetaUrl,gapic-tools/build/src/toggleESMFlagVariable build/cjs/src/util.js -o build/cjs/src/util.js && cp internal-tooling/helpers/package.cjs.json build/cjs/package.json",
      precompile: "rm -rf build/",
      "preconformance-test": "npm run compile:cjs -- --sourceMap",
      "predocs-test": "npm run docs",
      predocs: "npm run compile:cjs -- --sourceMap",
      prelint: "cd samples; npm link ../; npm install",
      prepare: "npm run compile",
      "presystem-test:esm": "npm run compile:esm",
      "presystem-test": "npm run compile -- --sourceMap",
      pretest: "npm run compile -- --sourceMap",
      "samples-test": "npm link && cd samples/ && npm link ../ && npm test && cd ../",
      "system-test:esm": "mocha build/esm/system-test --timeout 600000 --exit",
      "system-test": "mocha build/cjs/system-test --timeout 600000 --exit",
      test: "c8 mocha build/cjs/test"
    },
    dependencies: {
      "@google-cloud/paginator": "^5.0.0",
      "@google-cloud/projectify": "^4.0.0",
      "@google-cloud/promisify": "<4.1.0",
      "abort-controller": "^3.0.0",
      "async-retry": "^1.3.3",
      duplexify: "^4.1.3",
      "fast-xml-parser": "^4.4.1",
      gaxios: "^6.0.2",
      "google-auth-library": "^9.6.3",
      "html-entities": "^2.5.2",
      mime: "^3.0.0",
      "p-limit": "^3.0.1",
      "retry-request": "^7.0.0",
      "teeny-request": "^9.0.0",
      uuid: "^8.0.0"
    },
    devDependencies: {
      "@babel/cli": "^7.22.10",
      "@babel/core": "^7.22.11",
      "@google-cloud/pubsub": "^4.0.0",
      "@grpc/grpc-js": "^1.0.3",
      "@grpc/proto-loader": "^0.7.0",
      "@types/async-retry": "^1.4.3",
      "@types/duplexify": "^3.6.4",
      "@types/mime": "^3.0.0",
      "@types/mocha": "^9.1.1",
      "@types/mockery": "^1.4.29",
      "@types/node": "^22.0.0",
      "@types/node-fetch": "^2.1.3",
      "@types/proxyquire": "^1.3.28",
      "@types/request": "^2.48.4",
      "@types/sinon": "^17.0.0",
      "@types/tmp": "0.2.6",
      "@types/uuid": "^8.0.0",
      "@types/yargs": "^17.0.10",
      c8: "^9.0.0",
      "form-data": "^4.0.0",
      "gapic-tools": "^0.4.0",
      gts: "^5.0.0",
      jsdoc: "^4.0.0",
      "jsdoc-fresh": "^3.0.0",
      "jsdoc-region-tag": "^3.0.0",
      linkinator: "^3.0.0",
      mocha: "^9.2.2",
      mockery: "^2.1.0",
      nock: "~13.5.0",
      "node-fetch": "^2.6.7",
      "pack-n-play": "^2.0.0",
      proxyquire: "^2.1.3",
      sinon: "^18.0.0",
      nise: "6.0.0",
      "path-to-regexp": "6.3.0",
      tmp: "^0.2.0",
      typescript: "^5.1.6",
      yargs: "^17.3.1"
    }
  };
});

// node_modules/@google-cloud/storage/build/esm/src/package-json-helper.cjs
var Ee = E((li) => {
  function _n() {
    return ci();
  }
  d(_n, "getPackageJSON");
  li.getPackageJSON = _n;
});

// node_modules/@google-cloud/paginator/build/src/resource-stream.js
var vi = E((Ye) => {
  "use strict";
  Object.defineProperty(Ye, "__esModule", { value: !0 });
  Ye.ResourceStream = void 0;
  var On = tn("stream"), It = class extends On.Transform {
    static {
      d(this, "ResourceStream");
    }
    constructor(e, t) {
      let i = Object.assign({ objectMode: !0 }, e.streamOptions);
      super(i), this._ended = !1, this._maxApiCalls = e.maxApiCalls === -1 ? 1 / 0 : e.maxApiCalls, this._nextQuery = e.query, this._reading = !1, this._requestFn = t, this._requestsMade = 0, this._resultsToSend = e.maxResults === -1 ? 1 / 0 : e.maxResults, this._otherArgs = [];
    }
    /* eslint-disable  @typescript-eslint/no-explicit-any */
    end(...e) {
      return this._ended = !0, super.end(...e);
    }
    _read() {
      if (!this._reading) {
        this._reading = !0;
        try {
          this._requestFn(this._nextQuery, (e, t, i, ...n) => {
            if (e) {
              this.destroy(e);
              return;
            }
            this._otherArgs = n, this._nextQuery = i, this._resultsToSend !== 1 / 0 && (t = t.splice(0, this._resultsToSend), this._resultsToSend -= t.length);
            let s = !0;
            for (let o of t) {
              if (this._ended)
                break;
              s = this.push(o);
            }
            let c = !this._nextQuery || this._resultsToSend < 1, a = ++this._requestsMade >= this._maxApiCalls;
            (c || a) && this.end(), s && !this._ended && setImmediate(() => this._read()), this._reading = !1;
          });
        } catch (e) {
          this.destroy(e);
        }
      }
    }
  };
  Ye.ResourceStream = It;
});

// node_modules/@google-cloud/paginator/build/src/index.js
var St = E((re) => {
  "use strict";
  Object.defineProperty(re, "__esModule", { value: !0 });
  re.ResourceStream = re.paginator = re.Paginator = void 0;
  var Cn = rn(), bi = nn(), wi = vi();
  Object.defineProperty(re, "ResourceStream", { enumerable: !0, get: /* @__PURE__ */ d(function() {
    return wi.ResourceStream;
  }, "get") });
  var Je = class {
    static {
      d(this, "Paginator");
    }
    /**
     * Cache the original method, then overwrite it on the Class's prototype.
     *
     * @param {function} Class - The parent class of the methods to extend.
     * @param {string|string[]} methodNames - Name(s) of the methods to extend.
     */
    // tslint:disable-next-line:variable-name
    extend(e, t) {
      t = Cn(t), t.forEach((i) => {
        let n = e.prototype[i];
        e.prototype[i + "_"] = n, e.prototype[i] = function(...s) {
          let c = _e.parseArguments_(s);
          return _e.run_(c, n.bind(this));
        };
      });
    }
    /**
     * Wraps paginated API calls in a readable object stream.
     *
     * This method simply calls the nextQuery recursively, emitting results to a
     * stream. The stream ends when `nextQuery` is null.
     *
     * `maxResults` will act as a cap for how many results are fetched and emitted
     * to the stream.
     *
     * @param {string} methodName - Name of the method to streamify.
     * @return {function} - Wrapped function.
     */
    /* eslint-disable  @typescript-eslint/no-explicit-any */
    streamify(e) {
      return function(...t) {
        let i = _e.parseArguments_(t), n = this[e + "_"] || this[e];
        return _e.runAsStream_(i, n.bind(this));
      };
    }
    /**
     * Parse a pseudo-array `arguments` for a query and callback.
     *
     * @param {array} args - The original `arguments` pseduo-array that the original
     *     method received.
     */
    /* eslint-disable  @typescript-eslint/no-explicit-any */
    parseArguments_(e) {
      let t, i = !0, n = -1, s = -1, c, a = e[0], o = e[e.length - 1];
      typeof a == "function" ? c = a : t = a, typeof o == "function" && (c = o), typeof t == "object" && (t = bi(!0, {}, t), t.maxResults && typeof t.maxResults == "number" ? s = t.maxResults : typeof t.pageSize == "number" && (s = t.pageSize), t.maxApiCalls && typeof t.maxApiCalls == "number" && (n = t.maxApiCalls, delete t.maxApiCalls), (s !== -1 || t.autoPaginate === !1) && (i = !1));
      let l = {
        query: t || {},
        autoPaginate: i,
        maxApiCalls: n,
        maxResults: s,
        callback: c
      };
      return l.streamOptions = bi(!0, {}, l.query), delete l.streamOptions.autoPaginate, delete l.streamOptions.maxResults, delete l.streamOptions.pageSize, l;
    }
    /**
     * This simply checks to see if `autoPaginate` is set or not, if it's true
     * then we buffer all results, otherwise simply call the original method.
     *
     * @param {array} parsedArguments - Parsed arguments from the original method
     *     call.
     * @param {object=|string=} parsedArguments.query - Query object. This is most
     *     commonly an object, but to make the API more simple, it can also be a
     *     string in some places.
     * @param {function=} parsedArguments.callback - Callback function.
     * @param {boolean} parsedArguments.autoPaginate - Auto-pagination enabled.
     * @param {boolean} parsedArguments.maxApiCalls - Maximum API calls to make.
     * @param {number} parsedArguments.maxResults - Maximum results to return.
     * @param {function} originalMethod - The cached method that accepts a callback
     *     and returns `nextQuery` to receive more results.
     */
    run_(e, t) {
      let i = e.query, n = e.callback;
      if (!e.autoPaginate)
        return t(i, n);
      let s = new Array(), c = [], a = new Promise((o, l) => {
        let p = _e.runAsStream_(e, t);
        p.on("error", l).on("data", (u) => s.push(u)).on("end", () => {
          c = p._otherArgs || [], o(s);
        });
      });
      if (!n)
        return a.then((o) => [o, i, ...c]);
      a.then((o) => n(null, o, i, ...c), (o) => n(o));
    }
    /**
     * This method simply calls the nextQuery recursively, emitting results to a
     * stream. The stream ends when `nextQuery` is null.
     *
     * `maxResults` will act as a cap for how many results are fetched and emitted
     * to the stream.
     *
     * @param {object=|string=} parsedArguments.query - Query object. This is most
     *     commonly an object, but to make the API more simple, it can also be a
     *     string in some places.
     * @param {function=} parsedArguments.callback - Callback function.
     * @param {boolean} parsedArguments.autoPaginate - Auto-pagination enabled.
     * @param {boolean} parsedArguments.maxApiCalls - Maximum API calls to make.
     * @param {number} parsedArguments.maxResults - Maximum results to return.
     * @param {function} originalMethod - The cached method that accepts a callback
     *     and returns `nextQuery` to receive more results.
     * @return {stream} - Readable object stream.
     */
    /* eslint-disable  @typescript-eslint/no-explicit-any */
    runAsStream_(e, t) {
      return new wi.ResourceStream(e, t);
    }
  };
  re.Paginator = Je;
  var _e = new Je();
  re.paginator = _e;
});

// node_modules/mime/Mime.js
var Ai = E((Co, Ei) => {
  "use strict";
  function Qe() {
    this._types = /* @__PURE__ */ Object.create(null), this._extensions = /* @__PURE__ */ Object.create(null);
    for (let r = 0; r < arguments.length; r++)
      this.define(arguments[r]);
    this.define = this.define.bind(this), this.getType = this.getType.bind(this), this.getExtension = this.getExtension.bind(this);
  }
  d(Qe, "Mime");
  Qe.prototype.define = function(r, e) {
    for (let t in r) {
      let i = r[t].map(function(n) {
        return n.toLowerCase();
      });
      t = t.toLowerCase();
      for (let n = 0; n < i.length; n++) {
        let s = i[n];
        if (s[0] !== "*") {
          if (!e && s in this._types)
            throw new Error(
              'Attempt to change mapping for "' + s + '" extension from "' + this._types[s] + '" to "' + t + '". Pass `force=true` to allow this, otherwise remove "' + s + '" from the list of extensions for "' + t + '".'
            );
          this._types[s] = t;
        }
      }
      if (e || !this._extensions[t]) {
        let n = i[0];
        this._extensions[t] = n[0] !== "*" ? n : n.substr(1);
      }
    }
  };
  Qe.prototype.getType = function(r) {
    r = String(r);
    let e = r.replace(/^.*[/\\]/, "").toLowerCase(), t = e.replace(/^.*\./, "").toLowerCase(), i = e.length < r.length;
    return (t.length < e.length - 1 || !i) && this._types[t] || null;
  };
  Qe.prototype.getExtension = function(r) {
    return r = /^\s*([^;\s]*)/.test(r) && RegExp.$1, r && this._extensions[r.toLowerCase()] || null;
  };
  Ei.exports = Qe;
});

// node_modules/mime/types/standard.js
var Ti = E((ko, _i) => {
  _i.exports = { "application/andrew-inset": ["ez"], "application/applixware": ["aw"], "application/atom+xml": ["atom"], "application/atomcat+xml": ["atomcat"], "application/atomdeleted+xml": ["atomdeleted"], "application/atomsvc+xml": ["atomsvc"], "application/atsc-dwd+xml": ["dwd"], "application/atsc-held+xml": ["held"], "application/atsc-rsat+xml": ["rsat"], "application/bdoc": ["bdoc"], "application/calendar+xml": ["xcs"], "application/ccxml+xml": ["ccxml"], "application/cdfx+xml": ["cdfx"], "application/cdmi-capability": ["cdmia"], "application/cdmi-container": ["cdmic"], "application/cdmi-domain": ["cdmid"], "application/cdmi-object": ["cdmio"], "application/cdmi-queue": ["cdmiq"], "application/cu-seeme": ["cu"], "application/dash+xml": ["mpd"], "application/davmount+xml": ["davmount"], "application/docbook+xml": ["dbk"], "application/dssc+der": ["dssc"], "application/dssc+xml": ["xdssc"], "application/ecmascript": ["es", "ecma"], "application/emma+xml": ["emma"], "application/emotionml+xml": ["emotionml"], "application/epub+zip": ["epub"], "application/exi": ["exi"], "application/express": ["exp"], "application/fdt+xml": ["fdt"], "application/font-tdpfr": ["pfr"], "application/geo+json": ["geojson"], "application/gml+xml": ["gml"], "application/gpx+xml": ["gpx"], "application/gxf": ["gxf"], "application/gzip": ["gz"], "application/hjson": ["hjson"], "application/hyperstudio": ["stk"], "application/inkml+xml": ["ink", "inkml"], "application/ipfix": ["ipfix"], "application/its+xml": ["its"], "application/java-archive": ["jar", "war", "ear"], "application/java-serialized-object": ["ser"], "application/java-vm": ["class"], "application/javascript": ["js", "mjs"], "application/json": ["json", "map"], "application/json5": ["json5"], "application/jsonml+json": ["jsonml"], "application/ld+json": ["jsonld"], "application/lgr+xml": ["lgr"], "application/lost+xml": ["lostxml"], "application/mac-binhex40": ["hqx"], "application/mac-compactpro": ["cpt"], "application/mads+xml": ["mads"], "application/manifest+json": ["webmanifest"], "application/marc": ["mrc"], "application/marcxml+xml": ["mrcx"], "application/mathematica": ["ma", "nb", "mb"], "application/mathml+xml": ["mathml"], "application/mbox": ["mbox"], "application/mediaservercontrol+xml": ["mscml"], "application/metalink+xml": ["metalink"], "application/metalink4+xml": ["meta4"], "application/mets+xml": ["mets"], "application/mmt-aei+xml": ["maei"], "application/mmt-usd+xml": ["musd"], "application/mods+xml": ["mods"], "application/mp21": ["m21", "mp21"], "application/mp4": ["mp4s", "m4p"], "application/msword": ["doc", "dot"], "application/mxf": ["mxf"], "application/n-quads": ["nq"], "application/n-triples": ["nt"], "application/node": ["cjs"], "application/octet-stream": ["bin", "dms", "lrf", "mar", "so", "dist", "distz", "pkg", "bpk", "dump", "elc", "deploy", "exe", "dll", "deb", "dmg", "iso", "img", "msi", "msp", "msm", "buffer"], "application/oda": ["oda"], "application/oebps-package+xml": ["opf"], "application/ogg": ["ogx"], "application/omdoc+xml": ["omdoc"], "application/onenote": ["onetoc", "onetoc2", "onetmp", "onepkg"], "application/oxps": ["oxps"], "application/p2p-overlay+xml": ["relo"], "application/patch-ops-error+xml": ["xer"], "application/pdf": ["pdf"], "application/pgp-encrypted": ["pgp"], "application/pgp-signature": ["asc", "sig"], "application/pics-rules": ["prf"], "application/pkcs10": ["p10"], "application/pkcs7-mime": ["p7m", "p7c"], "application/pkcs7-signature": ["p7s"], "application/pkcs8": ["p8"], "application/pkix-attr-cert": ["ac"], "application/pkix-cert": ["cer"], "application/pkix-crl": ["crl"], "application/pkix-pkipath": ["pkipath"], "application/pkixcmp": ["pki"], "application/pls+xml": ["pls"], "application/postscript": ["ai", "eps", "ps"], "application/provenance+xml": ["provx"], "application/pskc+xml": ["pskcxml"], "application/raml+yaml": ["raml"], "application/rdf+xml": ["rdf", "owl"], "application/reginfo+xml": ["rif"], "application/relax-ng-compact-syntax": ["rnc"], "application/resource-lists+xml": ["rl"], "application/resource-lists-diff+xml": ["rld"], "application/rls-services+xml": ["rs"], "application/route-apd+xml": ["rapd"], "application/route-s-tsid+xml": ["sls"], "application/route-usd+xml": ["rusd"], "application/rpki-ghostbusters": ["gbr"], "application/rpki-manifest": ["mft"], "application/rpki-roa": ["roa"], "application/rsd+xml": ["rsd"], "application/rss+xml": ["rss"], "application/rtf": ["rtf"], "application/sbml+xml": ["sbml"], "application/scvp-cv-request": ["scq"], "application/scvp-cv-response": ["scs"], "application/scvp-vp-request": ["spq"], "application/scvp-vp-response": ["spp"], "application/sdp": ["sdp"], "application/senml+xml": ["senmlx"], "application/sensml+xml": ["sensmlx"], "application/set-payment-initiation": ["setpay"], "application/set-registration-initiation": ["setreg"], "application/shf+xml": ["shf"], "application/sieve": ["siv", "sieve"], "application/smil+xml": ["smi", "smil"], "application/sparql-query": ["rq"], "application/sparql-results+xml": ["srx"], "application/srgs": ["gram"], "application/srgs+xml": ["grxml"], "application/sru+xml": ["sru"], "application/ssdl+xml": ["ssdl"], "application/ssml+xml": ["ssml"], "application/swid+xml": ["swidtag"], "application/tei+xml": ["tei", "teicorpus"], "application/thraud+xml": ["tfi"], "application/timestamped-data": ["tsd"], "application/toml": ["toml"], "application/trig": ["trig"], "application/ttml+xml": ["ttml"], "application/ubjson": ["ubj"], "application/urc-ressheet+xml": ["rsheet"], "application/urc-targetdesc+xml": ["td"], "application/voicexml+xml": ["vxml"], "application/wasm": ["wasm"], "application/widget": ["wgt"], "application/winhlp": ["hlp"], "application/wsdl+xml": ["wsdl"], "application/wspolicy+xml": ["wspolicy"], "application/xaml+xml": ["xaml"], "application/xcap-att+xml": ["xav"], "application/xcap-caps+xml": ["xca"], "application/xcap-diff+xml": ["xdf"], "application/xcap-el+xml": ["xel"], "application/xcap-ns+xml": ["xns"], "application/xenc+xml": ["xenc"], "application/xhtml+xml": ["xhtml", "xht"], "application/xliff+xml": ["xlf"], "application/xml": ["xml", "xsl", "xsd", "rng"], "application/xml-dtd": ["dtd"], "application/xop+xml": ["xop"], "application/xproc+xml": ["xpl"], "application/xslt+xml": ["*xsl", "xslt"], "application/xspf+xml": ["xspf"], "application/xv+xml": ["mxml", "xhvml", "xvml", "xvm"], "application/yang": ["yang"], "application/yin+xml": ["yin"], "application/zip": ["zip"], "audio/3gpp": ["*3gpp"], "audio/adpcm": ["adp"], "audio/amr": ["amr"], "audio/basic": ["au", "snd"], "audio/midi": ["mid", "midi", "kar", "rmi"], "audio/mobile-xmf": ["mxmf"], "audio/mp3": ["*mp3"], "audio/mp4": ["m4a", "mp4a"], "audio/mpeg": ["mpga", "mp2", "mp2a", "mp3", "m2a", "m3a"], "audio/ogg": ["oga", "ogg", "spx", "opus"], "audio/s3m": ["s3m"], "audio/silk": ["sil"], "audio/wav": ["wav"], "audio/wave": ["*wav"], "audio/webm": ["weba"], "audio/xm": ["xm"], "font/collection": ["ttc"], "font/otf": ["otf"], "font/ttf": ["ttf"], "font/woff": ["woff"], "font/woff2": ["woff2"], "image/aces": ["exr"], "image/apng": ["apng"], "image/avif": ["avif"], "image/bmp": ["bmp"], "image/cgm": ["cgm"], "image/dicom-rle": ["drle"], "image/emf": ["emf"], "image/fits": ["fits"], "image/g3fax": ["g3"], "image/gif": ["gif"], "image/heic": ["heic"], "image/heic-sequence": ["heics"], "image/heif": ["heif"], "image/heif-sequence": ["heifs"], "image/hej2k": ["hej2"], "image/hsj2": ["hsj2"], "image/ief": ["ief"], "image/jls": ["jls"], "image/jp2": ["jp2", "jpg2"], "image/jpeg": ["jpeg", "jpg", "jpe"], "image/jph": ["jph"], "image/jphc": ["jhc"], "image/jpm": ["jpm"], "image/jpx": ["jpx", "jpf"], "image/jxr": ["jxr"], "image/jxra": ["jxra"], "image/jxrs": ["jxrs"], "image/jxs": ["jxs"], "image/jxsc": ["jxsc"], "image/jxsi": ["jxsi"], "image/jxss": ["jxss"], "image/ktx": ["ktx"], "image/ktx2": ["ktx2"], "image/png": ["png"], "image/sgi": ["sgi"], "image/svg+xml": ["svg", "svgz"], "image/t38": ["t38"], "image/tiff": ["tif", "tiff"], "image/tiff-fx": ["tfx"], "image/webp": ["webp"], "image/wmf": ["wmf"], "message/disposition-notification": ["disposition-notification"], "message/global": ["u8msg"], "message/global-delivery-status": ["u8dsn"], "message/global-disposition-notification": ["u8mdn"], "message/global-headers": ["u8hdr"], "message/rfc822": ["eml", "mime"], "model/3mf": ["3mf"], "model/gltf+json": ["gltf"], "model/gltf-binary": ["glb"], "model/iges": ["igs", "iges"], "model/mesh": ["msh", "mesh", "silo"], "model/mtl": ["mtl"], "model/obj": ["obj"], "model/step+xml": ["stpx"], "model/step+zip": ["stpz"], "model/step-xml+zip": ["stpxz"], "model/stl": ["stl"], "model/vrml": ["wrl", "vrml"], "model/x3d+binary": ["*x3db", "x3dbz"], "model/x3d+fastinfoset": ["x3db"], "model/x3d+vrml": ["*x3dv", "x3dvz"], "model/x3d+xml": ["x3d", "x3dz"], "model/x3d-vrml": ["x3dv"], "text/cache-manifest": ["appcache", "manifest"], "text/calendar": ["ics", "ifb"], "text/coffeescript": ["coffee", "litcoffee"], "text/css": ["css"], "text/csv": ["csv"], "text/html": ["html", "htm", "shtml"], "text/jade": ["jade"], "text/jsx": ["jsx"], "text/less": ["less"], "text/markdown": ["markdown", "md"], "text/mathml": ["mml"], "text/mdx": ["mdx"], "text/n3": ["n3"], "text/plain": ["txt", "text", "conf", "def", "list", "log", "in", "ini"], "text/richtext": ["rtx"], "text/rtf": ["*rtf"], "text/sgml": ["sgml", "sgm"], "text/shex": ["shex"], "text/slim": ["slim", "slm"], "text/spdx": ["spdx"], "text/stylus": ["stylus", "styl"], "text/tab-separated-values": ["tsv"], "text/troff": ["t", "tr", "roff", "man", "me", "ms"], "text/turtle": ["ttl"], "text/uri-list": ["uri", "uris", "urls"], "text/vcard": ["vcard"], "text/vtt": ["vtt"], "text/xml": ["*xml"], "text/yaml": ["yaml", "yml"], "video/3gpp": ["3gp", "3gpp"], "video/3gpp2": ["3g2"], "video/h261": ["h261"], "video/h263": ["h263"], "video/h264": ["h264"], "video/iso.segment": ["m4s"], "video/jpeg": ["jpgv"], "video/jpm": ["*jpm", "jpgm"], "video/mj2": ["mj2", "mjp2"], "video/mp2t": ["ts"], "video/mp4": ["mp4", "mp4v", "mpg4"], "video/mpeg": ["mpeg", "mpg", "mpe", "m1v", "m2v"], "video/ogg": ["ogv"], "video/quicktime": ["qt", "mov"], "video/webm": ["webm"] };
});

// node_modules/mime/types/other.js
var Ni = E((Uo, Ri) => {
  Ri.exports = { "application/prs.cww": ["cww"], "application/vnd.1000minds.decision-model+xml": ["1km"], "application/vnd.3gpp.pic-bw-large": ["plb"], "application/vnd.3gpp.pic-bw-small": ["psb"], "application/vnd.3gpp.pic-bw-var": ["pvb"], "application/vnd.3gpp2.tcap": ["tcap"], "application/vnd.3m.post-it-notes": ["pwn"], "application/vnd.accpac.simply.aso": ["aso"], "application/vnd.accpac.simply.imp": ["imp"], "application/vnd.acucobol": ["acu"], "application/vnd.acucorp": ["atc", "acutc"], "application/vnd.adobe.air-application-installer-package+zip": ["air"], "application/vnd.adobe.formscentral.fcdt": ["fcdt"], "application/vnd.adobe.fxp": ["fxp", "fxpl"], "application/vnd.adobe.xdp+xml": ["xdp"], "application/vnd.adobe.xfdf": ["xfdf"], "application/vnd.ahead.space": ["ahead"], "application/vnd.airzip.filesecure.azf": ["azf"], "application/vnd.airzip.filesecure.azs": ["azs"], "application/vnd.amazon.ebook": ["azw"], "application/vnd.americandynamics.acc": ["acc"], "application/vnd.amiga.ami": ["ami"], "application/vnd.android.package-archive": ["apk"], "application/vnd.anser-web-certificate-issue-initiation": ["cii"], "application/vnd.anser-web-funds-transfer-initiation": ["fti"], "application/vnd.antix.game-component": ["atx"], "application/vnd.apple.installer+xml": ["mpkg"], "application/vnd.apple.keynote": ["key"], "application/vnd.apple.mpegurl": ["m3u8"], "application/vnd.apple.numbers": ["numbers"], "application/vnd.apple.pages": ["pages"], "application/vnd.apple.pkpass": ["pkpass"], "application/vnd.aristanetworks.swi": ["swi"], "application/vnd.astraea-software.iota": ["iota"], "application/vnd.audiograph": ["aep"], "application/vnd.balsamiq.bmml+xml": ["bmml"], "application/vnd.blueice.multipass": ["mpm"], "application/vnd.bmi": ["bmi"], "application/vnd.businessobjects": ["rep"], "application/vnd.chemdraw+xml": ["cdxml"], "application/vnd.chipnuts.karaoke-mmd": ["mmd"], "application/vnd.cinderella": ["cdy"], "application/vnd.citationstyles.style+xml": ["csl"], "application/vnd.claymore": ["cla"], "application/vnd.cloanto.rp9": ["rp9"], "application/vnd.clonk.c4group": ["c4g", "c4d", "c4f", "c4p", "c4u"], "application/vnd.cluetrust.cartomobile-config": ["c11amc"], "application/vnd.cluetrust.cartomobile-config-pkg": ["c11amz"], "application/vnd.commonspace": ["csp"], "application/vnd.contact.cmsg": ["cdbcmsg"], "application/vnd.cosmocaller": ["cmc"], "application/vnd.crick.clicker": ["clkx"], "application/vnd.crick.clicker.keyboard": ["clkk"], "application/vnd.crick.clicker.palette": ["clkp"], "application/vnd.crick.clicker.template": ["clkt"], "application/vnd.crick.clicker.wordbank": ["clkw"], "application/vnd.criticaltools.wbs+xml": ["wbs"], "application/vnd.ctc-posml": ["pml"], "application/vnd.cups-ppd": ["ppd"], "application/vnd.curl.car": ["car"], "application/vnd.curl.pcurl": ["pcurl"], "application/vnd.dart": ["dart"], "application/vnd.data-vision.rdz": ["rdz"], "application/vnd.dbf": ["dbf"], "application/vnd.dece.data": ["uvf", "uvvf", "uvd", "uvvd"], "application/vnd.dece.ttml+xml": ["uvt", "uvvt"], "application/vnd.dece.unspecified": ["uvx", "uvvx"], "application/vnd.dece.zip": ["uvz", "uvvz"], "application/vnd.denovo.fcselayout-link": ["fe_launch"], "application/vnd.dna": ["dna"], "application/vnd.dolby.mlp": ["mlp"], "application/vnd.dpgraph": ["dpg"], "application/vnd.dreamfactory": ["dfac"], "application/vnd.ds-keypoint": ["kpxx"], "application/vnd.dvb.ait": ["ait"], "application/vnd.dvb.service": ["svc"], "application/vnd.dynageo": ["geo"], "application/vnd.ecowin.chart": ["mag"], "application/vnd.enliven": ["nml"], "application/vnd.epson.esf": ["esf"], "application/vnd.epson.msf": ["msf"], "application/vnd.epson.quickanime": ["qam"], "application/vnd.epson.salt": ["slt"], "application/vnd.epson.ssf": ["ssf"], "application/vnd.eszigno3+xml": ["es3", "et3"], "application/vnd.ezpix-album": ["ez2"], "application/vnd.ezpix-package": ["ez3"], "application/vnd.fdf": ["fdf"], "application/vnd.fdsn.mseed": ["mseed"], "application/vnd.fdsn.seed": ["seed", "dataless"], "application/vnd.flographit": ["gph"], "application/vnd.fluxtime.clip": ["ftc"], "application/vnd.framemaker": ["fm", "frame", "maker", "book"], "application/vnd.frogans.fnc": ["fnc"], "application/vnd.frogans.ltf": ["ltf"], "application/vnd.fsc.weblaunch": ["fsc"], "application/vnd.fujitsu.oasys": ["oas"], "application/vnd.fujitsu.oasys2": ["oa2"], "application/vnd.fujitsu.oasys3": ["oa3"], "application/vnd.fujitsu.oasysgp": ["fg5"], "application/vnd.fujitsu.oasysprs": ["bh2"], "application/vnd.fujixerox.ddd": ["ddd"], "application/vnd.fujixerox.docuworks": ["xdw"], "application/vnd.fujixerox.docuworks.binder": ["xbd"], "application/vnd.fuzzysheet": ["fzs"], "application/vnd.genomatix.tuxedo": ["txd"], "application/vnd.geogebra.file": ["ggb"], "application/vnd.geogebra.tool": ["ggt"], "application/vnd.geometry-explorer": ["gex", "gre"], "application/vnd.geonext": ["gxt"], "application/vnd.geoplan": ["g2w"], "application/vnd.geospace": ["g3w"], "application/vnd.gmx": ["gmx"], "application/vnd.google-apps.document": ["gdoc"], "application/vnd.google-apps.presentation": ["gslides"], "application/vnd.google-apps.spreadsheet": ["gsheet"], "application/vnd.google-earth.kml+xml": ["kml"], "application/vnd.google-earth.kmz": ["kmz"], "application/vnd.grafeq": ["gqf", "gqs"], "application/vnd.groove-account": ["gac"], "application/vnd.groove-help": ["ghf"], "application/vnd.groove-identity-message": ["gim"], "application/vnd.groove-injector": ["grv"], "application/vnd.groove-tool-message": ["gtm"], "application/vnd.groove-tool-template": ["tpl"], "application/vnd.groove-vcard": ["vcg"], "application/vnd.hal+xml": ["hal"], "application/vnd.handheld-entertainment+xml": ["zmm"], "application/vnd.hbci": ["hbci"], "application/vnd.hhe.lesson-player": ["les"], "application/vnd.hp-hpgl": ["hpgl"], "application/vnd.hp-hpid": ["hpid"], "application/vnd.hp-hps": ["hps"], "application/vnd.hp-jlyt": ["jlt"], "application/vnd.hp-pcl": ["pcl"], "application/vnd.hp-pclxl": ["pclxl"], "application/vnd.hydrostatix.sof-data": ["sfd-hdstx"], "application/vnd.ibm.minipay": ["mpy"], "application/vnd.ibm.modcap": ["afp", "listafp", "list3820"], "application/vnd.ibm.rights-management": ["irm"], "application/vnd.ibm.secure-container": ["sc"], "application/vnd.iccprofile": ["icc", "icm"], "application/vnd.igloader": ["igl"], "application/vnd.immervision-ivp": ["ivp"], "application/vnd.immervision-ivu": ["ivu"], "application/vnd.insors.igm": ["igm"], "application/vnd.intercon.formnet": ["xpw", "xpx"], "application/vnd.intergeo": ["i2g"], "application/vnd.intu.qbo": ["qbo"], "application/vnd.intu.qfx": ["qfx"], "application/vnd.ipunplugged.rcprofile": ["rcprofile"], "application/vnd.irepository.package+xml": ["irp"], "application/vnd.is-xpr": ["xpr"], "application/vnd.isac.fcs": ["fcs"], "application/vnd.jam": ["jam"], "application/vnd.jcp.javame.midlet-rms": ["rms"], "application/vnd.jisp": ["jisp"], "application/vnd.joost.joda-archive": ["joda"], "application/vnd.kahootz": ["ktz", "ktr"], "application/vnd.kde.karbon": ["karbon"], "application/vnd.kde.kchart": ["chrt"], "application/vnd.kde.kformula": ["kfo"], "application/vnd.kde.kivio": ["flw"], "application/vnd.kde.kontour": ["kon"], "application/vnd.kde.kpresenter": ["kpr", "kpt"], "application/vnd.kde.kspread": ["ksp"], "application/vnd.kde.kword": ["kwd", "kwt"], "application/vnd.kenameaapp": ["htke"], "application/vnd.kidspiration": ["kia"], "application/vnd.kinar": ["kne", "knp"], "application/vnd.koan": ["skp", "skd", "skt", "skm"], "application/vnd.kodak-descriptor": ["sse"], "application/vnd.las.las+xml": ["lasxml"], "application/vnd.llamagraphics.life-balance.desktop": ["lbd"], "application/vnd.llamagraphics.life-balance.exchange+xml": ["lbe"], "application/vnd.lotus-1-2-3": ["123"], "application/vnd.lotus-approach": ["apr"], "application/vnd.lotus-freelance": ["pre"], "application/vnd.lotus-notes": ["nsf"], "application/vnd.lotus-organizer": ["org"], "application/vnd.lotus-screencam": ["scm"], "application/vnd.lotus-wordpro": ["lwp"], "application/vnd.macports.portpkg": ["portpkg"], "application/vnd.mapbox-vector-tile": ["mvt"], "application/vnd.mcd": ["mcd"], "application/vnd.medcalcdata": ["mc1"], "application/vnd.mediastation.cdkey": ["cdkey"], "application/vnd.mfer": ["mwf"], "application/vnd.mfmp": ["mfm"], "application/vnd.micrografx.flo": ["flo"], "application/vnd.micrografx.igx": ["igx"], "application/vnd.mif": ["mif"], "application/vnd.mobius.daf": ["daf"], "application/vnd.mobius.dis": ["dis"], "application/vnd.mobius.mbk": ["mbk"], "application/vnd.mobius.mqy": ["mqy"], "application/vnd.mobius.msl": ["msl"], "application/vnd.mobius.plc": ["plc"], "application/vnd.mobius.txf": ["txf"], "application/vnd.mophun.application": ["mpn"], "application/vnd.mophun.certificate": ["mpc"], "application/vnd.mozilla.xul+xml": ["xul"], "application/vnd.ms-artgalry": ["cil"], "application/vnd.ms-cab-compressed": ["cab"], "application/vnd.ms-excel": ["xls", "xlm", "xla", "xlc", "xlt", "xlw"], "application/vnd.ms-excel.addin.macroenabled.12": ["xlam"], "application/vnd.ms-excel.sheet.binary.macroenabled.12": ["xlsb"], "application/vnd.ms-excel.sheet.macroenabled.12": ["xlsm"], "application/vnd.ms-excel.template.macroenabled.12": ["xltm"], "application/vnd.ms-fontobject": ["eot"], "application/vnd.ms-htmlhelp": ["chm"], "application/vnd.ms-ims": ["ims"], "application/vnd.ms-lrm": ["lrm"], "application/vnd.ms-officetheme": ["thmx"], "application/vnd.ms-outlook": ["msg"], "application/vnd.ms-pki.seccat": ["cat"], "application/vnd.ms-pki.stl": ["*stl"], "application/vnd.ms-powerpoint": ["ppt", "pps", "pot"], "application/vnd.ms-powerpoint.addin.macroenabled.12": ["ppam"], "application/vnd.ms-powerpoint.presentation.macroenabled.12": ["pptm"], "application/vnd.ms-powerpoint.slide.macroenabled.12": ["sldm"], "application/vnd.ms-powerpoint.slideshow.macroenabled.12": ["ppsm"], "application/vnd.ms-powerpoint.template.macroenabled.12": ["potm"], "application/vnd.ms-project": ["mpp", "mpt"], "application/vnd.ms-word.document.macroenabled.12": ["docm"], "application/vnd.ms-word.template.macroenabled.12": ["dotm"], "application/vnd.ms-works": ["wps", "wks", "wcm", "wdb"], "application/vnd.ms-wpl": ["wpl"], "application/vnd.ms-xpsdocument": ["xps"], "application/vnd.mseq": ["mseq"], "application/vnd.musician": ["mus"], "application/vnd.muvee.style": ["msty"], "application/vnd.mynfc": ["taglet"], "application/vnd.neurolanguage.nlu": ["nlu"], "application/vnd.nitf": ["ntf", "nitf"], "application/vnd.noblenet-directory": ["nnd"], "application/vnd.noblenet-sealer": ["nns"], "application/vnd.noblenet-web": ["nnw"], "application/vnd.nokia.n-gage.ac+xml": ["*ac"], "application/vnd.nokia.n-gage.data": ["ngdat"], "application/vnd.nokia.n-gage.symbian.install": ["n-gage"], "application/vnd.nokia.radio-preset": ["rpst"], "application/vnd.nokia.radio-presets": ["rpss"], "application/vnd.novadigm.edm": ["edm"], "application/vnd.novadigm.edx": ["edx"], "application/vnd.novadigm.ext": ["ext"], "application/vnd.oasis.opendocument.chart": ["odc"], "application/vnd.oasis.opendocument.chart-template": ["otc"], "application/vnd.oasis.opendocument.database": ["odb"], "application/vnd.oasis.opendocument.formula": ["odf"], "application/vnd.oasis.opendocument.formula-template": ["odft"], "application/vnd.oasis.opendocument.graphics": ["odg"], "application/vnd.oasis.opendocument.graphics-template": ["otg"], "application/vnd.oasis.opendocument.image": ["odi"], "application/vnd.oasis.opendocument.image-template": ["oti"], "application/vnd.oasis.opendocument.presentation": ["odp"], "application/vnd.oasis.opendocument.presentation-template": ["otp"], "application/vnd.oasis.opendocument.spreadsheet": ["ods"], "application/vnd.oasis.opendocument.spreadsheet-template": ["ots"], "application/vnd.oasis.opendocument.text": ["odt"], "application/vnd.oasis.opendocument.text-master": ["odm"], "application/vnd.oasis.opendocument.text-template": ["ott"], "application/vnd.oasis.opendocument.text-web": ["oth"], "application/vnd.olpc-sugar": ["xo"], "application/vnd.oma.dd2+xml": ["dd2"], "application/vnd.openblox.game+xml": ["obgx"], "application/vnd.openofficeorg.extension": ["oxt"], "application/vnd.openstreetmap.data+xml": ["osm"], "application/vnd.openxmlformats-officedocument.presentationml.presentation": ["pptx"], "application/vnd.openxmlformats-officedocument.presentationml.slide": ["sldx"], "application/vnd.openxmlformats-officedocument.presentationml.slideshow": ["ppsx"], "application/vnd.openxmlformats-officedocument.presentationml.template": ["potx"], "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet": ["xlsx"], "application/vnd.openxmlformats-officedocument.spreadsheetml.template": ["xltx"], "application/vnd.openxmlformats-officedocument.wordprocessingml.document": ["docx"], "application/vnd.openxmlformats-officedocument.wordprocessingml.template": ["dotx"], "application/vnd.osgeo.mapguide.package": ["mgp"], "application/vnd.osgi.dp": ["dp"], "application/vnd.osgi.subsystem": ["esa"], "application/vnd.palm": ["pdb", "pqa", "oprc"], "application/vnd.pawaafile": ["paw"], "application/vnd.pg.format": ["str"], "application/vnd.pg.osasli": ["ei6"], "application/vnd.picsel": ["efif"], "application/vnd.pmi.widget": ["wg"], "application/vnd.pocketlearn": ["plf"], "application/vnd.powerbuilder6": ["pbd"], "application/vnd.previewsystems.box": ["box"], "application/vnd.proteus.magazine": ["mgz"], "application/vnd.publishare-delta-tree": ["qps"], "application/vnd.pvi.ptid1": ["ptid"], "application/vnd.quark.quarkxpress": ["qxd", "qxt", "qwd", "qwt", "qxl", "qxb"], "application/vnd.rar": ["rar"], "application/vnd.realvnc.bed": ["bed"], "application/vnd.recordare.musicxml": ["mxl"], "application/vnd.recordare.musicxml+xml": ["musicxml"], "application/vnd.rig.cryptonote": ["cryptonote"], "application/vnd.rim.cod": ["cod"], "application/vnd.rn-realmedia": ["rm"], "application/vnd.rn-realmedia-vbr": ["rmvb"], "application/vnd.route66.link66+xml": ["link66"], "application/vnd.sailingtracker.track": ["st"], "application/vnd.seemail": ["see"], "application/vnd.sema": ["sema"], "application/vnd.semd": ["semd"], "application/vnd.semf": ["semf"], "application/vnd.shana.informed.formdata": ["ifm"], "application/vnd.shana.informed.formtemplate": ["itp"], "application/vnd.shana.informed.interchange": ["iif"], "application/vnd.shana.informed.package": ["ipk"], "application/vnd.simtech-mindmapper": ["twd", "twds"], "application/vnd.smaf": ["mmf"], "application/vnd.smart.teacher": ["teacher"], "application/vnd.software602.filler.form+xml": ["fo"], "application/vnd.solent.sdkm+xml": ["sdkm", "sdkd"], "application/vnd.spotfire.dxp": ["dxp"], "application/vnd.spotfire.sfs": ["sfs"], "application/vnd.stardivision.calc": ["sdc"], "application/vnd.stardivision.draw": ["sda"], "application/vnd.stardivision.impress": ["sdd"], "application/vnd.stardivision.math": ["smf"], "application/vnd.stardivision.writer": ["sdw", "vor"], "application/vnd.stardivision.writer-global": ["sgl"], "application/vnd.stepmania.package": ["smzip"], "application/vnd.stepmania.stepchart": ["sm"], "application/vnd.sun.wadl+xml": ["wadl"], "application/vnd.sun.xml.calc": ["sxc"], "application/vnd.sun.xml.calc.template": ["stc"], "application/vnd.sun.xml.draw": ["sxd"], "application/vnd.sun.xml.draw.template": ["std"], "application/vnd.sun.xml.impress": ["sxi"], "application/vnd.sun.xml.impress.template": ["sti"], "application/vnd.sun.xml.math": ["sxm"], "application/vnd.sun.xml.writer": ["sxw"], "application/vnd.sun.xml.writer.global": ["sxg"], "application/vnd.sun.xml.writer.template": ["stw"], "application/vnd.sus-calendar": ["sus", "susp"], "application/vnd.svd": ["svd"], "application/vnd.symbian.install": ["sis", "sisx"], "application/vnd.syncml+xml": ["xsm"], "application/vnd.syncml.dm+wbxml": ["bdm"], "application/vnd.syncml.dm+xml": ["xdm"], "application/vnd.syncml.dmddf+xml": ["ddf"], "application/vnd.tao.intent-module-archive": ["tao"], "application/vnd.tcpdump.pcap": ["pcap", "cap", "dmp"], "application/vnd.tmobile-livetv": ["tmo"], "application/vnd.trid.tpt": ["tpt"], "application/vnd.triscape.mxs": ["mxs"], "application/vnd.trueapp": ["tra"], "application/vnd.ufdl": ["ufd", "ufdl"], "application/vnd.uiq.theme": ["utz"], "application/vnd.umajin": ["umj"], "application/vnd.unity": ["unityweb"], "application/vnd.uoml+xml": ["uoml"], "application/vnd.vcx": ["vcx"], "application/vnd.visio": ["vsd", "vst", "vss", "vsw"], "application/vnd.visionary": ["vis"], "application/vnd.vsf": ["vsf"], "application/vnd.wap.wbxml": ["wbxml"], "application/vnd.wap.wmlc": ["wmlc"], "application/vnd.wap.wmlscriptc": ["wmlsc"], "application/vnd.webturbo": ["wtb"], "application/vnd.wolfram.player": ["nbp"], "application/vnd.wordperfect": ["wpd"], "application/vnd.wqd": ["wqd"], "application/vnd.wt.stf": ["stf"], "application/vnd.xara": ["xar"], "application/vnd.xfdl": ["xfdl"], "application/vnd.yamaha.hv-dic": ["hvd"], "application/vnd.yamaha.hv-script": ["hvs"], "application/vnd.yamaha.hv-voice": ["hvp"], "application/vnd.yamaha.openscoreformat": ["osf"], "application/vnd.yamaha.openscoreformat.osfpvg+xml": ["osfpvg"], "application/vnd.yamaha.smaf-audio": ["saf"], "application/vnd.yamaha.smaf-phrase": ["spf"], "application/vnd.yellowriver-custom-menu": ["cmp"], "application/vnd.zul": ["zir", "zirz"], "application/vnd.zzazz.deck+xml": ["zaz"], "application/x-7z-compressed": ["7z"], "application/x-abiword": ["abw"], "application/x-ace-compressed": ["ace"], "application/x-apple-diskimage": ["*dmg"], "application/x-arj": ["arj"], "application/x-authorware-bin": ["aab", "x32", "u32", "vox"], "application/x-authorware-map": ["aam"], "application/x-authorware-seg": ["aas"], "application/x-bcpio": ["bcpio"], "application/x-bdoc": ["*bdoc"], "application/x-bittorrent": ["torrent"], "application/x-blorb": ["blb", "blorb"], "application/x-bzip": ["bz"], "application/x-bzip2": ["bz2", "boz"], "application/x-cbr": ["cbr", "cba", "cbt", "cbz", "cb7"], "application/x-cdlink": ["vcd"], "application/x-cfs-compressed": ["cfs"], "application/x-chat": ["chat"], "application/x-chess-pgn": ["pgn"], "application/x-chrome-extension": ["crx"], "application/x-cocoa": ["cco"], "application/x-conference": ["nsc"], "application/x-cpio": ["cpio"], "application/x-csh": ["csh"], "application/x-debian-package": ["*deb", "udeb"], "application/x-dgc-compressed": ["dgc"], "application/x-director": ["dir", "dcr", "dxr", "cst", "cct", "cxt", "w3d", "fgd", "swa"], "application/x-doom": ["wad"], "application/x-dtbncx+xml": ["ncx"], "application/x-dtbook+xml": ["dtb"], "application/x-dtbresource+xml": ["res"], "application/x-dvi": ["dvi"], "application/x-envoy": ["evy"], "application/x-eva": ["eva"], "application/x-font-bdf": ["bdf"], "application/x-font-ghostscript": ["gsf"], "application/x-font-linux-psf": ["psf"], "application/x-font-pcf": ["pcf"], "application/x-font-snf": ["snf"], "application/x-font-type1": ["pfa", "pfb", "pfm", "afm"], "application/x-freearc": ["arc"], "application/x-futuresplash": ["spl"], "application/x-gca-compressed": ["gca"], "application/x-glulx": ["ulx"], "application/x-gnumeric": ["gnumeric"], "application/x-gramps-xml": ["gramps"], "application/x-gtar": ["gtar"], "application/x-hdf": ["hdf"], "application/x-httpd-php": ["php"], "application/x-install-instructions": ["install"], "application/x-iso9660-image": ["*iso"], "application/x-iwork-keynote-sffkey": ["*key"], "application/x-iwork-numbers-sffnumbers": ["*numbers"], "application/x-iwork-pages-sffpages": ["*pages"], "application/x-java-archive-diff": ["jardiff"], "application/x-java-jnlp-file": ["jnlp"], "application/x-keepass2": ["kdbx"], "application/x-latex": ["latex"], "application/x-lua-bytecode": ["luac"], "application/x-lzh-compressed": ["lzh", "lha"], "application/x-makeself": ["run"], "application/x-mie": ["mie"], "application/x-mobipocket-ebook": ["prc", "mobi"], "application/x-ms-application": ["application"], "application/x-ms-shortcut": ["lnk"], "application/x-ms-wmd": ["wmd"], "application/x-ms-wmz": ["wmz"], "application/x-ms-xbap": ["xbap"], "application/x-msaccess": ["mdb"], "application/x-msbinder": ["obd"], "application/x-mscardfile": ["crd"], "application/x-msclip": ["clp"], "application/x-msdos-program": ["*exe"], "application/x-msdownload": ["*exe", "*dll", "com", "bat", "*msi"], "application/x-msmediaview": ["mvb", "m13", "m14"], "application/x-msmetafile": ["*wmf", "*wmz", "*emf", "emz"], "application/x-msmoney": ["mny"], "application/x-mspublisher": ["pub"], "application/x-msschedule": ["scd"], "application/x-msterminal": ["trm"], "application/x-mswrite": ["wri"], "application/x-netcdf": ["nc", "cdf"], "application/x-ns-proxy-autoconfig": ["pac"], "application/x-nzb": ["nzb"], "application/x-perl": ["pl", "pm"], "application/x-pilot": ["*prc", "*pdb"], "application/x-pkcs12": ["p12", "pfx"], "application/x-pkcs7-certificates": ["p7b", "spc"], "application/x-pkcs7-certreqresp": ["p7r"], "application/x-rar-compressed": ["*rar"], "application/x-redhat-package-manager": ["rpm"], "application/x-research-info-systems": ["ris"], "application/x-sea": ["sea"], "application/x-sh": ["sh"], "application/x-shar": ["shar"], "application/x-shockwave-flash": ["swf"], "application/x-silverlight-app": ["xap"], "application/x-sql": ["sql"], "application/x-stuffit": ["sit"], "application/x-stuffitx": ["sitx"], "application/x-subrip": ["srt"], "application/x-sv4cpio": ["sv4cpio"], "application/x-sv4crc": ["sv4crc"], "application/x-t3vm-image": ["t3"], "application/x-tads": ["gam"], "application/x-tar": ["tar"], "application/x-tcl": ["tcl", "tk"], "application/x-tex": ["tex"], "application/x-tex-tfm": ["tfm"], "application/x-texinfo": ["texinfo", "texi"], "application/x-tgif": ["*obj"], "application/x-ustar": ["ustar"], "application/x-virtualbox-hdd": ["hdd"], "application/x-virtualbox-ova": ["ova"], "application/x-virtualbox-ovf": ["ovf"], "application/x-virtualbox-vbox": ["vbox"], "application/x-virtualbox-vbox-extpack": ["vbox-extpack"], "application/x-virtualbox-vdi": ["vdi"], "application/x-virtualbox-vhd": ["vhd"], "application/x-virtualbox-vmdk": ["vmdk"], "application/x-wais-source": ["src"], "application/x-web-app-manifest+json": ["webapp"], "application/x-x509-ca-cert": ["der", "crt", "pem"], "application/x-xfig": ["fig"], "application/x-xliff+xml": ["*xlf"], "application/x-xpinstall": ["xpi"], "application/x-xz": ["xz"], "application/x-zmachine": ["z1", "z2", "z3", "z4", "z5", "z6", "z7", "z8"], "audio/vnd.dece.audio": ["uva", "uvva"], "audio/vnd.digital-winds": ["eol"], "audio/vnd.dra": ["dra"], "audio/vnd.dts": ["dts"], "audio/vnd.dts.hd": ["dtshd"], "audio/vnd.lucent.voice": ["lvp"], "audio/vnd.ms-playready.media.pya": ["pya"], "audio/vnd.nuera.ecelp4800": ["ecelp4800"], "audio/vnd.nuera.ecelp7470": ["ecelp7470"], "audio/vnd.nuera.ecelp9600": ["ecelp9600"], "audio/vnd.rip": ["rip"], "audio/x-aac": ["aac"], "audio/x-aiff": ["aif", "aiff", "aifc"], "audio/x-caf": ["caf"], "audio/x-flac": ["flac"], "audio/x-m4a": ["*m4a"], "audio/x-matroska": ["mka"], "audio/x-mpegurl": ["m3u"], "audio/x-ms-wax": ["wax"], "audio/x-ms-wma": ["wma"], "audio/x-pn-realaudio": ["ram", "ra"], "audio/x-pn-realaudio-plugin": ["rmp"], "audio/x-realaudio": ["*ra"], "audio/x-wav": ["*wav"], "chemical/x-cdx": ["cdx"], "chemical/x-cif": ["cif"], "chemical/x-cmdf": ["cmdf"], "chemical/x-cml": ["cml"], "chemical/x-csml": ["csml"], "chemical/x-xyz": ["xyz"], "image/prs.btif": ["btif"], "image/prs.pti": ["pti"], "image/vnd.adobe.photoshop": ["psd"], "image/vnd.airzip.accelerator.azv": ["azv"], "image/vnd.dece.graphic": ["uvi", "uvvi", "uvg", "uvvg"], "image/vnd.djvu": ["djvu", "djv"], "image/vnd.dvb.subtitle": ["*sub"], "image/vnd.dwg": ["dwg"], "image/vnd.dxf": ["dxf"], "image/vnd.fastbidsheet": ["fbs"], "image/vnd.fpx": ["fpx"], "image/vnd.fst": ["fst"], "image/vnd.fujixerox.edmics-mmr": ["mmr"], "image/vnd.fujixerox.edmics-rlc": ["rlc"], "image/vnd.microsoft.icon": ["ico"], "image/vnd.ms-dds": ["dds"], "image/vnd.ms-modi": ["mdi"], "image/vnd.ms-photo": ["wdp"], "image/vnd.net-fpx": ["npx"], "image/vnd.pco.b16": ["b16"], "image/vnd.tencent.tap": ["tap"], "image/vnd.valve.source.texture": ["vtf"], "image/vnd.wap.wbmp": ["wbmp"], "image/vnd.xiff": ["xif"], "image/vnd.zbrush.pcx": ["pcx"], "image/x-3ds": ["3ds"], "image/x-cmu-raster": ["ras"], "image/x-cmx": ["cmx"], "image/x-freehand": ["fh", "fhc", "fh4", "fh5", "fh7"], "image/x-icon": ["*ico"], "image/x-jng": ["jng"], "image/x-mrsid-image": ["sid"], "image/x-ms-bmp": ["*bmp"], "image/x-pcx": ["*pcx"], "image/x-pict": ["pic", "pct"], "image/x-portable-anymap": ["pnm"], "image/x-portable-bitmap": ["pbm"], "image/x-portable-graymap": ["pgm"], "image/x-portable-pixmap": ["ppm"], "image/x-rgb": ["rgb"], "image/x-tga": ["tga"], "image/x-xbitmap": ["xbm"], "image/x-xpixmap": ["xpm"], "image/x-xwindowdump": ["xwd"], "message/vnd.wfa.wsc": ["wsc"], "model/vnd.collada+xml": ["dae"], "model/vnd.dwf": ["dwf"], "model/vnd.gdl": ["gdl"], "model/vnd.gtw": ["gtw"], "model/vnd.mts": ["mts"], "model/vnd.opengex": ["ogex"], "model/vnd.parasolid.transmit.binary": ["x_b"], "model/vnd.parasolid.transmit.text": ["x_t"], "model/vnd.sap.vds": ["vds"], "model/vnd.usdz+zip": ["usdz"], "model/vnd.valve.source.compiled-map": ["bsp"], "model/vnd.vtu": ["vtu"], "text/prs.lines.tag": ["dsc"], "text/vnd.curl": ["curl"], "text/vnd.curl.dcurl": ["dcurl"], "text/vnd.curl.mcurl": ["mcurl"], "text/vnd.curl.scurl": ["scurl"], "text/vnd.dvb.subtitle": ["sub"], "text/vnd.fly": ["fly"], "text/vnd.fmi.flexstor": ["flx"], "text/vnd.graphviz": ["gv"], "text/vnd.in3d.3dml": ["3dml"], "text/vnd.in3d.spot": ["spot"], "text/vnd.sun.j2me.app-descriptor": ["jad"], "text/vnd.wap.wml": ["wml"], "text/vnd.wap.wmlscript": ["wmls"], "text/x-asm": ["s", "asm"], "text/x-c": ["c", "cc", "cxx", "cpp", "h", "hh", "dic"], "text/x-component": ["htc"], "text/x-fortran": ["f", "for", "f77", "f90"], "text/x-handlebars-template": ["hbs"], "text/x-java-source": ["java"], "text/x-lua": ["lua"], "text/x-markdown": ["mkd"], "text/x-nfo": ["nfo"], "text/x-opml": ["opml"], "text/x-org": ["*org"], "text/x-pascal": ["p", "pas"], "text/x-processing": ["pde"], "text/x-sass": ["sass"], "text/x-scss": ["scss"], "text/x-setext": ["etx"], "text/x-sfv": ["sfv"], "text/x-suse-ymp": ["ymp"], "text/x-uuencode": ["uu"], "text/x-vcalendar": ["vcs"], "text/x-vcard": ["vcf"], "video/vnd.dece.hd": ["uvh", "uvvh"], "video/vnd.dece.mobile": ["uvm", "uvvm"], "video/vnd.dece.pd": ["uvp", "uvvp"], "video/vnd.dece.sd": ["uvs", "uvvs"], "video/vnd.dece.video": ["uvv", "uvvv"], "video/vnd.dvb.file": ["dvb"], "video/vnd.fvt": ["fvt"], "video/vnd.mpegurl": ["mxu", "m4u"], "video/vnd.ms-playready.media.pyv": ["pyv"], "video/vnd.uvvu.mp4": ["uvu", "uvvu"], "video/vnd.vivo": ["viv"], "video/x-f4v": ["f4v"], "video/x-fli": ["fli"], "video/x-flv": ["flv"], "video/x-m4v": ["m4v"], "video/x-matroska": ["mkv", "mk3d", "mks"], "video/x-mng": ["mng"], "video/x-ms-asf": ["asf", "asx"], "video/x-ms-vob": ["vob"], "video/x-ms-wm": ["wm"], "video/x-ms-wmv": ["wmv"], "video/x-ms-wmx": ["wmx"], "video/x-ms-wvx": ["wvx"], "video/x-msvideo": ["avi"], "video/x-sgi-movie": ["movie"], "video/x-smv": ["smv"], "x-conference/x-cooltalk": ["ice"] };
});

// node_modules/mime/index.js
var qt = E((Mo, Ii) => {
  "use strict";
  var Ln = Ai();
  Ii.exports = new Ln(Ti(), Ni());
});

// node_modules/yocto-queue/index.js
var qi = E((Do, Si) => {
  var Pt = class {
    static {
      d(this, "Node");
    }
    /// value;
    /// next;
    constructor(e) {
      this.value = e, this.next = void 0;
    }
  }, jt = class {
    static {
      d(this, "Queue");
    }
    // TODO: Use private class fields when targeting Node.js 12.
    // #_head;
    // #_tail;
    // #_size;
    constructor() {
      this.clear();
    }
    enqueue(e) {
      let t = new Pt(e);
      this._head ? (this._tail.next = t, this._tail = t) : (this._head = t, this._tail = t), this._size++;
    }
    dequeue() {
      let e = this._head;
      if (e)
        return this._head = this._head.next, this._size--, e.value;
    }
    clear() {
      this._head = void 0, this._tail = void 0, this._size = 0;
    }
    get size() {
      return this._size;
    }
    *[Symbol.iterator]() {
      let e = this._head;
      for (; e; )
        yield e.value, e = e.next;
    }
  };
  Si.exports = jt;
});

// node_modules/p-limit/index.js
var Ot = E((Bo, Pi) => {
  "use strict";
  var kn = qi(), Un = /* @__PURE__ */ d((r) => {
    if (!((Number.isInteger(r) || r === 1 / 0) && r > 0))
      throw new TypeError("Expected `concurrency` to be a number from 1 and up");
    let e = new kn(), t = 0, i = /* @__PURE__ */ d(() => {
      t--, e.size > 0 && e.dequeue()();
    }, "next"), n = /* @__PURE__ */ d(async (a, o, ...l) => {
      t++;
      let p = (async () => a(...l))();
      o(p);
      try {
        await p;
      } catch {
      }
      i();
    }, "run"), s = /* @__PURE__ */ d((a, o, ...l) => {
      e.enqueue(n.bind(null, a, o, ...l)), (async () => (await Promise.resolve(), t < r && e.size > 0 && e.dequeue()()))();
    }, "enqueue"), c = /* @__PURE__ */ d((a, ...o) => new Promise((l) => {
      s(a, l, ...o);
    }), "generator");
    return Object.defineProperties(c, {
      activeCount: {
        get: /* @__PURE__ */ d(() => t, "get")
      },
      pendingCount: {
        get: /* @__PURE__ */ d(() => e.size, "get")
      },
      clearQueue: {
        value: /* @__PURE__ */ d(() => {
          e.clear();
        }, "value")
      }
    }), c;
  }, "pLimit");
  Pi.exports = Un;
});

// node_modules/retry/lib/retry_operation.js
var Oi = E((zo, ji) => {
  function M(r, e) {
    typeof e == "boolean" && (e = { forever: e }), this._originalTimeouts = JSON.parse(JSON.stringify(r)), this._timeouts = r, this._options = e || {}, this._maxRetryTime = e && e.maxRetryTime || 1 / 0, this._fn = null, this._errors = [], this._attempts = 1, this._operationTimeout = null, this._operationTimeoutCb = null, this._timeout = null, this._operationStart = null, this._timer = null, this._options.forever && (this._cachedTimeouts = this._timeouts.slice(0));
  }
  d(M, "RetryOperation");
  ji.exports = M;
  M.prototype.reset = function() {
    this._attempts = 1, this._timeouts = this._originalTimeouts.slice(0);
  };
  M.prototype.stop = function() {
    this._timeout && clearTimeout(this._timeout), this._timer && clearTimeout(this._timer), this._timeouts = [], this._cachedTimeouts = null;
  };
  M.prototype.retry = function(r) {
    if (this._timeout && clearTimeout(this._timeout), !r)
      return !1;
    var e = (/* @__PURE__ */ new Date()).getTime();
    if (r && e - this._operationStart >= this._maxRetryTime)
      return this._errors.push(r), this._errors.unshift(new Error("RetryOperation timeout occurred")), !1;
    this._errors.push(r);
    var t = this._timeouts.shift();
    if (t === void 0)
      if (this._cachedTimeouts)
        this._errors.splice(0, this._errors.length - 1), t = this._cachedTimeouts.slice(-1);
      else
        return !1;
    var i = this;
    return this._timer = setTimeout(function() {
      i._attempts++, i._operationTimeoutCb && (i._timeout = setTimeout(function() {
        i._operationTimeoutCb(i._attempts);
      }, i._operationTimeout), i._options.unref && i._timeout.unref()), i._fn(i._attempts);
    }, t), this._options.unref && this._timer.unref(), !0;
  };
  M.prototype.attempt = function(r, e) {
    this._fn = r, e && (e.timeout && (this._operationTimeout = e.timeout), e.cb && (this._operationTimeoutCb = e.cb));
    var t = this;
    this._operationTimeoutCb && (this._timeout = setTimeout(function() {
      t._operationTimeoutCb();
    }, t._operationTimeout)), this._operationStart = (/* @__PURE__ */ new Date()).getTime(), this._fn(this._attempts);
  };
  M.prototype.try = function(r) {
    console.log("Using RetryOperation.try() is deprecated"), this.attempt(r);
  };
  M.prototype.start = function(r) {
    console.log("Using RetryOperation.start() is deprecated"), this.attempt(r);
  };
  M.prototype.start = M.prototype.try;
  M.prototype.errors = function() {
    return this._errors;
  };
  M.prototype.attempts = function() {
    return this._attempts;
  };
  M.prototype.mainError = function() {
    if (this._errors.length === 0)
      return null;
    for (var r = {}, e = null, t = 0, i = 0; i < this._errors.length; i++) {
      var n = this._errors[i], s = n.message, c = (r[s] || 0) + 1;
      r[s] = c, c >= t && (e = n, t = c);
    }
    return e;
  };
});

// node_modules/retry/lib/retry.js
var Ci = E((ue) => {
  var Mn = Oi();
  ue.operation = function(r) {
    var e = ue.timeouts(r);
    return new Mn(e, {
      forever: r && (r.forever || r.retries === 1 / 0),
      unref: r && r.unref,
      maxRetryTime: r && r.maxRetryTime
    });
  };
  ue.timeouts = function(r) {
    if (r instanceof Array)
      return [].concat(r);
    var e = {
      retries: 10,
      factor: 2,
      minTimeout: 1 * 1e3,
      maxTimeout: 1 / 0,
      randomize: !1
    };
    for (var t in r)
      e[t] = r[t];
    if (e.minTimeout > e.maxTimeout)
      throw new Error("minTimeout is greater than maxTimeout");
    for (var i = [], n = 0; n < e.retries; n++)
      i.push(this.createTimeout(n, e));
    return r && r.forever && !i.length && i.push(this.createTimeout(n, e)), i.sort(function(s, c) {
      return s - c;
    }), i;
  };
  ue.createTimeout = function(r, e) {
    var t = e.randomize ? Math.random() + 1 : 1, i = Math.round(t * Math.max(e.minTimeout, 1) * Math.pow(e.factor, r));
    return i = Math.min(i, e.maxTimeout), i;
  };
  ue.wrap = function(r, e, t) {
    if (e instanceof Array && (t = e, e = null), !t) {
      t = [];
      for (var i in r)
        typeof r[i] == "function" && t.push(i);
    }
    for (var n = 0; n < t.length; n++) {
      var s = t[n], c = r[s];
      r[s] = (/* @__PURE__ */ d(function(o) {
        var l = ue.operation(e), p = Array.prototype.slice.call(arguments, 1), u = p.pop();
        p.push(function(f) {
          l.retry(f) || (f && (arguments[0] = l.mainError()), u.apply(this, arguments));
        }), l.attempt(function() {
          o.apply(r, p);
        });
      }, "retryWrapper")).bind(r, c), r[s].options = e;
    }
  };
});

// node_modules/retry/index.js
var ki = E((Ko, Li) => {
  Li.exports = Ci();
});

// node_modules/async-retry/lib/index.js
var Ue = E((Wo, Ui) => {
  var Dn = ki();
  function Fn(r, e) {
    function t(i, n) {
      var s = e || {}, c;
      "randomize" in s || (s.randomize = !0), c = Dn.operation(s);
      function a(p) {
        n(p || new Error("Aborted"));
      }
      d(a, "bail");
      function o(p, u) {
        if (p.bail) {
          a(p);
          return;
        }
        c.retry(p) ? s.onRetry && s.onRetry(p, u) : n(c.mainError());
      }
      d(o, "onError");
      function l(p) {
        var u;
        try {
          u = r(a, p);
        } catch (f) {
          o(f, p);
          return;
        }
        Promise.resolve(u).then(i).catch(/* @__PURE__ */ d(function(m) {
          o(m, p);
        }, "catchIt"));
      }
      d(l, "runAttempt"), c.attempt(l);
    }
    return d(t, "run"), new Promise(t);
  }
  d(Fn, "retry");
  Ui.exports = Fn;
});

// node_modules/fast-xml-parser/src/util.js
var pt = E((Z) => {
  "use strict";
  var yr = ":A-Za-z_\\u00C0-\\u00D6\\u00D8-\\u00F6\\u00F8-\\u02FF\\u0370-\\u037D\\u037F-\\u1FFF\\u200C-\\u200D\\u2070-\\u218F\\u2C00-\\u2FEF\\u3001-\\uD7FF\\uF900-\\uFDCF\\uFDF0-\\uFFFD", fs = yr + "\\-.\\d\\u00B7\\u0300-\\u036F\\u203F-\\u2040", vr = "[" + yr + "][" + fs + "]*", ms = new RegExp("^" + vr + "$"), hs = /* @__PURE__ */ d(function(r, e) {
    let t = [], i = e.exec(r);
    for (; i; ) {
      let n = [];
      n.startIndex = e.lastIndex - i[0].length;
      let s = i.length;
      for (let c = 0; c < s; c++)
        n.push(i[c]);
      t.push(n), i = e.exec(r);
    }
    return t;
  }, "getAllMatches"), gs = /* @__PURE__ */ d(function(r) {
    let e = ms.exec(r);
    return !(e === null || typeof e > "u");
  }, "isName");
  Z.isExist = function(r) {
    return typeof r < "u";
  };
  Z.isEmptyObject = function(r) {
    return Object.keys(r).length === 0;
  };
  Z.merge = function(r, e, t) {
    if (e) {
      let i = Object.keys(e), n = i.length;
      for (let s = 0; s < n; s++)
        t === "strict" ? r[i[s]] = [e[i[s]]] : r[i[s]] = e[i[s]];
    }
  };
  Z.getValue = function(r) {
    return Z.isExist(r) ? r : "";
  };
  Z.isName = gs;
  Z.getAllMatches = hs;
  Z.nameRegexp = vr;
});

// node_modules/fast-xml-parser/src/validator.js
var Vt = E((_r) => {
  "use strict";
  var zt = pt(), xs = {
    allowBooleanAttributes: !1,
    //A tag can have attributes without any value
    unpairedTags: []
  };
  _r.validate = function(r, e) {
    e = Object.assign({}, xs, e);
    let t = [], i = !1, n = !1;
    r[0] === "\uFEFF" && (r = r.substr(1));
    for (let s = 0; s < r.length; s++)
      if (r[s] === "<" && r[s + 1] === "?") {
        if (s += 2, s = wr(r, s), s.err) return s;
      } else if (r[s] === "<") {
        let c = s;
        if (s++, r[s] === "!") {
          s = Er(r, s);
          continue;
        } else {
          let a = !1;
          r[s] === "/" && (a = !0, s++);
          let o = "";
          for (; s < r.length && r[s] !== ">" && r[s] !== " " && r[s] !== "	" && r[s] !== `
` && r[s] !== "\r"; s++)
            o += r[s];
          if (o = o.trim(), o[o.length - 1] === "/" && (o = o.substring(0, o.length - 1), s--), !Ts(o)) {
            let u;
            return o.trim().length === 0 ? u = "Invalid space after '<'." : u = "Tag '" + o + "' is an invalid name.", R("InvalidTag", u, P(r, s));
          }
          let l = bs(r, s);
          if (l === !1)
            return R("InvalidAttr", "Attributes for '" + o + "' have open quote.", P(r, s));
          let p = l.value;
          if (s = l.index, p[p.length - 1] === "/") {
            let u = s - p.length;
            p = p.substring(0, p.length - 1);
            let f = Ar(p, e);
            if (f === !0)
              i = !0;
            else
              return R(f.err.code, f.err.msg, P(r, u + f.err.line));
          } else if (a)
            if (l.tagClosed) {
              if (p.trim().length > 0)
                return R("InvalidTag", "Closing tag '" + o + "' can't have attributes or invalid starting.", P(r, c));
              if (t.length === 0)
                return R("InvalidTag", "Closing tag '" + o + "' has not been opened.", P(r, c));
              {
                let u = t.pop();
                if (o !== u.tagName) {
                  let f = P(r, u.tagStartPos);
                  return R(
                    "InvalidTag",
                    "Expected closing tag '" + u.tagName + "' (opened in line " + f.line + ", col " + f.col + ") instead of closing tag '" + o + "'.",
                    P(r, c)
                  );
                }
                t.length == 0 && (n = !0);
              }
            } else return R("InvalidTag", "Closing tag '" + o + "' doesn't have proper closing.", P(r, s));
          else {
            let u = Ar(p, e);
            if (u !== !0)
              return R(u.err.code, u.err.msg, P(r, s - p.length + u.err.line));
            if (n === !0)
              return R("InvalidXml", "Multiple possible root nodes found.", P(r, s));
            e.unpairedTags.indexOf(o) !== -1 || t.push({ tagName: o, tagStartPos: c }), i = !0;
          }
          for (s++; s < r.length; s++)
            if (r[s] === "<")
              if (r[s + 1] === "!") {
                s++, s = Er(r, s);
                continue;
              } else if (r[s + 1] === "?") {
                if (s = wr(r, ++s), s.err) return s;
              } else
                break;
            else if (r[s] === "&") {
              let u = As(r, s);
              if (u == -1)
                return R("InvalidChar", "char '&' is not expected.", P(r, s));
              s = u;
            } else if (n === !0 && !br(r[s]))
              return R("InvalidXml", "Extra text at the end", P(r, s));
          r[s] === "<" && s--;
        }
      } else {
        if (br(r[s]))
          continue;
        return R("InvalidChar", "char '" + r[s] + "' is not expected.", P(r, s));
      }
    if (i) {
      if (t.length == 1)
        return R("InvalidTag", "Unclosed tag '" + t[0].tagName + "'.", P(r, t[0].tagStartPos));
      if (t.length > 0)
        return R("InvalidXml", "Invalid '" + JSON.stringify(t.map((s) => s.tagName), null, 4).replace(/\r?\n/g, "") + "' found.", { line: 1, col: 1 });
    } else return R("InvalidXml", "Start tag expected.", 1);
    return !0;
  };
  function br(r) {
    return r === " " || r === "	" || r === `
` || r === "\r";
  }
  d(br, "isWhiteSpace");
  function wr(r, e) {
    let t = e;
    for (; e < r.length; e++)
      if (r[e] == "?" || r[e] == " ") {
        let i = r.substr(t, e - t);
        if (e > 5 && i === "xml")
          return R("InvalidXml", "XML declaration allowed only at the start of the document.", P(r, e));
        if (r[e] == "?" && r[e + 1] == ">") {
          e++;
          break;
        } else
          continue;
      }
    return e;
  }
  d(wr, "readPI");
  function Er(r, e) {
    if (r.length > e + 5 && r[e + 1] === "-" && r[e + 2] === "-") {
      for (e += 3; e < r.length; e++)
        if (r[e] === "-" && r[e + 1] === "-" && r[e + 2] === ">") {
          e += 2;
          break;
        }
    } else if (r.length > e + 8 && r[e + 1] === "D" && r[e + 2] === "O" && r[e + 3] === "C" && r[e + 4] === "T" && r[e + 5] === "Y" && r[e + 6] === "P" && r[e + 7] === "E") {
      let t = 1;
      for (e += 8; e < r.length; e++)
        if (r[e] === "<")
          t++;
        else if (r[e] === ">" && (t--, t === 0))
          break;
    } else if (r.length > e + 9 && r[e + 1] === "[" && r[e + 2] === "C" && r[e + 3] === "D" && r[e + 4] === "A" && r[e + 5] === "T" && r[e + 6] === "A" && r[e + 7] === "[") {
      for (e += 8; e < r.length; e++)
        if (r[e] === "]" && r[e + 1] === "]" && r[e + 2] === ">") {
          e += 2;
          break;
        }
    }
    return e;
  }
  d(Er, "readCommentAndCDATA");
  var ys = '"', vs = "'";
  function bs(r, e) {
    let t = "", i = "", n = !1;
    for (; e < r.length; e++) {
      if (r[e] === ys || r[e] === vs)
        i === "" ? i = r[e] : i !== r[e] || (i = "");
      else if (r[e] === ">" && i === "") {
        n = !0;
        break;
      }
      t += r[e];
    }
    return i !== "" ? !1 : {
      value: t,
      index: e,
      tagClosed: n
    };
  }
  d(bs, "readAttributeStr");
  var ws = new RegExp(`(\\s*)([^\\s=]+)(\\s*=)?(\\s*(['"])(([\\s\\S])*?)\\5)?`, "g");
  function Ar(r, e) {
    let t = zt.getAllMatches(r, ws), i = {};
    for (let n = 0; n < t.length; n++) {
      if (t[n][1].length === 0)
        return R("InvalidAttr", "Attribute '" + t[n][2] + "' has no space in starting.", Be(t[n]));
      if (t[n][3] !== void 0 && t[n][4] === void 0)
        return R("InvalidAttr", "Attribute '" + t[n][2] + "' is without value.", Be(t[n]));
      if (t[n][3] === void 0 && !e.allowBooleanAttributes)
        return R("InvalidAttr", "boolean attribute '" + t[n][2] + "' is not allowed.", Be(t[n]));
      let s = t[n][2];
      if (!_s(s))
        return R("InvalidAttr", "Attribute '" + s + "' is an invalid name.", Be(t[n]));
      if (!i.hasOwnProperty(s))
        i[s] = 1;
      else
        return R("InvalidAttr", "Attribute '" + s + "' is repeated.", Be(t[n]));
    }
    return !0;
  }
  d(Ar, "validateAttributeString");
  function Es(r, e) {
    let t = /\d/;
    for (r[e] === "x" && (e++, t = /[\da-fA-F]/); e < r.length; e++) {
      if (r[e] === ";")
        return e;
      if (!r[e].match(t))
        break;
    }
    return -1;
  }
  d(Es, "validateNumberAmpersand");
  function As(r, e) {
    if (e++, r[e] === ";")
      return -1;
    if (r[e] === "#")
      return e++, Es(r, e);
    let t = 0;
    for (; e < r.length; e++, t++)
      if (!(r[e].match(/\w/) && t < 20)) {
        if (r[e] === ";")
          break;
        return -1;
      }
    return e;
  }
  d(As, "validateAmpersand");
  function R(r, e, t) {
    return {
      err: {
        code: r,
        msg: e,
        line: t.line || t,
        col: t.col
      }
    };
  }
  d(R, "getErrorObject");
  function _s(r) {
    return zt.isName(r);
  }
  d(_s, "validateAttrName");
  function Ts(r) {
    return zt.isName(r);
  }
  d(Ts, "validateTagName");
  function P(r, e) {
    let t = r.substring(0, e).split(/\r?\n/);
    return {
      line: t.length,
      // column number is last line's length + 1, because column numbering starts at 1:
      col: t[t.length - 1].length + 1
    };
  }
  d(P, "getLineNumberForPosition");
  function Be(r) {
    return r.startIndex + r[1].length;
  }
  d(Be, "getPositionFromMatch");
});

// node_modules/fast-xml-parser/src/xmlparser/OptionsBuilder.js
var Rr = E(($t) => {
  var Tr = {
    preserveOrder: !1,
    attributeNamePrefix: "@_",
    attributesGroupName: !1,
    textNodeName: "#text",
    ignoreAttributes: !0,
    removeNSPrefix: !1,
    // remove NS from tag name or attribute name if true
    allowBooleanAttributes: !1,
    //a tag can have attributes without any value
    //ignoreRootElement : false,
    parseTagValue: !0,
    parseAttributeValue: !1,
    trimValues: !0,
    //Trim string values of tag and attributes
    cdataPropName: !1,
    numberParseOptions: {
      hex: !0,
      leadingZeros: !0,
      eNotation: !0
    },
    tagValueProcessor: /* @__PURE__ */ d(function(r, e) {
      return e;
    }, "tagValueProcessor"),
    attributeValueProcessor: /* @__PURE__ */ d(function(r, e) {
      return e;
    }, "attributeValueProcessor"),
    stopNodes: [],
    //nested tags will not be parsed even for errors
    alwaysCreateTextNode: !1,
    isArray: /* @__PURE__ */ d(() => !1, "isArray"),
    commentPropName: !1,
    unpairedTags: [],
    processEntities: !0,
    htmlEntities: !1,
    ignoreDeclaration: !1,
    ignorePiTags: !1,
    transformTagName: !1,
    transformAttributeName: !1,
    updateTag: /* @__PURE__ */ d(function(r, e, t) {
      return r;
    }, "updateTag")
    // skipEmptyListItem: false
  }, Rs = /* @__PURE__ */ d(function(r) {
    return Object.assign({}, Tr, r);
  }, "buildOptions");
  $t.buildOptions = Rs;
  $t.defaultOptions = Tr;
});

// node_modules/fast-xml-parser/src/xmlparser/xmlNode.js
var Ir = E((gl, Nr) => {
  "use strict";
  var Ht = class {
    static {
      d(this, "XmlNode");
    }
    constructor(e) {
      this.tagname = e, this.child = [], this[":@"] = {};
    }
    add(e, t) {
      e === "__proto__" && (e = "#__proto__"), this.child.push({ [e]: t });
    }
    addChild(e) {
      e.tagname === "__proto__" && (e.tagname = "#__proto__"), e[":@"] && Object.keys(e[":@"]).length > 0 ? this.child.push({ [e.tagname]: e.child, ":@": e[":@"] }) : this.child.push({ [e.tagname]: e.child });
    }
  };
  Nr.exports = Ht;
});

// node_modules/fast-xml-parser/src/xmlparser/DocTypeReader.js
var qr = E((yl, Sr) => {
  var Ns = pt();
  function Is(r, e) {
    let t = {};
    if (r[e + 3] === "O" && r[e + 4] === "C" && r[e + 5] === "T" && r[e + 6] === "Y" && r[e + 7] === "P" && r[e + 8] === "E") {
      e = e + 9;
      let i = 1, n = !1, s = !1, c = "";
      for (; e < r.length; e++)
        if (r[e] === "<" && !s) {
          if (n && Ps(r, e)) {
            e += 7;
            let a, o;
            [a, o, e] = Ss(r, e + 1), o.indexOf("&") === -1 && (t[Ls(a)] = {
              regx: RegExp(`&${a};`, "g"),
              val: o
            });
          } else if (n && js(r, e)) e += 8;
          else if (n && Os(r, e)) e += 8;
          else if (n && Cs(r, e)) e += 9;
          else if (qs) s = !0;
          else throw new Error("Invalid DOCTYPE");
          i++, c = "";
        } else if (r[e] === ">") {
          if (s ? r[e - 1] === "-" && r[e - 2] === "-" && (s = !1, i--) : i--, i === 0)
            break;
        } else r[e] === "[" ? n = !0 : c += r[e];
      if (i !== 0)
        throw new Error("Unclosed DOCTYPE");
    } else
      throw new Error("Invalid Tag instead of DOCTYPE");
    return { entities: t, i: e };
  }
  d(Is, "readDocType");
  function Ss(r, e) {
    let t = "";
    for (; e < r.length && r[e] !== "'" && r[e] !== '"'; e++)
      t += r[e];
    if (t = t.trim(), t.indexOf(" ") !== -1) throw new Error("External entites are not supported");
    let i = r[e++], n = "";
    for (; e < r.length && r[e] !== i; e++)
      n += r[e];
    return [t, n, e];
  }
  d(Ss, "readEntityExp");
  function qs(r, e) {
    return r[e + 1] === "!" && r[e + 2] === "-" && r[e + 3] === "-";
  }
  d(qs, "isComment");
  function Ps(r, e) {
    return r[e + 1] === "!" && r[e + 2] === "E" && r[e + 3] === "N" && r[e + 4] === "T" && r[e + 5] === "I" && r[e + 6] === "T" && r[e + 7] === "Y";
  }
  d(Ps, "isEntity");
  function js(r, e) {
    return r[e + 1] === "!" && r[e + 2] === "E" && r[e + 3] === "L" && r[e + 4] === "E" && r[e + 5] === "M" && r[e + 6] === "E" && r[e + 7] === "N" && r[e + 8] === "T";
  }
  d(js, "isElement");
  function Os(r, e) {
    return r[e + 1] === "!" && r[e + 2] === "A" && r[e + 3] === "T" && r[e + 4] === "T" && r[e + 5] === "L" && r[e + 6] === "I" && r[e + 7] === "S" && r[e + 8] === "T";
  }
  d(Os, "isAttlist");
  function Cs(r, e) {
    return r[e + 1] === "!" && r[e + 2] === "N" && r[e + 3] === "O" && r[e + 4] === "T" && r[e + 5] === "A" && r[e + 6] === "T" && r[e + 7] === "I" && r[e + 8] === "O" && r[e + 9] === "N";
  }
  d(Cs, "isNotation");
  function Ls(r) {
    if (Ns.isName(r))
      return r;
    throw new Error(`Invalid entity name ${r}`);
  }
  d(Ls, "validateEntityName");
  Sr.exports = Is;
});

// node_modules/strnum/strnum.js
var jr = E((bl, Pr) => {
  var ks = /^[-+]?0x[a-fA-F0-9]+$/, Us = /^([\-\+])?(0*)([0-9]*(\.[0-9]*)?)$/, Ms = {
    hex: !0,
    // oct: false,
    leadingZeros: !0,
    decimalPoint: ".",
    eNotation: !0
    //skipLike: /regex/
  };
  function Ds(r, e = {}) {
    if (e = Object.assign({}, Ms, e), !r || typeof r != "string") return r;
    let t = r.trim();
    if (e.skipLike !== void 0 && e.skipLike.test(t)) return r;
    if (r === "0") return 0;
    if (e.hex && ks.test(t))
      return Bs(t, 16);
    if (t.search(/[eE]/) !== -1) {
      let i = t.match(/^([-\+])?(0*)([0-9]*(\.[0-9]*)?[eE][-\+]?[0-9]+)$/);
      if (i) {
        if (e.leadingZeros)
          t = (i[1] || "") + i[3];
        else if (!(i[2] === "0" && i[3][0] === "."))
          return r;
        return e.eNotation ? Number(t) : r;
      } else
        return r;
    } else {
      let i = Us.exec(t);
      if (i) {
        let n = i[1], s = i[2], c = Fs(i[3]);
        if (!e.leadingZeros && s.length > 0 && n && t[2] !== ".") return r;
        if (!e.leadingZeros && s.length > 0 && !n && t[1] !== ".") return r;
        if (e.leadingZeros && s === r) return 0;
        {
          let a = Number(t), o = "" + a;
          return o.search(/[eE]/) !== -1 ? e.eNotation ? a : r : t.indexOf(".") !== -1 ? o === "0" && c === "" || o === c || n && o === "-" + c ? a : r : s ? c === o || n + c === o ? a : r : t === o || t === n + o ? a : r;
        }
      } else
        return r;
    }
  }
  d(Ds, "toNumber");
  function Fs(r) {
    return r && r.indexOf(".") !== -1 && (r = r.replace(/0+$/, ""), r === "." ? r = "0" : r[0] === "." ? r = "0" + r : r[r.length - 1] === "." && (r = r.substr(0, r.length - 1))), r;
  }
  d(Fs, "trimZeros");
  function Bs(r, e) {
    if (parseInt) return parseInt(r, e);
    if (Number.parseInt) return Number.parseInt(r, e);
    if (window && window.parseInt) return window.parseInt(r, e);
    throw new Error("parseInt, Number.parseInt, window.parseInt are not supported");
  }
  d(Bs, "parse_int");
  Pr.exports = Ds;
});

// node_modules/fast-xml-parser/src/ignoreAttributes.js
var Kt = E((El, Or) => {
  function Gs(r) {
    return typeof r == "function" ? r : Array.isArray(r) ? (e) => {
      for (let t of r)
        if (typeof t == "string" && e === t || t instanceof RegExp && t.test(e))
          return !0;
    } : () => !1;
  }
  d(Gs, "getIgnoreAttributesFn");
  Or.exports = Gs;
});

// node_modules/fast-xml-parser/src/xmlparser/OrderedObjParser.js
var kr = E((_l, Lr) => {
  "use strict";
  var Cr = pt(), Ge = Ir(), zs = qr(), Vs = jr(), $s = Kt(), Wt = class {
    static {
      d(this, "OrderedObjParser");
    }
    constructor(e) {
      this.options = e, this.currentNode = null, this.tagsNodeStack = [], this.docTypeEntities = {}, this.lastEntities = {
        apos: { regex: /&(apos|#39|#x27);/g, val: "'" },
        gt: { regex: /&(gt|#62|#x3E);/g, val: ">" },
        lt: { regex: /&(lt|#60|#x3C);/g, val: "<" },
        quot: { regex: /&(quot|#34|#x22);/g, val: '"' }
      }, this.ampEntity = { regex: /&(amp|#38|#x26);/g, val: "&" }, this.htmlEntities = {
        space: { regex: /&(nbsp|#160);/g, val: " " },
        // "lt" : { regex: /&(lt|#60);/g, val: "<" },
        // "gt" : { regex: /&(gt|#62);/g, val: ">" },
        // "amp" : { regex: /&(amp|#38);/g, val: "&" },
        // "quot" : { regex: /&(quot|#34);/g, val: "\"" },
        // "apos" : { regex: /&(apos|#39);/g, val: "'" },
        cent: { regex: /&(cent|#162);/g, val: "\xA2" },
        pound: { regex: /&(pound|#163);/g, val: "\xA3" },
        yen: { regex: /&(yen|#165);/g, val: "\xA5" },
        euro: { regex: /&(euro|#8364);/g, val: "\u20AC" },
        copyright: { regex: /&(copy|#169);/g, val: "\xA9" },
        reg: { regex: /&(reg|#174);/g, val: "\xAE" },
        inr: { regex: /&(inr|#8377);/g, val: "\u20B9" },
        num_dec: { regex: /&#([0-9]{1,7});/g, val: /* @__PURE__ */ d((t, i) => String.fromCharCode(Number.parseInt(i, 10)), "val") },
        num_hex: { regex: /&#x([0-9a-fA-F]{1,6});/g, val: /* @__PURE__ */ d((t, i) => String.fromCharCode(Number.parseInt(i, 16)), "val") }
      }, this.addExternalEntities = Hs, this.parseXml = Js, this.parseTextData = Ks, this.resolveNameSpace = Ws, this.buildAttributesMap = Ys, this.isItStopNode = ta, this.replaceEntitiesValue = Zs, this.readStopNodeData = ra, this.saveTextToParentTag = ea, this.addChild = Qs, this.ignoreAttributesFn = $s(this.options.ignoreAttributes);
    }
  };
  function Hs(r) {
    let e = Object.keys(r);
    for (let t = 0; t < e.length; t++) {
      let i = e[t];
      this.lastEntities[i] = {
        regex: new RegExp("&" + i + ";", "g"),
        val: r[i]
      };
    }
  }
  d(Hs, "addExternalEntities");
  function Ks(r, e, t, i, n, s, c) {
    if (r !== void 0 && (this.options.trimValues && !i && (r = r.trim()), r.length > 0)) {
      c || (r = this.replaceEntitiesValue(r));
      let a = this.options.tagValueProcessor(e, r, t, n, s);
      return a == null ? r : typeof a != typeof r || a !== r ? a : this.options.trimValues ? Yt(r, this.options.parseTagValue, this.options.numberParseOptions) : r.trim() === r ? Yt(r, this.options.parseTagValue, this.options.numberParseOptions) : r;
    }
  }
  d(Ks, "parseTextData");
  function Ws(r) {
    if (this.options.removeNSPrefix) {
      let e = r.split(":"), t = r.charAt(0) === "/" ? "/" : "";
      if (e[0] === "xmlns")
        return "";
      e.length === 2 && (r = t + e[1]);
    }
    return r;
  }
  d(Ws, "resolveNameSpace");
  var Xs = new RegExp(`([^\\s=]+)\\s*(=\\s*(['"])([\\s\\S]*?)\\3)?`, "gm");
  function Ys(r, e, t) {
    if (this.options.ignoreAttributes !== !0 && typeof r == "string") {
      let i = Cr.getAllMatches(r, Xs), n = i.length, s = {};
      for (let c = 0; c < n; c++) {
        let a = this.resolveNameSpace(i[c][1]);
        if (this.ignoreAttributesFn(a, e))
          continue;
        let o = i[c][4], l = this.options.attributeNamePrefix + a;
        if (a.length)
          if (this.options.transformAttributeName && (l = this.options.transformAttributeName(l)), l === "__proto__" && (l = "#__proto__"), o !== void 0) {
            this.options.trimValues && (o = o.trim()), o = this.replaceEntitiesValue(o);
            let p = this.options.attributeValueProcessor(a, o, e);
            p == null ? s[l] = o : typeof p != typeof o || p !== o ? s[l] = p : s[l] = Yt(
              o,
              this.options.parseAttributeValue,
              this.options.numberParseOptions
            );
          } else this.options.allowBooleanAttributes && (s[l] = !0);
      }
      if (!Object.keys(s).length)
        return;
      if (this.options.attributesGroupName) {
        let c = {};
        return c[this.options.attributesGroupName] = s, c;
      }
      return s;
    }
  }
  d(Ys, "buildAttributesMap");
  var Js = /* @__PURE__ */ d(function(r) {
    r = r.replace(/\r\n?/g, `
`);
    let e = new Ge("!xml"), t = e, i = "", n = "";
    for (let s = 0; s < r.length; s++)
      if (r[s] === "<")
        if (r[s + 1] === "/") {
          let a = xe(r, ">", s, "Closing Tag is not closed."), o = r.substring(s + 2, a).trim();
          if (this.options.removeNSPrefix) {
            let u = o.indexOf(":");
            u !== -1 && (o = o.substr(u + 1));
          }
          this.options.transformTagName && (o = this.options.transformTagName(o)), t && (i = this.saveTextToParentTag(i, t, n));
          let l = n.substring(n.lastIndexOf(".") + 1);
          if (o && this.options.unpairedTags.indexOf(o) !== -1)
            throw new Error(`Unpaired tag can not be used as closing tag: </${o}>`);
          let p = 0;
          l && this.options.unpairedTags.indexOf(l) !== -1 ? (p = n.lastIndexOf(".", n.lastIndexOf(".") - 1), this.tagsNodeStack.pop()) : p = n.lastIndexOf("."), n = n.substring(0, p), t = this.tagsNodeStack.pop(), i = "", s = a;
        } else if (r[s + 1] === "?") {
          let a = Xt(r, s, !1, "?>");
          if (!a) throw new Error("Pi Tag is not closed.");
          if (i = this.saveTextToParentTag(i, t, n), !(this.options.ignoreDeclaration && a.tagName === "?xml" || this.options.ignorePiTags)) {
            let o = new Ge(a.tagName);
            o.add(this.options.textNodeName, ""), a.tagName !== a.tagExp && a.attrExpPresent && (o[":@"] = this.buildAttributesMap(a.tagExp, n, a.tagName)), this.addChild(t, o, n);
          }
          s = a.closeIndex + 1;
        } else if (r.substr(s + 1, 3) === "!--") {
          let a = xe(r, "-->", s + 4, "Comment is not closed.");
          if (this.options.commentPropName) {
            let o = r.substring(s + 4, a - 2);
            i = this.saveTextToParentTag(i, t, n), t.add(this.options.commentPropName, [{ [this.options.textNodeName]: o }]);
          }
          s = a;
        } else if (r.substr(s + 1, 2) === "!D") {
          let a = zs(r, s);
          this.docTypeEntities = a.entities, s = a.i;
        } else if (r.substr(s + 1, 2) === "![") {
          let a = xe(r, "]]>", s, "CDATA is not closed.") - 2, o = r.substring(s + 9, a);
          i = this.saveTextToParentTag(i, t, n);
          let l = this.parseTextData(o, t.tagname, n, !0, !1, !0, !0);
          l == null && (l = ""), this.options.cdataPropName ? t.add(this.options.cdataPropName, [{ [this.options.textNodeName]: o }]) : t.add(this.options.textNodeName, l), s = a + 2;
        } else {
          let a = Xt(r, s, this.options.removeNSPrefix), o = a.tagName, l = a.rawTagName, p = a.tagExp, u = a.attrExpPresent, f = a.closeIndex;
          this.options.transformTagName && (o = this.options.transformTagName(o)), t && i && t.tagname !== "!xml" && (i = this.saveTextToParentTag(i, t, n, !1));
          let m = t;
          if (m && this.options.unpairedTags.indexOf(m.tagname) !== -1 && (t = this.tagsNodeStack.pop(), n = n.substring(0, n.lastIndexOf("."))), o !== e.tagname && (n += n ? "." + o : o), this.isItStopNode(this.options.stopNodes, n, o)) {
            let h = "";
            if (p.length > 0 && p.lastIndexOf("/") === p.length - 1)
              o[o.length - 1] === "/" ? (o = o.substr(0, o.length - 1), n = n.substr(0, n.length - 1), p = o) : p = p.substr(0, p.length - 1), s = a.closeIndex;
            else if (this.options.unpairedTags.indexOf(o) !== -1)
              s = a.closeIndex;
            else {
              let y = this.readStopNodeData(r, l, f + 1);
              if (!y) throw new Error(`Unexpected end of ${l}`);
              s = y.i, h = y.tagContent;
            }
            let g = new Ge(o);
            o !== p && u && (g[":@"] = this.buildAttributesMap(p, n, o)), h && (h = this.parseTextData(h, o, n, !0, u, !0, !0)), n = n.substr(0, n.lastIndexOf(".")), g.add(this.options.textNodeName, h), this.addChild(t, g, n);
          } else {
            if (p.length > 0 && p.lastIndexOf("/") === p.length - 1) {
              o[o.length - 1] === "/" ? (o = o.substr(0, o.length - 1), n = n.substr(0, n.length - 1), p = o) : p = p.substr(0, p.length - 1), this.options.transformTagName && (o = this.options.transformTagName(o));
              let h = new Ge(o);
              o !== p && u && (h[":@"] = this.buildAttributesMap(p, n, o)), this.addChild(t, h, n), n = n.substr(0, n.lastIndexOf("."));
            } else {
              let h = new Ge(o);
              this.tagsNodeStack.push(t), o !== p && u && (h[":@"] = this.buildAttributesMap(p, n, o)), this.addChild(t, h, n), t = h;
            }
            i = "", s = f;
          }
        }
      else
        i += r[s];
    return e.child;
  }, "parseXml");
  function Qs(r, e, t) {
    let i = this.options.updateTag(e.tagname, t, e[":@"]);
    i === !1 || (typeof i == "string" && (e.tagname = i), r.addChild(e));
  }
  d(Qs, "addChild");
  var Zs = /* @__PURE__ */ d(function(r) {
    if (this.options.processEntities) {
      for (let e in this.docTypeEntities) {
        let t = this.docTypeEntities[e];
        r = r.replace(t.regx, t.val);
      }
      for (let e in this.lastEntities) {
        let t = this.lastEntities[e];
        r = r.replace(t.regex, t.val);
      }
      if (this.options.htmlEntities)
        for (let e in this.htmlEntities) {
          let t = this.htmlEntities[e];
          r = r.replace(t.regex, t.val);
        }
      r = r.replace(this.ampEntity.regex, this.ampEntity.val);
    }
    return r;
  }, "replaceEntitiesValue");
  function ea(r, e, t, i) {
    return r && (i === void 0 && (i = e.child.length === 0), r = this.parseTextData(
      r,
      e.tagname,
      t,
      !1,
      e[":@"] ? Object.keys(e[":@"]).length !== 0 : !1,
      i
    ), r !== void 0 && r !== "" && e.add(this.options.textNodeName, r), r = ""), r;
  }
  d(ea, "saveTextToParentTag");
  function ta(r, e, t) {
    let i = "*." + t;
    for (let n in r) {
      let s = r[n];
      if (i === s || e === s) return !0;
    }
    return !1;
  }
  d(ta, "isItStopNode");
  function ia(r, e, t = ">") {
    let i, n = "";
    for (let s = e; s < r.length; s++) {
      let c = r[s];
      if (i)
        c === i && (i = "");
      else if (c === '"' || c === "'")
        i = c;
      else if (c === t[0])
        if (t[1]) {
          if (r[s + 1] === t[1])
            return {
              data: n,
              index: s
            };
        } else
          return {
            data: n,
            index: s
          };
      else c === "	" && (c = " ");
      n += c;
    }
  }
  d(ia, "tagExpWithClosingIndex");
  function xe(r, e, t, i) {
    let n = r.indexOf(e, t);
    if (n === -1)
      throw new Error(i);
    return n + e.length - 1;
  }
  d(xe, "findClosingIndex");
  function Xt(r, e, t, i = ">") {
    let n = ia(r, e + 1, i);
    if (!n) return;
    let s = n.data, c = n.index, a = s.search(/\s/), o = s, l = !0;
    a !== -1 && (o = s.substring(0, a), s = s.substring(a + 1).trimStart());
    let p = o;
    if (t) {
      let u = o.indexOf(":");
      u !== -1 && (o = o.substr(u + 1), l = o !== n.data.substr(u + 1));
    }
    return {
      tagName: o,
      tagExp: s,
      closeIndex: c,
      attrExpPresent: l,
      rawTagName: p
    };
  }
  d(Xt, "readTagExp");
  function ra(r, e, t) {
    let i = t, n = 1;
    for (; t < r.length; t++)
      if (r[t] === "<")
        if (r[t + 1] === "/") {
          let s = xe(r, ">", t, `${e} is not closed`);
          if (r.substring(t + 2, s).trim() === e && (n--, n === 0))
            return {
              tagContent: r.substring(i, t),
              i: s
            };
          t = s;
        } else if (r[t + 1] === "?")
          t = xe(r, "?>", t + 1, "StopNode is not closed.");
        else if (r.substr(t + 1, 3) === "!--")
          t = xe(r, "-->", t + 3, "StopNode is not closed.");
        else if (r.substr(t + 1, 2) === "![")
          t = xe(r, "]]>", t, "StopNode is not closed.") - 2;
        else {
          let s = Xt(r, t, ">");
          s && ((s && s.tagName) === e && s.tagExp[s.tagExp.length - 1] !== "/" && n++, t = s.closeIndex);
        }
  }
  d(ra, "readStopNodeData");
  function Yt(r, e, t) {
    if (e && typeof r == "string") {
      let i = r.trim();
      return i === "true" ? !0 : i === "false" ? !1 : Vs(r, t);
    } else
      return Cr.isExist(r) ? r : "";
  }
  d(Yt, "parseValue");
  Lr.exports = Wt;
});

// node_modules/fast-xml-parser/src/xmlparser/node2json.js
var Dr = E((Mr) => {
  "use strict";
  function na(r, e) {
    return Ur(r, e);
  }
  d(na, "prettify");
  function Ur(r, e, t) {
    let i, n = {};
    for (let s = 0; s < r.length; s++) {
      let c = r[s], a = sa(c), o = "";
      if (t === void 0 ? o = a : o = t + "." + a, a === e.textNodeName)
        i === void 0 ? i = c[a] : i += "" + c[a];
      else {
        if (a === void 0)
          continue;
        if (c[a]) {
          let l = Ur(c[a], e, o), p = oa(l, e);
          c[":@"] ? aa(l, c[":@"], o, e) : Object.keys(l).length === 1 && l[e.textNodeName] !== void 0 && !e.alwaysCreateTextNode ? l = l[e.textNodeName] : Object.keys(l).length === 0 && (e.alwaysCreateTextNode ? l[e.textNodeName] = "" : l = ""), n[a] !== void 0 && n.hasOwnProperty(a) ? (Array.isArray(n[a]) || (n[a] = [n[a]]), n[a].push(l)) : e.isArray(a, o, p) ? n[a] = [l] : n[a] = l;
        }
      }
    }
    return typeof i == "string" ? i.length > 0 && (n[e.textNodeName] = i) : i !== void 0 && (n[e.textNodeName] = i), n;
  }
  d(Ur, "compress");
  function sa(r) {
    let e = Object.keys(r);
    for (let t = 0; t < e.length; t++) {
      let i = e[t];
      if (i !== ":@") return i;
    }
  }
  d(sa, "propName");
  function aa(r, e, t, i) {
    if (e) {
      let n = Object.keys(e), s = n.length;
      for (let c = 0; c < s; c++) {
        let a = n[c];
        i.isArray(a, t + "." + a, !0, !0) ? r[a] = [e[a]] : r[a] = e[a];
      }
    }
  }
  d(aa, "assignAttributes");
  function oa(r, e) {
    let { textNodeName: t } = e, i = Object.keys(r).length;
    return !!(i === 0 || i === 1 && (r[t] || typeof r[t] == "boolean" || r[t] === 0));
  }
  d(oa, "isLeafTag");
  Mr.prettify = na;
});

// node_modules/fast-xml-parser/src/xmlparser/XMLParser.js
var Br = E((Il, Fr) => {
  var { buildOptions: ca } = Rr(), la = kr(), { prettify: pa } = Dr(), da = Vt(), Jt = class {
    static {
      d(this, "XMLParser");
    }
    constructor(e) {
      this.externalEntities = {}, this.options = ca(e);
    }
    /**
     * Parse XML dats to JS object 
     * @param {string|Buffer} xmlData 
     * @param {boolean|Object} validationOption 
     */
    parse(e, t) {
      if (typeof e != "string")
        if (e.toString)
          e = e.toString();
        else
          throw new Error("XML data is accepted in String or Bytes[] form.");
      if (t) {
        t === !0 && (t = {});
        let s = da.validate(e, t);
        if (s !== !0)
          throw Error(`${s.err.msg}:${s.err.line}:${s.err.col}`);
      }
      let i = new la(this.options);
      i.addExternalEntities(this.externalEntities);
      let n = i.parseXml(e);
      return this.options.preserveOrder || n === void 0 ? n : pa(n, this.options);
    }
    /**
     * Add Entity which is not by default supported by this library
     * @param {string} key 
     * @param {string} value 
     */
    addEntity(e, t) {
      if (t.indexOf("&") !== -1)
        throw new Error("Entity value can't have '&'");
      if (e.indexOf("&") !== -1 || e.indexOf(";") !== -1)
        throw new Error("An entity must be set without '&' and ';'. Eg. use '#xD' for '&#xD;'");
      if (t === "&")
        throw new Error("An entity with value '&' is not permitted");
      this.externalEntities[e] = t;
    }
  };
  Fr.exports = Jt;
});

// node_modules/fast-xml-parser/src/xmlbuilder/orderedJs2Xml.js
var Hr = E((ql, $r) => {
  var ua = `
`;
  function fa(r, e) {
    let t = "";
    return e.format && e.indentBy.length > 0 && (t = ua), zr(r, e, "", t);
  }
  d(fa, "toXml");
  function zr(r, e, t, i) {
    let n = "", s = !1;
    for (let c = 0; c < r.length; c++) {
      let a = r[c], o = ma(a);
      if (o === void 0) continue;
      let l = "";
      if (t.length === 0 ? l = o : l = `${t}.${o}`, o === e.textNodeName) {
        let h = a[o];
        ha(l, e) || (h = e.tagValueProcessor(o, h), h = Vr(h, e)), s && (n += i), n += h, s = !1;
        continue;
      } else if (o === e.cdataPropName) {
        s && (n += i), n += `<![CDATA[${a[o][0][e.textNodeName]}]]>`, s = !1;
        continue;
      } else if (o === e.commentPropName) {
        n += i + `<!--${a[o][0][e.textNodeName]}-->`, s = !0;
        continue;
      } else if (o[0] === "?") {
        let h = Gr(a[":@"], e), g = o === "?xml" ? "" : i, y = a[o][0][e.textNodeName];
        y = y.length !== 0 ? " " + y : "", n += g + `<${o}${y}${h}?>`, s = !0;
        continue;
      }
      let p = i;
      p !== "" && (p += e.indentBy);
      let u = Gr(a[":@"], e), f = i + `<${o}${u}`, m = zr(a[o], e, l, p);
      e.unpairedTags.indexOf(o) !== -1 ? e.suppressUnpairedNode ? n += f + ">" : n += f + "/>" : (!m || m.length === 0) && e.suppressEmptyNode ? n += f + "/>" : m && m.endsWith(">") ? n += f + `>${m}${i}</${o}>` : (n += f + ">", m && i !== "" && (m.includes("/>") || m.includes("</")) ? n += i + e.indentBy + m + i : n += m, n += `</${o}>`), s = !0;
    }
    return n;
  }
  d(zr, "arrToStr");
  function ma(r) {
    let e = Object.keys(r);
    for (let t = 0; t < e.length; t++) {
      let i = e[t];
      if (r.hasOwnProperty(i) && i !== ":@")
        return i;
    }
  }
  d(ma, "propName");
  function Gr(r, e) {
    let t = "";
    if (r && !e.ignoreAttributes)
      for (let i in r) {
        if (!r.hasOwnProperty(i)) continue;
        let n = e.attributeValueProcessor(i, r[i]);
        n = Vr(n, e), n === !0 && e.suppressBooleanAttributes ? t += ` ${i.substr(e.attributeNamePrefix.length)}` : t += ` ${i.substr(e.attributeNamePrefix.length)}="${n}"`;
      }
    return t;
  }
  d(Gr, "attr_to_str");
  function ha(r, e) {
    r = r.substr(0, r.length - e.textNodeName.length - 1);
    let t = r.substr(r.lastIndexOf(".") + 1);
    for (let i in e.stopNodes)
      if (e.stopNodes[i] === r || e.stopNodes[i] === "*." + t) return !0;
    return !1;
  }
  d(ha, "isStopNode");
  function Vr(r, e) {
    if (r && r.length > 0 && e.processEntities)
      for (let t = 0; t < e.entities.length; t++) {
        let i = e.entities[t];
        r = r.replace(i.regex, i.val);
      }
    return r;
  }
  d(Vr, "replaceEntitiesValue");
  $r.exports = fa;
});

// node_modules/fast-xml-parser/src/xmlbuilder/json2xml.js
var Wr = E((jl, Kr) => {
  "use strict";
  var ga = Hr(), xa = Kt(), ya = {
    attributeNamePrefix: "@_",
    attributesGroupName: !1,
    textNodeName: "#text",
    ignoreAttributes: !0,
    cdataPropName: !1,
    format: !1,
    indentBy: "  ",
    suppressEmptyNode: !1,
    suppressUnpairedNode: !0,
    suppressBooleanAttributes: !0,
    tagValueProcessor: /* @__PURE__ */ d(function(r, e) {
      return e;
    }, "tagValueProcessor"),
    attributeValueProcessor: /* @__PURE__ */ d(function(r, e) {
      return e;
    }, "attributeValueProcessor"),
    preserveOrder: !1,
    commentPropName: !1,
    unpairedTags: [],
    entities: [
      { regex: new RegExp("&", "g"), val: "&amp;" },
      //it must be on top
      { regex: new RegExp(">", "g"), val: "&gt;" },
      { regex: new RegExp("<", "g"), val: "&lt;" },
      { regex: new RegExp("'", "g"), val: "&apos;" },
      { regex: new RegExp('"', "g"), val: "&quot;" }
    ],
    processEntities: !0,
    stopNodes: [],
    // transformTagName: false,
    // transformAttributeName: false,
    oneListGroup: !1
  };
  function ce(r) {
    this.options = Object.assign({}, ya, r), this.options.ignoreAttributes === !0 || this.options.attributesGroupName ? this.isAttribute = function() {
      return !1;
    } : (this.ignoreAttributesFn = xa(this.options.ignoreAttributes), this.attrPrefixLen = this.options.attributeNamePrefix.length, this.isAttribute = wa), this.processTextOrObjNode = va, this.options.format ? (this.indentate = ba, this.tagEndChar = `>
`, this.newLine = `
`) : (this.indentate = function() {
      return "";
    }, this.tagEndChar = ">", this.newLine = "");
  }
  d(ce, "Builder");
  ce.prototype.build = function(r) {
    return this.options.preserveOrder ? ga(r, this.options) : (Array.isArray(r) && this.options.arrayNodeName && this.options.arrayNodeName.length > 1 && (r = {
      [this.options.arrayNodeName]: r
    }), this.j2x(r, 0, []).val);
  };
  ce.prototype.j2x = function(r, e, t) {
    let i = "", n = "", s = t.join(".");
    for (let c in r)
      if (Object.prototype.hasOwnProperty.call(r, c))
        if (typeof r[c] > "u")
          this.isAttribute(c) && (n += "");
        else if (r[c] === null)
          this.isAttribute(c) || c === this.options.cdataPropName ? n += "" : c[0] === "?" ? n += this.indentate(e) + "<" + c + "?" + this.tagEndChar : n += this.indentate(e) + "<" + c + "/" + this.tagEndChar;
        else if (r[c] instanceof Date)
          n += this.buildTextValNode(r[c], c, "", e);
        else if (typeof r[c] != "object") {
          let a = this.isAttribute(c);
          if (a && !this.ignoreAttributesFn(a, s))
            i += this.buildAttrPairStr(a, "" + r[c]);
          else if (!a)
            if (c === this.options.textNodeName) {
              let o = this.options.tagValueProcessor(c, "" + r[c]);
              n += this.replaceEntitiesValue(o);
            } else
              n += this.buildTextValNode(r[c], c, "", e);
        } else if (Array.isArray(r[c])) {
          let a = r[c].length, o = "", l = "";
          for (let p = 0; p < a; p++) {
            let u = r[c][p];
            if (!(typeof u > "u"))
              if (u === null)
                c[0] === "?" ? n += this.indentate(e) + "<" + c + "?" + this.tagEndChar : n += this.indentate(e) + "<" + c + "/" + this.tagEndChar;
              else if (typeof u == "object")
                if (this.options.oneListGroup) {
                  let f = this.j2x(u, e + 1, t.concat(c));
                  o += f.val, this.options.attributesGroupName && u.hasOwnProperty(this.options.attributesGroupName) && (l += f.attrStr);
                } else
                  o += this.processTextOrObjNode(u, c, e, t);
              else if (this.options.oneListGroup) {
                let f = this.options.tagValueProcessor(c, u);
                f = this.replaceEntitiesValue(f), o += f;
              } else
                o += this.buildTextValNode(u, c, "", e);
          }
          this.options.oneListGroup && (o = this.buildObjectNode(o, c, l, e)), n += o;
        } else if (this.options.attributesGroupName && c === this.options.attributesGroupName) {
          let a = Object.keys(r[c]), o = a.length;
          for (let l = 0; l < o; l++)
            i += this.buildAttrPairStr(a[l], "" + r[c][a[l]]);
        } else
          n += this.processTextOrObjNode(r[c], c, e, t);
    return { attrStr: i, val: n };
  };
  ce.prototype.buildAttrPairStr = function(r, e) {
    return e = this.options.attributeValueProcessor(r, "" + e), e = this.replaceEntitiesValue(e), this.options.suppressBooleanAttributes && e === "true" ? " " + r : " " + r + '="' + e + '"';
  };
  function va(r, e, t, i) {
    let n = this.j2x(r, t + 1, i.concat(e));
    return r[this.options.textNodeName] !== void 0 && Object.keys(r).length === 1 ? this.buildTextValNode(r[this.options.textNodeName], e, n.attrStr, t) : this.buildObjectNode(n.val, e, n.attrStr, t);
  }
  d(va, "processTextOrObjNode");
  ce.prototype.buildObjectNode = function(r, e, t, i) {
    if (r === "")
      return e[0] === "?" ? this.indentate(i) + "<" + e + t + "?" + this.tagEndChar : this.indentate(i) + "<" + e + t + this.closeTag(e) + this.tagEndChar;
    {
      let n = "</" + e + this.tagEndChar, s = "";
      return e[0] === "?" && (s = "?", n = ""), (t || t === "") && r.indexOf("<") === -1 ? this.indentate(i) + "<" + e + t + s + ">" + r + n : this.options.commentPropName !== !1 && e === this.options.commentPropName && s.length === 0 ? this.indentate(i) + `<!--${r}-->` + this.newLine : this.indentate(i) + "<" + e + t + s + this.tagEndChar + r + this.indentate(i) + n;
    }
  };
  ce.prototype.closeTag = function(r) {
    let e = "";
    return this.options.unpairedTags.indexOf(r) !== -1 ? this.options.suppressUnpairedNode || (e = "/") : this.options.suppressEmptyNode ? e = "/" : e = `></${r}`, e;
  };
  ce.prototype.buildTextValNode = function(r, e, t, i) {
    if (this.options.cdataPropName !== !1 && e === this.options.cdataPropName)
      return this.indentate(i) + `<![CDATA[${r}]]>` + this.newLine;
    if (this.options.commentPropName !== !1 && e === this.options.commentPropName)
      return this.indentate(i) + `<!--${r}-->` + this.newLine;
    if (e[0] === "?")
      return this.indentate(i) + "<" + e + t + "?" + this.tagEndChar;
    {
      let n = this.options.tagValueProcessor(e, r);
      return n = this.replaceEntitiesValue(n), n === "" ? this.indentate(i) + "<" + e + t + this.closeTag(e) + this.tagEndChar : this.indentate(i) + "<" + e + t + ">" + n + "</" + e + this.tagEndChar;
    }
  };
  ce.prototype.replaceEntitiesValue = function(r) {
    if (r && r.length > 0 && this.options.processEntities)
      for (let e = 0; e < this.options.entities.length; e++) {
        let t = this.options.entities[e];
        r = r.replace(t.regex, t.val);
      }
    return r;
  };
  function ba(r) {
    return this.options.indentBy.repeat(r);
  }
  d(ba, "indentate");
  function wa(r) {
    return r.startsWith(this.options.attributeNamePrefix) && r !== this.options.textNodeName ? r.substr(this.attrPrefixLen) : !1;
  }
  d(wa, "isAttribute");
  Kr.exports = ce;
});

// node_modules/fast-xml-parser/src/fxp.js
var Yr = E((Cl, Xr) => {
  "use strict";
  var Ea = Vt(), Aa = Br(), _a = Wr();
  Xr.exports = {
    XMLParser: Aa,
    XMLValidator: Ea,
    XMLBuilder: _a
  };
});

// node_modules/@google-cloud/storage/build/esm/src/nodejs-common/service.js
var xi = v(Oe(), 1);

// node_modules/@google-cloud/storage/node_modules/uuid/dist/esm-node/rng.js
import pn from "crypto";
var He = new Uint8Array(256), $e = He.length;
function gt() {
  return $e > He.length - 16 && (pn.randomFillSync(He), $e = 0), He.slice($e, $e += 16);
}
d(gt, "rng");

// node_modules/@google-cloud/storage/node_modules/uuid/dist/esm-node/regex.js
var ei = /^(?:[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}|00000000-0000-0000-0000-000000000000)$/i;

// node_modules/@google-cloud/storage/node_modules/uuid/dist/esm-node/validate.js
function dn(r) {
  return typeof r == "string" && ei.test(r);
}
d(dn, "validate");
var ti = dn;

// node_modules/@google-cloud/storage/node_modules/uuid/dist/esm-node/stringify.js
var S = [];
for (let r = 0; r < 256; ++r)
  S.push((r + 256).toString(16).substr(1));
function un(r, e = 0) {
  let t = (S[r[e + 0]] + S[r[e + 1]] + S[r[e + 2]] + S[r[e + 3]] + "-" + S[r[e + 4]] + S[r[e + 5]] + "-" + S[r[e + 6]] + S[r[e + 7]] + "-" + S[r[e + 8]] + S[r[e + 9]] + "-" + S[r[e + 10]] + S[r[e + 11]] + S[r[e + 12]] + S[r[e + 13]] + S[r[e + 14]] + S[r[e + 15]]).toLowerCase();
  if (!ti(t))
    throw TypeError("Stringified UUID is invalid");
  return t;
}
d(un, "stringify");
var ii = un;

// node_modules/@google-cloud/storage/node_modules/uuid/dist/esm-node/v4.js
function fn(r, e, t) {
  r = r || {};
  let i = r.random || (r.rng || gt)();
  if (i[6] = i[6] & 15 | 64, i[8] = i[8] & 63 | 128, e) {
    t = t || 0;
    for (let n = 0; n < 16; ++n)
      e[t + n] = i[n];
    return e;
  }
  return ii(i);
}
d(fn, "v4");
var k = fn;

// node_modules/@google-cloud/storage/build/esm/src/nodejs-common/util.js
var de = v(sn(), 1);

// node_modules/html-entities/dist/esm/named-references.js
var be = function() {
  return be = Object.assign || function(r) {
    for (var e, t = 1, i = arguments.length; t < i; t++) {
      e = arguments[t];
      for (var n in e) Object.prototype.hasOwnProperty.call(e, n) && (r[n] = e[n]);
    }
    return r;
  }, be.apply(this, arguments);
}, mn = "~", hn = "~~";
function yt(r, e) {
  for (var t = {}, i = {}, n = r.split(hn), s = !1, c = 0; n.length > c; c++) {
    for (var a = n[c].split(mn), o = 0; o < a.length; o += 2) {
      var l = a[o], p = a[o + 1], u = "&" + l + ";";
      t[u] = p, s && (t["&" + l] = p), i[p] = u;
    }
    s = !0;
  }
  return e ? { entities: be(be({}, t), e.entities), characters: be(be({}, i), e.characters) } : { entities: t, characters: i };
}
d(yt, "generateNamedReferences");
var Ke = {
  xml: /&(?:#\d+|#[xX][\da-fA-F]+|[0-9a-zA-Z]+);?/g,
  html4: /&notin;|&(?:nbsp|iexcl|cent|pound|curren|yen|brvbar|sect|uml|copy|ordf|laquo|not|shy|reg|macr|deg|plusmn|sup2|sup3|acute|micro|para|middot|cedil|sup1|ordm|raquo|frac14|frac12|frac34|iquest|Agrave|Aacute|Acirc|Atilde|Auml|Aring|AElig|Ccedil|Egrave|Eacute|Ecirc|Euml|Igrave|Iacute|Icirc|Iuml|ETH|Ntilde|Ograve|Oacute|Ocirc|Otilde|Ouml|times|Oslash|Ugrave|Uacute|Ucirc|Uuml|Yacute|THORN|szlig|agrave|aacute|acirc|atilde|auml|aring|aelig|ccedil|egrave|eacute|ecirc|euml|igrave|iacute|icirc|iuml|eth|ntilde|ograve|oacute|ocirc|otilde|ouml|divide|oslash|ugrave|uacute|ucirc|uuml|yacute|thorn|yuml|quot|amp|lt|gt|#\d+|#[xX][\da-fA-F]+|[0-9a-zA-Z]+);?/g,
  html5: /&centerdot;|&copysr;|&divideontimes;|&gtcc;|&gtcir;|&gtdot;|&gtlPar;|&gtquest;|&gtrapprox;|&gtrarr;|&gtrdot;|&gtreqless;|&gtreqqless;|&gtrless;|&gtrsim;|&ltcc;|&ltcir;|&ltdot;|&lthree;|&ltimes;|&ltlarr;|&ltquest;|&ltrPar;|&ltri;|&ltrie;|&ltrif;|&notin;|&notinE;|&notindot;|&notinva;|&notinvb;|&notinvc;|&notni;|&notniva;|&notnivb;|&notnivc;|&parallel;|&timesb;|&timesbar;|&timesd;|&(?:AElig|AMP|Aacute|Acirc|Agrave|Aring|Atilde|Auml|COPY|Ccedil|ETH|Eacute|Ecirc|Egrave|Euml|GT|Iacute|Icirc|Igrave|Iuml|LT|Ntilde|Oacute|Ocirc|Ograve|Oslash|Otilde|Ouml|QUOT|REG|THORN|Uacute|Ucirc|Ugrave|Uuml|Yacute|aacute|acirc|acute|aelig|agrave|amp|aring|atilde|auml|brvbar|ccedil|cedil|cent|copy|curren|deg|divide|eacute|ecirc|egrave|eth|euml|frac12|frac14|frac34|gt|iacute|icirc|iexcl|igrave|iquest|iuml|laquo|lt|macr|micro|middot|nbsp|not|ntilde|oacute|ocirc|ograve|ordf|ordm|oslash|otilde|ouml|para|plusmn|pound|quot|raquo|reg|sect|shy|sup1|sup2|sup3|szlig|thorn|times|uacute|ucirc|ugrave|uml|uuml|yacute|yen|yuml|#\d+|#[xX][\da-fA-F]+|[0-9a-zA-Z]+);?/g
}, le = {};
le.xml = yt(`lt~<~gt~>~quot~"~apos~'~amp~&`);
le.html4 = yt(`apos~'~OElig~\u0152~oelig~\u0153~Scaron~\u0160~scaron~\u0161~Yuml~\u0178~circ~\u02C6~tilde~\u02DC~ensp~\u2002~emsp~\u2003~thinsp~\u2009~zwnj~\u200C~zwj~\u200D~lrm~\u200E~rlm~\u200F~ndash~\u2013~mdash~\u2014~lsquo~\u2018~rsquo~\u2019~sbquo~\u201A~ldquo~\u201C~rdquo~\u201D~bdquo~\u201E~dagger~\u2020~Dagger~\u2021~permil~\u2030~lsaquo~\u2039~rsaquo~\u203A~euro~\u20AC~fnof~\u0192~Alpha~\u0391~Beta~\u0392~Gamma~\u0393~Delta~\u0394~Epsilon~\u0395~Zeta~\u0396~Eta~\u0397~Theta~\u0398~Iota~\u0399~Kappa~\u039A~Lambda~\u039B~Mu~\u039C~Nu~\u039D~Xi~\u039E~Omicron~\u039F~Pi~\u03A0~Rho~\u03A1~Sigma~\u03A3~Tau~\u03A4~Upsilon~\u03A5~Phi~\u03A6~Chi~\u03A7~Psi~\u03A8~Omega~\u03A9~alpha~\u03B1~beta~\u03B2~gamma~\u03B3~delta~\u03B4~epsilon~\u03B5~zeta~\u03B6~eta~\u03B7~theta~\u03B8~iota~\u03B9~kappa~\u03BA~lambda~\u03BB~mu~\u03BC~nu~\u03BD~xi~\u03BE~omicron~\u03BF~pi~\u03C0~rho~\u03C1~sigmaf~\u03C2~sigma~\u03C3~tau~\u03C4~upsilon~\u03C5~phi~\u03C6~chi~\u03C7~psi~\u03C8~omega~\u03C9~thetasym~\u03D1~upsih~\u03D2~piv~\u03D6~bull~\u2022~hellip~\u2026~prime~\u2032~Prime~\u2033~oline~\u203E~frasl~\u2044~weierp~\u2118~image~\u2111~real~\u211C~trade~\u2122~alefsym~\u2135~larr~\u2190~uarr~\u2191~rarr~\u2192~darr~\u2193~harr~\u2194~crarr~\u21B5~lArr~\u21D0~uArr~\u21D1~rArr~\u21D2~dArr~\u21D3~hArr~\u21D4~forall~\u2200~part~\u2202~exist~\u2203~empty~\u2205~nabla~\u2207~isin~\u2208~notin~\u2209~ni~\u220B~prod~\u220F~sum~\u2211~minus~\u2212~lowast~\u2217~radic~\u221A~prop~\u221D~infin~\u221E~ang~\u2220~and~\u2227~or~\u2228~cap~\u2229~cup~\u222A~int~\u222B~there4~\u2234~sim~\u223C~cong~\u2245~asymp~\u2248~ne~\u2260~equiv~\u2261~le~\u2264~ge~\u2265~sub~\u2282~sup~\u2283~nsub~\u2284~sube~\u2286~supe~\u2287~oplus~\u2295~otimes~\u2297~perp~\u22A5~sdot~\u22C5~lceil~\u2308~rceil~\u2309~lfloor~\u230A~rfloor~\u230B~lang~\u2329~rang~\u232A~loz~\u25CA~spades~\u2660~clubs~\u2663~hearts~\u2665~diams~\u2666~~nbsp~\xA0~iexcl~\xA1~cent~\xA2~pound~\xA3~curren~\xA4~yen~\xA5~brvbar~\xA6~sect~\xA7~uml~\xA8~copy~\xA9~ordf~\xAA~laquo~\xAB~not~\xAC~shy~\xAD~reg~\xAE~macr~\xAF~deg~\xB0~plusmn~\xB1~sup2~\xB2~sup3~\xB3~acute~\xB4~micro~\xB5~para~\xB6~middot~\xB7~cedil~\xB8~sup1~\xB9~ordm~\xBA~raquo~\xBB~frac14~\xBC~frac12~\xBD~frac34~\xBE~iquest~\xBF~Agrave~\xC0~Aacute~\xC1~Acirc~\xC2~Atilde~\xC3~Auml~\xC4~Aring~\xC5~AElig~\xC6~Ccedil~\xC7~Egrave~\xC8~Eacute~\xC9~Ecirc~\xCA~Euml~\xCB~Igrave~\xCC~Iacute~\xCD~Icirc~\xCE~Iuml~\xCF~ETH~\xD0~Ntilde~\xD1~Ograve~\xD2~Oacute~\xD3~Ocirc~\xD4~Otilde~\xD5~Ouml~\xD6~times~\xD7~Oslash~\xD8~Ugrave~\xD9~Uacute~\xDA~Ucirc~\xDB~Uuml~\xDC~Yacute~\xDD~THORN~\xDE~szlig~\xDF~agrave~\xE0~aacute~\xE1~acirc~\xE2~atilde~\xE3~auml~\xE4~aring~\xE5~aelig~\xE6~ccedil~\xE7~egrave~\xE8~eacute~\xE9~ecirc~\xEA~euml~\xEB~igrave~\xEC~iacute~\xED~icirc~\xEE~iuml~\xEF~eth~\xF0~ntilde~\xF1~ograve~\xF2~oacute~\xF3~ocirc~\xF4~otilde~\xF5~ouml~\xF6~divide~\xF7~oslash~\xF8~ugrave~\xF9~uacute~\xFA~ucirc~\xFB~uuml~\xFC~yacute~\xFD~thorn~\xFE~yuml~\xFF~quot~"~amp~&~lt~<~gt~>`);
le.html5 = yt('Abreve~\u0102~Acy~\u0410~Afr~\u{1D504}~Amacr~\u0100~And~\u2A53~Aogon~\u0104~Aopf~\u{1D538}~ApplyFunction~\u2061~Ascr~\u{1D49C}~Assign~\u2254~Backslash~\u2216~Barv~\u2AE7~Barwed~\u2306~Bcy~\u0411~Because~\u2235~Bernoullis~\u212C~Bfr~\u{1D505}~Bopf~\u{1D539}~Breve~\u02D8~Bscr~\u212C~Bumpeq~\u224E~CHcy~\u0427~Cacute~\u0106~Cap~\u22D2~CapitalDifferentialD~\u2145~Cayleys~\u212D~Ccaron~\u010C~Ccirc~\u0108~Cconint~\u2230~Cdot~\u010A~Cedilla~\xB8~CenterDot~\xB7~Cfr~\u212D~CircleDot~\u2299~CircleMinus~\u2296~CirclePlus~\u2295~CircleTimes~\u2297~ClockwiseContourIntegral~\u2232~CloseCurlyDoubleQuote~\u201D~CloseCurlyQuote~\u2019~Colon~\u2237~Colone~\u2A74~Congruent~\u2261~Conint~\u222F~ContourIntegral~\u222E~Copf~\u2102~Coproduct~\u2210~CounterClockwiseContourIntegral~\u2233~Cross~\u2A2F~Cscr~\u{1D49E}~Cup~\u22D3~CupCap~\u224D~DD~\u2145~DDotrahd~\u2911~DJcy~\u0402~DScy~\u0405~DZcy~\u040F~Darr~\u21A1~Dashv~\u2AE4~Dcaron~\u010E~Dcy~\u0414~Del~\u2207~Dfr~\u{1D507}~DiacriticalAcute~\xB4~DiacriticalDot~\u02D9~DiacriticalDoubleAcute~\u02DD~DiacriticalGrave~`~DiacriticalTilde~\u02DC~Diamond~\u22C4~DifferentialD~\u2146~Dopf~\u{1D53B}~Dot~\xA8~DotDot~\u20DC~DotEqual~\u2250~DoubleContourIntegral~\u222F~DoubleDot~\xA8~DoubleDownArrow~\u21D3~DoubleLeftArrow~\u21D0~DoubleLeftRightArrow~\u21D4~DoubleLeftTee~\u2AE4~DoubleLongLeftArrow~\u27F8~DoubleLongLeftRightArrow~\u27FA~DoubleLongRightArrow~\u27F9~DoubleRightArrow~\u21D2~DoubleRightTee~\u22A8~DoubleUpArrow~\u21D1~DoubleUpDownArrow~\u21D5~DoubleVerticalBar~\u2225~DownArrow~\u2193~DownArrowBar~\u2913~DownArrowUpArrow~\u21F5~DownBreve~\u0311~DownLeftRightVector~\u2950~DownLeftTeeVector~\u295E~DownLeftVector~\u21BD~DownLeftVectorBar~\u2956~DownRightTeeVector~\u295F~DownRightVector~\u21C1~DownRightVectorBar~\u2957~DownTee~\u22A4~DownTeeArrow~\u21A7~Downarrow~\u21D3~Dscr~\u{1D49F}~Dstrok~\u0110~ENG~\u014A~Ecaron~\u011A~Ecy~\u042D~Edot~\u0116~Efr~\u{1D508}~Element~\u2208~Emacr~\u0112~EmptySmallSquare~\u25FB~EmptyVerySmallSquare~\u25AB~Eogon~\u0118~Eopf~\u{1D53C}~Equal~\u2A75~EqualTilde~\u2242~Equilibrium~\u21CC~Escr~\u2130~Esim~\u2A73~Exists~\u2203~ExponentialE~\u2147~Fcy~\u0424~Ffr~\u{1D509}~FilledSmallSquare~\u25FC~FilledVerySmallSquare~\u25AA~Fopf~\u{1D53D}~ForAll~\u2200~Fouriertrf~\u2131~Fscr~\u2131~GJcy~\u0403~Gammad~\u03DC~Gbreve~\u011E~Gcedil~\u0122~Gcirc~\u011C~Gcy~\u0413~Gdot~\u0120~Gfr~\u{1D50A}~Gg~\u22D9~Gopf~\u{1D53E}~GreaterEqual~\u2265~GreaterEqualLess~\u22DB~GreaterFullEqual~\u2267~GreaterGreater~\u2AA2~GreaterLess~\u2277~GreaterSlantEqual~\u2A7E~GreaterTilde~\u2273~Gscr~\u{1D4A2}~Gt~\u226B~HARDcy~\u042A~Hacek~\u02C7~Hat~^~Hcirc~\u0124~Hfr~\u210C~HilbertSpace~\u210B~Hopf~\u210D~HorizontalLine~\u2500~Hscr~\u210B~Hstrok~\u0126~HumpDownHump~\u224E~HumpEqual~\u224F~IEcy~\u0415~IJlig~\u0132~IOcy~\u0401~Icy~\u0418~Idot~\u0130~Ifr~\u2111~Im~\u2111~Imacr~\u012A~ImaginaryI~\u2148~Implies~\u21D2~Int~\u222C~Integral~\u222B~Intersection~\u22C2~InvisibleComma~\u2063~InvisibleTimes~\u2062~Iogon~\u012E~Iopf~\u{1D540}~Iscr~\u2110~Itilde~\u0128~Iukcy~\u0406~Jcirc~\u0134~Jcy~\u0419~Jfr~\u{1D50D}~Jopf~\u{1D541}~Jscr~\u{1D4A5}~Jsercy~\u0408~Jukcy~\u0404~KHcy~\u0425~KJcy~\u040C~Kcedil~\u0136~Kcy~\u041A~Kfr~\u{1D50E}~Kopf~\u{1D542}~Kscr~\u{1D4A6}~LJcy~\u0409~Lacute~\u0139~Lang~\u27EA~Laplacetrf~\u2112~Larr~\u219E~Lcaron~\u013D~Lcedil~\u013B~Lcy~\u041B~LeftAngleBracket~\u27E8~LeftArrow~\u2190~LeftArrowBar~\u21E4~LeftArrowRightArrow~\u21C6~LeftCeiling~\u2308~LeftDoubleBracket~\u27E6~LeftDownTeeVector~\u2961~LeftDownVector~\u21C3~LeftDownVectorBar~\u2959~LeftFloor~\u230A~LeftRightArrow~\u2194~LeftRightVector~\u294E~LeftTee~\u22A3~LeftTeeArrow~\u21A4~LeftTeeVector~\u295A~LeftTriangle~\u22B2~LeftTriangleBar~\u29CF~LeftTriangleEqual~\u22B4~LeftUpDownVector~\u2951~LeftUpTeeVector~\u2960~LeftUpVector~\u21BF~LeftUpVectorBar~\u2958~LeftVector~\u21BC~LeftVectorBar~\u2952~Leftarrow~\u21D0~Leftrightarrow~\u21D4~LessEqualGreater~\u22DA~LessFullEqual~\u2266~LessGreater~\u2276~LessLess~\u2AA1~LessSlantEqual~\u2A7D~LessTilde~\u2272~Lfr~\u{1D50F}~Ll~\u22D8~Lleftarrow~\u21DA~Lmidot~\u013F~LongLeftArrow~\u27F5~LongLeftRightArrow~\u27F7~LongRightArrow~\u27F6~Longleftarrow~\u27F8~Longleftrightarrow~\u27FA~Longrightarrow~\u27F9~Lopf~\u{1D543}~LowerLeftArrow~\u2199~LowerRightArrow~\u2198~Lscr~\u2112~Lsh~\u21B0~Lstrok~\u0141~Lt~\u226A~Map~\u2905~Mcy~\u041C~MediumSpace~\u205F~Mellintrf~\u2133~Mfr~\u{1D510}~MinusPlus~\u2213~Mopf~\u{1D544}~Mscr~\u2133~NJcy~\u040A~Nacute~\u0143~Ncaron~\u0147~Ncedil~\u0145~Ncy~\u041D~NegativeMediumSpace~\u200B~NegativeThickSpace~\u200B~NegativeThinSpace~\u200B~NegativeVeryThinSpace~\u200B~NestedGreaterGreater~\u226B~NestedLessLess~\u226A~NewLine~\n~Nfr~\u{1D511}~NoBreak~\u2060~NonBreakingSpace~\xA0~Nopf~\u2115~Not~\u2AEC~NotCongruent~\u2262~NotCupCap~\u226D~NotDoubleVerticalBar~\u2226~NotElement~\u2209~NotEqual~\u2260~NotEqualTilde~\u2242\u0338~NotExists~\u2204~NotGreater~\u226F~NotGreaterEqual~\u2271~NotGreaterFullEqual~\u2267\u0338~NotGreaterGreater~\u226B\u0338~NotGreaterLess~\u2279~NotGreaterSlantEqual~\u2A7E\u0338~NotGreaterTilde~\u2275~NotHumpDownHump~\u224E\u0338~NotHumpEqual~\u224F\u0338~NotLeftTriangle~\u22EA~NotLeftTriangleBar~\u29CF\u0338~NotLeftTriangleEqual~\u22EC~NotLess~\u226E~NotLessEqual~\u2270~NotLessGreater~\u2278~NotLessLess~\u226A\u0338~NotLessSlantEqual~\u2A7D\u0338~NotLessTilde~\u2274~NotNestedGreaterGreater~\u2AA2\u0338~NotNestedLessLess~\u2AA1\u0338~NotPrecedes~\u2280~NotPrecedesEqual~\u2AAF\u0338~NotPrecedesSlantEqual~\u22E0~NotReverseElement~\u220C~NotRightTriangle~\u22EB~NotRightTriangleBar~\u29D0\u0338~NotRightTriangleEqual~\u22ED~NotSquareSubset~\u228F\u0338~NotSquareSubsetEqual~\u22E2~NotSquareSuperset~\u2290\u0338~NotSquareSupersetEqual~\u22E3~NotSubset~\u2282\u20D2~NotSubsetEqual~\u2288~NotSucceeds~\u2281~NotSucceedsEqual~\u2AB0\u0338~NotSucceedsSlantEqual~\u22E1~NotSucceedsTilde~\u227F\u0338~NotSuperset~\u2283\u20D2~NotSupersetEqual~\u2289~NotTilde~\u2241~NotTildeEqual~\u2244~NotTildeFullEqual~\u2247~NotTildeTilde~\u2249~NotVerticalBar~\u2224~Nscr~\u{1D4A9}~Ocy~\u041E~Odblac~\u0150~Ofr~\u{1D512}~Omacr~\u014C~Oopf~\u{1D546}~OpenCurlyDoubleQuote~\u201C~OpenCurlyQuote~\u2018~Or~\u2A54~Oscr~\u{1D4AA}~Otimes~\u2A37~OverBar~\u203E~OverBrace~\u23DE~OverBracket~\u23B4~OverParenthesis~\u23DC~PartialD~\u2202~Pcy~\u041F~Pfr~\u{1D513}~PlusMinus~\xB1~Poincareplane~\u210C~Popf~\u2119~Pr~\u2ABB~Precedes~\u227A~PrecedesEqual~\u2AAF~PrecedesSlantEqual~\u227C~PrecedesTilde~\u227E~Product~\u220F~Proportion~\u2237~Proportional~\u221D~Pscr~\u{1D4AB}~Qfr~\u{1D514}~Qopf~\u211A~Qscr~\u{1D4AC}~RBarr~\u2910~Racute~\u0154~Rang~\u27EB~Rarr~\u21A0~Rarrtl~\u2916~Rcaron~\u0158~Rcedil~\u0156~Rcy~\u0420~Re~\u211C~ReverseElement~\u220B~ReverseEquilibrium~\u21CB~ReverseUpEquilibrium~\u296F~Rfr~\u211C~RightAngleBracket~\u27E9~RightArrow~\u2192~RightArrowBar~\u21E5~RightArrowLeftArrow~\u21C4~RightCeiling~\u2309~RightDoubleBracket~\u27E7~RightDownTeeVector~\u295D~RightDownVector~\u21C2~RightDownVectorBar~\u2955~RightFloor~\u230B~RightTee~\u22A2~RightTeeArrow~\u21A6~RightTeeVector~\u295B~RightTriangle~\u22B3~RightTriangleBar~\u29D0~RightTriangleEqual~\u22B5~RightUpDownVector~\u294F~RightUpTeeVector~\u295C~RightUpVector~\u21BE~RightUpVectorBar~\u2954~RightVector~\u21C0~RightVectorBar~\u2953~Rightarrow~\u21D2~Ropf~\u211D~RoundImplies~\u2970~Rrightarrow~\u21DB~Rscr~\u211B~Rsh~\u21B1~RuleDelayed~\u29F4~SHCHcy~\u0429~SHcy~\u0428~SOFTcy~\u042C~Sacute~\u015A~Sc~\u2ABC~Scedil~\u015E~Scirc~\u015C~Scy~\u0421~Sfr~\u{1D516}~ShortDownArrow~\u2193~ShortLeftArrow~\u2190~ShortRightArrow~\u2192~ShortUpArrow~\u2191~SmallCircle~\u2218~Sopf~\u{1D54A}~Sqrt~\u221A~Square~\u25A1~SquareIntersection~\u2293~SquareSubset~\u228F~SquareSubsetEqual~\u2291~SquareSuperset~\u2290~SquareSupersetEqual~\u2292~SquareUnion~\u2294~Sscr~\u{1D4AE}~Star~\u22C6~Sub~\u22D0~Subset~\u22D0~SubsetEqual~\u2286~Succeeds~\u227B~SucceedsEqual~\u2AB0~SucceedsSlantEqual~\u227D~SucceedsTilde~\u227F~SuchThat~\u220B~Sum~\u2211~Sup~\u22D1~Superset~\u2283~SupersetEqual~\u2287~Supset~\u22D1~TRADE~\u2122~TSHcy~\u040B~TScy~\u0426~Tab~	~Tcaron~\u0164~Tcedil~\u0162~Tcy~\u0422~Tfr~\u{1D517}~Therefore~\u2234~ThickSpace~\u205F\u200A~ThinSpace~\u2009~Tilde~\u223C~TildeEqual~\u2243~TildeFullEqual~\u2245~TildeTilde~\u2248~Topf~\u{1D54B}~TripleDot~\u20DB~Tscr~\u{1D4AF}~Tstrok~\u0166~Uarr~\u219F~Uarrocir~\u2949~Ubrcy~\u040E~Ubreve~\u016C~Ucy~\u0423~Udblac~\u0170~Ufr~\u{1D518}~Umacr~\u016A~UnderBar~_~UnderBrace~\u23DF~UnderBracket~\u23B5~UnderParenthesis~\u23DD~Union~\u22C3~UnionPlus~\u228E~Uogon~\u0172~Uopf~\u{1D54C}~UpArrow~\u2191~UpArrowBar~\u2912~UpArrowDownArrow~\u21C5~UpDownArrow~\u2195~UpEquilibrium~\u296E~UpTee~\u22A5~UpTeeArrow~\u21A5~Uparrow~\u21D1~Updownarrow~\u21D5~UpperLeftArrow~\u2196~UpperRightArrow~\u2197~Upsi~\u03D2~Uring~\u016E~Uscr~\u{1D4B0}~Utilde~\u0168~VDash~\u22AB~Vbar~\u2AEB~Vcy~\u0412~Vdash~\u22A9~Vdashl~\u2AE6~Vee~\u22C1~Verbar~\u2016~Vert~\u2016~VerticalBar~\u2223~VerticalLine~|~VerticalSeparator~\u2758~VerticalTilde~\u2240~VeryThinSpace~\u200A~Vfr~\u{1D519}~Vopf~\u{1D54D}~Vscr~\u{1D4B1}~Vvdash~\u22AA~Wcirc~\u0174~Wedge~\u22C0~Wfr~\u{1D51A}~Wopf~\u{1D54E}~Wscr~\u{1D4B2}~Xfr~\u{1D51B}~Xopf~\u{1D54F}~Xscr~\u{1D4B3}~YAcy~\u042F~YIcy~\u0407~YUcy~\u042E~Ycirc~\u0176~Ycy~\u042B~Yfr~\u{1D51C}~Yopf~\u{1D550}~Yscr~\u{1D4B4}~ZHcy~\u0416~Zacute~\u0179~Zcaron~\u017D~Zcy~\u0417~Zdot~\u017B~ZeroWidthSpace~\u200B~Zfr~\u2128~Zopf~\u2124~Zscr~\u{1D4B5}~abreve~\u0103~ac~\u223E~acE~\u223E\u0333~acd~\u223F~acy~\u0430~af~\u2061~afr~\u{1D51E}~aleph~\u2135~amacr~\u0101~amalg~\u2A3F~andand~\u2A55~andd~\u2A5C~andslope~\u2A58~andv~\u2A5A~ange~\u29A4~angle~\u2220~angmsd~\u2221~angmsdaa~\u29A8~angmsdab~\u29A9~angmsdac~\u29AA~angmsdad~\u29AB~angmsdae~\u29AC~angmsdaf~\u29AD~angmsdag~\u29AE~angmsdah~\u29AF~angrt~\u221F~angrtvb~\u22BE~angrtvbd~\u299D~angsph~\u2222~angst~\xC5~angzarr~\u237C~aogon~\u0105~aopf~\u{1D552}~ap~\u2248~apE~\u2A70~apacir~\u2A6F~ape~\u224A~apid~\u224B~approx~\u2248~approxeq~\u224A~ascr~\u{1D4B6}~ast~*~asympeq~\u224D~awconint~\u2233~awint~\u2A11~bNot~\u2AED~backcong~\u224C~backepsilon~\u03F6~backprime~\u2035~backsim~\u223D~backsimeq~\u22CD~barvee~\u22BD~barwed~\u2305~barwedge~\u2305~bbrk~\u23B5~bbrktbrk~\u23B6~bcong~\u224C~bcy~\u0431~becaus~\u2235~because~\u2235~bemptyv~\u29B0~bepsi~\u03F6~bernou~\u212C~beth~\u2136~between~\u226C~bfr~\u{1D51F}~bigcap~\u22C2~bigcirc~\u25EF~bigcup~\u22C3~bigodot~\u2A00~bigoplus~\u2A01~bigotimes~\u2A02~bigsqcup~\u2A06~bigstar~\u2605~bigtriangledown~\u25BD~bigtriangleup~\u25B3~biguplus~\u2A04~bigvee~\u22C1~bigwedge~\u22C0~bkarow~\u290D~blacklozenge~\u29EB~blacksquare~\u25AA~blacktriangle~\u25B4~blacktriangledown~\u25BE~blacktriangleleft~\u25C2~blacktriangleright~\u25B8~blank~\u2423~blk12~\u2592~blk14~\u2591~blk34~\u2593~block~\u2588~bne~=\u20E5~bnequiv~\u2261\u20E5~bnot~\u2310~bopf~\u{1D553}~bot~\u22A5~bottom~\u22A5~bowtie~\u22C8~boxDL~\u2557~boxDR~\u2554~boxDl~\u2556~boxDr~\u2553~boxH~\u2550~boxHD~\u2566~boxHU~\u2569~boxHd~\u2564~boxHu~\u2567~boxUL~\u255D~boxUR~\u255A~boxUl~\u255C~boxUr~\u2559~boxV~\u2551~boxVH~\u256C~boxVL~\u2563~boxVR~\u2560~boxVh~\u256B~boxVl~\u2562~boxVr~\u255F~boxbox~\u29C9~boxdL~\u2555~boxdR~\u2552~boxdl~\u2510~boxdr~\u250C~boxh~\u2500~boxhD~\u2565~boxhU~\u2568~boxhd~\u252C~boxhu~\u2534~boxminus~\u229F~boxplus~\u229E~boxtimes~\u22A0~boxuL~\u255B~boxuR~\u2558~boxul~\u2518~boxur~\u2514~boxv~\u2502~boxvH~\u256A~boxvL~\u2561~boxvR~\u255E~boxvh~\u253C~boxvl~\u2524~boxvr~\u251C~bprime~\u2035~breve~\u02D8~bscr~\u{1D4B7}~bsemi~\u204F~bsim~\u223D~bsime~\u22CD~bsol~\\~bsolb~\u29C5~bsolhsub~\u27C8~bullet~\u2022~bump~\u224E~bumpE~\u2AAE~bumpe~\u224F~bumpeq~\u224F~cacute~\u0107~capand~\u2A44~capbrcup~\u2A49~capcap~\u2A4B~capcup~\u2A47~capdot~\u2A40~caps~\u2229\uFE00~caret~\u2041~caron~\u02C7~ccaps~\u2A4D~ccaron~\u010D~ccirc~\u0109~ccups~\u2A4C~ccupssm~\u2A50~cdot~\u010B~cemptyv~\u29B2~centerdot~\xB7~cfr~\u{1D520}~chcy~\u0447~check~\u2713~checkmark~\u2713~cir~\u25CB~cirE~\u29C3~circeq~\u2257~circlearrowleft~\u21BA~circlearrowright~\u21BB~circledR~\xAE~circledS~\u24C8~circledast~\u229B~circledcirc~\u229A~circleddash~\u229D~cire~\u2257~cirfnint~\u2A10~cirmid~\u2AEF~cirscir~\u29C2~clubsuit~\u2663~colon~:~colone~\u2254~coloneq~\u2254~comma~,~commat~@~comp~\u2201~compfn~\u2218~complement~\u2201~complexes~\u2102~congdot~\u2A6D~conint~\u222E~copf~\u{1D554}~coprod~\u2210~copysr~\u2117~cross~\u2717~cscr~\u{1D4B8}~csub~\u2ACF~csube~\u2AD1~csup~\u2AD0~csupe~\u2AD2~ctdot~\u22EF~cudarrl~\u2938~cudarrr~\u2935~cuepr~\u22DE~cuesc~\u22DF~cularr~\u21B6~cularrp~\u293D~cupbrcap~\u2A48~cupcap~\u2A46~cupcup~\u2A4A~cupdot~\u228D~cupor~\u2A45~cups~\u222A\uFE00~curarr~\u21B7~curarrm~\u293C~curlyeqprec~\u22DE~curlyeqsucc~\u22DF~curlyvee~\u22CE~curlywedge~\u22CF~curvearrowleft~\u21B6~curvearrowright~\u21B7~cuvee~\u22CE~cuwed~\u22CF~cwconint~\u2232~cwint~\u2231~cylcty~\u232D~dHar~\u2965~daleth~\u2138~dash~\u2010~dashv~\u22A3~dbkarow~\u290F~dblac~\u02DD~dcaron~\u010F~dcy~\u0434~dd~\u2146~ddagger~\u2021~ddarr~\u21CA~ddotseq~\u2A77~demptyv~\u29B1~dfisht~\u297F~dfr~\u{1D521}~dharl~\u21C3~dharr~\u21C2~diam~\u22C4~diamond~\u22C4~diamondsuit~\u2666~die~\xA8~digamma~\u03DD~disin~\u22F2~div~\xF7~divideontimes~\u22C7~divonx~\u22C7~djcy~\u0452~dlcorn~\u231E~dlcrop~\u230D~dollar~$~dopf~\u{1D555}~dot~\u02D9~doteq~\u2250~doteqdot~\u2251~dotminus~\u2238~dotplus~\u2214~dotsquare~\u22A1~doublebarwedge~\u2306~downarrow~\u2193~downdownarrows~\u21CA~downharpoonleft~\u21C3~downharpoonright~\u21C2~drbkarow~\u2910~drcorn~\u231F~drcrop~\u230C~dscr~\u{1D4B9}~dscy~\u0455~dsol~\u29F6~dstrok~\u0111~dtdot~\u22F1~dtri~\u25BF~dtrif~\u25BE~duarr~\u21F5~duhar~\u296F~dwangle~\u29A6~dzcy~\u045F~dzigrarr~\u27FF~eDDot~\u2A77~eDot~\u2251~easter~\u2A6E~ecaron~\u011B~ecir~\u2256~ecolon~\u2255~ecy~\u044D~edot~\u0117~ee~\u2147~efDot~\u2252~efr~\u{1D522}~eg~\u2A9A~egs~\u2A96~egsdot~\u2A98~el~\u2A99~elinters~\u23E7~ell~\u2113~els~\u2A95~elsdot~\u2A97~emacr~\u0113~emptyset~\u2205~emptyv~\u2205~emsp13~\u2004~emsp14~\u2005~eng~\u014B~eogon~\u0119~eopf~\u{1D556}~epar~\u22D5~eparsl~\u29E3~eplus~\u2A71~epsi~\u03B5~epsiv~\u03F5~eqcirc~\u2256~eqcolon~\u2255~eqsim~\u2242~eqslantgtr~\u2A96~eqslantless~\u2A95~equals~=~equest~\u225F~equivDD~\u2A78~eqvparsl~\u29E5~erDot~\u2253~erarr~\u2971~escr~\u212F~esdot~\u2250~esim~\u2242~excl~!~expectation~\u2130~exponentiale~\u2147~fallingdotseq~\u2252~fcy~\u0444~female~\u2640~ffilig~\uFB03~fflig~\uFB00~ffllig~\uFB04~ffr~\u{1D523}~filig~\uFB01~fjlig~fj~flat~\u266D~fllig~\uFB02~fltns~\u25B1~fopf~\u{1D557}~fork~\u22D4~forkv~\u2AD9~fpartint~\u2A0D~frac13~\u2153~frac15~\u2155~frac16~\u2159~frac18~\u215B~frac23~\u2154~frac25~\u2156~frac35~\u2157~frac38~\u215C~frac45~\u2158~frac56~\u215A~frac58~\u215D~frac78~\u215E~frown~\u2322~fscr~\u{1D4BB}~gE~\u2267~gEl~\u2A8C~gacute~\u01F5~gammad~\u03DD~gap~\u2A86~gbreve~\u011F~gcirc~\u011D~gcy~\u0433~gdot~\u0121~gel~\u22DB~geq~\u2265~geqq~\u2267~geqslant~\u2A7E~ges~\u2A7E~gescc~\u2AA9~gesdot~\u2A80~gesdoto~\u2A82~gesdotol~\u2A84~gesl~\u22DB\uFE00~gesles~\u2A94~gfr~\u{1D524}~gg~\u226B~ggg~\u22D9~gimel~\u2137~gjcy~\u0453~gl~\u2277~glE~\u2A92~gla~\u2AA5~glj~\u2AA4~gnE~\u2269~gnap~\u2A8A~gnapprox~\u2A8A~gne~\u2A88~gneq~\u2A88~gneqq~\u2269~gnsim~\u22E7~gopf~\u{1D558}~grave~`~gscr~\u210A~gsim~\u2273~gsime~\u2A8E~gsiml~\u2A90~gtcc~\u2AA7~gtcir~\u2A7A~gtdot~\u22D7~gtlPar~\u2995~gtquest~\u2A7C~gtrapprox~\u2A86~gtrarr~\u2978~gtrdot~\u22D7~gtreqless~\u22DB~gtreqqless~\u2A8C~gtrless~\u2277~gtrsim~\u2273~gvertneqq~\u2269\uFE00~gvnE~\u2269\uFE00~hairsp~\u200A~half~\xBD~hamilt~\u210B~hardcy~\u044A~harrcir~\u2948~harrw~\u21AD~hbar~\u210F~hcirc~\u0125~heartsuit~\u2665~hercon~\u22B9~hfr~\u{1D525}~hksearow~\u2925~hkswarow~\u2926~hoarr~\u21FF~homtht~\u223B~hookleftarrow~\u21A9~hookrightarrow~\u21AA~hopf~\u{1D559}~horbar~\u2015~hscr~\u{1D4BD}~hslash~\u210F~hstrok~\u0127~hybull~\u2043~hyphen~\u2010~ic~\u2063~icy~\u0438~iecy~\u0435~iff~\u21D4~ifr~\u{1D526}~ii~\u2148~iiiint~\u2A0C~iiint~\u222D~iinfin~\u29DC~iiota~\u2129~ijlig~\u0133~imacr~\u012B~imagline~\u2110~imagpart~\u2111~imath~\u0131~imof~\u22B7~imped~\u01B5~in~\u2208~incare~\u2105~infintie~\u29DD~inodot~\u0131~intcal~\u22BA~integers~\u2124~intercal~\u22BA~intlarhk~\u2A17~intprod~\u2A3C~iocy~\u0451~iogon~\u012F~iopf~\u{1D55A}~iprod~\u2A3C~iscr~\u{1D4BE}~isinE~\u22F9~isindot~\u22F5~isins~\u22F4~isinsv~\u22F3~isinv~\u2208~it~\u2062~itilde~\u0129~iukcy~\u0456~jcirc~\u0135~jcy~\u0439~jfr~\u{1D527}~jmath~\u0237~jopf~\u{1D55B}~jscr~\u{1D4BF}~jsercy~\u0458~jukcy~\u0454~kappav~\u03F0~kcedil~\u0137~kcy~\u043A~kfr~\u{1D528}~kgreen~\u0138~khcy~\u0445~kjcy~\u045C~kopf~\u{1D55C}~kscr~\u{1D4C0}~lAarr~\u21DA~lAtail~\u291B~lBarr~\u290E~lE~\u2266~lEg~\u2A8B~lHar~\u2962~lacute~\u013A~laemptyv~\u29B4~lagran~\u2112~langd~\u2991~langle~\u27E8~lap~\u2A85~larrb~\u21E4~larrbfs~\u291F~larrfs~\u291D~larrhk~\u21A9~larrlp~\u21AB~larrpl~\u2939~larrsim~\u2973~larrtl~\u21A2~lat~\u2AAB~latail~\u2919~late~\u2AAD~lates~\u2AAD\uFE00~lbarr~\u290C~lbbrk~\u2772~lbrace~{~lbrack~[~lbrke~\u298B~lbrksld~\u298F~lbrkslu~\u298D~lcaron~\u013E~lcedil~\u013C~lcub~{~lcy~\u043B~ldca~\u2936~ldquor~\u201E~ldrdhar~\u2967~ldrushar~\u294B~ldsh~\u21B2~leftarrow~\u2190~leftarrowtail~\u21A2~leftharpoondown~\u21BD~leftharpoonup~\u21BC~leftleftarrows~\u21C7~leftrightarrow~\u2194~leftrightarrows~\u21C6~leftrightharpoons~\u21CB~leftrightsquigarrow~\u21AD~leftthreetimes~\u22CB~leg~\u22DA~leq~\u2264~leqq~\u2266~leqslant~\u2A7D~les~\u2A7D~lescc~\u2AA8~lesdot~\u2A7F~lesdoto~\u2A81~lesdotor~\u2A83~lesg~\u22DA\uFE00~lesges~\u2A93~lessapprox~\u2A85~lessdot~\u22D6~lesseqgtr~\u22DA~lesseqqgtr~\u2A8B~lessgtr~\u2276~lesssim~\u2272~lfisht~\u297C~lfr~\u{1D529}~lg~\u2276~lgE~\u2A91~lhard~\u21BD~lharu~\u21BC~lharul~\u296A~lhblk~\u2584~ljcy~\u0459~ll~\u226A~llarr~\u21C7~llcorner~\u231E~llhard~\u296B~lltri~\u25FA~lmidot~\u0140~lmoust~\u23B0~lmoustache~\u23B0~lnE~\u2268~lnap~\u2A89~lnapprox~\u2A89~lne~\u2A87~lneq~\u2A87~lneqq~\u2268~lnsim~\u22E6~loang~\u27EC~loarr~\u21FD~lobrk~\u27E6~longleftarrow~\u27F5~longleftrightarrow~\u27F7~longmapsto~\u27FC~longrightarrow~\u27F6~looparrowleft~\u21AB~looparrowright~\u21AC~lopar~\u2985~lopf~\u{1D55D}~loplus~\u2A2D~lotimes~\u2A34~lowbar~_~lozenge~\u25CA~lozf~\u29EB~lpar~(~lparlt~\u2993~lrarr~\u21C6~lrcorner~\u231F~lrhar~\u21CB~lrhard~\u296D~lrtri~\u22BF~lscr~\u{1D4C1}~lsh~\u21B0~lsim~\u2272~lsime~\u2A8D~lsimg~\u2A8F~lsqb~[~lsquor~\u201A~lstrok~\u0142~ltcc~\u2AA6~ltcir~\u2A79~ltdot~\u22D6~lthree~\u22CB~ltimes~\u22C9~ltlarr~\u2976~ltquest~\u2A7B~ltrPar~\u2996~ltri~\u25C3~ltrie~\u22B4~ltrif~\u25C2~lurdshar~\u294A~luruhar~\u2966~lvertneqq~\u2268\uFE00~lvnE~\u2268\uFE00~mDDot~\u223A~male~\u2642~malt~\u2720~maltese~\u2720~map~\u21A6~mapsto~\u21A6~mapstodown~\u21A7~mapstoleft~\u21A4~mapstoup~\u21A5~marker~\u25AE~mcomma~\u2A29~mcy~\u043C~measuredangle~\u2221~mfr~\u{1D52A}~mho~\u2127~mid~\u2223~midast~*~midcir~\u2AF0~minusb~\u229F~minusd~\u2238~minusdu~\u2A2A~mlcp~\u2ADB~mldr~\u2026~mnplus~\u2213~models~\u22A7~mopf~\u{1D55E}~mp~\u2213~mscr~\u{1D4C2}~mstpos~\u223E~multimap~\u22B8~mumap~\u22B8~nGg~\u22D9\u0338~nGt~\u226B\u20D2~nGtv~\u226B\u0338~nLeftarrow~\u21CD~nLeftrightarrow~\u21CE~nLl~\u22D8\u0338~nLt~\u226A\u20D2~nLtv~\u226A\u0338~nRightarrow~\u21CF~nVDash~\u22AF~nVdash~\u22AE~nacute~\u0144~nang~\u2220\u20D2~nap~\u2249~napE~\u2A70\u0338~napid~\u224B\u0338~napos~\u0149~napprox~\u2249~natur~\u266E~natural~\u266E~naturals~\u2115~nbump~\u224E\u0338~nbumpe~\u224F\u0338~ncap~\u2A43~ncaron~\u0148~ncedil~\u0146~ncong~\u2247~ncongdot~\u2A6D\u0338~ncup~\u2A42~ncy~\u043D~neArr~\u21D7~nearhk~\u2924~nearr~\u2197~nearrow~\u2197~nedot~\u2250\u0338~nequiv~\u2262~nesear~\u2928~nesim~\u2242\u0338~nexist~\u2204~nexists~\u2204~nfr~\u{1D52B}~ngE~\u2267\u0338~nge~\u2271~ngeq~\u2271~ngeqq~\u2267\u0338~ngeqslant~\u2A7E\u0338~nges~\u2A7E\u0338~ngsim~\u2275~ngt~\u226F~ngtr~\u226F~nhArr~\u21CE~nharr~\u21AE~nhpar~\u2AF2~nis~\u22FC~nisd~\u22FA~niv~\u220B~njcy~\u045A~nlArr~\u21CD~nlE~\u2266\u0338~nlarr~\u219A~nldr~\u2025~nle~\u2270~nleftarrow~\u219A~nleftrightarrow~\u21AE~nleq~\u2270~nleqq~\u2266\u0338~nleqslant~\u2A7D\u0338~nles~\u2A7D\u0338~nless~\u226E~nlsim~\u2274~nlt~\u226E~nltri~\u22EA~nltrie~\u22EC~nmid~\u2224~nopf~\u{1D55F}~notinE~\u22F9\u0338~notindot~\u22F5\u0338~notinva~\u2209~notinvb~\u22F7~notinvc~\u22F6~notni~\u220C~notniva~\u220C~notnivb~\u22FE~notnivc~\u22FD~npar~\u2226~nparallel~\u2226~nparsl~\u2AFD\u20E5~npart~\u2202\u0338~npolint~\u2A14~npr~\u2280~nprcue~\u22E0~npre~\u2AAF\u0338~nprec~\u2280~npreceq~\u2AAF\u0338~nrArr~\u21CF~nrarr~\u219B~nrarrc~\u2933\u0338~nrarrw~\u219D\u0338~nrightarrow~\u219B~nrtri~\u22EB~nrtrie~\u22ED~nsc~\u2281~nsccue~\u22E1~nsce~\u2AB0\u0338~nscr~\u{1D4C3}~nshortmid~\u2224~nshortparallel~\u2226~nsim~\u2241~nsime~\u2244~nsimeq~\u2244~nsmid~\u2224~nspar~\u2226~nsqsube~\u22E2~nsqsupe~\u22E3~nsubE~\u2AC5\u0338~nsube~\u2288~nsubset~\u2282\u20D2~nsubseteq~\u2288~nsubseteqq~\u2AC5\u0338~nsucc~\u2281~nsucceq~\u2AB0\u0338~nsup~\u2285~nsupE~\u2AC6\u0338~nsupe~\u2289~nsupset~\u2283\u20D2~nsupseteq~\u2289~nsupseteqq~\u2AC6\u0338~ntgl~\u2279~ntlg~\u2278~ntriangleleft~\u22EA~ntrianglelefteq~\u22EC~ntriangleright~\u22EB~ntrianglerighteq~\u22ED~num~#~numero~\u2116~numsp~\u2007~nvDash~\u22AD~nvHarr~\u2904~nvap~\u224D\u20D2~nvdash~\u22AC~nvge~\u2265\u20D2~nvgt~>\u20D2~nvinfin~\u29DE~nvlArr~\u2902~nvle~\u2264\u20D2~nvlt~<\u20D2~nvltrie~\u22B4\u20D2~nvrArr~\u2903~nvrtrie~\u22B5\u20D2~nvsim~\u223C\u20D2~nwArr~\u21D6~nwarhk~\u2923~nwarr~\u2196~nwarrow~\u2196~nwnear~\u2927~oS~\u24C8~oast~\u229B~ocir~\u229A~ocy~\u043E~odash~\u229D~odblac~\u0151~odiv~\u2A38~odot~\u2299~odsold~\u29BC~ofcir~\u29BF~ofr~\u{1D52C}~ogon~\u02DB~ogt~\u29C1~ohbar~\u29B5~ohm~\u03A9~oint~\u222E~olarr~\u21BA~olcir~\u29BE~olcross~\u29BB~olt~\u29C0~omacr~\u014D~omid~\u29B6~ominus~\u2296~oopf~\u{1D560}~opar~\u29B7~operp~\u29B9~orarr~\u21BB~ord~\u2A5D~order~\u2134~orderof~\u2134~origof~\u22B6~oror~\u2A56~orslope~\u2A57~orv~\u2A5B~oscr~\u2134~osol~\u2298~otimesas~\u2A36~ovbar~\u233D~par~\u2225~parallel~\u2225~parsim~\u2AF3~parsl~\u2AFD~pcy~\u043F~percnt~%~period~.~pertenk~\u2031~pfr~\u{1D52D}~phiv~\u03D5~phmmat~\u2133~phone~\u260E~pitchfork~\u22D4~planck~\u210F~planckh~\u210E~plankv~\u210F~plus~+~plusacir~\u2A23~plusb~\u229E~pluscir~\u2A22~plusdo~\u2214~plusdu~\u2A25~pluse~\u2A72~plussim~\u2A26~plustwo~\u2A27~pm~\xB1~pointint~\u2A15~popf~\u{1D561}~pr~\u227A~prE~\u2AB3~prap~\u2AB7~prcue~\u227C~pre~\u2AAF~prec~\u227A~precapprox~\u2AB7~preccurlyeq~\u227C~preceq~\u2AAF~precnapprox~\u2AB9~precneqq~\u2AB5~precnsim~\u22E8~precsim~\u227E~primes~\u2119~prnE~\u2AB5~prnap~\u2AB9~prnsim~\u22E8~profalar~\u232E~profline~\u2312~profsurf~\u2313~propto~\u221D~prsim~\u227E~prurel~\u22B0~pscr~\u{1D4C5}~puncsp~\u2008~qfr~\u{1D52E}~qint~\u2A0C~qopf~\u{1D562}~qprime~\u2057~qscr~\u{1D4C6}~quaternions~\u210D~quatint~\u2A16~quest~?~questeq~\u225F~rAarr~\u21DB~rAtail~\u291C~rBarr~\u290F~rHar~\u2964~race~\u223D\u0331~racute~\u0155~raemptyv~\u29B3~rangd~\u2992~range~\u29A5~rangle~\u27E9~rarrap~\u2975~rarrb~\u21E5~rarrbfs~\u2920~rarrc~\u2933~rarrfs~\u291E~rarrhk~\u21AA~rarrlp~\u21AC~rarrpl~\u2945~rarrsim~\u2974~rarrtl~\u21A3~rarrw~\u219D~ratail~\u291A~ratio~\u2236~rationals~\u211A~rbarr~\u290D~rbbrk~\u2773~rbrace~}~rbrack~]~rbrke~\u298C~rbrksld~\u298E~rbrkslu~\u2990~rcaron~\u0159~rcedil~\u0157~rcub~}~rcy~\u0440~rdca~\u2937~rdldhar~\u2969~rdquor~\u201D~rdsh~\u21B3~realine~\u211B~realpart~\u211C~reals~\u211D~rect~\u25AD~rfisht~\u297D~rfr~\u{1D52F}~rhard~\u21C1~rharu~\u21C0~rharul~\u296C~rhov~\u03F1~rightarrow~\u2192~rightarrowtail~\u21A3~rightharpoondown~\u21C1~rightharpoonup~\u21C0~rightleftarrows~\u21C4~rightleftharpoons~\u21CC~rightrightarrows~\u21C9~rightsquigarrow~\u219D~rightthreetimes~\u22CC~ring~\u02DA~risingdotseq~\u2253~rlarr~\u21C4~rlhar~\u21CC~rmoust~\u23B1~rmoustache~\u23B1~rnmid~\u2AEE~roang~\u27ED~roarr~\u21FE~robrk~\u27E7~ropar~\u2986~ropf~\u{1D563}~roplus~\u2A2E~rotimes~\u2A35~rpar~)~rpargt~\u2994~rppolint~\u2A12~rrarr~\u21C9~rscr~\u{1D4C7}~rsh~\u21B1~rsqb~]~rsquor~\u2019~rthree~\u22CC~rtimes~\u22CA~rtri~\u25B9~rtrie~\u22B5~rtrif~\u25B8~rtriltri~\u29CE~ruluhar~\u2968~rx~\u211E~sacute~\u015B~sc~\u227B~scE~\u2AB4~scap~\u2AB8~sccue~\u227D~sce~\u2AB0~scedil~\u015F~scirc~\u015D~scnE~\u2AB6~scnap~\u2ABA~scnsim~\u22E9~scpolint~\u2A13~scsim~\u227F~scy~\u0441~sdotb~\u22A1~sdote~\u2A66~seArr~\u21D8~searhk~\u2925~searr~\u2198~searrow~\u2198~semi~;~seswar~\u2929~setminus~\u2216~setmn~\u2216~sext~\u2736~sfr~\u{1D530}~sfrown~\u2322~sharp~\u266F~shchcy~\u0449~shcy~\u0448~shortmid~\u2223~shortparallel~\u2225~sigmav~\u03C2~simdot~\u2A6A~sime~\u2243~simeq~\u2243~simg~\u2A9E~simgE~\u2AA0~siml~\u2A9D~simlE~\u2A9F~simne~\u2246~simplus~\u2A24~simrarr~\u2972~slarr~\u2190~smallsetminus~\u2216~smashp~\u2A33~smeparsl~\u29E4~smid~\u2223~smile~\u2323~smt~\u2AAA~smte~\u2AAC~smtes~\u2AAC\uFE00~softcy~\u044C~sol~/~solb~\u29C4~solbar~\u233F~sopf~\u{1D564}~spadesuit~\u2660~spar~\u2225~sqcap~\u2293~sqcaps~\u2293\uFE00~sqcup~\u2294~sqcups~\u2294\uFE00~sqsub~\u228F~sqsube~\u2291~sqsubset~\u228F~sqsubseteq~\u2291~sqsup~\u2290~sqsupe~\u2292~sqsupset~\u2290~sqsupseteq~\u2292~squ~\u25A1~square~\u25A1~squarf~\u25AA~squf~\u25AA~srarr~\u2192~sscr~\u{1D4C8}~ssetmn~\u2216~ssmile~\u2323~sstarf~\u22C6~star~\u2606~starf~\u2605~straightepsilon~\u03F5~straightphi~\u03D5~strns~\xAF~subE~\u2AC5~subdot~\u2ABD~subedot~\u2AC3~submult~\u2AC1~subnE~\u2ACB~subne~\u228A~subplus~\u2ABF~subrarr~\u2979~subset~\u2282~subseteq~\u2286~subseteqq~\u2AC5~subsetneq~\u228A~subsetneqq~\u2ACB~subsim~\u2AC7~subsub~\u2AD5~subsup~\u2AD3~succ~\u227B~succapprox~\u2AB8~succcurlyeq~\u227D~succeq~\u2AB0~succnapprox~\u2ABA~succneqq~\u2AB6~succnsim~\u22E9~succsim~\u227F~sung~\u266A~supE~\u2AC6~supdot~\u2ABE~supdsub~\u2AD8~supedot~\u2AC4~suphsol~\u27C9~suphsub~\u2AD7~suplarr~\u297B~supmult~\u2AC2~supnE~\u2ACC~supne~\u228B~supplus~\u2AC0~supset~\u2283~supseteq~\u2287~supseteqq~\u2AC6~supsetneq~\u228B~supsetneqq~\u2ACC~supsim~\u2AC8~supsub~\u2AD4~supsup~\u2AD6~swArr~\u21D9~swarhk~\u2926~swarr~\u2199~swarrow~\u2199~swnwar~\u292A~target~\u2316~tbrk~\u23B4~tcaron~\u0165~tcedil~\u0163~tcy~\u0442~tdot~\u20DB~telrec~\u2315~tfr~\u{1D531}~therefore~\u2234~thetav~\u03D1~thickapprox~\u2248~thicksim~\u223C~thkap~\u2248~thksim~\u223C~timesb~\u22A0~timesbar~\u2A31~timesd~\u2A30~tint~\u222D~toea~\u2928~top~\u22A4~topbot~\u2336~topcir~\u2AF1~topf~\u{1D565}~topfork~\u2ADA~tosa~\u2929~tprime~\u2034~triangle~\u25B5~triangledown~\u25BF~triangleleft~\u25C3~trianglelefteq~\u22B4~triangleq~\u225C~triangleright~\u25B9~trianglerighteq~\u22B5~tridot~\u25EC~trie~\u225C~triminus~\u2A3A~triplus~\u2A39~trisb~\u29CD~tritime~\u2A3B~trpezium~\u23E2~tscr~\u{1D4C9}~tscy~\u0446~tshcy~\u045B~tstrok~\u0167~twixt~\u226C~twoheadleftarrow~\u219E~twoheadrightarrow~\u21A0~uHar~\u2963~ubrcy~\u045E~ubreve~\u016D~ucy~\u0443~udarr~\u21C5~udblac~\u0171~udhar~\u296E~ufisht~\u297E~ufr~\u{1D532}~uharl~\u21BF~uharr~\u21BE~uhblk~\u2580~ulcorn~\u231C~ulcorner~\u231C~ulcrop~\u230F~ultri~\u25F8~umacr~\u016B~uogon~\u0173~uopf~\u{1D566}~uparrow~\u2191~updownarrow~\u2195~upharpoonleft~\u21BF~upharpoonright~\u21BE~uplus~\u228E~upsi~\u03C5~upuparrows~\u21C8~urcorn~\u231D~urcorner~\u231D~urcrop~\u230E~uring~\u016F~urtri~\u25F9~uscr~\u{1D4CA}~utdot~\u22F0~utilde~\u0169~utri~\u25B5~utrif~\u25B4~uuarr~\u21C8~uwangle~\u29A7~vArr~\u21D5~vBar~\u2AE8~vBarv~\u2AE9~vDash~\u22A8~vangrt~\u299C~varepsilon~\u03F5~varkappa~\u03F0~varnothing~\u2205~varphi~\u03D5~varpi~\u03D6~varpropto~\u221D~varr~\u2195~varrho~\u03F1~varsigma~\u03C2~varsubsetneq~\u228A\uFE00~varsubsetneqq~\u2ACB\uFE00~varsupsetneq~\u228B\uFE00~varsupsetneqq~\u2ACC\uFE00~vartheta~\u03D1~vartriangleleft~\u22B2~vartriangleright~\u22B3~vcy~\u0432~vdash~\u22A2~vee~\u2228~veebar~\u22BB~veeeq~\u225A~vellip~\u22EE~verbar~|~vert~|~vfr~\u{1D533}~vltri~\u22B2~vnsub~\u2282\u20D2~vnsup~\u2283\u20D2~vopf~\u{1D567}~vprop~\u221D~vrtri~\u22B3~vscr~\u{1D4CB}~vsubnE~\u2ACB\uFE00~vsubne~\u228A\uFE00~vsupnE~\u2ACC\uFE00~vsupne~\u228B\uFE00~vzigzag~\u299A~wcirc~\u0175~wedbar~\u2A5F~wedge~\u2227~wedgeq~\u2259~wfr~\u{1D534}~wopf~\u{1D568}~wp~\u2118~wr~\u2240~wreath~\u2240~wscr~\u{1D4CC}~xcap~\u22C2~xcirc~\u25EF~xcup~\u22C3~xdtri~\u25BD~xfr~\u{1D535}~xhArr~\u27FA~xharr~\u27F7~xlArr~\u27F8~xlarr~\u27F5~xmap~\u27FC~xnis~\u22FB~xodot~\u2A00~xopf~\u{1D569}~xoplus~\u2A01~xotime~\u2A02~xrArr~\u27F9~xrarr~\u27F6~xscr~\u{1D4CD}~xsqcup~\u2A06~xuplus~\u2A04~xutri~\u25B3~xvee~\u22C1~xwedge~\u22C0~yacy~\u044F~ycirc~\u0177~ycy~\u044B~yfr~\u{1D536}~yicy~\u0457~yopf~\u{1D56A}~yscr~\u{1D4CE}~yucy~\u044E~zacute~\u017A~zcaron~\u017E~zcy~\u0437~zdot~\u017C~zeetrf~\u2128~zfr~\u{1D537}~zhcy~\u0436~zigrarr~\u21DD~zopf~\u{1D56B}~zscr~\u{1D4CF}~~AMP~&~COPY~\xA9~GT~>~LT~<~QUOT~"~REG~\xAE', le.html4);

// node_modules/html-entities/dist/esm/numeric-unicode-map.js
var ri = {
  0: 65533,
  128: 8364,
  130: 8218,
  131: 402,
  132: 8222,
  133: 8230,
  134: 8224,
  135: 8225,
  136: 710,
  137: 8240,
  138: 352,
  139: 8249,
  140: 338,
  142: 381,
  145: 8216,
  146: 8217,
  147: 8220,
  148: 8221,
  149: 8226,
  150: 8211,
  151: 8212,
  152: 732,
  153: 8482,
  154: 353,
  155: 8250,
  156: 339,
  158: 382,
  159: 376
};

// node_modules/html-entities/dist/esm/surrogate-pairs.js
var ni = String.fromCodePoint || function(r) {
  return String.fromCharCode(Math.floor((r - 65536) / 1024) + 55296, (r - 65536) % 1024 + 56320);
}, gn = String.prototype.codePointAt ? function(r, e) {
  return r.codePointAt(e);
} : function(r, e) {
  return (r.charCodeAt(e) - 55296) * 1024 + r.charCodeAt(e + 1) - 56320 + 65536;
};

// node_modules/html-entities/dist/esm/index.js
var we = function() {
  return we = Object.assign || function(r) {
    for (var e, t = 1, i = arguments.length; t < i; t++) {
      e = arguments[t];
      for (var n in e) Object.prototype.hasOwnProperty.call(e, n) && (r[n] = e[n]);
    }
    return r;
  }, we.apply(this, arguments);
}, xn = we(we({}, le), { all: le.html5 });
var yn = {
  scope: "body",
  level: "all"
}, vt = /&(?:#\d+|#[xX][\da-fA-F]+|[0-9a-zA-Z]+);/g, bt = /&(?:#\d+|#[xX][\da-fA-F]+|[0-9a-zA-Z]+)[;=]?/g, si = {
  xml: {
    strict: vt,
    attribute: bt,
    body: Ke.xml
  },
  html4: {
    strict: vt,
    attribute: bt,
    body: Ke.html4
  },
  html5: {
    strict: vt,
    attribute: bt,
    body: Ke.html5
  }
}, vn = we(we({}, si), { all: si.html5 }), ai = String.fromCharCode, bn = ai(65533);
function wn(r, e, t, i) {
  var n = r, s = r[r.length - 1];
  if (t && s === "=")
    n = r;
  else if (i && s !== ";")
    n = r;
  else {
    var c = e[r];
    if (c)
      n = c;
    else if (r[0] === "&" && r[1] === "#") {
      var a = r[2], o = a == "x" || a == "X" ? parseInt(r.substr(3), 16) : parseInt(r.substr(2));
      n = o >= 1114111 ? bn : o > 65535 ? ni(o) : ai(ri[o] || o);
    }
  }
  return n;
}
d(wn, "getDecodedEntity");
function oi(r, e) {
  var t = e === void 0 ? yn : e, i = t.level, n = i === void 0 ? "all" : i, s = t.scope, c = s === void 0 ? n === "xml" ? "strict" : "body" : s;
  if (!r)
    return "";
  var a = vn[n][c], o = xn[n].entities, l = c === "attribute", p = c === "strict";
  return r.replace(a, function(u) {
    return wn(u, o, l, p);
  });
}
d(oi, "decode");

// node_modules/@google-cloud/storage/build/esm/src/nodejs-common/util.js
var Et = v(Oe(), 1), At = v(on(), 1), _t = v(cn(), 1);
import { Transform as In } from "stream";

// node_modules/@google-cloud/storage/build/esm/src/util.js
import * as pi from "querystring";
import { PassThrough as Tn } from "stream";
var di = v(Ee(), 1);
var Rn = !0;
function U(r, e) {
  return { options: typeof r == "object" ? r : {}, callback: typeof r == "function" ? r : e };
}
d(U, "normalize");
function wt(r) {
  return Object.keys(r).map((e) => [e, r[e]]);
}
d(wt, "objectEntries");
function Nn(r) {
  return encodeURIComponent(r).replace(/[!'()*]/g, (e) => "%" + e.charCodeAt(0).toString(16).toUpperCase());
}
d(Nn, "fixedEncodeURIComponent");
function Le(r, e) {
  return r.split("/").map(Nn).join(e ? "%2F" : "/");
}
d(Le, "encodeURI");
function ui(r) {
  return pi.stringify(r, "&", "=", {
    encodeURIComponent: /* @__PURE__ */ d((e) => Le(e, !0), "encodeURIComponent")
  });
}
d(ui, "qsStringify");
function fi(r) {
  let e = {};
  for (let t of Object.keys(r)) {
    let i = r[t];
    t = t.toLowerCase(), e[t] = i;
  }
  return e;
}
d(fi, "objectKeyToLowercase");
function mi(r) {
  return JSON.stringify(r).replace(/[\u0080-\uFFFF]/g, (e) => "\\u" + ("0000" + e.charCodeAt(0).toString(16)).slice(-4));
}
d(mi, "unicodeJSONStringify");
function We(r) {
  return r instanceof Date || r instanceof RegExp ? r : Array.isArray(r) ? r.map(We) : r instanceof Object ? Object.keys(r).reduce((e, t) => {
    let i = t[0].toLocaleLowerCase() + t.slice(1).replace(/([A-Z]+)/g, (n, s) => `_${s.toLowerCase()}`);
    return e[i] = We(r[t]), e;
  }, Object()) : r;
}
d(We, "convertObjKeysToSnakeCase");
function pe(r, e = !1, t = "", i = "") {
  let n = r.getUTCFullYear(), s = r.getUTCMonth() + 1, c = r.getUTCDate(), a = r.getUTCHours(), o = r.getUTCMinutes(), l = r.getUTCSeconds(), p = `${n.toString().padStart(4, "0")}${t}${s.toString().padStart(2, "0")}${t}${c.toString().padStart(2, "0")}`;
  return e && (p = `${p}T${a.toString().padStart(2, "0")}${i}${o.toString().padStart(2, "0")}${i}${l.toString().padStart(2, "0")}Z`), p;
}
d(pe, "formatAsUTCISO");
function z() {
  return (
    // eslint-disable-next-line @typescript-eslint/ban-ts-comment
    // @ts-ignore
    globalThis.Deno && // eslint-disable-next-line @typescript-eslint/ban-ts-comment
    // @ts-ignore
    globalThis.Deno.version && // eslint-disable-next-line @typescript-eslint/ban-ts-comment
    // @ts-ignore
    globalThis.Deno.version.deno ? `gl-deno/${globalThis.Deno.version.deno}` : `gl-node/${process.versions.node}`
  );
}
d(z, "getRuntimeTrackingString");
function V() {
  let r = (0, di.getPackageJSON)();
  return r.name.replace("@google-cloud", "gcloud-node").replace("/", "-") + "/" + r.version;
}
d(V, "getUserAgentString");
function te() {
  return Rn ? "ESM" : "CJS";
}
d(te, "getModuleFormat");
var Ce = class extends Tn {
  static {
    d(this, "PassThroughShim");
  }
  constructor() {
    super(...arguments), this.shouldEmitReading = !0, this.shouldEmitWriting = !0;
  }
  _read(e) {
    this.shouldEmitReading && (this.emit("reading"), this.shouldEmitReading = !1), super._read(e);
  }
  _write(e, t, i) {
    this.shouldEmitWriting && (this.emit("writing"), this.shouldEmitWriting = !1), process.nextTick(() => {
      super._write(e, t, i);
    });
  }
  _final(e) {
    this.shouldEmitReading && (this.emit("reading"), this.shouldEmitReading = !1), this.shouldEmitWriting && (this.emit("writing"), this.shouldEmitWriting = !1), e(null);
  }
};

// node_modules/@google-cloud/storage/build/esm/src/nodejs-common/util.js
var hi = v(Zt(), 1), gi = v(Ee(), 1);
var Sn = (0, gi.getPackageJSON)(), T = Symbol.for("GCCL_GCS_CMD"), Xe = {
  timeout: 6e4,
  gzip: !0,
  forever: !0,
  pool: {
    maxSockets: 1 / 0
  }
}, qn = !0, Pn = 3, ie = class r extends Error {
  static {
    d(this, "ApiError");
  }
  constructor(e) {
    if (super(), typeof e != "object") {
      this.message = e || "";
      return;
    }
    let t = e;
    this.code = t.code, this.errors = t.errors, this.response = t.response;
    try {
      this.errors = JSON.parse(this.response.body).error.errors;
    } catch {
      this.errors = t.errors;
    }
    this.message = r.createMultiErrorMessage(t, this.errors), Error.captureStackTrace(this);
  }
  /**
   * Pieces together an error message by combining all unique error messages
   * returned from a single GoogleError
   *
   * @private
   *
   * @param {GoogleErrorBody} err The original error.
   * @param {GoogleInnerError[]} [errors] Inner errors, if any.
   * @returns {string}
   */
  static createMultiErrorMessage(e, t) {
    let i = /* @__PURE__ */ new Set();
    e.message && i.add(e.message), t && t.length ? t.forEach(({ message: s }) => i.add(s)) : e.response && e.response.body ? i.add(oi(e.response.body.toString())) : e.message || i.add("A failure occurred during this request.");
    let n = Array.from(i);
    return n.length > 1 && (n = n.map((s, c) => `    ${c + 1}. ${s}`), n.unshift("Multiple errors occurred during the request. Please see the `errors` array for complete details.\n"), n.push(`
`)), n.join(`
`);
  }
}, Tt = class extends Error {
  static {
    d(this, "PartialFailureError");
  }
  constructor(e) {
    super();
    let t = e;
    this.errors = t.errors, this.name = "PartialFailureError", this.response = t.response, this.message = ie.createMultiErrorMessage(t, this.errors);
  }
}, Rt = class {
  static {
    d(this, "Util");
  }
  constructor() {
    this.ApiError = ie, this.PartialFailureError = Tt;
  }
  /**
   * No op.
   *
   * @example
   * function doSomething(callback) {
   *   callback = callback || noop;
   * }
   */
  noop() {
  }
  /**
   * Uniformly process an API response.
   *
   * @param {*} err - Error value.
   * @param {*} resp - Response value.
   * @param {*} body - Body value.
   * @param {function} callback - The callback function.
   */
  handleResp(e, t, i, n) {
    n = n || b.noop;
    let s = {
      err: e || null,
      ...t && b.parseHttpRespMessage(t),
      ...i && b.parseHttpRespBody(i)
    };
    !s.err && t && typeof s.body == "object" && (s.resp.body = s.body), s.err && t && (s.err.response = t), n(s.err, s.body, s.resp);
  }
  /**
   * Sniff an incoming HTTP response message for errors.
   *
   * @param {object} httpRespMessage - An incoming HTTP response message from `request`.
   * @return {object} parsedHttpRespMessage - The parsed response.
   * @param {?error} parsedHttpRespMessage.err - An error detected.
   * @param {object} parsedHttpRespMessage.resp - The original response object.
   */
  parseHttpRespMessage(e) {
    let t = {
      resp: e
    };
    return (e.statusCode < 200 || e.statusCode > 299) && (t.err = new ie({
      errors: new Array(),
      code: e.statusCode,
      message: e.statusMessage,
      response: e
    })), t;
  }
  /**
   * Parse the response body from an HTTP request.
   *
   * @param {object} body - The response body.
   * @return {object} parsedHttpRespMessage - The parsed response.
   * @param {?error} parsedHttpRespMessage.err - An error detected.
   * @param {object} parsedHttpRespMessage.body - The original body value provided
   *     will try to be JSON.parse'd. If it's successful, the parsed value will
   * be returned here, otherwise the original value and an error will be returned.
   */
  parseHttpRespBody(e) {
    let t = {
      body: e
    };
    if (typeof e == "string")
      try {
        t.body = JSON.parse(e);
      } catch {
        t.body = e;
      }
    return t.body && t.body.error && (t.err = new ie(t.body.error)), t;
  }
  /**
   * Take a Duplexify stream, fetch an authenticated connection header, and
   * create an outgoing writable stream.
   *
   * @param {Duplexify} dup - Duplexify stream.
   * @param {object} options - Configuration object.
   * @param {module:common/connection} options.connection - A connection instance used to get a token with and send the request through.
   * @param {object} options.metadata - Metadata to send at the head of the request.
   * @param {object} options.request - Request object, in the format of a standard Node.js http.request() object.
   * @param {string=} options.request.method - Default: "POST".
   * @param {string=} options.request.qs.uploadType - Default: "multipart".
   * @param {string=} options.streamContentType - Default: "application/octet-stream".
   * @param {function} onComplete - Callback, executed after the writable Request stream has completed.
   */
  makeWritableStream(e, t, i) {
    var n;
    i = i || b.noop;
    let s = new Nt();
    s.on("progress", (l) => e.emit("progress", l)), e.setWritable(s);
    let c = {
      method: "POST",
      qs: {
        uploadType: "multipart"
      },
      timeout: 0,
      maxRetries: 0
    }, a = t.metadata || {}, o = {
      ...c,
      ...t.request,
      qs: {
        ...c.qs,
        ...(n = t.request) === null || n === void 0 ? void 0 : n.qs
      },
      multipart: [
        {
          "Content-Type": "application/json",
          body: JSON.stringify(a)
        },
        {
          "Content-Type": a.contentType || "application/octet-stream",
          body: s
        }
      ]
    };
    t.makeAuthenticatedRequest(o, {
      onAuthenticated(l, p) {
        if (l) {
          e.destroy(l);
          return;
        }
        Xe.headers = b._getDefaultHeaders(o[T]), _t.teenyRequest.defaults(Xe)(p, (f, m, h) => {
          b.handleResp(f, m, h, (g, y) => {
            if (g) {
              e.destroy(g);
              return;
            }
            e.emit("response", m), i(y);
          });
        });
      }
    });
  }
  /**
   * Returns true if the API request should be retried, given the error that was
   * given the first time the request was attempted. This is used for rate limit
   * related errors as well as intermittent server errors.
   *
   * @param {error} err - The API error to check if it is appropriate to retry.
   * @return {boolean} True if the API request should be retried, false otherwise.
   */
  shouldRetryRequest(e) {
    if (e) {
      if ([408, 429, 500, 502, 503, 504].indexOf(e.code) !== -1)
        return !0;
      if (e.errors)
        for (let t of e.errors) {
          let i = t.reason;
          if (i === "rateLimitExceeded" || i === "userRateLimitExceeded" || i && i.includes("EAI_AGAIN"))
            return !0;
        }
    }
    return !1;
  }
  /**
   * Get a function for making authenticated requests.
   *
   * @param {object} config - Configuration object.
   * @param {boolean=} config.autoRetry - Automatically retry requests if the
   *     response is related to rate limits or certain intermittent server
   * errors. We will exponentially backoff subsequent requests by default.
   * (default: true)
   * @param {object=} config.credentials - Credentials object.
   * @param {boolean=} config.customEndpoint - If true, just return the provided request options. Default: false.
   * @param {boolean=} config.useAuthWithCustomEndpoint - If true, will authenticate when using a custom endpoint. Default: false.
   * @param {string=} config.email - Account email address, required for PEM/P12 usage.
   * @param {number=} config.maxRetries - Maximum number of automatic retries attempted before returning the error. (default: 3)
   * @param {string=} config.keyFile - Path to a .json, .pem, or .p12 keyfile.
   * @param {array} config.scopes - Array of scopes required for the API.
   */
  makeAuthenticatedRequestFactory(e) {
    let t = { ...e };
    t.projectId === Ae && delete t.projectId;
    let i;
    t.authClient instanceof Et.GoogleAuth ? i = t.authClient : i = new Et.GoogleAuth({
      ...t,
      authClient: t.authClient,
      clientOptions: t.clientOptions
    });
    function n(c, a) {
      let o, l, p = { ...e }, u;
      a || (o = (0, hi.default)(), p.stream = o);
      let f = typeof a == "object" ? a : void 0, m = typeof a == "function" ? a : void 0;
      async function h() {
        l = await i.getProjectId();
      }
      d(h, "setProjectId");
      let g = /* @__PURE__ */ d(async (x, w) => {
        let N = x, q = x && typeof x.message == "string" && x.message.indexOf("Could not load the default credentials") > -1;
        if (q && (w = c), !x || q)
          try {
            w = b.decorateRequest(w, l), x = null;
          } catch (A) {
            if (A instanceof de.MissingProjectIdError)
              try {
                await h(), w = b.decorateRequest(w, l), x = null;
              } catch (j) {
                x = x || j;
              }
            else
              x = x || A;
          }
        if (x) {
          o ? o.destroy(x) : (f && f.onAuthenticated ? f.onAuthenticated : m)(x);
          return;
        }
        f && f.onAuthenticated ? f.onAuthenticated(null, w) : u = b.makeRequest(w, p, (A, ...j) => {
          A && A.code === 401 && N && (A = N), m(A, ...j);
        });
      }, "onAuthenticated");
      return (/* @__PURE__ */ d(async () => {
        try {
          let x = /* @__PURE__ */ d(async () => e.projectId && e.projectId !== Ae ? e.projectId : e.projectIdRequired === !1 ? Ae : h(), "getProjectId"), w = /* @__PURE__ */ d(async () => p.customEndpoint && !p.useAuthWithCustomEndpoint ? c : i.authorizeRequest(c), "authorizeRequest"), [N, q] = await Promise.all([
            x(),
            w()
          ]);
          return N && (l = N), g(null, q);
        } catch (x) {
          return g(x);
        }
      }, "prepareRequest"))(), o || {
        abort() {
          setImmediate(() => {
            u && (u.abort(), u = null);
          });
        }
      };
    }
    d(n, "makeAuthenticatedRequest");
    let s = n;
    return s.getCredentials = i.getCredentials.bind(i), s.authClient = i, s;
  }
  /**
   * Make a request through the `retryRequest` module with built-in error
   * handling and exponential back off.
   *
   * @param {object} reqOpts - Request options in the format `request` expects.
   * @param {object=} config - Configuration object.
   * @param {boolean=} config.autoRetry - Automatically retry requests if the
   *     response is related to rate limits or certain intermittent server
   * errors. We will exponentially backoff subsequent requests by default.
   * (default: true)
   * @param {number=} config.maxRetries - Maximum number of automatic retries
   *     attempted before returning the error. (default: 3)
   * @param {object=} config.request - HTTP module for request calls.
   * @param {function} callback - The callback function.
   */
  makeRequest(e, t, i) {
    var n, s, c, a, o;
    let l = qn;
    t.autoRetry !== void 0 ? l = t.autoRetry : ((n = t.retryOptions) === null || n === void 0 ? void 0 : n.autoRetry) !== void 0 && (l = t.retryOptions.autoRetry);
    let p = Pn;
    t.maxRetries !== void 0 ? p = t.maxRetries : ((s = t.retryOptions) === null || s === void 0 ? void 0 : s.maxRetries) !== void 0 && (p = t.retryOptions.maxRetries), Xe.headers = this._getDefaultHeaders(e[T]);
    let u = {
      request: _t.teenyRequest.defaults(Xe),
      retries: l !== !1 ? p : 0,
      noResponseRetries: l !== !1 ? p : 0,
      shouldRetryFn(g) {
        var y, x;
        let w = b.parseHttpRespMessage(g).err;
        return !((y = t.retryOptions) === null || y === void 0) && y.retryableErrorFn ? w && ((x = t.retryOptions) === null || x === void 0 ? void 0 : x.retryableErrorFn(w)) : w && b.shouldRetryRequest(w);
      },
      maxRetryDelay: (c = t.retryOptions) === null || c === void 0 ? void 0 : c.maxRetryDelay,
      retryDelayMultiplier: (a = t.retryOptions) === null || a === void 0 ? void 0 : a.retryDelayMultiplier,
      totalTimeout: (o = t.retryOptions) === null || o === void 0 ? void 0 : o.totalTimeout
    };
    if (typeof e.maxRetries == "number" && (u.retries = e.maxRetries, u.noResponseRetries = e.maxRetries), !t.stream)
      return (0, At.default)(
        e,
        u,
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        (g, y, x) => {
          b.handleResp(g, y, x, i);
        }
      );
    let f = t.stream, m;
    return (e.method || "GET").toUpperCase() === "GET" ? (m = (0, At.default)(e, u), f.setReadable(m)) : (m = u.request(e), f.setWritable(m)), m.on("error", f.destroy.bind(f)).on("response", f.emit.bind(f, "response")).on("complete", f.emit.bind(f, "complete")), f.abort = m.abort, f;
  }
  /**
   * Decorate the options about to be made in a request.
   *
   * @param {object} reqOpts - The options to be passed to `request`.
   * @param {string} projectId - The project ID.
   * @return {object} reqOpts - The decorated reqOpts.
   */
  decorateRequest(e, t) {
    return delete e.autoPaginate, delete e.autoPaginateVal, delete e.objectMode, e.qs !== null && typeof e.qs == "object" && (delete e.qs.autoPaginate, delete e.qs.autoPaginateVal, e.qs = (0, de.replaceProjectIdToken)(e.qs, t)), Array.isArray(e.multipart) && (e.multipart = e.multipart.map((i) => (0, de.replaceProjectIdToken)(i, t))), e.json !== null && typeof e.json == "object" && (delete e.json.autoPaginate, delete e.json.autoPaginateVal, e.json = (0, de.replaceProjectIdToken)(e.json, t)), e.uri = (0, de.replaceProjectIdToken)(e.uri, t), e;
  }
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  isCustomType(e, t) {
    function i(o) {
      return o.constructor && o.constructor.name.toLowerCase();
    }
    d(i, "getConstructorName");
    let n = t.split("/"), s = n[0] && n[0].toLowerCase(), c = n[1] && n[1].toLowerCase();
    if (c && i(e) !== c)
      return !1;
    let a = e;
    for (; ; ) {
      if (i(a) === s)
        return !0;
      if (a = a.parent, !a)
        return !1;
    }
  }
  /**
   * Given two parameters, figure out if this is either:
   *  - Just a callback function
   *  - An options object, and then a callback function
   * @param optionsOrCallback An options object or callback.
   * @param cb A potentially undefined callback.
   */
  maybeOptionsOrCallback(e, t) {
    return typeof e == "function" ? [{}, e] : [e, t];
  }
  _getDefaultHeaders(e) {
    let t = {
      "User-Agent": V(),
      "x-goog-api-client": `${z()} gccl/${Sn.version}-${te()} gccl-invocation-id/${k()}`
    };
    return e && (t["x-goog-api-client"] += ` gccl-gcs-cmd/${e}`), t;
  }
}, Nt = class extends In {
  static {
    d(this, "ProgressStream");
  }
  constructor() {
    super(...arguments), this.bytesRead = 0;
  }
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  _transform(e, t, i) {
    this.bytesRead += e.length, this.emit("progress", { bytesWritten: this.bytesRead, contentLength: "*" }), this.push(e), i();
  }
}, b = new Rt();

// node_modules/@google-cloud/storage/build/esm/src/nodejs-common/service.js
var Ae = "{{projectId}}", ke = class r {
  static {
    d(this, "Service");
  }
  /**
   * Service is a base class, meant to be inherited from by a "service," like
   * BigQuery or Storage.
   *
   * This handles making authenticated requests by exposing a `makeReq_`
   * function.
   *
   * @constructor
   * @alias module:common/service
   *
   * @param {object} config - Configuration object.
   * @param {string} config.baseUrl - The base URL to make API requests to.
   * @param {string[]} config.scopes - The scopes required for the request.
   * @param {object=} options - [Configuration object](#/docs).
   */
  constructor(e, t = {}) {
    this.baseUrl = e.baseUrl, this.apiEndpoint = e.apiEndpoint, this.timeout = t.timeout, this.globalInterceptors = Array.isArray(t.interceptors_) ? t.interceptors_ : [], this.interceptors = [], this.packageJson = e.packageJson, this.projectId = t.projectId || Ae, this.projectIdRequired = e.projectIdRequired !== !1, this.providedUserAgent = t.userAgent, this.universeDomain = t.universeDomain || xi.DEFAULT_UNIVERSE, this.customEndpoint = e.customEndpoint || !1, this.makeAuthenticatedRequest = b.makeAuthenticatedRequestFactory({
      ...e,
      projectIdRequired: this.projectIdRequired,
      projectId: this.projectId,
      authClient: t.authClient || e.authClient,
      credentials: t.credentials,
      keyFile: t.keyFilename,
      email: t.email,
      clientOptions: {
        universeDomain: t.universeDomain,
        ...t.clientOptions
      }
    }), this.authClient = this.makeAuthenticatedRequest.authClient, !!process.env.FUNCTION_NAME && this.interceptors.push({
      request(n) {
        return n.forever = !1, n;
      }
    });
  }
  /**
   * Return the user's custom request interceptors.
   */
  getRequestInterceptors() {
    return [].slice.call(this.globalInterceptors).concat(this.interceptors).filter((e) => typeof e.request == "function").map((e) => e.request);
  }
  getProjectId(e) {
    if (!e)
      return this.getProjectIdAsync();
    this.getProjectIdAsync().then((t) => e(null, t), e);
  }
  async getProjectIdAsync() {
    let e = await this.authClient.getProjectId();
    return this.projectId === Ae && e && (this.projectId = e), this.projectId;
  }
  request_(e, t) {
    e = { ...e, timeout: this.timeout };
    let i = e.uri.indexOf("http") === 0, n = [this.baseUrl];
    this.projectIdRequired && (e.projectId ? (n.push("projects"), n.push(e.projectId)) : (n.push("projects"), n.push(this.projectId))), n.push(e.uri), i && n.splice(0, n.indexOf(e.uri)), e.uri = n.map((l) => {
      let p = /^\/*|\/*$/g;
      return l.replace(p, "");
    }).join("/").replace(/\/:/g, ":");
    let s = this.getRequestInterceptors();
    (Array.isArray(e.interceptors_) ? e.interceptors_ : []).forEach((l) => {
      typeof l.request == "function" && s.push(l.request);
    }), s.forEach((l) => {
      e = l(e);
    }), delete e.interceptors_;
    let a = this.packageJson, o = V();
    if (this.providedUserAgent && (o = `${this.providedUserAgent} ${o}`), e.headers = {
      ...e.headers,
      "User-Agent": o,
      "x-goog-api-client": `${z()} gccl/${a.version}-${te()} gccl-invocation-id/${k()}`
    }, e[T] && (e.headers["x-goog-api-client"] += ` gccl-gcs-cmd/${e[T]}`), e.shouldReturnStream)
      return this.makeAuthenticatedRequest(e);
    this.makeAuthenticatedRequest(e, t);
  }
  /**
   * Make an authenticated API request.
   *
   * @param {object} reqOpts - Request options that are passed to `request`.
   * @param {string} reqOpts.uri - A URI relative to the baseUrl.
   * @param {function} callback - The callback function passed to `request`.
   */
  request(e, t) {
    r.prototype.request_.call(this, e, t);
  }
  /**
   * Make an authenticated API request.
   *
   * @param {object} reqOpts - Request options that are passed to `request`.
   * @param {string} reqOpts.uri - A URI relative to the baseUrl.
   */
  requestStream(e) {
    let t = { ...e, shouldReturnStream: !0 };
    return r.prototype.request_.call(this, t);
  }
};

// node_modules/@google-cloud/storage/build/esm/src/nodejs-common/service-object.js
var yi = v(W(), 1);
import { EventEmitter as jn } from "events";
var O = class r extends jn {
  static {
    d(this, "ServiceObject");
  }
  /*
   * @constructor
   * @alias module:common/service-object
   *
   * @private
   *
   * @param {object} config - Configuration object.
   * @param {string} config.baseUrl - The base URL to make API requests to.
   * @param {string} config.createMethod - The method which creates this object.
   * @param {string=} config.id - The identifier of the object. For example, the
   *     name of a Storage bucket or Pub/Sub topic.
   * @param {object=} config.methods - A map of each method name that should be inherited.
   * @param {object} config.methods[].reqOpts - Default request options for this
   *     particular method. A common use case is when `setMetadata` requires a
   *     `PUT` method to override the default `PATCH`.
   * @param {object} config.parent - The parent service instance. For example, an
   *     instance of Storage if the object is Bucket.
   */
  constructor(e) {
    super(), this.metadata = {}, this.baseUrl = e.baseUrl, this.parent = e.parent, this.id = e.id, this.createMethod = e.createMethod, this.methods = e.methods || {}, this.interceptors = [], this.projectId = e.projectId, e.methods && Object.getOwnPropertyNames(r.prototype).filter((t) => (
      // All ServiceObjects need `request` and `getRequestInterceptors`.
      // clang-format off
      !/^request/.test(t) && !/^getRequestInterceptors/.test(t) && // clang-format on
      // The ServiceObject didn't redefine the method.
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      this[t] === // eslint-disable-next-line @typescript-eslint/no-explicit-any
      r.prototype[t] && // This method isn't wanted.
      !e.methods[t]
    )).forEach((t) => {
      this[t] = void 0;
    });
  }
  create(e, t) {
    let i = this, n = [this.id];
    typeof e == "function" && (t = e), typeof e == "object" && n.push(e);
    function s(...c) {
      let [a, o] = c;
      a || (i.metadata = o.metadata, i.id && o.metadata && (i.id = o.metadata.id), c[1] = i), t(...c);
    }
    d(s, "onCreate"), n.push(s), this.createMethod.apply(null, n);
  }
  delete(e, t) {
    var i;
    let [n, s] = b.maybeOptionsOrCallback(e, t), c = n.ignoreNotFound;
    delete n.ignoreNotFound;
    let a = typeof this.methods.delete == "object" && this.methods.delete || {}, o = {
      method: "DELETE",
      uri: "",
      ...a.reqOpts,
      qs: {
        ...(i = a.reqOpts) === null || i === void 0 ? void 0 : i.qs,
        ...n
      }
    };
    r.prototype.request.call(this, o, (l, p, u) => {
      l && l.code === 404 && c && (l = null), s(l, u);
    });
  }
  exists(e, t) {
    let [i, n] = b.maybeOptionsOrCallback(e, t);
    this.get(i, (s) => {
      if (s) {
        s.code === 404 ? n(null, !1) : n(s);
        return;
      }
      n(null, !0);
    });
  }
  get(e, t) {
    let i = this, [n, s] = b.maybeOptionsOrCallback(e, t), c = Object.assign({}, n), a = c.autoCreate && typeof this.create == "function";
    delete c.autoCreate;
    function o(l, p, u) {
      if (l) {
        if (l.code === 409) {
          i.get(c, s);
          return;
        }
        s(l, null, u);
        return;
      }
      s(null, p, u);
    }
    d(o, "onCreate"), this.getMetadata(c, (l, p) => {
      if (l) {
        if (l.code === 404 && a) {
          let u = [];
          Object.keys(c).length > 0 && u.push(c), u.push(o), i.create(...u);
          return;
        }
        s(l, null, p);
        return;
      }
      s(null, i, p);
    });
  }
  getMetadata(e, t) {
    var i;
    let [n, s] = b.maybeOptionsOrCallback(e, t), c = typeof this.methods.getMetadata == "object" && this.methods.getMetadata || {}, a = {
      uri: "",
      ...c.reqOpts,
      qs: {
        ...(i = c.reqOpts) === null || i === void 0 ? void 0 : i.qs,
        ...n
      }
    };
    r.prototype.request.call(this, a, (o, l, p) => {
      this.metadata = l, s(o, this.metadata, p);
    });
  }
  /**
   * Return the user's custom request interceptors.
   */
  getRequestInterceptors() {
    let e = this.interceptors.filter((t) => typeof t.request == "function").map((t) => t.request);
    return this.parent.getRequestInterceptors().concat(e);
  }
  setMetadata(e, t, i) {
    var n, s;
    let [c, a] = b.maybeOptionsOrCallback(t, i), o = typeof this.methods.setMetadata == "object" && this.methods.setMetadata || {}, l = {
      method: "PATCH",
      uri: "",
      ...o.reqOpts,
      json: {
        ...(n = o.reqOpts) === null || n === void 0 ? void 0 : n.json,
        ...e
      },
      qs: {
        ...(s = o.reqOpts) === null || s === void 0 ? void 0 : s.qs,
        ...c
      }
    };
    r.prototype.request.call(this, l, (p, u, f) => {
      this.metadata = u, a(p, this.metadata, f);
    });
  }
  request_(e, t) {
    e = { ...e }, this.projectId && (e.projectId = this.projectId);
    let i = e.uri.indexOf("http") === 0, n = [this.baseUrl, this.id || "", e.uri];
    i && n.splice(0, n.indexOf(e.uri)), e.uri = n.filter((a) => a.trim()).map((a) => {
      let o = /^\/*|\/*$/g;
      return a.replace(o, "");
    }).join("/");
    let s = Array.isArray(e.interceptors_) ? e.interceptors_ : [], c = [].slice.call(this.interceptors);
    if (e.interceptors_ = s.concat(c), e.shouldReturnStream)
      return this.parent.requestStream(e);
    this.parent.request(e, t);
  }
  request(e, t) {
    this.request_(e, t);
  }
  /**
   * Make an authenticated API request.
   *
   * @param {object} reqOpts - Request options that are passed to `request`.
   * @param {string} reqOpts.uri - A URI relative to the baseUrl.
   */
  requestStream(e) {
    let t = { ...e, shouldReturnStream: !0 };
    return this.request_(t);
  }
};
(0, yi.promisifyAll)(O, { exclude: ["getRequestInterceptors"] });

// node_modules/@google-cloud/storage/build/esm/src/storage.js
var lt = v(St(), 1), mr = v(W(), 1);
import { Readable as fr } from "stream";

// node_modules/@google-cloud/storage/build/esm/src/bucket.js
var Gt = v(St(), 1), ar = v(W(), 1), cr = v(qt(), 1), Ft = v(Ot(), 1), pr = v(Ue(), 1);
import * as or from "fs";
import * as lr from "path";
import { promisify as sr } from "util";

// node_modules/@google-cloud/storage/build/esm/src/acl.js
var Mi = v(W(), 1);
var Te = class r {
  static {
    d(this, "AclRoleAccessorMethods");
  }
  constructor() {
    this.owners = {}, this.readers = {}, this.writers = {}, this.owners = {}, this.readers = {}, this.writers = {}, r.roles.forEach(this._assignAccessMethods.bind(this));
  }
  _assignAccessMethods(e) {
    let t = r.accessMethods, i = r.entities, n = e.toLowerCase() + "s";
    this[n] = i.reduce((s, c) => {
      let a = c.charAt(c.length - 1) === "-";
      return t.forEach((o) => {
        let l = o + c[0].toUpperCase() + c.substring(1);
        a && (l = l.replace("-", "")), s[l] = (p, u, f) => {
          let m;
          typeof u == "function" && (f = u, u = {}), a ? m = c + p : (m = c, f = p), u = Object.assign({
            entity: m,
            role: e
          }, u);
          let h = [u];
          return typeof f == "function" && h.push(f), this[o].apply(this, h);
        };
      }), s;
    }, {});
  }
};
Te.accessMethods = ["add", "delete"];
Te.entities = [
  // Special entity groups that do not require further specification.
  "allAuthenticatedUsers",
  "allUsers",
  // Entity groups that require specification, e.g. `user-email@example.com`.
  "domain-",
  "group-",
  "project-",
  "user-"
];
Te.roles = ["OWNER", "READER", "WRITER"];
var ne = class extends Te {
  static {
    d(this, "Acl");
  }
  constructor(e) {
    super(), this.pathPrefix = e.pathPrefix, this.request_ = e.request;
  }
  /**
   * @typedef {array} AddAclResponse
   * @property {object} 0 The Acl Objects.
   * @property {object} 1 The full API response.
   */
  /**
   * @callback AddAclCallback
   * @param {?Error} err Request error, if any.
   * @param {object} acl The Acl Objects.
   * @param {object} apiResponse The full API response.
   */
  /**
   * Add access controls on a {@link Bucket} or {@link File}.
   *
   * See {@link https://cloud.google.com/storage/docs/json_api/v1/bucketAccessControls/insert| BucketAccessControls: insert API Documentation}
   * See {@link https://cloud.google.com/storage/docs/json_api/v1/objectAccessControls/insert| ObjectAccessControls: insert API Documentation}
   *
   * @param {object} options Configuration options.
   * @param {string} options.entity Whose permissions will be added.
   * @param {string} options.role Permissions allowed for the defined entity.
   *     See {@link https://cloud.google.com/storage/docs/access-control Access
   * Control}.
   * @param {number} [options.generation] **File Objects Only** Select a specific
   *     revision of this file (as opposed to the latest version, the default).
   * @param {string} [options.userProject] The ID of the project which will be
   *     billed for the request.
   * @param {AddAclCallback} [callback] Callback function.
   * @returns {Promise<AddAclResponse>}
   *
   * @example
   * ```
   * const storage = require('@google-cloud/storage')();
   * const myBucket = storage.bucket('my-bucket');
   * const myFile = myBucket.file('my-file');
   *
   * const options = {
   *   entity: 'user-useremail@example.com',
   *   role: gcs.acl.OWNER_ROLE
   * };
   *
   * myBucket.acl.add(options, function(err, aclObject, apiResponse) {});
   *
   * //-
   * // For file ACL operations, you can also specify a `generation` property.
   * // Here is how you would grant ownership permissions to a user on a
   * specific
   * // revision of a file.
   * //-
   * myFile.acl.add({
   *   entity: 'user-useremail@example.com',
   *   role: gcs.acl.OWNER_ROLE,
   *   generation: 1
   * }, function(err, aclObject, apiResponse) {});
   *
   * //-
   * // If the callback is omitted, we'll return a Promise.
   * //-
   * myBucket.acl.add(options).then(function(data) {
   *   const aclObject = data[0];
   *   const apiResponse = data[1];
   * });
   *
   * ```
   * @example <caption>include:samples/acl.js</caption>
   * region_tag:storage_add_file_owner
   * Example of adding an owner to a file:
   *
   * @example <caption>include:samples/acl.js</caption>
   * region_tag:storage_add_bucket_owner
   * Example of adding an owner to a bucket:
   *
   * @example <caption>include:samples/acl.js</caption>
   * region_tag:storage_add_bucket_default_owner
   * Example of adding a default owner to a bucket:
   */
  add(e, t) {
    let i = {};
    e.generation && (i.generation = e.generation), e.userProject && (i.userProject = e.userProject), this.request({
      method: "POST",
      uri: "",
      qs: i,
      maxRetries: 0,
      //explicitly set this value since this is a non-idempotent function
      json: {
        entity: e.entity,
        role: e.role.toUpperCase()
      }
    }, (n, s) => {
      if (n) {
        t(n, null, s);
        return;
      }
      t(null, this.makeAclObject_(s), s);
    });
  }
  /**
   * @typedef {array} RemoveAclResponse
   * @property {object} 0 The full API response.
   */
  /**
   * @callback RemoveAclCallback
   * @param {?Error} err Request error, if any.
   * @param {object} apiResponse The full API response.
   */
  /**
   * Delete access controls on a {@link Bucket} or {@link File}.
   *
   * See {@link https://cloud.google.com/storage/docs/json_api/v1/bucketAccessControls/delete| BucketAccessControls: delete API Documentation}
   * See {@link https://cloud.google.com/storage/docs/json_api/v1/objectAccessControls/delete| ObjectAccessControls: delete API Documentation}
   *
   * @param {object} options Configuration object.
   * @param {string} options.entity Whose permissions will be revoked.
   * @param {int} [options.generation] **File Objects Only** Select a specific
   *     revision of this file (as opposed to the latest version, the default).
   * @param {string} [options.userProject] The ID of the project which will be
   *     billed for the request.
   * @param {RemoveAclCallback} callback The callback function.
   * @returns {Promise<RemoveAclResponse>}
   *
   * @example
   * ```
   * const storage = require('@google-cloud/storage')();
   * const myBucket = storage.bucket('my-bucket');
   * const myFile = myBucket.file('my-file');
   *
   * myBucket.acl.delete({
   *   entity: 'user-useremail@example.com'
   * }, function(err, apiResponse) {});
   *
   * //-
   * // For file ACL operations, you can also specify a `generation` property.
   * //-
   * myFile.acl.delete({
   *   entity: 'user-useremail@example.com',
   *   generation: 1
   * }, function(err, apiResponse) {});
   *
   * //-
   * // If the callback is omitted, we'll return a Promise.
   * //-
   * myFile.acl.delete().then(function(data) {
   *   const apiResponse = data[0];
   * });
   *
   * ```
   * @example <caption>include:samples/acl.js</caption>
   * region_tag:storage_remove_bucket_owner
   * Example of removing an owner from a bucket:
   *
   * @example <caption>include:samples/acl.js</caption>
   * region_tag:storage_remove_bucket_default_owner
   * Example of removing a default owner from a bucket:
   *
   * @example <caption>include:samples/acl.js</caption>
   * region_tag:storage_remove_file_owner
   * Example of removing an owner from a bucket:
   */
  delete(e, t) {
    let i = {};
    e.generation && (i.generation = e.generation), e.userProject && (i.userProject = e.userProject), this.request({
      method: "DELETE",
      uri: "/" + encodeURIComponent(e.entity),
      qs: i
    }, (n, s) => {
      t(n, s);
    });
  }
  /**
   * @typedef {array} GetAclResponse
   * @property {object|object[]} 0 Single or array of Acl Objects.
   * @property {object} 1 The full API response.
   */
  /**
   * @callback GetAclCallback
   * @param {?Error} err Request error, if any.
   * @param {object|object[]} acl Single or array of Acl Objects.
   * @param {object} apiResponse The full API response.
   */
  /**
   * Get access controls on a {@link Bucket} or {@link File}. If
   * an entity is omitted, you will receive an array of all applicable access
   * controls.
   *
   * See {@link https://cloud.google.com/storage/docs/json_api/v1/bucketAccessControls/get| BucketAccessControls: get API Documentation}
   * See {@link https://cloud.google.com/storage/docs/json_api/v1/objectAccessControls/get| ObjectAccessControls: get API Documentation}
   *
   * @param {object|function} [options] Configuration options. If you want to
   *     receive a list of all access controls, pass the callback function as
   * the only argument.
   * @param {string} options.entity Whose permissions will be fetched.
   * @param {number} [options.generation] **File Objects Only** Select a specific
   *     revision of this file (as opposed to the latest version, the default).
   * @param {string} [options.userProject] The ID of the project which will be
   *     billed for the request.
   * @param {GetAclCallback} [callback] Callback function.
   * @returns {Promise<GetAclResponse>}
   *
   * @example
   * ```
   * const storage = require('@google-cloud/storage')();
   * const myBucket = storage.bucket('my-bucket');
   * const myFile = myBucket.file('my-file');
   *
   * myBucket.acl.get({
   *   entity: 'user-useremail@example.com'
   * }, function(err, aclObject, apiResponse) {});
   *
   * //-
   * // Get all access controls.
   * //-
   * myBucket.acl.get(function(err, aclObjects, apiResponse) {
   *   // aclObjects = [
   *   //   {
   *   //     entity: 'user-useremail@example.com',
   *   //     role: 'owner'
   *   //   }
   *   // ]
   * });
   *
   * //-
   * // For file ACL operations, you can also specify a `generation` property.
   * //-
   * myFile.acl.get({
   *   entity: 'user-useremail@example.com',
   *   generation: 1
   * }, function(err, aclObject, apiResponse) {});
   *
   * //-
   * // If the callback is omitted, we'll return a Promise.
   * //-
   * myBucket.acl.get().then(function(data) {
   *   const aclObject = data[0];
   *   const apiResponse = data[1];
   * });
   *
   * ```
   * @example <caption>include:samples/acl.js</caption>
   * region_tag:storage_print_file_acl
   * Example of printing a file's ACL:
   *
   * @example <caption>include:samples/acl.js</caption>
   * region_tag:storage_print_file_acl_for_user
   * Example of printing a file's ACL for a specific user:
   *
   * @example <caption>include:samples/acl.js</caption>
   * region_tag:storage_print_bucket_acl
   * Example of printing a bucket's ACL:
   *
   * @example <caption>include:samples/acl.js</caption>
   * region_tag:storage_print_bucket_acl_for_user
   * Example of printing a bucket's ACL for a specific user:
   */
  get(e, t) {
    let i = typeof e == "object" ? e : null, n = typeof e == "function" ? e : t, s = "", c = {};
    i && (s = "/" + encodeURIComponent(i.entity), i.generation && (c.generation = i.generation), i.userProject && (c.userProject = i.userProject)), this.request({
      uri: s,
      qs: c
    }, (a, o) => {
      if (a) {
        n(a, null, o);
        return;
      }
      let l;
      o.items ? l = o.items.map(this.makeAclObject_) : l = this.makeAclObject_(o), n(null, l, o);
    });
  }
  /**
   * @typedef {array} UpdateAclResponse
   * @property {object} 0 The updated Acl Objects.
   * @property {object} 1 The full API response.
   */
  /**
   * @callback UpdateAclCallback
   * @param {?Error} err Request error, if any.
   * @param {object} acl The updated Acl Objects.
   * @param {object} apiResponse The full API response.
   */
  /**
   * Update access controls on a {@link Bucket} or {@link File}.
   *
   * See {@link https://cloud.google.com/storage/docs/json_api/v1/bucketAccessControls/update| BucketAccessControls: update API Documentation}
   * See {@link https://cloud.google.com/storage/docs/json_api/v1/objectAccessControls/update| ObjectAccessControls: update API Documentation}
   *
   * @param {object} options Configuration options.
   * @param {string} options.entity Whose permissions will be updated.
   * @param {string} options.role Permissions allowed for the defined entity.
   *     See {@link Storage.acl}.
   * @param {number} [options.generation] **File Objects Only** Select a specific
   *     revision of this file (as opposed to the latest version, the default).
   * @param {string} [options.userProject] The ID of the project which will be
   *     billed for the request.
   * @param {UpdateAclCallback} [callback] Callback function.
   * @returns {Promise<UpdateAclResponse>}
   *
   * @example
   * ```
   * const storage = require('@google-cloud/storage')();
   * const myBucket = storage.bucket('my-bucket');
   * const myFile = myBucket.file('my-file');
   *
   * const options = {
   *   entity: 'user-useremail@example.com',
   *   role: gcs.acl.WRITER_ROLE
   * };
   *
   * myBucket.acl.update(options, function(err, aclObject, apiResponse) {});
   *
   * //-
   * // For file ACL operations, you can also specify a `generation` property.
   * //-
   * myFile.acl.update({
   *   entity: 'user-useremail@example.com',
   *   role: gcs.acl.WRITER_ROLE,
   *   generation: 1
   * }, function(err, aclObject, apiResponse) {});
   *
   * //-
   * // If the callback is omitted, we'll return a Promise.
   * //-
   * myFile.acl.update(options).then(function(data) {
   *   const aclObject = data[0];
   *   const apiResponse = data[1];
   * });
   * ```
   */
  update(e, t) {
    let i = {};
    e.generation && (i.generation = e.generation), e.userProject && (i.userProject = e.userProject), this.request({
      method: "PUT",
      uri: "/" + encodeURIComponent(e.entity),
      qs: i,
      json: {
        role: e.role.toUpperCase()
      }
    }, (n, s) => {
      if (n) {
        t(n, null, s);
        return;
      }
      t(null, this.makeAclObject_(s), s);
    });
  }
  /**
   * Transform API responses to a consistent object format.
   *
   * @private
   */
  makeAclObject_(e) {
    let t = {
      entity: e.entity,
      role: e.role
    };
    return e.projectTeam && (t.projectTeam = e.projectTeam), t;
  }
  /**
   * Patch requests up to the bucket's request object.
   *
   * @private
   *
   * @param {string} method Action.
   * @param {string} path Request path.
   * @param {*} query Request query object.
   * @param {*} body Request body contents.
   * @param {function} callback Callback function.
   */
  request(e, t) {
    e.uri = this.pathPrefix + e.uri, this.request_(e, t);
  }
};
(0, Mi.promisifyAll)(ne, {
  exclude: ["request"]
});

// node_modules/@google-cloud/storage/build/esm/src/file.js
var Qi = v(W(), 1), er = v(qt(), 1);
import * as Zi from "crypto";
import * as at from "fs";

// node_modules/@google-cloud/storage/build/esm/src/resumable-upload.js
var Fi = v(ln(), 1), Gn = v(an(), 1), fe = v(Oe(), 1), Bi = v(Ue(), 1);
import { createHash as Di } from "crypto";
import { Readable as zn, Writable as Vn } from "stream";
var Gi = v(Ee(), 1);
var Bn = function(r, e, t, i, n) {
  if (i === "m") throw new TypeError("Private method is not writable");
  if (i === "a" && !n) throw new TypeError("Private accessor was defined without a setter");
  if (typeof e == "function" ? r !== e || !n : !e.has(r)) throw new TypeError("Cannot write private member to an object whose class did not declare it");
  return i === "a" ? n.call(r, t) : n ? n.value = t : e.set(r, t), t;
}, C = function(r, e, t, i) {
  if (t === "a" && !i) throw new TypeError("Private accessor was defined without a getter");
  if (typeof e == "function" ? r !== e || !i : !e.has(r)) throw new TypeError("Cannot read private member from an object whose class did not declare it");
  return t === "m" ? i : t === "a" ? i.call(r) : i ? i.value : e.get(r);
}, X, Y, Me, et, $n = 404, Ze = 308, Ct = (0, Gi.getPackageJSON)(), Hn = /^(\w*):\/\//, tt = class extends Vn {
  static {
    d(this, "Upload");
  }
  constructor(e) {
    var t;
    if (super(e), X.add(this), this.numBytesWritten = 0, this.numRetries = 0, this.currentInvocationId = {
      checkUploadStatus: k(),
      chunk: k(),
      uri: k()
    }, this.writeBuffers = [], this.numChunksReadInRequest = 0, this.localWriteCache = [], this.localWriteCacheByteLength = 0, this.upstreamEnded = !1, Y.set(this, void 0), e = e || {}, !e.bucket || !e.file)
      throw new Error("A bucket and file name are required");
    if (e.offset && !e.uri)
      throw new RangeError("Cannot provide an `offset` without providing a `uri`");
    if (e.isPartialUpload && !e.chunkSize)
      throw new RangeError("Cannot set `isPartialUpload` without providing a `chunkSize`");
    e.authConfig = e.authConfig || {}, e.authConfig.scopes = [
      "https://www.googleapis.com/auth/devstorage.full_control"
    ], this.authClient = e.authClient || new fe.GoogleAuth(e.authConfig);
    let i = e.universeDomain || fe.DEFAULT_UNIVERSE;
    if (this.apiEndpoint = `https://storage.${i}`, e.apiEndpoint && e.apiEndpoint !== this.apiEndpoint) {
      this.apiEndpoint = this.sanitizeEndpoint(e.apiEndpoint);
      let a = new URL(this.apiEndpoint).hostname, o = a === i, l = a === fe.DEFAULT_UNIVERSE, p = a.slice(-(i.length + 1)) === `.${i}`, u = a.slice(-(fe.DEFAULT_UNIVERSE.length + 1)) === `.${fe.DEFAULT_UNIVERSE}`;
      !o && !l && !p && !u && (this.authClient = Gn);
    }
    this.baseURI = `${this.apiEndpoint}/upload/storage/v1/b`, this.bucket = e.bucket;
    let n = [e.bucket, e.file];
    if (typeof e.generation == "number" && n.push(`${e.generation}`), this.cacheKey = n.join("/"), this.customRequestOptions = e.customRequestOptions || {}, this.file = e.file, this.generation = e.generation, this.kmsKeyName = e.kmsKeyName, this.metadata = e.metadata || {}, this.offset = e.offset, this.origin = e.origin, this.params = e.params || {}, this.userProject = e.userProject, this.chunkSize = e.chunkSize, this.retryOptions = e.retryOptions, this.isPartialUpload = (t = e.isPartialUpload) !== null && t !== void 0 ? t : !1, e.key)
      if (typeof e.key == "string") {
        let a = Buffer.from(e.key).toString("base64");
        this.encryption = {
          key: a,
          hash: Di("sha256").update(e.key).digest("base64")
        };
      } else {
        let a = e.key.toString("base64");
        this.encryption = {
          key: a,
          hash: Di("sha256").update(e.key).digest("base64")
        };
      }
    this.predefinedAcl = e.predefinedAcl, e.private && (this.predefinedAcl = "private"), e.public && (this.predefinedAcl = "publicRead");
    let s = e.retryOptions.autoRetry;
    this.uriProvidedManually = !!e.uri, this.uri = e.uri, this.offset && (this.numBytesWritten = this.offset), this.numRetries = 0, s || (e.retryOptions.maxRetries = 0), this.timeOfFirstRequest = Date.now();
    let c = e.metadata ? Number(e.metadata.contentLength) : NaN;
    this.contentLength = isNaN(c) ? "*" : c, Bn(this, Y, e[T], "f"), this.once("writing", () => {
      this.uri ? this.continueUploading() : this.createURI((a) => {
        if (a)
          return this.destroy(a);
        this.startUploading();
      });
    });
  }
  /**
   * Prevent 'finish' event until the upload has succeeded.
   *
   * @param fireFinishEvent The finish callback
   */
  _final(e = () => {
  }) {
    this.upstreamEnded = !0, this.once("uploadFinished", e), process.nextTick(() => {
      this.emit("upstreamFinished"), this.emit("writing");
    });
  }
  /**
   * Handles incoming data from upstream
   *
   * @param chunk The chunk to append to the buffer
   * @param encoding The encoding of the chunk
   * @param readCallback A callback for when the buffer has been read downstream
   */
  _write(e, t, i = () => {
  }) {
    this.emit("writing"), this.writeBuffers.push(typeof e == "string" ? Buffer.from(e, t) : e), this.once("readFromChunkBuffer", i), process.nextTick(() => this.emit("wroteToChunkBuffer"));
  }
  /**
   * Prepends the local buffer to write buffer and resets it.
   *
   * @param keepLastBytes number of bytes to keep from the end of the local buffer.
   */
  prependLocalBufferToUpstream(e) {
    let t = [];
    if (e) {
      let n = 0;
      for (; e > n; ) {
        let s = this.localWriteCache.pop();
        if (!s)
          break;
        if (n += s.byteLength, n > e) {
          let c = n - e;
          s = s.subarray(c), n -= c;
        }
        t.unshift(s);
      }
    } else
      t = this.localWriteCache;
    let i = this.writeBuffers;
    this.writeBuffers = t;
    for (let n of i)
      this.writeBuffers.push(n);
    C(this, X, "m", Me).call(this);
  }
  /**
   * Retrieves data from upstream's buffer.
   *
   * @param limit The maximum amount to return from the buffer.
   */
  *pullFromChunkBuffer(e) {
    for (; e; ) {
      let t = this.writeBuffers.shift();
      if (!t)
        break;
      let i = t;
      t.byteLength > e ? (i = t.subarray(0, e), this.writeBuffers.unshift(t.subarray(e)), e = 0) : e -= t.byteLength, yield i, this.emit("readFromChunkBuffer");
    }
  }
  /**
   * A handler for determining if data is ready to be read from upstream.
   *
   * @returns If there will be more chunks to read in the future
   */
  async waitForNextChunk() {
    return await new Promise((t) => {
      if (this.writeBuffers.length)
        return t(!0);
      if (this.upstreamEnded)
        return t(!1);
      let i = /* @__PURE__ */ d(() => (s(), t(!0)), "wroteToChunkBufferCallback"), n = /* @__PURE__ */ d(() => (s(), this.writeBuffers.length ? t(!0) : t(!1)), "upstreamFinishedCallback"), s = /* @__PURE__ */ d(() => {
        this.removeListener("wroteToChunkBuffer", i), this.removeListener("upstreamFinished", n);
      }, "removeListeners");
      this.once("wroteToChunkBuffer", i), this.once("upstreamFinished", n);
    });
  }
  /**
   * Reads data from upstream up to the provided `limit`.
   * Ends when the limit has reached or no data is expected to be pushed from upstream.
   *
   * @param limit The most amount of data this iterator should return. `Infinity` by default.
   */
  async *upstreamIterator(e = 1 / 0) {
    for (; e && await this.waitForNextChunk(); )
      for (let t of this.pullFromChunkBuffer(e))
        e -= t.byteLength, yield t;
  }
  createURI(e) {
    if (!e)
      return this.createURIAsync();
    this.createURIAsync().then((t) => e(null, t), e);
  }
  async createURIAsync() {
    let e = { ...this.metadata }, t = {};
    e.contentLength && (t["X-Upload-Content-Length"] = e.contentLength.toString(), delete e.contentLength), e.contentType && (t["X-Upload-Content-Type"] = e.contentType, delete e.contentType);
    let i = `${z()} gccl/${Ct.version}-${te()} gccl-invocation-id/${this.currentInvocationId.uri}`;
    C(this, Y, "f") && (i += ` gccl-gcs-cmd/${C(this, Y, "f")}`);
    let n = {
      method: "POST",
      url: [this.baseURI, this.bucket, "o"].join("/"),
      params: Object.assign({
        name: this.file,
        uploadType: "resumable"
      }, this.params),
      data: e,
      headers: {
        "User-Agent": V(),
        "x-goog-api-client": i,
        ...t
      }
    };
    e.contentLength && (n.headers["X-Upload-Content-Length"] = e.contentLength.toString()), e.contentType && (n.headers["X-Upload-Content-Type"] = e.contentType), typeof this.generation < "u" && (n.params.ifGenerationMatch = this.generation), this.kmsKeyName && (n.params.kmsKeyName = this.kmsKeyName), this.predefinedAcl && (n.params.predefinedAcl = this.predefinedAcl), this.origin && (n.headers.Origin = this.origin);
    let s = await (0, Bi.default)(async (c) => {
      var a, o, l;
      try {
        let p = await this.makeRequest(n);
        return this.currentInvocationId.uri = k(), p.headers.location;
      } catch (p) {
        let u = p, f = {
          code: (a = u.response) === null || a === void 0 ? void 0 : a.status,
          name: (o = u.response) === null || o === void 0 ? void 0 : o.statusText,
          message: (l = u.response) === null || l === void 0 ? void 0 : l.statusText,
          errors: [
            {
              reason: u.code
            }
          ]
        };
        if (this.retryOptions.maxRetries > 0 && this.retryOptions.retryableErrorFn(f))
          throw u;
        return c(u);
      }
    }, {
      retries: this.retryOptions.maxRetries,
      factor: this.retryOptions.retryDelayMultiplier,
      maxTimeout: this.retryOptions.maxRetryDelay * 1e3,
      //convert to milliseconds
      maxRetryTime: this.retryOptions.totalTimeout * 1e3
      //convert to milliseconds
    });
    return this.uri = s, this.offset = 0, this.emit("uri", s), s;
  }
  async continueUploading() {
    var e;
    return (e = this.offset) !== null && e !== void 0 || await this.getAndSetOffset(), this.startUploading();
  }
  async startUploading() {
    let e = !!this.chunkSize, t = !1;
    if (this.numChunksReadInRequest = 0, this.offset || (this.offset = 0), this.offset < this.numBytesWritten) {
      let l = this.numBytesWritten - this.offset, p = `The offset is lower than the number of bytes written. The server has ${this.offset} bytes and while ${this.numBytesWritten} bytes has been uploaded - thus ${l} bytes are missing. Stopping as this could result in data loss. Initiate a new upload to continue.`;
      this.emit("error", new RangeError(p));
      return;
    }
    if (this.numBytesWritten < this.offset) {
      let l = this.offset - this.numBytesWritten;
      for await (let p of this.upstreamIterator(l))
        ;
      this.numBytesWritten = this.offset;
    }
    let i;
    typeof this.contentLength == "number" && (i = this.contentLength - this.numBytesWritten), this.chunkSize && (i = i ? Math.min(this.chunkSize, i) : this.chunkSize);
    let n = this.upstreamIterator(i), s = new zn({
      read: /* @__PURE__ */ d(async () => {
        t && s.push(null);
        let l = await n.next();
        l.value && (this.numChunksReadInRequest++, e ? C(this, X, "m", et).call(this, l.value) : (C(this, X, "m", Me).call(this), C(this, X, "m", et).call(this, l.value)), this.numBytesWritten += l.value.byteLength, this.emit("progress", {
          bytesWritten: this.numBytesWritten,
          contentLength: this.contentLength
        }), s.push(l.value)), l.done && s.push(null);
      }, "read")
    }), c = `${z()} gccl/${Ct.version}-${te()} gccl-invocation-id/${this.currentInvocationId.chunk}`;
    C(this, Y, "f") && (c += ` gccl-gcs-cmd/${C(this, Y, "f")}`);
    let a = {
      "User-Agent": V(),
      "x-goog-api-client": c
    };
    if (e) {
      for await (let m of this.upstreamIterator(i))
        C(this, X, "m", et).call(this, m);
      let l = this.localWriteCacheByteLength, p = !await this.waitForNextChunk();
      this.prependLocalBufferToUpstream();
      let u = this.contentLength;
      typeof this.contentLength != "number" && p && !this.isPartialUpload && (u = l + this.numBytesWritten);
      let f = l + this.numBytesWritten - 1;
      a["Content-Length"] = l, a["Content-Range"] = `bytes ${this.offset}-${f}/${u}`;
    } else
      a["Content-Range"] = `bytes ${this.offset}-*/${this.contentLength}`;
    let o = {
      method: "PUT",
      url: this.uri,
      headers: a,
      body: s
    };
    try {
      let l = await this.makeRequestStream(o);
      l && (t = !0, await this.responseHandler(l));
    } catch (l) {
      let p = l;
      if (this.retryOptions.retryableErrorFn(p)) {
        this.attemptDelayedRetry({
          status: NaN,
          data: p
        });
        return;
      }
      this.destroy(p);
    }
  }
  // Process the API response to look for errors that came in
  // the response body.
  async responseHandler(e) {
    if (e.data.error) {
      this.destroy(e.data.error);
      return;
    }
    this.currentInvocationId.chunk = k();
    let t = await this.waitForNextChunk(), i = this.chunkSize && e.status === Ze && e.headers.range && t, n = this.isPartialUpload && e.status === Ze && !t;
    if (i) {
      let s = e.headers.range;
      this.offset = Number(s.split("-")[1]) + 1;
      let c = this.numBytesWritten - this.offset;
      c ? (this.prependLocalBufferToUpstream(c), this.numBytesWritten -= c) : C(this, X, "m", Me).call(this), this.continueUploading();
    } else if (!this.isSuccessfulResponse(e.status) && !n) {
      let s = new Error("Upload failed");
      s.code = e.status, s.name = "Upload failed", e?.data && (s.errors = [e?.data]), this.destroy(s);
    } else
      C(this, X, "m", Me).call(this), e && e.data && (e.data.size = Number(e.data.size)), this.emit("metadata", e.data), this.emit("uploadFinished");
  }
  /**
   * Check the status of an existing resumable upload.
   *
   * @param cfg A configuration to use. `uri` is required.
   * @returns the current upload status
   */
  async checkUploadStatus(e = {}) {
    let t = `${z()} gccl/${Ct.version}-${te()} gccl-invocation-id/${this.currentInvocationId.checkUploadStatus}`;
    C(this, Y, "f") && (t += ` gccl-gcs-cmd/${C(this, Y, "f")}`);
    let i = {
      method: "PUT",
      url: this.uri,
      headers: {
        "Content-Length": 0,
        "Content-Range": "bytes */*",
        "User-Agent": V(),
        "x-goog-api-client": t
      }
    };
    try {
      let n = await this.makeRequest(i);
      return this.currentInvocationId.checkUploadStatus = k(), n;
    } catch (n) {
      if (e.retry === !1 || !(n instanceof Error) || !this.retryOptions.retryableErrorFn(n))
        throw n;
      let s = this.getRetryDelay();
      if (s <= 0)
        throw n;
      return await new Promise((c) => setTimeout(c, s)), this.checkUploadStatus(e);
    }
  }
  async getAndSetOffset() {
    try {
      let e = await this.checkUploadStatus({ retry: !1 });
      if (e.status === Ze && typeof e.headers.range == "string") {
        this.offset = Number(e.headers.range.split("-")[1]) + 1;
        return;
      }
      this.offset = 0;
    } catch (e) {
      let t = e;
      if (this.retryOptions.retryableErrorFn(t)) {
        this.attemptDelayedRetry({
          status: NaN,
          data: t
        });
        return;
      }
      this.destroy(t);
    }
  }
  async makeRequest(e) {
    this.encryption && (e.headers = e.headers || {}, e.headers["x-goog-encryption-algorithm"] = "AES256", e.headers["x-goog-encryption-key"] = this.encryption.key.toString(), e.headers["x-goog-encryption-key-sha256"] = this.encryption.hash.toString()), this.userProject && (e.params = e.params || {}, e.params.userProject = this.userProject), e.validateStatus = (n) => this.isSuccessfulResponse(n) || n === Ze;
    let t = {
      ...this.customRequestOptions,
      ...e,
      headers: {
        ...this.customRequestOptions.headers,
        ...e.headers
      }
    }, i = await this.authClient.request(t);
    if (i.data && i.data.error)
      throw i.data.error;
    return i;
  }
  async makeRequestStream(e) {
    let t = new Fi.default(), i = /* @__PURE__ */ d(() => t.abort(), "errorCallback");
    this.once("error", i), this.userProject && (e.params = e.params || {}, e.params.userProject = this.userProject), e.signal = t.signal, e.validateStatus = () => !0;
    let n = {
      ...this.customRequestOptions,
      ...e,
      headers: {
        ...this.customRequestOptions.headers,
        ...e.headers
      }
    }, s = await this.authClient.request(n), c = this.onResponse(s);
    return this.removeListener("error", i), c ? s : null;
  }
  /**
   * @return {bool} is the request good?
   */
  onResponse(e) {
    return e.status !== 200 && this.retryOptions.retryableErrorFn({
      code: e.status,
      message: e.statusText,
      name: e.statusText
    }) ? (this.attemptDelayedRetry(e), !1) : (this.emit("response", e), !0);
  }
  /**
   * @param resp GaxiosResponse object from previous attempt
   */
  attemptDelayedRetry(e) {
    if (this.numRetries < this.retryOptions.maxRetries) {
      if (e.status === $n && this.numChunksReadInRequest === 0)
        this.startUploading();
      else {
        let t = this.getRetryDelay();
        if (t <= 0) {
          this.destroy(new Error(`Retry total time limit exceeded - ${JSON.stringify(e.data)}`));
          return;
        }
        this.numBytesWritten -= this.localWriteCacheByteLength, this.prependLocalBufferToUpstream(), this.offset = void 0, setTimeout(this.continueUploading.bind(this), t);
      }
      this.numRetries++;
    } else
      this.destroy(new Error(`Retry limit exceeded - ${JSON.stringify(e.data)}`));
  }
  /**
   * The amount of time to wait before retrying the request, in milliseconds.
   * If negative, do not retry.
   *
   * @returns the amount of time to wait, in milliseconds.
   */
  getRetryDelay() {
    let e = Math.round(Math.random() * 1e3), t = Math.pow(this.retryOptions.retryDelayMultiplier, this.numRetries) * 1e3 + e, i = this.retryOptions.totalTimeout * 1e3 - (Date.now() - this.timeOfFirstRequest), n = this.retryOptions.maxRetryDelay * 1e3;
    return Math.min(t, n, i);
  }
  /*
   * Prepare user-defined API endpoint for compatibility with our API.
   */
  sanitizeEndpoint(e) {
    return Hn.test(e) || (e = `https://${e}`), e.replace(/\/+$/, "");
  }
  /**
   * Check if a given status code is 2xx
   *
   * @param status The status code to check
   * @returns if the status is 2xx
   */
  isSuccessfulResponse(e) {
    return e >= 200 && e < 300;
  }
};
Y = /* @__PURE__ */ new WeakMap(), X = /* @__PURE__ */ new WeakSet(), Me = /* @__PURE__ */ d(function() {
  this.localWriteCache = [], this.localWriteCacheByteLength = 0;
}, "_Upload_resetLocalBuffersCache"), et = /* @__PURE__ */ d(function(e) {
  this.localWriteCache.push(e), this.localWriteCacheByteLength += e.byteLength;
}, "_Upload_addLocalBufferCache");
function zi(r) {
  return new tt(r);
}
d(zi, "upload");
function Vi(r, e) {
  let t = new tt(r);
  if (!e)
    return t.createURI();
  t.createURI().then((i) => e(null, i), e);
}
d(Vi, "createURI");

// node_modules/@google-cloud/storage/build/esm/src/file.js
import { Writable as es, pipeline as Ut } from "stream";
import * as ot from "zlib";

// node_modules/@google-cloud/storage/build/esm/src/signer.js
import * as Hi from "crypto";
import * as Lt from "url";
var De;
(function(r) {
  r.ACCESSIBLE_DATE_INVALID = "The accessible at date provided was invalid.", r.EXPIRATION_BEFORE_ACCESSIBLE_DATE = "An expiration date cannot be before accessible date.", r.X_GOOG_CONTENT_SHA256 = "The header X-Goog-Content-SHA256 must be a hexadecimal string.";
})(De || (De = {}));
var Wn = "v2", $i = 7 * 24 * 60 * 60;
var Re = class {
  static {
    d(this, "URLSigner");
  }
  constructor(e, t, i, n = new D()) {
    this.auth = e, this.bucket = t, this.file = i, this.storage = n;
  }
  getSignedUrl(e) {
    let t = this.parseExpires(e.expires), i = e.method, n = this.parseAccessibleAt(e.accessibleAt);
    if (t < n)
      throw new Error(De.EXPIRATION_BEFORE_ACCESSIBLE_DATE);
    let s, c = e.virtualHostedStyle || !1;
    e.cname ? s = e.cname : c && (s = `https://${this.bucket.name}.storage.${this.storage.universeDomain}`);
    let a = 1e3, o = Object.assign({}, e, {
      method: i,
      expiration: t,
      accessibleAt: new Date(a * n),
      bucket: this.bucket.name,
      file: this.file ? Le(this.file.name, !1) : void 0
    });
    s && (o.cname = s);
    let l = e.version || Wn, p;
    if (l === "v2")
      p = this.getSignedUrlV2(o);
    else if (l === "v4")
      p = this.getSignedUrlV4(o);
    else
      throw new Error(`Invalid signed URL version: ${l}. Supported versions are 'v2' and 'v4'.`);
    return p.then((u) => {
      var f;
      u = Object.assign(u, e.queryParams);
      let m = new Lt.URL(((f = e.host) === null || f === void 0 ? void 0 : f.toString()) || o.cname || this.storage.apiEndpoint);
      return m.pathname = this.getResourcePath(!!o.cname, this.bucket.name, o.file), m.search = ui(u), m.href;
    });
  }
  getSignedUrlV2(e) {
    let t = this.getCanonicalHeaders(e.extensionHeaders || {}), i = this.getResourcePath(!1, e.bucket, e.file), n = [
      e.method,
      e.contentMd5 || "",
      e.contentType || "",
      e.expiration,
      t + i
    ].join(`
`);
    return (/* @__PURE__ */ d(async () => {
      var c;
      let a = this.auth;
      try {
        let o = await a.sign(n, (c = e.signingEndpoint) === null || c === void 0 ? void 0 : c.toString());
        return {
          GoogleAccessId: (await a.getCredentials()).client_email,
          Expires: e.expiration,
          Signature: o
        };
      } catch (o) {
        let l = o, p = new me(l.message);
        throw p.stack = l.stack, p;
      }
    }, "sign"))();
  }
  getSignedUrlV4(e) {
    var t;
    e.accessibleAt = e.accessibleAt ? e.accessibleAt : /* @__PURE__ */ new Date();
    let i = 1 / 1e3, n = e.expiration - e.accessibleAt.valueOf() * i;
    if (n > $i)
      throw new Error(`Max allowed expiration is seven days (${$i} seconds).`);
    let s = Object.assign({}, e.extensionHeaders), c = new Lt.URL(((t = e.host) === null || t === void 0 ? void 0 : t.toString()) || e.cname || this.storage.apiEndpoint);
    s.host = c.hostname, e.contentMd5 && (s["content-md5"] = e.contentMd5), e.contentType && (s["content-type"] = e.contentType);
    let a, o = s["x-goog-content-sha256"];
    if (o) {
      if (typeof o != "string" || !/[A-Fa-f0-9]{40}/.test(o))
        throw new Error(De.X_GOOG_CONTENT_SHA256);
      a = o;
    }
    let l = Object.keys(s).map((h) => h.toLowerCase()).sort().join(";"), p = this.getCanonicalHeaders(s), f = `${pe(e.accessibleAt)}/auto/storage/goog4_request`;
    return (/* @__PURE__ */ d(async () => {
      var h;
      let y = `${(await this.auth.getCredentials()).client_email}/${f}`, x = pe(e.accessibleAt ? e.accessibleAt : /* @__PURE__ */ new Date(), !0), w = {
        "X-Goog-Algorithm": "GOOG4-RSA-SHA256",
        "X-Goog-Credential": y,
        "X-Goog-Date": x,
        "X-Goog-Expires": n.toString(10),
        "X-Goog-SignedHeaders": l,
        ...e.queryParams || {}
      }, N = this.getCanonicalQueryParams(w), q = this.getCanonicalRequest(e.method, this.getResourcePath(!!e.cname, e.bucket, e.file), N, p, l, a), A = Hi.createHash("sha256").update(q).digest("hex"), j = [
        "GOOG4-RSA-SHA256",
        x,
        f,
        A
      ].join(`
`);
      try {
        let je = await this.auth.sign(j, (h = e.signingEndpoint) === null || h === void 0 ? void 0 : h.toString()), ve = Buffer.from(je, "base64").toString("hex");
        return Object.assign({}, w, {
          "X-Goog-Signature": ve
        });
      } catch (je) {
        let ve = je, ht = new me(ve.message);
        throw ht.stack = ve.stack, ht;
      }
    }, "sign"))();
  }
  /**
   * Create canonical headers for signing v4 url.
   *
   * The canonical headers for v4-signing a request demands header names are
   * first lowercased, followed by sorting the header names.
   * Then, construct the canonical headers part of the request:
   *  <lowercasedHeaderName> + ":" + Trim(<value>) + "\n"
   *  ..
   *  <lowercasedHeaderName> + ":" + Trim(<value>) + "\n"
   *
   * @param headers
   * @private
   */
  getCanonicalHeaders(e) {
    return wt(e).map(([i, n]) => [
      i.toLowerCase(),
      n
    ]).sort((i, n) => i[0].localeCompare(n[0])).filter(([, i]) => i !== void 0).map(([i, n]) => {
      let s = `${n}`.trim().replace(/\s{2,}/g, " ");
      return `${i}:${s}
`;
    }).join("");
  }
  getCanonicalRequest(e, t, i, n, s, c) {
    return [
      e,
      t,
      i,
      n,
      s,
      c || "UNSIGNED-PAYLOAD"
    ].join(`
`);
  }
  getCanonicalQueryParams(e) {
    return wt(e).map(([t, i]) => [Le(t, !0), Le(i, !0)]).sort((t, i) => t[0] < i[0] ? -1 : 1).map(([t, i]) => `${t}=${i}`).join("&");
  }
  getResourcePath(e, t, i) {
    return e ? "/" + (i || "") : i ? `/${t}/${i}` : `/${t}`;
  }
  parseExpires(e, t = /* @__PURE__ */ new Date()) {
    let i = new Date(e).valueOf();
    if (isNaN(i))
      throw new Error($.EXPIRATION_DATE_INVALID);
    if (i < t.valueOf())
      throw new Error($.EXPIRATION_DATE_PAST);
    return Math.floor(i / 1e3);
  }
  parseAccessibleAt(e) {
    let t = new Date(e || /* @__PURE__ */ new Date()).valueOf();
    if (isNaN(t))
      throw new Error(De.ACCESSIBLE_DATE_INVALID);
    return Math.floor(t / 1e3);
  }
}, me = class extends Error {
  static {
    d(this, "SigningError");
  }
  constructor() {
    super(...arguments), this.name = "SigningError";
  }
};

// node_modules/@google-cloud/storage/build/esm/src/file.js
var tr = v(Zt(), 1);

// node_modules/@google-cloud/storage/build/esm/src/crc32c.js
import { createReadStream as Xn } from "fs";
var Ki = function(r, e, t, i, n) {
  if (i === "m") throw new TypeError("Private method is not writable");
  if (i === "a" && !n) throw new TypeError("Private accessor was defined without a setter");
  if (typeof e == "function" ? r !== e || !n : !e.has(r)) throw new TypeError("Cannot write private member to an object whose class did not declare it");
  return i === "a" ? n.call(r, t) : n ? n.value = t : e.set(r, t), t;
}, it = function(r, e, t, i) {
  if (t === "a" && !i) throw new TypeError("Private accessor was defined without a getter");
  if (typeof e == "function" ? r !== e || !i : !e.has(r)) throw new TypeError("Cannot read private member from an object whose class did not declare it");
  return t === "m" ? i : t === "a" ? i.call(r) : i ? i.value : e.get(r);
}, se, Wi = [
  0,
  4067132163,
  3778769143,
  324072436,
  3348797215,
  904991772,
  648144872,
  3570033899,
  2329499855,
  2024987596,
  1809983544,
  2575936315,
  1296289744,
  3207089363,
  2893594407,
  1578318884,
  274646895,
  3795141740,
  4049975192,
  51262619,
  3619967088,
  632279923,
  922689671,
  3298075524,
  2592579488,
  1760304291,
  2075979607,
  2312596564,
  1562183871,
  2943781820,
  3156637768,
  1313733451,
  549293790,
  3537243613,
  3246849577,
  871202090,
  3878099393,
  357341890,
  102525238,
  4101499445,
  2858735121,
  1477399826,
  1264559846,
  3107202533,
  1845379342,
  2677391885,
  2361733625,
  2125378298,
  820201905,
  3263744690,
  3520608582,
  598981189,
  4151959214,
  85089709,
  373468761,
  3827903834,
  3124367742,
  1213305469,
  1526817161,
  2842354314,
  2107672161,
  2412447074,
  2627466902,
  1861252501,
  1098587580,
  3004210879,
  2688576843,
  1378610760,
  2262928035,
  1955203488,
  1742404180,
  2511436119,
  3416409459,
  969524848,
  714683780,
  3639785095,
  205050476,
  4266873199,
  3976438427,
  526918040,
  1361435347,
  2739821008,
  2954799652,
  1114974503,
  2529119692,
  1691668175,
  2005155131,
  2247081528,
  3690758684,
  697762079,
  986182379,
  3366744552,
  476452099,
  3993867776,
  4250756596,
  255256311,
  1640403810,
  2477592673,
  2164122517,
  1922457750,
  2791048317,
  1412925310,
  1197962378,
  3037525897,
  3944729517,
  427051182,
  170179418,
  4165941337,
  746937522,
  3740196785,
  3451792453,
  1070968646,
  1905808397,
  2213795598,
  2426610938,
  1657317369,
  3053634322,
  1147748369,
  1463399397,
  2773627110,
  4215344322,
  153784257,
  444234805,
  3893493558,
  1021025245,
  3467647198,
  3722505002,
  797665321,
  2197175160,
  1889384571,
  1674398607,
  2443626636,
  1164749927,
  3070701412,
  2757221520,
  1446797203,
  137323447,
  4198817972,
  3910406976,
  461344835,
  3484808360,
  1037989803,
  781091935,
  3705997148,
  2460548119,
  1623424788,
  1939049696,
  2180517859,
  1429367560,
  2807687179,
  3020495871,
  1180866812,
  410100952,
  3927582683,
  4182430767,
  186734380,
  3756733383,
  763408580,
  1053836080,
  3434856499,
  2722870694,
  1344288421,
  1131464017,
  2971354706,
  1708204729,
  2545590714,
  2229949006,
  1988219213,
  680717673,
  3673779818,
  3383336350,
  1002577565,
  4010310262,
  493091189,
  238226049,
  4233660802,
  2987750089,
  1082061258,
  1395524158,
  2705686845,
  1972364758,
  2279892693,
  2494862625,
  1725896226,
  952904198,
  3399985413,
  3656866545,
  731699698,
  4283874585,
  222117402,
  510512622,
  3959836397,
  3280807620,
  837199303,
  582374963,
  3504198960,
  68661723,
  4135334616,
  3844915500,
  390545967,
  1230274059,
  3141532936,
  2825850620,
  1510247935,
  2395924756,
  2091215383,
  1878366691,
  2644384480,
  3553878443,
  565732008,
  854102364,
  3229815391,
  340358836,
  3861050807,
  4117890627,
  119113024,
  1493875044,
  2875275879,
  3090270611,
  1247431312,
  2660249211,
  1828433272,
  2141937292,
  2378227087,
  3811616794,
  291187481,
  34330861,
  4032846830,
  615137029,
  3603020806,
  3314634738,
  939183345,
  1776939221,
  2609017814,
  2295496738,
  2058945313,
  2926798794,
  1545135305,
  1330124605,
  3173225534,
  4084100981,
  17165430,
  307568514,
  3762199681,
  888469610,
  3332340585,
  3587147933,
  665062302,
  2042050490,
  2346497209,
  2559330125,
  1793573966,
  3190661285,
  1279665062,
  1595330642,
  2910671697
], Yn = new Int32Array(Wi), rt = /* @__PURE__ */ d(() => new J(), "CRC32C_DEFAULT_VALIDATOR_GENERATOR"), kt = {
  INVALID_INIT_BASE64_RANGE: /* @__PURE__ */ d((r) => `base64-encoded data expected to equal 4 bytes, not ${r}`, "INVALID_INIT_BASE64_RANGE"),
  INVALID_INIT_BUFFER_LENGTH: /* @__PURE__ */ d((r) => `Buffer expected to equal 4 bytes, not ${r}`, "INVALID_INIT_BUFFER_LENGTH"),
  INVALID_INIT_INTEGER: /* @__PURE__ */ d((r) => `Number expected to be a safe, unsigned 32-bit integer, not ${r}`, "INVALID_INIT_INTEGER")
}, J = class r {
  static {
    d(this, "CRC32C");
  }
  /**
   * Constructs a new `CRC32C` object.
   *
   * Reconstruction is recommended via the `CRC32C.from` static method.
   *
   * @param initialValue An initial CRC32C value - a signed 32-bit integer.
   */
  constructor(e = 0) {
    se.set(this, 0), Ki(this, se, e, "f");
  }
  /**
   * Calculates a CRC32C from a provided buffer.
   *
   * Implementation inspired from:
   * - {@link https://github.com/google/crc32c/blob/21fc8ef30415a635e7351ffa0e5d5367943d4a94/src/crc32c_portable.cc github.com/google/crc32c}
   * - {@link https://github.com/googleapis/python-crc32c/blob/a595e758c08df445a99c3bf132ee8e80a3ec4308/src/google_crc32c/python.py github.com/googleapis/python-crc32c}
   * - {@link https://github.com/googleapis/java-storage/pull/1376/files github.com/googleapis/java-storage}
   *
   * @param data The `Buffer` to generate the CRC32C from
   */
  update(e) {
    let t = it(this, se, "f") ^ 4294967295;
    for (let i of e)
      t = r.CRC32C_EXTENSION_TABLE[(i ^ t) & 255] ^ t >>> 8;
    Ki(this, se, t ^ 4294967295, "f");
  }
  /**
   * Validates a provided input to the current CRC32C value.
   *
   * @param input A Buffer, `CRC32C`-compatible object, base64-encoded data (string), or signed 32-bit integer
   */
  validate(e) {
    return typeof e == "number" ? e === it(this, se, "f") : typeof e == "string" ? e === this.toString() : Buffer.isBuffer(e) ? Buffer.compare(e, this.toBuffer()) === 0 : e.toString() === this.toString();
  }
  /**
   * Returns a `Buffer` representation of the CRC32C value
   */
  toBuffer() {
    let e = Buffer.alloc(4);
    return e.writeInt32BE(it(this, se, "f")), e;
  }
  /**
   * Returns a JSON-compatible, base64-encoded representation of the CRC32C value.
   *
   * See {@link https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/JSON/stringify `JSON#stringify`}
   */
  toJSON() {
    return this.toString();
  }
  /**
   * Returns a base64-encoded representation of the CRC32C value.
   *
   * See {@link https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Object/toString `Object#toString`}
   */
  toString() {
    return this.toBuffer().toString("base64");
  }
  /**
   * Returns the `number` representation of the CRC32C value as a signed 32-bit integer
   *
   * See {@link https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Object/valueOf `Object#valueOf`}
   */
  valueOf() {
    return it(this, se, "f");
  }
  /**
   * Generates a `CRC32C` from a compatible buffer format.
   *
   * @param value 4-byte `ArrayBufferView`/`Buffer`/`TypedArray`
   */
  static fromBuffer(e) {
    let t;
    if (Buffer.isBuffer(e) ? t = e : "buffer" in e ? t = Buffer.from(e.buffer) : t = Buffer.from(e), t.byteLength !== 4)
      throw new RangeError(kt.INVALID_INIT_BUFFER_LENGTH(t.byteLength));
    return new r(t.readInt32BE());
  }
  static async fromFile(e) {
    let t = new r();
    return await new Promise((i, n) => {
      Xn(e).on("data", (s) => {
        typeof s == "string" ? t.update(Buffer.from(s)) : t.update(s);
      }).on("end", () => i()).on("error", n);
    }), t;
  }
  /**
   * Generates a `CRC32C` from 4-byte base64-encoded data (string).
   *
   * @param value 4-byte base64-encoded data (string)
   */
  static fromString(e) {
    let t = Buffer.from(e, "base64");
    if (t.byteLength !== 4)
      throw new RangeError(kt.INVALID_INIT_BASE64_RANGE(t.byteLength));
    return this.fromBuffer(t);
  }
  /**
   * Generates a `CRC32C` from a safe, unsigned 32-bit integer.
   *
   * @param value an unsigned 32-bit integer
   */
  static fromNumber(e) {
    if (!Number.isSafeInteger(e) || e > 2 ** 32 || e < -(2 ** 32))
      throw new RangeError(kt.INVALID_INIT_INTEGER(e));
    return new r(e);
  }
  /**
   * Generates a `CRC32C` from a variety of compatable types.
   * Note: strings are treated as input, not as file paths to read from.
   *
   * @param value A number, 4-byte `ArrayBufferView`/`Buffer`/`TypedArray`, or 4-byte base64-encoded data (string)
   */
  static from(e) {
    return typeof e == "number" ? this.fromNumber(e) : typeof e == "string" ? this.fromString(e) : "byteLength" in e ? this.fromBuffer(e) : this.fromString(e.toString());
  }
};
se = /* @__PURE__ */ new WeakMap();
J.CRC32C_EXTENSIONS = Wi;
J.CRC32C_EXTENSION_TABLE = Yn;

// node_modules/@google-cloud/storage/build/esm/src/hash-stream-validator.js
import { createHash as Jn } from "crypto";
import { Transform as Qn } from "stream";
var nt = function(r, e, t, i, n) {
  if (i === "m") throw new TypeError("Private method is not writable");
  if (i === "a" && !n) throw new TypeError("Private accessor was defined without a setter");
  if (typeof e == "function" ? r !== e || !n : !e.has(r)) throw new TypeError("Cannot write private member to an object whose class did not declare it");
  return i === "a" ? n.call(r, t) : n ? n.value = t : e.set(r, t), t;
}, B = function(r, e, t, i) {
  if (t === "a" && !i) throw new TypeError("Private accessor was defined without a getter");
  if (typeof e == "function" ? r !== e || !i : !e.has(r)) throw new TypeError("Cannot read private member from an object whose class did not declare it");
  return t === "m" ? i : t === "a" ? i.call(r) : i ? i.value : e.get(r);
}, Q, ae, st, Fe = class extends Qn {
  static {
    d(this, "HashStreamValidator");
  }
  constructor(e = {}) {
    if (super(), this.updateHashesOnly = !1, Q.set(this, void 0), ae.set(this, void 0), st.set(this, ""), this.crc32cEnabled = !!e.crc32c, this.md5Enabled = !!e.md5, this.updateHashesOnly = !!e.updateHashesOnly, this.crc32cExpected = e.crc32cExpected, this.md5Expected = e.md5Expected, this.crc32cEnabled)
      if (e.crc32cInstance)
        nt(this, Q, e.crc32cInstance, "f");
      else {
        let t = e.crc32cGenerator || rt;
        nt(this, Q, t(), "f");
      }
    this.md5Enabled && nt(this, ae, Jn("md5"), "f");
  }
  /**
   * Return the current CRC32C value, if available.
   */
  get crc32c() {
    var e;
    return (e = B(this, Q, "f")) === null || e === void 0 ? void 0 : e.toString();
  }
  _flush(e) {
    if (B(this, ae, "f") && nt(this, st, B(this, ae, "f").digest("base64"), "f"), this.updateHashesOnly) {
      e();
      return;
    }
    let t = this.crc32cEnabled || this.md5Enabled;
    if (this.crc32cEnabled && this.crc32cExpected && (t = !this.test("crc32c", this.crc32cExpected)), this.md5Enabled && this.md5Expected && (t = !this.test("md5", this.md5Expected)), t) {
      let i = new oe(I.DOWNLOAD_MISMATCH);
      i.code = "CONTENT_DOWNLOAD_MISMATCH", e(i);
    } else
      e();
  }
  _transform(e, t, i) {
    this.push(e, t);
    try {
      B(this, Q, "f") && B(this, Q, "f").update(e), B(this, ae, "f") && B(this, ae, "f").update(e), i();
    } catch (n) {
      i(n);
    }
  }
  test(e, t) {
    let i = Buffer.isBuffer(t) ? t.toString("base64") : t;
    return e === "crc32c" && B(this, Q, "f") ? B(this, Q, "f").validate(i) : e === "md5" && B(this, ae, "f") ? B(this, st, "f") === i : !1;
  }
};
Q = /* @__PURE__ */ new WeakMap(), ae = /* @__PURE__ */ new WeakMap(), st = /* @__PURE__ */ new WeakMap();

// node_modules/@google-cloud/storage/build/esm/src/file.js
var ir = v(Ue(), 1);
var Zn = function(r, e, t, i) {
  if (t === "a" && !i) throw new TypeError("Private accessor was defined without a getter");
  if (typeof e == "function" ? r !== e || !i : !e.has(r)) throw new TypeError("Cannot read private member from an object whose class did not declare it");
  return t === "m" ? i : t === "a" ? i.call(r) : i ? i.value : e.get(r);
}, Mt, Ji, Dt;
(function(r) {
  r.read = "GET", r.write = "PUT", r.delete = "DELETE", r.resumable = "POST";
})(Dt || (Dt = {}));
var Xi = /^gs:\/\/([a-z0-9_.-]+)\/(.+)$/, ts = new RegExp([
  /^text\/|application\/ecmascript|application\/javascript|application\/json/,
  /|application\/postscript|application\/rtf|application\/toml|application\/vnd.dart/,
  /|application\/vnd.ms-fontobject|application\/wasm|application\/x-httpd-php|application\/x-ns-proxy-autoconfig/,
  /|application\/x-sh(?!ockwave-flash)|application\/x-tar|application\/x-virtualbox-hdd|application\/x-virtualbox-ova|application\/x-virtualbox-ovf/,
  /|^application\/x-virtualbox-vbox$|application\/x-virtualbox-vdi|application\/x-virtualbox-vhd|application\/x-virtualbox-vmdk/,
  /|application\/xml|application\/xml-dtd|font\/otf|font\/ttf|image\/bmp|image\/vnd.adobe.photoshop|image\/vnd.microsoft.icon/,
  /|image\/vnd.ms-dds|image\/x-icon|image\/x-ms-bmp|message\/rfc822|model\/gltf-binary|\+json|\+text|\+xml|\+yaml/
].map((r) => r.source).join(""), "i"), oe = class extends Error {
  static {
    d(this, "RequestError");
  }
}, Yi = 7 * 24 * 60 * 60, is = /(gs):\/\/([a-z0-9_.-]+)\/(.+)/g, rs = /(https):\/\/(storage\.googleapis\.com)\/([a-z0-9_.-]+)\/(.+)/g, I;
(function(r) {
  r.EXPIRATION_TIME_NA = "An expiration time is not available.", r.DESTINATION_NO_NAME = "Destination file should have a name.", r.INVALID_VALIDATION_FILE_RANGE = "Cannot use validation with file ranges (start/end).", r.MD5_NOT_AVAILABLE = "MD5 verification was specified, but is not available for the requested object. MD5 is not available for composite objects.", r.EQUALS_CONDITION_TWO_ELEMENTS = "Equals condition must be an array of 2 elements.", r.STARTS_WITH_TWO_ELEMENTS = "StartsWith condition must be an array of 2 elements.", r.CONTENT_LENGTH_RANGE_MIN_MAX = "ContentLengthRange must have numeric min & max fields.", r.DOWNLOAD_MISMATCH = "The downloaded data did not match the data from the server. To be sure the content is the same, you should download the file again.", r.UPLOAD_MISMATCH_DELETE_FAIL = `The uploaded data did not match the data from the server.
    As a precaution, we attempted to delete the file, but it was not successful.
    To be sure the content is the same, you should try removing the file manually,
    then uploading the file again.
    

The delete attempt failed with this message:

  `, r.UPLOAD_MISMATCH = `The uploaded data did not match the data from the server.
    As a precaution, the file has been deleted.
    To be sure the content is the same, you should try uploading the file again.`, r.MD5_RESUMED_UPLOAD = "MD5 cannot be used with a continued resumable upload as MD5 cannot be extended from an existing value", r.MISSING_RESUME_CRC32C_FINAL_UPLOAD = "The CRC32C is missing for the final portion of a resumed upload, which is required for validation. Please provide `resumeCRC32C` if validation is required, or disable `validation`.";
})(I || (I = {}));
var H = class r extends O {
  static {
    d(this, "File");
  }
  /**
   * Cloud Storage uses access control lists (ACLs) to manage object and
   * bucket access. ACLs are the mechanism you use to share objects with other
   * users and allow other users to access your buckets and objects.
   *
   * An ACL consists of one or more entries, where each entry grants permissions
   * to an entity. Permissions define the actions that can be performed against
   * an object or bucket (for example, `READ` or `WRITE`); the entity defines
   * who the permission applies to (for example, a specific user or group of
   * users).
   *
   * The `acl` object on a File instance provides methods to get you a list of
   * the ACLs defined on your bucket, as well as set, update, and delete them.
   *
   * See {@link http://goo.gl/6qBBPO| About Access Control lists}
   *
   * @name File#acl
   * @mixes Acl
   *
   * @example
   * ```
   * const {Storage} = require('@google-cloud/storage');
   * const storage = new Storage();
   * const myBucket = storage.bucket('my-bucket');
   *
   * const file = myBucket.file('my-file');
   * //-
   * // Make a file publicly readable.
   * //-
   * const options = {
   *   entity: 'allUsers',
   *   role: storage.acl.READER_ROLE
   * };
   *
   * file.acl.add(options, function(err, aclObject) {});
   *
   * //-
   * // If the callback is omitted, we'll return a Promise.
   * //-
   * file.acl.add(options).then(function(data) {
   *   const aclObject = data[0];
   *   const apiResponse = data[1];
   * });
   * ```
   */
  /**
   * The API-formatted resource description of the file.
   *
   * Note: This is not guaranteed to be up-to-date when accessed. To get the
   * latest record, call the `getMetadata()` method.
   *
   * @name File#metadata
   * @type {object}
   */
  /**
   * The file's name.
   * @name File#name
   * @type {string}
   */
  /**
   * @callback Crc32cGeneratorToStringCallback
   * A method returning the CRC32C as a base64-encoded string.
   *
   * @returns {string}
   *
   * @example
   * Hashing the string 'data' should return 'rth90Q=='
   *
   * ```js
   * const buffer = Buffer.from('data');
   * crc32c.update(buffer);
   * crc32c.toString(); // 'rth90Q=='
   * ```
   **/
  /**
   * @callback Crc32cGeneratorValidateCallback
   * A method validating a base64-encoded CRC32C string.
   *
   * @param {string} [value] base64-encoded CRC32C string to validate
   * @returns {boolean}
   *
   * @example
   * Should return `true` if the value matches, `false` otherwise
   *
   * ```js
   * const buffer = Buffer.from('data');
   * crc32c.update(buffer);
   * crc32c.validate('DkjKuA=='); // false
   * crc32c.validate('rth90Q=='); // true
   * ```
   **/
  /**
   * @callback Crc32cGeneratorUpdateCallback
   * A method for passing `Buffer`s for CRC32C generation.
   *
   * @param {Buffer} [data] data to update CRC32C value with
   * @returns {undefined}
   *
   * @example
   * Hashing buffers from 'some ' and 'text\n'
   *
   * ```js
   * const buffer1 = Buffer.from('some ');
   * crc32c.update(buffer1);
   *
   * const buffer2 = Buffer.from('text\n');
   * crc32c.update(buffer2);
   *
   * crc32c.toString(); // 'DkjKuA=='
   * ```
   **/
  /**
   * @typedef {object} CRC32CValidator
   * @property {Crc32cGeneratorToStringCallback}
   * @property {Crc32cGeneratorValidateCallback}
   * @property {Crc32cGeneratorUpdateCallback}
   */
  /**
   * @callback Crc32cGeneratorCallback
   * @returns {CRC32CValidator}
   */
  /**
   * @typedef {object} FileOptions Options passed to the File constructor.
   * @property {string} [encryptionKey] A custom encryption key.
   * @property {number} [generation] Generation to scope the file to.
   * @property {string} [kmsKeyName] Cloud KMS Key used to encrypt this
   *     object, if the object is encrypted by such a key. Limited availability;
   *     usable only by enabled projects.
   * @property {string} [userProject] The ID of the project which will be
   *     billed for all requests made from File object.
   * @property {Crc32cGeneratorCallback} [callback] A function that generates a CRC32C Validator. Defaults to {@link CRC32C}
   */
  /**
   * Constructs a file object.
   *
   * @param {Bucket} bucket The Bucket instance this file is
   *     attached to.
   * @param {string} name The name of the remote file.
   * @param {FileOptions} [options] Configuration options.
   * @example
   * ```
   * const {Storage} = require('@google-cloud/storage');
   * const storage = new Storage();
   * const myBucket = storage.bucket('my-bucket');
   *
   * const file = myBucket.file('my-file');
   * ```
   */
  constructor(e, t, i = {}) {
    var n, s;
    let c = {}, a;
    i.generation !== null && (typeof i.generation == "string" ? a = Number(i.generation) : a = i.generation, isNaN(a) || (c.generation = a)), Object.assign(c, i.preconditionOpts);
    let o = i.userProject || e.userProject;
    typeof o == "string" && (c.userProject = o);
    let l = {
      /**
       * @typedef {array} DeleteFileResponse
       * @property {object} 0 The full API response.
       */
      /**
       * @callback DeleteFileCallback
       * @param {?Error} err Request error, if any.
       * @param {object} apiResponse The full API response.
       */
      /**
       * Delete the file.
       *
       * See {@link https://cloud.google.com/storage/docs/json_api/v1/objects/delete| Objects: delete API Documentation}
       *
       * @method File#delete
       * @param {object} [options] Configuration options.
       * @param {boolean} [options.ignoreNotFound = false] Ignore an error if
       *     the file does not exist.
       * @param {string} [options.userProject] The ID of the project which will be
       *     billed for the request.
       * @param {DeleteFileCallback} [callback] Callback function.
       * @returns {Promise<DeleteFileResponse>}
       *
       * @example
       * ```
       * const {Storage} = require('@google-cloud/storage');
       * const storage = new Storage();
       * const myBucket = storage.bucket('my-bucket');
       *
       * const file = myBucket.file('my-file');
       * file.delete(function(err, apiResponse) {});
       *
       * //-
       * // If the callback is omitted, we'll return a Promise.
       * //-
       * file.delete().then(function(data) {
       *   const apiResponse = data[0];
       * });
       *
       * ```
       * @example <caption>include:samples/files.js</caption>
       * region_tag:storage_delete_file
       * Another example:
       */
      delete: {
        reqOpts: {
          qs: c
        }
      },
      /**
       * @typedef {array} FileExistsResponse
       * @property {boolean} 0 Whether the {@link File} exists.
       */
      /**
       * @callback FileExistsCallback
       * @param {?Error} err Request error, if any.
       * @param {boolean} exists Whether the {@link File} exists.
       */
      /**
       * Check if the file exists.
       *
       * @method File#exists
       * @param {options} [options] Configuration options.
       * @param {string} [options.userProject] The ID of the project which will be
       *     billed for the request.
       * @param {FileExistsCallback} [callback] Callback function.
       * @returns {Promise<FileExistsResponse>}
       *
       * @example
       * ```
       * const {Storage} = require('@google-cloud/storage');
       * const storage = new Storage();
       * const myBucket = storage.bucket('my-bucket');
       *
       * const file = myBucket.file('my-file');
       *
       * file.exists(function(err, exists) {});
       *
       * //-
       * // If the callback is omitted, we'll return a Promise.
       * //-
       * file.exists().then(function(data) {
       *   const exists = data[0];
       * });
       * ```
       */
      exists: {
        reqOpts: {
          qs: c
        }
      },
      /**
       * @typedef {array} GetFileResponse
       * @property {File} 0 The {@link File}.
       * @property {object} 1 The full API response.
       */
      /**
       * @callback GetFileCallback
       * @param {?Error} err Request error, if any.
       * @param {File} file The {@link File}.
       * @param {object} apiResponse The full API response.
       */
      /**
       * Get a file object and its metadata if it exists.
       *
       * @method File#get
       * @param {options} [options] Configuration options.
       * @param {string} [options.userProject] The ID of the project which will be
       *     billed for the request.
       * @param {number} [options.generation] The generation number to get
       * @param {string} [options.restoreToken] If this is a soft-deleted object in an HNS-enabled bucket, returns the restore token which will
       *    be necessary to restore it if there's a name conflict with another object.
       * @param {boolean} [options.softDeleted] If true, returns the soft-deleted object.
            Object `generation` is required if `softDeleted` is set to True.
       * @param {GetFileCallback} [callback] Callback function.
       * @returns {Promise<GetFileResponse>}
       *
       * @example
       * ```
       * const {Storage} = require('@google-cloud/storage');
       * const storage = new Storage();
       * const myBucket = storage.bucket('my-bucket');
       *
       * const file = myBucket.file('my-file');
       *
       * file.get(function(err, file, apiResponse) {
       *   // file.metadata` has been populated.
       * });
       *
       * //-
       * // If the callback is omitted, we'll return a Promise.
       * //-
       * file.get().then(function(data) {
       *   const file = data[0];
       *   const apiResponse = data[1];
       * });
       * ```
       */
      get: {
        reqOpts: {
          qs: c
        }
      },
      /**
       * @typedef {array} GetFileMetadataResponse
       * @property {object} 0 The {@link File} metadata.
       * @property {object} 1 The full API response.
       */
      /**
       * @callback GetFileMetadataCallback
       * @param {?Error} err Request error, if any.
       * @param {object} metadata The {@link File} metadata.
       * @param {object} apiResponse The full API response.
       */
      /**
       * Get the file's metadata.
       *
       * See {@link https://cloud.google.com/storage/docs/json_api/v1/objects/get| Objects: get API Documentation}
       *
       * @method File#getMetadata
       * @param {object} [options] Configuration options.
       * @param {string} [options.userProject] The ID of the project which will be
       *     billed for the request.
       * @param {GetFileMetadataCallback} [callback] Callback function.
       * @returns {Promise<GetFileMetadataResponse>}
       *
       * @example
       * ```
       * const {Storage} = require('@google-cloud/storage');
       * const storage = new Storage();
       * const myBucket = storage.bucket('my-bucket');
       *
       * const file = myBucket.file('my-file');
       *
       * file.getMetadata(function(err, metadata, apiResponse) {});
       *
       * //-
       * // If the callback is omitted, we'll return a Promise.
       * //-
       * file.getMetadata().then(function(data) {
       *   const metadata = data[0];
       *   const apiResponse = data[1];
       * });
       *
       * ```
       * @example <caption>include:samples/files.js</caption>
       * region_tag:storage_get_metadata
       * Another example:
       */
      getMetadata: {
        reqOpts: {
          qs: c
        }
      },
      /**
       * @typedef {object} SetFileMetadataOptions Configuration options for File#setMetadata().
       * @param {string} [userProject] The ID of the project which will be billed for the request.
       */
      /**
       * @callback SetFileMetadataCallback
       * @param {?Error} err Request error, if any.
       * @param {object} apiResponse The full API response.
       */
      /**
       * @typedef {array} SetFileMetadataResponse
       * @property {object} 0 The full API response.
       */
      /**
       * Merge the given metadata with the current remote file's metadata. This
       * will set metadata if it was previously unset or update previously set
       * metadata. To unset previously set metadata, set its value to null.
       *
       * You can set custom key/value pairs in the metadata key of the given
       * object, however the other properties outside of this object must adhere
       * to the {@link https://goo.gl/BOnnCK| official API documentation}.
       *
       *
       * See the examples below for more information.
       *
       * See {@link https://cloud.google.com/storage/docs/json_api/v1/objects/patch| Objects: patch API Documentation}
       *
       * @method File#setMetadata
       * @param {object} [metadata] The metadata you wish to update.
       * @param {SetFileMetadataOptions} [options] Configuration options.
       * @param {SetFileMetadataCallback} [callback] Callback function.
       * @returns {Promise<SetFileMetadataResponse>}
       *
       * @example
       * ```
       * const {Storage} = require('@google-cloud/storage');
       * const storage = new Storage();
       * const myBucket = storage.bucket('my-bucket');
       *
       * const file = myBucket.file('my-file');
       *
       * const metadata = {
       *   contentType: 'application/x-font-ttf',
       *   metadata: {
       *     my: 'custom',
       *     properties: 'go here'
       *   }
       * };
       *
       * file.setMetadata(metadata, function(err, apiResponse) {});
       *
       * // Assuming current metadata = { hello: 'world', unsetMe: 'will do' }
       * file.setMetadata({
       *   metadata: {
       *     abc: '123', // will be set.
       *     unsetMe: null, // will be unset (deleted).
       *     hello: 'goodbye' // will be updated from 'world' to 'goodbye'.
       *   }
       * }, function(err, apiResponse) {
       *   // metadata should now be { abc: '123', hello: 'goodbye' }
       * });
       *
       * //-
       * // Set a temporary hold on this file from its bucket's retention period
       * // configuration.
       * //
       * file.setMetadata({
       *   temporaryHold: true
       * }, function(err, apiResponse) {});
       *
       * //-
       * // Alternatively, you may set a temporary hold. This will follow the
       * // same behavior as an event-based hold, with the exception that the
       * // bucket's retention policy will not renew for this file from the time
       * // the hold is released.
       * //-
       * file.setMetadata({
       *   eventBasedHold: true
       * }, function(err, apiResponse) {});
       *
       * //-
       * // If the callback is omitted, we'll return a Promise.
       * //-
       * file.setMetadata(metadata).then(function(data) {
       *   const apiResponse = data[0];
       * });
       * ```
       */
      setMetadata: {
        reqOpts: {
          qs: c
        }
      }
    };
    if (super({
      parent: e,
      baseUrl: "/o",
      id: encodeURIComponent(t),
      methods: l
    }), Mt.add(this), this.bucket = e, this.storage = e.parent, i.generation !== null) {
      let p;
      typeof i.generation == "string" ? p = Number(i.generation) : p = i.generation, isNaN(p) || (this.generation = p);
    }
    this.kmsKeyName = i.kmsKeyName, this.userProject = o, this.name = t, i.encryptionKey && this.setEncryptionKey(i.encryptionKey), this.acl = new ne({
      request: this.request.bind(this),
      pathPrefix: "/acl"
    }), this.crc32cGenerator = i.crc32cGenerator || this.bucket.crc32cGenerator, this.instanceRetryValue = (s = (n = this.storage) === null || n === void 0 ? void 0 : n.retryOptions) === null || s === void 0 ? void 0 : s.autoRetry, this.instancePreconditionOpts = i?.preconditionOpts;
  }
  /**
   * The object's Cloud Storage URI (`gs://`)
   *
   * @example
   * ```ts
   * const {Storage} = require('@google-cloud/storage');
   * const storage = new Storage();
   * const bucket = storage.bucket('my-bucket');
   * const file = bucket.file('image.png');
   *
   * // `gs://my-bucket/image.png`
   * const href = file.cloudStorageURI.href;
   * ```
   */
  get cloudStorageURI() {
    let e = this.bucket.cloudStorageURI;
    return e.pathname = this.name, e;
  }
  /**
   * A helper method for determining if a request should be retried based on preconditions.
   * This should only be used for methods where the idempotency is determined by
   * `ifGenerationMatch`
   * @private
   *
   * A request should not be retried under the following conditions:
   * - if precondition option `ifGenerationMatch` is not set OR
   * - if `idempotencyStrategy` is set to `RetryNever`
   */
  shouldRetryBasedOnPreconditionAndIdempotencyStrat(e) {
    var t;
    return !(e?.ifGenerationMatch === void 0 && ((t = this.instancePreconditionOpts) === null || t === void 0 ? void 0 : t.ifGenerationMatch) === void 0 && this.storage.retryOptions.idempotencyStrategy === _.RetryConditional || this.storage.retryOptions.idempotencyStrategy === _.RetryNever);
  }
  /**
   * @typedef {array} CopyResponse
   * @property {File} 0 The copied {@link File}.
   * @property {object} 1 The full API response.
   */
  /**
   * @callback CopyCallback
   * @param {?Error} err Request error, if any.
   * @param {File} copiedFile The copied {@link File}.
   * @param {object} apiResponse The full API response.
   */
  /**
   * @typedef {object} CopyOptions Configuration options for File#copy(). See an
   *     {@link https://cloud.google.com/storage/docs/json_api/v1/objects#resource| Object resource}.
   * @property {string} [cacheControl] The cacheControl setting for the new file.
   * @property {string} [contentEncoding] The contentEncoding setting for the new file.
   * @property {string} [contentType] The contentType setting for the new file.
   * @property {string} [destinationKmsKeyName] Resource name of the Cloud
   *     KMS key, of the form
   *     `projects/my-project/locations/location/keyRings/my-kr/cryptoKeys/my-key`,
   *     that will be used to encrypt the object. Overwrites the object
   * metadata's `kms_key_name` value, if any.
   * @property {Metadata} [metadata] Metadata to specify on the copied file.
   * @property {string} [predefinedAcl] Set the ACL for the new file.
   * @property {string} [token] A previously-returned `rewriteToken` from an
   *     unfinished rewrite request.
   * @property {string} [userProject] The ID of the project which will be
   *     billed for the request.
   */
  /**
   * Copy this file to another file. By default, this will copy the file to the
   * same bucket, but you can choose to copy it to another Bucket by providing
   * a Bucket or File object or a URL starting with "gs://".
   * The generation of the file will not be preserved.
   *
   * See {@link https://cloud.google.com/storage/docs/json_api/v1/objects/rewrite| Objects: rewrite API Documentation}
   *
   * @throws {Error} If the destination file is not provided.
   *
   * @param {string|Bucket|File} destination Destination file.
   * @param {CopyOptions} [options] Configuration options. See an
   * @param {CopyCallback} [callback] Callback function.
   * @returns {Promise<CopyResponse>}
   *
   * @example
   * ```
   * const {Storage} = require('@google-cloud/storage');
   * const storage = new Storage();
   *
   * //-
   * // You can pass in a variety of types for the destination.
   * //
   * // For all of the below examples, assume we are working with the following
   * // Bucket and File objects.
   * //-
   * const bucket = storage.bucket('my-bucket');
   * const file = bucket.file('my-image.png');
   *
   * //-
   * // If you pass in a string for the destination, the file is copied to its
   * // current bucket, under the new name provided.
   * //-
   * file.copy('my-image-copy.png', function(err, copiedFile, apiResponse) {
   *   // `my-bucket` now contains:
   *   // - "my-image.png"
   *   // - "my-image-copy.png"
   *
   *   // `copiedFile` is an instance of a File object that refers to your new
   *   // file.
   * });
   *
   * //-
   * // If you pass in a string starting with "gs://" for the destination, the
   * // file is copied to the other bucket and under the new name provided.
   * //-
   * const newLocation = 'gs://another-bucket/my-image-copy.png';
   * file.copy(newLocation, function(err, copiedFile, apiResponse) {
   *   // `my-bucket` still contains:
   *   // - "my-image.png"
   *   //
   *   // `another-bucket` now contains:
   *   // - "my-image-copy.png"
   *
   *   // `copiedFile` is an instance of a File object that refers to your new
   *   // file.
   * });
   *
   * //-
   * // If you pass in a Bucket object, the file will be copied to that bucket
   * // using the same name.
   * //-
   * const anotherBucket = storage.bucket('another-bucket');
   * file.copy(anotherBucket, function(err, copiedFile, apiResponse) {
   *   // `my-bucket` still contains:
   *   // - "my-image.png"
   *   //
   *   // `another-bucket` now contains:
   *   // - "my-image.png"
   *
   *   // `copiedFile` is an instance of a File object that refers to your new
   *   // file.
   * });
   *
   * //-
   * // If you pass in a File object, you have complete control over the new
   * // bucket and filename.
   * //-
   * const anotherFile = anotherBucket.file('my-awesome-image.png');
   * file.copy(anotherFile, function(err, copiedFile, apiResponse) {
   *   // `my-bucket` still contains:
   *   // - "my-image.png"
   *   //
   *   // `another-bucket` now contains:
   *   // - "my-awesome-image.png"
   *
   *   // Note:
   *   // The `copiedFile` parameter is equal to `anotherFile`.
   * });
   *
   * //-
   * // If the callback is omitted, we'll return a Promise.
   * //-
   * file.copy(newLocation).then(function(data) {
   *   const newFile = data[0];
   *   const apiResponse = data[1];
   * });
   *
   * ```
   * @example <caption>include:samples/files.js</caption>
   * region_tag:storage_copy_file
   * Another example:
   */
  copy(e, t, i) {
    var n, s;
    let c = new Error(I.DESTINATION_NO_NAME);
    if (!e)
      throw c;
    let a = {};
    typeof t == "function" ? i = t : t && (a = { ...t }), i = i || b.noop;
    let o, l, p;
    if (typeof e == "string") {
      let m = Xi.exec(e);
      m !== null && m.length === 3 ? (o = this.storage.bucket(m[1]), l = m[2]) : (o = this.bucket, l = e);
    } else if (e instanceof F)
      o = e, l = this.name;
    else if (e instanceof r)
      o = e.bucket, l = e.name, p = e;
    else
      throw c;
    let u = {};
    this.generation !== void 0 && (u.sourceGeneration = this.generation), a.token !== void 0 && (u.rewriteToken = a.token), a.userProject !== void 0 && (u.userProject = a.userProject, delete a.userProject), a.predefinedAcl !== void 0 && (u.destinationPredefinedAcl = a.predefinedAcl, delete a.predefinedAcl), p = p || o.file(l);
    let f = {};
    if (this.encryptionKey !== void 0 && (f["x-goog-copy-source-encryption-algorithm"] = "AES256", f["x-goog-copy-source-encryption-key"] = this.encryptionKeyBase64, f["x-goog-copy-source-encryption-key-sha256"] = this.encryptionKeyHash), p.encryptionKey !== void 0 ? this.setEncryptionKey(p.encryptionKey) : a.destinationKmsKeyName !== void 0 ? (u.destinationKmsKeyName = a.destinationKmsKeyName, delete a.destinationKmsKeyName) : p.kmsKeyName !== void 0 && (u.destinationKmsKeyName = p.kmsKeyName), u.destinationKmsKeyName) {
      this.kmsKeyName = u.destinationKmsKeyName;
      let m = this.interceptors.indexOf(this.encryptionKeyInterceptor);
      m > -1 && this.interceptors.splice(m, 1);
    }
    this.shouldRetryBasedOnPreconditionAndIdempotencyStrat(a?.preconditionOpts) || (this.storage.retryOptions.autoRetry = !1), ((n = a.preconditionOpts) === null || n === void 0 ? void 0 : n.ifGenerationMatch) !== void 0 && (u.ifGenerationMatch = (s = a.preconditionOpts) === null || s === void 0 ? void 0 : s.ifGenerationMatch, delete a.preconditionOpts), this.request({
      method: "POST",
      uri: `/rewriteTo/b/${o.name}/o/${encodeURIComponent(p.name)}`,
      qs: u,
      json: a,
      headers: f
    }, (m, h) => {
      if (this.storage.retryOptions.autoRetry = this.instanceRetryValue, m) {
        i(m, null, h);
        return;
      }
      if (h.rewriteToken) {
        let g = {
          token: h.rewriteToken
        };
        u.userProject && (g.userProject = u.userProject), u.destinationKmsKeyName && (g.destinationKmsKeyName = u.destinationKmsKeyName), this.copy(p, g, i);
        return;
      }
      i(null, p, h);
    });
  }
  /**
   * @typedef {object} CreateReadStreamOptions Configuration options for File#createReadStream.
   * @property {string} [userProject] The ID of the project which will be
   *     billed for the request.
   * @property {string|boolean} [validation] Possible values: `"md5"`,
   *     `"crc32c"`, or `false`. By default, data integrity is validated with a
   *     CRC32c checksum. You may use MD5 if preferred, but that hash is not
   *     supported for composite objects. An error will be raised if MD5 is
   *     specified but is not available. You may also choose to skip validation
   *     completely, however this is **not recommended**.
   * @property {number} [start] A byte offset to begin the file's download
   *     from. Default is 0. NOTE: Byte ranges are inclusive; that is,
   *     `options.start = 0` and `options.end = 999` represent the first 1000
   *     bytes in a file or object. NOTE: when specifying a byte range, data
   *     integrity is not available.
   * @property {number} [end] A byte offset to stop reading the file at.
   *     NOTE: Byte ranges are inclusive; that is, `options.start = 0` and
   *     `options.end = 999` represent the first 1000 bytes in a file or object.
   *     NOTE: when specifying a byte range, data integrity is not available.
   * @property {boolean} [decompress=true] Disable auto decompression of the
   *     received data. By default this option is set to `true`.
   *     Applicable in cases where the data was uploaded with
   *     `gzip: true` option. See {@link File#createWriteStream}.
   */
  /**
   * Create a readable stream to read the contents of the remote file. It can be
   * piped to a writable stream or listened to for 'data' events to read a
   * file's contents.
   *
   * In the unlikely event there is a mismatch between what you downloaded and
   * the version in your Bucket, your error handler will receive an error with
   * code "CONTENT_DOWNLOAD_MISMATCH". If you receive this error, the best
   * recourse is to try downloading the file again.
   *
   * NOTE: Readable streams will emit the `end` event when the file is fully
   * downloaded.
   *
   * @param {CreateReadStreamOptions} [options] Configuration options.
   * @returns {ReadableStream}
   *
   * @example
   * ```
   * //-
   * // <h4>Downloading a File</h4>
   * //
   * // The example below demonstrates how we can reference a remote file, then
   * // pipe its contents to a local file. This is effectively creating a local
   * // backup of your remote data.
   * //-
   * const {Storage} = require('@google-cloud/storage');
   * const storage = new Storage();
   * const bucket = storage.bucket('my-bucket');
   *
   * const fs = require('fs');
   * const remoteFile = bucket.file('image.png');
   * const localFilename = '/Users/stephen/Photos/image.png';
   *
   * remoteFile.createReadStream()
   *   .on('error', function(err) {})
   *   .on('response', function(response) {
   *     // Server connected and responded with the specified status and headers.
   *    })
   *   .on('end', function() {
   *     // The file is fully downloaded.
   *   })
   *   .pipe(fs.createWriteStream(localFilename));
   *
   * //-
   * // To limit the downloaded data to only a byte range, pass an options
   * // object.
   * //-
   * const logFile = myBucket.file('access_log');
   * logFile.createReadStream({
   *     start: 10000,
   *     end: 20000
   *   })
   *   .on('error', function(err) {})
   *   .pipe(fs.createWriteStream('/Users/stephen/logfile.txt'));
   *
   * //-
   * // To read a tail byte range, specify only `options.end` as a negative
   * // number.
   * //-
   * const logFile = myBucket.file('access_log');
   * logFile.createReadStream({
   *     end: -100
   *   })
   *   .on('error', function(err) {})
   *   .pipe(fs.createWriteStream('/Users/stephen/logfile.txt'));
   * ```
   */
  createReadStream(e = {}) {
    e = Object.assign({ decompress: !0 }, e);
    let t = typeof e.start == "number" || typeof e.end == "number", i = e.end < 0, n, s, c = new Ce(), a = !0, o = !1;
    if (typeof e.validation == "string") {
      let m = e.validation.toLowerCase().trim();
      a = m === "crc32c", o = m === "md5";
    } else e.validation === !1 && (a = !1);
    let l = !t && (a || o);
    if (t) {
      if (typeof e.validation == "string" || e.validation === !0)
        throw new Error(I.INVALID_VALIDATION_FILE_RANGE);
      a = !1, o = !1;
    }
    let p = /* @__PURE__ */ d((m) => {
      m && (s?.agent && s.agent.destroy(), c.destroy(m));
    }, "onComplete"), u = /* @__PURE__ */ d((m, h, g) => {
      if (m) {
        this.getBufferFromReadable(g).then((A) => {
          m.message = A.toString("utf8"), c.destroy(m);
        });
        return;
      }
      s = g.request;
      let y = g.toJSON().headers, x = y["content-encoding"] === "gzip", w = {}, N = y["x-goog-stored-content-encoding"] === "gzip" && x || y["x-goog-stored-content-encoding"] === "identity", q = [];
      if (l && (typeof y["x-goog-hash"] == "string" && y["x-goog-hash"].split(",").forEach((A) => {
        let j = A.indexOf("="), je = A.substring(0, j), ve = A.substring(j + 1);
        w[je] = ve;
      }), n = new Fe({
        crc32c: a,
        md5: o,
        crc32cGenerator: this.crc32cGenerator,
        crc32cExpected: w.crc32c,
        md5Expected: w.md5
      })), o && !w.md5) {
        let A = new oe(I.MD5_NOT_AVAILABLE);
        A.code = "MD5_NOT_AVAILABLE", c.destroy(A);
        return;
      }
      N && l && n && q.push(n), x && e.decompress && q.push(ot.createGunzip()), Ut(g, ...q, c, p);
    }, "onResponse"), f = /* @__PURE__ */ d(() => {
      let m = { alt: "media" };
      this.generation && (m.generation = this.generation), e.userProject && (m.userProject = e.userProject);
      let h = {
        "Accept-Encoding": "gzip",
        "Cache-Control": "no-store"
      };
      if (t) {
        let y = typeof e.start == "number" ? e.start : "0", x = typeof e.end == "number" ? e.end : "";
        h.Range = `bytes=${i ? x : `${y}-${x}`}`;
      }
      let g = {
        uri: "",
        headers: h,
        qs: m
      };
      e[T] && (g[T] = e[T]), this.requestStream(g).on("error", (y) => {
        c.destroy(y);
      }).on("response", (y) => {
        c.emit("response", y), b.handleResp(null, y, null, u);
      }).resume();
    }, "makeRequest");
    return c.on("reading", f), c;
  }
  /**
   * @callback CreateResumableUploadCallback
   * @param {?Error} err Request error, if any.
   * @param {string} uri The resumable upload's unique session URI.
   */
  /**
   * @typedef {array} CreateResumableUploadResponse
   * @property {string} 0 The resumable upload's unique session URI.
   */
  /**
   * @typedef {object} CreateResumableUploadOptions
   * @property {object} [metadata] Metadata to set on the file.
   * @property {number} [offset] The starting byte of the upload stream for resuming an interrupted upload.
   * @property {string} [origin] Origin header to set for the upload.
   * @property {string} [predefinedAcl] Apply a predefined set of access
   * controls to this object.
   *
   * Acceptable values are:
   * - **`authenticatedRead`** - Object owner gets `OWNER` access, and
   *   `allAuthenticatedUsers` get `READER` access.
   *
   * - **`bucketOwnerFullControl`** - Object owner gets `OWNER` access, and
   *   project team owners get `OWNER` access.
   *
   * - **`bucketOwnerRead`** - Object owner gets `OWNER` access, and project
   *   team owners get `READER` access.
   *
   * - **`private`** - Object owner gets `OWNER` access.
   *
   * - **`projectPrivate`** - Object owner gets `OWNER` access, and project
   *   team members get access according to their roles.
   *
   * - **`publicRead`** - Object owner gets `OWNER` access, and `allUsers`
   *   get `READER` access.
   * @property {boolean} [private] Make the uploaded file private. (Alias for
   *     `options.predefinedAcl = 'private'`)
   * @property {boolean} [public] Make the uploaded file public. (Alias for
   *     `options.predefinedAcl = 'publicRead'`)
   * @property {string} [userProject] The ID of the project which will be
   *     billed for the request.
   * @property {string} [chunkSize] Create a separate request per chunk. This
   *     value is in bytes and should be a multiple of 256 KiB (2^18).
   *     {@link https://cloud.google.com/storage/docs/performing-resumable-uploads#chunked-upload| We recommend using at least 8 MiB for the chunk size.}
   */
  /**
   * Create a unique resumable upload session URI. This is the first step when
   * performing a resumable upload.
   *
   * See the {@link https://cloud.google.com/storage/docs/json_api/v1/how-tos/resumable-upload| Resumable upload guide}
   * for more on how the entire process works.
   *
   * <h4>Note</h4>
   *
   * If you are just looking to perform a resumable upload without worrying
   * about any of the details, see {@link File#createWriteStream}. Resumable
   * uploads are performed by default.
   *
   * See {@link https://cloud.google.com/storage/docs/json_api/v1/how-tos/resumable-upload| Resumable upload guide}
   *
   * @param {CreateResumableUploadOptions} [options] Configuration options.
   * @param {CreateResumableUploadCallback} [callback] Callback function.
   * @returns {Promise<CreateResumableUploadResponse>}
   *
   * @example
   * ```
   * const {Storage} = require('@google-cloud/storage');
   * const storage = new Storage();
   * const myBucket = storage.bucket('my-bucket');
   *
   * const file = myBucket.file('my-file');
   * file.createResumableUpload(function(err, uri) {
   *   if (!err) {
   *     // `uri` can be used to PUT data to.
   *   }
   * });
   *
   * //-
   * // If the callback is omitted, we'll return a Promise.
   * //-
   * file.createResumableUpload().then(function(data) {
   *   const uri = data[0];
   * });
   * ```
   */
  createResumableUpload(e, t) {
    var i, n;
    let s = typeof e == "object" ? e : {};
    t = typeof e == "function" ? e : t;
    let c = this.storage.retryOptions;
    (((i = s?.preconditionOpts) === null || i === void 0 ? void 0 : i.ifGenerationMatch) === void 0 && ((n = this.instancePreconditionOpts) === null || n === void 0 ? void 0 : n.ifGenerationMatch) === void 0 && this.storage.retryOptions.idempotencyStrategy === _.RetryConditional || this.storage.retryOptions.idempotencyStrategy === _.RetryNever) && (c.autoRetry = !1), Vi({
      authClient: this.storage.authClient,
      apiEndpoint: this.storage.apiEndpoint,
      bucket: this.bucket.name,
      customRequestOptions: this.getRequestInterceptors().reduce((a, o) => o(a), {}),
      file: this.name,
      generation: this.generation,
      key: this.encryptionKey,
      kmsKeyName: this.kmsKeyName,
      metadata: s.metadata,
      offset: s.offset,
      origin: s.origin,
      predefinedAcl: s.predefinedAcl,
      private: s.private,
      public: s.public,
      userProject: s.userProject || this.userProject,
      retryOptions: c,
      params: s?.preconditionOpts || this.instancePreconditionOpts,
      universeDomain: this.bucket.storage.universeDomain,
      [T]: s[T]
    }, t), this.storage.retryOptions.autoRetry = this.instanceRetryValue;
  }
  /**
   * @typedef {object} CreateWriteStreamOptions Configuration options for File#createWriteStream().
   * @property {string} [contentType] Alias for
   *     `options.metadata.contentType`. If set to `auto`, the file name is used
   *     to determine the contentType.
   * @property {string|boolean} [gzip] If true, automatically gzip the file.
   *     If set to `auto`, the contentType is used to determine if the file
   * should be gzipped. This will set `options.metadata.contentEncoding` to
   * `gzip` if necessary.
   * @property {object} [metadata] See the examples below or
   *     {@link https://cloud.google.com/storage/docs/json_api/v1/objects/insert#request_properties_JSON| Objects: insert request body}
   *     for more details.
   * @property {number} [offset] The starting byte of the upload stream, for
   *     resuming an interrupted upload. Defaults to 0.
   * @property {string} [predefinedAcl] Apply a predefined set of access
   * controls to this object.
   *
   * Acceptable values are:
   * - **`authenticatedRead`** - Object owner gets `OWNER` access, and
   *   `allAuthenticatedUsers` get `READER` access.
   *
   * - **`bucketOwnerFullControl`** - Object owner gets `OWNER` access, and
   *   project team owners get `OWNER` access.
   *
   * - **`bucketOwnerRead`** - Object owner gets `OWNER` access, and project
   *   team owners get `READER` access.
   *
   * - **`private`** - Object owner gets `OWNER` access.
   *
   * - **`projectPrivate`** - Object owner gets `OWNER` access, and project
   *   team members get access according to their roles.
   *
   * - **`publicRead`** - Object owner gets `OWNER` access, and `allUsers`
   *   get `READER` access.
   * @property {boolean} [private] Make the uploaded file private. (Alias for
   *     `options.predefinedAcl = 'private'`)
   * @property {boolean} [public] Make the uploaded file public. (Alias for
   *     `options.predefinedAcl = 'publicRead'`)
   * @property {boolean} [resumable] Force a resumable upload. NOTE: When
   *     working with streams, the file format and size is unknown until it's
   *     completely consumed. Because of this, it's best for you to be explicit
   *     for what makes sense given your input.
   * @property {number} [timeout=60000] Set the HTTP request timeout in
   *     milliseconds. This option is not available for resumable uploads.
   *     Default: `60000`
   * @property {string} [uri] The URI for an already-created resumable
   *     upload. See {@link File#createResumableUpload}.
   * @property {string} [userProject] The ID of the project which will be
   *     billed for the request.
   * @property {string|boolean} [validation] Possible values: `"md5"`,
   *     `"crc32c"`, or `false`. By default, data integrity is validated with a
   *     CRC32c checksum. You may use MD5 if preferred, but that hash is not
   *     supported for composite objects. An error will be raised if MD5 is
   *     specified but is not available. You may also choose to skip validation
   *     completely, however this is **not recommended**. In addition to specifying
   *     validation type, providing `metadata.crc32c` or `metadata.md5Hash` will
   *     cause the server to perform validation in addition to client validation.
   *     NOTE: Validation is automatically skipped for objects that were
   *     uploaded using the `gzip` option and have already compressed content.
   */
  /**
   * Create a writable stream to overwrite the contents of the file in your
   * bucket.
   *
   * A File object can also be used to create files for the first time.
   *
   * Resumable uploads are automatically enabled and must be shut off explicitly
   * by setting `options.resumable` to `false`.
   *
   *
   * <p class="notice">
   *   There is some overhead when using a resumable upload that can cause
   *   noticeable performance degradation while uploading a series of small
   *   files. When uploading files less than 10MB, it is recommended that the
   *   resumable feature is disabled.
   * </p>
   *
   * NOTE: Writable streams will emit the `finish` event when the file is fully
   * uploaded.
   *
   * See {@link https://cloud.google.com/storage/docs/json_api/v1/how-tos/upload Upload Options (Simple or Resumable)}
   * See {@link https://cloud.google.com/storage/docs/json_api/v1/objects/insert Objects: insert API Documentation}
   *
   * @param {CreateWriteStreamOptions} [options] Configuration options.
   * @returns {WritableStream}
   *
   * @example
   * ```
   * const fs = require('fs');
   * const {Storage} = require('@google-cloud/storage');
   * const storage = new Storage();
   * const myBucket = storage.bucket('my-bucket');
   *
   * const file = myBucket.file('my-file');
   *
   * //-
   * // <h4>Uploading a File</h4>
   * //
   * // Now, consider a case where we want to upload a file to your bucket. You
   * // have the option of using {@link Bucket#upload}, but that is just
   * // a convenience method which will do the following.
   * //-
   * fs.createReadStream('/Users/stephen/Photos/birthday-at-the-zoo/panda.jpg')
   *   .pipe(file.createWriteStream())
   *   .on('error', function(err) {})
   *   .on('finish', function() {
   *     // The file upload is complete.
   *   });
   *
   * //-
   * // <h4>Uploading a File with gzip compression</h4>
   * //-
   * fs.createReadStream('/Users/stephen/site/index.html')
   *   .pipe(file.createWriteStream({ gzip: true }))
   *   .on('error', function(err) {})
   *   .on('finish', function() {
   *     // The file upload is complete.
   *   });
   *
   * //-
   * // Downloading the file with `createReadStream` will automatically decode
   * // the file.
   * //-
   *
   * //-
   * // <h4>Uploading a File with Metadata</h4>
   * //
   * // One last case you may run into is when you want to upload a file to your
   * // bucket and set its metadata at the same time. Like above, you can use
   * // {@link Bucket#upload} to do this, which is just a wrapper around
   * // the following.
   * //-
   * fs.createReadStream('/Users/stephen/Photos/birthday-at-the-zoo/panda.jpg')
   *   .pipe(file.createWriteStream({
   *     metadata: {
   *       contentType: 'image/jpeg',
   *       metadata: {
   *         custom: 'metadata'
   *       }
   *     }
   *   }))
   *   .on('error', function(err) {})
   *   .on('finish', function() {
   *     // The file upload is complete.
   *   });
   * ```
   *
   * //-
   * // <h4>Continuing a Resumable Upload</h4>
   * //
   * // One can capture a `uri` from a resumable upload to reuse later.
   * // Additionally, for validation, one can also capture and pass `crc32c`.
   * //-
   * let uri: string | undefined = undefined;
   * let resumeCRC32C: string | undefined = undefined;
   *
   * fs.createWriteStream()
   *   .on('uri', link => {uri = link})
   *   .on('crc32', crc32c => {resumeCRC32C = crc32c});
   *
   * // later...
   * fs.createWriteStream({uri, resumeCRC32C});
   */
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  createWriteStream(e = {}) {
    var t;
    if ((t = e.metadata) !== null && t !== void 0 || (e.metadata = {}), e.contentType && (e.metadata.contentType = e.contentType), !e.metadata.contentType || e.metadata.contentType === "auto") {
      let m = er.default.getType(this.name);
      m && (e.metadata.contentType = m);
    }
    let i = e.gzip;
    i === "auto" && (i = ts.test(e.metadata.contentType || "")), i && (e.metadata.contentEncoding = "gzip");
    let n = !0, s = !1;
    if (typeof e.validation == "string" ? (e.validation = e.validation.toLowerCase(), n = e.validation === "crc32c", s = e.validation === "md5") : e.validation === !1 && (n = !1, s = !1), e.offset) {
      if (s)
        throw new RangeError(I.MD5_RESUMED_UPLOAD);
      if (n && !e.isPartialUpload && !e.resumeCRC32C)
        throw new RangeError(I.MISSING_RESUME_CRC32C_FINAL_UPLOAD);
    }
    let c = /* @__PURE__ */ d((m) => {
      a.destroy(m || void 0);
    }, "pipelineCallback"), a = new es({
      final(m) {
        c = m, l.end();
      },
      write(m, h, g) {
        l.write(m, h, g);
      }
    });
    a.once("error", (m) => {
      l.destroy(m);
    }), a.once("close", () => {
      l.destroy();
    });
    let o = [];
    i && o.push(ot.createGzip());
    let l = new Ce(), p = null;
    if (n || s) {
      let m = e.resumeCRC32C ? J.from(e.resumeCRC32C) : void 0;
      p = new Fe({
        crc32c: n,
        crc32cInstance: m,
        md5: s,
        crc32cGenerator: this.crc32cGenerator,
        updateHashesOnly: !0
      }), o.push(p);
    }
    let u = (0, tr.default)(), f = !1;
    return l.on("reading", () => a.emit("reading")), l.on("writing", () => a.emit("writing")), u.on("uri", (m) => a.emit("uri", m)), u.on("progress", (m) => a.emit("progress", m)), u.on("response", (m) => a.emit("response", m)), u.once("metadata", () => {
      f = !0;
    }), a.once("writing", () => {
      e.resumable === !1 ? this.startSimpleUpload_(u, e) : this.startResumableUpload_(u, e), Ut(l, ...o, u, async (m) => {
        if (m)
          return c(m);
        if (!f)
          try {
            await new Promise((h, g) => {
              u.once("metadata", h), u.once("error", g);
            });
          } catch (h) {
            return c(h);
          }
        p?.crc32c && a.emit("crc32c", p.crc32c);
        try {
          let h = e.isPartialUpload && !this.metadata;
          p && !h && await Zn(this, Mt, "m", Ji).call(this, p, {
            crc32c: n,
            md5: s
          }), c();
        } catch (h) {
          c(h);
        }
      });
    }), a;
  }
  delete(e, t) {
    let i = typeof e == "object" ? e : {};
    t = typeof e == "function" ? e : t, this.disableAutoRetryConditionallyIdempotent_(this.methods.delete, G.delete, i), super.delete(i).then((n) => t(null, ...n)).catch(t).finally(() => {
      this.storage.retryOptions.autoRetry = this.instanceRetryValue;
    });
  }
  /**
   * @typedef {array} DownloadResponse
   * @property [0] The contents of a File.
   */
  /**
   * @callback DownloadCallback
   * @param err Request error, if any.
   * @param contents The contents of a File.
   */
  /**
   * Convenience method to download a file into memory or to a local
   * destination.
   *
   * @param {object} [options] Configuration options. The arguments match those
   *     passed to {@link File#createReadStream}.
   * @param {string} [options.destination] Local file path to write the file's
   *     contents to.
   * @param {string} [options.userProject] The ID of the project which will be
   *     billed for the request.
   * @param {DownloadCallback} [callback] Callback function.
   * @returns {Promise<DownloadResponse>}
   *
   * @example
   * ```
   * const {Storage} = require('@google-cloud/storage');
   * const storage = new Storage();
   * const myBucket = storage.bucket('my-bucket');
   *
   * const file = myBucket.file('my-file');
   *
   * //-
   * // Download a file into memory. The contents will be available as the
   * second
   * // argument in the demonstration below, `contents`.
   * //-
   * file.download(function(err, contents) {});
   *
   * //-
   * // Download a file to a local destination.
   * //-
   * file.download({
   *   destination: '/Users/me/Desktop/file-backup.txt'
   * }, function(err) {});
   *
   * //-
   * // If the callback is omitted, we'll return a Promise.
   * //-
   * file.download().then(function(data) {
   *   const contents = data[0];
   * });
   *
   * ```
   * @example <caption>include:samples/files.js</caption>
   * region_tag:storage_download_file
   * Another example:
   *
   * @example <caption>include:samples/encryption.js</caption>
   * region_tag:storage_download_encrypted_file
   * Example of downloading an encrypted file:
   *
   * @example <caption>include:samples/requesterPays.js</caption>
   * region_tag:storage_download_file_requester_pays
   * Example of downloading a file where the requester pays:
   */
  download(e, t) {
    let i;
    typeof e == "function" ? (t = e, i = {}) : i = e;
    let n = !1, s = /* @__PURE__ */ d((...l) => {
      n || t(...l), n = !0;
    }, "callback"), c = i.destination;
    delete i.destination;
    let a = this.createReadStream(i), o = !1;
    c ? a.on("error", s).once("data", (l) => {
      o = !0;
      let p = at.createWriteStream(c);
      p.write(l), a.pipe(p).on("error", (u) => {
        s(u, Buffer.from(""));
      }).on("finish", () => {
        s(null, l);
      });
    }).on("end", () => {
      if (!o) {
        let l = Buffer.alloc(0);
        try {
          at.writeFileSync(c, l), s(null, l);
        } catch (p) {
          s(p, l);
        }
      }
    }) : this.getBufferFromReadable(a).then((l) => s?.(null, l)).catch(s);
  }
  /**
   * The Storage API allows you to use a custom key for server-side encryption.
   *
   * See {@link https://cloud.google.com/storage/docs/encryption#customer-supplied| Customer-supplied Encryption Keys}
   *
   * @param {string|buffer} encryptionKey An AES-256 encryption key.
   * @returns {File}
   *
   * @example
   * ```
   * const crypto = require('crypto');
   * const {Storage} = require('@google-cloud/storage');
   * const storage = new Storage();
   * const myBucket = storage.bucket('my-bucket');
   *
   * const encryptionKey = crypto.randomBytes(32);
   *
   * const fileWithCustomEncryption = myBucket.file('my-file');
   * fileWithCustomEncryption.setEncryptionKey(encryptionKey);
   *
   * const fileWithoutCustomEncryption = myBucket.file('my-file');
   *
   * fileWithCustomEncryption.save('data', function(err) {
   *   // Try to download with the File object that hasn't had
   *   // `setEncryptionKey()` called:
   *   fileWithoutCustomEncryption.download(function(err) {
   *     // We will receive an error:
   *     //   err.message === 'Bad Request'
   *
   *     // Try again with the File object we called `setEncryptionKey()` on:
   *     fileWithCustomEncryption.download(function(err, contents) {
   *       // contents.toString() === 'data'
   *     });
   *   });
   * });
   *
   * ```
   * @example <caption>include:samples/encryption.js</caption>
   * region_tag:storage_upload_encrypted_file
   * Example of uploading an encrypted file:
   *
   * @example <caption>include:samples/encryption.js</caption>
   * region_tag:storage_download_encrypted_file
   * Example of downloading an encrypted file:
   */
  setEncryptionKey(e) {
    return this.encryptionKey = e, this.encryptionKeyBase64 = Buffer.from(e).toString("base64"), this.encryptionKeyHash = Zi.createHash("sha256").update(this.encryptionKeyBase64, "base64").digest("base64"), this.encryptionKeyInterceptor = {
      request: /* @__PURE__ */ d((t) => (t.headers = t.headers || {}, t.headers["x-goog-encryption-algorithm"] = "AES256", t.headers["x-goog-encryption-key"] = this.encryptionKeyBase64, t.headers["x-goog-encryption-key-sha256"] = this.encryptionKeyHash, t), "request")
    }, this.interceptors.push(this.encryptionKeyInterceptor), this;
  }
  /**
   * Gets a reference to a Cloud Storage {@link File} file from the provided URL in string format.
   * @param {string} publicUrlOrGsUrl the URL as a string. Must be of the format gs://bucket/file
   *  or https://storage.googleapis.com/bucket/file.
   * @param {Storage} storageInstance an instance of a Storage object.
   * @param {FileOptions} [options] Configuration options
   * @returns {File}
   */
  static from(e, t, i) {
    let n = [...e.matchAll(is)], s = [...e.matchAll(rs)];
    if (n.length > 0) {
      let c = new F(t, n[0][2]);
      return new r(c, n[0][3], i);
    } else if (s.length > 0) {
      let c = new F(t, s[0][3]);
      return new r(c, s[0][4], i);
    } else
      throw new Error("URL string must be of format gs://bucket/file or https://storage.googleapis.com/bucket/file");
  }
  get(e, t) {
    let i = typeof e == "object" ? e : {};
    t = typeof e == "function" ? e : t, super.get(i).then((n) => t(null, ...n)).catch(t);
  }
  /**
   * @typedef {array} GetExpirationDateResponse
   * @property {date} 0 A Date object representing the earliest time this file's
   *     retention policy will expire.
   */
  /**
   * @callback GetExpirationDateCallback
   * @param {?Error} err Request error, if any.
   * @param {date} expirationDate A Date object representing the earliest time
   *     this file's retention policy will expire.
   */
  /**
   * If this bucket has a retention policy defined, use this method to get a
   * Date object representing the earliest time this file will expire.
   *
   * @param {GetExpirationDateCallback} [callback] Callback function.
   * @returns {Promise<GetExpirationDateResponse>}
   *
   * @example
   * ```
   * const storage = require('@google-cloud/storage')();
   * const myBucket = storage.bucket('my-bucket');
   *
   * const file = myBucket.file('my-file');
   *
   * file.getExpirationDate(function(err, expirationDate) {
   *   // expirationDate is a Date object.
   * });
   * ```
   */
  getExpirationDate(e) {
    this.getMetadata((t, i, n) => {
      if (t) {
        e(t, null, n);
        return;
      }
      if (!i.retentionExpirationTime) {
        let s = new Error(I.EXPIRATION_TIME_NA);
        e(s, null, n);
        return;
      }
      e(null, new Date(i.retentionExpirationTime), n);
    });
  }
  /**
   * @typedef {array} GenerateSignedPostPolicyV2Response
   * @property {object} 0 The document policy.
   */
  /**
   * @callback GenerateSignedPostPolicyV2Callback
   * @param {?Error} err Request error, if any.
   * @param {object} policy The document policy.
   */
  /**
   * Get a signed policy document to allow a user to upload data with a POST
   * request.
   *
   * In Google Cloud Platform environments, such as Cloud Functions and App
   * Engine, you usually don't provide a `keyFilename` or `credentials` during
   * instantiation. In those environments, we call the
   * {@link https://cloud.google.com/iam/docs/reference/credentials/rest/v1/projects.serviceAccounts/signBlob| signBlob API}
   * to create a signed policy. That API requires either the
   * `https://www.googleapis.com/auth/iam` or
   * `https://www.googleapis.com/auth/cloud-platform` scope, so be sure they are
   * enabled.
   *
   * See {@link https://cloud.google.com/storage/docs/xml-api/post-object-v2| POST Object with the V2 signing process}
   *
   * @throws {Error} If an expiration timestamp from the past is given.
   * @throws {Error} If options.equals has an array with less or more than two
   *     members.
   * @throws {Error} If options.startsWith has an array with less or more than two
   *     members.
   *
   * @param {object} options Configuration options.
   * @param {array|array[]} [options.equals] Array of request parameters and
   *     their expected value (e.g. [['$<field>', '<value>']]). Values are
   *     translated into equality constraints in the conditions field of the
   *     policy document (e.g. ['eq', '$<field>', '<value>']). If only one
   *     equality condition is to be specified, options.equals can be a one-
   *     dimensional array (e.g. ['$<field>', '<value>']).
   * @param {*} options.expires - A timestamp when this policy will expire. Any
   *     value given is passed to `new Date()`.
   * @param {array|array[]} [options.startsWith] Array of request parameters and
   *     their expected prefixes (e.g. [['$<field>', '<value>']). Values are
   *     translated into starts-with constraints in the conditions field of the
   *     policy document (e.g. ['starts-with', '$<field>', '<value>']). If only
   *     one prefix condition is to be specified, options.startsWith can be a
   * one- dimensional array (e.g. ['$<field>', '<value>']).
   * @param {string} [options.acl] ACL for the object from possibly predefined
   *     ACLs.
   * @param {string} [options.successRedirect] The URL to which the user client
   *     is redirected if the upload is successful.
   * @param {string} [options.successStatus] - The status of the Google Storage
   *     response if the upload is successful (must be string).
   * @param {object} [options.contentLengthRange]
   * @param {number} [options.contentLengthRange.min] Minimum value for the
   *     request's content length.
   * @param {number} [options.contentLengthRange.max] Maximum value for the
   *     request's content length.
   * @param {GenerateSignedPostPolicyV2Callback} [callback] Callback function.
   * @returns {Promise<GenerateSignedPostPolicyV2Response>}
   *
   * @example
   * ```
   * const {Storage} = require('@google-cloud/storage');
   * const storage = new Storage();
   * const myBucket = storage.bucket('my-bucket');
   *
   * const file = myBucket.file('my-file');
   * const options = {
   *   equals: ['$Content-Type', 'image/jpeg'],
   *   expires: '10-25-2022',
   *   contentLengthRange: {
   *     min: 0,
   *     max: 1024
   *   }
   * };
   *
   * file.generateSignedPostPolicyV2(options, function(err, policy) {
   *   // policy.string: the policy document in plain text.
   *   // policy.base64: the policy document in base64.
   *   // policy.signature: the policy signature in base64.
   * });
   *
   * //-
   * // If the callback is omitted, we'll return a Promise.
   * //-
   * file.generateSignedPostPolicyV2(options).then(function(data) {
   *   const policy = data[0];
   * });
   * ```
   */
  generateSignedPostPolicyV2(e, t) {
    let i = U(e, t), n = i.options, s = i.callback, c = new Date(n.expires);
    if (isNaN(c.getTime()))
      throw new Error($.EXPIRATION_DATE_INVALID);
    if (c.valueOf() < Date.now())
      throw new Error($.EXPIRATION_DATE_PAST);
    n = Object.assign({}, n);
    let a = [
      ["eq", "$key", this.name],
      {
        bucket: this.bucket.name
      }
    ];
    if (Array.isArray(n.equals) && (Array.isArray(n.equals[0]) || (n.equals = [n.equals]), n.equals.forEach((u) => {
      if (!Array.isArray(u) || u.length !== 2)
        throw new Error(I.EQUALS_CONDITION_TWO_ELEMENTS);
      a.push(["eq", u[0], u[1]]);
    })), Array.isArray(n.startsWith) && (Array.isArray(n.startsWith[0]) || (n.startsWith = [n.startsWith]), n.startsWith.forEach((u) => {
      if (!Array.isArray(u) || u.length !== 2)
        throw new Error(I.STARTS_WITH_TWO_ELEMENTS);
      a.push(["starts-with", u[0], u[1]]);
    })), n.acl && a.push({
      acl: n.acl
    }), n.successRedirect && a.push({
      success_action_redirect: n.successRedirect
    }), n.successStatus && a.push({
      success_action_status: n.successStatus
    }), n.contentLengthRange) {
      let u = n.contentLengthRange.min, f = n.contentLengthRange.max;
      if (typeof u != "number" || typeof f != "number")
        throw new Error(I.CONTENT_LENGTH_RANGE_MIN_MAX);
      a.push(["content-length-range", u, f]);
    }
    let o = {
      expiration: c.toISOString(),
      conditions: a
    }, l = JSON.stringify(o), p = Buffer.from(l).toString("base64");
    this.storage.authClient.sign(p, n.signingEndpoint).then((u) => {
      s(null, {
        string: l,
        base64: p,
        signature: u
      });
    }, (u) => {
      s(new me(u.message));
    });
  }
  /**
   * @typedef {object} SignedPostPolicyV4Output
   * @property {string} url The request URL.
   * @property {object} fields The form fields to include in the POST request.
   */
  /**
   * @typedef {array} GenerateSignedPostPolicyV4Response
   * @property {SignedPostPolicyV4Output} 0 An object containing the request URL and form fields.
   */
  /**
   * @callback GenerateSignedPostPolicyV4Callback
   * @param {?Error} err Request error, if any.
   * @param {SignedPostPolicyV4Output} output An object containing the request URL and form fields.
   */
  /**
   * Get a v4 signed policy document to allow a user to upload data with a POST
   * request.
   *
   * In Google Cloud Platform environments, such as Cloud Functions and App
   * Engine, you usually don't provide a `keyFilename` or `credentials` during
   * instantiation. In those environments, we call the
   * {@link https://cloud.google.com/iam/docs/reference/credentials/rest/v1/projects.serviceAccounts/signBlob| signBlob API}
   * to create a signed policy. That API requires either the
   * `https://www.googleapis.com/auth/iam` or
   * `https://www.googleapis.com/auth/cloud-platform` scope, so be sure they are
   * enabled.
   *
   * See {@link https://cloud.google.com/storage/docs/xml-api/post-object#policydocument| Policy Document Reference}
   *
   * @param {object} options Configuration options.
   * @param {Date|number|string} options.expires - A timestamp when this policy will expire. Any
   *     value given is passed to `new Date()`.
   * @param {boolean} [config.virtualHostedStyle=false] Use virtual hosted-style
   *     URLs ('https://mybucket.storage.googleapis.com/...') instead of path-style
   *     ('https://storage.googleapis.com/mybucket/...'). Virtual hosted-style URLs
   *     should generally be preferred instead of path-style URL.
   *     Currently defaults to `false` for path-style, although this may change in a
   *     future major-version release.
   * @param {string} [config.bucketBoundHostname] The bucket-bound hostname to return in
   *     the result, e.g. "https://cdn.example.com".
   * @param {object} [config.fields] [Form fields]{@link https://cloud.google.com/storage/docs/xml-api/post-object#policydocument}
   *     to include in the signed policy. Any fields with key beginning with 'x-ignore-'
   *     will not be included in the policy to be signed.
   * @param {object[]} [config.conditions] [Conditions]{@link https://cloud.google.com/storage/docs/authentication/signatures#policy-document}
   *     to include in the signed policy. All fields given in `config.fields` are
   *     automatically included in the conditions array, adding the same entry
   *     in both `fields` and `conditions` will result in duplicate entries.
   *
   * @param {GenerateSignedPostPolicyV4Callback} [callback] Callback function.
   * @returns {Promise<GenerateSignedPostPolicyV4Response>}
   *
   * @example
   * ```
   * const {Storage} = require('@google-cloud/storage');
   * const storage = new Storage();
   * const myBucket = storage.bucket('my-bucket');
   *
   * const file = myBucket.file('my-file');
   * const options = {
   *   expires: '10-25-2022',
   *   conditions: [
   *     ['eq', '$Content-Type', 'image/jpeg'],
   *     ['content-length-range', 0, 1024],
   *   ],
   *   fields: {
   *     acl: 'public-read',
   *     'x-goog-meta-foo': 'bar',
   *     'x-ignore-mykey': 'data'
   *   }
   * };
   *
   * file.generateSignedPostPolicyV4(options, function(err, response) {
   *   // response.url The request URL
   *   // response.fields The form fields (including the signature) to include
   *   //     to be used to upload objects by HTML forms.
   * });
   *
   * //-
   * // If the callback is omitted, we'll return a Promise.
   * //-
   * file.generateSignedPostPolicyV4(options).then(function(data) {
   *   const response = data[0];
   *   // response.url The request URL
   *   // response.fields The form fields (including the signature) to include
   *   //     to be used to upload objects by HTML forms.
   * });
   * ```
   */
  generateSignedPostPolicyV4(e, t) {
    let i = U(e, t), n = i.options, s = i.callback, c = new Date(n.expires);
    if (isNaN(c.getTime()))
      throw new Error($.EXPIRATION_DATE_INVALID);
    if (c.valueOf() < Date.now())
      throw new Error($.EXPIRATION_DATE_PAST);
    if (c.valueOf() - Date.now() > Yi * 1e3)
      throw new Error(`Max allowed expiration is seven days (${Yi} seconds).`);
    n = Object.assign({}, n);
    let a = Object.assign({}, n.fields), o = /* @__PURE__ */ new Date(), l = pe(o, !0), p = pe(o);
    (/* @__PURE__ */ d(async () => {
      let { client_email: f } = await this.storage.authClient.getCredentials(), m = `${f}/${p}/auto/storage/goog4_request`;
      a = {
        ...a,
        bucket: this.bucket.name,
        key: this.name,
        "x-goog-date": l,
        "x-goog-credential": m,
        "x-goog-algorithm": "GOOG4-RSA-SHA256"
      };
      let h = n.conditions || [];
      Object.entries(a).forEach(([N, q]) => {
        N.startsWith("x-ignore-") || h.push({ [N]: q });
      }), delete a.bucket;
      let g = pe(c, !0, "-", ":"), x = mi({
        conditions: h,
        expiration: g
      }), w = Buffer.from(x).toString("base64");
      try {
        let N = await this.storage.authClient.sign(w, n.signingEndpoint), q = Buffer.from(N, "base64").toString("hex"), A = this.parent.storage.universeDomain;
        a.policy = w, a["x-goog-signature"] = q;
        let j;
        return this.storage.customEndpoint ? j = this.storage.apiEndpoint : n.virtualHostedStyle ? j = `https://${this.bucket.name}.storage.${A}/` : n.bucketBoundHostname ? j = `${n.bucketBoundHostname}/` : j = `https://storage.${A}/${this.bucket.name}/`, {
          url: j,
          fields: a
        };
      } catch (N) {
        throw new me(N.message);
      }
    }, "sign"))().then((f) => s(null, f), s);
  }
  /**
   * @typedef {array} GetSignedUrlResponse
   * @property {object} 0 The signed URL.
   */
  /**
   * @callback GetSignedUrlCallback
   * @param {?Error} err Request error, if any.
   * @param {object} url The signed URL.
   */
  /**
   * Get a signed URL to allow limited time access to the file.
   *
   * In Google Cloud Platform environments, such as Cloud Functions and App
   * Engine, you usually don't provide a `keyFilename` or `credentials` during
   * instantiation. In those environments, we call the
   * {@link https://cloud.google.com/iam/docs/reference/credentials/rest/v1/projects.serviceAccounts/signBlob| signBlob API}
   * to create a signed URL. That API requires either the
   * `https://www.googleapis.com/auth/iam` or
   * `https://www.googleapis.com/auth/cloud-platform` scope, so be sure they are
   * enabled.
   *
   * See {@link https://cloud.google.com/storage/docs/access-control/signed-urls| Signed URLs Reference}
   *
   * @throws {Error} if an expiration timestamp from the past is given.
   *
   * @param {object} config Configuration object.
   * @param {string} config.action "read" (HTTP: GET), "write" (HTTP: PUT), or
   *     "delete" (HTTP: DELETE), "resumable" (HTTP: POST).
   *     When using "resumable", the header `X-Goog-Resumable: start` has
   *     to be sent when making a request with the signed URL.
   * @param {*} config.expires A timestamp when this link will expire. Any value
   *     given is passed to `new Date()`.
   *     Note: 'v4' supports maximum duration of 7 days (604800 seconds) from now.
   *     See [reference]{@link https://cloud.google.com/storage/docs/access-control/signed-urls#example}
   * @param {string} [config.version='v2'] The signing version to use, either
   *     'v2' or 'v4'.
   * @param {boolean} [config.virtualHostedStyle=false] Use virtual hosted-style
   *     URLs (e.g. 'https://mybucket.storage.googleapis.com/...') instead of path-style
   *     (e.g. 'https://storage.googleapis.com/mybucket/...'). Virtual hosted-style URLs
   *     should generally be preferred instaed of path-style URL.
   *     Currently defaults to `false` for path-style, although this may change in a
   *     future major-version release.
   * @param {string} [config.cname] The cname for this bucket, i.e.,
   *     "https://cdn.example.com".
   * @param {string} [config.contentMd5] The MD5 digest value in base64. Just like
   *     if you provide this, the client must provide this HTTP header with this same
   *     value in its request, so to if this parameter is not provided here,
   *     the client must not provide any value for this HTTP header in its request.
   * @param {string} [config.contentType] Just like if you provide this, the client
   *     must provide this HTTP header with this same value in its request, so to if
   *     this parameter is not provided here, the client must not provide any value
   *     for this HTTP header in its request.
   * @param {object} [config.extensionHeaders] If these headers are used, the
   * server will check to make sure that the client provides matching
   * values. See {@link https://cloud.google.com/storage/docs/access-control/signed-urls#about-canonical-extension-headers| Canonical extension headers}
   * for the requirements of this feature, most notably:
   * - The header name must be prefixed with `x-goog-`
   * - The header name must be all lowercase
   *
   * Note: Multi-valued header passed as an array in the extensionHeaders
   *       object is converted into a string, delimited by `,` with
   *       no space. Requests made using the signed URL will need to
   *       delimit multi-valued headers using a single `,` as well, or
   *       else the server will report a mismatched signature.
   * @param {object} [config.queryParams] Additional query parameters to include
   *     in the signed URL.
   * @param {string} [config.promptSaveAs] The filename to prompt the user to
   *     save the file as when the signed url is accessed. This is ignored if
   *     `config.responseDisposition` is set.
   * @param {string} [config.responseDisposition] The
   *     {@link http://goo.gl/yMWxQV| response-content-disposition parameter} of the
   *     signed url.
   * @param {*} [config.accessibleAt=Date.now()] A timestamp when this link became usable. Any value
   *     given is passed to `new Date()`.
   *     Note: Use for 'v4' only.
   * @param {string} [config.responseType] The response-content-type parameter
   *     of the signed url.
   * @param {GetSignedUrlCallback} [callback] Callback function.
   * @returns {Promise<GetSignedUrlResponse>}
   *
   * @example
   * ```
   * const {Storage} = require('@google-cloud/storage');
   * const storage = new Storage();
   * const myBucket = storage.bucket('my-bucket');
   *
   * const file = myBucket.file('my-file');
   *
   * //-
   * // Generate a URL that allows temporary access to download your file.
   * //-
   * const request = require('request');
   *
   * const config = {
   *   action: 'read',
   *   expires: '03-17-2025',
   * };
   *
   * file.getSignedUrl(config, function(err, url) {
   *   if (err) {
   *     console.error(err);
   *     return;
   *   }
   *
   *   // The file is now available to read from this URL.
   *   request(url, function(err, resp) {
   *     // resp.statusCode = 200
   *   });
   * });
   *
   * //-
   * // Generate a URL that allows temporary access to download your file.
   * // Access will begin at accessibleAt and end at expires.
   * //-
   * const request = require('request');
   *
   * const config = {
   *   action: 'read',
   *   expires: '03-17-2025',
   *   accessibleAt: '03-13-2025'
   * };
   *
   * file.getSignedUrl(config, function(err, url) {
   *   if (err) {
   *     console.error(err);
   *     return;
   *   }
   *
   *   // The file will be available to read from this URL from 03-13-2025 to 03-17-2025.
   *   request(url, function(err, resp) {
   *     // resp.statusCode = 200
   *   });
   * });
   *
   * //-
   * // Generate a URL to allow write permissions. This means anyone with this
   * URL
   * // can send a POST request with new data that will overwrite the file.
   * //-
   * file.getSignedUrl({
   *   action: 'write',
   *   expires: '03-17-2025'
   * }, function(err, url) {
   *   if (err) {
   *     console.error(err);
   *     return;
   *   }
   *
   *   // The file is now available to be written to.
   *   const writeStream = request.put(url);
   *   writeStream.end('New data');
   *
   *   writeStream.on('complete', function(resp) {
   *     // Confirm the new content was saved.
   *     file.download(function(err, fileContents) {
   *       console.log('Contents:', fileContents.toString());
   *       // Contents: New data
   *     });
   *   });
   * });
   *
   * //-
   * // If the callback is omitted, we'll return a Promise.
   * //-
   * file.getSignedUrl(config).then(function(data) {
   *   const url = data[0];
   * });
   *
   * ```
   * @example <caption>include:samples/files.js</caption>
   * region_tag:storage_generate_signed_url
   * Another example:
   */
  getSignedUrl(e, t) {
    let i = Dt[e.action], n = fi(e.extensionHeaders || {});
    e.action === "resumable" && (n["x-goog-resumable"] = "start");
    let s = Object.assign({}, e.queryParams);
    typeof e.responseType == "string" && (s["response-content-type"] = e.responseType), typeof e.promptSaveAs == "string" && (s["response-content-disposition"] = 'attachment; filename="' + e.promptSaveAs + '"'), typeof e.responseDisposition == "string" && (s["response-content-disposition"] = e.responseDisposition), this.generation && (s.generation = this.generation.toString());
    let c = {
      method: i,
      expires: e.expires,
      accessibleAt: e.accessibleAt,
      extensionHeaders: n,
      queryParams: s,
      contentMd5: e.contentMd5,
      contentType: e.contentType,
      host: e.host
    };
    e.cname && (c.cname = e.cname), e.version && (c.version = e.version), e.virtualHostedStyle && (c.virtualHostedStyle = e.virtualHostedStyle), this.signer || (this.signer = new Re(this.storage.authClient, this.bucket, this, this.storage)), this.signer.getSignedUrl(c).then((a) => t(null, a), t);
  }
  /**
   * @callback IsPublicCallback
   * @param {?Error} err Request error, if any.
   * @param {boolean} resp Whether file is public or not.
   */
  /**
   * @typedef {array} IsPublicResponse
   * @property {boolean} 0 Whether file is public or not.
   */
  /**
   * Check whether this file is public or not by sending
   * a HEAD request without credentials.
   * No errors from the server indicates that the current
   * file is public.
   * A 403-Forbidden error {@link https://cloud.google.com/storage/docs/json_api/v1/status-codes#403_Forbidden}
   * indicates that file is private.
   * Any other non 403 error is propagated to user.
   *
   * @param {IsPublicCallback} [callback] Callback function.
   * @returns {Promise<IsPublicResponse>}
   *
   * @example
   * ```
   * const {Storage} = require('@google-cloud/storage');
   * const storage = new Storage();
   * const myBucket = storage.bucket('my-bucket');
   *
   * const file = myBucket.file('my-file');
   *
   * //-
   * // Check whether the file is publicly accessible.
   * //-
   * file.isPublic(function(err, resp) {
   *   if (err) {
   *     console.error(err);
   *     return;
   *   }
   *   console.log(`the file ${file.id} is public: ${resp}`) ;
   * })
   * //-
   * // If the callback is omitted, we'll return a Promise.
   * //-
   * file.isPublic().then(function(data) {
   *   const resp = data[0];
   * });
   * ```
   */
  isPublic(e) {
    var t;
    let i = ((t = this.storage) === null || t === void 0 ? void 0 : t.interceptors) || [], n = this.interceptors || [], c = i.concat(n).reduce((a, o) => {
      let l = o.request({
        uri: `${this.storage.apiEndpoint}/${this.bucket.name}/${encodeURIComponent(this.name)}`
      });
      return Object.assign(a, l.headers), a;
    }, {});
    b.makeRequest({
      method: "GET",
      uri: `${this.storage.apiEndpoint}/${this.bucket.name}/${encodeURIComponent(this.name)}`,
      headers: c
    }, {
      retryOptions: this.storage.retryOptions
    }, (a) => {
      a ? a.code === 403 ? e(null, !1) : e(a) : e(null, !0);
    });
  }
  /**
   * @typedef {object} MakeFilePrivateOptions Configuration options for File#makePrivate().
   * @property {Metadata} [metadata] Define custom metadata properties to define
   *     along with the operation.
   * @property {boolean} [strict] If true, set the file to be private to
   *     only the owner user. Otherwise, it will be private to the project.
   * @property {string} [userProject] The ID of the project which will be
   *     billed for the request.
   */
  /**
   * @callback MakeFilePrivateCallback
   * @param {?Error} err Request error, if any.
   * @param {object} apiResponse The full API response.
   */
  /**
   * @typedef {array} MakeFilePrivateResponse
   * @property {object} 0 The full API response.
   */
  /**
   * Make a file private to the project and remove all other permissions.
   * Set `options.strict` to true to make the file private to only the owner.
   *
   * See {@link https://cloud.google.com/storage/docs/json_api/v1/objects/patch| Objects: patch API Documentation}
   *
   * @param {MakeFilePrivateOptions} [options] Configuration options.
   * @param {MakeFilePrivateCallback} [callback] Callback function.
   * @returns {Promise<MakeFilePrivateResponse>}
   *
   * @example
   * ```
   * const {Storage} = require('@google-cloud/storage');
   * const storage = new Storage();
   * const myBucket = storage.bucket('my-bucket');
   *
   * const file = myBucket.file('my-file');
   *
   * //-
   * // Set the file private so only project maintainers can see and modify it.
   * //-
   * file.makePrivate(function(err) {});
   *
   * //-
   * // Set the file private so only the owner can see and modify it.
   * //-
   * file.makePrivate({ strict: true }, function(err) {});
   *
   * //-
   * // If the callback is omitted, we'll return a Promise.
   * //-
   * file.makePrivate().then(function(data) {
   *   const apiResponse = data[0];
   * });
   * ```
   */
  makePrivate(e, t) {
    var i, n;
    let s = typeof e == "object" ? e : {};
    t = typeof e == "function" ? e : t;
    let c = {
      predefinedAcl: s.strict ? "private" : "projectPrivate"
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
    };
    ((i = s.preconditionOpts) === null || i === void 0 ? void 0 : i.ifMetagenerationMatch) !== void 0 && (c.ifMetagenerationMatch = (n = s.preconditionOpts) === null || n === void 0 ? void 0 : n.ifMetagenerationMatch, delete s.preconditionOpts), s.userProject && (c.userProject = s.userProject);
    let a = { ...s.metadata, acl: null };
    this.setMetadata(a, c, t);
  }
  /**
   * @typedef {array} MakeFilePublicResponse
   * @property {object} 0 The full API response.
   */
  /**
   * @callback MakeFilePublicCallback
   * @param {?Error} err Request error, if any.
   * @param {object} apiResponse The full API response.
   */
  /**
   * Set a file to be publicly readable and maintain all previous permissions.
   *
   * See {@link https://cloud.google.com/storage/docs/json_api/v1/objectAccessControls/insert| ObjectAccessControls: insert API Documentation}
   *
   * @param {MakeFilePublicCallback} [callback] Callback function.
   * @returns {Promise<MakeFilePublicResponse>}
   *
   * @example
   * ```
   * const {Storage} = require('@google-cloud/storage');
   * const storage = new Storage();
   * const myBucket = storage.bucket('my-bucket');
   *
   * const file = myBucket.file('my-file');
   *
   * file.makePublic(function(err, apiResponse) {});
   *
   * //-
   * // If the callback is omitted, we'll return a Promise.
   * //-
   * file.makePublic().then(function(data) {
   *   const apiResponse = data[0];
   * });
   *
   * ```
   * @example <caption>include:samples/files.js</caption>
   * region_tag:storage_make_public
   * Another example:
   */
  makePublic(e) {
    e = e || b.noop, this.acl.add({
      entity: "allUsers",
      role: "READER"
    }, (t, i, n) => {
      e(t, n);
    });
  }
  /**
   * The public URL of this File
   * Use {@link File#makePublic} to enable anonymous access via the returned URL.
   *
   * @returns {string}
   *
   * @example
   * ```
   * const {Storage} = require('@google-cloud/storage');
   * const storage = new Storage();
   * const bucket = storage.bucket('albums');
   * const file = bucket.file('my-file');
   *
   * // publicUrl will be "https://storage.googleapis.com/albums/my-file"
   * const publicUrl = file.publicUrl();
   * ```
   */
  publicUrl() {
    return `${this.storage.apiEndpoint}/${this.bucket.name}/${encodeURIComponent(this.name)}`;
  }
  /**
   * @typedef {array} MoveFileAtomicResponse
   * @property {File} 0 The moved {@link File}.
   * @property {object} 1 The full API response.
   */
  /**
   * @callback MoveFileAtomicCallback
   * @param {?Error} err Request error, if any.
   * @param {File} movedFile The moved {@link File}.
   * @param {object} apiResponse The full API response.
   */
  /**
   * @typedef {object} MoveFileAtomicOptions Configuration options for File#moveFileAtomic(). See an
   *     {@link https://cloud.google.com/storage/docs/json_api/v1/objects#resource| Object resource}.
   * @property {string} [userProject] The ID of the project which will be
   *     billed for the request.
   * @property {object} [preconditionOpts] Precondition options.
   * @property {number} [preconditionOpts.ifGenerationMatch] Makes the operation conditional on whether the object's current generation matches the given value.
   */
  /**
   * Move this file within the same HNS-enabled bucket.
   * The source object must exist and be a live object.
   * The source and destination object IDs must be different.
   * Overwriting the destination object is allowed by default, but can be prevented
   * using preconditions.
   * If the destination path includes non-existent parent folders, they will be created.
   *
   * See {@link https://cloud.google.com/storage/docs/json_api/v1/objects/move| Objects: move API Documentation}
   *
   * @throws {Error} If the destination file is not provided.
   *
   * @param {string|File} destination Destination file name or File object within the same bucket..
   * @param {MoveFileAtomicOptions} [options] Configuration options. See an
   * @param {MoveFileAtomicCallback} [callback] Callback function.
   * @returns {Promise<MoveFileAtomicResponse>}
   *
   * @example
   * ```
   * const {Storage} = require('@google-cloud/storage');
   * const storage = new Storage();
   *
   * //-
   * // Assume 'my-hns-bucket' is an HNS-enabled bucket.
   * //-
   * const bucket = storage.bucket('my-hns-bucket');
   * const file = bucket.file('my-image.png');
   *
   * //-
   * // If you pass in a string for the destination, the file is copied to its
   * // current bucket, under the new name provided.
   * //-
   * file.moveFileAtomic('moved-image.png', function(err, movedFile, apiResponse) {
   *   // `my-hns-bucket` now contains:
   *   // - "moved-image.png"
   *
   *   // `movedFile` is an instance of a File object that refers to your new
   *   // file.
   * });
   *
   * //-
   * // Move the file to a subdirectory, creating parent folders if necessary.
   * //-
   * file.moveFileAtomic('new-folder/subfolder/moved-image.png', function(err, movedFile, apiResponse) {
   * // `my-hns-bucket` now contains:
   * // - "new-folder/subfolder/moved-image.png"
   * });
   *
   * //-
   * // Prevent overwriting an existing destination object using preconditions.
   * //-
   * file.moveFileAtomic('existing-destination.png', {
   * preconditionOpts: {
   * ifGenerationMatch: 0 // Fails if the destination object exists.
   * }
   * }, function(err, movedFile, apiResponse) {
   * if (err) {
   * // Handle the error (e.g., the destination object already exists).
   * } else {
   * // Move successful.
   * }
   * });
   *
   * //-
   * // If the callback is omitted, we'll return a Promise.
   * //-
   * file.moveFileAtomic('moved-image.png).then(function(data) {
   *   const newFile = data[0];
   *   const apiResponse = data[1];
   * });
   *
   * ```
   * @example <caption>include:samples/files.js</caption>
   * region_tag:storage_move_file_hns
   * Another example:
   */
  moveFileAtomic(e, t, i) {
    var n, s;
    let c = new Error(I.DESTINATION_NO_NAME);
    if (!e)
      throw c;
    let a = {};
    typeof t == "function" ? i = t : t && (a = { ...t }), i = i || b.noop;
    let o, l;
    if (typeof e == "string") {
      let u = Xi.exec(e);
      u !== null && u.length === 3 ? o = u[2] : o = e;
    } else if (e instanceof r)
      o = e.name, l = e;
    else
      throw c;
    l = l || this.bucket.file(o), this.shouldRetryBasedOnPreconditionAndIdempotencyStrat(a?.preconditionOpts) || (this.storage.retryOptions.autoRetry = !1);
    let p = {};
    a.userProject !== void 0 && (p.userProject = a.userProject, delete a.userProject), ((n = a.preconditionOpts) === null || n === void 0 ? void 0 : n.ifGenerationMatch) !== void 0 && (p.ifGenerationMatch = (s = a.preconditionOpts) === null || s === void 0 ? void 0 : s.ifGenerationMatch, delete a.preconditionOpts), this.request({
      method: "POST",
      uri: `/moveTo/o/${encodeURIComponent(l.name)}`,
      qs: p,
      json: a
    }, (u, f) => {
      if (this.storage.retryOptions.autoRetry = this.instanceRetryValue, u) {
        i(u, null, f);
        return;
      }
      i(null, l, f);
    });
  }
  /**
   * @typedef {array} MoveResponse
   * @property {File} 0 The destination File.
   * @property {object} 1 The full API response.
   */
  /**
   * @callback MoveCallback
   * @param {?Error} err Request error, if any.
   * @param {?File} destinationFile The destination File.
   * @param {object} apiResponse The full API response.
   */
  /**
   * @typedef {object} MoveOptions Configuration options for File#move(). See an
   *     {@link https://cloud.google.com/storage/docs/json_api/v1/objects#resource| Object resource}.
   * @param {string} [userProject] The ID of the project which will be
   *     billed for the request.
   */
  /**
   * Move this file to another location. By default, this will rename the file
   * and keep it in the same bucket, but you can choose to move it to another
   * Bucket by providing a Bucket or File object or a URL beginning with
   * "gs://".
   *
   * **Warning**:
   * There is currently no atomic `move` method in the Cloud Storage API,
   * so this method is a composition of {@link File#copy} (to the new
   * location) and {@link File#delete} (from the old location). While
   * unlikely, it is possible that an error returned to your callback could be
   * triggered from either one of these API calls failing, which could leave a
   * duplicate file lingering. The error message will indicate what operation
   * has failed.
   *
   * See {@link https://cloud.google.com/storage/docs/json_api/v1/objects/copy| Objects: copy API Documentation}
   *
   * @throws {Error} If the destination file is not provided.
   *
   * @param {string|Bucket|File} destination Destination file.
   * @param {MoveCallback} [callback] Callback function.
   * @returns {Promise<MoveResponse>}
   *
   * @example
   * ```
   * const {Storage} = require('@google-cloud/storage');
   * const storage = new Storage();
   * //-
   * // You can pass in a variety of types for the destination.
   * //
   * // For all of the below examples, assume we are working with the following
   * // Bucket and File objects.
   * //-
   * const bucket = storage.bucket('my-bucket');
   * const file = bucket.file('my-image.png');
   *
   * //-
   * // If you pass in a string for the destination, the file is moved to its
   * // current bucket, under the new name provided.
   * //-
   * file.move('my-image-new.png', function(err, destinationFile, apiResponse) {
   *   // `my-bucket` no longer contains:
   *   // - "my-image.png"
   *   // but contains instead:
   *   // - "my-image-new.png"
   *
   *   // `destinationFile` is an instance of a File object that refers to your
   *   // new file.
   * });
   *
   * //-
   * // If you pass in a string starting with "gs://" for the destination, the
   * // file is copied to the other bucket and under the new name provided.
   * //-
   * const newLocation = 'gs://another-bucket/my-image-new.png';
   * file.move(newLocation, function(err, destinationFile, apiResponse) {
   *   // `my-bucket` no longer contains:
   *   // - "my-image.png"
   *   //
   *   // `another-bucket` now contains:
   *   // - "my-image-new.png"
   *
   *   // `destinationFile` is an instance of a File object that refers to your
   *   // new file.
   * });
   *
   * //-
   * // If you pass in a Bucket object, the file will be moved to that bucket
   * // using the same name.
   * //-
   * const anotherBucket = gcs.bucket('another-bucket');
   *
   * file.move(anotherBucket, function(err, destinationFile, apiResponse) {
   *   // `my-bucket` no longer contains:
   *   // - "my-image.png"
   *   //
   *   // `another-bucket` now contains:
   *   // - "my-image.png"
   *
   *   // `destinationFile` is an instance of a File object that refers to your
   *   // new file.
   * });
   *
   * //-
   * // If you pass in a File object, you have complete control over the new
   * // bucket and filename.
   * //-
   * const anotherFile = anotherBucket.file('my-awesome-image.png');
   *
   * file.move(anotherFile, function(err, destinationFile, apiResponse) {
   *   // `my-bucket` no longer contains:
   *   // - "my-image.png"
   *   //
   *   // `another-bucket` now contains:
   *   // - "my-awesome-image.png"
   *
   *   // Note:
   *   // The `destinationFile` parameter is equal to `anotherFile`.
   * });
   *
   * //-
   * // If the callback is omitted, we'll return a Promise.
   * //-
   * file.move('my-image-new.png').then(function(data) {
   *   const destinationFile = data[0];
   *   const apiResponse = data[1];
   * });
   *
   * ```
   * @example <caption>include:samples/files.js</caption>
   * region_tag:storage_move_file
   * Another example:
   */
  move(e, t, i) {
    let n = typeof t == "object" ? t : {};
    i = typeof t == "function" ? t : i, i = i || b.noop, this.copy(e, n, (s, c, a) => {
      if (s) {
        s.message = "file#copy failed with an error - " + s.message, i(s, null, a);
        return;
      }
      this.name !== c.name || this.bucket.name !== c.bucket.name ? this.delete(n, (o, l) => {
        if (o) {
          o.message = "file#delete failed with an error - " + o.message, i(o, c, l);
          return;
        }
        i(null, c, a);
      }) : i(null, c, a);
    });
  }
  /**
   * @typedef {array} RenameResponse
   * @property {File} 0 The destination File.
   * @property {object} 1 The full API response.
   */
  /**
   * @callback RenameCallback
   * @param {?Error} err Request error, if any.
   * @param {?File} destinationFile The destination File.
   * @param {object} apiResponse The full API response.
   */
  /**
   * @typedef {object} RenameOptions Configuration options for File#move(). See an
   *     {@link https://cloud.google.com/storage/docs/json_api/v1/objects#resource| Object resource}.
   * @param {string} [userProject] The ID of the project which will be
   *     billed for the request.
   */
  /**
   * Rename this file.
   *
   * **Warning**:
   * There is currently no atomic `rename` method in the Cloud Storage API,
   * so this method is an alias of {@link File#move}, which in turn is a
   * composition of {@link File#copy} (to the new location) and
   * {@link File#delete} (from the old location). While
   * unlikely, it is possible that an error returned to your callback could be
   * triggered from either one of these API calls failing, which could leave a
   * duplicate file lingering. The error message will indicate what operation
   * has failed.
   *
   * @param {string|File} destinationFile Destination file.
   * @param {RenameCallback} [callback] Callback function.
   * @returns {Promise<RenameResponse>}
   *
   * @example
   * ```
   * const {Storage} = require('@google-cloud/storage');
   * const storage = new Storage();
   *
   * //-
   * // You can pass in a string or a File object.
   * //
   * // For all of the below examples, assume we are working with the following
   * // Bucket and File objects.
   * //-
   *
   * const bucket = storage.bucket('my-bucket');
   * const file = bucket.file('my-image.png');
   *
   * //-
   * // You can pass in a string for the destinationFile.
   * //-
   * file.rename('renamed-image.png', function(err, renamedFile, apiResponse) {
   *   // `my-bucket` no longer contains:
   *   // - "my-image.png"
   *   // but contains instead:
   *   // - "renamed-image.png"
   *
   *   // `renamedFile` is an instance of a File object that refers to your
   *   // renamed file.
   * });
   *
   * //-
   * // You can pass in a File object.
   * //-
   * const anotherFile = anotherBucket.file('my-awesome-image.png');
   *
   * file.rename(anotherFile, function(err, renamedFile, apiResponse) {
   *   // `my-bucket` no longer contains:
   *   // - "my-image.png"
   *
   *   // Note:
   *   // The `renamedFile` parameter is equal to `anotherFile`.
   * });
   *
   * //-
   * // If the callback is omitted, we'll return a Promise.
   * //-
   * file.rename('my-renamed-image.png').then(function(data) {
   *   const renamedFile = data[0];
   *   const apiResponse = data[1];
   * });
   * ```
   */
  rename(e, t, i) {
    let n = typeof t == "object" ? t : {};
    i = typeof t == "function" ? t : i, i = i || b.noop, this.move(e, n, i);
  }
  /**
   * @typedef {object} RestoreOptions Options for File#restore(). See an
   *     {@link https://cloud.google.com/storage/docs/json_api/v1/objects#resource| Object resource}.
   * @param {string} [userProject] The ID of the project which will be
   *     billed for the request.
   * @param {number} [generation] If present, selects a specific revision of this object.
   * @param {string} [restoreToken] Returns an option that must be specified when getting a soft-deleted object from an HNS-enabled
   *  bucket that has a naming and generation conflict with another object in the same bucket.
   * @param {string} [projection] Specifies the set of properties to return. If used, must be 'full' or 'noAcl'.
   * @param {string | number} [ifGenerationMatch] Request proceeds if the generation of the target resource
   *  matches the value used in the precondition.
   *  If the values don't match, the request fails with a 412 Precondition Failed response.
   * @param {string | number} [ifGenerationNotMatch] Request proceeds if the generation of the target resource does
   *  not match the value used in the precondition. If the values match, the request fails with a 304 Not Modified response.
   * @param {string | number} [ifMetagenerationMatch] Request proceeds if the meta-generation of the target resource
   *  matches the value used in the precondition.
   *  If the values don't match, the request fails with a 412 Precondition Failed response.
   * @param {string | number} [ifMetagenerationNotMatch]  Request proceeds if the meta-generation of the target resource does
   *  not match the value used in the precondition. If the values match, the request fails with a 304 Not Modified response.
   */
  /**
   * Restores a soft-deleted file
   * @param {RestoreOptions} options Restore options.
   * @returns {Promise<File>}
   */
  async restore(e) {
    let [t] = await this.request({
      method: "POST",
      uri: "/restore",
      qs: e
    });
    return t;
  }
  /**
   * Makes request and applies userProject query parameter if necessary.
   *
   * @private
   *
   * @param {object} reqOpts - The request options.
   * @param {function} callback - The callback function.
   */
  request(e, t) {
    return this.parent.request.call(this, e, t);
  }
  /**
   * @callback RotateEncryptionKeyCallback
   * @extends CopyCallback
   */
  /**
   * @typedef RotateEncryptionKeyResponse
   * @extends CopyResponse
   */
  /**
   * @param {string|buffer|object} RotateEncryptionKeyOptions Configuration options
   *     for File#rotateEncryptionKey().
   * If a string or Buffer is provided, it is interpreted as an AES-256,
   * customer-supplied encryption key. If you'd like to use a Cloud KMS key
   * name, you must specify an options object with the property name:
   * `kmsKeyName`.
   * @param {string|buffer} [options.encryptionKey] An AES-256 encryption key.
   * @param {string} [options.kmsKeyName] A Cloud KMS key name.
   */
  /**
   * This method allows you to update the encryption key associated with this
   * file.
   *
   * See {@link https://cloud.google.com/storage/docs/encryption#customer-supplied| Customer-supplied Encryption Keys}
   *
   * @param {RotateEncryptionKeyOptions} [options] - Configuration options.
   * @param {RotateEncryptionKeyCallback} [callback]
   * @returns {Promise<File>}
   *
   * @example <caption>include:samples/encryption.js</caption>
   * region_tag:storage_rotate_encryption_key
   * Example of rotating the encryption key for this file:
   */
  rotateEncryptionKey(e, t) {
    var i;
    t = typeof e == "function" ? e : t;
    let n = {};
    typeof e == "string" || e instanceof Buffer ? n = {
      encryptionKey: e
    } : typeof e == "object" && (n = e);
    let s = this.bucket.file(this.id, n), c = ((i = n.preconditionOpts) === null || i === void 0 ? void 0 : i.ifGenerationMatch) !== void 0 ? { preconditionOpts: n.preconditionOpts } : {};
    this.copy(s, c, t);
  }
  /**
   * @typedef {object} SaveOptions
   * @extends CreateWriteStreamOptions
   */
  /**
   * @callback SaveCallback
   * @param {?Error} err Request error, if any.
   */
  /**
   * Write strings or buffers to a file.
   *
   * *This is a convenience method which wraps {@link File#createWriteStream}.*
   * To upload arbitrary data to a file, please use {@link File#createWriteStream} directly.
   *
   * Resumable uploads are automatically enabled and must be shut off explicitly
   * by setting `options.resumable` to `false`.
   *
   * Multipart uploads with retryable error codes will be retried 3 times with exponential backoff.
   *
   * <p class="notice">
   *   There is some overhead when using a resumable upload that can cause
   *   noticeable performance degradation while uploading a series of small
   * files. When uploading files less than 10MB, it is recommended that the
   * resumable feature is disabled.
   * </p>
   *
   * @param {SaveData} data The data to write to a file.
   * @param {SaveOptions} [options] See {@link File#createWriteStream}'s `options`
   *     parameter.
   * @param {SaveCallback} [callback] Callback function.
   * @returns {Promise}
   *
   * @example
   * ```
   * const {Storage} = require('@google-cloud/storage');
   * const storage = new Storage();
   * const myBucket = storage.bucket('my-bucket');
   *
   * const file = myBucket.file('my-file');
   * const contents = 'This is the contents of the file.';
   *
   * file.save(contents, function(err) {
   *   if (!err) {
   *     // File written successfully.
   *   }
   * });
   *
   * //-
   * // If the callback is omitted, we'll return a Promise.
   * //-
   * file.save(contents).then(function() {});
   * ```
   */
  save(e, t, i) {
    i = typeof t == "function" ? t : i;
    let n = typeof t == "object" ? t : {}, s = this.storage.retryOptions.maxRetries;
    this.shouldRetryBasedOnPreconditionAndIdempotencyStrat(n?.preconditionOpts) || (s = 0);
    let c = (0, ir.default)(async (a) => new Promise((o, l) => {
      s === 0 && (this.storage.retryOptions.autoRetry = !1);
      let p = this.createWriteStream(n);
      n.onUploadProgress && p.on("progress", n.onUploadProgress);
      let u = /* @__PURE__ */ d((f) => this.storage.retryOptions.autoRetry && this.storage.retryOptions.retryableErrorFn(f) ? l(f) : a(f), "handleError");
      typeof e == "string" || Buffer.isBuffer(e) || e instanceof Uint8Array ? p.on("error", u).on("finish", () => o()).end(e) : Ut(e, p, (f) => {
        if (f) {
          if (typeof e != "function")
            return a(f);
          u(f);
        } else
          o();
      });
    }), {
      retries: s,
      factor: this.storage.retryOptions.retryDelayMultiplier,
      maxTimeout: this.storage.retryOptions.maxRetryDelay * 1e3,
      //convert to milliseconds
      maxRetryTime: this.storage.retryOptions.totalTimeout * 1e3
      //convert to milliseconds
    });
    return i ? c.then(() => {
      if (i)
        return i();
    }).catch(i) : c;
  }
  setMetadata(e, t, i) {
    let n = typeof t == "object" ? t : {};
    i = typeof t == "function" ? t : i, this.disableAutoRetryConditionallyIdempotent_(this.methods.setMetadata, G.setMetadata, n), super.setMetadata(e, n).then((s) => i(null, ...s)).catch(i).finally(() => {
      this.storage.retryOptions.autoRetry = this.instanceRetryValue;
    });
  }
  /**
   * @typedef {array} SetStorageClassResponse
   * @property {object} 0 The full API response.
   */
  /**
   * @typedef {object} SetStorageClassOptions Configuration options for File#setStorageClass().
   * @property {string} [userProject] The ID of the project which will be
   *     billed for the request.
   */
  /**
   * @callback SetStorageClassCallback
   * @param {?Error} err Request error, if any.
   * @param {object} apiResponse The full API response.
   */
  /**
   * Set the storage class for this file.
   *
   * See {@link https://cloud.google.com/storage/docs/per-object-storage-class| Per-Object Storage Class}
   * See {@link https://cloud.google.com/storage/docs/storage-classes| Storage Classes}
   *
   * @param {string} storageClass The new storage class. (`standard`,
   *     `nearline`, `coldline`, or `archive`)
   *     **Note:** The storage classes `multi_regional` and `regional`
   *     are now legacy and will be deprecated in the future.
   * @param {SetStorageClassOptions} [options] Configuration options.
   * @param {string} [options.userProject] The ID of the project which will be
   *     billed for the request.
   * @param {SetStorageClassCallback} [callback] Callback function.
   * @returns {Promise<SetStorageClassResponse>}
   *
   * @example
   * ```
   * file.setStorageClass('nearline', function(err, apiResponse) {
   *   if (err) {
   *     // Error handling omitted.
   *   }
   *
   *   // The storage class was updated successfully.
   * });
   *
   * //-
   * // If the callback is omitted, we'll return a Promise.
   * //-
   * file.setStorageClass('nearline').then(function() {});
   * ```
   */
  setStorageClass(e, t, i) {
    i = typeof t == "function" ? t : i;
    let s = {
      ...typeof t == "object" ? t : {},
      // In case we get input like `storageClass`, convert to `storage_class`.
      storageClass: e.replace(/-/g, "_").replace(/([a-z])([A-Z])/g, (c, a, o) => a + "_" + o).toUpperCase()
    };
    this.copy(this, s, (c, a, o) => {
      if (c) {
        i(c, o);
        return;
      }
      this.metadata = a.metadata, i(null, o);
    });
  }
  /**
   * Set a user project to be billed for all requests made from this File
   * object.
   *
   * @param {string} userProject The user project.
   *
   * @example
   * ```
   * const {Storage} = require('@google-cloud/storage');
   * const storage = new Storage();
   * const bucket = storage.bucket('albums');
   * const file = bucket.file('my-file');
   *
   * file.setUserProject('grape-spaceship-123');
   * ```
   */
  setUserProject(e) {
    this.bucket.setUserProject.call(this, e);
  }
  /**
   * This creates a resumable-upload upload stream.
   *
   * @param {Duplexify} stream - Duplexify stream of data to pipe to the file.
   * @param {object=} options - Configuration object.
   *
   * @private
   */
  startResumableUpload_(e, t = {}) {
    var i;
    (i = t.metadata) !== null && i !== void 0 || (t.metadata = {});
    let n = this.storage.retryOptions;
    this.shouldRetryBasedOnPreconditionAndIdempotencyStrat(t.preconditionOpts) || (n.autoRetry = !1);
    let s = {
      authClient: this.storage.authClient,
      apiEndpoint: this.storage.apiEndpoint,
      bucket: this.bucket.name,
      customRequestOptions: this.getRequestInterceptors().reduce((a, o) => o(a), {}),
      file: this.name,
      generation: this.generation,
      isPartialUpload: t.isPartialUpload,
      key: this.encryptionKey,
      kmsKeyName: this.kmsKeyName,
      metadata: t.metadata,
      offset: t.offset,
      predefinedAcl: t.predefinedAcl,
      private: t.private,
      public: t.public,
      uri: t.uri,
      userProject: t.userProject || this.userProject,
      retryOptions: { ...n },
      params: t?.preconditionOpts || this.instancePreconditionOpts,
      chunkSize: t?.chunkSize,
      highWaterMark: t?.highWaterMark,
      universeDomain: this.bucket.storage.universeDomain,
      [T]: t[T]
    }, c;
    try {
      c = zi(s);
    } catch (a) {
      e.destroy(a), this.storage.retryOptions.autoRetry = this.instanceRetryValue;
      return;
    }
    c.on("response", (a) => {
      e.emit("response", a);
    }).on("uri", (a) => {
      e.emit("uri", a);
    }).on("metadata", (a) => {
      this.metadata = a, e.emit("metadata");
    }).on("finish", () => {
      e.emit("complete");
    }).on("progress", (a) => e.emit("progress", a)), e.setWritable(c), this.storage.retryOptions.autoRetry = this.instanceRetryValue;
  }
  /**
   * Takes a readable stream and pipes it to a remote file. Unlike
   * `startResumableUpload_`, which uses the resumable upload technique, this
   * method uses a simple upload (all or nothing).
   *
   * @param {Duplexify} dup - Duplexify stream of data to pipe to the file.
   * @param {object=} options - Configuration object.
   *
   * @private
   */
  startSimpleUpload_(e, t = {}) {
    var i;
    (i = t.metadata) !== null && i !== void 0 || (t.metadata = {});
    let n = this.storage.apiEndpoint, s = this.bucket.name, c = `${n}/upload/storage/v1/b/${s}/o`, a = {
      qs: {
        name: this.name
      },
      uri: c,
      [T]: t[T]
    };
    this.generation !== void 0 && (a.qs.ifGenerationMatch = this.generation), this.kmsKeyName !== void 0 && (a.qs.kmsKeyName = this.kmsKeyName), typeof t.timeout == "number" && (a.timeout = t.timeout), (t.userProject || this.userProject) && (a.qs.userProject = t.userProject || this.userProject), t.predefinedAcl ? a.qs.predefinedAcl = t.predefinedAcl : t.private ? a.qs.predefinedAcl = "private" : t.public && (a.qs.predefinedAcl = "publicRead"), Object.assign(a.qs, this.instancePreconditionOpts, t.preconditionOpts), b.makeWritableStream(e, {
      makeAuthenticatedRequest: /* @__PURE__ */ d((o) => {
        this.request(o, (l, p, u) => {
          if (l) {
            e.destroy(l);
            return;
          }
          this.metadata = p, e.emit("metadata", p), e.emit("response", u), e.emit("complete");
        });
      }, "makeAuthenticatedRequest"),
      metadata: t.metadata,
      request: a
    });
  }
  disableAutoRetryConditionallyIdempotent_(e, t, i) {
    var n, s, c, a;
    (typeof e == "object" && ((s = (n = e?.reqOpts) === null || n === void 0 ? void 0 : n.qs) === null || s === void 0 ? void 0 : s.ifGenerationMatch) === void 0 && i?.ifGenerationMatch === void 0 && t === G.delete && this.storage.retryOptions.idempotencyStrategy === _.RetryConditional || this.storage.retryOptions.idempotencyStrategy === _.RetryNever) && (this.storage.retryOptions.autoRetry = !1), (typeof e == "object" && ((a = (c = e?.reqOpts) === null || c === void 0 ? void 0 : c.qs) === null || a === void 0 ? void 0 : a.ifMetagenerationMatch) === void 0 && i?.ifMetagenerationMatch === void 0 && t === G.setMetadata && this.storage.retryOptions.idempotencyStrategy === _.RetryConditional || this.storage.retryOptions.idempotencyStrategy === _.RetryNever) && (this.storage.retryOptions.autoRetry = !1);
  }
  async getBufferFromReadable(e) {
    let t = [];
    for await (let i of e)
      t.push(i);
    return Buffer.concat(t);
  }
};
Mt = /* @__PURE__ */ new WeakSet(), Ji = /**
 *
 * @param hashCalculatingStream
 * @param verify
 * @returns {boolean} Returns `true` if valid, throws with error otherwise
 */
/* @__PURE__ */ d(async function(e, t = {}) {
  let i = this.metadata, n = !!(t.crc32c || t.md5);
  if (t.crc32c && i.crc32c && (n = !e.test("crc32c", i.crc32c)), t.md5 && i.md5Hash && (n = !e.test("md5", i.md5Hash)), n) {
    let s = [], c = "", a = "";
    try {
      await this.delete(), t.md5 && !i.md5Hash ? (c = "MD5_NOT_AVAILABLE", a = I.MD5_NOT_AVAILABLE) : (c = "FILE_NO_UPLOAD", a = I.UPLOAD_MISMATCH);
    } catch (l) {
      let p = l;
      c = "FILE_NO_UPLOAD_DELETE", a = `${I.UPLOAD_MISMATCH_DELETE_FAIL}${p.message}`, s.push(p);
    }
    let o = new oe(a);
    throw o.code = c, o.errors = s, o;
  }
  return !0;
}, "_File_validateIntegrity");
(0, Qi.promisifyAll)(H, {
  exclude: [
    "cloudStorageURI",
    "publicUrl",
    "request",
    "save",
    "setEncryptionKey",
    "shouldRetryBasedOnPreconditionAndIdempotencyStrat",
    "getBufferFromReadable",
    "restore"
  ]
});

// node_modules/@google-cloud/storage/build/esm/src/iam.js
var rr = v(W(), 1);
var ct;
(function(r) {
  r.POLICY_OBJECT_REQUIRED = "A policy object is required.", r.PERMISSIONS_REQUIRED = "Permissions are required.";
})(ct || (ct = {}));
var Ne = class {
  static {
    d(this, "Iam");
  }
  constructor(e) {
    this.request_ = e.request.bind(e), this.resourceId_ = "buckets/" + e.getId();
  }
  /**
   * @typedef {object} GetPolicyOptions Requested options for IAM#getPolicy().
   * @property {number} [requestedPolicyVersion] The version of IAM policies to
   *     request. If a policy with a condition is requested without setting
   *     this, the server will return an error. This must be set to a value
   *     of 3 to retrieve IAM policies containing conditions. This is to
   *     prevent client code that isn't aware of IAM conditions from
   *     interpreting and modifying policies incorrectly. The service might
   *     return a policy with version lower than the one that was requested,
   *     based on the feature syntax in the policy fetched.
   *     See {@link https://cloud.google.com/iam/docs/policies#versions| IAM Policy versions}
   * @property {string} [userProject] The ID of the project which will be
   *     billed for the request.
   */
  /**
   * @typedef {array} GetPolicyResponse
   * @property {Policy} 0 The policy.
   * @property {object} 1 The full API response.
   */
  /**
   * @typedef {object} Policy
   * @property {PolicyBinding[]} policy.bindings Bindings associate members with roles.
   * @property {string} [policy.etag] Etags are used to perform a read-modify-write.
   * @property {number} [policy.version] The syntax schema version of the Policy.
   *      To set an IAM policy with conditional binding, this field must be set to
   *      3 or greater.
   *     See {@link https://cloud.google.com/iam/docs/policies#versions| IAM Policy versions}
   */
  /**
   * @typedef {object} PolicyBinding
   * @property {string} role Role that is assigned to members.
   * @property {string[]} members Specifies the identities requesting access for the bucket.
   * @property {Expr} [condition] The condition that is associated with this binding.
   */
  /**
   * @typedef {object} Expr
   * @property {string} [title] An optional title for the expression, i.e. a
   *     short string describing its purpose. This can be used e.g. in UIs
   *     which allow to enter the expression.
   * @property {string} [description] An optional description of the
   *     expression. This is a longer text which describes the expression,
   *     e.g. when hovered over it in a UI.
   * @property {string} expression Textual representation of an expression in
   *     Common Expression Language syntax. The application context of the
   *     containing message determines which well-known feature set of CEL
   *     is supported.The condition that is associated with this binding.
   *
   * @see [Condition] https://cloud.google.com/storage/docs/access-control/iam#conditions
   */
  /**
   * Get the IAM policy.
   *
   * @param {GetPolicyOptions} [options] Request options.
   * @param {GetPolicyCallback} [callback] Callback function.
   * @returns {Promise<GetPolicyResponse>}
   *
   * See {@link https://cloud.google.com/storage/docs/json_api/v1/buckets/getIamPolicy| Buckets: setIamPolicy API Documentation}
   *
   * @example
   * ```
   * const {Storage} = require('@google-cloud/storage');
   * const storage = new Storage();
   * const bucket = storage.bucket('my-bucket');
   *
   * bucket.iam.getPolicy(
   *     {requestedPolicyVersion: 3},
   *     function(err, policy, apiResponse) {
   *
   *     },
   * );
   *
   * //-
   * // If the callback is omitted, we'll return a Promise.
   * //-
   * bucket.iam.getPolicy({requestedPolicyVersion: 3})
   *   .then(function(data) {
   *     const policy = data[0];
   *     const apiResponse = data[1];
   *   });
   *
   * ```
   * @example <caption>include:samples/iam.js</caption>
   * region_tag:storage_view_bucket_iam_members
   * Example of retrieving a bucket's IAM policy:
   */
  getPolicy(e, t) {
    let { options: i, callback: n } = U(e, t), s = {};
    i.userProject && (s.userProject = i.userProject), i.requestedPolicyVersion !== null && i.requestedPolicyVersion !== void 0 && (s.optionsRequestedPolicyVersion = i.requestedPolicyVersion), this.request_({
      uri: "/iam",
      qs: s
    }, n);
  }
  /**
   * Set the IAM policy.
   *
   * @throws {Error} If no policy is provided.
   *
   * @param {Policy} policy The policy.
   * @param {SetPolicyOptions} [options] Configuration options.
   * @param {SetPolicyCallback} callback Callback function.
   * @returns {Promise<SetPolicyResponse>}
   *
   * See {@link https://cloud.google.com/storage/docs/json_api/v1/buckets/setIamPolicy| Buckets: setIamPolicy API Documentation}
   * See {@link https://cloud.google.com/iam/docs/understanding-roles| IAM Roles}
   *
   * @example
   * ```
   * const {Storage} = require('@google-cloud/storage');
   * const storage = new Storage();
   * const bucket = storage.bucket('my-bucket');
   *
   * const myPolicy = {
   *   bindings: [
   *     {
   *       role: 'roles/storage.admin',
   *       members:
   * ['serviceAccount:myotherproject@appspot.gserviceaccount.com']
   *     }
   *   ]
   * };
   *
   * bucket.iam.setPolicy(myPolicy, function(err, policy, apiResponse) {});
   *
   * //-
   * // If the callback is omitted, we'll return a Promise.
   * //-
   * bucket.iam.setPolicy(myPolicy).then(function(data) {
   *   const policy = data[0];
   *   const apiResponse = data[1];
   * });
   *
   * ```
   * @example <caption>include:samples/iam.js</caption>
   * region_tag:storage_add_bucket_iam_member
   * Example of adding to a bucket's IAM policy:
   *
   * @example <caption>include:samples/iam.js</caption>
   * region_tag:storage_remove_bucket_iam_member
   * Example of removing from a bucket's IAM policy:
   */
  setPolicy(e, t, i) {
    if (e === null || typeof e != "object")
      throw new Error(ct.POLICY_OBJECT_REQUIRED);
    let { options: n, callback: s } = U(t, i), c;
    e.etag === void 0 && (c = 0), this.request_({
      method: "PUT",
      uri: "/iam",
      maxRetries: c,
      json: Object.assign({
        resourceId: this.resourceId_
      }, e),
      qs: n
    }, s);
  }
  /**
   * Test a set of permissions for a resource.
   *
   * @throws {Error} If permissions are not provided.
   *
   * @param {string|string[]} permissions The permission(s) to test for.
   * @param {TestIamPermissionsOptions} [options] Configuration object.
   * @param {TestIamPermissionsCallback} [callback] Callback function.
   * @returns {Promise<TestIamPermissionsResponse>}
   *
   * See {@link https://cloud.google.com/storage/docs/json_api/v1/buckets/testIamPermissions| Buckets: testIamPermissions API Documentation}
   *
   * @example
   * ```
   * const {Storage} = require('@google-cloud/storage');
   * const storage = new Storage();
   * const bucket = storage.bucket('my-bucket');
   *
   * //-
   * // Test a single permission.
   * //-
   * const test = 'storage.buckets.delete';
   *
   * bucket.iam.testPermissions(test, function(err, permissions, apiResponse) {
   *   console.log(permissions);
   *   // {
   *   //   "storage.buckets.delete": true
   *   // }
   * });
   *
   * //-
   * // Test several permissions at once.
   * //-
   * const tests = [
   *   'storage.buckets.delete',
   *   'storage.buckets.get'
   * ];
   *
   * bucket.iam.testPermissions(tests, function(err, permissions) {
   *   console.log(permissions);
   *   // {
   *   //   "storage.buckets.delete": false,
   *   //   "storage.buckets.get": true
   *   // }
   * });
   *
   * //-
   * // If the callback is omitted, we'll return a Promise.
   * //-
   * bucket.iam.testPermissions(test).then(function(data) {
   *   const permissions = data[0];
   *   const apiResponse = data[1];
   * });
   * ```
   */
  testPermissions(e, t, i) {
    if (!Array.isArray(e) && typeof e != "string")
      throw new Error(ct.PERMISSIONS_REQUIRED);
    let { options: n, callback: s } = U(t, i), c = Array.isArray(e) ? e : [e], a = Object.assign({
      permissions: c
    }, n);
    this.request_({
      uri: "/iam/testPermissions",
      qs: a,
      useQuerystring: !0
    }, (o, l) => {
      if (o) {
        s(o, null, l);
        return;
      }
      let p = Array.isArray(l.permissions) ? l.permissions : [], u = c.reduce((f, m) => (f[m] = p.indexOf(m) > -1, f), {});
      s(null, u, l);
    });
  }
};
(0, rr.promisifyAll)(Ne);

// node_modules/@google-cloud/storage/build/esm/src/notification.js
var nr = v(W(), 1);
var Ie = class extends O {
  static {
    d(this, "Notification");
  }
  constructor(e, t) {
    let i = {}, n = {
      /**
       * Creates a notification subscription for the bucket.
       *
       * See {@link https://cloud.google.com/storage/docs/json_api/v1/notifications/insert| Notifications: insert}
       * @method Notification#create
       *
       * @param {Topic|string} topic The Cloud PubSub topic to which this
       * subscription publishes. If the project ID is omitted, the current
       * project ID will be used.
       *
       * Acceptable formats are:
       * - `projects/grape-spaceship-123/topics/my-topic`
       *
       * - `my-topic`
       * @param {CreateNotificationRequest} [options] Metadata to set for
       *     the notification.
       * @param {CreateNotificationCallback} [callback] Callback function.
       * @returns {Promise<CreateNotificationResponse>}
       * @throws {Error} If a valid topic is not provided.
       *
       * @example
       * ```
       * const {Storage} = require('@google-cloud/storage');
       * const storage = new Storage();
       * const myBucket = storage.bucket('my-bucket');
       * const notification = myBucket.notification('1');
       *
       * notification.create(function(err, notification, apiResponse) {
       *   if (!err) {
       *     // The notification was created successfully.
       *   }
       * });
       *
       * //-
       * // If the callback is omitted, we'll return a Promise.
       * //-
       * notification.create().then(function(data) {
       *   const notification = data[0];
       *   const apiResponse = data[1];
       * });
       * ```
       */
      create: !0,
      /**
       * @typedef {array} DeleteNotificationResponse
       * @property {object} 0 The full API response.
       */
      /**
       * Permanently deletes a notification subscription.
       *
       * See {@link https://cloud.google.com/storage/docs/json_api/v1/notifications/delete| Notifications: delete API Documentation}
       *
       * @param {object} [options] Configuration options.
       * @param {string} [options.userProject] The ID of the project which will be
       *     billed for the request.
       * @param {DeleteNotificationCallback} [callback] Callback function.
       * @returns {Promise<DeleteNotificationResponse>}
       *
       * @example
       * ```
       * const {Storage} = require('@google-cloud/storage');
       * const storage = new Storage();
       * const myBucket = storage.bucket('my-bucket');
       * const notification = myBucket.notification('1');
       *
       * notification.delete(function(err, apiResponse) {});
       *
       * //-
       * // If the callback is omitted, we'll return a Promise.
       * //-
       * notification.delete().then(function(data) {
       *   const apiResponse = data[0];
       * });
       *
       * ```
       * @example <caption>include:samples/deleteNotification.js</caption>
       * region_tag:storage_delete_bucket_notification
       * Another example:
       */
      delete: {
        reqOpts: {
          qs: i
        }
      },
      /**
       * Get a notification and its metadata if it exists.
       *
       * See {@link https://cloud.google.com/storage/docs/json_api/v1/notifications/get| Notifications: get API Documentation}
       *
       * @param {object} [options] Configuration options.
       *     See {@link Bucket#createNotification} for create options.
       * @param {boolean} [options.autoCreate] Automatically create the object if
       *     it does not exist. Default: `false`.
       * @param {string} [options.userProject] The ID of the project which will be
       *     billed for the request.
       * @param {GetNotificationCallback} [callback] Callback function.
       * @return {Promise<GetNotificationCallback>}
       *
       * @example
       * ```
       * const {Storage} = require('@google-cloud/storage');
       * const storage = new Storage();
       * const myBucket = storage.bucket('my-bucket');
       * const notification = myBucket.notification('1');
       *
       * notification.get(function(err, notification, apiResponse) {
       *   // `notification.metadata` has been populated.
       * });
       *
       * //-
       * // If the callback is omitted, we'll return a Promise.
       * //-
       * notification.get().then(function(data) {
       *   const notification = data[0];
       *   const apiResponse = data[1];
       * });
       * ```
       */
      get: {
        reqOpts: {
          qs: i
        }
      },
      /**
       * Get the notification's metadata.
       *
       * See {@link https://cloud.google.com/storage/docs/json_api/v1/notifications/get| Notifications: get API Documentation}
       *
       * @param {object} [options] Configuration options.
       * @param {string} [options.userProject] The ID of the project which will be
       *     billed for the request.
       * @param {GetNotificationMetadataCallback} [callback] Callback function.
       * @returns {Promise<GetNotificationMetadataResponse>}
       *
       * @example
       * ```
       * const {Storage} = require('@google-cloud/storage');
       * const storage = new Storage();
       * const myBucket = storage.bucket('my-bucket');
       * const notification = myBucket.notification('1');
       *
       * notification.getMetadata(function(err, metadata, apiResponse) {});
       *
       * //-
       * // If the callback is omitted, we'll return a Promise.
       * //-
       * notification.getMetadata().then(function(data) {
       *   const metadata = data[0];
       *   const apiResponse = data[1];
       * });
       *
       * ```
       * @example <caption>include:samples/getMetadataNotifications.js</caption>
       * region_tag:storage_print_pubsub_bucket_notification
       * Another example:
       */
      getMetadata: {
        reqOpts: {
          qs: i
        }
      },
      /**
       * @typedef {array} NotificationExistsResponse
       * @property {boolean} 0 Whether the notification exists or not.
       */
      /**
       * @callback NotificationExistsCallback
       * @param {?Error} err Request error, if any.
       * @param {boolean} exists Whether the notification exists or not.
       */
      /**
       * Check if the notification exists.
       *
       * @method Notification#exists
       * @param {NotificationExistsCallback} [callback] Callback function.
       * @returns {Promise<NotificationExistsResponse>}
       *
       * @example
       * ```
       * const {Storage} = require('@google-cloud/storage');
       * const storage = new Storage();
       * const myBucket = storage.bucket('my-bucket');
       * const notification = myBucket.notification('1');
       *
       * notification.exists(function(err, exists) {});
       *
       * //-
       * // If the callback is omitted, we'll return a Promise.
       * //-
       * notification.exists().then(function(data) {
       *   const exists = data[0];
       * });
       * ```
       */
      exists: !0
    };
    super({
      parent: e,
      baseUrl: "/notificationConfigs",
      id: t.toString(),
      createMethod: e.createNotification.bind(e),
      methods: n
    });
  }
};
(0, nr.promisifyAll)(Ie);

// node_modules/@google-cloud/storage/build/esm/src/bucket.js
import { Readable as ns } from "stream";
import { URL as ss } from "url";
var Bt;
(function(r) {
  r.list = "GET";
})(Bt || (Bt = {}));
var G;
(function(r) {
  r[r.setMetadata = 0] = "setMetadata", r[r.delete = 1] = "delete";
})(G || (G = {}));
var K;
(function(r) {
  r.PROVIDE_SOURCE_FILE = "You must provide at least one source file.", r.DESTINATION_FILE_NOT_SPECIFIED = "A destination file must be specified.", r.CHANNEL_ID_REQUIRED = "An ID is required to create a channel.", r.TOPIC_NAME_REQUIRED = "A valid topic name is required.", r.CONFIGURATION_OBJECT_PREFIX_REQUIRED = "A configuration object with a prefix is required.", r.SPECIFY_FILE_NAME = "A file name must be specified.", r.METAGENERATION_NOT_PROVIDED = "A metageneration must be provided.", r.SUPPLY_NOTIFICATION_ID = "You must supply a notification ID.";
})(K || (K = {}));
var F = class r extends O {
  static {
    d(this, "Bucket");
  }
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  getFilesStream(e) {
    return new ns();
  }
  constructor(e, t, i) {
    var n, s, c, a;
    i = i || {}, t = t.replace(/^gs:\/\//, "").replace(/\/+$/, "");
    let o = {};
    !((n = i?.preconditionOpts) === null || n === void 0) && n.ifGenerationMatch && (o.ifGenerationMatch = i.preconditionOpts.ifGenerationMatch), !((s = i?.preconditionOpts) === null || s === void 0) && s.ifGenerationNotMatch && (o.ifGenerationNotMatch = i.preconditionOpts.ifGenerationNotMatch), !((c = i?.preconditionOpts) === null || c === void 0) && c.ifMetagenerationMatch && (o.ifMetagenerationMatch = i.preconditionOpts.ifMetagenerationMatch), !((a = i?.preconditionOpts) === null || a === void 0) && a.ifMetagenerationNotMatch && (o.ifMetagenerationNotMatch = i.preconditionOpts.ifMetagenerationNotMatch);
    let l = i.userProject;
    typeof l == "string" && (o.userProject = l);
    let p = {
      /**
       * Create a bucket.
       *
       * @method Bucket#create
       * @param {CreateBucketRequest} [metadata] Metadata to set for the bucket.
       * @param {CreateBucketCallback} [callback] Callback function.
       * @returns {Promise<CreateBucketResponse>}
       *
       * @example
       * ```
       * const {Storage} = require('@google-cloud/storage');
       * const storage = new Storage();
       * const bucket = storage.bucket('albums');
       * bucket.create(function(err, bucket, apiResponse) {
       *   if (!err) {
       *     // The bucket was created successfully.
       *   }
       * });
       *
       * //-
       * // If the callback is omitted, we'll return a Promise.
       * //-
       * bucket.create().then(function(data) {
       *   const bucket = data[0];
       *   const apiResponse = data[1];
       * });
       * ```
       */
      create: {
        reqOpts: {
          qs: o
        }
      },
      /**
       * IamDeleteBucketOptions Configuration options.
       * @property {boolean} [ignoreNotFound = false] Ignore an error if
       *     the bucket does not exist.
       * @property {string} [userProject] The ID of the project which will be
       *     billed for the request.
       */
      /**
       * @typedef {array} DeleteBucketResponse
       * @property {object} 0 The full API response.
       */
      /**
       * @callback DeleteBucketCallback
       * @param {?Error} err Request error, if any.
       * @param {object} apiResponse The full API response.
       */
      /**
       * Delete the bucket.
       *
       * See {@link https://cloud.google.com/storage/docs/json_api/v1/buckets/delete| Buckets: delete API Documentation}
       *
       * @method Bucket#delete
       * @param {DeleteBucketOptions} [options] Configuration options.
       * @param {boolean} [options.ignoreNotFound = false] Ignore an error if
       *     the bucket does not exist.
       * @param {string} [options.userProject] The ID of the project which will be
       *     billed for the request.
       * @param {DeleteBucketCallback} [callback] Callback function.
       * @returns {Promise<DeleteBucketResponse>}
       *
       * @example
       * ```
       * const {Storage} = require('@google-cloud/storage');
       * const storage = new Storage();
       * const bucket = storage.bucket('albums');
       * bucket.delete(function(err, apiResponse) {});
       *
       * //-
       * // If the callback is omitted, we'll return a Promise.
       * //-
       * bucket.delete().then(function(data) {
       *   const apiResponse = data[0];
       * });
       *
       * ```
       * @example <caption>include:samples/buckets.js</caption>
       * region_tag:storage_delete_bucket
       * Another example:
       */
      delete: {
        reqOpts: {
          qs: o
        }
      },
      /**
       * @typedef {object} BucketExistsOptions Configuration options for Bucket#exists().
       * @property {string} [userProject] The ID of the project which will be
       *     billed for the request.
       */
      /**
       * @typedef {array} BucketExistsResponse
       * @property {boolean} 0 Whether the {@link Bucket} exists.
       */
      /**
       * @callback BucketExistsCallback
       * @param {?Error} err Request error, if any.
       * @param {boolean} exists Whether the {@link Bucket} exists.
       */
      /**
       * Check if the bucket exists.
       *
       * @method Bucket#exists
       * @param {BucketExistsOptions} [options] Configuration options.
       * @param {string} [options.userProject] The ID of the project which will be
       *     billed for the request.
       * @param {BucketExistsCallback} [callback] Callback function.
       * @returns {Promise<BucketExistsResponse>}
       *
       * @example
       * ```
       * const {Storage} = require('@google-cloud/storage');
       * const storage = new Storage();
       * const bucket = storage.bucket('albums');
       *
       * bucket.exists(function(err, exists) {});
       *
       * //-
       * // If the callback is omitted, we'll return a Promise.
       * //-
       * bucket.exists().then(function(data) {
       *   const exists = data[0];
       * });
       * ```
       */
      exists: {
        reqOpts: {
          qs: o
        }
      },
      /**
       * @typedef {object} [GetBucketOptions] Configuration options for Bucket#get()
       * @property {boolean} [autoCreate] Automatically create the object if
       *     it does not exist. Default: `false`
       * @property {string} [userProject] The ID of the project which will be
       *     billed for the request.
       */
      /**
       * @typedef {array} GetBucketResponse
       * @property {Bucket} 0 The {@link Bucket}.
       * @property {object} 1 The full API response.
       */
      /**
       * @callback GetBucketCallback
       * @param {?Error} err Request error, if any.
       * @param {Bucket} bucket The {@link Bucket}.
       * @param {object} apiResponse The full API response.
       */
      /**
       * Get a bucket if it exists.
       *
       * You may optionally use this to "get or create" an object by providing
       * an object with `autoCreate` set to `true`. Any extra configuration that
       * is normally required for the `create` method must be contained within
       * this object as well.
       *
       * @method Bucket#get
       * @param {GetBucketOptions} [options] Configuration options.
       * @param {boolean} [options.autoCreate] Automatically create the object if
       *     it does not exist. Default: `false`
       * @param {string} [options.userProject] The ID of the project which will be
       *     billed for the request.
       * @param {GetBucketCallback} [callback] Callback function.
       * @returns {Promise<GetBucketResponse>}
       *
       * @example
       * ```
       * const {Storage} = require('@google-cloud/storage');
       * const storage = new Storage();
       * const bucket = storage.bucket('albums');
       *
       * bucket.get(function(err, bucket, apiResponse) {
       *   // `bucket.metadata` has been populated.
       * });
       *
       * //-
       * // If the callback is omitted, we'll return a Promise.
       * //-
       * bucket.get().then(function(data) {
       *   const bucket = data[0];
       *   const apiResponse = data[1];
       * });
       * ```
       */
      get: {
        reqOpts: {
          qs: o
        }
      },
      /**
       * @typedef {array} GetBucketMetadataResponse
       * @property {object} 0 The bucket metadata.
       * @property {object} 1 The full API response.
       */
      /**
       * @callback GetBucketMetadataCallback
       * @param {?Error} err Request error, if any.
       * @param {object} metadata The bucket metadata.
       * @param {object} apiResponse The full API response.
       */
      /**
       * @typedef {object} GetBucketMetadataOptions Configuration options for Bucket#getMetadata().
       * @property {string} [userProject] The ID of the project which will be
       *     billed for the request.
       */
      /**
       * Get the bucket's metadata.
       *
       * To set metadata, see {@link Bucket#setMetadata}.
       *
       * See {@link https://cloud.google.com/storage/docs/json_api/v1/buckets/get| Buckets: get API Documentation}
       *
       * @method Bucket#getMetadata
       * @param {GetBucketMetadataOptions} [options] Configuration options.
       * @param {string} [options.userProject] The ID of the project which will be
       *     billed for the request.
       * @param {GetBucketMetadataCallback} [callback] Callback function.
       * @returns {Promise<GetBucketMetadataResponse>}
       *
       * @example
       * ```
       * const {Storage} = require('@google-cloud/storage');
       * const storage = new Storage();
       * const bucket = storage.bucket('albums');
       *
       * bucket.getMetadata(function(err, metadata, apiResponse) {});
       *
       * //-
       * // If the callback is omitted, we'll return a Promise.
       * //-
       * bucket.getMetadata().then(function(data) {
       *   const metadata = data[0];
       *   const apiResponse = data[1];
       * });
       *
       * ```
       * @example <caption>include:samples/requesterPays.js</caption>
       * region_tag:storage_get_requester_pays_status
       * Example of retrieving the requester pays status of a bucket:
       */
      getMetadata: {
        reqOpts: {
          qs: o
        }
      },
      /**
       * @typedef {object} SetBucketMetadataOptions Configuration options for Bucket#setMetadata().
       * @property {string} [userProject] The ID of the project which will be
       *     billed for the request.
       */
      /**
       * @typedef {array} SetBucketMetadataResponse
       * @property {object} apiResponse The full API response.
       */
      /**
       * @callback SetBucketMetadataCallback
       * @param {?Error} err Request error, if any.
       * @param {object} metadata The bucket metadata.
       */
      /**
       * Set the bucket's metadata.
       *
       * See {@link https://cloud.google.com/storage/docs/json_api/v1/buckets/patch| Buckets: patch API Documentation}
       *
       * @method Bucket#setMetadata
       * @param {object<string, *>} metadata The metadata you wish to set.
       * @param {SetBucketMetadataOptions} [options] Configuration options.
       * @param {string} [options.userProject] The ID of the project which will be
       *     billed for the request.
       * @param {SetBucketMetadataCallback} [callback] Callback function.
       * @returns {Promise<SetBucketMetadataResponse>}
       *
       * @example
       * ```
       * const {Storage} = require('@google-cloud/storage');
       * const storage = new Storage();
       * const bucket = storage.bucket('albums');
       *
       * //-
       * // Set website metadata field on the bucket.
       * //-
       * const metadata = {
       *   website: {
       *     mainPageSuffix: 'http://example.com',
       *     notFoundPage: 'http://example.com/404.html'
       *   }
       * };
       *
       * bucket.setMetadata(metadata, function(err, apiResponse) {});
       *
       * //-
       * // Enable versioning for your bucket.
       * //-
       * bucket.setMetadata({
       *   versioning: {
       *     enabled: true
       *   }
       * }, function(err, apiResponse) {});
       *
       * //-
       * // Enable KMS encryption for objects within this bucket.
       * //-
       * bucket.setMetadata({
       *   encryption: {
       *     defaultKmsKeyName: 'projects/grape-spaceship-123/...'
       *   }
       * }, function(err, apiResponse) {});
       *
       * //-
       * // Set the default event-based hold value for new objects in this
       * // bucket.
       * //-
       * bucket.setMetadata({
       *   defaultEventBasedHold: true
       * }, function(err, apiResponse) {});
       *
       * //-
       * // Remove object lifecycle rules.
       * //-
       * bucket.setMetadata({
       *   lifecycle: null
       * }, function(err, apiResponse) {});
       *
       * //-
       * // If the callback is omitted, we'll return a Promise.
       * //-
       * bucket.setMetadata(metadata).then(function(data) {
       *   const apiResponse = data[0];
       * });
       * ```
       */
      setMetadata: {
        reqOpts: {
          qs: o
        }
      }
    };
    super({
      parent: e,
      baseUrl: "/b",
      id: t,
      createMethod: e.createBucket.bind(e),
      methods: p
    }), this.name = t, this.storage = e, this.userProject = i.userProject, this.acl = new ne({
      request: this.request.bind(this),
      pathPrefix: "/acl"
    }), this.acl.default = new ne({
      request: this.request.bind(this),
      pathPrefix: "/defaultObjectAcl"
    }), this.crc32cGenerator = i.crc32cGenerator || this.storage.crc32cGenerator, this.iam = new Ne(this), this.getFilesStream = Gt.paginator.streamify("getFiles"), this.instanceRetryValue = e.retryOptions.autoRetry, this.instancePreconditionOpts = i?.preconditionOpts;
  }
  /**
   * The bucket's Cloud Storage URI (`gs://`)
   *
   * @example
   * ```ts
   * const {Storage} = require('@google-cloud/storage');
   * const storage = new Storage();
   * const bucket = storage.bucket('my-bucket');
   *
   * // `gs://my-bucket`
   * const href = bucket.cloudStorageURI.href;
   * ```
   */
  get cloudStorageURI() {
    let e = new ss("gs://");
    return e.host = this.name, e;
  }
  /**
   * @typedef {object} AddLifecycleRuleOptions Configuration options for Bucket#addLifecycleRule().
   * @property {boolean} [append=true] The new rules will be appended to any
   *     pre-existing rules.
   */
  /**
   *
   * @typedef {object} LifecycleRule The new lifecycle rule to be added to objects
   *     in this bucket.
   * @property {string|object} action The action to be taken upon matching of
   *     all the conditions 'delete', 'setStorageClass', or 'AbortIncompleteMultipartUpload'.
   *     **Note**: For configuring a raw-formatted rule object to be passed as `action`
   *               please refer to the [examples]{@link https://cloud.google.com/storage/docs/managing-lifecycles#configexamples}.
   * @property {object} condition Condition a bucket must meet before the
   *     action occurs on the bucket. Refer to following supported [conditions]{@link https://cloud.google.com/storage/docs/lifecycle#conditions}.
   * @property {string} [storageClass] When using the `setStorageClass`
   *     action, provide this option to dictate which storage class the object
   *     should update to. Please see
   *     [SetStorageClass option documentation]{@link https://cloud.google.com/storage/docs/lifecycle#setstorageclass} for supported transitions.
   */
  /**
   * Add an object lifecycle management rule to the bucket.
   *
   * By default, an Object Lifecycle Management rule provided to this method
   * will be included to the existing policy. To replace all existing rules,
   * supply the `options` argument, setting `append` to `false`.
   *
   * To add multiple rules, pass a list to the `rule` parameter. Calling this
   * function multiple times asynchronously does not guarantee that all rules
   * are added correctly.
   *
   * See {@link https://cloud.google.com/storage/docs/lifecycle| Object Lifecycle Management}
   * See {@link https://cloud.google.com/storage/docs/json_api/v1/buckets/patch| Buckets: patch API Documentation}
   *
   * @param {LifecycleRule|LifecycleRule[]} rule The new lifecycle rule or rules to be added to objects
   *     in this bucket.
   * @param {string|object} rule.action The action to be taken upon matching of
   *     all the conditions 'delete', 'setStorageClass', or 'AbortIncompleteMultipartUpload'.
   *     **Note**: For configuring a raw-formatted rule object to be passed as `action`
   *               please refer to the [examples]{@link https://cloud.google.com/storage/docs/managing-lifecycles#configexamples}.
   * @param {object} rule.condition Condition a bucket must meet before the
   *     action occurson the bucket. Refer to followitn supported [conditions]{@link https://cloud.google.com/storage/docs/lifecycle#conditions}.
   * @param {string} [rule.storageClass] When using the `setStorageClass`
   *     action, provide this option to dictate which storage class the object
   *     should update to.
   * @param {AddLifecycleRuleOptions} [options] Configuration object.
   * @param {boolean} [options.append=true] Append the new rule to the existing
   *     policy.
   * @param {SetBucketMetadataCallback} [callback] Callback function.
   * @returns {Promise<SetBucketMetadataResponse>}
   *
   * @example
   * ```
   * const {Storage} = require('@google-cloud/storage');
   * const storage = new Storage();
   * const bucket = storage.bucket('albums');
   *
   * //-
   * // Automatically have an object deleted from this bucket once it is 3 years
   * // of age.
   * //-
   * bucket.addLifecycleRule({
   *   action: 'delete',
   *   condition: {
   *     age: 365 * 3 // Specified in days.
   *   }
   * }, function(err, apiResponse) {
   *   if (err) {
   *     // Error handling omitted.
   *   }
   *
   *   const lifecycleRules = bucket.metadata.lifecycle.rule;
   *
   *   // Iterate over the Object Lifecycle Management rules on this bucket.
   *   lifecycleRules.forEach(lifecycleRule => {});
   * });
   *
   * //-
   * // By default, the rule you provide will be added to the existing policy.
   * // Optionally, you can disable this behavior to replace all of the
   * // pre-existing rules.
   * //-
   * const options = {
   *   append: false
   * };
   *
   * bucket.addLifecycleRule({
   *   action: 'delete',
   *   condition: {
   *     age: 365 * 3 // Specified in days.
   *   }
   * }, options, function(err, apiResponse) {
   *   if (err) {
   *     // Error handling omitted.
   *   }
   *
   *   // All rules have been replaced with the new "delete" rule.
   *
   *   // Iterate over the Object Lifecycle Management rules on this bucket.
   *   lifecycleRules.forEach(lifecycleRule => {});
   * });
   *
   * //-
   * // For objects created before 2018, "downgrade" the storage class.
   * //-
   * bucket.addLifecycleRule({
   *   action: 'setStorageClass',
   *   storageClass: 'COLDLINE',
   *   condition: {
   *     createdBefore: new Date('2018')
   *   }
   * }, function(err, apiResponse) {});
   *
   * //-
   * // Delete objects created before 2016 which have the Coldline storage
   * // class.
   * //-
   * bucket.addLifecycleRule({
   *   action: 'delete',
   *   condition: {
   *     matchesStorageClass: [
   *       'COLDLINE'
   *     ],
   *     createdBefore: new Date('2016')
   *   }
   * }, function(err, apiResponse) {});
   *
   * //-
   * // Delete object that has a noncurrent timestamp that is at least 100 days.
   * //-
   * bucket.addLifecycleRule({
   *   action: 'delete',
   *   condition: {
   *     daysSinceNoncurrentTime: 100
   *   }
   * }, function(err, apiResponse) {});
   *
   * //-
   * // Delete object that has a noncurrent timestamp before 2020-01-01.
   * //-
   * bucket.addLifecycleRule({
   *   action: 'delete',
   *   condition: {
   *     noncurrentTimeBefore: new Date('2020-01-01')
   *   }
   * }, function(err, apiResponse) {});
   *
   * //-
   * // Delete object that has a customTime that is at least 100 days.
   * //-
   * bucket.addLifecycleRule({
   *   action: 'delete',
   *   condition: {
   *     daysSinceCustomTime: 100
   *   }
   * }, function(err, apiResponse) ());
   *
   * //-
   * // Delete object that has a customTime before 2020-01-01.
   * //-
   * bucket.addLifecycleRule({
   *   action: 'delete',
   *   condition: {
   *     customTimeBefore: new Date('2020-01-01')
   *   }
   * }, function(err, apiResponse) {});
   * ```
   */
  addLifecycleRule(e, t, i) {
    let n = {};
    typeof t == "function" ? i = t : t && (n = t), n = n || {};
    let s = Array.isArray(e) ? e : [e];
    for (let c of s)
      c.condition.createdBefore instanceof Date && (c.condition.createdBefore = c.condition.createdBefore.toISOString().replace(/T.+$/, "")), c.condition.customTimeBefore instanceof Date && (c.condition.customTimeBefore = c.condition.customTimeBefore.toISOString().replace(/T.+$/, "")), c.condition.noncurrentTimeBefore instanceof Date && (c.condition.noncurrentTimeBefore = c.condition.noncurrentTimeBefore.toISOString().replace(/T.+$/, ""));
    if (n.append === !1) {
      this.setMetadata({ lifecycle: { rule: s } }, n, i);
      return;
    }
    this.getMetadata((c, a) => {
      var o, l;
      if (c) {
        i(c);
        return;
      }
      let p = Array.isArray((o = a.lifecycle) === null || o === void 0 ? void 0 : o.rule) ? (l = a.lifecycle) === null || l === void 0 ? void 0 : l.rule : [];
      this.setMetadata({
        lifecycle: { rule: p.concat(s) }
      }, n, i);
    });
  }
  /**
   * @typedef {object} CombineOptions
   * @property {string} [kmsKeyName] Resource name of the Cloud KMS key, of
   *     the form
   *     `projects/my-project/locations/location/keyRings/my-kr/cryptoKeys/my-key`,
   *     that will be used to encrypt the object. Overwrites the object
   * metadata's `kms_key_name` value, if any.
   * @property {string} [userProject] The ID of the project which will be
   *     billed for the request.
   */
  /**
   * @callback CombineCallback
   * @param {?Error} err Request error, if any.
   * @param {File} newFile The new {@link File}.
   * @param {object} apiResponse The full API response.
   */
  /**
   * @typedef {array} CombineResponse
   * @property {File} 0 The new {@link File}.
   * @property {object} 1 The full API response.
   */
  /**
     * Combine multiple files into one new file.
     *
     * See {@link https://cloud.google.com/storage/docs/json_api/v1/objects/compose| Objects: compose API Documentation}
     *
     * @throws {Error} if a non-array is provided as sources argument.
     * @throws {Error} if no sources are provided.
     * @throws {Error} if no destination is provided.
     *
     * @param {string[]|File[]} sources The source files that will be
     *     combined.
     * @param {string|File} destination The file you would like the
     *     source files combined into.
     * @param {CombineOptions} [options] Configuration options.
     * @param {string} [options.kmsKeyName] Resource name of the Cloud KMS key, of
     *     the form
     *     `projects/my-project/locations/location/keyRings/my-kr/cryptoKeys/my-key`,
     *     that will be used to encrypt the object. Overwrites the object
     * metadata's `kms_key_name` value, if any.
     * @param {string} [options.userProject] The ID of the project which will be
     *     billed for the request.
  
     * @param {CombineCallback} [callback] Callback function.
     * @returns {Promise<CombineResponse>}
     *
     * @example
     * ```
     * const logBucket = storage.bucket('log-bucket');
     *
     * const sources = [
     *   logBucket.file('2013-logs.txt'),
     *   logBucket.file('2014-logs.txt')
     * ];
     *
     * const allLogs = logBucket.file('all-logs.txt');
     *
     * logBucket.combine(sources, allLogs, function(err, newFile, apiResponse) {
     *   // newFile === allLogs
     * });
     *
     * //-
     * // If the callback is omitted, we'll return a Promise.
     * //-
     * logBucket.combine(sources, allLogs).then(function(data) {
     *   const newFile = data[0];
     *   const apiResponse = data[1];
     * });
     * ```
     */
  combine(e, t, i, n) {
    var s;
    if (!Array.isArray(e) || e.length === 0)
      throw new Error(K.PROVIDE_SOURCE_FILE);
    if (!t)
      throw new Error(K.DESTINATION_FILE_NOT_SPECIFIED);
    let c = {};
    typeof i == "function" ? n = i : i && (c = i), this.disableAutoRetryConditionallyIdempotent_(
      this.methods.setMetadata,
      // Not relevant but param is required
      G.setMetadata,
      // Same as above
      c
    );
    let a = /* @__PURE__ */ d((p) => p instanceof H ? p : this.file(p), "convertToFile");
    e = e.map(a);
    let o = a(t);
    if (n = n || b.noop, !o.metadata.contentType) {
      let p = cr.default.getType(o.name) || void 0;
      p && (o.metadata.contentType = p);
    }
    let l = this.storage.retryOptions.maxRetries;
    (((s = o?.instancePreconditionOpts) === null || s === void 0 ? void 0 : s.ifGenerationMatch) === void 0 && c.ifGenerationMatch === void 0 && this.storage.retryOptions.idempotencyStrategy === _.RetryConditional || this.storage.retryOptions.idempotencyStrategy === _.RetryNever) && (l = 0), c.ifGenerationMatch === void 0 && Object.assign(c, o.instancePreconditionOpts, c), o.request({
      method: "POST",
      uri: "/compose",
      maxRetries: l,
      json: {
        destination: {
          contentType: o.metadata.contentType,
          contentEncoding: o.metadata.contentEncoding
        },
        sourceObjects: e.map((p) => {
          let u = {
            name: p.name
          };
          return p.metadata && p.metadata.generation && (u.generation = parseInt(p.metadata.generation.toString())), u;
        })
      },
      qs: c
    }, (p, u) => {
      if (this.storage.retryOptions.autoRetry = this.instanceRetryValue, p) {
        n(p, null, u);
        return;
      }
      n(null, o, u);
    });
  }
  /**
   * See a {@link https://cloud.google.com/storage/docs/json_api/v1/objects/watchAll| Objects: watchAll request body}.
   *
   * @typedef {object} CreateChannelConfig
   * @property {string} address The address where notifications are
   *     delivered for this channel.
   * @property {string} [delimiter] Returns results in a directory-like mode.
   * @property {number} [maxResults] Maximum number of `items` plus `prefixes`
   *     to return in a single page of responses.
   * @property {string} [pageToken] A previously-returned page token
   *     representing part of the larger set of results to view.
   * @property {string} [prefix] Filter results to objects whose names begin
   *     with this prefix.
   * @property {string} [projection=noAcl] Set of properties to return.
   * @property {string} [userProject] The ID of the project which will be
   *     billed for the request.
   * @property {boolean} [versions=false] If `true`, lists all versions of an object
   *     as distinct results.
   */
  /**
   * @typedef {object} CreateChannelOptions
   * @property {string} [userProject] The ID of the project which will be
   *     billed for the request.
   */
  /**
   * @typedef {array} CreateChannelResponse
   * @property {Channel} 0 The new {@link Channel}.
   * @property {object} 1 The full API response.
   */
  /**
   * @callback CreateChannelCallback
   * @param {?Error} err Request error, if any.
   * @param {Channel} channel The new {@link Channel}.
   * @param {object} apiResponse The full API response.
   */
  /**
   * Create a channel that will be notified when objects in this bucket changes.
   *
   * @throws {Error} If an ID is not provided.
   * @throws {Error} If an address is not provided.
   *
   * See {@link https://cloud.google.com/storage/docs/json_api/v1/objects/watchAll| Objects: watchAll API Documentation}
   *
   * @param {string} id The ID of the channel to create.
   * @param {CreateChannelConfig} config Configuration for creating channel.
   * @param {string} config.address The address where notifications are
   *     delivered for this channel.
   * @param {string} [config.delimiter] Returns results in a directory-like mode.
   * @param {number} [config.maxResults] Maximum number of `items` plus `prefixes`
   *     to return in a single page of responses.
   * @param {string} [config.pageToken] A previously-returned page token
   *     representing part of the larger set of results to view.
   * @param {string} [config.prefix] Filter results to objects whose names begin
   *     with this prefix.
   * @param {string} [config.projection=noAcl] Set of properties to return.
   * @param {string} [config.userProject] The ID of the project which will be
   *     billed for the request.
   * @param {boolean} [config.versions=false] If `true`, lists all versions of an object
   *     as distinct results.
   * @param {CreateChannelOptions} [options] Configuration options.
   * @param {string} [options.userProject] The ID of the project which will be
   *     billed for the request.
   * @param {CreateChannelCallback} [callback] Callback function.
   * @returns {Promise<CreateChannelResponse>}
   *
   * @example
   * ```
   * const {Storage} = require('@google-cloud/storage');
   * const storage = new Storage();
   * const bucket = storage.bucket('albums');
   * const id = 'new-channel-id';
   *
   * const config = {
   *   address: 'https://...'
   * };
   *
   * bucket.createChannel(id, config, function(err, channel, apiResponse) {
   *   if (!err) {
   *     // Channel created successfully.
   *   }
   * });
   *
   * //-
   * // If the callback is omitted, we'll return a Promise.
   * //-
   * bucket.createChannel(id, config).then(function(data) {
   *   const channel = data[0];
   *   const apiResponse = data[1];
   * });
   * ```
   */
  createChannel(e, t, i, n) {
    if (typeof e != "string")
      throw new Error(K.CHANNEL_ID_REQUIRED);
    let s = {};
    typeof i == "function" ? n = i : i && (s = i), this.request({
      method: "POST",
      uri: "/o/watch",
      json: Object.assign({
        id: e,
        type: "web_hook"
      }, t),
      qs: s
    }, (c, a) => {
      if (c) {
        n(c, null, a);
        return;
      }
      let o = a.resourceId, l = this.storage.channel(e, o);
      l.metadata = a, n(null, l, a);
    });
  }
  /**
   * Metadata to set for the Notification.
   *
   * @typedef {object} CreateNotificationOptions
   * @property {object} [customAttributes] An optional list of additional
   *     attributes to attach to each Cloud PubSub message published for this
   *     notification subscription.
   * @property {string[]} [eventTypes] If present, only send notifications about
   *     listed event types. If empty, sent notifications for all event types.
   * @property {string} [objectNamePrefix] If present, only apply this
   *     notification configuration to object names that begin with this prefix.
   * @property {string} [payloadFormat] The desired content of the Payload.
   * Defaults to `JSON_API_V1`.
   *
   * Acceptable values are:
   * - `JSON_API_V1`
   *
   * - `NONE`
   * @property {string} [userProject] The ID of the project which will be
   *     billed for the request.
   */
  /**
   * @callback CreateNotificationCallback
   * @param {?Error} err Request error, if any.
   * @param {Notification} notification The new {@link Notification}.
   * @param {object} apiResponse The full API response.
   */
  /**
   * @typedef {array} CreateNotificationResponse
   * @property {Notification} 0 The new {@link Notification}.
   * @property {object} 1 The full API response.
   */
  /**
   * Creates a notification subscription for the bucket.
   *
   * See {@link https://cloud.google.com/storage/docs/json_api/v1/notifications/insert| Notifications: insert}
   *
   * @param {Topic|string} topic The Cloud PubSub topic to which this
   * subscription publishes. If the project ID is omitted, the current
   * project ID will be used.
   *
   * Acceptable formats are:
   * - `projects/grape-spaceship-123/topics/my-topic`
   *
   * - `my-topic`
   * @param {CreateNotificationOptions} [options] Metadata to set for the
   *     notification.
   * @param {object} [options.customAttributes] An optional list of additional
   *     attributes to attach to each Cloud PubSub message published for this
   *     notification subscription.
   * @param {string[]} [options.eventTypes] If present, only send notifications about
   *     listed event types. If empty, sent notifications for all event types.
   * @param {string} [options.objectNamePrefix] If present, only apply this
   *     notification configuration to object names that begin with this prefix.
   * @param {string} [options.payloadFormat] The desired content of the Payload.
   * Defaults to `JSON_API_V1`.
   *
   * Acceptable values are:
   * - `JSON_API_V1`
   *
   * - `NONE`
   * @param {string} [options.userProject] The ID of the project which will be
   *     billed for the request.
   * @param {CreateNotificationCallback} [callback] Callback function.
   * @returns {Promise<CreateNotificationResponse>}
   * @throws {Error} If a valid topic is not provided.
   * @see Notification#create
   *
   * @example
   * ```
   * const {Storage} = require('@google-cloud/storage');
   * const storage = new Storage();
   * const myBucket = storage.bucket('my-bucket');
   *
   * const callback = function(err, notification, apiResponse) {
   *   if (!err) {
   *     // The notification was created successfully.
   *   }
   * };
   *
   * myBucket.createNotification('my-topic', callback);
   *
   * //-
   * // Configure the nofiication by providing Notification metadata.
   * //-
   * const metadata = {
   *   objectNamePrefix: 'prefix-'
   * };
   *
   * myBucket.createNotification('my-topic', metadata, callback);
   *
   * //-
   * // If the callback is omitted, we'll return a Promise.
   * //-
   * myBucket.createNotification('my-topic').then(function(data) {
   *   const notification = data[0];
   *   const apiResponse = data[1];
   * });
   *
   * ```
   * @example <caption>include:samples/createNotification.js</caption>
   * region_tag:storage_create_bucket_notifications
   * Another example:
   */
  createNotification(e, t, i) {
    let n = {};
    if (typeof t == "function" ? i = t : t && (n = t), e !== null && typeof e == "object" && b.isCustomType(e, "pubsub/topic") && (e = e.name), typeof e != "string")
      throw new Error(K.TOPIC_NAME_REQUIRED);
    let c = Object.assign({ topic: e }, n);
    c.topic.indexOf("projects") !== 0 && (c.topic = "projects/{{projectId}}/topics/" + c.topic), c.topic = `//pubsub.${this.storage.universeDomain}/` + c.topic, c.payloadFormat || (c.payloadFormat = "JSON_API_V1");
    let a = {};
    c.userProject && (a.userProject = c.userProject, delete c.userProject), this.request({
      method: "POST",
      uri: "/notificationConfigs",
      json: We(c),
      qs: a,
      maxRetries: 0
      //explicitly set this value since this is a non-idempotent function
    }, (o, l) => {
      if (o) {
        i(o, null, l);
        return;
      }
      let p = this.notification(l.id);
      p.metadata = l, i(null, p, l);
    });
  }
  /**
   * @typedef {object} DeleteFilesOptions Query object. See {@link Bucket#getFiles}
   *     for all of the supported properties.
   * @property {boolean} [force] Suppress errors until all files have been
   *     processed.
   */
  /**
   * @callback DeleteFilesCallback
   * @param {?Error|?Error[]} err Request error, if any, or array of errors from
   *     files that were not able to be deleted.
   * @param {object} [apiResponse] The full API response.
   */
  /**
   * Iterate over the bucket's files, calling `file.delete()` on each.
   *
   * <strong>This is not an atomic request.</strong> A delete attempt will be
   * made for each file individually. Any one can fail, in which case only a
   * portion of the files you intended to be deleted would have.
   *
   * Operations are performed in parallel, up to 10 at once. The first error
   * breaks the loop and will execute the provided callback with it. Specify
   * `{ force: true }` to suppress the errors until all files have had a chance
   * to be processed.
   *
   * File preconditions cannot be passed to this function. It will not retry unless
   * the idempotency strategy is set to retry always.
   *
   * The `query` object passed as the first argument will also be passed to
   * {@link Bucket#getFiles}.
   *
   * See {@link https://cloud.google.com/storage/docs/json_api/v1/objects/delete| Objects: delete API Documentation}
   *
   * @param {DeleteFilesOptions} [query] Query object. See {@link Bucket#getFiles}
   * @param {boolean} [query.force] Suppress errors until all files have been
   *     processed.
   * @param {DeleteFilesCallback} [callback] Callback function.
   * @returns {Promise}
   *
   * @example
   * ```
   * const {Storage} = require('@google-cloud/storage');
   * const storage = new Storage();
   * const bucket = storage.bucket('albums');
   *
   * //-
   * // Delete all of the files in the bucket.
   * //-
   * bucket.deleteFiles(function(err) {});
   *
   * //-
   * // By default, if a file cannot be deleted, this method will stop deleting
   * // files from your bucket. You can override this setting with `force:
   * // true`.
   * //-
   * bucket.deleteFiles({
   *   force: true
   * }, function(errors) {
   *   // `errors`:
   *   //    Array of errors if any occurred, otherwise null.
   * });
   *
   * //-
   * // The first argument to this method acts as a query to
   * // {@link Bucket#getFiles}. As an example, you can delete files
   * // which match a prefix.
   * //-
   * bucket.deleteFiles({
   *   prefix: 'images/'
   * }, function(err) {
   *   if (!err) {
   *     // All files in the `images` directory have been deleted.
   *   }
   * });
   *
   * //-
   * // If the callback is omitted, we'll return a Promise.
   * //-
   * bucket.deleteFiles().then(function() {});
   * ```
   */
  deleteFiles(e, t) {
    let i = {};
    typeof e == "function" ? t = e : e && (i = e);
    let n = 10, s = 1e3, c = [], a = /* @__PURE__ */ d((o) => o.delete(i).catch((l) => {
      if (!i.force)
        throw l;
      c.push(l);
    }), "deleteFile");
    (async () => {
      try {
        let o = [], l = (0, Ft.default)(n), p = this.getFilesStream(i);
        for await (let u of p)
          o.length >= s && (await Promise.all(o), o = []), o.push(l(() => a(u)).catch((f) => {
            throw p.destroy(), f;
          }));
        await Promise.all(o), t(c.length > 0 ? c : null);
      } catch (o) {
        t(o);
        return;
      }
    })();
  }
  /**
   * @deprecated
   * @typedef {array} DeleteLabelsResponse
   * @property {object} 0 The full API response.
   */
  /**
   * @deprecated
   * @callback DeleteLabelsCallback
   * @param {?Error} err Request error, if any.
   * @param {object} metadata Bucket's metadata.
   */
  /**
   * @deprecated Use setMetadata directly
   * Delete one or more labels from this bucket.
   *
   * @param {string|string[]} [labels] The labels to delete. If no labels are
   *     provided, all of the labels are removed.
   * @param {DeleteLabelsCallback} [callback] Callback function.
   * @param {DeleteLabelsOptions} [options] Options, including precondition options
   * @returns {Promise<DeleteLabelsResponse>}
   *
   * @example
   * ```
   * const {Storage} = require('@google-cloud/storage');
   * const storage = new Storage();
   * const bucket = storage.bucket('albums');
   *
   * //-
   * // Delete all of the labels from this bucket.
   * //-
   * bucket.deleteLabels(function(err, apiResponse) {});
   *
   * //-
   * // Delete a single label.
   * //-
   * bucket.deleteLabels('labelone', function(err, apiResponse) {});
   *
   * //-
   * // Delete a specific set of labels.
   * //-
   * bucket.deleteLabels([
   *   'labelone',
   *   'labeltwo'
   * ], function(err, apiResponse) {});
   *
   * //-
   * // If the callback is omitted, we'll return a Promise.
   * //-
   * bucket.deleteLabels().then(function(data) {
   *   const apiResponse = data[0];
   * });
   * ```
   */
  deleteLabels(e, t, i) {
    let n = new Array(), s = {};
    typeof e == "function" ? i = e : typeof e == "string" ? n = [e] : Array.isArray(e) ? n = e : e && (s = e), typeof t == "function" ? i = t : t && (s = t);
    let c = /* @__PURE__ */ d((a) => {
      let o = a.reduce((l, p) => (l[p] = null, l), {});
      s?.ifMetagenerationMatch !== void 0 ? this.setLabels(o, s, i) : this.setLabels(o, i);
    }, "deleteLabels");
    n.length === 0 ? this.getLabels((a, o) => {
      if (a) {
        i(a);
        return;
      }
      c(Object.keys(o));
    }) : c(n);
  }
  /**
   * @typedef {array} DisableRequesterPaysResponse
   * @property {object} 0 The full API response.
   */
  /**
   * @callback DisableRequesterPaysCallback
   * @param {?Error} err Request error, if any.
   * @param {object} apiResponse The full API response.
   */
  /**
   * <div class="notice">
   *   <strong>Early Access Testers Only</strong>
   *   <p>
   *     This feature is not yet widely-available.
   *   </p>
   * </div>
   *
   * Disable `requesterPays` functionality from this bucket.
   *
   * @param {DisableRequesterPaysCallback} [callback] Callback function.
   * @param {DisableRequesterPaysOptions} [options] Options, including precondition options
   * @returns {Promise<DisableRequesterPaysCallback>}
   *
   * @example
   * ```
   * const {Storage} = require('@google-cloud/storage');
   * const storage = new Storage();
   * const bucket = storage.bucket('albums');
   *
   * bucket.disableRequesterPays(function(err, apiResponse) {
   *   if (!err) {
   *     // requesterPays functionality disabled successfully.
   *   }
   * });
   *
   * //-
   * // If the callback is omitted, we'll return a Promise.
   * //-
   * bucket.disableRequesterPays().then(function(data) {
   *   const apiResponse = data[0];
   * });
   *
   * ```
   * @example <caption>include:samples/requesterPays.js</caption>
   * region_tag:storage_disable_requester_pays
   * Example of disabling requester pays:
   */
  disableRequesterPays(e, t) {
    let i = {};
    typeof e == "function" ? t = e : e && (i = e), this.setMetadata({
      billing: {
        requesterPays: !1
      }
    }, i, t);
  }
  /**
   * Configuration object for enabling logging.
   *
   * @typedef {object} EnableLoggingOptions
   * @property {string|Bucket} [bucket] The bucket for the log entries. By
   *     default, the current bucket is used.
   * @property {string} prefix A unique prefix for log object names.
   */
  /**
   * Enable logging functionality for this bucket. This will make two API
   * requests, first to grant Cloud Storage WRITE permission to the bucket, then
   * to set the appropriate configuration on the Bucket's metadata.
   *
   * @param {EnableLoggingOptions} config Configuration options.
   * @param {string|Bucket} [config.bucket] The bucket for the log entries. By
   *     default, the current bucket is used.
   * @param {string} config.prefix A unique prefix for log object names.
   * @param {SetBucketMetadataCallback} [callback] Callback function.
   * @returns {Promise<SetBucketMetadataResponse>}
   *
   * @example
   * ```
   * const {Storage} = require('@google-cloud/storage');
   * const storage = new Storage();
   * const bucket = storage.bucket('albums');
   *
   * const config = {
   *   prefix: 'log'
   * };
   *
   * bucket.enableLogging(config, function(err, apiResponse) {
   *   if (!err) {
   *     // Logging functionality enabled successfully.
   *   }
   * });
   *
   * ```
   * @example
   * Optionally, provide a destination bucket.
   * ```
   * const config = {
   *   prefix: 'log',
   *   bucket: 'destination-bucket'
   * };
   *
   * bucket.enableLogging(config, function(err, apiResponse) {});
   * ```
   *
   * @example
   * If the callback is omitted, we'll return a Promise.
   * ```
   * bucket.enableLogging(config).then(function(data) {
   *   const apiResponse = data[0];
   * });
   * ```
   */
  enableLogging(e, t) {
    if (!e || typeof e == "function" || typeof e.prefix > "u")
      throw new Error(K.CONFIGURATION_OBJECT_PREFIX_REQUIRED);
    let i = this.id;
    e.bucket && e.bucket instanceof r ? i = e.bucket.id : e.bucket && typeof e.bucket == "string" && (i = e.bucket);
    let n = {};
    e?.ifMetagenerationMatch && (n.ifMetagenerationMatch = e.ifMetagenerationMatch), e?.ifMetagenerationNotMatch && (n.ifMetagenerationNotMatch = e.ifMetagenerationNotMatch), (async () => {
      try {
        let [s] = await this.iam.getPolicy();
        s.bindings.push({
          members: ["group:cloud-storage-analytics@google.com"],
          role: "roles/storage.objectCreator"
        }), await this.iam.setPolicy(s), this.setMetadata({
          logging: {
            logBucket: i,
            logObjectPrefix: e.prefix
          }
        }, n, t);
      } catch (s) {
        t(s);
        return;
      }
    })();
  }
  /**
   * @typedef {array} EnableRequesterPaysResponse
   * @property {object} 0 The full API response.
   */
  /**
   * @callback EnableRequesterPaysCallback
   * @param {?Error} err Request error, if any.
   * @param {object} apiResponse The full API response.
   */
  /**
   * <div class="notice">
   *   <strong>Early Access Testers Only</strong>
   *   <p>
   *     This feature is not yet widely-available.
   *   </p>
   * </div>
   *
   * Enable `requesterPays` functionality for this bucket. This enables you, the
   * bucket owner, to have the requesting user assume the charges for the access
   * to your bucket and its contents.
   *
   * @param {EnableRequesterPaysCallback | EnableRequesterPaysOptions} [optionsOrCallback]
   * Callback function or precondition options.
   * @returns {Promise<EnableRequesterPaysResponse>}
   *
   * @example
   * ```
   * const {Storage} = require('@google-cloud/storage');
   * const storage = new Storage();
   * const bucket = storage.bucket('albums');
   *
   * bucket.enableRequesterPays(function(err, apiResponse) {
   *   if (!err) {
   *     // requesterPays functionality enabled successfully.
   *   }
   * });
   *
   * //-
   * // If the callback is omitted, we'll return a Promise.
   * //-
   * bucket.enableRequesterPays().then(function(data) {
   *   const apiResponse = data[0];
   * });
   *
   * ```
   * @example <caption>include:samples/requesterPays.js</caption>
   * region_tag:storage_enable_requester_pays
   * Example of enabling requester pays:
   */
  enableRequesterPays(e, t) {
    let i = {};
    typeof e == "function" ? t = e : e && (i = e), this.setMetadata({
      billing: {
        requesterPays: !0
      }
    }, i, t);
  }
  /**
   * Create a {@link File} object. See {@link File} to see how to handle
   * the different use cases you may have.
   *
   * @param {string} name The name of the file in this bucket.
   * @param {FileOptions} [options] Configuration options.
   * @param {string|number} [options.generation] Only use a specific revision of
   *     this file.
   * @param {string} [options.encryptionKey] A custom encryption key. See
   *     {@link https://cloud.google.com/storage/docs/encryption#customer-supplied| Customer-supplied Encryption Keys}.
   * @param {string} [options.kmsKeyName] The name of the Cloud KMS key that will
   *     be used to encrypt the object. Must be in the format:
   *     `projects/my-project/locations/location/keyRings/my-kr/cryptoKeys/my-key`.
   *     KMS key ring must use the same location as the bucket.
   * @param {string} [options.userProject] The ID of the project which will be
   *     billed for all requests made from File object.
   * @returns {File}
   *
   * @example
   * ```
   * const {Storage} = require('@google-cloud/storage');
   * const storage = new Storage();
   * const bucket = storage.bucket('albums');
   * const file = bucket.file('my-existing-file.png');
   * ```
   */
  file(e, t) {
    if (!e)
      throw Error(K.SPECIFY_FILE_NAME);
    return new H(this, e, t);
  }
  /**
   * @typedef {array} GetFilesResponse
   * @property {File[]} 0 Array of {@link File} instances.
   * @param {object} nextQuery 1 A query object to receive more results.
   * @param {object} apiResponse 2 The full API response.
   */
  /**
   * @callback GetFilesCallback
   * @param {?Error} err Request error, if any.
   * @param {File[]} files Array of {@link File} instances.
   * @param {object} nextQuery A query object to receive more results.
   * @param {object} apiResponse The full API response.
   */
  /**
   * Query object for listing files.
   *
   * @typedef {object} GetFilesOptions
   * @property {boolean} [autoPaginate=true] Have pagination handled
   *     automatically.
   * @property {string} [delimiter] Results will contain only objects whose
   *     names, aside from the prefix, do not contain delimiter. Objects whose
   *     names, aside from the prefix, contain delimiter will have their name
   *     truncated after the delimiter, returned in `apiResponse.prefixes`.
   *     Duplicate prefixes are omitted.
   * @property {string} [endOffset] Filter results to objects whose names are
   * lexicographically before endOffset. If startOffset is also set, the objects
   * listed have names between startOffset (inclusive) and endOffset (exclusive).
   * @property {boolean} [includeFoldersAsPrefixes] If true, includes folders and
   * managed folders in the set of prefixes returned by the query. Only applicable if
   * delimiter is set to / and autoPaginate is set to false.
   * See: https://cloud.google.com/storage/docs/managed-folders
   * @property {boolean} [includeTrailingDelimiter] If true, objects that end in
   * exactly one instance of delimiter have their metadata included in items[]
   * in addition to the relevant part of the object name appearing in prefixes[].
   * @property {string} [prefix] Filter results to objects whose names begin
   *     with this prefix.
   * @property {string} [matchGlob] A glob pattern used to filter results,
   *     for example foo*bar
   * @property {number} [maxApiCalls] Maximum number of API calls to make.
   * @property {number} [maxResults] Maximum number of items plus prefixes to
   *     return per call.
   *     Note: By default will handle pagination automatically
   *     if more than 1 page worth of results are requested per call.
   *     When `autoPaginate` is set to `false` the smaller of `maxResults`
   *     or 1 page of results will be returned per call.
   * @property {string} [pageToken] A previously-returned page token
   *     representing part of the larger set of results to view.
   * @property {boolean} [softDeleted] If true, only soft-deleted object versions will be
   *     listed as distinct results in order of generation number. Note `soft_deleted` and
   *     `versions` cannot be set to true simultaneously.
   * @property {string} [startOffset] Filter results to objects whose names are
   * lexicographically equal to or after startOffset. If endOffset is also set,
   * the objects listed have names between startOffset (inclusive) and endOffset (exclusive).
   * @property {string} [userProject] The ID of the project which will be
   *     billed for the request.
   * @property {boolean} [versions] If true, returns File objects scoped to
   *     their versions.
   */
  /**
   * Get {@link File} objects for the files currently in the bucket.
   *
   * See {@link https://cloud.google.com/storage/docs/json_api/v1/objects/list| Objects: list API Documentation}
   *
   * @param {GetFilesOptions} [query] Query object for listing files.
   * @param {boolean} [query.autoPaginate=true] Have pagination handled
   *     automatically.
   * @param {string} [query.delimiter] Results will contain only objects whose
   *     names, aside from the prefix, do not contain delimiter. Objects whose
   *     names, aside from the prefix, contain delimiter will have their name
   *     truncated after the delimiter, returned in `apiResponse.prefixes`.
   *     Duplicate prefixes are omitted.
   * @param {string} [query.endOffset] Filter results to objects whose names are
   * lexicographically before endOffset. If startOffset is also set, the objects
   * listed have names between startOffset (inclusive) and endOffset (exclusive).
   * @param {boolean} [query.includeFoldersAsPrefixes] If true, includes folders and
   * managed folders in the set of prefixes returned by the query. Only applicable if
   * delimiter is set to / and autoPaginate is set to false.
   * See: https://cloud.google.com/storage/docs/managed-folders
   * @param {boolean} [query.includeTrailingDelimiter] If true, objects that end in
   * exactly one instance of delimiter have their metadata included in items[]
   * in addition to the relevant part of the object name appearing in prefixes[].
   * @param {string} [query.prefix] Filter results to objects whose names begin
   *     with this prefix.
   * @param {number} [query.maxApiCalls] Maximum number of API calls to make.
   * @param {number} [query.maxResults] Maximum number of items plus prefixes to
   *     return per call.
   *     Note: By default will handle pagination automatically
   *     if more than 1 page worth of results are requested per call.
   *     When `autoPaginate` is set to `false` the smaller of `maxResults`
   *     or 1 page of results will be returned per call.
   * @param {string} [query.pageToken] A previously-returned page token
   *     representing part of the larger set of results to view.
   * @param {boolean} [query.softDeleted] If true, only soft-deleted object versions will be
   *     listed as distinct results in order of generation number. Note `soft_deleted` and
   *     `versions` cannot be set to true simultaneously.
   * @param {string} [query.startOffset] Filter results to objects whose names are
   * lexicographically equal to or after startOffset. If endOffset is also set,
   * the objects listed have names between startOffset (inclusive) and endOffset (exclusive).
   * @param {string} [query.userProject] The ID of the project which will be
   *     billed for the request.
   * @param {boolean} [query.versions] If true, returns File objects scoped to
   *     their versions.
   * @param {GetFilesCallback} [callback] Callback function.
   * @returns {Promise<GetFilesResponse>}
   *
   * @example
   * ```
   * const {Storage} = require('@google-cloud/storage');
   * const storage = new Storage();
   * const bucket = storage.bucket('albums');
   *
   * bucket.getFiles(function(err, files) {
   *   if (!err) {
   *     // files is an array of File objects.
   *   }
   * });
   *
   * //-
   * // If your bucket has versioning enabled, you can get all of your files
   * // scoped to their generation.
   * //-
   * bucket.getFiles({
   *   versions: true
   * }, function(err, files) {
   *   // Each file is scoped to its generation.
   * });
   *
   * //-
   * // To control how many API requests are made and page through the results
   * // manually, set `autoPaginate` to `false`.
   * //-
   * const callback = function(err, files, nextQuery, apiResponse) {
   *   if (nextQuery) {
   *     // More results exist.
   *     bucket.getFiles(nextQuery, callback);
   *   }
   *
   *   // The `metadata` property is populated for you with the metadata at the
   *   // time of fetching.
   *   files[0].metadata;
   *
   *   // However, in cases where you are concerned the metadata could have
   *   // changed, use the `getMetadata` method.
   *   files[0].getMetadata(function(err, metadata) {});
   * };
   *
   * bucket.getFiles({
   *   autoPaginate: false
   * }, callback);
   *
   * //-
   * // If the callback is omitted, we'll return a Promise.
   * //-
   * bucket.getFiles().then(function(data) {
   *   const files = data[0];
   * });
   *
   * ```
   * @example
   * <h6>Simulating a File System</h6><p>With `autoPaginate: false`, it's possible to iterate over files which incorporate a common structure using a delimiter.</p><p>Consider the following remote objects:</p><ol><li>"a"</li><li>"a/b/c/d"</li><li>"b/d/e"</li></ol><p>Using a delimiter of `/` will return a single file, "a".</p><p>`apiResponse.prefixes` will return the "sub-directories" that were found:</p><ol><li>"a/"</li><li>"b/"</li></ol>
   * ```
   * bucket.getFiles({
   *   autoPaginate: false,
   *   delimiter: '/'
   * }, function(err, files, nextQuery, apiResponse) {
   *   // files = [
   *   //   {File} // File object for file "a"
   *   // ]
   *
   *   // apiResponse.prefixes = [
   *   //   'a/',
   *   //   'b/'
   *   // ]
   * });
   * ```
   *
   * @example
   * Using prefixes, it's now possible to simulate a file system with follow-up requests.
   * ```
   * bucket.getFiles({
   *   autoPaginate: false,
   *   delimiter: '/',
   *   prefix: 'a/'
   * }, function(err, files, nextQuery, apiResponse) {
   *   // No files found within "directory" a.
   *   // files = []
   *
   *   // However, a "sub-directory" was found.
   *   // This prefix can be used to continue traversing the "file system".
   *   // apiResponse.prefixes = [
   *   //   'a/b/'
   *   // ]
   * });
   * ```
   *
   * @example <caption>include:samples/files.js</caption>
   * region_tag:storage_list_files
   * Another example:
   *
   * @example <caption>include:samples/files.js</caption>
   * region_tag:storage_list_files_with_prefix
   * Example of listing files, filtered by a prefix:
   */
  getFiles(e, t) {
    let i = typeof e == "object" ? e : {};
    t || (t = e), i = Object.assign({}, i), i.fields && i.autoPaginate && !i.fields.includes("nextPageToken") && (i.fields = `${i.fields},nextPageToken`), this.request({
      uri: "/o",
      qs: i
    }, (n, s) => {
      if (n) {
        t(n, null, null, s);
        return;
      }
      let a = (s.items ? s.items : []).map((l) => {
        let p = {};
        if (i.fields)
          return l;
        i.versions && (p.generation = l.generation), l.kmsKeyName && (p.kmsKeyName = l.kmsKeyName);
        let u = this.file(l.name, p);
        return u.metadata = l, u;
      }), o = null;
      s.nextPageToken && (o = Object.assign({}, i, {
        pageToken: s.nextPageToken
      })), t(null, a, o, s);
    });
  }
  /**
   * @deprecated
   * @typedef {object} GetLabelsOptions Configuration options for Bucket#getLabels().
   * @param {string} [userProject] The ID of the project which will be
   *     billed for the request.
   */
  /**
   * @deprecated
   * @typedef {array} GetLabelsResponse
   * @property {object} 0 Object of labels currently set on this bucket.
   */
  /**
   * @deprecated
   * @callback GetLabelsCallback
   * @param {?Error} err Request error, if any.
   * @param {object} labels Object of labels currently set on this bucket.
   */
  /**
   * @deprecated Use getMetadata directly.
   * Get the labels currently set on this bucket.
   *
   * @param {object} [options] Configuration options.
   * @param {string} [options.userProject] The ID of the project which will be
   *     billed for the request.
   * @param {GetLabelsCallback} [callback] Callback function.
   * @returns {Promise<GetLabelsCallback>}
   *
   * @example
   * ```
   * const {Storage} = require('@google-cloud/storage');
   * const storage = new Storage();
   * const bucket = storage.bucket('albums');
   *
   * bucket.getLabels(function(err, labels) {
   *   if (err) {
   *     // Error handling omitted.
   *   }
   *
   *   // labels = {
   *   //   label: 'labelValue',
   *   //   ...
   *   // }
   * });
   *
   * //-
   * // If the callback is omitted, we'll return a Promise.
   * //-
   * bucket.getLabels().then(function(data) {
   *   const labels = data[0];
   * });
   * ```
   */
  getLabels(e, t) {
    let i = {};
    typeof e == "function" ? t = e : e && (i = e), this.getMetadata(i, (n, s) => {
      if (n) {
        t(n, null);
        return;
      }
      t(null, s?.labels || {});
    });
  }
  /**
   * @typedef {object} GetNotificationsOptions Configuration options for Bucket#getNotification().
   * @property {string} [userProject] The ID of the project which will be
   *     billed for the request.
   */
  /**
   * @callback GetNotificationsCallback
   * @param {?Error} err Request error, if any.
   * @param {Notification[]} notifications Array of {@link Notification}
   *     instances.
   * @param {object} apiResponse The full API response.
   */
  /**
   * @typedef {array} GetNotificationsResponse
   * @property {Notification[]} 0 Array of {@link Notification} instances.
   * @property {object} 1 The full API response.
   */
  /**
   * Retrieves a list of notification subscriptions for a given bucket.
   *
   * See {@link https://cloud.google.com/storage/docs/json_api/v1/notifications/list| Notifications: list}
   *
   * @param {GetNotificationsOptions} [options] Configuration options.
   * @param {string} [options.userProject] The ID of the project which will be
   *     billed for the request.
   * @param {GetNotificationsCallback} [callback] Callback function.
   * @returns {Promise<GetNotificationsResponse>}
   *
   * @example
   * ```
   * const {Storage} = require('@google-cloud/storage');
   * const storage = new Storage();
   * const bucket = storage.bucket('my-bucket');
   *
   * bucket.getNotifications(function(err, notifications, apiResponse) {
   *   if (!err) {
   *     // notifications is an array of Notification objects.
   *   }
   * });
   *
   * //-
   * // If the callback is omitted, we'll return a Promise.
   * //-
   * bucket.getNotifications().then(function(data) {
   *   const notifications = data[0];
   *   const apiResponse = data[1];
   * });
   *
   * ```
   * @example <caption>include:samples/listNotifications.js</caption>
   * region_tag:storage_list_bucket_notifications
   * Another example:
   */
  getNotifications(e, t) {
    let i = {};
    typeof e == "function" ? t = e : e && (i = e), this.request({
      uri: "/notificationConfigs",
      qs: i
    }, (n, s) => {
      if (n) {
        t(n, null, s);
        return;
      }
      let a = (s.items ? s.items : []).map((o) => {
        let l = this.notification(o.id);
        return l.metadata = o, l;
      });
      t(null, a, s);
    });
  }
  /**
   * @typedef {array} GetSignedUrlResponse
   * @property {object} 0 The signed URL.
   */
  /**
   * @callback GetSignedUrlCallback
   * @param {?Error} err Request error, if any.
   * @param {object} url The signed URL.
   */
  /**
   * @typedef {object} GetBucketSignedUrlConfig
   * @property {string} action Only listing objects within a bucket (HTTP: GET) is supported for bucket-level signed URLs.
   * @property {*} expires A timestamp when this link will expire. Any value
   *     given is passed to `new Date()`.
   *     Note: 'v4' supports maximum duration of 7 days (604800 seconds) from now.
   * @property {string} [version='v2'] The signing version to use, either
   *     'v2' or 'v4'.
   * @property {boolean} [virtualHostedStyle=false] Use virtual hosted-style
   *     URLs ('https://mybucket.storage.googleapis.com/...') instead of path-style
   *     ('https://storage.googleapis.com/mybucket/...'). Virtual hosted-style URLs
   *     should generally be preferred instaed of path-style URL.
   *     Currently defaults to `false` for path-style, although this may change in a
   *     future major-version release.
   * @property {string} [cname] The cname for this bucket, i.e.,
   *     "https://cdn.example.com".
   *     See [reference]{@link https://cloud.google.com/storage/docs/access-control/signed-urls#example}
   * @property {object} [extensionHeaders] If these headers are used, the
   * server will check to make sure that the client provides matching
   * values. See {@link https://cloud.google.com/storage/docs/access-control/signed-urls#about-canonical-extension-headers| Canonical extension headers}
   * for the requirements of this feature, most notably:
   * - The header name must be prefixed with `x-goog-`
   * - The header name must be all lowercase
   *
   * Note: Multi-valued header passed as an array in the extensionHeaders
   *       object is converted into a string, delimited by `,` with
   *       no space. Requests made using the signed URL will need to
   *       delimit multi-valued headers using a single `,` as well, or
   *       else the server will report a mismatched signature.
   * @property {object} [queryParams] Additional query parameters to include
   *     in the signed URL.
   */
  /**
   * Get a signed URL to allow limited time access to a bucket.
   *
   * In Google Cloud Platform environments, such as Cloud Functions and App
   * Engine, you usually don't provide a `keyFilename` or `credentials` during
   * instantiation. In those environments, we call the
   * {@link https://cloud.google.com/iam/docs/reference/credentials/rest/v1/projects.serviceAccounts/signBlob| signBlob API}
   * to create a signed URL. That API requires either the
   * `https://www.googleapis.com/auth/iam` or
   * `https://www.googleapis.com/auth/cloud-platform` scope, so be sure they are
   * enabled.
   *
   * See {@link https://cloud.google.com/storage/docs/access-control/signed-urls| Signed URLs Reference}
   *
   * @throws {Error} if an expiration timestamp from the past is given.
   *
   * @param {GetBucketSignedUrlConfig} config Configuration object.
   * @param {string} config.action Currently only supports "list" (HTTP: GET).
   * @param {*} config.expires A timestamp when this link will expire. Any value
   *     given is passed to `new Date()`.
   *     Note: 'v4' supports maximum duration of 7 days (604800 seconds) from now.
   * @param {string} [config.version='v2'] The signing version to use, either
   *     'v2' or 'v4'.
   * @param {boolean} [config.virtualHostedStyle=false] Use virtual hosted-style
   *     URLs ('https://mybucket.storage.googleapis.com/...') instead of path-style
   *     ('https://storage.googleapis.com/mybucket/...'). Virtual hosted-style URLs
   *     should generally be preferred instaed of path-style URL.
   *     Currently defaults to `false` for path-style, although this may change in a
   *     future major-version release.
   * @param {string} [config.cname] The cname for this bucket, i.e.,
   *     "https://cdn.example.com".
   *     See [reference]{@link https://cloud.google.com/storage/docs/access-control/signed-urls#example}
   * @param {object} [config.extensionHeaders] If these headers are used, the
   * server will check to make sure that the client provides matching
   * values. See {@link https://cloud.google.com/storage/docs/access-control/signed-urls#about-canonical-extension-headers| Canonical extension headers}
   * for the requirements of this feature, most notably:
   * - The header name must be prefixed with `x-goog-`
   * - The header name must be all lowercase
   *
   * Note: Multi-valued header passed as an array in the extensionHeaders
   *       object is converted into a string, delimited by `,` with
   *       no space. Requests made using the signed URL will need to
   *       delimit multi-valued headers using a single `,` as well, or
   *       else the server will report a mismatched signature.
   * @property {object} [config.queryParams] Additional query parameters to include
   *     in the signed URL.
   * @param {GetSignedUrlCallback} [callback] Callback function.
   * @returns {Promise<GetSignedUrlResponse>}
   *
   * @example
   * ```
   * const {Storage} = require('@google-cloud/storage');
   * const storage = new Storage();
   * const myBucket = storage.bucket('my-bucket');
   *
   * //-
   * // Generate a URL that allows temporary access to list files in a bucket.
   * //-
   * const request = require('request');
   *
   * const config = {
   *   action: 'list',
   *   expires: '03-17-2025'
   * };
   *
   * bucket.getSignedUrl(config, function(err, url) {
   *   if (err) {
   *     console.error(err);
   *     return;
   *   }
   *
   *   // The bucket is now available to be listed from this URL.
   *   request(url, function(err, resp) {
   *     // resp.statusCode = 200
   *   });
   * });
   *
   * //-
   * // If the callback is omitted, we'll return a Promise.
   * //-
   * bucket.getSignedUrl(config).then(function(data) {
   *   const url = data[0];
   * });
   * ```
   */
  getSignedUrl(e, t) {
    let n = {
      method: Bt[e.action],
      expires: e.expires,
      version: e.version,
      cname: e.cname,
      extensionHeaders: e.extensionHeaders || {},
      queryParams: e.queryParams || {},
      host: e.host,
      signingEndpoint: e.signingEndpoint
    };
    this.signer || (this.signer = new Re(this.storage.authClient, this, void 0, this.storage)), this.signer.getSignedUrl(n).then((s) => t(null, s), t);
  }
  /**
   * @callback BucketLockCallback
   * @param {?Error} err Request error, if any.
   * @param {object} apiResponse The full API response.
   */
  /**
   * Lock a previously-defined retention policy. This will prevent changes to
   * the policy.
   *
   * @throws {Error} if a metageneration is not provided.
   *
   * @param {number|string} metageneration The bucket's metageneration. This is
   *     accesssible from calling {@link File#getMetadata}.
   * @param {BucketLockCallback} [callback] Callback function.
   * @returns {Promise<BucketLockResponse>}
   *
   * @example
   * ```
   * const storage = require('@google-cloud/storage')();
   * const bucket = storage.bucket('albums');
   *
   * const metageneration = 2;
   *
   * bucket.lock(metageneration, function(err, apiResponse) {});
   *
   * //-
   * // If the callback is omitted, we'll return a Promise.
   * //-
   * bucket.lock(metageneration).then(function(data) {
   *   const apiResponse = data[0];
   * });
   * ```
   */
  lock(e, t) {
    let i = typeof e;
    if (i !== "number" && i !== "string")
      throw new Error(K.METAGENERATION_NOT_PROVIDED);
    this.request({
      method: "POST",
      uri: "/lockRetentionPolicy",
      qs: {
        ifMetagenerationMatch: e
      }
    }, t);
  }
  /**
   * @typedef {object} RestoreOptions Options for Bucket#restore(). See an
   *     {@link https://cloud.google.com/storage/docs/json_api/v1/buckets/restore#resource| Object resource}.
   * @param {number} [generation] If present, selects a specific revision of this object.
   * @param {string} [projection] Specifies the set of properties to return. If used, must be 'full' or 'noAcl'.
   */
  /**
   * Restores a soft-deleted bucket
   * @param {RestoreOptions} options Restore options.
   * @returns {Promise<Bucket>}
   */
  async restore(e) {
    let [t] = await this.request({
      method: "POST",
      uri: "/restore",
      qs: e
    });
    return t;
  }
  /**
   * @typedef {array} MakeBucketPrivateResponse
   * @property {File[]} 0 List of files made private.
   */
  /**
   * @callback MakeBucketPrivateCallback
   * @param {?Error} err Request error, if any.
   * @param {File[]} files List of files made private.
   */
  /**
   * @typedef {object} MakeBucketPrivateOptions
   * @property {boolean} [includeFiles=false] Make each file in the bucket
   *     private.
   * @property {Metadata} [metadata] Define custom metadata properties to define
   *     along with the operation.
   * @property {boolean} [force] Queue errors occurred while making files
   *     private until all files have been processed.
   * @property {string} [userProject] The ID of the project which will be
   *     billed for the request.
   */
  /**
   * Make the bucket listing private.
   *
   * You may also choose to make the contents of the bucket private by
   * specifying `includeFiles: true`. This will automatically run
   * {@link File#makePrivate} for every file in the bucket.
   *
   * When specifying `includeFiles: true`, use `force: true` to delay execution
   * of your callback until all files have been processed. By default, the
   * callback is executed after the first error. Use `force` to queue such
   * errors until all files have been processed, after which they will be
   * returned as an array as the first argument to your callback.
   *
   * NOTE: This may cause the process to be long-running and use a high number
   * of requests. Use with caution.
   *
   * See {@link https://cloud.google.com/storage/docs/json_api/v1/buckets/patch| Buckets: patch API Documentation}
   *
   * @param {MakeBucketPrivateOptions} [options] Configuration options.
   * @param {boolean} [options.includeFiles=false] Make each file in the bucket
   *     private.
   * @param {Metadata} [options.metadata] Define custom metadata properties to define
   *     along with the operation.
   * @param {boolean} [options.force] Queue errors occurred while making files
   *     private until all files have been processed.
   * @param {string} [options.userProject] The ID of the project which will be
   *     billed for the request.
   * @param {MakeBucketPrivateCallback} [callback] Callback function.
   * @returns {Promise<MakeBucketPrivateResponse>}
   *
   * @example
   * ```
   * const {Storage} = require('@google-cloud/storage');
   * const storage = new Storage();
   * const bucket = storage.bucket('albums');
   *
   * //-
   * // Make the bucket private.
   * //-
   * bucket.makePrivate(function(err) {});
   *
   * //-
   * // Make the bucket and its contents private.
   * //-
   * const opts = {
   *   includeFiles: true
   * };
   *
   * bucket.makePrivate(opts, function(err, files) {
   *   // `err`:
   *   //    The first error to occur, otherwise null.
   *   //
   *   // `files`:
   *   //    Array of files successfully made private in the bucket.
   * });
   *
   * //-
   * // Make the bucket and its contents private, using force to suppress errors
   * // until all files have been processed.
   * //-
   * const opts = {
   *   includeFiles: true,
   *   force: true
   * };
   *
   * bucket.makePrivate(opts, function(errors, files) {
   *   // `errors`:
   *   //    Array of errors if any occurred, otherwise null.
   *   //
   *   // `files`:
   *   //    Array of files successfully made private in the bucket.
   * });
   *
   * //-
   * // If the callback is omitted, we'll return a Promise.
   * //-
   * bucket.makePrivate(opts).then(function(data) {
   *   const files = data[0];
   * });
   * ```
   */
  makePrivate(e, t) {
    var i, n, s, c;
    let a = typeof e == "object" ? e : {};
    t = typeof e == "function" ? e : t, a.private = !0;
    let o = {
      predefinedAcl: "projectPrivate"
    };
    a.userProject && (o.userProject = a.userProject), !((i = a.preconditionOpts) === null || i === void 0) && i.ifGenerationMatch && (o.ifGenerationMatch = a.preconditionOpts.ifGenerationMatch), !((n = a.preconditionOpts) === null || n === void 0) && n.ifGenerationNotMatch && (o.ifGenerationNotMatch = a.preconditionOpts.ifGenerationNotMatch), !((s = a.preconditionOpts) === null || s === void 0) && s.ifMetagenerationMatch && (o.ifMetagenerationMatch = a.preconditionOpts.ifMetagenerationMatch), !((c = a.preconditionOpts) === null || c === void 0) && c.ifMetagenerationNotMatch && (o.ifMetagenerationNotMatch = a.preconditionOpts.ifMetagenerationNotMatch);
    let l = { ...a.metadata, acl: null };
    this.setMetadata(l, o, (p) => {
      p && t(p), (/* @__PURE__ */ d(() => a.includeFiles ? sr(this.makeAllFilesPublicPrivate_).call(this, a) : Promise.resolve([]), "internalCall"))().then((f) => t(null, f)).catch(t);
    });
  }
  /**
   * @typedef {object} MakeBucketPublicOptions
   * @property {boolean} [includeFiles=false] Make each file in the bucket
   *     private.
   * @property {boolean} [force] Queue errors occurred while making files
   *     private until all files have been processed.
   */
  /**
   * @callback MakeBucketPublicCallback
   * @param {?Error} err Request error, if any.
   * @param {File[]} files List of files made public.
   */
  /**
   * @typedef {array} MakeBucketPublicResponse
   * @property {File[]} 0 List of files made public.
   */
  /**
   * Make the bucket publicly readable.
   *
   * You may also choose to make the contents of the bucket publicly readable by
   * specifying `includeFiles: true`. This will automatically run
   * {@link File#makePublic} for every file in the bucket.
   *
   * When specifying `includeFiles: true`, use `force: true` to delay execution
   * of your callback until all files have been processed. By default, the
   * callback is executed after the first error. Use `force` to queue such
   * errors until all files have been processed, after which they will be
   * returned as an array as the first argument to your callback.
   *
   * NOTE: This may cause the process to be long-running and use a high number
   * of requests. Use with caution.
   *
   * See {@link https://cloud.google.com/storage/docs/json_api/v1/buckets/patch| Buckets: patch API Documentation}
   *
   * @param {MakeBucketPublicOptions} [options] Configuration options.
   * @param {boolean} [options.includeFiles=false] Make each file in the bucket
   *     private.
   * @param {boolean} [options.force] Queue errors occurred while making files
   *     private until all files have been processed.
   * @param {MakeBucketPublicCallback} [callback] Callback function.
   * @returns {Promise<MakeBucketPublicResponse>}
   *
   * @example
   * ```
   * const {Storage} = require('@google-cloud/storage');
   * const storage = new Storage();
   * const bucket = storage.bucket('albums');
   *
   * //-
   * // Make the bucket publicly readable.
   * //-
   * bucket.makePublic(function(err) {});
   *
   * //-
   * // Make the bucket and its contents publicly readable.
   * //-
   * const opts = {
   *   includeFiles: true
   * };
   *
   * bucket.makePublic(opts, function(err, files) {
   *   // `err`:
   *   //    The first error to occur, otherwise null.
   *   //
   *   // `files`:
   *   //    Array of files successfully made public in the bucket.
   * });
   *
   * //-
   * // Make the bucket and its contents publicly readable, using force to
   * // suppress errors until all files have been processed.
   * //-
   * const opts = {
   *   includeFiles: true,
   *   force: true
   * };
   *
   * bucket.makePublic(opts, function(errors, files) {
   *   // `errors`:
   *   //    Array of errors if any occurred, otherwise null.
   *   //
   *   // `files`:
   *   //    Array of files successfully made public in the bucket.
   * });
   *
   * //-
   * // If the callback is omitted, we'll return a Promise.
   * //-
   * bucket.makePublic(opts).then(function(data) {
   *   const files = data[0];
   * });
   * ```
   */
  makePublic(e, t) {
    let i = typeof e == "object" ? e : {};
    t = typeof e == "function" ? e : t;
    let n = { public: !0, ...i };
    this.acl.add({
      entity: "allUsers",
      role: "READER"
    }).then(() => this.acl.default.add({
      entity: "allUsers",
      role: "READER"
    })).then(() => n.includeFiles ? sr(this.makeAllFilesPublicPrivate_).call(this, n) : []).then((s) => t(null, s), t);
  }
  /**
   * Get a reference to a Cloud Pub/Sub Notification.
   *
   * @param {string} id ID of notification.
   * @returns {Notification}
   * @see Notification
   *
   * @example
   * ```
   * const {Storage} = require('@google-cloud/storage');
   * const storage = new Storage();
   * const bucket = storage.bucket('my-bucket');
   * const notification = bucket.notification('1');
   * ```
   */
  notification(e) {
    if (!e)
      throw new Error(K.SUPPLY_NOTIFICATION_ID);
    return new Ie(this, e);
  }
  /**
   * Remove an already-existing retention policy from this bucket, if it is not
   * locked.
   *
   * @param {SetBucketMetadataCallback} [callback] Callback function.
   * @param {SetBucketMetadataOptions} [options] Options, including precondition options
   * @returns {Promise<SetBucketMetadataResponse>}
   *
   * @example
   * ```
   * const storage = require('@google-cloud/storage')();
   * const bucket = storage.bucket('albums');
   *
   * bucket.removeRetentionPeriod(function(err, apiResponse) {});
   *
   * //-
   * // If the callback is omitted, we'll return a Promise.
   * //-
   * bucket.removeRetentionPeriod().then(function(data) {
   *   const apiResponse = data[0];
   * });
   * ```
   */
  removeRetentionPeriod(e, t) {
    let i = typeof e == "object" ? e : {};
    t = typeof e == "function" ? e : t, this.setMetadata({
      retentionPolicy: null
    }, i, t);
  }
  /**
   * Makes request and applies userProject query parameter if necessary.
   *
   * @private
   *
   * @param {object} reqOpts - The request options.
   * @param {function} callback - The callback function.
   */
  request(e, t) {
    return this.userProject && (!e.qs || !e.qs.userProject) && (e.qs = { ...e.qs, userProject: this.userProject }), super.request(e, t);
  }
  /**
   * @deprecated
   * @typedef {array} SetLabelsResponse
   * @property {object} 0 The bucket metadata.
   */
  /**
   * @deprecated
   * @callback SetLabelsCallback
   * @param {?Error} err Request error, if any.
   * @param {object} metadata The bucket metadata.
   */
  /**
   * @deprecated
   * @typedef {object} SetLabelsOptions Configuration options for Bucket#setLabels().
   * @property {string} [userProject] The ID of the project which will be
   *     billed for the request.
   */
  /**
   * @deprecated Use setMetadata directly.
   * Set labels on the bucket.
   *
   * This makes an underlying call to {@link Bucket#setMetadata}, which
   * is a PATCH request. This means an individual label can be overwritten, but
   * unmentioned labels will not be touched.
   *
   * @param {object<string, string>} labels Labels to set on the bucket.
   * @param {SetLabelsOptions} [options] Configuration options.
   * @param {string} [options.userProject] The ID of the project which will be
   *     billed for the request.
   * @param {SetLabelsCallback} [callback] Callback function.
   * @returns {Promise<SetLabelsResponse>}
   *
   * @example
   * ```
   * const {Storage} = require('@google-cloud/storage');
   * const storage = new Storage();
   * const bucket = storage.bucket('albums');
   *
   * const labels = {
   *   labelone: 'labelonevalue',
   *   labeltwo: 'labeltwovalue'
   * };
   *
   * bucket.setLabels(labels, function(err, metadata) {
   *   if (!err) {
   *     // Labels set successfully.
   *   }
   * });
   *
   * //-
   * // If the callback is omitted, we'll return a Promise.
   * //-
   * bucket.setLabels(labels).then(function(data) {
   *   const metadata = data[0];
   * });
   * ```
   */
  setLabels(e, t, i) {
    let n = typeof t == "object" ? t : {};
    i = typeof t == "function" ? t : i, i = i || b.noop, this.setMetadata({ labels: e }, n, i);
  }
  setMetadata(e, t, i) {
    let n = typeof t == "object" ? t : {};
    i = typeof t == "function" ? t : i, this.disableAutoRetryConditionallyIdempotent_(this.methods.setMetadata, G.setMetadata, n), super.setMetadata(e, n).then((s) => i(null, ...s)).catch(i).finally(() => {
      this.storage.retryOptions.autoRetry = this.instanceRetryValue;
    });
  }
  /**
   * Lock all objects contained in the bucket, based on their creation time. Any
   * attempt to overwrite or delete objects younger than the retention period
   * will result in a `PERMISSION_DENIED` error.
   *
   * An unlocked retention policy can be modified or removed from the bucket via
   * {@link File#removeRetentionPeriod} and {@link File#setRetentionPeriod}. A
   * locked retention policy cannot be removed or shortened in duration for the
   * lifetime of the bucket. Attempting to remove or decrease period of a locked
   * retention policy will result in a `PERMISSION_DENIED` error. You can still
   * increase the policy.
   *
   * @param {*} duration In seconds, the minimum retention time for all objects
   *     contained in this bucket.
   * @param {SetBucketMetadataCallback} [callback] Callback function.
   * @param {SetBucketMetadataCallback} [options] Options, including precondition options.
   * @returns {Promise<SetBucketMetadataResponse>}
   *
   * @example
   * ```
   * const storage = require('@google-cloud/storage')();
   * const bucket = storage.bucket('albums');
   *
   * const DURATION_SECONDS = 15780000; // 6 months.
   *
   * //-
   * // Lock the objects in this bucket for 6 months.
   * //-
   * bucket.setRetentionPeriod(DURATION_SECONDS, function(err, apiResponse) {});
   *
   * //-
   * // If the callback is omitted, we'll return a Promise.
   * //-
   * bucket.setRetentionPeriod(DURATION_SECONDS).then(function(data) {
   *   const apiResponse = data[0];
   * });
   * ```
   */
  setRetentionPeriod(e, t, i) {
    let n = typeof t == "object" ? t : {};
    i = typeof t == "function" ? t : i, this.setMetadata({
      retentionPolicy: {
        retentionPeriod: e.toString()
      }
    }, n, i);
  }
  /**
   *
   * @typedef {object} Cors
   * @property {number} [maxAgeSeconds] The number of seconds the browser is
   *     allowed to make requests before it must repeat the preflight request.
   * @property {string[]} [method] HTTP method allowed for cross origin resource
   *     sharing with this bucket.
   * @property {string[]} [origin] an origin allowed for cross origin resource
   *     sharing with this bucket.
   * @property {string[]} [responseHeader] A header allowed for cross origin
   *     resource sharing with this bucket.
   */
  /**
   * This can be used to set the CORS configuration on the bucket.
   *
   * The configuration will be overwritten with the value passed into this.
   *
   * @param {Cors[]} corsConfiguration The new CORS configuration to set
   * @param {number} [corsConfiguration.maxAgeSeconds] The number of seconds the browser is
   *     allowed to make requests before it must repeat the preflight request.
   * @param {string[]} [corsConfiguration.method] HTTP method allowed for cross origin resource
   *     sharing with this bucket.
   * @param {string[]} [corsConfiguration.origin] an origin allowed for cross origin resource
   *     sharing with this bucket.
   * @param {string[]} [corsConfiguration.responseHeader] A header allowed for cross origin
   *     resource sharing with this bucket.
   * @param {SetBucketMetadataCallback} [callback] Callback function.
   * @param {SetBucketMetadataOptions} [options] Options, including precondition options.
   * @returns {Promise<SetBucketMetadataResponse>}
   *
   * @example
   * ```
   * const storage = require('@google-cloud/storage')();
   * const bucket = storage.bucket('albums');
   *
   * const corsConfiguration = [{maxAgeSeconds: 3600}]; // 1 hour
   * bucket.setCorsConfiguration(corsConfiguration);
   *
   * //-
   * // If the callback is omitted, we'll return a Promise.
   * //-
   * bucket.setCorsConfiguration(corsConfiguration).then(function(data) {
   *   const apiResponse = data[0];
   * });
   * ```
   */
  setCorsConfiguration(e, t, i) {
    let n = typeof t == "object" ? t : {};
    i = typeof t == "function" ? t : i, this.setMetadata({
      cors: e
    }, n, i);
  }
  /**
   * @typedef {object} SetBucketStorageClassOptions
   * @property {string} [userProject] - The ID of the project which will be
   *     billed for the request.
   */
  /**
   * @callback SetBucketStorageClassCallback
   * @param {?Error} err Request error, if any.
   */
  /**
   * Set the default storage class for new files in this bucket.
   *
   * See {@link https://cloud.google.com/storage/docs/storage-classes| Storage Classes}
   *
   * @param {string} storageClass The new storage class. (`standard`,
   *     `nearline`, `coldline`, or `archive`).
   *     **Note:** The storage classes `multi_regional`, `regional`, and
   *     `durable_reduced_availability` are now legacy and will be deprecated in
   *     the future.
   * @param {object} [options] Configuration options.
   * @param {string} [options.userProject] - The ID of the project which will be
   *     billed for the request.
   * @param {SetStorageClassCallback} [callback] Callback function.
   * @returns {Promise}
   *
   * @example
   * ```
   * const {Storage} = require('@google-cloud/storage');
   * const storage = new Storage();
   * const bucket = storage.bucket('albums');
   *
   * bucket.setStorageClass('nearline', function(err, apiResponse) {
   *   if (err) {
   *     // Error handling omitted.
   *   }
   *
   *   // The storage class was updated successfully.
   * });
   *
   * //-
   * // If the callback is omitted, we'll return a Promise.
   * //-
   * bucket.setStorageClass('nearline').then(function() {});
   * ```
   */
  setStorageClass(e, t, i) {
    let n = typeof t == "object" ? t : {};
    i = typeof t == "function" ? t : i, e = e.replace(/-/g, "_").replace(/([a-z])([A-Z])/g, (s, c, a) => c + "_" + a).toUpperCase(), this.setMetadata({ storageClass: e }, n, i);
  }
  /**
   * Set a user project to be billed for all requests made from this Bucket
   * object and any files referenced from this Bucket object.
   *
   * @param {string} userProject The user project.
   *
   * @example
   * ```
   * const {Storage} = require('@google-cloud/storage');
   * const storage = new Storage();
   * const bucket = storage.bucket('albums');
   *
   * bucket.setUserProject('grape-spaceship-123');
   * ```
   */
  setUserProject(e) {
    this.userProject = e, [
      "create",
      "delete",
      "exists",
      "get",
      "getMetadata",
      "setMetadata"
    ].forEach((i) => {
      let n = this.methods[i];
      typeof n == "object" && (typeof n.reqOpts == "object" ? Object.assign(n.reqOpts.qs, { userProject: e }) : n.reqOpts = {
        qs: { userProject: e }
      });
    });
  }
  /**
   * @typedef {object} UploadOptions Configuration options for Bucket#upload().
   * @property {string|File} [destination] The place to save
   *     your file. If given a string, the file will be uploaded to the bucket
   *     using the string as a filename. When given a File object, your local
   * file will be uploaded to the File object's bucket and under the File
   * object's name. Lastly, when this argument is omitted, the file is uploaded
   * to your bucket using the name of the local file.
   * @property {string} [encryptionKey] A custom encryption key. See
   *     {@link https://cloud.google.com/storage/docs/encryption#customer-supplied| Customer-supplied Encryption Keys}.
   * @property {boolean} [gzip] Automatically gzip the file. This will set
   *     `options.metadata.contentEncoding` to `gzip`.
   * @property {string} [kmsKeyName] The name of the Cloud KMS key that will
   *     be used to encrypt the object. Must be in the format:
   *     `projects/my-project/locations/location/keyRings/my-kr/cryptoKeys/my-key`.
   * @property {object} [metadata] See an
   *     {@link https://cloud.google.com/storage/docs/json_api/v1/objects/insert#request_properties_JSON| Objects: insert request body}.
   * @property {string} [offset] The starting byte of the upload stream, for
   *     resuming an interrupted upload. Defaults to 0.
   * @property {string} [predefinedAcl] Apply a predefined set of access
   * controls to this object.
   *
   * Acceptable values are:
   * - **`authenticatedRead`** - Object owner gets `OWNER` access, and
   *       `allAuthenticatedUsers` get `READER` access.
   *
   * - **`bucketOwnerFullControl`** - Object owner gets `OWNER` access, and
   *       project team owners get `OWNER` access.
   *
   * - **`bucketOwnerRead`** - Object owner gets `OWNER` access, and project
   *       team owners get `READER` access.
   *
   * - **`private`** - Object owner gets `OWNER` access.
   *
   * - **`projectPrivate`** - Object owner gets `OWNER` access, and project
   *       team members get access according to their roles.
   *
   * - **`publicRead`** - Object owner gets `OWNER` access, and `allUsers`
   *       get `READER` access.
   * @property {boolean} [private] Make the uploaded file private. (Alias for
   *     `options.predefinedAcl = 'private'`)
   * @property {boolean} [public] Make the uploaded file public. (Alias for
   *     `options.predefinedAcl = 'publicRead'`)
   * @property {boolean} [resumable=true] Resumable uploads are automatically
   *     enabled and must be shut off explicitly by setting to false.
   * @property {number} [timeout=60000] Set the HTTP request timeout in
   *     milliseconds. This option is not available for resumable uploads.
   *     Default: `60000`
   * @property {string} [uri] The URI for an already-created resumable
   *     upload. See {@link File#createResumableUpload}.
   * @property {string} [userProject] The ID of the project which will be
   *     billed for the request.
   * @property {string|boolean} [validation] Possible values: `"md5"`,
   *     `"crc32c"`, or `false`. By default, data integrity is validated with an
   *     MD5 checksum for maximum reliability. CRC32c will provide better
   *     performance with less reliability. You may also choose to skip
   * validation completely, however this is **not recommended**.
   */
  /**
   * @typedef {array} UploadResponse
   * @property {object} 0 The uploaded {@link File}.
   * @property {object} 1 The full API response.
   */
  /**
   * @callback UploadCallback
   * @param {?Error} err Request error, if any.
   * @param {object} file The uploaded {@link File}.
   * @param {object} apiResponse The full API response.
   */
  /**
   * Upload a file to the bucket. This is a convenience method that wraps
   * {@link File#createWriteStream}.
   *
   * Resumable uploads are enabled by default
   *
   * See {@link https://cloud.google.com/storage/docs/json_api/v1/how-tos/upload#uploads| Upload Options (Simple or Resumable)}
   * See {@link https://cloud.google.com/storage/docs/json_api/v1/objects/insert| Objects: insert API Documentation}
   *
   * @param {string} pathString The fully qualified path to the file you
   *     wish to upload to your bucket.
   * @param {UploadOptions} [options] Configuration options.
   * @param {string|File} [options.destination] The place to save
   *     your file. If given a string, the file will be uploaded to the bucket
   *     using the string as a filename. When given a File object, your local
   * file will be uploaded to the File object's bucket and under the File
   * object's name. Lastly, when this argument is omitted, the file is uploaded
   * to your bucket using the name of the local file.
   * @param {string} [options.encryptionKey] A custom encryption key. See
   *     {@link https://cloud.google.com/storage/docs/encryption#customer-supplied| Customer-supplied Encryption Keys}.
   * @param {boolean} [options.gzip] Automatically gzip the file. This will set
   *     `options.metadata.contentEncoding` to `gzip`.
   * @param {string} [options.kmsKeyName] The name of the Cloud KMS key that will
   *     be used to encrypt the object. Must be in the format:
   *     `projects/my-project/locations/location/keyRings/my-kr/cryptoKeys/my-key`.
   * @param {object} [options.metadata] See an
   *     {@link https://cloud.google.com/storage/docs/json_api/v1/objects/insert#request_properties_JSON| Objects: insert request body}.
   * @param {string} [options.offset] The starting byte of the upload stream, for
   *     resuming an interrupted upload. Defaults to 0.
   * @param {string} [options.predefinedAcl] Apply a predefined set of access
   * controls to this object.
   * Acceptable values are:
   * - **`authenticatedRead`** - Object owner gets `OWNER` access, and
   *   `allAuthenticatedUsers` get `READER` access.
   *
   * - **`bucketOwnerFullControl`** - Object owner gets `OWNER` access, and
   *   project team owners get `OWNER` access.
   *
   * - **`bucketOwnerRead`** - Object owner gets `OWNER` access, and project
   *   team owners get `READER` access.
   *
   * - **`private`** - Object owner gets `OWNER` access.
   *
   * - **`projectPrivate`** - Object owner gets `OWNER` access, and project
   *   team members get access according to their roles.
   *
   * - **`publicRead`** - Object owner gets `OWNER` access, and `allUsers`
   *   get `READER` access.
   * @param {boolean} [options.private] Make the uploaded file private. (Alias for
   *     `options.predefinedAcl = 'private'`)
   * @param {boolean} [options.public] Make the uploaded file public. (Alias for
   *     `options.predefinedAcl = 'publicRead'`)
   * @param {boolean} [options.resumable=true] Resumable uploads are automatically
   *     enabled and must be shut off explicitly by setting to false.
   * @param {number} [options.timeout=60000] Set the HTTP request timeout in
   *     milliseconds. This option is not available for resumable uploads.
   *     Default: `60000`
   * @param {string} [options.uri] The URI for an already-created resumable
   *     upload. See {@link File#createResumableUpload}.
   * @param {string} [options.userProject] The ID of the project which will be
   *     billed for the request.
   * @param {string|boolean} [options.validation] Possible values: `"md5"`,
   *     `"crc32c"`, or `false`. By default, data integrity is validated with an
   *     MD5 checksum for maximum reliability. CRC32c will provide better
   *     performance with less reliability. You may also choose to skip
   * validation completely, however this is **not recommended**.
   * @param {UploadCallback} [callback] Callback function.
   * @returns {Promise<UploadResponse>}
   *
   * @example
   * ```
   * const {Storage} = require('@google-cloud/storage');
   * const storage = new Storage();
   * const bucket = storage.bucket('albums');
   *
   * //-
   * // Upload a file from a local path.
   * //-
   * bucket.upload('/local/path/image.png', function(err, file, apiResponse) {
   *   // Your bucket now contains:
   *   // - "image.png" (with the contents of `/local/path/image.png')
   *
   *   // `file` is an instance of a File object that refers to your new file.
   * });
   *
   *
   * //-
   * // It's not always that easy. You will likely want to specify the filename
   * // used when your new file lands in your bucket.
   * //
   * // You may also want to set metadata or customize other options.
   * //-
   * const options = {
   *   destination: 'new-image.png',
   *   validation: 'crc32c',
   *   metadata: {
   *     metadata: {
   *       event: 'Fall trip to the zoo'
   *     }
   *   }
   * };
   *
   * bucket.upload('local-image.png', options, function(err, file) {
   *   // Your bucket now contains:
   *   // - "new-image.png" (with the contents of `local-image.png')
   *
   *   // `file` is an instance of a File object that refers to your new file.
   * });
   *
   * //-
   * // You can also have a file gzip'd on the fly.
   * //-
   * bucket.upload('index.html', { gzip: true }, function(err, file) {
   *   // Your bucket now contains:
   *   // - "index.html" (automatically compressed with gzip)
   *
   *   // Downloading the file with `file.download` will automatically decode
   * the
   *   // file.
   * });
   *
   * //-
   * // You may also re-use a File object, {File}, that references
   * // the file you wish to create or overwrite.
   * //-
   * const options = {
   *   destination: bucket.file('existing-file.png'),
   *   resumable: false
   * };
   *
   * bucket.upload('local-img.png', options, function(err, newFile) {
   *   // Your bucket now contains:
   *   // - "existing-file.png" (with the contents of `local-img.png')
   *
   *   // Note:
   *   // The `newFile` parameter is equal to `file`.
   * });
   *
   * //-
   * // To use
   * // <a
   * href="https://cloud.google.com/storage/docs/encryption#customer-supplied">
   * // Customer-supplied Encryption Keys</a>, provide the `encryptionKey`
   * option.
   * //-
   * const crypto = require('crypto');
   * const encryptionKey = crypto.randomBytes(32);
   *
   * bucket.upload('img.png', {
   *   encryptionKey: encryptionKey
   * }, function(err, newFile) {
   *   // `img.png` was uploaded with your custom encryption key.
   *
   *   // `newFile` is already configured to use the encryption key when making
   *   // operations on the remote object.
   *
   *   // However, to use your encryption key later, you must create a `File`
   *   // instance with the `key` supplied:
   *   const file = bucket.file('img.png', {
   *     encryptionKey: encryptionKey
   *   });
   *
   *   // Or with `file#setEncryptionKey`:
   *   const file = bucket.file('img.png');
   *   file.setEncryptionKey(encryptionKey);
   * });
   *
   * //-
   * // If the callback is omitted, we'll return a Promise.
   * //-
   * bucket.upload('local-image.png').then(function(data) {
   *   const file = data[0];
   * });
   *
   * To upload a file from a URL, use {@link File#createWriteStream}.
   *
   * ```
   * @example <caption>include:samples/files.js</caption>
   * region_tag:storage_upload_file
   * Another example:
   *
   * @example <caption>include:samples/encryption.js</caption>
   * region_tag:storage_upload_encrypted_file
   * Example of uploading an encrypted file:
   */
  upload(e, t, i) {
    var n, s;
    let c = /* @__PURE__ */ d((p) => {
      let u = (0, pr.default)(async (f) => {
        await new Promise((m, h) => {
          var g, y;
          p === 0 && (!((y = (g = l?.storage) === null || g === void 0 ? void 0 : g.retryOptions) === null || y === void 0) && y.autoRetry) && (l.storage.retryOptions.autoRetry = !1);
          let x = l.createWriteStream(a);
          a.onUploadProgress && x.on("progress", a.onUploadProgress), or.createReadStream(e).on("error", f).pipe(x).on("error", (w) => this.storage.retryOptions.autoRetry && this.storage.retryOptions.retryableErrorFn(w) ? h(w) : f(w)).on("finish", () => m());
        });
      }, {
        retries: p,
        factor: this.storage.retryOptions.retryDelayMultiplier,
        maxTimeout: this.storage.retryOptions.maxRetryDelay * 1e3,
        //convert to milliseconds
        maxRetryTime: this.storage.retryOptions.totalTimeout * 1e3
        //convert to milliseconds
      });
      return i ? u.then(() => {
        if (i)
          return i(null, l, l.metadata);
      }).catch(i) : u;
    }, "upload");
    if (global.GCLOUD_SANDBOX_ENV)
      return;
    let a = typeof t == "object" ? t : {};
    i = typeof t == "function" ? t : i, a = Object.assign({
      metadata: {}
    }, a);
    let o = this.storage.retryOptions.maxRetries;
    (((n = a?.preconditionOpts) === null || n === void 0 ? void 0 : n.ifGenerationMatch) === void 0 && ((s = this.instancePreconditionOpts) === null || s === void 0 ? void 0 : s.ifGenerationMatch) === void 0 && this.storage.retryOptions.idempotencyStrategy === _.RetryConditional || this.storage.retryOptions.idempotencyStrategy === _.RetryNever) && (o = 0);
    let l;
    if (a.destination instanceof H)
      l = a.destination;
    else if (a.destination !== null && typeof a.destination == "string")
      l = this.file(a.destination, {
        encryptionKey: a.encryptionKey,
        kmsKeyName: a.kmsKeyName,
        preconditionOpts: this.instancePreconditionOpts
      });
    else {
      let p = lr.basename(e);
      l = this.file(p, {
        encryptionKey: a.encryptionKey,
        kmsKeyName: a.kmsKeyName,
        preconditionOpts: this.instancePreconditionOpts
      });
    }
    c(o);
  }
  /**
   * @private
   *
   * @typedef {object} MakeAllFilesPublicPrivateOptions
   * @property {boolean} [force] Suppress errors until all files have been
   *     processed.
   * @property {boolean} [private] Make files private.
   * @property {boolean} [public] Make files public.
   * @property {string} [userProject] The ID of the project which will be
   *     billed for the request.
   */
  /**
   * @private
   *
   * @callback SetBucketMetadataCallback
   * @param {?Error} err Request error, if any.
   * @param {File[]} files Files that were updated.
   */
  /**
   * @typedef {array} MakeAllFilesPublicPrivateResponse
   * @property {File[]} 0 List of files affected.
   */
  /**
     * Iterate over all of a bucket's files, calling `file.makePublic()` (public)
     * or `file.makePrivate()` (private) on each.
     *
     * Operations are performed in parallel, up to 10 at once. The first error
     * breaks the loop, and will execute the provided callback with it. Specify
     * `{ force: true }` to suppress the errors.
     *
     * @private
     *
     * @param {MakeAllFilesPublicPrivateOptions} [options] Configuration options.
     * @param {boolean} [options.force] Suppress errors until all files have been
     *     processed.
     * @param {boolean} [options.private] Make files private.
     * @param {boolean} [options.public] Make files public.
     * @param {string} [options.userProject] The ID of the project which will be
     *     billed for the request.
  
     * @param {MakeAllFilesPublicPrivateCallback} callback Callback function.
     *
     * @return {Promise<MakeAllFilesPublicPrivateResponse>}
     */
  makeAllFilesPublicPrivate_(e, t) {
    let n = [], s = [], c = typeof e == "object" ? e : {};
    t = typeof e == "function" ? e : t;
    let a = /* @__PURE__ */ d(async (o) => {
      try {
        await (c.public ? o.makePublic() : o.makePrivate(c)), s.push(o);
      } catch (l) {
        if (!c.force)
          throw l;
        n.push(l);
      }
    }, "processFile");
    this.getFiles(c).then(([o]) => {
      let l = (0, Ft.default)(10), p = o.map((u) => l(() => a(u)));
      return Promise.all(p);
    }).then(() => t(n.length > 0 ? n : null, s), (o) => t(o, s));
  }
  getId() {
    return this.id;
  }
  disableAutoRetryConditionallyIdempotent_(e, t, i) {
    var n, s;
    typeof e == "object" && ((s = (n = e?.reqOpts) === null || n === void 0 ? void 0 : n.qs) === null || s === void 0 ? void 0 : s.ifMetagenerationMatch) === void 0 && i?.ifMetagenerationMatch === void 0 && (t === G.setMetadata || t === G.delete) && this.storage.retryOptions.idempotencyStrategy === _.RetryConditional ? this.storage.retryOptions.autoRetry = !1 : this.storage.retryOptions.idempotencyStrategy === _.RetryNever && (this.storage.retryOptions.autoRetry = !1);
  }
};
Gt.paginator.extend(F, "getFiles");
(0, ar.promisifyAll)(F, {
  exclude: ["cloudStorageURI", "request", "file", "notification", "restore"]
});

// node_modules/@google-cloud/storage/build/esm/src/channel.js
var dr = v(W(), 1);
var he = class extends O {
  static {
    d(this, "Channel");
  }
  constructor(e, t, i) {
    let n = {
      parent: e,
      baseUrl: "/channels",
      // An ID shouldn't be included in the API requests.
      // RE:
      // https://github.com/GoogleCloudPlatform/google-cloud-node/issues/1145
      id: "",
      methods: {
        // Only need `request`.
      }
    };
    super(n), this.metadata.id = t, this.metadata.resourceId = i;
  }
  /**
   * @typedef {array} StopResponse
   * @property {object} 0 The full API response.
   */
  /**
   * @callback StopCallback
   * @param {?Error} err Request error, if any.
   * @param {object} apiResponse The full API response.
   */
  /**
   * Stop this channel.
   *
   * @param {StopCallback} [callback] Callback function.
   * @returns {Promise<StopResponse>}
   *
   * @example
   * ```
   * const {Storage} = require('@google-cloud/storage');
   * const storage = new Storage();
   * const channel = storage.channel('id', 'resource-id');
   * channel.stop(function(err, apiResponse) {
   *   if (!err) {
   *     // Channel stopped successfully.
   *   }
   * });
   *
   * //-
   * // If the callback is omitted, we'll return a Promise.
   * //-
   * channel.stop().then(function(data) {
   *   const apiResponse = data[0];
   * });
   * ```
   */
  stop(e) {
    e = e || b.noop, this.request({
      method: "POST",
      uri: "/stop",
      json: this.metadata
    }, (t, i) => {
      e(t, i);
    });
  }
};
(0, dr.promisifyAll)(he);

// node_modules/@google-cloud/storage/build/esm/src/storage.js
var hr = v(Ee(), 1);

// node_modules/@google-cloud/storage/build/esm/src/hmacKey.js
var ur = v(W(), 1);
var ge = class extends O {
  static {
    d(this, "HmacKey");
  }
  /**
   * @typedef {object} HmacKeyOptions
   * @property {string} [projectId] The project ID of the project that owns
   *     the service account of the requested HMAC key. If not provided,
   *     the project ID used to instantiate the Storage client will be used.
   */
  /**
   * Constructs an HmacKey object.
   *
   * Note: this only create a local reference to an HMAC key, to create
   * an HMAC key, use {@link Storage#createHmacKey}.
   *
   * @param {Storage} storage The Storage instance this HMAC key is
   *     attached to.
   * @param {string} accessId The unique accessId for this HMAC key.
   * @param {HmacKeyOptions} options Constructor configurations.
   * @example
   * ```
   * const {Storage} = require('@google-cloud/storage');
   * const storage = new Storage();
   * const hmacKey = storage.hmacKey('access-id');
   * ```
   */
  constructor(e, t, i) {
    let n = {
      /**
       * @typedef {object} DeleteHmacKeyOptions
       * @property {string} [userProject] This parameter is currently ignored.
       */
      /**
       * @typedef {array} DeleteHmacKeyResponse
       * @property {object} 0 The full API response.
       */
      /**
       * @callback DeleteHmacKeyCallback
       * @param {?Error} err Request error, if any.
       * @param {object} apiResponse The full API response.
       */
      /**
       * Deletes an HMAC key.
       * Key state must be set to `INACTIVE` prior to deletion.
       * Caution: HMAC keys cannot be recovered once you delete them.
       *
       * The authenticated user must have `storage.hmacKeys.delete` permission for the project in which the key exists.
       *
       * @method HmacKey#delete
       * @param {DeleteHmacKeyOptions} [options] Configuration options.
       * @param {DeleteHmacKeyCallback} [callback] Callback function.
       * @returns {Promise<DeleteHmacKeyResponse>}
       *
       * @example
       * ```
       * const {Storage} = require('@google-cloud/storage');
       * const storage = new Storage();
       *
       * //-
       * // Delete HMAC key after making the key inactive.
       * //-
       * const hmacKey = storage.hmacKey('ACCESS_ID');
       * hmacKey.setMetadata({state: 'INACTIVE'}, (err, hmacKeyMetadata) => {
       *     if (err) {
       *       // The request was an error.
       *       console.error(err);
       *       return;
       *     }
       *     hmacKey.delete((err) => {
       *       if (err) {
       *         console.error(err);
       *         return;
       *       }
       *       // The HMAC key is deleted.
       *     });
       *   });
       *
       * //-
       * // If the callback is omitted, a promise is returned.
       * //-
       * const hmacKey = storage.hmacKey('ACCESS_ID');
       * hmacKey
       *   .setMetadata({state: 'INACTIVE'})
       *   .then(() => {
       *     return hmacKey.delete();
       *   });
       * ```
       */
      delete: !0,
      /**
       * @callback GetHmacKeyCallback
       * @param {?Error} err Request error, if any.
       * @param {HmacKey} hmacKey this {@link HmacKey} instance.
       * @param {object} apiResponse The full API response.
       */
      /**
       * @typedef {array} GetHmacKeyResponse
       * @property {HmacKey} 0 This {@link HmacKey} instance.
       * @property {object} 1 The full API response.
       */
      /**
       * @typedef {object} GetHmacKeyOptions
       * @property {string} [userProject] This parameter is currently ignored.
       */
      /**
       * Retrieves and populate an HMAC key's metadata, and return
       * this {@link HmacKey} instance.
       *
       * HmacKey.get() does not give the HMAC key secret, as
       * it is only returned on creation.
       *
       * The authenticated user must have `storage.hmacKeys.get` permission
       * for the project in which the key exists.
       *
       * @method HmacKey#get
       * @param {GetHmacKeyOptions} [options] Configuration options.
       * @param {GetHmacKeyCallback} [callback] Callback function.
       * @returns {Promise<GetHmacKeyResponse>}
       *
       * @example
       * ```
       * const {Storage} = require('@google-cloud/storage');
       * const storage = new Storage();
       *
       * //-
       * // Get the HmacKey's Metadata.
       * //-
       * storage.hmacKey('ACCESS_ID')
       *   .get((err, hmacKey) => {
       *     if (err) {
       *       // The request was an error.
       *       console.error(err);
       *       return;
       *     }
       *     // do something with the returned HmacKey object.
       *   });
       *
       * //-
       * // If the callback is omitted, a promise is returned.
       * //-
       * storage.hmacKey('ACCESS_ID')
       *   .get()
       *   .then((data) => {
       *     const hmacKey = data[0];
       *   });
       * ```
       */
      get: !0,
      /**
       * @typedef {object} GetHmacKeyMetadataOptions
       * @property {string} [userProject] This parameter is currently ignored.
       */
      /**
       * Retrieves and populate an HMAC key's metadata, and return
       * the HMAC key's metadata as an object.
       *
       * HmacKey.getMetadata() does not give the HMAC key secret, as
       * it is only returned on creation.
       *
       * The authenticated user must have `storage.hmacKeys.get` permission
       * for the project in which the key exists.
       *
       * @method HmacKey#getMetadata
       * @param {GetHmacKeyMetadataOptions} [options] Configuration options.
       * @param {HmacKeyMetadataCallback} [callback] Callback function.
       * @returns {Promise<HmacKeyMetadataResponse>}
       *
       * @example
       * ```
       * const {Storage} = require('@google-cloud/storage');
       * const storage = new Storage();
       *
       * //-
       * // Get the HmacKey's metadata and populate to the metadata property.
       * //-
       * storage.hmacKey('ACCESS_ID')
       *   .getMetadata((err, hmacKeyMetadata) => {
       *     if (err) {
       *       // The request was an error.
       *       console.error(err);
       *       return;
       *     }
       *     console.log(hmacKeyMetadata);
       *   });
       *
       * //-
       * // If the callback is omitted, a promise is returned.
       * //-
       * storage.hmacKey('ACCESS_ID')
       *   .getMetadata()
       *   .then((data) => {
       *     const hmacKeyMetadata = data[0];
       *     console.log(hmacKeyMetadata);
       *   });
       * ```
       */
      getMetadata: !0,
      /**
       * @typedef {object} SetHmacKeyMetadata Subset of {@link HmacKeyMetadata} to update.
       * @property {string} state New state of the HmacKey. Either 'ACTIVE' or 'INACTIVE'.
       * @property {string} [etag] Include an etag from a previous get HMAC key request
       *    to perform safe read-modify-write.
       */
      /**
       * @typedef {object} SetHmacKeyMetadataOptions
       * @property {string} [userProject] This parameter is currently ignored.
       */
      /**
       * @callback HmacKeyMetadataCallback
       * @param {?Error} err Request error, if any.
       * @param {HmacKeyMetadata} metadata The updated {@link HmacKeyMetadata} object.
       * @param {object} apiResponse The full API response.
       */
      /**
       * @typedef {array} HmacKeyMetadataResponse
       * @property {HmacKeyMetadata} 0 The updated {@link HmacKeyMetadata} object.
       * @property {object} 1 The full API response.
       */
      /**
       * Updates the state of an HMAC key. See {@link SetHmacKeyMetadata} for
       * valid states.
       *
       * @method HmacKey#setMetadata
       * @param {SetHmacKeyMetadata} metadata The new metadata.
       * @param {SetHmacKeyMetadataOptions} [options] Configuration options.
       * @param {HmacKeyMetadataCallback} [callback] Callback function.
       * @returns {Promise<HmacKeyMetadataResponse>}
       *
       * @example
       * ```
       * const {Storage} = require('@google-cloud/storage');
       * const storage = new Storage();
       *
       * const metadata = {
       *   state: 'INACTIVE',
       * };
       *
       * storage.hmacKey('ACCESS_ID')
       *   .setMetadata(metadata, (err, hmacKeyMetadata) => {
       *     if (err) {
       *       // The request was an error.
       *       console.error(err);
       *       return;
       *     }
       *     console.log(hmacKeyMetadata);
       *   });
       *
       * //-
       * // If the callback is omitted, a promise is returned.
       * //-
       * storage.hmacKey('ACCESS_ID')
       *   .setMetadata(metadata)
       *   .then((data) => {
       *     const hmacKeyMetadata = data[0];
       *     console.log(hmacKeyMetadata);
       *   });
       * ```
       */
      setMetadata: {
        reqOpts: {
          method: "PUT"
        }
      }
    }, s = i && i.projectId || e.projectId;
    super({
      parent: e,
      id: t,
      baseUrl: `/projects/${s}/hmacKeys`,
      methods: n
    }), this.storage = e, this.instanceRetryValue = e.retryOptions.autoRetry;
  }
  setMetadata(e, t, i) {
    this.storage.retryOptions.idempotencyStrategy !== _.RetryAlways && (this.storage.retryOptions.autoRetry = !1);
    let n = typeof t == "object" ? t : {};
    i = typeof t == "function" ? t : i, super.setMetadata(e, n).then((s) => i(null, ...s)).catch(i).finally(() => {
      this.storage.retryOptions.autoRetry = this.instanceRetryValue;
    });
  }
};
(0, ur.promisifyAll)(ge);

// node_modules/@google-cloud/storage/build/esm/src/storage.js
var gr = v(Oe(), 1);
var _;
(function(r) {
  r[r.RetryAlways = 0] = "RetryAlways", r[r.RetryConditional = 1] = "RetryConditional", r[r.RetryNever = 2] = "RetryNever";
})(_ || (_ = {}));
var $;
(function(r) {
  r.EXPIRATION_DATE_INVALID = "The expiration date provided was invalid.", r.EXPIRATION_DATE_PAST = "An expiration date cannot be in the past.";
})($ || ($ = {}));
var Se;
(function(r) {
  r.BUCKET_NAME_REQUIRED = "A bucket name is needed to use Cloud Storage.", r.BUCKET_NAME_REQUIRED_CREATE = "A name is required to create a bucket.", r.HMAC_SERVICE_ACCOUNT = "The first argument must be a service account email to create an HMAC key.", r.HMAC_ACCESS_ID = "An access ID is needed to create an HmacKey object.";
})(Se || (Se = {}));
var as = /^(\w*):\/\//, os = !0, cs = 3, ls = 2, ps = 600, ds = 64, us = _.RetryConditional, xr = /* @__PURE__ */ d(function(r) {
  var e;
  let t = /* @__PURE__ */ d((i) => i.includes("eai_again") || // DNS lookup error
  i === "econnreset" || i === "unexpected connection closure" || i === "epipe" || i === "socket connection timeout", "isConnectionProblem");
  if (r) {
    if ([408, 429, 500, 502, 503, 504].indexOf(r.code) !== -1)
      return !0;
    if (typeof r.code == "string") {
      if (["408", "429", "500", "502", "503", "504"].indexOf(r.code) !== -1)
        return !0;
      let i = r.code.toLowerCase();
      if (t(i))
        return !0;
    }
    if (r.errors)
      for (let i of r.errors) {
        let n = (e = i?.reason) === null || e === void 0 ? void 0 : e.toString().toLowerCase();
        if (n && t(n))
          return !0;
      }
  }
  return !1;
}, "RETRYABLE_ERR_FN_DEFAULT");
var D = class r extends ke {
  static {
    d(this, "Storage");
  }
  getBucketsStream() {
    return new fr();
  }
  getHmacKeysStream() {
    return new fr();
  }
  /**
   * @callback Crc32cGeneratorToStringCallback
   * A method returning the CRC32C as a base64-encoded string.
   *
   * @returns {string}
   *
   * @example
   * Hashing the string 'data' should return 'rth90Q=='
   *
   * ```js
   * const buffer = Buffer.from('data');
   * crc32c.update(buffer);
   * crc32c.toString(); // 'rth90Q=='
   * ```
   **/
  /**
   * @callback Crc32cGeneratorValidateCallback
   * A method validating a base64-encoded CRC32C string.
   *
   * @param {string} [value] base64-encoded CRC32C string to validate
   * @returns {boolean}
   *
   * @example
   * Should return `true` if the value matches, `false` otherwise
   *
   * ```js
   * const buffer = Buffer.from('data');
   * crc32c.update(buffer);
   * crc32c.validate('DkjKuA=='); // false
   * crc32c.validate('rth90Q=='); // true
   * ```
   **/
  /**
   * @callback Crc32cGeneratorUpdateCallback
   * A method for passing `Buffer`s for CRC32C generation.
   *
   * @param {Buffer} [data] data to update CRC32C value with
   * @returns {undefined}
   *
   * @example
   * Hashing buffers from 'some ' and 'text\n'
   *
   * ```js
   * const buffer1 = Buffer.from('some ');
   * crc32c.update(buffer1);
   *
   * const buffer2 = Buffer.from('text\n');
   * crc32c.update(buffer2);
   *
   * crc32c.toString(); // 'DkjKuA=='
   * ```
   **/
  /**
   * @typedef {object} CRC32CValidator
   * @property {Crc32cGeneratorToStringCallback}
   * @property {Crc32cGeneratorValidateCallback}
   * @property {Crc32cGeneratorUpdateCallback}
   */
  /**
   * @callback Crc32cGeneratorCallback
   * @returns {CRC32CValidator}
   */
  /**
   * @typedef {object} StorageOptions
   * @property {string} [projectId] The project ID from the Google Developer's
   *     Console, e.g. 'grape-spaceship-123'. We will also check the environment
   *     variable `GCLOUD_PROJECT` for your project ID. If your app is running
   * in an environment which supports {@link
   * https://cloud.google.com/docs/authentication/production#providing_credentials_to_your_application
   * Application Default Credentials}, your project ID will be detected
   * automatically.
   * @property {string} [keyFilename] Full path to the a .json, .pem, or .p12 key
   *     downloaded from the Google Developers Console. If you provide a path to
   * a JSON file, the `projectId` option above is not necessary. NOTE: .pem and
   *     .p12 require you to specify the `email` option as well.
   * @property {string} [email] Account email address. Required when using a .pem
   *     or .p12 keyFilename.
   * @property {object} [credentials] Credentials object.
   * @property {string} [credentials.client_email]
   * @property {string} [credentials.private_key]
   * @property {object} [retryOptions] Options for customizing retries. Retriable server errors
   *     will be retried with exponential delay between them dictated by the formula
   *     max(maxRetryDelay, retryDelayMultiplier*retryNumber) until maxRetries or totalTimeout
   *     has been reached. Retries will only happen if autoRetry is set to true.
   * @property {boolean} [retryOptions.autoRetry=true] Automatically retry requests if the
   *     response is related to rate limits or certain intermittent server
   * errors. We will exponentially backoff subsequent requests by default.
   * @property {number} [retryOptions.retryDelayMultiplier = 2] the multiplier by which to
   *   increase the delay time between the completion of failed requests, and the
   *   initiation of the subsequent retrying request.
   * @property {number} [retryOptions.totalTimeout = 600] The total time, starting from
   *  when the initial request is sent, after which an error will
   *   be returned, regardless of the retrying attempts made meanwhile.
   * @property {number} [retryOptions.maxRetryDelay = 64] The maximum delay time between requests.
   *   When this value is reached, ``retryDelayMultiplier`` will no longer be used to
   *   increase delay time.
   * @property {number} [retryOptions.maxRetries=3] Maximum number of automatic retries
   *     attempted before returning the error.
   * @property {function} [retryOptions.retryableErrorFn] Function that returns true if a given
   *     error should be retried and false otherwise.
   * @property {enum} [retryOptions.idempotencyStrategy=IdempotencyStrategy.RetryConditional] Enumeration
   *     controls how conditionally idempotent operations are retried. Possible values are: RetryAlways -
   *     will respect other retry settings and attempt to retry conditionally idempotent operations. RetryConditional -
   *     will retry conditionally idempotent operations if the correct preconditions are set. RetryNever - never
   *     retry a conditionally idempotent operation.
   * @property {string} [userAgent] The value to be prepended to the User-Agent
   *     header in API requests.
   * @property {object} [authClient] `AuthClient` or `GoogleAuth` client to reuse instead of creating a new one.
   * @property {number} [timeout] The amount of time in milliseconds to wait per http request before timing out.
   * @property {object[]} [interceptors_] Array of custom request interceptors to be returned in the order they were assigned.
   * @property {string} [apiEndpoint = storage.google.com] The API endpoint of the service used to make requests.
   * @property {boolean} [useAuthWithCustomEndpoint = false] Controls whether or not to use authentication when using a custom endpoint.
   * @property {Crc32cGeneratorCallback} [callback] A function that generates a CRC32C Validator. Defaults to {@link CRC32C}
   */
  /**
   * Constructs the Storage client.
   *
   * @example
   * Create a client that uses Application Default Credentials
   * (ADC)
   * ```
   * const {Storage} = require('@google-cloud/storage');
   * const storage = new Storage();
   * ```
   *
   * @example
   * Create a client with explicit credentials
   * ```
   * const storage = new Storage({
   *   projectId: 'your-project-id',
   *   keyFilename: '/path/to/keyfile.json'
   * });
   * ```
   *
   * @example
   * Create a client with credentials passed
   * by value as a JavaScript object
   * ```
   * const storage = new Storage({
   *   projectId: 'your-project-id',
   *   credentials: {
   *     type: 'service_account',
   *     project_id: 'xxxxxxx',
   *     private_key_id: 'xxxx',
   *     private_key:'-----BEGIN PRIVATE KEY-----xxxxxxx\n-----END PRIVATE KEY-----\n',
   *     client_email: 'xxxx',
   *     client_id: 'xxx',
   *     auth_uri: 'https://accounts.google.com/o/oauth2/auth',
   *     token_uri: 'https://oauth2.googleapis.com/token',
   *     auth_provider_x509_cert_url: 'https://www.googleapis.com/oauth2/v1/certs',
   *     client_x509_cert_url: 'xxx',
   *     }
   * });
   * ```
   *
   * @example
   * Create a client with credentials passed
   * by loading a JSON file directly from disk
   * ```
   * const storage = new Storage({
   *   projectId: 'your-project-id',
   *   credentials: require('/path/to-keyfile.json')
   * });
   * ```
   *
   * @example
   * Create a client with an `AuthClient` (e.g. `DownscopedClient`)
   * ```
   * const {DownscopedClient} = require('google-auth-library');
   * const authClient = new DownscopedClient({...});
   *
   * const storage = new Storage({authClient});
   * ```
   *
   * Additional samples:
   * - https://github.com/googleapis/google-auth-library-nodejs#sample-usage-1
   * - https://github.com/googleapis/google-auth-library-nodejs/blob/main/samples/downscopedclient.js
   *
   * @param {StorageOptions} [options] Configuration options.
   */
  constructor(e = {}) {
    var t, i, n, s, c, a, o, l, p, u, f, m, h, g;
    let x = `https://storage.${e.universeDomain || gr.DEFAULT_UNIVERSE}`, w = !1, N = process.env.STORAGE_EMULATOR_HOST;
    typeof N == "string" && (x = r.sanitizeEndpoint(N), w = !0), e.apiEndpoint && e.apiEndpoint !== x && (x = r.sanitizeEndpoint(e.apiEndpoint), w = !0), e = Object.assign({}, e, { apiEndpoint: x });
    let q = N || `${e.apiEndpoint}/storage/v1`, A = {
      apiEndpoint: e.apiEndpoint,
      retryOptions: {
        autoRetry: ((t = e.retryOptions) === null || t === void 0 ? void 0 : t.autoRetry) !== void 0 ? (i = e.retryOptions) === null || i === void 0 ? void 0 : i.autoRetry : os,
        maxRetries: !((n = e.retryOptions) === null || n === void 0) && n.maxRetries ? (s = e.retryOptions) === null || s === void 0 ? void 0 : s.maxRetries : cs,
        retryDelayMultiplier: !((c = e.retryOptions) === null || c === void 0) && c.retryDelayMultiplier ? (a = e.retryOptions) === null || a === void 0 ? void 0 : a.retryDelayMultiplier : ls,
        totalTimeout: !((o = e.retryOptions) === null || o === void 0) && o.totalTimeout ? (l = e.retryOptions) === null || l === void 0 ? void 0 : l.totalTimeout : ps,
        maxRetryDelay: !((p = e.retryOptions) === null || p === void 0) && p.maxRetryDelay ? (u = e.retryOptions) === null || u === void 0 ? void 0 : u.maxRetryDelay : ds,
        retryableErrorFn: !((f = e.retryOptions) === null || f === void 0) && f.retryableErrorFn ? (m = e.retryOptions) === null || m === void 0 ? void 0 : m.retryableErrorFn : xr,
        idempotencyStrategy: ((h = e.retryOptions) === null || h === void 0 ? void 0 : h.idempotencyStrategy) !== void 0 ? (g = e.retryOptions) === null || g === void 0 ? void 0 : g.idempotencyStrategy : us
      },
      baseUrl: q,
      customEndpoint: w,
      useAuthWithCustomEndpoint: e?.useAuthWithCustomEndpoint,
      projectIdRequired: !1,
      scopes: [
        "https://www.googleapis.com/auth/iam",
        "https://www.googleapis.com/auth/cloud-platform",
        "https://www.googleapis.com/auth/devstorage.full_control"
      ],
      packageJson: (0, hr.getPackageJSON)()
    };
    super(A, e), this.acl = r.acl, this.crc32cGenerator = e.crc32cGenerator || rt, this.retryOptions = A.retryOptions, this.getBucketsStream = lt.paginator.streamify("getBuckets"), this.getHmacKeysStream = lt.paginator.streamify("getHmacKeys");
  }
  static sanitizeEndpoint(e) {
    return as.test(e) || (e = `https://${e}`), e.replace(/\/+$/, "");
  }
  /**
   * Get a reference to a Cloud Storage bucket.
   *
   * @param {string} name Name of the bucket.
   * @param {object} [options] Configuration object.
   * @param {string} [options.kmsKeyName] A Cloud KMS key that will be used to
   *     encrypt objects inserted into this bucket, if no encryption method is
   *     specified.
   * @param {string} [options.userProject] User project to be billed for all
   *     requests made from this Bucket object.
   * @returns {Bucket}
   * @see Bucket
   *
   * @example
   * ```
   * const {Storage} = require('@google-cloud/storage');
   * const storage = new Storage();
   * const albums = storage.bucket('albums');
   * const photos = storage.bucket('photos');
   * ```
   */
  bucket(e, t) {
    if (!e)
      throw new Error(Se.BUCKET_NAME_REQUIRED);
    return new F(this, e, t);
  }
  /**
   * Reference a channel to receive notifications about changes to your bucket.
   *
   * @param {string} id The ID of the channel.
   * @param {string} resourceId The resource ID of the channel.
   * @returns {Channel}
   * @see Channel
   *
   * @example
   * ```
   * const {Storage} = require('@google-cloud/storage');
   * const storage = new Storage();
   * const channel = storage.channel('id', 'resource-id');
   * ```
   */
  channel(e, t) {
    return new he(this, e, t);
  }
  /**
   * @typedef {array} CreateBucketResponse
   * @property {Bucket} 0 The new {@link Bucket}.
   * @property {object} 1 The full API response.
   */
  /**
   * @callback CreateBucketCallback
   * @param {?Error} err Request error, if any.
   * @param {Bucket} bucket The new {@link Bucket}.
   * @param {object} apiResponse The full API response.
   */
  /**
   * Metadata to set for the bucket.
   *
   * @typedef {object} CreateBucketRequest
   * @property {boolean} [archive=false] Specify the storage class as Archive.
   * @property {object} [autoclass.enabled=false] Specify whether Autoclass is
   *     enabled for the bucket.
   * @property {object} [autoclass.terminalStorageClass='NEARLINE'] The storage class that objects in an Autoclass bucket eventually transition to if
   *     they are not read for a certain length of time. Valid values are NEARLINE and ARCHIVE.
   * @property {boolean} [coldline=false] Specify the storage class as Coldline.
   * @property {Cors[]} [cors=[]] Specify the CORS configuration to use.
   * @property {CustomPlacementConfig} [customPlacementConfig={}] Specify the bucket's regions for dual-region buckets.
   *     For more information, see {@link https://cloud.google.com/storage/docs/locations| Bucket Locations}.
   * @property {boolean} [dra=false] Specify the storage class as Durable Reduced
   *     Availability.
   * @property {boolean} [enableObjectRetention=false] Specifiy whether or not object retention should be enabled on this bucket.
   * @property {object} [hierarchicalNamespace.enabled=false] Specify whether or not to enable hierarchical namespace on this bucket.
   * @property {string} [location] Specify the bucket's location. If specifying
   *     a dual-region, the `customPlacementConfig` property should be set in conjunction.
   *     For more information, see {@link https://cloud.google.com/storage/docs/locations| Bucket Locations}.
   * @property {boolean} [multiRegional=false] Specify the storage class as
   *     Multi-Regional.
   * @property {boolean} [nearline=false] Specify the storage class as Nearline.
   * @property {boolean} [regional=false] Specify the storage class as Regional.
   * @property {boolean} [requesterPays=false] Force the use of the User Project metadata field to assign operational
   *     costs when an operation is made on a Bucket and its objects.
   * @property {string} [rpo] For dual-region buckets, controls whether turbo
   *      replication is enabled (`ASYNC_TURBO`) or disabled (`DEFAULT`).
   * @property {boolean} [standard=true] Specify the storage class as Standard.
   * @property {string} [storageClass] The new storage class. (`standard`,
   *     `nearline`, `coldline`, or `archive`).
   *     **Note:** The storage classes `multi_regional`, `regional`, and
   *     `durable_reduced_availability` are now legacy and will be deprecated in
   *     the future.
   * @property {Versioning} [versioning=undefined] Specify the versioning status.
   * @property {string} [userProject] The ID of the project which will be billed
   *     for the request.
   */
  /**
   * Create a bucket.
   *
   * Cloud Storage uses a flat namespace, so you can't create a bucket with
   * a name that is already in use. For more information, see
   * {@link https://cloud.google.com/storage/docs/bucketnaming.html#requirements| Bucket Naming Guidelines}.
   *
   * See {@link https://cloud.google.com/storage/docs/json_api/v1/buckets/insert| Buckets: insert API Documentation}
   * See {@link https://cloud.google.com/storage/docs/storage-classes| Storage Classes}
   *
   * @param {string} name Name of the bucket to create.
   * @param {CreateBucketRequest} [metadata] Metadata to set for the bucket.
   * @param {CreateBucketCallback} [callback] Callback function.
   * @returns {Promise<CreateBucketResponse>}
   * @throws {Error} If a name is not provided.
   * @see Bucket#create
   *
   * @example
   * ```
   * const {Storage} = require('@google-cloud/storage');
   * const storage = new Storage();
   * const callback = function(err, bucket, apiResponse) {
   *   // `bucket` is a Bucket object.
   * };
   *
   * storage.createBucket('new-bucket', callback);
   *
   * //-
   * // Create a bucket in a specific location and region. <em>See the <a
   * // href="https://cloud.google.com/storage/docs/json_api/v1/buckets/insert">
   * // Official JSON API docs</a> for complete details on the `location`
   * option.
   * // </em>
   * //-
   * const metadata = {
   *   location: 'US-CENTRAL1',
   *   regional: true
   * };
   *
   * storage.createBucket('new-bucket', metadata, callback);
   *
   * //-
   * // Create a bucket with a retention policy of 6 months.
   * //-
   * const metadata = {
   *   retentionPolicy: {
   *     retentionPeriod: 15780000 // 6 months in seconds.
   *   }
   * };
   *
   * storage.createBucket('new-bucket', metadata, callback);
   *
   * //-
   * // Enable versioning on a new bucket.
   * //-
   * const metadata = {
   *   versioning: {
   *     enabled: true
   *   }
   * };
   *
   * storage.createBucket('new-bucket', metadata, callback);
   *
   * //-
   * // If the callback is omitted, we'll return a Promise.
   * //-
   * storage.createBucket('new-bucket').then(function(data) {
   *   const bucket = data[0];
   *   const apiResponse = data[1];
   * });
   *
   * ```
   * @example <caption>include:samples/buckets.js</caption>
   * region_tag:storage_create_bucket
   * Another example:
   */
  createBucket(e, t, i) {
    if (!e)
      throw new Error(Se.BUCKET_NAME_REQUIRED_CREATE);
    let n;
    i ? n = t : (i = t, n = {});
    let s = {
      ...n,
      name: e
    }, c = {
      archive: "ARCHIVE",
      coldline: "COLDLINE",
      dra: "DURABLE_REDUCED_AVAILABILITY",
      multiRegional: "MULTI_REGIONAL",
      nearline: "NEARLINE",
      regional: "REGIONAL",
      standard: "STANDARD"
    }, a = Object.keys(c);
    for (let l of a)
      if (s[l]) {
        if (n.storageClass && n.storageClass !== l)
          throw new Error(`Both \`${l}\` and \`storageClass\` were provided.`);
        s.storageClass = c[l], delete s[l];
      }
    s.requesterPays && (s.billing = {
      requesterPays: s.requesterPays
    }, delete s.requesterPays);
    let o = {
      project: this.projectId
    };
    s.userProject && (o.userProject = s.userProject, delete s.userProject), s.enableObjectRetention && (o.enableObjectRetention = s.enableObjectRetention, delete s.enableObjectRetention), s.predefinedAcl && (o.predefinedAcl = s.predefinedAcl, delete s.predefinedAcl), s.predefinedDefaultObjectAcl && (o.predefinedDefaultObjectAcl = s.predefinedDefaultObjectAcl, delete s.predefinedDefaultObjectAcl), s.projection && (o.projection = s.projection, delete s.projection), this.request({
      method: "POST",
      uri: "/b",
      qs: o,
      json: s
    }, (l, p) => {
      if (l) {
        i(l, null, p);
        return;
      }
      let u = this.bucket(e);
      u.metadata = p, i(null, u, p);
    });
  }
  /**
   * @typedef {object} CreateHmacKeyOptions
   * @property {string} [projectId] The project ID of the project that owns
   *     the service account of the requested HMAC key. If not provided,
   *     the project ID used to instantiate the Storage client will be used.
   * @property {string} [userProject] This parameter is currently ignored.
   */
  /**
   * @typedef {object} HmacKeyMetadata
   * @property {string} accessId The access id identifies which HMAC key was
   *     used to sign a request when authenticating with HMAC.
   * @property {string} etag Used to perform a read-modify-write of the key.
   * @property {string} id The resource name of the HMAC key.
   * @property {string} projectId The project ID.
   * @property {string} serviceAccountEmail The service account's email this
   *     HMAC key is created for.
   * @property {string} state The state of this HMAC key. One of "ACTIVE",
   *     "INACTIVE" or "DELETED".
   * @property {string} timeCreated The creation time of the HMAC key in
   *     RFC 3339 format.
   * @property {string} [updated] The time this HMAC key was last updated in
   *     RFC 3339 format.
   */
  /**
   * @typedef {array} CreateHmacKeyResponse
   * @property {HmacKey} 0 The HmacKey instance created from API response.
   * @property {string} 1 The HMAC key's secret used to access the XML API.
   * @property {object} 3 The raw API response.
   */
  /**
   * @callback CreateHmacKeyCallback Callback function.
   * @param {?Error} err Request error, if any.
   * @param {HmacKey} hmacKey The HmacKey instance created from API response.
   * @param {string} secret The HMAC key's secret used to access the XML API.
   * @param {object} apiResponse The raw API response.
   */
  /**
   * Create an HMAC key associated with an service account to authenticate
   * requests to the Cloud Storage XML API.
   *
   * See {@link https://cloud.google.com/storage/docs/authentication/hmackeys| HMAC keys documentation}
   *
   * @param {string} serviceAccountEmail The service account's email address
   *     with which the HMAC key is created for.
   * @param {CreateHmacKeyCallback} [callback] Callback function.
   * @return {Promise<CreateHmacKeyResponse>}
   *
   * @example
   * ```
   * const {Storage} = require('google-cloud/storage');
   * const storage = new Storage();
   *
   * // Replace with your service account's email address
   * const serviceAccountEmail =
   *   'my-service-account@appspot.gserviceaccount.com';
   *
   * storage.createHmacKey(serviceAccountEmail, function(err, hmacKey, secret) {
   *   if (!err) {
   *     // Securely store the secret for use with the XML API.
   *   }
   * });
   *
   * //-
   * // If the callback is omitted, we'll return a Promise.
   * //-
   * storage.createHmacKey(serviceAccountEmail)
   *   .then((response) => {
   *     const hmacKey = response[0];
   *     const secret = response[1];
   *     // Securely store the secret for use with the XML API.
   *   });
   * ```
   */
  createHmacKey(e, t, i) {
    if (typeof e != "string")
      throw new Error(Se.HMAC_SERVICE_ACCOUNT);
    let { options: n, callback: s } = U(t, i), c = Object.assign({}, n, { serviceAccountEmail: e }), a = c.projectId || this.projectId;
    delete c.projectId, this.request({
      method: "POST",
      uri: `/projects/${a}/hmacKeys`,
      qs: c,
      maxRetries: 0
      //explicitly set this value since this is a non-idempotent function
    }, (o, l) => {
      if (o) {
        s(o, null, null, l);
        return;
      }
      let p = l.metadata, u = this.hmacKey(p.accessId, {
        projectId: p.projectId
      });
      u.metadata = l.metadata, s(null, u, l.secret, l);
    });
  }
  /**
   * Query object for listing buckets.
   *
   * @typedef {object} GetBucketsRequest
   * @property {boolean} [autoPaginate=true] Have pagination handled
   *     automatically.
   * @property {number} [maxApiCalls] Maximum number of API calls to make.
   * @property {number} [maxResults] Maximum number of items plus prefixes to
   *     return per call.
   *     Note: By default will handle pagination automatically
   *     if more than 1 page worth of results are requested per call.
   *     When `autoPaginate` is set to `false` the smaller of `maxResults`
   *     or 1 page of results will be returned per call.
   * @property {string} [pageToken] A previously-returned page token
   *     representing part of the larger set of results to view.
   * @property {string} [userProject] The ID of the project which will be billed
   *     for the request.
   *  @param {boolean} [softDeleted] If true, returns the soft-deleted object.
   *     Object `generation` is required if `softDeleted` is set to True.
   */
  /**
   * @typedef {array} GetBucketsResponse
   * @property {Bucket[]} 0 Array of {@link Bucket} instances.
   * @property {object} 1 nextQuery A query object to receive more results.
   * @property {object} 2 The full API response.
   */
  /**
   * @callback GetBucketsCallback
   * @param {?Error} err Request error, if any.
   * @param {Bucket[]} buckets Array of {@link Bucket} instances.
   * @param {object} nextQuery A query object to receive more results.
   * @param {object} apiResponse The full API response.
   */
  /**
   * Get Bucket objects for all of the buckets in your project.
   *
   * See {@link https://cloud.google.com/storage/docs/json_api/v1/buckets/list| Buckets: list API Documentation}
   *
   * @param {GetBucketsRequest} [query] Query object for listing buckets.
   * @param {GetBucketsCallback} [callback] Callback function.
   * @returns {Promise<GetBucketsResponse>}
   *
   * @example
   * ```
   * const {Storage} = require('@google-cloud/storage');
   * const storage = new Storage();
   * storage.getBuckets(function(err, buckets) {
   *   if (!err) {
   *     // buckets is an array of Bucket objects.
   *   }
   * });
   *
   * //-
   * // To control how many API requests are made and page through the results
   * // manually, set `autoPaginate` to `false`.
   * //-
   * const callback = function(err, buckets, nextQuery, apiResponse) {
   *   if (nextQuery) {
   *     // More results exist.
   *     storage.getBuckets(nextQuery, callback);
   *   }
   *
   *   // The `metadata` property is populated for you with the metadata at the
   *   // time of fetching.
   *   buckets[0].metadata;
   *
   *   // However, in cases where you are concerned the metadata could have
   *   // changed, use the `getMetadata` method.
   *   buckets[0].getMetadata(function(err, metadata, apiResponse) {});
   * };
   *
   * storage.getBuckets({
   *   autoPaginate: false
   * }, callback);
   *
   * //-
   * // If the callback is omitted, we'll return a Promise.
   * //-
   * storage.getBuckets().then(function(data) {
   *   const buckets = data[0];
   * });
   *
   * ```
   * @example <caption>include:samples/buckets.js</caption>
   * region_tag:storage_list_buckets
   * Another example:
   */
  getBuckets(e, t) {
    let { options: i, callback: n } = U(e, t);
    i.project = i.project || this.projectId, this.request({
      uri: "/b",
      qs: i
    }, (s, c) => {
      if (s) {
        n(s, null, null, c);
        return;
      }
      let o = (c.items ? c.items : []).map((p) => {
        let u = this.bucket(p.id);
        return u.metadata = p, u;
      }), l = c.nextPageToken ? Object.assign({}, i, { pageToken: c.nextPageToken }) : null;
      n(null, o, l, c);
    });
  }
  getHmacKeys(e, t) {
    let { options: i, callback: n } = U(e, t), s = Object.assign({}, i), c = s.projectId || this.projectId;
    delete s.projectId, this.request({
      uri: `/projects/${c}/hmacKeys`,
      qs: s
    }, (a, o) => {
      if (a) {
        n(a, null, null, o);
        return;
      }
      let p = (o.items ? o.items : []).map((f) => {
        let m = this.hmacKey(f.accessId, {
          projectId: f.projectId
        });
        return m.metadata = f, m;
      }), u = o.nextPageToken ? Object.assign({}, i, { pageToken: o.nextPageToken }) : null;
      n(null, p, u, o);
    });
  }
  /**
   * @typedef {array} GetServiceAccountResponse
   * @property {object} 0 The service account resource.
   * @property {object} 1 The full
   * {@link https://cloud.google.com/storage/docs/json_api/v1/projects/serviceAccount#resource| API response}.
   */
  /**
   * @callback GetServiceAccountCallback
   * @param {?Error} err Request error, if any.
   * @param {object} serviceAccount The serviceAccount resource.
   * @param {string} serviceAccount.emailAddress The service account email
   *     address.
   * @param {object} apiResponse The full
   * {@link https://cloud.google.com/storage/docs/json_api/v1/projects/serviceAccount#resource| API response}.
   */
  /**
   * Get the email address of this project's Google Cloud Storage service
   * account.
   *
   * See {@link https://cloud.google.com/storage/docs/json_api/v1/projects/serviceAccount/get| Projects.serviceAccount: get API Documentation}
   * See {@link https://cloud.google.com/storage/docs/json_api/v1/projects/serviceAccount#resource| Projects.serviceAccount Resource}
   *
   * @param {object} [options] Configuration object.
   * @param {string} [options.userProject] User project to be billed for this
   *     request.
   * @param {GetServiceAccountCallback} [callback] Callback function.
   * @returns {Promise<GetServiceAccountResponse>}
   *
   * @example
   * ```
   * const {Storage} = require('@google-cloud/storage');
   * const storage = new Storage();
   *
   * storage.getServiceAccount(function(err, serviceAccount, apiResponse) {
   *   if (!err) {
   *     const serviceAccountEmail = serviceAccount.emailAddress;
   *   }
   * });
   *
   * //-
   * // If the callback is omitted, we'll return a Promise.
   * //-
   * storage.getServiceAccount().then(function(data) {
   *   const serviceAccountEmail = data[0].emailAddress;
   *   const apiResponse = data[1];
   * });
   * ```
   */
  getServiceAccount(e, t) {
    let { options: i, callback: n } = U(e, t);
    this.request({
      uri: `/projects/${this.projectId}/serviceAccount`,
      qs: i
    }, (s, c) => {
      if (s) {
        n(s, null, c);
        return;
      }
      let a = {};
      for (let o in c)
        if (c.hasOwnProperty(o)) {
          let l = o.replace(/_(\w)/g, (p, u) => u.toUpperCase());
          a[l] = c[o];
        }
      n(null, a, c);
    });
  }
  /**
   * Get a reference to an HmacKey object.
   * Note: this does not fetch the HMAC key's metadata. Use HmacKey#get() to
   * retrieve and populate the metadata.
   *
   * To get a reference to an HMAC key that's not created for a service
   * account in the same project used to instantiate the Storage client,
   * supply the project's ID as `projectId` in the `options` argument.
   *
   * @param {string} accessId The HMAC key's access ID.
   * @param {HmacKeyOptions} options HmacKey constructor options.
   * @returns {HmacKey}
   * @see HmacKey
   *
   * @example
   * ```
   * const {Storage} = require('@google-cloud/storage');
   * const storage = new Storage();
   * const hmacKey = storage.hmacKey('ACCESS_ID');
   * ```
   */
  hmacKey(e, t) {
    if (!e)
      throw new Error(Se.HMAC_ACCESS_ID);
    return new ge(this, e, t);
  }
};
D.Bucket = F;
D.Channel = he;
D.File = H;
D.HmacKey = ge;
D.acl = {
  OWNER_ROLE: "OWNER",
  READER_ROLE: "READER",
  WRITER_ROLE: "WRITER"
};
lt.paginator.extend(D, ["getBuckets", "getHmacKeys"]);
(0, mr.promisifyAll)(D, {
  exclude: ["bucket", "channel", "hmacKey"]
});

// node_modules/@google-cloud/storage/build/esm/src/transfer-manager.js
var qe = v(Ot(), 1);
import * as L from "path";
import { createReadStream as Ta, existsSync as Ra, promises as dt } from "fs";
var Zr = v(Oe(), 1), mt = v(Yr(), 1), Ve = v(Ue(), 1);
import { createHash as Na } from "crypto";
var en = v(Ee(), 1);
var ye = function(r, e, t, i) {
  if (t === "a" && !i) throw new TypeError("Private accessor was defined without a getter");
  if (typeof e == "function" ? r !== e || !i : !e.has(r)) throw new TypeError("Cannot read private member from an object whose class did not declare it");
  return t === "m" ? i : t === "a" ? i.call(r) : i ? i.value : e.get(r);
}, ee, ut, ze, Ia = (0, en.getPackageJSON)(), Sa = 5, qa = 5, Pa = 5, ja = 32 * 1024 * 1024, Oa = 32 * 1024 * 1024, Ca = 32 * 1024 * 1024, Jr = 5, La = "(?:)", Pe = {
  UPLOAD_MANY: "tm.upload_many",
  DOWNLOAD_MANY: "tm.download_many",
  UPLOAD_SHARDED: "tm.upload_sharded",
  DOWNLOAD_SHARDED: "tm.download_sharded"
}, ka = /* @__PURE__ */ d((r, e, t, i) => new Qt(r, e, t, i), "defaultMultiPartGenerator"), ft = class extends Error {
  static {
    d(this, "MultiPartUploadError");
  }
  constructor(e, t, i) {
    super(e), this.uploadId = t, this.partsMap = i;
  }
}, Qt = class {
  static {
    d(this, "XMLMultiPartUploadHelper");
  }
  constructor(e, t, i, n) {
    ee.add(this), this.authClient = e.storage.authClient || new Zr.GoogleAuth(), this.uploadId = i || "", this.bucket = e, this.fileName = t, this.baseUrl = `https://${e.name}.${new URL(this.bucket.storage.apiEndpoint).hostname}/${t}`, this.xmlBuilder = new mt.XMLBuilder({ arrayNodeName: "Part" }), this.xmlParser = new mt.XMLParser(), this.partsMap = n || /* @__PURE__ */ new Map(), this.retryOptions = {
      retries: this.bucket.storage.retryOptions.maxRetries,
      factor: this.bucket.storage.retryOptions.retryDelayMultiplier,
      maxTimeout: this.bucket.storage.retryOptions.maxRetryDelay * 1e3,
      maxRetryTime: this.bucket.storage.retryOptions.totalTimeout * 1e3
    };
  }
  /**
   * Initiates a multipart upload (MPU) to the XML API and stores the resultant upload id.
   *
   * @returns {Promise<void>}
   */
  async initiateUpload(e = {}) {
    let t = `${this.baseUrl}?uploads`;
    return (0, Ve.default)(async (i) => {
      try {
        let n = await this.authClient.request({
          headers: ye(this, ee, "m", ut).call(this, e),
          method: "POST",
          url: t
        });
        if (n.data && n.data.error)
          throw n.data.error;
        let s = this.xmlParser.parse(n.data);
        this.uploadId = s.InitiateMultipartUploadResult.UploadId;
      } catch (n) {
        ye(this, ee, "m", ze).call(this, n, i);
      }
    }, this.retryOptions);
  }
  /**
   * Uploads the provided chunk of data to the XML API using the previously created upload id.
   *
   * @param {number} partNumber the sequence number of this chunk.
   * @param {Buffer} chunk the chunk of data to be uploaded.
   * @param {string | false} validation whether or not to include the md5 hash in the headers to cause the server
   * to validate the chunk was not corrupted.
   * @returns {Promise<void>}
   */
  async uploadPart(e, t, i) {
    let n = `${this.baseUrl}?partNumber=${e}&uploadId=${this.uploadId}`, s = ye(this, ee, "m", ut).call(this);
    return i === "md5" && (s = {
      "Content-MD5": Na("md5").update(t).digest("base64")
    }), (0, Ve.default)(async (c) => {
      try {
        let a = await this.authClient.request({
          url: n,
          method: "PUT",
          body: t,
          headers: s
        });
        if (a.data && a.data.error)
          throw a.data.error;
        this.partsMap.set(e, a.headers.etag);
      } catch (a) {
        ye(this, ee, "m", ze).call(this, a, c);
      }
    }, this.retryOptions);
  }
  /**
   * Sends the final request of the MPU to tell GCS the upload is now complete.
   *
   * @returns {Promise<void>}
   */
  async completeUpload() {
    let e = `${this.baseUrl}?uploadId=${this.uploadId}`, t = new Map([...this.partsMap.entries()].sort((s, c) => s[0] - c[0])), i = [];
    for (let s of t.entries())
      i.push({ PartNumber: s[0], ETag: s[1] });
    let n = `<CompleteMultipartUpload>${this.xmlBuilder.build(i)}</CompleteMultipartUpload>`;
    return (0, Ve.default)(async (s) => {
      try {
        let c = await this.authClient.request({
          headers: ye(this, ee, "m", ut).call(this),
          url: e,
          method: "POST",
          body: n
        });
        if (c.data && c.data.error)
          throw c.data.error;
        return c;
      } catch (c) {
        ye(this, ee, "m", ze).call(this, c, s);
        return;
      }
    }, this.retryOptions);
  }
  /**
   * Aborts an multipart upload that is in progress. Once aborted, any parts in the process of being uploaded fail,
   * and future requests using the upload ID fail.
   *
   * @returns {Promise<void>}
   */
  async abortUpload() {
    let e = `${this.baseUrl}?uploadId=${this.uploadId}`;
    return (0, Ve.default)(async (t) => {
      try {
        let i = await this.authClient.request({
          url: e,
          method: "DELETE"
        });
        if (i.data && i.data.error)
          throw i.data.error;
      } catch (i) {
        ye(this, ee, "m", ze).call(this, i, t);
        return;
      }
    }, this.retryOptions);
  }
};
ee = /* @__PURE__ */ new WeakSet(), ut = /* @__PURE__ */ d(function(e = {}) {
  let t = !1, i = !1;
  for (let [n, s] of Object.entries(e))
    n.toLocaleLowerCase().trim() === "x-goog-api-client" ? (t = !0, s.includes(Pe.UPLOAD_SHARDED) || (e[n] = `${s} gccl-gcs-cmd/${Pe.UPLOAD_SHARDED}`)) : n.toLocaleLowerCase().trim() === "user-agent" && (i = !0);
  return t || (e["x-goog-api-client"] = `${z()} gccl/${Ia.version} gccl-gcs-cmd/${Pe.UPLOAD_SHARDED}`), i || (e["User-Agent"] = V()), e;
}, "_XMLMultiPartUploadHelper_setGoogApiClientHeaders"), ze = /* @__PURE__ */ d(function(e, t) {
  if (this.bucket.storage.retryOptions.autoRetry && this.bucket.storage.retryOptions.retryableErrorFn(e))
    throw e;
  t(e);
}, "_XMLMultiPartUploadHelper_handleErrorResponse");
var Qr = class {
  static {
    d(this, "TransferManager");
  }
  constructor(e) {
    this.bucket = e;
  }
  /**
   * @typedef {object} UploadManyFilesOptions
   * @property {number} [concurrencyLimit] The number of concurrently executing promises
   * to use when uploading the files.
   * @property {Function} [customDestinationBuilder] A fuction that will take the current path of a local file
   * and return a string representing a custom path to be used to upload the file to GCS.
   * @property {boolean} [skipIfExists] Do not upload the file if it already exists in
   * the bucket. This will set the precondition ifGenerationMatch = 0.
   * @property {string} [prefix] A prefix to append to all of the uploaded files.
   * @property {object} [passthroughOptions] {@link UploadOptions} Options to be passed through
   * to each individual upload operation.
   *
   */
  /**
   * Upload multiple files in parallel to the bucket. This is a convenience method
   * that utilizes {@link Bucket#upload} to perform the upload.
   *
   * @param {array | string} [filePathsOrDirectory] An array of fully qualified paths to the files or a directory name.
   * If a directory name is provided, the directory will be recursively walked and all files will be added to the upload list.
   * to be uploaded to the bucket
   * @param {UploadManyFilesOptions} [options] Configuration options.
   * @returns {Promise<UploadResponse[]>}
   *
   * @example
   * ```
   * const {Storage} = require('@google-cloud/storage');
   * const storage = new Storage();
   * const bucket = storage.bucket('my-bucket');
   * const transferManager = new TransferManager(bucket);
   *
   * //-
   * // Upload multiple files in parallel.
   * //-
   * const response = await transferManager.uploadManyFiles(['/local/path/file1.txt, 'local/path/file2.txt']);
   * // Your bucket now contains:
   * // - "local/path/file1.txt" (with the contents of '/local/path/file1.txt')
   * // - "local/path/file2.txt" (with the contents of '/local/path/file2.txt')
   * const response = await transferManager.uploadManyFiles('/local/directory');
   * // Your bucket will now contain all files contained in '/local/directory' maintaining the subdirectory structure.
   * ```
   *
   */
  async uploadManyFiles(e, t = {}) {
    var i;
    t.skipIfExists && (!((i = t.passthroughOptions) === null || i === void 0) && i.preconditionOpts) ? t.passthroughOptions.preconditionOpts.ifGenerationMatch = 0 : t.skipIfExists && t.passthroughOptions === void 0 && (t.passthroughOptions = {
      preconditionOpts: {
        ifGenerationMatch: 0
      }
    });
    let n = (0, qe.default)(t.concurrencyLimit || Sa), s = [], c = [];
    if (Array.isArray(e))
      c = e;
    else
      for await (let a of this.getPathsFromDirectory(e))
        c.push(a);
    for (let a of c) {
      if ((await dt.lstat(a)).isDirectory())
        continue;
      let l = {
        ...t.passthroughOptions,
        [T]: Pe.UPLOAD_MANY
      };
      l.destination = t.customDestinationBuilder ? t.customDestinationBuilder(a, t) : a.split(L.sep).join(L.posix.sep), t.prefix && (l.destination = L.posix.join(...t.prefix.split(L.sep), l.destination)), s.push(n(() => this.bucket.upload(a, l)));
    }
    return Promise.all(s);
  }
  /**
   * @typedef {object} DownloadManyFilesOptions
   * @property {number} [concurrencyLimit] The number of concurrently executing promises
   * to use when downloading the files.
   * @property {string} [prefix] A prefix to append to all of the downloaded files.
   * @property {string} [stripPrefix] A prefix to remove from all of the downloaded files.
   * @property {object} [passthroughOptions] {@link DownloadOptions} Options to be passed through
   * to each individual download operation.
   * @property {boolean} [skipIfExists] Do not download the file if it already exists in
   * the destination.
   *
   */
  /**
   * Download multiple files in parallel to the local filesystem. This is a convenience method
   * that utilizes {@link File#download} to perform the download.
   *
   * @param {array | string} [filesOrFolder] An array of file name strings or file objects to be downloaded. If
   * a string is provided this will be treated as a GCS prefix and all files with that prefix will be downloaded.
   * @param {DownloadManyFilesOptions} [options] Configuration options. Setting options.prefix or options.stripPrefix
   * or options.passthroughOptions.destination will cause the downloaded files to be written to the file system
   * instead of being returned as a buffer.
   * @returns {Promise<DownloadResponse[]>}
   *
   * @example
   * ```
   * const {Storage} = require('@google-cloud/storage');
   * const storage = new Storage();
   * const bucket = storage.bucket('my-bucket');
   * const transferManager = new TransferManager(bucket);
   *
   * //-
   * // Download multiple files in parallel.
   * //-
   * const response = await transferManager.downloadManyFiles(['file1.txt', 'file2.txt']);
   * // The following files have been downloaded:
   * // - "file1.txt" (with the contents from my-bucket.file1.txt)
   * // - "file2.txt" (with the contents from my-bucket.file2.txt)
   * const response = await transferManager.downloadManyFiles([bucket.File('file1.txt'), bucket.File('file2.txt')]);
   * // The following files have been downloaded:
   * // - "file1.txt" (with the contents from my-bucket.file1.txt)
   * // - "file2.txt" (with the contents from my-bucket.file2.txt)
   * const response = await transferManager.downloadManyFiles('test-folder');
   * // All files with GCS prefix of 'test-folder' have been downloaded.
   * ```
   *
   */
  async downloadManyFiles(e, t = {}) {
    let i = (0, qe.default)(t.concurrencyLimit || qa), n = [], s = [];
    Array.isArray(e) ? s = e.map((o) => typeof o == "string" ? this.bucket.file(o) : o) : s = (await this.bucket.getFiles({
      prefix: e
    }))[0];
    let c = t.stripPrefix ? `^${t.stripPrefix}` : La, a = new RegExp(c, "g");
    for (let o of s) {
      let l = {
        ...t.passthroughOptions,
        [T]: Pe.DOWNLOAD_MANY
      };
      (t.prefix || l.destination) && (l.destination = L.join(t.prefix || "", l.destination || "", o.name)), t.stripPrefix && (l.destination = o.name.replace(a, "")), !(t.skipIfExists && Ra(l.destination || "")) && n.push(i(async () => {
        let p = l.destination;
        return p && p.endsWith(L.sep) ? (await dt.mkdir(p, { recursive: !0 }), Promise.resolve([
          Buffer.alloc(0)
        ])) : o.download(l);
      }));
    }
    return Promise.all(n);
  }
  /**
   * @typedef {object} DownloadFileInChunksOptions
   * @property {number} [concurrencyLimit] The number of concurrently executing promises
   * to use when downloading the file.
   * @property {number} [chunkSizeBytes] The size in bytes of each chunk to be downloaded.
   * @property {string | boolean} [validation] Whether or not to perform a CRC32C validation check when download is complete.
   * @property {boolean} [noReturnData] Whether or not to return the downloaded data. A `true` value here would be useful for files with a size that will not fit into memory.
   *
   */
  /**
   * Download a large file in chunks utilizing parallel download operations. This is a convenience method
   * that utilizes {@link File#download} to perform the download.
   *
   * @param {File | string} fileOrName {@link File} to download.
   * @param {DownloadFileInChunksOptions} [options] Configuration options.
   * @returns {Promise<void | DownloadResponse>}
   *
   * @example
   * ```
   * const {Storage} = require('@google-cloud/storage');
   * const storage = new Storage();
   * const bucket = storage.bucket('my-bucket');
   * const transferManager = new TransferManager(bucket);
   *
   * //-
   * // Download a large file in chunks utilizing parallel operations.
   * //-
   * const response = await transferManager.downloadFileInChunks(bucket.file('large-file.txt');
   * // Your local directory now contains:
   * // - "large-file.txt" (with the contents from my-bucket.large-file.txt)
   * ```
   *
   */
  async downloadFileInChunks(e, t = {}) {
    let i = t.chunkSizeBytes || Oa, n = (0, qe.default)(t.concurrencyLimit || Pa), s = !!t.noReturnData, c = [], a = typeof e == "string" ? this.bucket.file(e) : e, o = await a.get(), l = parseInt(o[0].metadata.size.toString());
    l < ja && (n = (0, qe.default)(1), i = l);
    let p = 0, u = t.destination || L.basename(a.name), f = await dt.open(u, "w");
    for (; p < l; ) {
      let h = p, g = p + i - 1;
      g = g > l ? l : g, c.push(n(async () => {
        let y = await a.download({
          start: h,
          end: g,
          [T]: Pe.DOWNLOAD_SHARDED
        }), x = await f.write(y[0], 0, y[0].length, h);
        if (!s)
          return x.buffer;
      })), p += i;
    }
    let m;
    try {
      m = await Promise.all(c);
    } finally {
      await f.close();
    }
    if (t.validation === "crc32c" && o[0].metadata.crc32c && !(await J.fromFile(u)).validate(o[0].metadata.crc32c)) {
      let g = new oe(I.DOWNLOAD_MISMATCH);
      throw g.code = "CONTENT_DOWNLOAD_MISMATCH", g;
    }
    if (!s)
      return [Buffer.concat(m, l)];
  }
  /**
   * @typedef {object} UploadFileInChunksOptions
   * @property {number} [concurrencyLimit] The number of concurrently executing promises
   * to use when uploading the file.
   * @property {number} [chunkSizeBytes] The size in bytes of each chunk to be uploaded.
   * @property {string} [uploadName] Name of the file when saving to GCS. If ommitted the name is taken from the file path.
   * @property {number} [maxQueueSize] The number of chunks to be uploaded to hold in memory concurrently. If not specified
   * defaults to the specified concurrency limit.
   * @property {string} [uploadId] If specified attempts to resume a previous upload.
   * @property {Map} [partsMap] If specified alongside uploadId, attempts to resume a previous upload from the last chunk
   * specified in partsMap
   * @property {object} [headers] headers to be sent when initiating the multipart upload.
   * See {@link https://cloud.google.com/storage/docs/xml-api/post-object-multipart#request_headers| Request Headers: Initiate a Multipart Upload}
   * @property {boolean} [autoAbortFailure] boolean to indicate if an in progress upload session will be automatically aborted upon failure. If not set,
   * failures will be automatically aborted.
   *
   */
  /**
   * Upload a large file in chunks utilizing parallel upload opertions. If the upload fails, an uploadId and
   * map containing all the successfully uploaded parts will be returned to the caller. These arguments can be used to
   * resume the upload.
   *
   * @param {string} [filePath] The path of the file to be uploaded
   * @param {UploadFileInChunksOptions} [options] Configuration options.
   * @param {MultiPartHelperGenerator} [generator] A function that will return a type that implements the MPU interface. Most users will not need to use this.
   * @returns {Promise<void>} If successful a promise resolving to void, otherwise a error containing the message, uploadid, and parts map.
   *
   * @example
   * ```
   * const {Storage} = require('@google-cloud/storage');
   * const storage = new Storage();
   * const bucket = storage.bucket('my-bucket');
   * const transferManager = new TransferManager(bucket);
   *
   * //-
   * // Upload a large file in chunks utilizing parallel operations.
   * //-
   * const response = await transferManager.uploadFileInChunks('large-file.txt');
   * // Your bucket now contains:
   * // - "large-file.txt"
   * ```
   *
   *
   */
  async uploadFileInChunks(e, t = {}, i = ka) {
    let n = t.chunkSizeBytes || Ca, s = (0, qe.default)(t.concurrencyLimit || Jr), c = t.maxQueueSize || t.concurrencyLimit || Jr, a = t.uploadName || L.basename(e), o = i(this.bucket, a, t.uploadId, t.partsMap), l = 1, p = [];
    try {
      t.uploadId === void 0 && await o.initiateUpload(t.headers);
      let u = o.partsMap.size * n, f = Ta(e, {
        highWaterMark: n,
        start: u
      });
      for await (let m of f)
        p.length >= c && (await Promise.all(p), p = []), p.push(s(() => o.uploadPart(l++, m, t.validation)));
      return await Promise.all(p), await o.completeUpload();
    } catch (u) {
      if ((t.autoAbortFailure === void 0 || t.autoAbortFailure) && o.uploadId)
        try {
          await o.abortUpload();
          return;
        } catch (f) {
          throw new ft(f.message, o.uploadId, o.partsMap);
        }
      throw new ft(u.message, o.uploadId, o.partsMap);
    }
  }
  async *getPathsFromDirectory(e) {
    let t = await dt.readdir(e, {
      withFileTypes: !0
    });
    for (let i of t) {
      let n = L.join(e, i.name);
      i.isDirectory() ? yield* this.getPathsFromDirectory(n) : yield n;
    }
  }
};

export {
  ie as a,
  Wi as b,
  Yn as c,
  rt as d,
  kt as e,
  J as f,
  Fe as g,
  H as h,
  Ne as i,
  Ie as j,
  F as k,
  he as l,
  ge as m,
  _ as n,
  xr as o,
  D as p,
  ft as q,
  Qr as r
};
/*! Bundled license information:

@google-cloud/paginator/build/src/resource-stream.js:
  (*!
   * Copyright 2019 Google Inc. All Rights Reserved.
   *
   * Licensed under the Apache License, Version 2.0 (the "License");
   * you may not use this file except in compliance with the License.
   * You may obtain a copy of the License at
   *
   *      http://www.apache.org/licenses/LICENSE-2.0
   *
   * Unless required by applicable law or agreed to in writing, software
   * distributed under the License is distributed on an "AS IS" BASIS,
   * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   * See the License for the specific language governing permissions and
   * limitations under the License.
   *)

@google-cloud/paginator/build/src/index.js:
  (*!
   * Copyright 2015 Google Inc. All Rights Reserved.
   *
   * Licensed under the Apache License, Version 2.0 (the "License");
   * you may not use this file except in compliance with the License.
   * You may obtain a copy of the License at
   *
   *      http://www.apache.org/licenses/LICENSE-2.0
   *
   * Unless required by applicable law or agreed to in writing, software
   * distributed under the License is distributed on an "AS IS" BASIS,
   * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   * See the License for the specific language governing permissions and
   * limitations under the License.
   *)
  (*!
   * @module common/paginator
   *)
  (*! Developer Documentation
   *
   * paginator is used to auto-paginate `nextQuery` methods as well as
   * streamifying them.
   *
   * Before:
   *
   *   search.query('done=true', function(err, results, nextQuery) {
   *     search.query(nextQuery, function(err, results, nextQuery) {});
   *   });
   *
   * After:
   *
   *   search.query('done=true', function(err, results) {});
   *
   * Methods to extend should be written to accept callbacks and return a
   * `nextQuery`.
   *)

@google-cloud/storage/build/esm/src/nodejs-common/util.js:
  (*!
   * Copyright 2022 Google LLC. All Rights Reserved.
   *
   * Licensed under the Apache License, Version 2.0 (the "License");
   * you may not use this file except in compliance with the License.
   * You may obtain a copy of the License at
   *
   *      http://www.apache.org/licenses/LICENSE-2.0
   *
   * Unless required by applicable law or agreed to in writing, software
   * distributed under the License is distributed on an "AS IS" BASIS,
   * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   * See the License for the specific language governing permissions and
   * limitations under the License.
   *)
  (*!
   * @module common/util
   *)

@google-cloud/storage/build/esm/src/nodejs-common/service.js:
@google-cloud/storage/build/esm/src/nodejs-common/service-object.js:
@google-cloud/storage/build/esm/src/transfer-manager.js:
  (*!
   * Copyright 2022 Google LLC. All Rights Reserved.
   *
   * Licensed under the Apache License, Version 2.0 (the "License");
   * you may not use this file except in compliance with the License.
   * You may obtain a copy of the License at
   *
   *      http://www.apache.org/licenses/LICENSE-2.0
   *
   * Unless required by applicable law or agreed to in writing, software
   * distributed under the License is distributed on an "AS IS" BASIS,
   * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   * See the License for the specific language governing permissions and
   * limitations under the License.
   *)

@google-cloud/storage/build/esm/src/acl.js:
@google-cloud/storage/build/esm/src/file.js:
@google-cloud/storage/build/esm/src/iam.js:
@google-cloud/storage/build/esm/src/notification.js:
@google-cloud/storage/build/esm/src/channel.js:
@google-cloud/storage/build/esm/src/hmacKey.js:
  (*! Developer Documentation
   *
   * All async methods (except for streams) will return a Promise in the event
   * that a callback is omitted.
   *)

@google-cloud/storage/build/esm/src/bucket.js:
  (*! Developer Documentation
   *
   * These methods can be auto-paginated.
   *)
  (*! Developer Documentation
   *
   * All async methods (except for streams) will return a Promise in the event
   * that a callback is omitted.
   *)

@google-cloud/storage/build/esm/src/storage.js:
  (*! Developer Documentation
   *
   * Invoke this method to create a new Storage object bound with pre-determined
   * configuration options. For each object that can be created (e.g., a bucket),
   * there is an equivalent static and instance method. While they are classes,
   * they can be instantiated without use of the `new` keyword.
   *)
  (*! Developer Documentation
   *
   * These methods can be auto-paginated.
   *)
  (*! Developer Documentation
   *
   * All async methods (except for streams) will return a Promise in the event
   * that a callback is omitted.
   *)
*/
//# sourceMappingURL=ZAA3ZEWY.js.map
