import {
  a as l
} from "./V7X2J7BI.js";

// convex/lib/vertexAI_improved.ts
function h(n, r) {
  if (!n || n.trim() === "")
    return console.warn("[safeJsonParse] \u7A7A\u307E\u305F\u306Fnull\u6587\u5B57\u5217\u304C\u6E21\u3055\u308C\u307E\u3057\u305F"), r;
  let e = n.trim();
  if (e = e.replace(/[\x00-\x1F\x7F]/g, ""), e.includes("```")) {
    let a = e.match(/```(?:json)?\s*(\{[\s\S]*?\})\s*```/);
    a ? e = a[1] : e = e.replace(/```[^`]*```/g, "").trim();
  }
  let s = e.indexOf("{"), t = e.lastIndexOf("}");
  s !== -1 && t !== -1 && s < t && (e = e.substring(s, t + 1));
  try {
    return JSON.parse(e) || r;
  } catch (a) {
    console.warn("[safeJsonParse] \u521D\u671F\u30D1\u30FC\u30B9\u5931\u6557\u3002\u4FEE\u5FA9\u3092\u8A66\u884C:", a);
    let c = e;
    c = u(c), c = p(c), c = g(c);
    try {
      let o = JSON.parse(c);
      return console.log("[safeJsonParse] \u4FEE\u5FA9\u6210\u529F"), o;
    } catch (o) {
      console.warn("[safeJsonParse] \u4FEE\u5FA9\u5931\u6557\u3001\u90E8\u5206\u30D1\u30FC\u30B9\u3092\u8A66\u884C:", o);
      let i = f(e, r);
      return i !== r ? i : (console.error("[safeJsonParse] \u5168\u3066\u306E\u4FEE\u5FA9\u8A66\u884C\u304C\u5931\u6557\u3001\u30D5\u30A9\u30FC\u30EB\u30D0\u30C3\u30AF\u5024\u3092\u8FD4\u5374"), r);
    }
  }
}
l(h, "safeJsonParse");
function u(n) {
  let r = n, e = /"([^"]+)"\s*:\s*"([^"]*?)$/, s = r.match(e);
  if (s) {
    let t = s[1], a = s[2];
    r = r.replace(s[0], `"${t}": "${a}"`);
  }
  return r = r.replace(/"([^"]+)"\s*:\s*"([^"]*?)(?!")/g, '"$1": "$2"'), r;
}
l(u, "repairIncompleteStrings");
function p(n) {
  let r = n, e = (r.match(/\{/g) || []).length, s = (r.match(/\}/g) || []).length;
  if (e > s) {
    let t = e - s;
    r += "}".repeat(t);
  }
  return r;
}
l(p, "repairIncompleteObjects");
function g(n) {
  return n.replace(/,\s*([}\]])/g, "$1");
}
l(g, "repairTrailingCommas");
function f(n, r) {
  try {
    let e = /"([^"]+)"\s*:\s*("([^"]*)"|(\d+(?:\.\d+)?)|true|false|null|\[[^\]]*\]|\{[^}]*\})/g, s = [...n.matchAll(e)];
    if (s.length === 0)
      return r;
    let t = {};
    for (let a of s) {
      let c = a[1], o = a[2];
      try {
        let i;
        o.startsWith('"') && o.endsWith('"') ? i = o.slice(1, -1) : i = JSON.parse(o), t[c] = i;
      } catch {
        t[c] = o;
      }
    }
    if (Object.keys(t).length > 0)
      return console.log("[safeJsonParse] \u90E8\u5206\u30D1\u30FC\u30B9\u6210\u529F\u3001\u62BD\u51FA\u3055\u308C\u305F\u30AD\u30FC:", Object.keys(t)), t;
  } catch (e) {
    console.error("[safeJsonParse] \u90E8\u5206\u30D1\u30FC\u30B9\u5931\u6557:", e);
  }
  return r;
}
l(f, "extractPartialJson");

export {
  h as a,
  u as b,
  p as c,
  g as d,
  f as e
};
//# sourceMappingURL=2SFASJNQ.js.map
