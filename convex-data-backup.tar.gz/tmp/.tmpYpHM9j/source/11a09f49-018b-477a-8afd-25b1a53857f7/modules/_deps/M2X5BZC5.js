import {
  n as e,
  p as a
} from "./6XQQNYIR.js";
import {
  j as o,
  n
} from "./3TDUHHJO.js";

// convex/schema/evaluation.ts
a();
n();
var t = o.union(
  o.literal("M&A\u30ED\u30FC\u30EB\u30D7\u30EC\u30A4"),
  o.literal("\u521D\u56DE\u9762\u8AC7"),
  o.literal("AD\u7DE0\u7D50\u63D0\u6848"),
  o.literal("\u4F01\u696D\u6982\u8981\u66F8\u63D0\u6848"),
  o.literal("\u8B72\u6E21\u67B6\u96FB")
), r = o.union(
  o.literal("pending"),
  o.literal("processing"),
  o.literal("completed"),
  o.literal("failed")
), i = o.object({
  score: o.number(),
  analysis: o.string(),
  strength: o.optional(o.string()),
  weakness: o.optional(o.string())
}), p = {
  evaluations: e({
    transcriptionId: o.id("transcriptions"),
    videoId: o.optional(o.id("videos")),
    userId: o.id("users"),
    videoType: t,
    status: r,
    // 基本評価情報
    scores: o.optional(o.record(o.string(), o.number())),
    comments: o.optional(o.string()),
    // 初回面談評価項目（構造化）
    initialMeetingScores: o.optional(
      o.object({
        hearingAbility: o.optional(i),
        problemSetting: o.optional(i),
        knowledge: o.optional(i),
        negotiation: o.optional(i),
        businessManners: o.optional(i)
      })
    ),
    // AD締結提案評価項目（構造化）
    adProposalScores: o.optional(
      o.object({
        hearingAbility: o.optional(i),
        knowledge: o.optional(i),
        proposalAbility: o.optional(i),
        negotiation: o.optional(i),
        relationshipBuilding: o.optional(i)
      })
    ),
    // 企業概要書提案評価項目（構造化）
    imProposalScores: o.optional(
      o.object({
        needsHearingProposal: o.optional(i),
        sellerUnderstanding: o.optional(i),
        buyerUnderstanding: o.optional(i),
        synergyProposal: o.optional(i),
        testClosing: o.optional(i)
      })
    ),
    // 譲渡架電評価項目（構造化）
    callScores: o.optional(
      o.object({
        tone: o.optional(i),
        listening: o.optional(i),
        scheduling: o.optional(i),
        importantInfo: o.optional(i),
        deepHearing: o.optional(i)
      })
    ),
    // AI評価メタデータ
    aiModel: o.optional(o.string()),
    processingDurationMs: o.optional(o.number()),
    retryCount: o.optional(o.number()),
    errorMessage: o.optional(o.string()),
    evaluationRequestedAt: o.optional(o.number()),
    evaluationCompletedAt: o.optional(o.number())
  }).index("by_transcription_id", ["transcriptionId"]).index("by_user_id", ["userId"]).index("by_status", ["status"]).index("by_video_type_status", ["videoType", "status"]),
  evaluationCriteria: e({
    videoType: t,
    criterionKey: o.string(),
    criterionName: o.string(),
    description: o.optional(o.string()),
    scale: o.object({
      minScore: o.number(),
      maxScore: o.number(),
      description: o.string(),
      scales: o.record(o.string(), o.string())
    }),
    isActive: o.boolean(),
    createdBy: o.id("users"),
    weight: o.optional(o.number())
  }).index("by_video_type", ["videoType"]).index("by_video_type_and_active", ["videoType", "isActive"])
};

export {
  p as a
};
//# sourceMappingURL=M2X5BZC5.js.map
