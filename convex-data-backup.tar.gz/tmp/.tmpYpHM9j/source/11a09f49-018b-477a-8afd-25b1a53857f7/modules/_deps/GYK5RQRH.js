import {
  a,
  c as R
} from "./RUVYHBJQ.js";

// node_modules/base64-js/index.js
var q = R((C) => {
  "use strict";
  C.byteLength = er;
  C.toByteArray = or;
  C.fromByteArray = fr;
  var m = [], E = [], nr = typeof Uint8Array < "u" ? Uint8Array : Array, L = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
  for (g = 0, H = L.length; g < H; ++g)
    m[g] = L[g], E[L.charCodeAt(g)] = g;
  var g, H;
  E[45] = 62;
  E[95] = 63;
  function X(i) {
    var r = i.length;
    if (r % 4 > 0)
      throw new Error("Invalid string. Length must be a multiple of 4");
    var t = i.indexOf("=");
    t === -1 && (t = r);
    var n = t === r ? 0 : 4 - t % 4;
    return [t, n];
  }
  a(X, "getLens");
  function er(i) {
    var r = X(i), t = r[0], n = r[1];
    return (t + n) * 3 / 4 - n;
  }
  a(er, "byteLength");
  function ur(i, r, t) {
    return (r + t) * 3 / 4 - t;
  }
  a(ur, "_byteLength");
  function or(i) {
    var r, t = X(i), n = t[0], e = t[1], u = new nr(ur(i, n, e)), o = 0, f = e > 0 ? n - 4 : n, p;
    for (p = 0; p < f; p += 4)
      r = E[i.charCodeAt(p)] << 18 | E[i.charCodeAt(p + 1)] << 12 | E[i.charCodeAt(p + 2)] << 6 | E[i.charCodeAt(p + 3)], u[o++] = r >> 16 & 255, u[o++] = r >> 8 & 255, u[o++] = r & 255;
    return e === 2 && (r = E[i.charCodeAt(p)] << 2 | E[i.charCodeAt(p + 1)] >> 4, u[o++] = r & 255), e === 1 && (r = E[i.charCodeAt(p)] << 10 | E[i.charCodeAt(p + 1)] << 4 | E[i.charCodeAt(p + 2)] >> 2, u[o++] = r >> 8 & 255, u[o++] = r & 255), u;
  }
  a(or, "toByteArray");
  function hr(i) {
    return m[i >> 18 & 63] + m[i >> 12 & 63] + m[i >> 6 & 63] + m[i & 63];
  }
  a(hr, "tripletToBase64");
  function ar(i, r, t) {
    for (var n, e = [], u = r; u < t; u += 3)
      n = (i[u] << 16 & 16711680) + (i[u + 1] << 8 & 65280) + (i[u + 2] & 255), e.push(hr(n));
    return e.join("");
  }
  a(ar, "encodeChunk");
  function fr(i) {
    for (var r, t = i.length, n = t % 3, e = [], u = 16383, o = 0, f = t - n; o < f; o += u)
      e.push(ar(i, o, o + u > f ? f : o + u));
    return n === 1 ? (r = i[t - 1], e.push(
      m[r >> 2] + m[r << 4 & 63] + "=="
    )) : n === 2 && (r = (i[t - 2] << 8) + i[t - 1], e.push(
      m[r >> 10] + m[r >> 4 & 63] + m[r << 2 & 63] + "="
    )), e.join("");
  }
  a(fr, "fromByteArray");
});

// node_modules/ieee754/index.js
var G = R((M) => {
  M.read = function(i, r, t, n, e) {
    var u, o, f = e * 8 - n - 1, p = (1 << f) - 1, l = p >> 1, w = -7, c = t ? e - 1 : 0, F = t ? -1 : 1, x = i[r + c];
    for (c += F, u = x & (1 << -w) - 1, x >>= -w, w += f; w > 0; u = u * 256 + i[r + c], c += F, w -= 8)
      ;
    for (o = u & (1 << -w) - 1, u >>= -w, w += n; w > 0; o = o * 256 + i[r + c], c += F, w -= 8)
      ;
    if (u === 0)
      u = 1 - l;
    else {
      if (u === p)
        return o ? NaN : (x ? -1 : 1) * (1 / 0);
      o = o + Math.pow(2, n), u = u - l;
    }
    return (x ? -1 : 1) * o * Math.pow(2, u - n);
  };
  M.write = function(i, r, t, n, e, u) {
    var o, f, p, l = u * 8 - e - 1, w = (1 << l) - 1, c = w >> 1, F = e === 23 ? Math.pow(2, -24) - Math.pow(2, -77) : 0, x = n ? 0 : u - 1, I = n ? 1 : -1, ir = r < 0 || r === 0 && 1 / r < 0 ? 1 : 0;
    for (r = Math.abs(r), isNaN(r) || r === 1 / 0 ? (f = isNaN(r) ? 1 : 0, o = w) : (o = Math.floor(Math.log(r) / Math.LN2), r * (p = Math.pow(2, -o)) < 1 && (o--, p *= 2), o + c >= 1 ? r += F / p : r += F * Math.pow(2, 1 - c), r * p >= 2 && (o++, p /= 2), o + c >= w ? (f = 0, o = w) : o + c >= 1 ? (f = (r * p - 1) * Math.pow(2, e), o = o + c) : (f = r * Math.pow(2, c - 1) * Math.pow(2, e), o = 0)); e >= 8; i[t + x] = f & 255, x += I, f /= 256, e -= 8)
      ;
    for (o = o << e | f, l += e; l > 0; i[t + x] = o & 255, x += I, o /= 256, l -= 8)
      ;
    i[t + x - I] |= ir * 128;
  };
});

// node_modules/buffer/index.js
var kr = R((T) => {
  var k = q(), v = G(), z = typeof Symbol == "function" && typeof Symbol.for == "function" ? Symbol.for("nodejs.util.inspect.custom") : null;
  T.Buffer = h;
  T.SlowBuffer = yr;
  T.INSPECT_MAX_BYTES = 50;
  var d = 2147483647;
  T.kMaxLength = d;
  h.TYPED_ARRAY_SUPPORT = pr();
  !h.TYPED_ARRAY_SUPPORT && typeof console < "u" && typeof console.error == "function" && console.error(
    "This browser lacks typed array (Uint8Array) support which is required by `buffer` v5.x. Use `buffer` v4.x if you require old browser support."
  );
  function pr() {
    try {
      var i = new Uint8Array(1), r = { foo: /* @__PURE__ */ a(function() {
        return 42;
      }, "foo") };
      return Object.setPrototypeOf(r, Uint8Array.prototype), Object.setPrototypeOf(i, r), i.foo() === 42;
    } catch {
      return !1;
    }
  }
  a(pr, "typedArraySupport");
  Object.defineProperty(h.prototype, "parent", {
    enumerable: !0,
    get: /* @__PURE__ */ a(function() {
      if (h.isBuffer(this))
        return this.buffer;
    }, "get")
  });
  Object.defineProperty(h.prototype, "offset", {
    enumerable: !0,
    get: /* @__PURE__ */ a(function() {
      if (h.isBuffer(this))
        return this.byteOffset;
    }, "get")
  });
  function A(i) {
    if (i > d)
      throw new RangeError('The value "' + i + '" is invalid for option "size"');
    var r = new Uint8Array(i);
    return Object.setPrototypeOf(r, h.prototype), r;
  }
  a(A, "createBuffer");
  function h(i, r, t) {
    if (typeof i == "number") {
      if (typeof r == "string")
        throw new TypeError(
          'The "string" argument must be of type string. Received type number'
        );
      return b(i);
    }
    return K(i, r, t);
  }
  a(h, "Buffer");
  h.poolSize = 8192;
  function K(i, r, t) {
    if (typeof i == "string")
      return lr(i, r);
    if (ArrayBuffer.isView(i))
      return wr(i);
    if (i == null)
      throw new TypeError(
        "The first argument must be one of type string, Buffer, ArrayBuffer, Array, or Array-like Object. Received type " + typeof i
      );
    if (B(i, ArrayBuffer) || i && B(i.buffer, ArrayBuffer) || typeof SharedArrayBuffer < "u" && (B(i, SharedArrayBuffer) || i && B(i.buffer, SharedArrayBuffer)))
      return N(i, r, t);
    if (typeof i == "number")
      throw new TypeError(
        'The "value" argument must not be of type number. Received type number'
      );
    var n = i.valueOf && i.valueOf();
    if (n != null && n !== i)
      return h.from(n, r, t);
    var e = sr(i);
    if (e) return e;
    if (typeof Symbol < "u" && Symbol.toPrimitive != null && typeof i[Symbol.toPrimitive] == "function")
      return h.from(
        i[Symbol.toPrimitive]("string"),
        r,
        t
      );
    throw new TypeError(
      "The first argument must be one of type string, Buffer, ArrayBuffer, Array, or Array-like Object. Received type " + typeof i
    );
  }
  a(K, "from");
  h.from = function(i, r, t) {
    return K(i, r, t);
  };
  Object.setPrototypeOf(h.prototype, Uint8Array.prototype);
  Object.setPrototypeOf(h, Uint8Array);
  function O(i) {
    if (typeof i != "number")
      throw new TypeError('"size" argument must be of type number');
    if (i < 0)
      throw new RangeError('The value "' + i + '" is invalid for option "size"');
  }
  a(O, "assertSize");
  function cr(i, r, t) {
    return O(i), i <= 0 ? A(i) : r !== void 0 ? typeof t == "string" ? A(i).fill(r, t) : A(i).fill(r) : A(i);
  }
  a(cr, "alloc");
  h.alloc = function(i, r, t) {
    return cr(i, r, t);
  };
  function b(i) {
    return O(i), A(i < 0 ? 0 : W(i) | 0);
  }
  a(b, "allocUnsafe");
  h.allocUnsafe = function(i) {
    return b(i);
  };
  h.allocUnsafeSlow = function(i) {
    return b(i);
  };
  function lr(i, r) {
    if ((typeof r != "string" || r === "") && (r = "utf8"), !h.isEncoding(r))
      throw new TypeError("Unknown encoding: " + r);
    var t = Z(i, r) | 0, n = A(t), e = n.write(i, r);
    return e !== t && (n = n.slice(0, e)), n;
  }
  a(lr, "fromString");
  function D(i) {
    for (var r = i.length < 0 ? 0 : W(i.length) | 0, t = A(r), n = 0; n < r; n += 1)
      t[n] = i[n] & 255;
    return t;
  }
  a(D, "fromArrayLike");
  function wr(i) {
    if (B(i, Uint8Array)) {
      var r = new Uint8Array(i);
      return N(r.buffer, r.byteOffset, r.byteLength);
    }
    return D(i);
  }
  a(wr, "fromArrayView");
  function N(i, r, t) {
    if (r < 0 || i.byteLength < r)
      throw new RangeError('"offset" is outside of buffer bounds');
    if (i.byteLength < r + (t || 0))
      throw new RangeError('"length" is outside of buffer bounds');
    var n;
    return r === void 0 && t === void 0 ? n = new Uint8Array(i) : t === void 0 ? n = new Uint8Array(i, r) : n = new Uint8Array(i, r, t), Object.setPrototypeOf(n, h.prototype), n;
  }
  a(N, "fromArrayBuffer");
  function sr(i) {
    if (h.isBuffer(i)) {
      var r = W(i.length) | 0, t = A(r);
      return t.length === 0 || i.copy(t, 0, 0, r), t;
    }
    if (i.length !== void 0)
      return typeof i.length != "number" || Y(i.length) ? A(0) : D(i);
    if (i.type === "Buffer" && Array.isArray(i.data))
      return D(i.data);
  }
  a(sr, "fromObject");
  function W(i) {
    if (i >= d)
      throw new RangeError("Attempt to allocate Buffer larger than maximum size: 0x" + d.toString(16) + " bytes");
    return i | 0;
  }
  a(W, "checked");
  function yr(i) {
    return +i != i && (i = 0), h.alloc(+i);
  }
  a(yr, "SlowBuffer");
  h.isBuffer = /* @__PURE__ */ a(function(r) {
    return r != null && r._isBuffer === !0 && r !== h.prototype;
  }, "isBuffer");
  h.compare = /* @__PURE__ */ a(function(r, t) {
    if (B(r, Uint8Array) && (r = h.from(r, r.offset, r.byteLength)), B(t, Uint8Array) && (t = h.from(t, t.offset, t.byteLength)), !h.isBuffer(r) || !h.isBuffer(t))
      throw new TypeError(
        'The "buf1", "buf2" arguments must be one of type Buffer or Uint8Array'
      );
    if (r === t) return 0;
    for (var n = r.length, e = t.length, u = 0, o = Math.min(n, e); u < o; ++u)
      if (r[u] !== t[u]) {
        n = r[u], e = t[u];
        break;
      }
    return n < e ? -1 : e < n ? 1 : 0;
  }, "compare");
  h.isEncoding = /* @__PURE__ */ a(function(r) {
    switch (String(r).toLowerCase()) {
      case "hex":
      case "utf8":
      case "utf-8":
      case "ascii":
      case "latin1":
      case "binary":
      case "base64":
      case "ucs2":
      case "ucs-2":
      case "utf16le":
      case "utf-16le":
        return !0;
      default:
        return !1;
    }
  }, "isEncoding");
  h.concat = /* @__PURE__ */ a(function(r, t) {
    if (!Array.isArray(r))
      throw new TypeError('"list" argument must be an Array of Buffers');
    if (r.length === 0)
      return h.alloc(0);
    var n;
    if (t === void 0)
      for (t = 0, n = 0; n < r.length; ++n)
        t += r[n].length;
    var e = h.allocUnsafe(t), u = 0;
    for (n = 0; n < r.length; ++n) {
      var o = r[n];
      if (B(o, Uint8Array))
        u + o.length > e.length ? h.from(o).copy(e, u) : Uint8Array.prototype.set.call(
          e,
          o,
          u
        );
      else if (h.isBuffer(o))
        o.copy(e, u);
      else
        throw new TypeError('"list" argument must be an Array of Buffers');
      u += o.length;
    }
    return e;
  }, "concat");
  function Z(i, r) {
    if (h.isBuffer(i))
      return i.length;
    if (ArrayBuffer.isView(i) || B(i, ArrayBuffer))
      return i.byteLength;
    if (typeof i != "string")
      throw new TypeError(
        'The "string" argument must be one of type string, Buffer, or ArrayBuffer. Received type ' + typeof i
      );
    var t = i.length, n = arguments.length > 2 && arguments[2] === !0;
    if (!n && t === 0) return 0;
    for (var e = !1; ; )
      switch (r) {
        case "ascii":
        case "latin1":
        case "binary":
          return t;
        case "utf8":
        case "utf-8":
          return _(i).length;
        case "ucs2":
        case "ucs-2":
        case "utf16le":
        case "utf-16le":
          return t * 2;
        case "hex":
          return t >>> 1;
        case "base64":
          return tr(i).length;
        default:
          if (e)
            return n ? -1 : _(i).length;
          r = ("" + r).toLowerCase(), e = !0;
      }
  }
  a(Z, "byteLength");
  h.byteLength = Z;
  function xr(i, r, t) {
    var n = !1;
    if ((r === void 0 || r < 0) && (r = 0), r > this.length || ((t === void 0 || t > this.length) && (t = this.length), t <= 0) || (t >>>= 0, r >>>= 0, t <= r))
      return "";
    for (i || (i = "utf8"); ; )
      switch (i) {
        case "hex":
          return Tr(this, r, t);
        case "utf8":
        case "utf-8":
          return $(this, r, t);
        case "ascii":
          return Ir(this, r, t);
        case "latin1":
        case "binary":
          return vr(this, r, t);
        case "base64":
          return gr(this, r, t);
        case "ucs2":
        case "ucs-2":
        case "utf16le":
        case "utf-16le":
          return Cr(this, r, t);
        default:
          if (n) throw new TypeError("Unknown encoding: " + i);
          i = (i + "").toLowerCase(), n = !0;
      }
  }
  a(xr, "slowToString");
  h.prototype._isBuffer = !0;
  function U(i, r, t) {
    var n = i[r];
    i[r] = i[t], i[t] = n;
  }
  a(U, "swap");
  h.prototype.swap16 = /* @__PURE__ */ a(function() {
    var r = this.length;
    if (r % 2 !== 0)
      throw new RangeError("Buffer size must be a multiple of 16-bits");
    for (var t = 0; t < r; t += 2)
      U(this, t, t + 1);
    return this;
  }, "swap16");
  h.prototype.swap32 = /* @__PURE__ */ a(function() {
    var r = this.length;
    if (r % 4 !== 0)
      throw new RangeError("Buffer size must be a multiple of 32-bits");
    for (var t = 0; t < r; t += 4)
      U(this, t, t + 3), U(this, t + 1, t + 2);
    return this;
  }, "swap32");
  h.prototype.swap64 = /* @__PURE__ */ a(function() {
    var r = this.length;
    if (r % 8 !== 0)
      throw new RangeError("Buffer size must be a multiple of 64-bits");
    for (var t = 0; t < r; t += 8)
      U(this, t, t + 7), U(this, t + 1, t + 6), U(this, t + 2, t + 5), U(this, t + 3, t + 4);
    return this;
  }, "swap64");
  h.prototype.toString = /* @__PURE__ */ a(function() {
    var r = this.length;
    return r === 0 ? "" : arguments.length === 0 ? $(this, 0, r) : xr.apply(this, arguments);
  }, "toString");
  h.prototype.toLocaleString = h.prototype.toString;
  h.prototype.equals = /* @__PURE__ */ a(function(r) {
    if (!h.isBuffer(r)) throw new TypeError("Argument must be a Buffer");
    return this === r ? !0 : h.compare(this, r) === 0;
  }, "equals");
  h.prototype.inspect = /* @__PURE__ */ a(function() {
    var r = "", t = T.INSPECT_MAX_BYTES;
    return r = this.toString("hex", 0, t).replace(/(.{2})/g, "$1 ").trim(), this.length > t && (r += " ... "), "<Buffer " + r + ">";
  }, "inspect");
  z && (h.prototype[z] = h.prototype.inspect);
  h.prototype.compare = /* @__PURE__ */ a(function(r, t, n, e, u) {
    if (B(r, Uint8Array) && (r = h.from(r, r.offset, r.byteLength)), !h.isBuffer(r))
      throw new TypeError(
        'The "target" argument must be one of type Buffer or Uint8Array. Received type ' + typeof r
      );
    if (t === void 0 && (t = 0), n === void 0 && (n = r ? r.length : 0), e === void 0 && (e = 0), u === void 0 && (u = this.length), t < 0 || n > r.length || e < 0 || u > this.length)
      throw new RangeError("out of range index");
    if (e >= u && t >= n)
      return 0;
    if (e >= u)
      return -1;
    if (t >= n)
      return 1;
    if (t >>>= 0, n >>>= 0, e >>>= 0, u >>>= 0, this === r) return 0;
    for (var o = u - e, f = n - t, p = Math.min(o, f), l = this.slice(e, u), w = r.slice(t, n), c = 0; c < p; ++c)
      if (l[c] !== w[c]) {
        o = l[c], f = w[c];
        break;
      }
    return o < f ? -1 : f < o ? 1 : 0;
  }, "compare");
  function Q(i, r, t, n, e) {
    if (i.length === 0) return -1;
    if (typeof t == "string" ? (n = t, t = 0) : t > 2147483647 ? t = 2147483647 : t < -2147483648 && (t = -2147483648), t = +t, Y(t) && (t = e ? 0 : i.length - 1), t < 0 && (t = i.length + t), t >= i.length) {
      if (e) return -1;
      t = i.length - 1;
    } else if (t < 0)
      if (e) t = 0;
      else return -1;
    if (typeof r == "string" && (r = h.from(r, n)), h.isBuffer(r))
      return r.length === 0 ? -1 : J(i, r, t, n, e);
    if (typeof r == "number")
      return r = r & 255, typeof Uint8Array.prototype.indexOf == "function" ? e ? Uint8Array.prototype.indexOf.call(i, r, t) : Uint8Array.prototype.lastIndexOf.call(i, r, t) : J(i, [r], t, n, e);
    throw new TypeError("val must be string, number or Buffer");
  }
  a(Q, "bidirectionalIndexOf");
  function J(i, r, t, n, e) {
    var u = 1, o = i.length, f = r.length;
    if (n !== void 0 && (n = String(n).toLowerCase(), n === "ucs2" || n === "ucs-2" || n === "utf16le" || n === "utf-16le")) {
      if (i.length < 2 || r.length < 2)
        return -1;
      u = 2, o /= 2, f /= 2, t /= 2;
    }
    function p(x, I) {
      return u === 1 ? x[I] : x.readUInt16BE(I * u);
    }
    a(p, "read");
    var l;
    if (e) {
      var w = -1;
      for (l = t; l < o; l++)
        if (p(i, l) === p(r, w === -1 ? 0 : l - w)) {
          if (w === -1 && (w = l), l - w + 1 === f) return w * u;
        } else
          w !== -1 && (l -= l - w), w = -1;
    } else
      for (t + f > o && (t = o - f), l = t; l >= 0; l--) {
        for (var c = !0, F = 0; F < f; F++)
          if (p(i, l + F) !== p(r, F)) {
            c = !1;
            break;
          }
        if (c) return l;
      }
    return -1;
  }
  a(J, "arrayIndexOf");
  h.prototype.includes = /* @__PURE__ */ a(function(r, t, n) {
    return this.indexOf(r, t, n) !== -1;
  }, "includes");
  h.prototype.indexOf = /* @__PURE__ */ a(function(r, t, n) {
    return Q(this, r, t, n, !0);
  }, "indexOf");
  h.prototype.lastIndexOf = /* @__PURE__ */ a(function(r, t, n) {
    return Q(this, r, t, n, !1);
  }, "lastIndexOf");
  function Er(i, r, t, n) {
    t = Number(t) || 0;
    var e = i.length - t;
    n ? (n = Number(n), n > e && (n = e)) : n = e;
    var u = r.length;
    n > u / 2 && (n = u / 2);
    for (var o = 0; o < n; ++o) {
      var f = parseInt(r.substr(o * 2, 2), 16);
      if (Y(f)) return o;
      i[t + o] = f;
    }
    return o;
  }
  a(Er, "hexWrite");
  function Fr(i, r, t, n) {
    return S(_(r, i.length - t), i, t, n);
  }
  a(Fr, "utf8Write");
  function mr(i, r, t, n) {
    return S(Rr(r), i, t, n);
  }
  a(mr, "asciiWrite");
  function Br(i, r, t, n) {
    return S(tr(r), i, t, n);
  }
  a(Br, "base64Write");
  function Ar(i, r, t, n) {
    return S(Lr(r, i.length - t), i, t, n);
  }
  a(Ar, "ucs2Write");
  h.prototype.write = /* @__PURE__ */ a(function(r, t, n, e) {
    if (t === void 0)
      e = "utf8", n = this.length, t = 0;
    else if (n === void 0 && typeof t == "string")
      e = t, n = this.length, t = 0;
    else if (isFinite(t))
      t = t >>> 0, isFinite(n) ? (n = n >>> 0, e === void 0 && (e = "utf8")) : (e = n, n = void 0);
    else
      throw new Error(
        "Buffer.write(string, encoding, offset[, length]) is no longer supported"
      );
    var u = this.length - t;
    if ((n === void 0 || n > u) && (n = u), r.length > 0 && (n < 0 || t < 0) || t > this.length)
      throw new RangeError("Attempt to write outside buffer bounds");
    e || (e = "utf8");
    for (var o = !1; ; )
      switch (e) {
        case "hex":
          return Er(this, r, t, n);
        case "utf8":
        case "utf-8":
          return Fr(this, r, t, n);
        case "ascii":
        case "latin1":
        case "binary":
          return mr(this, r, t, n);
        case "base64":
          return Br(this, r, t, n);
        case "ucs2":
        case "ucs-2":
        case "utf16le":
        case "utf-16le":
          return Ar(this, r, t, n);
        default:
          if (o) throw new TypeError("Unknown encoding: " + e);
          e = ("" + e).toLowerCase(), o = !0;
      }
  }, "write");
  h.prototype.toJSON = /* @__PURE__ */ a(function() {
    return {
      type: "Buffer",
      data: Array.prototype.slice.call(this._arr || this, 0)
    };
  }, "toJSON");
  function gr(i, r, t) {
    return r === 0 && t === i.length ? k.fromByteArray(i) : k.fromByteArray(i.slice(r, t));
  }
  a(gr, "base64Slice");
  function $(i, r, t) {
    t = Math.min(i.length, t);
    for (var n = [], e = r; e < t; ) {
      var u = i[e], o = null, f = u > 239 ? 4 : u > 223 ? 3 : u > 191 ? 2 : 1;
      if (e + f <= t) {
        var p, l, w, c;
        switch (f) {
          case 1:
            u < 128 && (o = u);
            break;
          case 2:
            p = i[e + 1], (p & 192) === 128 && (c = (u & 31) << 6 | p & 63, c > 127 && (o = c));
            break;
          case 3:
            p = i[e + 1], l = i[e + 2], (p & 192) === 128 && (l & 192) === 128 && (c = (u & 15) << 12 | (p & 63) << 6 | l & 63, c > 2047 && (c < 55296 || c > 57343) && (o = c));
            break;
          case 4:
            p = i[e + 1], l = i[e + 2], w = i[e + 3], (p & 192) === 128 && (l & 192) === 128 && (w & 192) === 128 && (c = (u & 15) << 18 | (p & 63) << 12 | (l & 63) << 6 | w & 63, c > 65535 && c < 1114112 && (o = c));
        }
      }
      o === null ? (o = 65533, f = 1) : o > 65535 && (o -= 65536, n.push(o >>> 10 & 1023 | 55296), o = 56320 | o & 1023), n.push(o), e += f;
    }
    return Ur(n);
  }
  a($, "utf8Slice");
  var V = 4096;
  function Ur(i) {
    var r = i.length;
    if (r <= V)
      return String.fromCharCode.apply(String, i);
    for (var t = "", n = 0; n < r; )
      t += String.fromCharCode.apply(
        String,
        i.slice(n, n += V)
      );
    return t;
  }
  a(Ur, "decodeCodePointsArray");
  function Ir(i, r, t) {
    var n = "";
    t = Math.min(i.length, t);
    for (var e = r; e < t; ++e)
      n += String.fromCharCode(i[e] & 127);
    return n;
  }
  a(Ir, "asciiSlice");
  function vr(i, r, t) {
    var n = "";
    t = Math.min(i.length, t);
    for (var e = r; e < t; ++e)
      n += String.fromCharCode(i[e]);
    return n;
  }
  a(vr, "latin1Slice");
  function Tr(i, r, t) {
    var n = i.length;
    (!r || r < 0) && (r = 0), (!t || t < 0 || t > n) && (t = n);
    for (var e = "", u = r; u < t; ++u)
      e += Mr[i[u]];
    return e;
  }
  a(Tr, "hexSlice");
  function Cr(i, r, t) {
    for (var n = i.slice(r, t), e = "", u = 0; u < n.length - 1; u += 2)
      e += String.fromCharCode(n[u] + n[u + 1] * 256);
    return e;
  }
  a(Cr, "utf16leSlice");
  h.prototype.slice = /* @__PURE__ */ a(function(r, t) {
    var n = this.length;
    r = ~~r, t = t === void 0 ? n : ~~t, r < 0 ? (r += n, r < 0 && (r = 0)) : r > n && (r = n), t < 0 ? (t += n, t < 0 && (t = 0)) : t > n && (t = n), t < r && (t = r);
    var e = this.subarray(r, t);
    return Object.setPrototypeOf(e, h.prototype), e;
  }, "slice");
  function s(i, r, t) {
    if (i % 1 !== 0 || i < 0) throw new RangeError("offset is not uint");
    if (i + r > t) throw new RangeError("Trying to access beyond buffer length");
  }
  a(s, "checkOffset");
  h.prototype.readUintLE = h.prototype.readUIntLE = /* @__PURE__ */ a(function(r, t, n) {
    r = r >>> 0, t = t >>> 0, n || s(r, t, this.length);
    for (var e = this[r], u = 1, o = 0; ++o < t && (u *= 256); )
      e += this[r + o] * u;
    return e;
  }, "readUIntLE");
  h.prototype.readUintBE = h.prototype.readUIntBE = /* @__PURE__ */ a(function(r, t, n) {
    r = r >>> 0, t = t >>> 0, n || s(r, t, this.length);
    for (var e = this[r + --t], u = 1; t > 0 && (u *= 256); )
      e += this[r + --t] * u;
    return e;
  }, "readUIntBE");
  h.prototype.readUint8 = h.prototype.readUInt8 = /* @__PURE__ */ a(function(r, t) {
    return r = r >>> 0, t || s(r, 1, this.length), this[r];
  }, "readUInt8");
  h.prototype.readUint16LE = h.prototype.readUInt16LE = /* @__PURE__ */ a(function(r, t) {
    return r = r >>> 0, t || s(r, 2, this.length), this[r] | this[r + 1] << 8;
  }, "readUInt16LE");
  h.prototype.readUint16BE = h.prototype.readUInt16BE = /* @__PURE__ */ a(function(r, t) {
    return r = r >>> 0, t || s(r, 2, this.length), this[r] << 8 | this[r + 1];
  }, "readUInt16BE");
  h.prototype.readUint32LE = h.prototype.readUInt32LE = /* @__PURE__ */ a(function(r, t) {
    return r = r >>> 0, t || s(r, 4, this.length), (this[r] | this[r + 1] << 8 | this[r + 2] << 16) + this[r + 3] * 16777216;
  }, "readUInt32LE");
  h.prototype.readUint32BE = h.prototype.readUInt32BE = /* @__PURE__ */ a(function(r, t) {
    return r = r >>> 0, t || s(r, 4, this.length), this[r] * 16777216 + (this[r + 1] << 16 | this[r + 2] << 8 | this[r + 3]);
  }, "readUInt32BE");
  h.prototype.readIntLE = /* @__PURE__ */ a(function(r, t, n) {
    r = r >>> 0, t = t >>> 0, n || s(r, t, this.length);
    for (var e = this[r], u = 1, o = 0; ++o < t && (u *= 256); )
      e += this[r + o] * u;
    return u *= 128, e >= u && (e -= Math.pow(2, 8 * t)), e;
  }, "readIntLE");
  h.prototype.readIntBE = /* @__PURE__ */ a(function(r, t, n) {
    r = r >>> 0, t = t >>> 0, n || s(r, t, this.length);
    for (var e = t, u = 1, o = this[r + --e]; e > 0 && (u *= 256); )
      o += this[r + --e] * u;
    return u *= 128, o >= u && (o -= Math.pow(2, 8 * t)), o;
  }, "readIntBE");
  h.prototype.readInt8 = /* @__PURE__ */ a(function(r, t) {
    return r = r >>> 0, t || s(r, 1, this.length), this[r] & 128 ? (255 - this[r] + 1) * -1 : this[r];
  }, "readInt8");
  h.prototype.readInt16LE = /* @__PURE__ */ a(function(r, t) {
    r = r >>> 0, t || s(r, 2, this.length);
    var n = this[r] | this[r + 1] << 8;
    return n & 32768 ? n | 4294901760 : n;
  }, "readInt16LE");
  h.prototype.readInt16BE = /* @__PURE__ */ a(function(r, t) {
    r = r >>> 0, t || s(r, 2, this.length);
    var n = this[r + 1] | this[r] << 8;
    return n & 32768 ? n | 4294901760 : n;
  }, "readInt16BE");
  h.prototype.readInt32LE = /* @__PURE__ */ a(function(r, t) {
    return r = r >>> 0, t || s(r, 4, this.length), this[r] | this[r + 1] << 8 | this[r + 2] << 16 | this[r + 3] << 24;
  }, "readInt32LE");
  h.prototype.readInt32BE = /* @__PURE__ */ a(function(r, t) {
    return r = r >>> 0, t || s(r, 4, this.length), this[r] << 24 | this[r + 1] << 16 | this[r + 2] << 8 | this[r + 3];
  }, "readInt32BE");
  h.prototype.readFloatLE = /* @__PURE__ */ a(function(r, t) {
    return r = r >>> 0, t || s(r, 4, this.length), v.read(this, r, !0, 23, 4);
  }, "readFloatLE");
  h.prototype.readFloatBE = /* @__PURE__ */ a(function(r, t) {
    return r = r >>> 0, t || s(r, 4, this.length), v.read(this, r, !1, 23, 4);
  }, "readFloatBE");
  h.prototype.readDoubleLE = /* @__PURE__ */ a(function(r, t) {
    return r = r >>> 0, t || s(r, 8, this.length), v.read(this, r, !0, 52, 8);
  }, "readDoubleLE");
  h.prototype.readDoubleBE = /* @__PURE__ */ a(function(r, t) {
    return r = r >>> 0, t || s(r, 8, this.length), v.read(this, r, !1, 52, 8);
  }, "readDoubleBE");
  function y(i, r, t, n, e, u) {
    if (!h.isBuffer(i)) throw new TypeError('"buffer" argument must be a Buffer instance');
    if (r > e || r < u) throw new RangeError('"value" argument is out of bounds');
    if (t + n > i.length) throw new RangeError("Index out of range");
  }
  a(y, "checkInt");
  h.prototype.writeUintLE = h.prototype.writeUIntLE = /* @__PURE__ */ a(function(r, t, n, e) {
    if (r = +r, t = t >>> 0, n = n >>> 0, !e) {
      var u = Math.pow(2, 8 * n) - 1;
      y(this, r, t, n, u, 0);
    }
    var o = 1, f = 0;
    for (this[t] = r & 255; ++f < n && (o *= 256); )
      this[t + f] = r / o & 255;
    return t + n;
  }, "writeUIntLE");
  h.prototype.writeUintBE = h.prototype.writeUIntBE = /* @__PURE__ */ a(function(r, t, n, e) {
    if (r = +r, t = t >>> 0, n = n >>> 0, !e) {
      var u = Math.pow(2, 8 * n) - 1;
      y(this, r, t, n, u, 0);
    }
    var o = n - 1, f = 1;
    for (this[t + o] = r & 255; --o >= 0 && (f *= 256); )
      this[t + o] = r / f & 255;
    return t + n;
  }, "writeUIntBE");
  h.prototype.writeUint8 = h.prototype.writeUInt8 = /* @__PURE__ */ a(function(r, t, n) {
    return r = +r, t = t >>> 0, n || y(this, r, t, 1, 255, 0), this[t] = r & 255, t + 1;
  }, "writeUInt8");
  h.prototype.writeUint16LE = h.prototype.writeUInt16LE = /* @__PURE__ */ a(function(r, t, n) {
    return r = +r, t = t >>> 0, n || y(this, r, t, 2, 65535, 0), this[t] = r & 255, this[t + 1] = r >>> 8, t + 2;
  }, "writeUInt16LE");
  h.prototype.writeUint16BE = h.prototype.writeUInt16BE = /* @__PURE__ */ a(function(r, t, n) {
    return r = +r, t = t >>> 0, n || y(this, r, t, 2, 65535, 0), this[t] = r >>> 8, this[t + 1] = r & 255, t + 2;
  }, "writeUInt16BE");
  h.prototype.writeUint32LE = h.prototype.writeUInt32LE = /* @__PURE__ */ a(function(r, t, n) {
    return r = +r, t = t >>> 0, n || y(this, r, t, 4, 4294967295, 0), this[t + 3] = r >>> 24, this[t + 2] = r >>> 16, this[t + 1] = r >>> 8, this[t] = r & 255, t + 4;
  }, "writeUInt32LE");
  h.prototype.writeUint32BE = h.prototype.writeUInt32BE = /* @__PURE__ */ a(function(r, t, n) {
    return r = +r, t = t >>> 0, n || y(this, r, t, 4, 4294967295, 0), this[t] = r >>> 24, this[t + 1] = r >>> 16, this[t + 2] = r >>> 8, this[t + 3] = r & 255, t + 4;
  }, "writeUInt32BE");
  h.prototype.writeIntLE = /* @__PURE__ */ a(function(r, t, n, e) {
    if (r = +r, t = t >>> 0, !e) {
      var u = Math.pow(2, 8 * n - 1);
      y(this, r, t, n, u - 1, -u);
    }
    var o = 0, f = 1, p = 0;
    for (this[t] = r & 255; ++o < n && (f *= 256); )
      r < 0 && p === 0 && this[t + o - 1] !== 0 && (p = 1), this[t + o] = (r / f >> 0) - p & 255;
    return t + n;
  }, "writeIntLE");
  h.prototype.writeIntBE = /* @__PURE__ */ a(function(r, t, n, e) {
    if (r = +r, t = t >>> 0, !e) {
      var u = Math.pow(2, 8 * n - 1);
      y(this, r, t, n, u - 1, -u);
    }
    var o = n - 1, f = 1, p = 0;
    for (this[t + o] = r & 255; --o >= 0 && (f *= 256); )
      r < 0 && p === 0 && this[t + o + 1] !== 0 && (p = 1), this[t + o] = (r / f >> 0) - p & 255;
    return t + n;
  }, "writeIntBE");
  h.prototype.writeInt8 = /* @__PURE__ */ a(function(r, t, n) {
    return r = +r, t = t >>> 0, n || y(this, r, t, 1, 127, -128), r < 0 && (r = 255 + r + 1), this[t] = r & 255, t + 1;
  }, "writeInt8");
  h.prototype.writeInt16LE = /* @__PURE__ */ a(function(r, t, n) {
    return r = +r, t = t >>> 0, n || y(this, r, t, 2, 32767, -32768), this[t] = r & 255, this[t + 1] = r >>> 8, t + 2;
  }, "writeInt16LE");
  h.prototype.writeInt16BE = /* @__PURE__ */ a(function(r, t, n) {
    return r = +r, t = t >>> 0, n || y(this, r, t, 2, 32767, -32768), this[t] = r >>> 8, this[t + 1] = r & 255, t + 2;
  }, "writeInt16BE");
  h.prototype.writeInt32LE = /* @__PURE__ */ a(function(r, t, n) {
    return r = +r, t = t >>> 0, n || y(this, r, t, 4, 2147483647, -2147483648), this[t] = r & 255, this[t + 1] = r >>> 8, this[t + 2] = r >>> 16, this[t + 3] = r >>> 24, t + 4;
  }, "writeInt32LE");
  h.prototype.writeInt32BE = /* @__PURE__ */ a(function(r, t, n) {
    return r = +r, t = t >>> 0, n || y(this, r, t, 4, 2147483647, -2147483648), r < 0 && (r = 4294967295 + r + 1), this[t] = r >>> 24, this[t + 1] = r >>> 16, this[t + 2] = r >>> 8, this[t + 3] = r & 255, t + 4;
  }, "writeInt32BE");
  function j(i, r, t, n, e, u) {
    if (t + n > i.length) throw new RangeError("Index out of range");
    if (t < 0) throw new RangeError("Index out of range");
  }
  a(j, "checkIEEE754");
  function P(i, r, t, n, e) {
    return r = +r, t = t >>> 0, e || j(i, r, t, 4, 34028234663852886e22, -34028234663852886e22), v.write(i, r, t, n, 23, 4), t + 4;
  }
  a(P, "writeFloat");
  h.prototype.writeFloatLE = /* @__PURE__ */ a(function(r, t, n) {
    return P(this, r, t, !0, n);
  }, "writeFloatLE");
  h.prototype.writeFloatBE = /* @__PURE__ */ a(function(r, t, n) {
    return P(this, r, t, !1, n);
  }, "writeFloatBE");
  function rr(i, r, t, n, e) {
    return r = +r, t = t >>> 0, e || j(i, r, t, 8, 17976931348623157e292, -17976931348623157e292), v.write(i, r, t, n, 52, 8), t + 8;
  }
  a(rr, "writeDouble");
  h.prototype.writeDoubleLE = /* @__PURE__ */ a(function(r, t, n) {
    return rr(this, r, t, !0, n);
  }, "writeDoubleLE");
  h.prototype.writeDoubleBE = /* @__PURE__ */ a(function(r, t, n) {
    return rr(this, r, t, !1, n);
  }, "writeDoubleBE");
  h.prototype.copy = /* @__PURE__ */ a(function(r, t, n, e) {
    if (!h.isBuffer(r)) throw new TypeError("argument should be a Buffer");
    if (n || (n = 0), !e && e !== 0 && (e = this.length), t >= r.length && (t = r.length), t || (t = 0), e > 0 && e < n && (e = n), e === n || r.length === 0 || this.length === 0) return 0;
    if (t < 0)
      throw new RangeError("targetStart out of bounds");
    if (n < 0 || n >= this.length) throw new RangeError("Index out of range");
    if (e < 0) throw new RangeError("sourceEnd out of bounds");
    e > this.length && (e = this.length), r.length - t < e - n && (e = r.length - t + n);
    var u = e - n;
    return this === r && typeof Uint8Array.prototype.copyWithin == "function" ? this.copyWithin(t, n, e) : Uint8Array.prototype.set.call(
      r,
      this.subarray(n, e),
      t
    ), u;
  }, "copy");
  h.prototype.fill = /* @__PURE__ */ a(function(r, t, n, e) {
    if (typeof r == "string") {
      if (typeof t == "string" ? (e = t, t = 0, n = this.length) : typeof n == "string" && (e = n, n = this.length), e !== void 0 && typeof e != "string")
        throw new TypeError("encoding must be a string");
      if (typeof e == "string" && !h.isEncoding(e))
        throw new TypeError("Unknown encoding: " + e);
      if (r.length === 1) {
        var u = r.charCodeAt(0);
        (e === "utf8" && u < 128 || e === "latin1") && (r = u);
      }
    } else typeof r == "number" ? r = r & 255 : typeof r == "boolean" && (r = Number(r));
    if (t < 0 || this.length < t || this.length < n)
      throw new RangeError("Out of range index");
    if (n <= t)
      return this;
    t = t >>> 0, n = n === void 0 ? this.length : n >>> 0, r || (r = 0);
    var o;
    if (typeof r == "number")
      for (o = t; o < n; ++o)
        this[o] = r;
    else {
      var f = h.isBuffer(r) ? r : h.from(r, e), p = f.length;
      if (p === 0)
        throw new TypeError('The value "' + r + '" is invalid for argument "value"');
      for (o = 0; o < n - t; ++o)
        this[o + t] = f[o % p];
    }
    return this;
  }, "fill");
  var dr = /[^+/0-9A-Za-z-_]/g;
  function Sr(i) {
    if (i = i.split("=")[0], i = i.trim().replace(dr, ""), i.length < 2) return "";
    for (; i.length % 4 !== 0; )
      i = i + "=";
    return i;
  }
  a(Sr, "base64clean");
  function _(i, r) {
    r = r || 1 / 0;
    for (var t, n = i.length, e = null, u = [], o = 0; o < n; ++o) {
      if (t = i.charCodeAt(o), t > 55295 && t < 57344) {
        if (!e) {
          if (t > 56319) {
            (r -= 3) > -1 && u.push(239, 191, 189);
            continue;
          } else if (o + 1 === n) {
            (r -= 3) > -1 && u.push(239, 191, 189);
            continue;
          }
          e = t;
          continue;
        }
        if (t < 56320) {
          (r -= 3) > -1 && u.push(239, 191, 189), e = t;
          continue;
        }
        t = (e - 55296 << 10 | t - 56320) + 65536;
      } else e && (r -= 3) > -1 && u.push(239, 191, 189);
      if (e = null, t < 128) {
        if ((r -= 1) < 0) break;
        u.push(t);
      } else if (t < 2048) {
        if ((r -= 2) < 0) break;
        u.push(
          t >> 6 | 192,
          t & 63 | 128
        );
      } else if (t < 65536) {
        if ((r -= 3) < 0) break;
        u.push(
          t >> 12 | 224,
          t >> 6 & 63 | 128,
          t & 63 | 128
        );
      } else if (t < 1114112) {
        if ((r -= 4) < 0) break;
        u.push(
          t >> 18 | 240,
          t >> 12 & 63 | 128,
          t >> 6 & 63 | 128,
          t & 63 | 128
        );
      } else
        throw new Error("Invalid code point");
    }
    return u;
  }
  a(_, "utf8ToBytes");
  function Rr(i) {
    for (var r = [], t = 0; t < i.length; ++t)
      r.push(i.charCodeAt(t) & 255);
    return r;
  }
  a(Rr, "asciiToBytes");
  function Lr(i, r) {
    for (var t, n, e, u = [], o = 0; o < i.length && !((r -= 2) < 0); ++o)
      t = i.charCodeAt(o), n = t >> 8, e = t % 256, u.push(e), u.push(n);
    return u;
  }
  a(Lr, "utf16leToBytes");
  function tr(i) {
    return k.toByteArray(Sr(i));
  }
  a(tr, "base64ToBytes");
  function S(i, r, t, n) {
    for (var e = 0; e < n && !(e + t >= r.length || e >= i.length); ++e)
      r[e + t] = i[e];
    return e;
  }
  a(S, "blitBuffer");
  function B(i, r) {
    return i instanceof r || i != null && i.constructor != null && i.constructor.name != null && i.constructor.name === r.name;
  }
  a(B, "isInstance");
  function Y(i) {
    return i !== i;
  }
  a(Y, "numberIsNaN");
  var Mr = function() {
    for (var i = "0123456789abcdef", r = new Array(256), t = 0; t < 16; ++t)
      for (var n = t * 16, e = 0; e < 16; ++e)
        r[n + e] = i[t] + i[e];
    return r;
  }();
});
export default kr();
/*! Bundled license information:

ieee754/index.js:
  (*! ieee754. BSD-3-Clause License. Feross Aboukhadijeh <https://feross.org/opensource> *)

buffer/index.js:
  (*!
   * The buffer module from node.js, for the browser.
   *
   * @author   Feross Aboukhadijeh <https://feross.org>
   * @license  MIT
   *)
*/
//# sourceMappingURL=GYK5RQRH.js.map
