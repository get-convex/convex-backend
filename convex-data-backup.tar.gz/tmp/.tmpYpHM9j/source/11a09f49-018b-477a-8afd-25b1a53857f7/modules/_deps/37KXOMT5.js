import {
  a,
  e as l
} from "./IVQGLTSC.js";
import {
  d as n
} from "./75JH2J25.js";
import {
  j as e,
  n as u
} from "./3TDUHHJO.js";
import {
  a as r
} from "./RUVYHBJQ.js";

// convex/videos/processing.ts
u();
l();
var f = n({
  args: {
    videoId: e.id("videos"),
    transcriptionType: e.optional(e.string())
  },
  returns: e.object({
    success: e.boolean(),
    transcriptionId: e.optional(e.id("transcriptions")),
    message: e.string()
  }),
  handler: /* @__PURE__ */ r(async (s, o) => {
    try {
      if (!await s.db.get(o.videoId))
        return {
          success: !1,
          message: "\u52D5\u753B\u304C\u898B\u3064\u304B\u308A\u307E\u305B\u3093"
        };
      let t = await s.db.query("transcriptions").withIndex("by_video_id", (c) => c.eq("video_id", o.videoId)).first();
      return t && t.status === "completed" ? {
        success: !0,
        message: "\u6587\u5B57\u8D77\u3053\u3057\u306F\u65E2\u306B\u5B8C\u4E86\u3057\u3066\u3044\u307E\u3059",
        transcriptionId: t._id
      } : await s.runMutation(a.transcriptions.startBasicTranscription, {
        resourceType: "video",
        resourceId: o.videoId,
        text: ""
        // 基本的な文字起こしAPIは空文字列を送信
      });
    } catch (i) {
      return console.error("[startTranscription] \u30A8\u30E9\u30FC:", i), {
        success: !1,
        message: "\u6587\u5B57\u8D77\u3053\u3057\u306E\u958B\u59CB\u4E2D\u306B\u30A8\u30E9\u30FC\u304C\u767A\u751F\u3057\u307E\u3057\u305F"
      };
    }
  }, "handler")
}), g = n({
  args: {
    videoId: e.id("videos"),
    evaluationCriteria: e.optional(e.array(e.string()))
  },
  returns: e.object({
    success: e.boolean(),
    message: e.string()
  }),
  handler: /* @__PURE__ */ r(async (s, o) => {
    try {
      if (!await s.db.get(o.videoId))
        return {
          success: !1,
          message: "\u52D5\u753B\u304C\u898B\u3064\u304B\u308A\u307E\u305B\u3093"
        };
      let t = await s.db.query("transcriptions").withIndex("by_video_id", (d) => d.eq("video_id", o.videoId)).first();
      return !t || t.status !== "completed" ? {
        success: !1,
        message: "\u6587\u5B57\u8D77\u3053\u3057\u304C\u5B8C\u4E86\u3057\u3066\u3044\u307E\u305B\u3093"
      } : (console.log(`[reEvaluate] \u518D\u8A55\u4FA1\u958B\u59CB (Video ID: ${o.videoId})`), {
        success: !0,
        message: "\u518D\u8A55\u4FA1\u51E6\u7406\u3092\u958B\u59CB\u3057\u307E\u3057\u305F",
        evaluationId: `eval-${Date.now()}-${o.videoId}`
      });
    } catch (i) {
      return console.error("[reEvaluate] \u30A8\u30E9\u30FC:", i), {
        success: !1,
        message: "\u518D\u8A55\u4FA1\u306E\u958B\u59CB\u4E2D\u306B\u30A8\u30E9\u30FC\u304C\u767A\u751F\u3057\u307E\u3057\u305F"
      };
    }
  }, "handler")
}), b = n({
  args: {
    videoId: e.id("videos"),
    options: e.optional(
      e.object({
        transcription: e.optional(e.boolean()),
        evaluation: e.optional(e.boolean()),
        summary: e.optional(e.boolean())
      })
    )
  },
  returns: e.object({
    success: e.boolean(),
    message: e.string()
  }),
  handler: /* @__PURE__ */ r(async (s, o) => {
    try {
      if (!await s.db.get(o.videoId))
        return {
          success: !1,
          message: "\u52D5\u753B\u304C\u898B\u3064\u304B\u308A\u307E\u305B\u3093"
        };
      let t = o.options || {};
      return t.transcription && await s.runMutation(a.videos.processing.startTranscription, {
        videoId: o.videoId,
        options: {
          enableSpeakerDiarization: !0,
          enableAiEvaluation: !0,
          autoStartAnalysis: !0
        }
      }), t.evaluation && await s.runMutation(a.videos.processing.reEvaluate, {
        videoId: o.videoId
      }), console.log(`[reprocess] \u518D\u51E6\u7406\u958B\u59CB (Video ID: ${o.videoId})`), {
        success: !0,
        message: "\u518D\u51E6\u7406\u3092\u958B\u59CB\u3057\u307E\u3057\u305F"
      };
    } catch (i) {
      return console.error("[reprocess] \u30A8\u30E9\u30FC:", i), {
        success: !1,
        message: "\u518D\u51E6\u7406\u306E\u958B\u59CB\u4E2D\u306B\u30A8\u30E9\u30FC\u304C\u767A\u751F\u3057\u307E\u3057\u305F"
      };
    }
  }, "handler")
});

export {
  f as a,
  g as b,
  b as c
};
//# sourceMappingURL=37KXOMT5.js.map
