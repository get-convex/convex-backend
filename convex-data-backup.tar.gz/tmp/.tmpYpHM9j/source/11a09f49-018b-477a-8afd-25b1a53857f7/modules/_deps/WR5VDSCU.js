import {
  b as o
} from "./SZVQRWFS.js";
import {
  l as a,
  n as u
} from "./3TDUHHJO.js";
import {
  a as n
} from "./RUVYHBJQ.js";

// convex/lib/security.ts
u();
async function f(e) {
  return await o(e);
}
n(f, "requireUser");
async function l(e) {
  try {
    return await o(e);
  } catch {
    return null;
  }
}
n(l, "getCurrentUser");
function p(e, t = "\u30A8\u30E9\u30FC\u304C\u767A\u751F\u3057\u307E\u3057\u305F") {
  return e instanceof a ? e.message : (e instanceof Error, t);
}
n(p, "createSafeErrorMessage");
function d(e) {
  return typeof e != "string" ? "" : e.trim().replace(/<script[^>]*>.*?<\/script>/gi, "").replace(/<[^>]*>/g, "").replace(/javascript:/gi, "").replace(/on\w+\s*=\s*[^>]*/gi, "").substring(0, 1e3);
}
n(d, "sanitizeUserInput");
function m(e) {
  if (typeof e != "string")
    return "";
  let t = {
    "&": "&amp;",
    "<": "&lt;",
    ">": "&gt;",
    '"': "&quot;",
    "'": "&#39;",
    "/": "&#x2F;"
  };
  return e.replace(/[&<>"'\/]/g, (i) => t[i]);
}
n(m, "escapeHtml");
function y(e) {
  return typeof e != "string" ? "" : e.replace(/'/g, "''");
}
n(y, "escapeSqlString");
function x(e) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(e);
}
n(x, "isValidEmail");
function h(e) {
  return /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)[a-zA-Z\d@$!%*?&]{8,}$/.test(e);
}
n(h, "isStrongPassword");
function S(e) {
  let t = /^(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/, i = /^(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}$/;
  return t.test(e) || i.test(e);
}
n(S, "isValidIP");
function $(e) {
  try {
    return new URL(e), !0;
  } catch {
    return !1;
  }
}
n($, "isValidUrl");
function b(e, t) {
  try {
    return JSON.parse(e);
  } catch {
    return t;
  }
}
n(b, "safeJsonParse");
function w(e) {
  if (e == null)
    return e;
  if (typeof e == "object" && !Array.isArray(e)) {
    let t = { ...e };
    return delete t.password, delete t.api_key, delete t.secret, delete t.token, t;
  }
  return e;
}
n(w, "sanitizeDbResult");
function A(e) {
  return e.replace(/[<>:"/\\|?*]/g, "").replace(/\s+/g, "_").substring(0, 255);
}
n(A, "sanitizeFileName");
function M(e, t, i = "hour") {
  let r = /* @__PURE__ */ new Date(), s;
  switch (i) {
    case "minute":
      s = `${r.getFullYear()}-${r.getMonth()}-${r.getDate()}-${r.getHours()}-${r.getMinutes()}`;
      break;
    case "hour":
      s = `${r.getFullYear()}-${r.getMonth()}-${r.getDate()}-${r.getHours()}`;
      break;
    case "day":
      s = `${r.getFullYear()}-${r.getMonth()}-${r.getDate()}`;
      break;
  }
  return `rate_limit:${e}:${t}:${s}`;
}
n(M, "createRateLimitKey");
function R() {
  return {
    "X-Content-Type-Options": "nosniff",
    "X-Frame-Options": "DENY",
    "X-XSS-Protection": "1; mode=block",
    "Strict-Transport-Security": "max-age=31536000; includeSubDomains",
    "Content-Security-Policy": "default-src 'self'",
    "Referrer-Policy": "strict-origin-when-cross-origin"
  };
}
n(R, "getSecurityHeaders");
function k() {
  return Math.random().toString(36).substring(2, 15) + Math.random().toString(36).substring(2, 15);
}
n(k, "generateCsrfToken");
function C(e = 32) {
  let t = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789", i = "";
  for (let r = 0; r < e; r++)
    i += t.charAt(Math.floor(Math.random() * t.length));
  return i;
}
n(C, "generateSecureRandomString");
function P(e) {
  let t = 0;
  for (let i = 0; i < e.length; i++) {
    let r = e.charCodeAt(i);
    t = (t << 5) - t + r, t = t & t;
  }
  return t.toString();
}
n(P, "hashPassword");
function U(e) {
  if (typeof e != "object" || e === null)
    return e;
  let t = { ...e }, i = ["password", "token", "api_key", "secret", "credit_card", "ssn"];
  for (let r of i)
    r in t && (t[r] = "***MASKED***");
  return t;
}
n(U, "maskSensitiveData");

export {
  f as a,
  l as b,
  p as c,
  d,
  m as e,
  y as f,
  x as g,
  h,
  S as i,
  $ as j,
  b as k,
  w as l,
  A as m,
  M as n,
  R as o,
  k as p,
  C as q,
  P as r,
  U as s
};
//# sourceMappingURL=WR5VDSCU.js.map
