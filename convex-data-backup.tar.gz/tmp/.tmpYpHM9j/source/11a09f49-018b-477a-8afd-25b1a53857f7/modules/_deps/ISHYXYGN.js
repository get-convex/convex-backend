import {
  j as t,
  n as m
} from "./3TDUHHJO.js";
import {
  a as r
} from "./RUVYHBJQ.js";

// convex/lib/apiResponse.ts
m();
var l = /* @__PURE__ */ r((e) => t.object({
  success: t.boolean(),
  data: t.optional(e),
  error: t.optional(t.string()),
  meta: t.optional(
    t.object({
      pagination: t.optional(
        t.object({
          page: t.number(),
          limit: t.number(),
          total: t.number(),
          totalPages: t.number()
        })
      ),
      timestamp: t.optional(t.number()),
      version: t.optional(t.string()),
      errorCode: t.optional(t.string()),
      statusCode: t.optional(t.number()),
      details: t.optional(t.any()),
      correlationId: t.optional(t.string())
    })
  )
}), "standardApiResponseValidator"), b = /* @__PURE__ */ r((e) => t.object({
  success: t.boolean(),
  data: t.array(e),
  error: t.optional(t.string()),
  meta: t.object({
    pagination: t.object({
      page: t.number(),
      limit: t.number(),
      total: t.number(),
      totalPages: t.number()
    }),
    timestamp: t.optional(t.number()),
    version: t.optional(t.string()),
    errorCode: t.optional(t.string()),
    statusCode: t.optional(t.number()),
    details: t.optional(t.any()),
    correlationId: t.optional(t.string())
  })
}), "paginatedApiResponseValidator");
function o(e, n) {
  return {
    success: !0,
    data: e,
    meta: {
      timestamp: Date.now(),
      version: "1.0",
      ...n
    }
  };
}
r(o, "createSuccessResponse");
function g(e, n) {
  return {
    success: !0,
    data: e,
    meta: {
      pagination: n,
      timestamp: Date.now(),
      version: "1.0"
    }
  };
}
r(g, "createPaginatedResponse");
function s(e, n) {
  return {
    success: !1,
    error: e,
    meta: {
      timestamp: Date.now(),
      version: "1.0",
      ...n
    }
  };
}
r(s, "createErrorResponse");
function f(e) {
  return o({
    message: e || "\u6B63\u5E38\u306B\u524A\u9664\u3055\u308C\u307E\u3057\u305F"
  });
}
r(f, "createDeleteResponse");
function T(e, n) {
  return o({
    id: e,
    message: n || "\u6B63\u5E38\u306B\u4F5C\u6210\u3055\u308C\u307E\u3057\u305F"
  });
}
r(T, "createCreateResponse");
function x(e, n) {
  return o({
    ...e,
    message: n || "\u6B63\u5E38\u306B\u66F4\u65B0\u3055\u308C\u307E\u3057\u305F"
  });
}
r(x, "createUpdateResponse");
function A(e, n = "\u30EA\u30BD\u30FC\u30B9") {
  return e ? o(e) : s(`${n}\u304C\u898B\u3064\u304B\u308A\u307E\u305B\u3093`);
}
r(A, "createResourceResponse");
function S(e = 1, n = 20, a) {
  let p = Math.max(1, e), i = Math.min(Math.max(1, n), 100), u = Math.ceil(a / i);
  return {
    page: p,
    limit: i,
    total: a,
    totalPages: u
  };
}
r(S, "calculatePagination");
function P(e, n) {
  return (Math.max(1, e) - 1) * Math.max(1, n);
}
r(P, "calculateOffset");
async function R(e, n = "\u64CD\u4F5C\u4E2D\u306B\u30A8\u30E9\u30FC\u304C\u767A\u751F\u3057\u307E\u3057\u305F") {
  try {
    let a = await e();
    return o(a);
  } catch (a) {
    return console.error("API Operation Error:", a), s(a instanceof Error ? a.message : n);
  }
}
r(R, "withStandardResponse");
function d(e) {
  return typeof e == "object" && e !== null && typeof e.success == "boolean" && (e.data !== void 0 || e.error !== void 0);
}
r(d, "isStandardApiResponse");
function v(e, n) {
  return d(e) ? e : e && typeof e == "object" ? "success" in e ? {
    success: e.success,
    data: n ? e[n] : e.data,
    error: e.success ? void 0 : e.message,
    meta: {
      timestamp: Date.now(),
      version: "1.0"
    }
  } : o(e) : e == null ? s("\u30C7\u30FC\u30BF\u304C\u898B\u3064\u304B\u308A\u307E\u305B\u3093") : o(e);
}
r(v, "convertLegacyResponse");

export {
  l as a,
  b,
  o as c,
  g as d,
  s as e,
  f,
  T as g,
  x as h,
  A as i,
  S as j,
  P as k,
  R as l,
  d as m,
  v as n
};
//# sourceMappingURL=ISHYXYGN.js.map
