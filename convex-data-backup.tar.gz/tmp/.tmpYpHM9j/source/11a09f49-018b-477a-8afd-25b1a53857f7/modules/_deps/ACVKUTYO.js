import {
  a as f,
  b as a,
  e as y
} from "./IVQGLTSC.js";
import {
  b as s,
  d as c,
  e as p
} from "./75JH2J25.js";
import {
  j as e,
  n as m
} from "./3TDUHHJO.js";
import {
  a as l
} from "./RUVYHBJQ.js";

// convex/videos/storage.ts
m();
y();
var v = p({
  args: {
    fileUploadId: e.id("fileUploads"),
    title: e.string(),
    filename: e.string(),
    contentType: e.string(),
    description: e.optional(e.string()),
    type: e.optional(e.string())
  },
  returns: e.object({
    videoId: e.id("videos"),
    url: e.string()
  }),
  handler: /* @__PURE__ */ l(async (t, i) => {
    let o = await t.auth.getUserIdentity();
    if (!o)
      throw new Error("\u8A8D\u8A3C\u304C\u5FC5\u8981\u3067\u3059");
    let r = await t.runQuery(
      a.videos.storage.getUserByEmail,
      {
        email: o.email || ""
      }
    );
    if (!r)
      throw new Error("\u30E6\u30FC\u30B6\u30FC\u304C\u898B\u3064\u304B\u308A\u307E\u305B\u3093");
    let d = await t.runQuery(a.videos.storage.getFileUploadInfo, {
      fileUploadId: i.fileUploadId
    });
    if (!d)
      throw new Error("\u30A2\u30C3\u30D7\u30ED\u30FC\u30C9\u30D5\u30A1\u30A4\u30EB\u304C\u898B\u3064\u304B\u308A\u307E\u305B\u3093");
    let n = `https://storage.googleapis.com/ai-sales-hub-dev-new_dify-ai-sales-hub-dev-new/${d.gcp_file_path}`;
    return {
      videoId: await t.runMutation(a.videos.storage.createVideoRecord, {
        userId: r._id,
        title: i.title,
        description: i.description,
        type: i.type || "\u305D\u306E\u4ED6",
        url: n,
        fileUploadId: i.fileUploadId,
        filename: i.filename,
        contentType: i.contentType
      }),
      url: n
    };
  }, "handler")
}), h = s({
  args: { email: e.string() },
  returns: e.union(
    e.null(),
    e.object({
      _id: e.id("users"),
      email: e.string(),
      name: e.optional(e.string())
    })
  ),
  handler: /* @__PURE__ */ l(async (t, i) => {
    let o = await t.db.query("users").withIndex("by_email", (r) => r.eq("email", i.email)).first();
    return o ? {
      _id: o._id,
      email: o.email,
      name: o.name
    } : null;
  }, "handler")
}), w = s({
  args: { fileUploadId: e.id("fileUploads") },
  returns: e.union(
    e.null(),
    e.object({
      gcp_file_path: e.string(),
      file_size: e.number()
    })
  ),
  handler: /* @__PURE__ */ l(async (t, i) => {
    let o = await t.db.get(i.fileUploadId);
    return o ? {
      gcp_file_path: o.gcp_file_path,
      file_size: o.file_size
    } : null;
  }, "handler")
}), T = c({
  args: {
    userId: e.id("users"),
    title: e.string(),
    description: e.optional(e.string()),
    type: e.string(),
    url: e.string(),
    fileUploadId: e.id("fileUploads"),
    filename: e.string(),
    contentType: e.string()
  },
  returns: e.id("videos"),
  handler: /* @__PURE__ */ l(async (t, i) => {
    let r = (await t.db.get(i.fileUploadId))?.file_size || 0, d = i.contentType.startsWith("audio/") ? void 0 : 0, n = await t.db.insert("videos", {
      user_id: i.userId,
      title: i.title,
      description: i.description,
      type: i.type,
      url: i.url,
      file_upload_id: i.fileUploadId,
      duration_seconds: d,
      file_size: r,
      content_type: i.contentType,
      processing_status: "completed"
    });
    if (await t.db.patch(i.fileUploadId, {
      related_resource_type: "video",
      related_resource_id: n,
      public_url: i.url,
      status: "completed",
      completed_at: Date.now()
    }), i.contentType.startsWith("video/") || i.contentType.startsWith("audio/")) {
      console.log(
        `[Auto-Transcription] Starting transcription for video ${n} (${i.contentType})`
      );
      try {
        await t.scheduler.runAfter(0, a.transcriptions.startTranscription, {
          resourceType: "video",
          resourceId: n.toString(),
          fileUrl: i.url,
          fileType: i.contentType,
          options: {
            enableSpeakerDiarization: !0,
            enableAiEvaluation: !0,
            enableContentAnalysis: !1,
            language: "ja",
            autoStartAnalysis: !0
          }
        }), console.log(`[Auto-Transcription] Scheduled transcription for video ${n}`);
      } catch (u) {
        console.error(
          `[Auto-Transcription] Failed to schedule transcription for video ${n}:`,
          u
        );
      }
    } else
      console.log(`[Auto-Transcription] Transcription disabled for ${i.contentType}`);
    return n;
  }, "handler")
}), b = p({
  args: {
    fileName: e.string(),
    fileType: e.string(),
    fileSize: e.number()
  },
  returns: e.object({
    success: e.boolean(),
    uploadUrl: e.optional(e.string()),
    videoId: e.optional(e.id("videos")),
    fileUploadId: e.optional(e.id("fileUploads")),
    message: e.string()
  }),
  handler: /* @__PURE__ */ l(async (t, i) => {
    if (!await t.auth.getUserIdentity())
      throw new Error("\u8A8D\u8A3C\u304C\u5FC5\u8981\u3067\u3059");
    return await t.runAction(f.gcsActions.generateGCPUploadUrl, {
      filename: i.fileName,
      contentType: i.fileType,
      uploadType: "video",
      fileSize: i.fileSize
    });
  }, "handler")
});

export {
  v as a,
  h as b,
  w as c,
  T as d,
  b as e
};
//# sourceMappingURL=ACVKUTYO.js.map
