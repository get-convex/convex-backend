import {
  b as u
} from "./SZVQRWFS.js";
import {
  l as o,
  n as c
} from "./3TDUHHJO.js";
import {
  a as s
} from "./RUVYHBJQ.js";

// convex/lib/chatAuth.ts
c();
async function d(t) {
  let e = await t.auth.getUserIdentity();
  if (!e)
    throw new Error("\u8A8D\u8A3C\u304C\u5FC5\u8981\u3067\u3059\u3002\u30ED\u30B0\u30A4\u30F3\u3057\u3066\u304F\u3060\u3055\u3044\u3002");
  return e;
}
s(d, "verifyUserAuthentication");
async function y(t, e) {
  let r = await t.db.query("users").withIndex("by_email", (i) => i.eq("email", e)).first();
  if (!r)
    throw new Error("\u30E6\u30FC\u30B6\u30FC\u60C5\u5831\u304C\u898B\u3064\u304B\u308A\u307E\u305B\u3093\u3002");
  return r;
}
s(y, "getUnifiedUser");
async function l(t) {
  let e = await d(t);
  if (!e.email)
    throw new Error("\u6709\u52B9\u306A\u30E1\u30FC\u30EB\u30A2\u30C9\u30EC\u30B9\u304C\u5FC5\u8981\u3067\u3059\u3002");
  let r = await y(t, e.email);
  return { identity: e, user: r };
}
s(l, "getAuthenticatedBetterAuthUser");
async function x(t) {
  if ("runQuery" in t) {
    let n = await t.auth.getUserIdentity();
    if (!n)
      throw new o("\u8A8D\u8A3C\u304C\u5FC5\u8981\u3067\u3059");
    return {
      user: {
        identity: n,
        unifiedUserId: n.subject,
        user: { email: n.email },
        isAdmin: !1
      },
      betterAuthUser: {
        _id: n.subject,
        email: n.email || "",
        role: "employee"
      }
    };
  }
  let e = await u(t), i = await t.db.query("users").filter((n) => n.eq(n.field("email"), e.user.email || "")).first();
  if (!i)
    throw new o("User not found in unified system");
  return { user: e, betterAuthUser: i };
}
s(x, "getAuthenticatedBetterAuthUserViarequireUser");
async function w(t, e, r) {
  let i = await t.db.query("chatSessions").withIndex("by_session_id", (n) => n.eq("session_id", e)).unique();
  return i ? i.user_id === r || i.legacy_user_id === r : !1;
}
s(w, "verifySessionOwnership");
async function C(t, e, r) {
  if (!await w(t, e, r))
    throw new Error("\u3053\u306E\u30BB\u30C3\u30B7\u30E7\u30F3\u306B\u30A2\u30AF\u30BB\u30B9\u3059\u308B\u6A29\u9650\u304C\u3042\u308A\u307E\u305B\u3093\u3002");
  let n = await t.db.query("chatSessions").withIndex("by_session_id", (a) => a.eq("session_id", e)).unique();
  if (!n)
    throw new Error("\u30BB\u30C3\u30B7\u30E7\u30F3\u304C\u898B\u3064\u304B\u308A\u307E\u305B\u3093\u3002");
  return n;
}
s(C, "validateSessionAccess");
async function m(t, e, r) {
  let i = await t.db.get(e);
  if (!i)
    throw new o("Slack integration not found");
  if (i.created_by !== r)
    throw new o("Access denied. You can only access your own integrations.");
  return i;
}
s(m, "validateSlackIntegrationOwnership");
async function g(t, e, r) {
  let n = (await t.db.query("slackOAuthTokens").withIndex("by_user_id", (a) => a.eq("user_id", r)).collect()).find((a) => a.team_id === e);
  if (!n)
    throw new o("Slack OAuth token not found");
  return n;
}
s(g, "validateSlackOAuthTokenOwnership");

export {
  d as a,
  y as b,
  l as c,
  x as d,
  w as e,
  C as f,
  m as g,
  g as h
};
//# sourceMappingURL=OQRPCOVT.js.map
