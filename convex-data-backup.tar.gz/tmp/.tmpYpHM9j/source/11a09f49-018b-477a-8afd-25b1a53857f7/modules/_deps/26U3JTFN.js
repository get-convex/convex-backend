import {
  b as c,
  d
} from "./75JH2J25.js";
import {
  j as e,
  n as p
} from "./3TDUHHJO.js";
import {
  a
} from "./RUVYHBJQ.js";

// convex/testing/authHelpers.ts
p();
var f = {
  ADMIN: {
    name: "Test Admin",
    email: "admin@test.com",
    role: "admin",
    tokenIdentifier: "test://admin-user",
    clerkUserId: "test-admin-user"
  },
  TRAINER: {
    name: "Test Trainer",
    email: "trainer@test.com",
    role: "trainer",
    tokenIdentifier: "test://trainer-user",
    clerkUserId: "test-trainer-user"
  },
  EMPLOYEE: {
    name: "Test Employee",
    email: "employee@test.com",
    role: "employee",
    tokenIdentifier: "test://employee-user",
    clerkUserId: "test-employee-user"
  },
  VIEWER: {
    name: "Test Viewer",
    email: "viewer@test.com",
    role: "viewer",
    tokenIdentifier: "test://viewer-user",
    clerkUserId: "test-viewer-user"
  }
}, y = d({
  args: {
    profile: e.optional(e.any()),
    predefinedUser: e.optional(e.string()),
    customTokenIdentifier: e.optional(e.string())
  },
  returns: e.object({
    userId: e.id("users"),
    tokenIdentifier: e.string(),
    clerkUserId: e.string(),
    userProfile: e.any()
  }),
  handler: /* @__PURE__ */ a(async (i, t) => {
    if (process.env.VITEST !== "true")
      throw new Error("\u3053\u306E\u6A5F\u80FD\u306F\u30C6\u30B9\u30C8\u74B0\u5883\u3067\u306E\u307F\u4F7F\u7528\u53EF\u80FD\u3067\u3059");
    let r;
    t.predefinedUser && t.predefinedUser in f ? r = f[t.predefinedUser] : t.profile ? r = t.profile : r = f.EMPLOYEE;
    let s = t.customTokenIdentifier || r.tokenIdentifier || `test://user-${Date.now()}`, n = r.clerkUserId || `test-clerk-${Date.now()}`, o = await i.db.query("users").withIndex("by_token", (l) => l.eq("tokenIdentifier", s)).first();
    return o ? {
      userId: o._id,
      tokenIdentifier: s,
      clerkUserId: o.clerkUserId,
      userProfile: r
    } : {
      userId: await i.db.insert("users", {
        clerkUserId: n,
        tokenIdentifier: s,
        email: r.email,
        emailVerified: !0,
        name: r.name,
        role: r.role,
        department: r.department,
        isActive: r.isActive ?? !0,
        joinDate: Date.now(),
        lastLoginAt: Date.now()
      }),
      tokenIdentifier: s,
      clerkUserId: n,
      userProfile: r
    };
  }, "handler")
}), w = c({
  args: {
    tokenIdentifier: e.string()
  },
  returns: e.object({
    identity: e.any(),
    user: e.any()
  }),
  handler: /* @__PURE__ */ a(async (i, t) => {
    if (process.env.VITEST !== "true")
      throw new Error("\u3053\u306E\u6A5F\u80FD\u306F\u30C6\u30B9\u30C8\u74B0\u5883\u3067\u306E\u307F\u4F7F\u7528\u53EF\u80FD\u3067\u3059");
    let r = await i.db.query("users").withIndex("by_token", (n) => n.eq("tokenIdentifier", t.tokenIdentifier)).first();
    if (!r)
      throw new Error(`\u6307\u5B9A\u3055\u308C\u305FtokenIdentifier\u306E\u30E6\u30FC\u30B6\u30FC\u304C\u898B\u3064\u304B\u308A\u307E\u305B\u3093: ${t.tokenIdentifier}`);
    return {
      identity: {
        subject: r.clerkUserId,
        tokenIdentifier: t.tokenIdentifier,
        email: r.email,
        name: r.name
      },
      user: r
    };
  }, "handler")
}), g = d({
  args: {
    users: e.array(e.object({
      name: e.string(),
      role: e.string(),
      tokenIdentifier: e.string()
    }))
  },
  returns: e.array(e.object({
    userId: e.id("users"),
    tokenIdentifier: e.string(),
    role: e.string()
  })),
  handler: /* @__PURE__ */ a(async (i, t) => {
    if (process.env.VITEST !== "true")
      throw new Error("\u3053\u306E\u6A5F\u80FD\u306F\u30C6\u30B9\u30C8\u74B0\u5883\u3067\u306E\u307F\u4F7F\u7528\u53EF\u80FD\u3067\u3059");
    let r = [];
    for (let s of t.users) {
      let n = s.tokenIdentifier, o = `test-clerk-${s.name.toLowerCase().replace(/\s+/g, "")}`, u = await i.db.query("users").withIndex("by_token", (I) => I.eq("tokenIdentifier", n)).first(), l;
      u ? l = u._id : l = await i.db.insert("users", {
        clerkUserId: o,
        tokenIdentifier: n,
        email: `${s.name.toLowerCase().replace(/\s+/g, "")}@test.com`,
        emailVerified: !0,
        name: s.name,
        role: s.role,
        isActive: !0,
        joinDate: Date.now(),
        lastLoginAt: Date.now()
      });
      let m = {
        userId: l,
        tokenIdentifier: n,
        role: s.role
      };
      r.push({
        userId: m.userId,
        tokenIdentifier: m.tokenIdentifier,
        role: s.role
      });
    }
    return r;
  }, "handler")
}), T = d({
  args: {
    enabled: e.boolean(),
    defaultRole: e.optional(e.string())
  },
  returns: e.object({
    success: e.boolean(),
    message: e.string()
  }),
  handler: /* @__PURE__ */ a(async (i, t) => {
    if (process.env.VITEST !== "true")
      throw new Error("\u3053\u306E\u6A5F\u80FD\u306F\u30C6\u30B9\u30C8\u74B0\u5883\u3067\u306E\u307F\u4F7F\u7528\u53EF\u80FD\u3067\u3059");
    return {
      success: !0,
      message: `\u30C6\u30B9\u30C8\u8A8D\u8A3C\u30D0\u30A4\u30D1\u30B9\u304C${t.enabled ? "\u6709\u52B9" : "\u7121\u52B9"}\u306B\u306A\u308A\u307E\u3057\u305F`
    };
  }, "handler")
}), h = c({
  args: {
    userId: e.id("users"),
    requiredRole: e.string()
  },
  returns: e.object({
    hasPermission: e.boolean(),
    userRole: e.string(),
    message: e.string()
  }),
  handler: /* @__PURE__ */ a(async (i, t) => {
    if (process.env.VITEST !== "true")
      throw new Error("\u3053\u306E\u6A5F\u80FD\u306F\u30C6\u30B9\u30C8\u74B0\u5883\u3067\u306E\u307F\u4F7F\u7528\u53EF\u80FD\u3067\u3059");
    let r = await i.db.get(t.userId);
    if (!r)
      return {
        hasPermission: !1,
        userRole: "unknown",
        message: "\u30E6\u30FC\u30B6\u30FC\u304C\u898B\u3064\u304B\u308A\u307E\u305B\u3093"
      };
    let s = {
      viewer: 1,
      employee: 2,
      trainer: 3,
      admin: 4
    }, n = s[r.role] || 0, o = s[t.requiredRole] || 999;
    return {
      hasPermission: n >= o,
      userRole: r.role,
      message: n >= o ? "\u6A29\u9650\u304C\u627F\u8A8D\u3055\u308C\u307E\u3057\u305F" : `\u6A29\u9650\u4E0D\u8DB3: ${r.role} < ${t.requiredRole}`
    };
  }, "handler")
});

export {
  f as a,
  y as b,
  w as c,
  g as d,
  T as e,
  h as f
};
//# sourceMappingURL=26U3JTFN.js.map
