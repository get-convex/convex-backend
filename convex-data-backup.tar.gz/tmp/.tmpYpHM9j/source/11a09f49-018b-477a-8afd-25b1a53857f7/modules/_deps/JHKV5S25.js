import {
  a as _,
  g as u,
  h as s,
  k as y,
  p as f
} from "./SMJ6X5F7.js";
import {
  a
} from "./RUVYHBJQ.js";

// convex/evaluationUtils.ts
var d = class extends Error {
  constructor(r, i, n) {
    super(r);
    this.code = i;
    this.details = n;
    this.name = "EvaluationError";
  }
  static {
    a(this, "EvaluationError");
  }
};
async function E(t) {
  let e = await t.auth.getUserIdentity();
  if (!e)
    throw new d("Authentication required", s.UNAUTHORIZED, {
      requiredAuth: !0
    });
  return e;
}
a(E, "validateAuthentication");
function m(t, e) {
  if (!t && !e)
    throw new d(
      "Either transcriptionId or transcript is required",
      s.MISSING_REQUIRED_PARAMS,
      { required: ["transcriptionId", "transcript"] }
    );
}
a(m, "validateRequiredParams");
function w(t) {
  let e = t || "M&A\u30ED\u30FC\u30EB\u30D7\u30EC\u30A4";
  if (!y(e))
    throw new d("Invalid video type", s.INVALID_VIDEO_TYPE, {
      provided: e,
      validTypes: _
    });
  return e;
}
a(w, "validateVideoType");
function R(t, e) {
  let r = t || e.subject;
  if (!r)
    throw new d("User ID could not be determined", s.USER_ID_ERROR, {
      userId: t,
      identity: !!e
    });
  return r;
}
a(R, "validateUserId");
async function x(t, e, r, i) {
  let n = e, o = r;
  if (!n && r && i && (n = await t.db.insert("transcriptions", {
    resource_type: "video",
    resource_id: i,
    video_id: i,
    text: r,
    status: "completed",
    created_at: Date.now(),
    updated_at: Date.now()
  })), !n)
    throw new d(
      "Failed to create or find transcription record",
      s.TRANSCRIPTION_ERROR,
      { transcriptionId: e, transcript: !!r }
    );
  let c = await t.db.get(n);
  if (!c)
    throw new d("Transcription not found", s.TRANSCRIPTION_NOT_FOUND, {
      transcriptionId: n
    });
  return o = o || c.text, {
    transcriptionId: n,
    transcript: o
  };
}
a(x, "processTranscription");
async function T(t, e) {
  let { transcriptionId: r, videoId: i, userId: n, videoType: o } = e, c = Math.random().toString(36).substring(2) + Date.now().toString(36), p = {
    transcription_id: r,
    user_id: n,
    video_type: o,
    status: "processing",
    retry_count: 0,
    evaluation_requested_at: Date.now(),
    external_id: c
    // 外部IDを設定
  };
  i && (p.video_id = i);
  let l = await t.db.insert("evaluations", p), I = f(l);
  return await t.db.insert("evaluationDetails", {
    evaluation_id: l,
    video_type: o,
    final_score: 0,
    recommendation: "\u51E6\u7406\u4E2D",
    retry_count: 0,
    evaluation_id_external: I,
    status: "processing"
  }), {
    evaluationId: l,
    externalId: c
    // UUIDを使用
  };
}
a(T, "createEvaluationRecord");
async function h(t, e, r, i, n) {
  try {
    await t.scheduler.runAfter(
      u.SCHEDULER_DELAY_MS,
      n.evaluations.processEvaluation,
      {
        evaluationId: e,
        transcript: r,
        videoType: i
      }
    );
  } catch (o) {
    throw await t.db.patch(e, {
      status: "failed",
      error_message: o instanceof Error ? o.message : "Scheduler error"
    }), new d("Failed to schedule evaluation", s.SCHEDULER_ERROR, {
      originalError: o instanceof Error ? o.message : "Unknown error"
    });
  }
}
a(h, "scheduleEvaluation");
async function g(t, e, r) {
  let i = await t.db.query("evaluationDetails").withIndex("by_external_id", (o) => o.eq("evaluation_id_external", e)).first();
  if (!i)
    return {
      success: !1,
      status: "failed",
      evaluationId: e,
      error: "Evaluation not found",
      errorCode: s.EVALUATION_NOT_FOUND
    };
  let n = await t.db.get(i.evaluation_id);
  if (!n)
    return {
      success: !1,
      status: "failed",
      evaluationId: e,
      error: "Evaluation record not found",
      errorCode: s.EVALUATION_RECORD_NOT_FOUND
    };
  if (n.user_id !== r.subject)
    throw new d(
      "Access denied: You can only access your own evaluations",
      s.ACCESS_DENIED,
      { requestedEvaluationId: e, userId: r.subject }
    );
  return { evaluationDetail: i, evaluation: n };
}
a(g, "checkEvaluationAccess");
async function A(t, e) {
  try {
    let r = await t.db.query("evaluationCriteria").withIndex(
      "by_video_type_and_active",
      (n) => n.eq("video_type", e).eq("is_active", !0)
    ).collect(), i = {};
    return r.forEach((n) => {
      i[n.criterion_key] = {
        minScore: n.scale.minScore,
        maxScore: n.scale.maxScore,
        description: n.scale.description,
        scales: n.scale.scales
      };
    }), i;
  } catch (r) {
    console.warn("Failed to load criteria:", r);
    return;
  }
}
a(A, "getCriteriaForVideoTypeSafe");
async function C(t, e, r = u.BATCH_SIZE) {
  let i = [];
  for (let n = 0; n < t.length; n += r) {
    let o = t.slice(n, n + r), c = await e(o);
    i.push(...c);
  }
  return i;
}
a(C, "processBatch");
function b(t, e, r) {
  let i = {
    success: r !== "failed",
    status: r,
    evaluationId: e.evaluation_id_external
  };
  switch (r) {
    case "processing":
      return {
        ...i,
        message: "Evaluation is still in progress"
      };
    case "failed":
      return {
        ...i,
        error: t.error_message || "Evaluation failed",
        errorCode: s.EVALUATION_FAILED,
        finalScore: e.final_score || u.ERROR_DEFAULT_SCORE,
        recommendation: e.recommendation || "\u30A8\u30E9\u30FC"
      };
    case "completed":
      return {
        ...i,
        finalScore: e.final_score,
        recommendation: e.recommendation,
        evaluationDetails: e.evaluation_details,
        goodPoints: e.good_points || [],
        improvementPoints: e.improvement_points || [],
        recommendedActions: e.recommended_actions || []
      };
    default:
      throw new d("Invalid evaluation status", s.INTERNAL_ERROR, {
        status: r
      });
  }
}
a(b, "formatEvaluationResult");
function O(t, e) {
  let { userId: r, videoType: i, status: n } = e;
  return r && i ? t.withIndex(
    "by_user_and_video_type",
    (o) => o.eq("user_id", r).eq("video_type", i)
  ) : n && r ? t.withIndex(
    "by_status_and_user",
    (o) => o.eq("status", n).eq("user_id", r)
  ) : i && n ? t.withIndex(
    "by_video_type_and_status",
    (o) => o.eq("video_type", i).eq("status", n)
  ) : r ? t.withIndex("by_user_id", (o) => o.eq("user_id", r)) : n ? t.withIndex("by_status", (o) => o.eq("status", n)) : t;
}
a(O, "optimizeQuery");

export {
  d as a,
  E as b,
  m as c,
  w as d,
  R as e,
  x as f,
  T as g,
  h,
  g as i,
  A as j,
  C as k,
  b as l,
  O as m
};
//# sourceMappingURL=JHKV5S25.js.map
