import {
  a as s
} from "./RUVYHBJQ.js";

// convex/videos/utils.ts
function o(e, n = null) {
  if (!e) return n;
  try {
    return JSON.parse(e);
  } catch {
    return n;
  }
}
s(o, "safeJsonParse");
function a(e, n, r) {
  let t = null;
  return typeof e == "string" ? t = o(e) : typeof e == "object" && e !== null && (t = e), {
    data: t,
    status: n || "pending",
    generatedAt: r ?? null,
    isAvailable: !!t && n === "completed"
  };
}
s(a, "parseSummaryData");
function c(e, n = !1) {
  let r = {};
  return n && e === "processing" && (r.processing_started_at = Date.now()), e === "completed" && (r.generated_at = Date.now()), r;
}
s(c, "createProcessingStatusFields");
function l(e) {
  return !!e && ["training", "roleplay", "meeting", "case", "review"].includes(e);
}
s(l, "isValidVideoType");
function p(e) {
  if (!e) return null;
  let n = e.match(/^(\d+)-(\d+)$/);
  if (!n) return null;
  let r = Number.parseInt(n[1], 10), t = Number.parseInt(n[2], 10);
  return r > t || r < 0 || t > 100 ? null : { min: r, max: t };
}
s(p, "parseScoreRange");
function d(e) {
  if (!e || e <= 0) return "00:00";
  let n = Math.floor(e / 60), r = e % 60;
  return `${n}:${r.toString().padStart(2, "0")}`;
}
s(d, "formatDuration");
async function E(e, n) {
  let r = Array.from(new Set(e)), t = await Promise.all(
    r.map(async (i) => {
      try {
        let u = await n(i);
        return { id: i, user: u };
      } catch (u) {
        return console.warn(`\u30E6\u30FC\u30B6\u30FC\u60C5\u5831\u53D6\u5F97\u30A8\u30E9\u30FC (ID: ${i}):`, u), { id: i, user: null };
      }
    })
  );
  return new Map(t.map(({ id: i, user: u }) => [i, u]));
}
s(E, "batchGetUsers");
var f = {
  VIDEO_NOT_FOUND: "\u6307\u5B9A\u3055\u308C\u305F\u52D5\u753B\u304C\u898B\u3064\u304B\u308A\u307E\u305B\u3093",
  TRANSCRIPTION_NOT_FOUND: "\u6587\u5B57\u8D77\u3053\u3057\u30C7\u30FC\u30BF\u304C\u898B\u3064\u304B\u308A\u307E\u305B\u3093\u3002\u5148\u306B\u6587\u5B57\u8D77\u3053\u3057\u3092\u5B9F\u884C\u3057\u3066\u304F\u3060\u3055\u3044",
  INSUFFICIENT_TEXT: "\u6587\u5B57\u8D77\u3053\u3057\u30C6\u30AD\u30B9\u30C8\u304C\u4E0D\u5341\u5206\u3067\u3059\u3002\u5341\u5206\u306A\u9577\u3055\u306E\u4F1A\u8A71\u304C\u5FC5\u8981\u3067\u3059",
  AUTH_REQUIRED: "\u8A8D\u8A3C\u304C\u5FC5\u8981\u3067\u3059",
  USER_NOT_FOUND: "\u30E6\u30FC\u30B6\u30FC\u304C\u898B\u3064\u304B\u308A\u307E\u305B\u3093",
  ACCESS_DENIED: "\u3053\u306E\u52D5\u753B\u306B\u30A2\u30AF\u30BB\u30B9\u3059\u308B\u6A29\u9650\u304C\u3042\u308A\u307E\u305B\u3093",
  PROCESSING_ERROR: "\u51E6\u7406\u4E2D\u306B\u30A8\u30E9\u30FC\u304C\u767A\u751F\u3057\u307E\u3057\u305F"
}, T = {
  CASE_SUMMARY_GENERATED: "\u6848\u4EF6\u5316\u60C5\u5831\u30B5\u30DE\u30EA\u30FC\u306E\u751F\u6210\u3092\u958B\u59CB\u3057\u307E\u3057\u305F",
  CASE_SUMMARY_DELETED: "\u6848\u4EF6\u5316\u60C5\u5831\u30B5\u30DE\u30EA\u30FC\u3092\u524A\u9664\u3057\u307E\u3057\u305F",
  MEETING_SUMMARY_GENERATED: "\u5546\u8AC7\u8A18\u9332\u30B5\u30DE\u30EA\u30FC\u306E\u751F\u6210\u3092\u958B\u59CB\u3057\u307E\u3057\u305F",
  MEETING_SUMMARY_DELETED: "\u5546\u8AC7\u8A18\u9332\u30B5\u30DE\u30EA\u30FC\u3092\u524A\u9664\u3057\u307E\u3057\u305F",
  VIDEO_DELETED: "\u52D5\u753B\u304C\u6B63\u5E38\u306B\u524A\u9664\u3055\u308C\u307E\u3057\u305F",
  VIDEO_CREATED: "\u52D5\u753B\u304C\u6B63\u5E38\u306B\u4F5C\u6210\u3055\u308C\u307E\u3057\u305F"
};
function m(e, n) {
  return {
    success: !0,
    ...e !== void 0 && { data: e },
    ...n && { message: n }
  };
}
s(m, "createSuccessResponse");
function g(e) {
  return {
    success: !1,
    message: e
  };
}
s(g, "createErrorResponse");

export {
  o as a,
  a as b,
  c,
  l as d,
  p as e,
  d as f,
  E as g,
  f as h,
  T as i,
  m as j,
  g as k
};
//# sourceMappingURL=K6BAPRLZ.js.map
