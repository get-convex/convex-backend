import {
  n as t,
  p as i
} from "./6XQQNYIR.js";
import {
  j as e,
  n as r
} from "./3TDUHHJO.js";

// convex/schema/integration.ts
i();
r();
var n = e.object({
  evaluations: e.boolean(),
  uploads: e.boolean(),
  system_alerts: e.boolean()
}), a = e.object({
  requests_per_minute: e.number(),
  requests_per_hour: e.number()
}), o = e.object({
  max_retries: e.number(),
  backoff_factor: e.number()
}), s = e.object({
  total_requests: e.number(),
  successful_requests: e.number(),
  failed_requests: e.number(),
  last_request_at: e.optional(e.number()),
  average_response_time: e.optional(e.number())
}), l = e.object({
  total_users: e.number(),
  synced_users: e.number(),
  failed_users: e.number(),
  last_error: e.optional(e.string())
}), _ = e.object({
  type: e.literal("saml"),
  entity_id: e.string(),
  sso_url: e.string(),
  certificate: e.string(),
  attribute_mapping: e.object({
    email: e.string(),
    name: e.string(),
    role: e.optional(e.string())
  })
}), d = e.object({
  type: e.literal("oidc"),
  client_id: e.string(),
  client_secret: e.string(),
  discovery_url: e.string(),
  scopes: e.array(e.string())
}), b = e.object({
  type: e.literal("oauth2"),
  client_id: e.string(),
  client_secret: e.string(),
  authorization_url: e.string(),
  token_url: e.string(),
  user_info_url: e.string()
}), c = e.object({
  type: e.literal("ldap"),
  server_url: e.string(),
  bind_dn: e.string(),
  bind_password: e.string(),
  user_search_base: e.string(),
  user_search_filter: e.string()
}), p = {
  // Slack統合設定
  slackIntegrations: t({
    workspace_id: e.string(),
    team_name: e.string(),
    bot_token: e.string(),
    webhook_url: e.optional(e.string()),
    channel_id: e.string(),
    channel_name: e.string(),
    enabled: e.boolean(),
    created_by: e.id("users"),
    config: e.optional(
      e.object({
        notifications: n,
        message_format: e.optional(e.string()),
        mention_users: e.optional(e.array(e.string()))
      })
    ),
    last_used_at: e.optional(e.number()),
    error_count: e.optional(e.number()),
    last_error: e.optional(e.string())
  }).index("by_workspace", ["workspace_id"]).index("by_created_by", ["created_by"]).index("by_enabled", ["enabled"]),
  // Teams統合設定
  teamsIntegrations: t({
    tenant_id: e.string(),
    team_id: e.string(),
    team_name: e.string(),
    webhook_url: e.string(),
    channel_id: e.string(),
    channel_name: e.string(),
    enabled: e.boolean(),
    created_by: e.id("users"),
    config: e.optional(
      e.object({
        notifications: n,
        card_format: e.optional(e.string()),
        mention_users: e.optional(e.array(e.string()))
      })
    ),
    last_used_at: e.optional(e.number()),
    error_count: e.optional(e.number()),
    last_error: e.optional(e.string())
  }).index("by_tenant", ["tenant_id"]).index("by_team", ["team_id"]).index("by_created_by", ["created_by"]).index("by_enabled", ["enabled"]),
  // Webhook統合設定
  webhookIntegrations: t({
    name: e.string(),
    url: e.string(),
    method: e.union(e.literal("GET"), e.literal("POST"), e.literal("PUT")),
    headers: e.optional(e.record(e.string(), e.string())),
    enabled: e.boolean(),
    created_by: e.id("users"),
    trigger_events: e.array(
      e.union(
        e.literal("evaluation_completed"),
        e.literal("video_uploaded"),
        e.literal("transcription_completed"),
        e.literal("user_registered"),
        e.literal("system_alert")
      )
    ),
    config: e.optional(
      e.object({
        retry_count: e.number(),
        timeout_ms: e.number(),
        secret_token: e.optional(e.string()),
        verify_ssl: e.boolean()
      })
    ),
    last_triggered_at: e.optional(e.number()),
    success_count: e.optional(e.number()),
    error_count: e.optional(e.number()),
    last_error: e.optional(e.string())
  }).index("by_created_by", ["created_by"]).index("by_enabled", ["enabled"]).index("by_trigger_events", ["trigger_events"]),
  // API統合設定（外部API）
  apiIntegrations: t({
    name: e.string(),
    provider: e.union(
      e.literal("dify"),
      e.literal("openai"),
      e.literal("anthropic"),
      e.literal("google"),
      e.literal("custom")
    ),
    base_url: e.string(),
    api_key: e.string(),
    enabled: e.boolean(),
    created_by: e.id("users"),
    config: e.optional(
      e.object({
        rate_limit: e.optional(a),
        timeout_ms: e.number(),
        retry_config: e.optional(o),
        custom_headers: e.optional(e.record(e.string(), e.string()))
      })
    ),
    usage_stats: e.optional(s),
    last_health_check: e.optional(e.number()),
    health_status: e.optional(
      e.union(e.literal("healthy"), e.literal("degraded"), e.literal("unhealthy"))
    ),
    last_error: e.optional(e.string())
  }).index("by_provider", ["provider"]).index("by_created_by", ["created_by"]).index("by_enabled", ["enabled"]).index("by_health_status", ["health_status"]),
  // SSO統合設定
  ssoIntegrations: t({
    name: e.string(),
    provider: e.union(e.literal("saml"), e.literal("oidc"), e.literal("oauth2"), e.literal("ldap")),
    enabled: e.boolean(),
    created_by: e.id("users"),
    config: e.union(_, d, b, c),
    domain_restrictions: e.optional(e.array(e.string())),
    auto_provisioning: e.boolean(),
    default_role: e.string(),
    last_sync_at: e.optional(e.number()),
    sync_stats: e.optional(l)
  }).index("by_provider", ["provider"]).index("by_created_by", ["created_by"]).index("by_enabled", ["enabled"]),
  // 統合イベントログ
  integrationEventLogs: t({
    integration_type: e.union(
      e.literal("slack"),
      e.literal("teams"),
      e.literal("webhook"),
      e.literal("api"),
      e.literal("sso")
    ),
    integration_id: e.string(),
    event_type: e.string(),
    event_data: e.any(),
    status: e.union(e.literal("success"), e.literal("failed"), e.literal("pending")),
    response_data: e.optional(e.any()),
    error_message: e.optional(e.string()),
    processing_time_ms: e.optional(e.number()),
    retry_count: e.optional(e.number()),
    created_by: e.optional(e.id("users"))
  }).index("by_integration", ["integration_type", "integration_id"]).index("by_status", ["status"]).index("by_event_type", ["event_type"])
};

export {
  p as a
};
//# sourceMappingURL=6734VT7R.js.map
