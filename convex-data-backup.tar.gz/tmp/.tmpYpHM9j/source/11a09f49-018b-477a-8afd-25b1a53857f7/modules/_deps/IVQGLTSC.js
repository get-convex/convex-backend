import {
  j as o,
  m as n,
  p
} from "./6XQQNYIR.js";
import {
  b as t,
  d as e
} from "./RUVYHBJQ.js";

// convex/_generated/api.js
var s = {};
e(s, {
  api: () => r,
  components: () => i,
  internal: () => c
});
var r, c, i, m = t(() => {
  p();
  r = o, c = o, i = n();
});

export {
  r as a,
  c as b,
  i as c,
  s as d,
  m as e
};
//# sourceMappingURL=IVQGLTSC.js.map
