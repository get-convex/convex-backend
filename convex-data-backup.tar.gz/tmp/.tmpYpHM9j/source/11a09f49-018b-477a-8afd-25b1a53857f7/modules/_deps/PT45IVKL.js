import {
  a as I,
  e as k
} from "./IVQGLTSC.js";
import {
  b as h
} from "./SZVQRWFS.js";
import {
  a as b,
  c as w
} from "./75JH2J25.js";
import {
  j as e,
  n as P
} from "./3TDUHHJO.js";
import {
  a as u
} from "./RUVYHBJQ.js";

// convex/videos/review.ts
P();
k();
var S = {
  CONVERSATION_TIMESTAMP_INTERVAL: 10,
  DEFAULT_TIMESTAMP_FORMAT: "s"
}, $ = b({
  args: {
    videoId: e.id("videos")
  },
  returns: e.union(
    e.object({
      success: e.literal(!0),
      data: e.object({
        videoId: e.id("videos"),
        transcription: e.optional(
          e.object({
            text: e.string(),
            formatted_text: e.optional(e.string()),
            status: e.string()
          })
        ),
        meeting_minutes: e.optional(
          e.object({
            summary: e.optional(e.string()),
            keyPoints: e.optional(e.array(e.string())),
            actionItems: e.optional(e.array(e.string())),
            participants: e.optional(e.array(e.string())),
            duration: e.optional(e.string())
          })
        ),
        case_summary: e.optional(
          e.object({
            transferReason: e.optional(e.string()),
            hasSuccessor: e.optional(e.string()),
            desiredStockPrice: e.optional(e.string()),
            successFeeUnderstanding: e.optional(e.string()),
            shareholderStructure: e.optional(e.string()),
            shareholderDisclosureStatus: e.optional(e.string()),
            employeeCount: e.optional(e.object({
              fullTime: e.optional(e.union(e.number(), e.null())),
              partTime: e.optional(e.union(e.number(), e.null())),
              total: e.optional(e.union(e.number(), e.null()))
            })),
            familyStructure: e.optional(e.string()),
            personalityProfile: e.optional(e.string()),
            businessOverview: e.optional(e.string()),
            currentYearFinancials: e.optional(e.object({
              revenue: e.optional(e.union(e.string(), e.null())),
              grossProfit: e.optional(e.union(e.string(), e.null())),
              operatingProfit: e.optional(e.union(e.string(), e.null()))
            })),
            nextYearForecasts: e.optional(e.object({
              revenue: e.optional(e.union(e.string(), e.null())),
              grossProfit: e.optional(e.union(e.string(), e.null())),
              operatingProfit: e.optional(e.union(e.string(), e.null()))
            })),
            companyStrengths: e.optional(e.array(e.string())),
            companyChallenges: e.optional(e.array(e.string())),
            buyerPreferences: e.optional(e.string()),
            confidenceLevel: e.optional(e.string()),
            dataQuality: e.optional(e.object({
              completeness: e.optional(e.number()),
              clarity: e.optional(e.number())
            }))
          })
        ),
        meeting_summary: e.optional(
          e.object({
            attendees: e.optional(e.string()),
            businessContent: e.optional(e.string()),
            companyOverview: e.optional(e.string()),
            maRelatedInfo: e.optional(e.string()),
            ownerInfo: e.optional(e.string()),
            stockPriceExpectation: e.optional(e.string()),
            transferIntention: e.optional(e.string()),
            financialContent: e.optional(e.string()),
            intervieweeInfo: e.optional(e.string()),
            personalCharacteristics: e.optional(e.string()),
            brokerMeetingHistory: e.optional(e.string()),
            shareholderInfo: e.optional(e.string()),
            nextActions: e.optional(e.string()),
            todos: e.optional(e.string()),
            confidenceLevel: e.optional(e.string()),
            dataQuality: e.optional(e.object({
              clarity: e.optional(e.number()),
              completeness: e.optional(e.number())
            })),
            clientSide: e.optional(e.string()),
            ourSide: e.optional(e.string())
          })
        ),
        evaluation: e.optional(
          e.object({
            status: e.string(),
            scores: e.object({
              hearingAbility: e.optional(e.number()),
              problemSetting: e.optional(e.number()),
              knowledge: e.optional(e.number()),
              negotiation: e.optional(e.number()),
              businessManners: e.optional(e.number())
            })
          })
        ),
        processingStatus: e.string()
      })
    }),
    e.object({
      success: e.literal(!1),
      error: e.string()
    })
  ),
  handler: /* @__PURE__ */ u(async (n, l) => {
    if (!await n.auth.getUserIdentity())
      return { success: !1, error: "\u8A8D\u8A3C\u304C\u5FC5\u8981\u3067\u3059" };
    try {
      if (!await n.db.get(l.videoId))
        return { success: !1, error: "\u52D5\u753B\u304C\u898B\u3064\u304B\u308A\u307E\u305B\u3093" };
      let s = await n.db.query("transcriptions").withIndex("by_resource", (o) => o.eq("resource_type", "video").eq("resource_id", l.videoId)).first(), c = await n.db.query("evaluations").withIndex("by_video_id", (o) => o.eq("video_id", l.videoId)).first(), r = "pending";
      return s?.status === "completed" ? r = "completed" : s?.status === "processing" ? r = "processing" : s?.status === "failed" && (r = "failed"), {
        success: !0,
        data: {
          videoId: l.videoId,
          transcription: s ? {
            text: s.text,
            formatted_text: s.formatted_text,
            status: s.status
          } : void 0,
          meeting_minutes: s?.meeting_minutes ? (() => {
            let o = s.meeting_minutes;
            if (o && typeof o == "object")
              return {
                summary: o.summary || "",
                keyPoints: typeof o.keyPoints == "string" ? o.keyPoints.split(`
`).filter(Boolean) : [],
                actionItems: o.actionItems && typeof o.actionItems == "string" ? o.actionItems.split(`
`).filter(Boolean) : void 0,
                participants: o.participants && typeof o.participants == "string" ? o.participants.split(`
`).filter(Boolean) : void 0,
                duration: o.duration
              };
          })() : void 0,
          case_summary: s?.case_summary ? (() => {
            let o = s.case_summary;
            if (typeof o == "string")
              try {
                let p = JSON.parse(o);
                return v(p);
              } catch {
                return;
              }
            else if (o && typeof o == "object")
              return v(o);
          })() : void 0,
          meeting_summary: s?.meeting_summary ? (() => {
            let o = s.meeting_summary;
            if (o && typeof o == "object")
              return {
                attendees: o.attendees || "\u53C2\u52A0\u8005\u60C5\u5831\u304C\u898B\u3064\u304B\u308A\u307E\u305B\u3093",
                businessContent: o.businessContent || "\u4E8B\u696D\u5185\u5BB9\u304C\u898B\u3064\u304B\u308A\u307E\u305B\u3093",
                companyOverview: o.companyOverview || "\u4F1A\u793E\u6982\u8981\u304C\u898B\u3064\u304B\u308A\u307E\u305B\u3093",
                maRelatedInfo: o.maRelatedInfo || "M&A\u95A2\u9023\u60C5\u5831\u304C\u898B\u3064\u304B\u308A\u307E\u305B\u3093",
                ownerInfo: o.ownerInfo || "\u30AA\u30FC\u30CA\u30FC\u60C5\u5831\u304C\u898B\u3064\u304B\u308A\u307E\u305B\u3093",
                stockPriceExpectation: o.stockPriceExpectation || "\u682A\u4FA1\u671F\u5F85\u5024\u304C\u898B\u3064\u304B\u308A\u307E\u305B\u3093",
                transferIntention: o.transferIntention || "\u8B72\u6E21\u610F\u601D\u304C\u898B\u3064\u304B\u308A\u307E\u305B\u3093",
                financialContent: o.financialContent || "\u8CA1\u52D9\u5185\u5BB9\u304C\u898B\u3064\u304B\u308A\u307E\u305B\u3093",
                intervieweeInfo: o.intervieweeInfo || "\u9762\u8AC7\u8005\u60C5\u5831\u304C\u898B\u3064\u304B\u308A\u307E\u305B\u3093",
                personalCharacteristics: o.personalCharacteristics || "\u4EBA\u7269\u7279\u6027\u304C\u898B\u3064\u304B\u308A\u307E\u305B\u3093",
                brokerMeetingHistory: o.brokerMeetingHistory || "\u4EF2\u4ECB\u4F1A\u793E\u3068\u306E\u9762\u8AC7\u5C65\u6B74\u304C\u898B\u3064\u304B\u308A\u307E\u305B\u3093",
                shareholderInfo: o.shareholderInfo || "\u682A\u4E3B\u60C5\u5831\u304C\u898B\u3064\u304B\u308A\u307E\u305B\u3093",
                nextActions: o.nextActions || "\u6B21\u306E\u30A2\u30AF\u30B7\u30E7\u30F3\u304C\u898B\u3064\u304B\u308A\u307E\u305B\u3093",
                todos: o.todos || "TODO\u304C\u898B\u3064\u304B\u308A\u307E\u305B\u3093",
                confidenceLevel: o.confidenceLevel || "\u4FE1\u983C\u5EA6\u304C\u8A2D\u5B9A\u3055\u308C\u3066\u3044\u307E\u305B\u3093",
                dataQuality: {
                  clarity: o.dataQuality?.clarity ?? 0,
                  completeness: o.dataQuality?.completeness ?? 0
                },
                clientSide: o.clientSide || "\u9867\u5BA2\u5074\u60C5\u5831\u304C\u898B\u3064\u304B\u308A\u307E\u305B\u3093",
                ourSide: o.ourSide || "\u5F53\u65B9\u60C5\u5831\u304C\u898B\u3064\u304B\u308A\u307E\u305B\u3093"
              };
          })() : void 0,
          evaluation: c ? {
            status: c.status,
            scores: {
              // レガシー評価フィールド対応
              hearingAbility: c.hearingAbility,
              problemSetting: c.problemSetting,
              knowledge: c.knowledge,
              negotiation: c.negotiation,
              businessManners: c.businessManners
            }
          } : void 0,
          processingStatus: r
        }
      };
    } catch (d) {
      return console.error("[getReview] \u30A8\u30E9\u30FC:", d), { success: !1, error: d instanceof Error ? d.message : "\u4E0D\u660E\u306A\u30A8\u30E9\u30FC\u304C\u767A\u751F\u3057\u307E\u3057\u305F" };
    }
  }, "handler")
}), V = b({
  args: {
    videoId: e.id("videos")
  },
  returns: e.union(
    e.object({
      success: e.literal(!0),
      videoId: e.id("videos"),
      averageScore: e.optional(e.number()),
      evaluationHistory: e.array(
        e.object({
          evaluationId: e.string(),
          evaluatedAt: e.string(),
          evaluator: e.string(),
          averageScore: e.number(),
          status: e.string()
        })
      ),
      processingStatus: e.string(),
      lastUpdated: e.string()
    }),
    e.object({
      success: e.literal(!1),
      error: e.string()
    })
  ),
  handler: /* @__PURE__ */ u(async (n, l) => {
    await h(n);
    try {
      if (!await n.db.get(l.videoId))
        throw new Error("\u52D5\u753B\u304C\u898B\u3064\u304B\u308A\u307E\u305B\u3093");
      let d = await n.db.query("evaluations").withIndex("by_video_id", (r) => r.eq("video_id", l.videoId)).take(100), s = d.map((r) => ({
        evaluationId: `eval-${r._id}`,
        evaluatedAt: new Date(r._creationTime).toISOString(),
        evaluator: "AI System",
        averageScore: T(r),
        status: r.status
      })), c = s.length > 0 ? s.reduce((r, o) => r + o.averageScore, 0) / s.length : void 0;
      return {
        success: !0,
        videoId: l.videoId,
        averageScore: c,
        evaluationHistory: s,
        processingStatus: d.length > 0 ? d[0].status : "pending",
        lastUpdated: (/* @__PURE__ */ new Date()).toISOString()
      };
    } catch (g) {
      return console.error("[getEvaluationHistory] \u30A8\u30E9\u30FC:", g), {
        success: !1,
        error: "\u8A55\u4FA1\u5C65\u6B74\u306E\u53D6\u5F97\u4E2D\u306B\u30A8\u30E9\u30FC\u304C\u767A\u751F\u3057\u307E\u3057\u305F"
      };
    }
  }, "handler")
}), U = b({
  args: {
    videoId: e.id("videos")
  },
  returns: e.union(
    e.object({
      id: e.string(),
      videoType: e.string(),
      conversationLogs: e.array(
        e.object({
          speaker: e.string(),
          text: e.string(),
          timestamp: e.string()
        })
      ),
      scores: e.object({
        hearing: e.float64(),
        problemDefinition: e.float64(),
        reactivity: e.float64(),
        counter: e.float64(),
        businessSense: e.float64()
      }),
      overallComment: e.string(),
      improvementSummary: e.string(),
      details: e.object({
        hearing: e.object({
          score: e.float64(),
          description: e.string(),
          details: e.array(e.string()),
          goodExamples: e.array(
            e.object({
              text: e.string(),
              explanation: e.string()
            })
          ),
          badExamples: e.array(
            e.object({
              text: e.string(),
              explanation: e.string()
            })
          )
        }),
        problemDefinition: e.object({
          score: e.float64(),
          description: e.string(),
          details: e.array(e.string()),
          goodExamples: e.array(
            e.object({
              text: e.string(),
              explanation: e.string()
            })
          ),
          badExamples: e.array(
            e.object({
              text: e.string(),
              explanation: e.string()
            })
          )
        }),
        reactivity: e.object({
          score: e.float64(),
          description: e.string(),
          details: e.array(e.string()),
          goodExamples: e.array(
            e.object({
              text: e.string(),
              explanation: e.string()
            })
          ),
          badExamples: e.array(
            e.object({
              text: e.string(),
              explanation: e.string()
            })
          )
        }),
        counter: e.object({
          score: e.float64(),
          description: e.string(),
          details: e.array(e.string()),
          goodExamples: e.array(
            e.object({
              text: e.string(),
              explanation: e.string()
            })
          ),
          badExamples: e.array(
            e.object({
              text: e.string(),
              explanation: e.string()
            })
          )
        }),
        businessSense: e.object({
          score: e.float64(),
          description: e.string(),
          details: e.array(e.string()),
          goodExamples: e.array(
            e.object({
              text: e.string(),
              explanation: e.string()
            })
          ),
          badExamples: e.array(
            e.object({
              text: e.string(),
              explanation: e.string()
            })
          )
        })
      }),
      meeting_minutes: e.optional(
        e.object({
          summary: e.string(),
          keyPoints: e.array(e.string()),
          actionItems: e.optional(e.array(e.string())),
          participants: e.optional(e.array(e.string())),
          duration: e.optional(e.string())
        })
      ),
      meeting_minutes_status: e.optional(e.string()),
      meeting_minutes_generated_at: e.optional(e.string()),
      case_summary: e.optional(
        e.object({
          businessOverview: e.string(),
          buyerPreferences: e.string(),
          companyChallenges: e.array(e.union(e.string(), e.null())),
          companyStrengths: e.array(e.union(e.string(), e.null())),
          confidenceLevel: e.string(),
          currentYearFinancials: e.object({
            grossProfit: e.union(e.string(), e.null()),
            operatingProfit: e.union(e.string(), e.null()),
            revenue: e.union(e.string(), e.null())
          }),
          dataQuality: e.object({
            clarity: e.float64(),
            completeness: e.float64()
          }),
          desiredStockPrice: e.string(),
          employeeCount: e.object({
            fullTime: e.union(e.float64(), e.null()),
            partTime: e.union(e.float64(), e.null()),
            total: e.union(e.float64(), e.null())
          }),
          familyStructure: e.string(),
          hasSuccessor: e.string(),
          nextYearForecasts: e.object({
            grossProfit: e.union(e.string(), e.null()),
            operatingProfit: e.union(e.string(), e.null()),
            revenue: e.union(e.string(), e.null())
          }),
          personalityProfile: e.string(),
          shareholderDisclosureStatus: e.string(),
          shareholderStructure: e.string(),
          successFeeUnderstanding: e.string(),
          transferReason: e.string()
        })
      ),
      case_summary_status: e.optional(
        e.union(
          e.literal("pending"),
          e.literal("processing"),
          e.literal("completed"),
          e.literal("failed")
        )
      ),
      case_summary_generated_at: e.optional(e.string()),
      meeting_summary: e.optional(
        e.object({
          attendees: e.string(),
          brokerMeetingHistory: e.string(),
          businessContent: e.string(),
          clientSide: e.string(),
          companyOverview: e.string(),
          confidenceLevel: e.string(),
          dataQuality: e.object({
            clarity: e.float64(),
            completeness: e.float64()
          }),
          financialContent: e.string(),
          intervieweeInfo: e.string(),
          maRelatedInfo: e.string(),
          nextActions: e.string(),
          ourSide: e.string(),
          ownerInfo: e.string(),
          personalCharacteristics: e.string(),
          shareholderInfo: e.string(),
          stockPriceExpectation: e.string(),
          todos: e.string(),
          transferIntention: e.string()
        })
      ),
      meeting_summary_status: e.optional(
        e.union(
          e.literal("pending"),
          e.literal("processing"),
          e.literal("completed"),
          e.literal("failed")
        )
      ),
      meeting_summary_generated_at: e.optional(e.string()),
      transcript_with_speaker: e.optional(e.string()),
      title: e.optional(e.string()),
      // グループ情報
      upload_session_id: e.optional(e.string()),
      is_group_primary: e.optional(e.boolean()),
      file_count: e.optional(e.float64())
    }),
    e.null()
  ),
  handler: /* @__PURE__ */ u(async (n, l) => {
    await h(n);
    try {
      console.log(`[getVideoReviewData] \u30D3\u30C7\u30AAID: ${l.videoId}`);
      let g = await A(n, l.videoId);
      if (!g)
        return console.log(`[getVideoReviewData] coreData\u304C\u898B\u3064\u304B\u308A\u307E\u305B\u3093: ${l.videoId}`), null;
      let { video: d, transcription: s, evaluation: c } = g;
      console.log("[getVideoReviewData] \u30C7\u30FC\u30BF\u53D6\u5F97\u6210\u529F:", {
        video: !!d,
        transcription: !!s,
        evaluation: !!c,
        evaluationKeys: c ? Object.keys(c) : []
      });
      let r = x(s), o = C(c), p = c ? E(c) : j();
      c && console.log("[getVideoReviewData] \u30B9\u30B3\u30A2\u5909\u63DB:", {
        originalDifyScores: {
          callListening: c.callListening,
          callImportantInfo: c.callImportantInfo,
          callDeepHearing: c.callDeepHearing,
          callScheduling: c.callScheduling,
          callTone: c.callTone
        },
        convertedScores: o
      });
      let t = R({
        video: d,
        transcription: s,
        evaluation: c,
        conversationLogs: r,
        scores: o,
        details: p
      });
      return console.log("[getVideoReviewData] \u6700\u7D42\u30EC\u30B9\u30DD\u30F3\u30B9:", {
        scores: t.scores,
        overallComment: t.overallComment,
        improvementSummary: t.improvementSummary,
        hasDetails: !!t.details,
        detailsKeys: t.details ? Object.keys(t.details) : [],
        conversationLogsCount: t.conversationLogs.length
      }), t;
    } catch (g) {
      return console.error("[getVideoReviewData] \u30A8\u30E9\u30FC:", g), null;
    }
  }, "handler")
});
function v(n) {
  if (n)
    return {
      transferReason: n.transferReason || "\u672A\u78BA\u8A8D",
      hasSuccessor: n.hasSuccessor || "\u672A\u78BA\u8A8D",
      desiredStockPrice: typeof n.desiredStockPrice == "object" ? `${n.desiredStockPrice.value}${n.desiredStockPrice.unit}` : n.desiredStockPrice || "\u672A\u78BA\u8A8D",
      successFeeUnderstanding: n.successFeeUnderstanding || "\u672A\u78BA\u8A8D",
      shareholderStructure: n.shareholderStructure || "\u672A\u78BA\u8A8D",
      shareholderDisclosureStatus: n.shareholderDisclosureStatus || "\u672A\u78BA\u8A8D",
      employeeCount: {
        fullTime: n.employeeCount?.fullTime ?? null,
        partTime: n.employeeCount?.partTime ?? null,
        total: n.employeeCount?.total ?? null
      },
      familyStructure: n.familyStructure || "\u672A\u78BA\u8A8D",
      personalityProfile: n.personalityProfile || "\u672A\u78BA\u8A8D",
      businessOverview: n.businessOverview || "\u672A\u78BA\u8A8D",
      currentYearFinancials: {
        revenue: n.financials?.currentYear?.revenue?.toString() || null,
        grossProfit: n.financials?.currentYear?.grossProfit?.toString() || null,
        operatingProfit: n.financials?.currentYear?.operatingProfit?.toString() || null
      },
      nextYearForecasts: {
        revenue: n.financials?.nextYearForecast?.revenue?.toString() || null,
        grossProfit: n.financials?.nextYearForecast?.grossProfit?.toString() || null,
        operatingProfit: n.financials?.nextYearForecast?.operatingProfit?.toString() || null
      },
      companyStrengths: Array.isArray(n.companyStrengths) ? n.companyStrengths : [],
      companyChallenges: Array.isArray(n.companyChallenges) ? n.companyChallenges : [],
      buyerPreferences: n.buyerPreferences || "\u672A\u78BA\u8A8D",
      confidenceLevel: n.confidenceLevel || "\u4F4E",
      dataQuality: {
        completeness: n.dataQuality?.completeness ?? 0,
        clarity: n.dataQuality?.clarity ?? 0
      }
    };
}
u(v, "transformCaseSummaryForSchema");
async function A(n, l) {
  console.log(`[fetchVideoReviewCoreData] \u691C\u7D22\u958B\u59CB: videoId=${l}`);
  let g = await n.db.get(l);
  if (!g)
    return console.log(`[fetchVideoReviewCoreData] \u30D3\u30C7\u30AA\u304C\u898B\u3064\u304B\u308A\u307E\u305B\u3093: ${l}`), null;
  let d = g;
  console.log(`[fetchVideoReviewCoreData] \u30D3\u30C7\u30AA\u53D6\u5F97\u6210\u529F: ${d._id}, \u30BF\u30A4\u30D7: ${d.type}`);
  let s = await n.db.query("transcriptions").withIndex("by_resource", (a) => a.eq("resource_type", "video").eq("resource_id", l)).first();
  if (!s)
    return console.log(`[fetchVideoReviewCoreData] \u6587\u5B57\u8D77\u3053\u3057\u304C\u898B\u3064\u304B\u308A\u307E\u305B\u3093: videoId=${l}`), null;
  console.log(
    `[fetchVideoReviewCoreData] \u6587\u5B57\u8D77\u3053\u3057\u53D6\u5F97\u6210\u529F: ${s._id}, \u72B6\u614B: ${s.status}`
  );
  let c = {
    text: s.text,
    formatted_text: s.formatted_text || void 0,
    transcript_with_speaker: s.transcript_with_speaker || void 0,
    status: s.status,
    meeting_minutes: s.meeting_minutes ? (() => {
      let a = s.meeting_minutes;
      if (a && typeof a == "object")
        return {
          summary: a.summary || "",
          keyPoints: typeof a.keyPoints == "string" ? a.keyPoints.split(`
`).filter(Boolean) : Array.isArray(a.keyPoints) ? a.keyPoints : [],
          actionItems: a.actionItems ? typeof a.actionItems == "string" ? a.actionItems.split(`
`).filter(Boolean) : Array.isArray(a.actionItems) ? a.actionItems : void 0 : void 0,
          participants: a.participants ? typeof a.participants == "string" ? a.participants.split(`
`).filter(Boolean) : Array.isArray(a.participants) ? a.participants : void 0 : void 0,
          duration: a.duration
        };
    })() : void 0,
    meeting_minutes_status: s.meeting_minutes_status,
    meeting_minutes_generated_at: s.meeting_minutes_generated_at ? String(s.meeting_minutes_generated_at) : void 0,
    case_summary: s.case_summary,
    case_summary_status: s.case_summary_status,
    case_summary_generated_at: s.case_summary_generated_at ? String(s.case_summary_generated_at) : void 0,
    meeting_summary: s.meeting_summary,
    meeting_summary_status: s.meeting_summary_status,
    meeting_summary_generated_at: s.meeting_summary_generated_at ? String(s.meeting_summary_generated_at) : void 0
  }, r = null, o = await n.db.query("evaluations").withIndex("by_video_id", (a) => a.eq("video_id", l)).collect();
  console.log(`[fetchVideoReviewCoreData] \u898B\u3064\u304B\u3063\u305F\u8A55\u4FA1\u30EC\u30B3\u30FC\u30C9\u6570: ${o.length}`), o.forEach((a, y) => {
    console.log(`[fetchVideoReviewCoreData] \u30EC\u30B3\u30FC\u30C9${y + 1}:`, {
      id: a._id,
      status: a.status,
      hasScores: !!(a.hearingAbility || a.businessManners || a.problemSetting),
      creationTime: a._creationTime,
      completedAt: a.evaluation_completed_at
    });
  });
  let p = o.filter((a) => a.status === "completed");
  console.log(`[fetchVideoReviewCoreData] \u5B8C\u4E86\u3057\u305F\u30EC\u30B3\u30FC\u30C9\u6570: ${p.length}`);
  let t = p.filter(
    (a) => a.hearingAbility !== void 0 || a.businessManners !== void 0 || a.problemSetting !== void 0 || a.knowledge !== void 0 || a.negotiation !== void 0 || a.callListening !== void 0 || a.callTone !== void 0
  );
  console.log(`[fetchVideoReviewCoreData] \u30B9\u30B3\u30A2\u3042\u308A\u30EC\u30B3\u30FC\u30C9\u6570: ${t.length}`);
  let i = (
    // 1. スコアありレコードを最新順で取得
    t.sort((a, y) => (y.evaluation_completed_at || y._creationTime) - (a.evaluation_completed_at || a._creationTime))[0] || // 2. 完了レコードを最新順で取得  
    p.sort((a, y) => (y.evaluation_completed_at || y._creationTime) - (a.evaluation_completed_at || a._creationTime))[0] || // 3. 全レコードを最新順で取得
    o.sort((a, y) => y._creationTime - a._creationTime)[0]
  );
  return console.log("[fetchVideoReviewCoreData] \u9078\u629E\u3055\u308C\u305F\u30EC\u30B3\u30FC\u30C9:", {
    id: i?._id,
    status: i?.status,
    hasScores: !!(i?.hearingAbility || i?.businessManners || i?.problemSetting)
  }), i ? (console.log(`[fetchVideoReviewCoreData] evaluations\u30C6\u30FC\u30D6\u30EB\u304B\u3089\u8A55\u4FA1\u30C7\u30FC\u30BF\u53D6\u5F97: ${i._id}`), r = {
    // 基本情報
    status: i.status || "pending",
    // 初回面談用スコア
    hearingAbility: i.hearingAbility,
    problemSetting: i.problemSetting,
    knowledge: i.knowledge,
    negotiation: i.negotiation,
    businessManners: i.businessManners,
    // 初回面談用詳細分析
    hearingAbility_analysis: i.hearingAbility_analysis,
    hearingAbility_strength: i.hearingAbility_strength,
    hearingAbility_weakness: i.hearingAbility_weakness,
    problemSetting_analysis: i.problemSetting_analysis,
    problemSetting_strength: i.problemSetting_strength,
    problemSetting_weakness: i.problemSetting_weakness,
    knowledge_analysis: i.knowledge_analysis,
    knowledge_strength: i.knowledge_strength,
    knowledge_weakness: i.knowledge_weakness,
    negotiation_analysis: i.negotiation_analysis,
    negotiation_strength: i.negotiation_strength,
    negotiation_weakness: i.negotiation_weakness,
    businessManners_analysis: i.businessManners_analysis,
    businessManners_strength: i.businessManners_strength,
    businessManners_weakness: i.businessManners_weakness,
    // AD締結提案用
    adHearingAbility: i.adHearingAbility,
    adProposalAbility: i.adProposalAbility,
    adKnowledge: i.adKnowledge,
    adNegotiation: i.adNegotiation,
    adRelationshipBuilding: i.adRelationshipBuilding,
    // 譲渡架電用
    callListening: i.callListening,
    callImportantInfo: i.callImportantInfo,
    callDeepHearing: i.callDeepHearing,
    callScheduling: i.callScheduling,
    callTone: i.callTone,
    // 企業概要書提案（IM）用
    imNeedsHearingProposal: i.imNeedsHearingProposal,
    imSellerUnderstanding: i.imSellerUnderstanding,
    imBuyerUnderstanding: i.imBuyerUnderstanding,
    imSynergyProposal: i.imSynergyProposal,
    imTestClosing: i.imTestClosing,
    // 総合コメント
    overallComment: i.overallComment,
    improvementSummary: i.improvementSummary
  }) : (console.log("[fetchVideoReviewCoreData] transcriptions\u30C6\u30FC\u30D6\u30EB\u304B\u3089\u8A55\u4FA1\u30C7\u30FC\u30BF\u3092\u53D6\u5F97"), r = s.evaluation ? {
    ...s.evaluation,
    status: s.evaluation_status || "pending"
  } : null), console.log("[fetchVideoReviewCoreData] \u8A55\u4FA1\u30C7\u30FC\u30BF\u306E\u8A73\u7D30\u69CB\u9020:", {
    hasEvaluation: !!r,
    evaluationKeys: r ? Object.keys(r) : [],
    evaluationStatus: r?.status,
    rawEvaluationData: i || s.evaluation,
    evaluationType: typeof (i || s.evaluation)
  }), r && console.log("[fetchVideoReviewCoreData] \u5B9F\u969B\u306E\u30B9\u30B3\u30A2\u5024:", {
    // 初回面談用
    hearingAbility: r.hearingAbility,
    problemSetting: r.problemSetting,
    knowledge: r.knowledge,
    negotiation: r.negotiation,
    businessManners: r.businessManners,
    // AD締結提案用
    adHearingAbility: r.adHearingAbility,
    adProposalAbility: r.adProposalAbility,
    adKnowledge: r.adKnowledge,
    adNegotiation: r.adNegotiation,
    adRelationshipBuilding: r.adRelationshipBuilding,
    // 譲渡架電用
    callListening: r.callListening,
    callImportantInfo: r.callImportantInfo,
    callDeepHearing: r.callDeepHearing,
    callScheduling: r.callScheduling,
    callTone: r.callTone,
    // 企業概要書提案（IM）用
    imNeedsHearingProposal: r.imNeedsHearingProposal,
    imSellerUnderstanding: r.imSellerUnderstanding,
    imBuyerUnderstanding: r.imBuyerUnderstanding,
    imSynergyProposal: r.imSynergyProposal,
    imTestClosing: r.imTestClosing,
    // コメント
    overallComment: r.overallComment,
    overall_comment: r.overall_comment,
    improvementSummary: r.improvementSummary,
    improvement_suggestions: r.improvement_suggestions
  }), { video: d, transcription: c, evaluation: r };
}
u(A, "fetchVideoReviewCoreData");
function C(n) {
  if (!n)
    return {
      hearing: 0,
      problemDefinition: 0,
      reactivity: 0,
      counter: 0,
      businessSense: 0
    };
  let l = /* @__PURE__ */ u((s) => {
    if (typeof s != "number" || isNaN(s))
      return console.log(`[convertScore] \u7121\u52B9\u306A\u30B9\u30B3\u30A2: ${s} (type: ${typeof s})`), 0;
    console.log(`[convertScore] \u5909\u63DB\u524D\u30B9\u30B3\u30A2: ${s}`);
    let c;
    return s <= 1 ? c = Math.round(s * 5 * 2) / 2 : s <= 5 ? c = Math.round(s * 2) / 2 : s <= 10 ? c = Math.round(s / 10 * 5 * 2) / 2 : s <= 100 ? c = Math.round(s / 100 * 5 * 2) / 2 : c = 5, console.log(`[convertScore] \u5909\u63DB\u5F8C\u30B9\u30B3\u30A2: ${s} \u2192 ${c}`), c;
  }, "convertScore"), g = /* @__PURE__ */ u((s) => {
    for (let c of s)
      if (typeof c == "number" && !isNaN(c) && c > 0)
        return l(c);
    return 0;
  }, "getScore"), d = {
    hearing: g([
      n.callListening,
      // 譲渡架電: あいづち・傾聴力
      n.imNeedsHearingProposal,
      // IM: ニーズヒアリング提案力
      n.hearingAbility,
      // M&A: ヒアリング能力
      n.adHearingAbility
      // AD: ヒアリング能力
    ]),
    problemDefinition: g([
      n.callImportantInfo,
      // 譲渡架電: 重要事項ヒアリング力
      n.imSellerUnderstanding,
      // IM: 売り手理解力
      n.problemSetting,
      // M&A: 課題設定能力
      n.adProposalAbility
      // AD: 提案能力
    ]),
    reactivity: g([
      n.callDeepHearing,
      // 譲渡架電: 深掘りヒアリング力
      n.imBuyerUnderstanding,
      // IM: 買い手理解力
      n.knowledge,
      // M&A: 知識
      n.adKnowledge
      // AD: 知識
    ]),
    counter: g([
      n.callScheduling,
      // 譲渡架電: 日程確定力
      n.imSynergyProposal,
      // IM: シナジー提案力
      n.negotiation,
      // M&A: 交渉力
      n.adNegotiation
      // AD: 交渉力
    ]),
    businessSense: g([
      n.callTone,
      // 譲渡架電: 声のトーン
      n.imTestClosing,
      // IM: テストクローージング
      n.businessManners,
      // M&A: ビジネスマナー
      n.adRelationshipBuilding
      // AD: 関係構築力
    ])
  };
  return console.log("[transformEvaluationScores] \u30B9\u30B3\u30A2\u5909\u63DB\u7D50\u679C:", {
    originalScores: {
      callListening: n.callListening,
      callImportantInfo: n.callImportantInfo,
      callDeepHearing: n.callDeepHearing,
      callScheduling: n.callScheduling,
      callTone: n.callTone
    },
    convertedScores: d
  }), d;
}
u(C, "transformEvaluationScores");
function R({
  video: n,
  transcription: l,
  evaluation: g,
  conversationLogs: d,
  scores: s,
  details: c
}) {
  let r = /* @__PURE__ */ u((t) => {
    if (t) {
      console.log(
        "[transformMeetingMinutes] \u5909\u63DB\u524D\u30C7\u30FC\u30BF:",
        JSON.stringify(t, null, 2)
      );
      try {
        if (typeof t == "string")
          return {
            summary: t,
            keyPoints: [],
            actionItems: void 0,
            participants: void 0,
            duration: void 0
          };
        let i = {
          summary: t.summary || "\u8B70\u4E8B\u9332\u30B5\u30DE\u30EA\u30FC\u304C\u751F\u6210\u3055\u308C\u3066\u3044\u307E\u3059",
          keyPoints: Array.isArray(t.keyPoints) ? t.keyPoints : Array.isArray(t.key_topics) ? t.key_topics : typeof t.keyPoints == "string" ? [t.keyPoints] : typeof t.key_topics == "string" ? [t.key_topics] : [],
          actionItems: Array.isArray(t.actionItems) ? t.actionItems : Array.isArray(t.action_items) ? t.action_items : typeof t.actionItems == "string" ? [t.actionItems] : typeof t.action_items == "string" ? [t.action_items] : void 0,
          participants: Array.isArray(t.participants) ? t.participants : typeof t.participants == "string" ? [t.participants] : void 0,
          duration: t.duration || void 0
        };
        return console.log("[transformMeetingMinutes] \u5909\u63DB\u5F8C\u30C7\u30FC\u30BF:", JSON.stringify(i, null, 2)), i;
      } catch (i) {
        console.error("[assembleVideoReviewResponse] meetingMinutes\u5909\u63DB\u30A8\u30E9\u30FC:", i);
        return;
      }
    }
  }, "transformMeetingMinutes"), o = /* @__PURE__ */ u((t) => {
    if (t)
      try {
        let i = t.caseSummary || t;
        return {
          transferReason: i.transferReason || "\u672A\u78BA\u8A8D",
          hasSuccessor: i.hasSuccessor || "\u672A\u78BA\u8A8D",
          desiredStockPrice: typeof i.desiredStockPrice == "object" ? `${i.desiredStockPrice.value}${i.desiredStockPrice.unit}` : i.desiredStockPrice || "\u672A\u78BA\u8A8D",
          successFeeUnderstanding: i.successFeeUnderstanding || "\u672A\u78BA\u8A8D",
          shareholderStructure: i.shareholderStructure || "\u672A\u78BA\u8A8D",
          shareholderDisclosureStatus: i.shareholderDisclosureStatus || "\u672A\u78BA\u8A8D",
          employeeCount: {
            fullTime: i.employeeCount?.fullTime ?? null,
            partTime: i.employeeCount?.partTime ?? null,
            total: i.employeeCount?.total ?? null
          },
          familyStructure: i.familyStructure || "\u672A\u78BA\u8A8D",
          personalityProfile: i.personalityProfile || "\u672A\u78BA\u8A8D",
          businessOverview: i.businessOverview || "\u672A\u78BA\u8A8D",
          currentYearFinancials: {
            revenue: i.financials?.currentYear?.revenue?.toString() || null,
            grossProfit: i.financials?.currentYear?.grossProfit?.toString() || null,
            operatingProfit: i.financials?.currentYear?.operatingProfit?.toString() || null
          },
          nextYearForecasts: {
            revenue: i.financials?.nextYearForecast?.revenue?.toString() || null,
            grossProfit: i.financials?.nextYearForecast?.grossProfit?.toString() || null,
            operatingProfit: i.financials?.nextYearForecast?.operatingProfit?.toString() || null
          },
          companyStrengths: Array.isArray(i.companyStrengths) ? i.companyStrengths : [],
          companyChallenges: Array.isArray(i.companyChallenges) ? i.companyChallenges : [],
          buyerPreferences: i.buyerPreferences || "\u672A\u78BA\u8A8D",
          confidenceLevel: i.confidenceLevel || "\u4F4E",
          dataQuality: {
            completeness: i.dataQuality?.completeness ?? 0,
            clarity: i.dataQuality?.clarity ?? 0
          }
        };
      } catch (i) {
        console.error("[assembleVideoReviewResponse] caseSummary\u5909\u63DB\u30A8\u30E9\u30FC:", i);
        return;
      }
  }, "transformCaseSummary"), p = /* @__PURE__ */ u((t) => {
    if (t) {
      console.log("[transformMeetingSummary] \u5165\u529B\u30C7\u30FC\u30BF:", JSON.stringify(t, null, 2));
      try {
        let i = /* @__PURE__ */ u((_, f) => Array.isArray(_) ? _.map((m) => typeof m == "string" ? m : typeof m == "object" && m !== null ? f && m[f] ? m[f] : m.name && m.affiliation ? `${m.name} (${m.affiliation})` : m.name ? m.name : Object.values(m).join(", ") : String(m)).join(", ") : "\u60C5\u5831\u304C\u3042\u308A\u307E\u305B\u3093", "extractFromArray"), a = /* @__PURE__ */ u((_) => {
          if (!_ || typeof _ != "object") return "\u60C5\u5831\u304C\u3042\u308A\u307E\u305B\u3093";
          let f = Object.values(_).filter((m) => m != null);
          return f.length > 0 ? f.join(", ") : "\u60C5\u5831\u304C\u3042\u308A\u307E\u305B\u3093";
        }, "extractFromObject"), y = {
          // 基本情報 - ネストされた構造から文字列に変換
          attendees: t.Attendees ? i(t.Attendees) : t.attendees || "\u53C2\u52A0\u8005\u60C5\u5831\u304C\u898B\u3064\u304B\u308A\u307E\u305B\u3093",
          businessContent: t.BusinessContent ? `\u5F53\u793E\u4E8B\u696D: ${t.BusinessContent.ourCompany || "\u4E0D\u660E"}, \u5BFE\u8C61\u4F01\u696D\u4E8B\u696D: ${a(t.BusinessContent.targetCompany || {})}` : t.businessContent || "\u4E8B\u696D\u5185\u5BB9\u304C\u898B\u3064\u304B\u308A\u307E\u305B\u3093",
          companyOverview: t.CompanyOverview ? a(t.CompanyOverview) : t.companyOverview || "\u4F1A\u793E\u6982\u8981\u304C\u898B\u3064\u304B\u308A\u307E\u305B\u3093",
          // M&A関連情報
          maRelatedInfo: t.MARelatedInfo ? a(t.MARelatedInfo) : t.maRelatedInfo || "M&A\u95A2\u9023\u60C5\u5831\u304C\u898B\u3064\u304B\u308A\u307E\u305B\u3093",
          ownerInfo: t.OwnerInfo ? a(t.OwnerInfo) : t.ownerInfo || "\u30AA\u30FC\u30CA\u30FC\u60C5\u5831\u304C\u898B\u3064\u304B\u308A\u307E\u305B\u3093",
          stockPriceExpectation: t.StockPriceExpectation ? a(t.StockPriceExpectation) : t.stockPriceExpectation || "\u682A\u4FA1\u671F\u5F85\u5024\u304C\u898B\u3064\u304B\u308A\u307E\u305B\u3093",
          transferIntention: t.TransferIntention ? a(t.TransferIntention) : t.transferIntention || "\u8B72\u6E21\u610F\u601D\u304C\u898B\u3064\u304B\u308A\u307E\u305B\u3093",
          // 財務・人物情報
          financialContent: t.FinancialContent ? a(t.FinancialContent) : t.financialContent || "\u8CA1\u52D9\u5185\u5BB9\u304C\u898B\u3064\u304B\u308A\u307E\u305B\u3093",
          intervieweeInfo: t.IntervieweeInfo ? a(t.IntervieweeInfo) : t.intervieweeInfo || "\u9762\u8AC7\u8005\u60C5\u5831\u304C\u898B\u3064\u304B\u308A\u307E\u305B\u3093",
          personalCharacteristics: t.PersonalCharacteristics ? a(t.PersonalCharacteristics) : t.personalCharacteristics || "\u4EBA\u7269\u7279\u6027\u304C\u898B\u3064\u304B\u308A\u307E\u305B\u3093",
          // その他
          brokerMeetingHistory: t.BrokerMeetingHistory ? a(t.BrokerMeetingHistory) : t.brokerMeetingHistory || "\u4EF2\u4ECB\u4F1A\u793E\u3068\u306E\u9762\u8AC7\u5C65\u6B74\u304C\u898B\u3064\u304B\u308A\u307E\u305B\u3093",
          shareholderInfo: t.ShareholderInfo ? a(t.ShareholderInfo) : t.shareholderInfo || "\u682A\u4E3B\u60C5\u5831\u304C\u898B\u3064\u304B\u308A\u307E\u305B\u3093",
          nextActions: t.NextActions ? a(t.NextActions) : t.nextActions || "\u6B21\u306E\u30A2\u30AF\u30B7\u30E7\u30F3\u304C\u898B\u3064\u304B\u308A\u307E\u305B\u3093",
          todos: t.Todos ? a(t.Todos) : t.todos || "TODO\u304C\u898B\u3064\u304B\u308A\u307E\u305B\u3093",
          // データ品質
          confidenceLevel: t.ConfidenceLevel ? a(t.ConfidenceLevel) : t.confidenceLevel || "\u4FE1\u983C\u5EA6\u304C\u8A2D\u5B9A\u3055\u308C\u3066\u3044\u307E\u305B\u3093",
          dataQuality: t.DataQuality ? t.DataQuality : t.dataQuality || { clarity: 0, completeness: 0 },
          // 側面情報
          clientSide: t.ClientSide ? a(t.ClientSide) : t.clientSide || "\u9867\u5BA2\u5074\u60C5\u5831\u304C\u898B\u3064\u304B\u308A\u307E\u305B\u3093",
          ourSide: t.OurSide ? a(t.OurSide) : t.ourSide || "\u5F53\u65B9\u60C5\u5831\u304C\u898B\u3064\u304B\u308A\u307E\u305B\u3093"
        };
        return console.log("[transformMeetingSummary] \u5909\u63DB\u7D50\u679C:", JSON.stringify(y, null, 2)), y;
      } catch (i) {
        console.error("[assembleVideoReviewResponse] meetingSummary\u5909\u63DB\u30A8\u30E9\u30FC:", i);
        return;
      }
    }
  }, "transformMeetingSummary");
  return {
    id: n._id,
    title: n.title,
    // 動画の実際のタイトルを追加
    videoType: n.type || "unknown",
    conversationLogs: d,
    scores: s,
    overallComment: (() => {
      let t = g?.overallComment || g?.overall_comment || "\u8A55\u4FA1\u304C\u672A\u5B8C\u4E86\u3067\u3059";
      return console.log("[assembleVideoReviewResponse] \u30B3\u30E1\u30F3\u30C8\u53D6\u5F97:", {
        evaluationHas: !!g,
        overallComment: g?.overallComment,
        overall_comment: g?.overall_comment,
        finalComment: t
      }), t;
    })(),
    improvementSummary: g?.improvementSummary || g?.improvement_suggestions?.join(`
`) || "",
    details: c,
    meeting_minutes: r(
      l.meeting_minutes || l?.quick_transcription?.meeting_minutes
    ),
    meeting_minutes_status: l.meeting_minutes_status || l?.quick_transcription?.meeting_minutes_status || (l.meeting_minutes || l?.quick_transcription?.meeting_minutes ? "completed" : "pending"),
    meeting_minutes_generated_at: (() => {
      let t = l.meeting_minutes_generated_at || l?.quick_transcription?.meeting_minutes_generated_at;
      if (t)
        try {
          if (typeof t == "string" && t.includes("T"))
            return t;
          if (typeof t == "number" && !isNaN(t) && t > 0)
            return new Date(t).toISOString();
          if (typeof t == "string") {
            let i = new Date(t);
            if (!isNaN(i.getTime()))
              return i.toISOString();
          }
          return;
        } catch (i) {
          console.error("[assembleVideoReviewResponse] meeting_minutes_generated_at\u5909\u63DB\u30A8\u30E9\u30FC:", i);
          return;
        }
    })(),
    case_summary: o(l.case_summary),
    case_summary_status: l.case_summary_status || (l.case_summary ? "completed" : "pending"),
    case_summary_generated_at: (() => {
      let t = l.case_summary_generated_at;
      if (t)
        try {
          if (typeof t == "string" && t.includes("T"))
            return t;
          if (typeof t == "number" && !isNaN(t) && t > 0)
            return new Date(t).toISOString();
          if (typeof t == "string") {
            let i = new Date(t);
            if (!isNaN(i.getTime()))
              return i.toISOString();
          }
          return;
        } catch (i) {
          console.error("[assembleVideoReviewResponse] case_summary_generated_at\u5909\u63DB\u30A8\u30E9\u30FC:", i);
          return;
        }
    })(),
    meeting_summary: p(l.meeting_summary),
    meeting_summary_status: l.meeting_summary_status || (l.meeting_summary ? "completed" : "pending"),
    meeting_summary_generated_at: (() => {
      let t = l.meeting_summary_generated_at;
      if (t)
        try {
          if (typeof t == "string" && t.includes("T"))
            return t;
          if (typeof t == "number" && !isNaN(t) && t > 0)
            return new Date(t).toISOString();
          if (typeof t == "string") {
            let i = new Date(t);
            if (!isNaN(i.getTime()))
              return i.toISOString();
          }
          return;
        } catch (i) {
          console.error("[assembleVideoReviewResponse] meeting_summary_generated_at\u5909\u63DB\u30A8\u30E9\u30FC:", i);
          return;
        }
    })(),
    transcript_with_speaker: l.transcript_with_speaker || void 0,
    // グループ情報
    upload_session_id: n.upload_session_id || void 0,
    is_group_primary: n.is_group_primary || void 0,
    file_count: n.file_count || void 0
  };
}
u(R, "assembleVideoReviewResponse");
function T(n) {
  let l = [
    n.hearingAbility,
    n.problemSetting,
    n.knowledge,
    n.negotiation,
    n.businessManners
  ].filter((g) => typeof g == "number");
  return l.length > 0 ? l.reduce((g, d) => g + d, 0) / l.length : 0;
}
u(T, "calculateAverageScore");
function x(n) {
  if (!n.formatted_text)
    return [];
  try {
    return n.formatted_text.split(`
`).map((g, d) => {
      let s = g.match(/^(\w+):\s*(.+)$/);
      return s ? {
        speaker: s[1],
        text: s[2],
        timestamp: `${Math.floor(d * S.CONVERSATION_TIMESTAMP_INTERVAL)}${S.DEFAULT_TIMESTAMP_FORMAT}`
      } : {
        speaker: "Unknown",
        text: g,
        timestamp: `${Math.floor(d * S.CONVERSATION_TIMESTAMP_INTERVAL)}${S.DEFAULT_TIMESTAMP_FORMAT}`
      };
    }).filter((g) => g.text.trim().length > 0);
  } catch (l) {
    return console.error("\u4F1A\u8A71\u30ED\u30B0\u751F\u6210\u30A8\u30E9\u30FC:", l), [];
  }
}
u(x, "generateConversationLogs");
function E(n) {
  let l = /* @__PURE__ */ u((r) => {
    if (typeof r != "number")
      return console.log(`[convertScore] \u7121\u52B9\u306A\u30B9\u30B3\u30A2: ${r} (type: ${typeof r})`), 0;
    let o;
    return r <= 1 ? o = Math.round(r * 5 * 2) / 2 : r <= 5 ? o = Math.round(r * 2) / 2 : r <= 10 ? o = Math.round(r / 10 * 5 * 2) / 2 : r <= 100 ? o = Math.round(r / 100 * 5 * 2) / 2 : o = 5, console.log(`[convertScore] ${r} \u2192 ${o}`), o;
  }, "convertScore"), g = /* @__PURE__ */ u((r, o = "\u5206\u6790\u60C5\u5831\u304C\u5229\u7528\u3067\u304D\u307E\u305B\u3093") => r && typeof r == "string" && r.trim().length > 0 ? r : o, "getAnalysisContent"), d = /* @__PURE__ */ u((r, o) => {
    let p = [], t = [];
    return r && typeof r == "string" && r.trim().length > 0 && p.push({
      text: r,
      explanation: "\u3053\u306E\u70B9\u304C\u512A\u308C\u3066\u3044\u308B\u7406\u7531"
    }), o && typeof o == "string" && o.trim().length > 0 && t.push({
      text: o,
      explanation: "\u3053\u306E\u70B9\u3092\u6539\u5584\u3059\u308B\u3053\u3068\u3067\u8A55\u4FA1\u304C\u5411\u4E0A\u3057\u307E\u3059"
    }), p.length === 0 && p.push({
      text: "\u5206\u6790\u30C7\u30FC\u30BF\u304B\u3089\u826F\u3044\u4F8B\u3092\u62BD\u51FA\u4E2D\u3067\u3059",
      explanation: "\u8A73\u7D30\u306A\u5206\u6790\u304C\u5B8C\u4E86\u3059\u308B\u3068\u5177\u4F53\u4F8B\u304C\u8868\u793A\u3055\u308C\u307E\u3059"
    }), t.length === 0 && t.push({
      text: "\u5206\u6790\u30C7\u30FC\u30BF\u304B\u3089\u6539\u5584\u70B9\u3092\u62BD\u51FA\u4E2D\u3067\u3059",
      explanation: "\u8A73\u7D30\u306A\u5206\u6790\u304C\u5B8C\u4E86\u3059\u308B\u3068\u5177\u4F53\u7684\u306A\u6539\u5584\u63D0\u6848\u304C\u8868\u793A\u3055\u308C\u307E\u3059"
    }), { goodExamples: p, badExamples: t };
  }, "createExamples"), s = /* @__PURE__ */ u((r, o, p, t, i) => {
    console.log("[createSkillEvaluation] Creating skill evaluation:", {
      score: r,
      description: o,
      hasAnalysis: !!p,
      hasStrength: !!t,
      hasWeakness: !!i,
      analysisLength: p?.length || 0,
      strengthLength: t?.length || 0,
      weaknessLength: i?.length || 0
    });
    let a = g(p), { goodExamples: y, badExamples: _ } = d(t, i), f = {
      score: r,
      description: o,
      details: [
        `\u8A55\u4FA1\u30B9\u30B3\u30A2: ${r}/5.0`,
        a,
        t ? `\u5F37\u307F: ${t}` : "\u5F37\u307F\u306E\u5206\u6790\u3092\u5B9F\u884C\u4E2D\u3067\u3059",
        i ? `\u6539\u5584\u70B9: ${i}` : "\u6539\u5584\u70B9\u306E\u5206\u6790\u3092\u5B9F\u884C\u4E2D\u3067\u3059"
      ].filter((m) => m.length > 0),
      goodExamples: y,
      badExamples: _
    };
    return console.log("[createSkillEvaluation] Result:", {
      ...f,
      detailsCount: f.details.length,
      goodExamplesCount: f.goodExamples.length,
      badExamplesCount: f.badExamples.length
    }), f;
  }, "createSkillEvaluation"), c = /* @__PURE__ */ u((r, o) => typeof r == "number" ? l(r) : typeof o == "number" ? l(o) : 0, "getScore");
  return console.log("[generateEvaluationDetails] \u8A55\u4FA1\u8A73\u7D30\u751F\u6210\u958B\u59CB:", {
    // M&Aロールプレイ用
    hearingAbility_analysis: n.hearingAbility_analysis,
    problemSetting_analysis: n.problemSetting_analysis,
    knowledge_analysis: n.knowledge_analysis,
    negotiation_analysis: n.negotiation_analysis,
    businessManners_analysis: n.businessManners_analysis,
    // AD締結提案用
    adHearingAbility_analysis: n.adHearingAbility_analysis,
    adProposalAbility_analysis: n.adProposalAbility_analysis,
    adKnowledge_analysis: n.adKnowledge_analysis,
    adNegotiation_analysis: n.adNegotiation_analysis,
    adRelationshipBuilding_analysis: n.adRelationshipBuilding_analysis,
    // 譲渡架電用
    callListening_analysis: n.callListening_analysis,
    callImportantInfo_analysis: n.callImportantInfo_analysis,
    callDeepHearing_analysis: n.callDeepHearing_analysis,
    callScheduling_analysis: n.callScheduling_analysis,
    callTone_analysis: n.callTone_analysis,
    // 企業概要書提案（IM）用
    imNeedsHearingProposal_analysis: n.imNeedsHearingProposal_analysis,
    imSellerUnderstanding_analysis: n.imSellerUnderstanding_analysis,
    imBuyerUnderstanding_analysis: n.imBuyerUnderstanding_analysis,
    imSynergyProposal_analysis: n.imSynergyProposal_analysis,
    imTestClosing_analysis: n.imTestClosing_analysis
  }), {
    hearing: s(
      c(
        n.callListening || n.imNeedsHearingProposal,
        n.hearingAbility || n.adHearingAbility
      ),
      "\u30D2\u30A2\u30EA\u30F3\u30B0\u80FD\u529B\u306E\u8A55\u4FA1",
      n.callListening_analysis || n.imNeedsHearingProposal_analysis || n.hearingAbility_analysis || n.adHearingAbility_analysis,
      n.callListening_strength || n.imNeedsHearingProposal_strength || n.hearingAbility_strength || n.adHearingAbility_strength,
      n.callListening_weakness || n.imNeedsHearingProposal_weakness || n.hearingAbility_weakness || n.adHearingAbility_weakness
    ),
    problemDefinition: s(
      c(
        n.callImportantInfo || n.imSellerUnderstanding,
        n.problemSetting || n.adProposalAbility
      ),
      "\u8AB2\u984C\u8A2D\u5B9A\u80FD\u529B\u306E\u8A55\u4FA1",
      n.callImportantInfo_analysis || n.imSellerUnderstanding_analysis || n.problemSetting_analysis || n.adProposalAbility_analysis,
      n.callImportantInfo_strength || n.imSellerUnderstanding_strength || n.problemSetting_strength || n.adProposalAbility_strength,
      n.callImportantInfo_weakness || n.imSellerUnderstanding_weakness || n.problemSetting_weakness || n.adProposalAbility_weakness
    ),
    reactivity: s(
      c(
        n.callDeepHearing || n.imBuyerUnderstanding,
        n.knowledge || n.adKnowledge
      ),
      "\u53CD\u5FDC\u6027\u30FB\u77E5\u8B58\u306E\u8A55\u4FA1",
      n.callDeepHearing_analysis || n.imBuyerUnderstanding_analysis || n.knowledge_analysis || n.adKnowledge_analysis,
      n.callDeepHearing_strength || n.imBuyerUnderstanding_strength || n.knowledge_strength || n.adKnowledge_strength,
      n.callDeepHearing_weakness || n.imBuyerUnderstanding_weakness || n.knowledge_weakness || n.adKnowledge_weakness
    ),
    counter: s(
      c(
        n.callScheduling || n.imSynergyProposal,
        n.negotiation || n.adNegotiation
      ),
      "\u4EA4\u6E09\u30FB\u5BFE\u5FDC\u80FD\u529B\u306E\u8A55\u4FA1",
      n.callScheduling_analysis || n.imSynergyProposal_analysis || n.negotiation_analysis || n.adNegotiation_analysis,
      n.callScheduling_strength || n.imSynergyProposal_strength || n.negotiation_strength || n.adNegotiation_strength,
      n.callScheduling_weakness || n.imSynergyProposal_weakness || n.negotiation_weakness || n.adNegotiation_weakness
    ),
    businessSense: s(
      c(
        n.callTone || n.imTestClosing,
        n.businessManners || n.adRelationshipBuilding
      ),
      "\u30D3\u30B8\u30CD\u30B9\u30BB\u30F3\u30B9\u306E\u8A55\u4FA1",
      n.callTone_analysis || n.imTestClosing_analysis || n.businessManners_analysis || n.adRelationshipBuilding_analysis,
      n.callTone_strength || n.imTestClosing_strength || n.businessManners_strength || n.adRelationshipBuilding_strength,
      n.callTone_weakness || n.imTestClosing_weakness || n.businessManners_weakness || n.adRelationshipBuilding_weakness
    )
  };
}
u(E, "generateEvaluationDetails");
function j() {
  let n = /* @__PURE__ */ u(() => ({
    score: 0,
    description: "\u8A55\u4FA1\u304C\u672A\u5B8C\u4E86\u3067\u3059",
    details: ["\u8A55\u4FA1\u51E6\u7406\u3092\u5B9F\u884C\u3057\u3066\u304F\u3060\u3055\u3044"],
    goodExamples: [],
    badExamples: []
  }), "createDefaultSkillEvaluation");
  return {
    hearing: n(),
    problemDefinition: n(),
    reactivity: n(),
    counter: n(),
    businessSense: n()
  };
}
u(j, "generateDefaultDetails");
var F = w({
  args: {
    videoId: e.id("videos"),
    format: e.optional(e.union(e.literal("pdf"), e.literal("json")))
  },
  returns: e.object({
    success: e.boolean(),
    content: e.optional(e.string()),
    fileName: e.optional(e.string()),
    contentType: e.optional(e.string()),
    message: e.string()
  }),
  handler: /* @__PURE__ */ u(async (n, l) => {
    try {
      if (await h(n), !await n.db.get(l.videoId))
        return {
          success: !1,
          message: "\u52D5\u753B\u304C\u898B\u3064\u304B\u308A\u307E\u305B\u3093"
        };
      let d = await n.runQuery(I.videos.review.getVideoReviewData, {
        videoId: l.videoId
      });
      if (!d)
        return {
          success: !1,
          message: "\u30EC\u30D3\u30E5\u30FC\u30C7\u30FC\u30BF\u304C\u898B\u3064\u304B\u308A\u307E\u305B\u3093"
        };
      let s = l.format || "json";
      return s === "json" ? {
        success: !0,
        content: JSON.stringify(d, null, 2),
        fileName: `video-review-${l.videoId}.json`,
        contentType: "application/json",
        message: "\u30EC\u30D3\u30E5\u30FC\u30D5\u30A1\u30A4\u30EB\u306E\u751F\u6210\u304C\u5B8C\u4E86\u3057\u307E\u3057\u305F"
      } : s === "pdf" ? {
        success: !1,
        message: "PDF\u5F62\u5F0F\u306E\u30C0\u30A6\u30F3\u30ED\u30FC\u30C9\u306F\u73FE\u5728\u958B\u767A\u4E2D\u3067\u3059"
      } : {
        success: !1,
        message: "\u30B5\u30DD\u30FC\u30C8\u3055\u308C\u3066\u3044\u306A\u3044\u30D5\u30A1\u30A4\u30EB\u5F62\u5F0F\u3067\u3059"
      };
    } catch (g) {
      return console.error("[downloadReviewFile] \u30A8\u30E9\u30FC:", g), {
        success: !1,
        message: "\u30EC\u30D3\u30E5\u30FC\u30D5\u30A1\u30A4\u30EB\u306E\u751F\u6210\u4E2D\u306B\u30A8\u30E9\u30FC\u304C\u767A\u751F\u3057\u307E\u3057\u305F"
      };
    }
  }, "handler")
});

export {
  $ as a,
  V as b,
  U as c,
  F as d
};
//# sourceMappingURL=PT45IVKL.js.map
