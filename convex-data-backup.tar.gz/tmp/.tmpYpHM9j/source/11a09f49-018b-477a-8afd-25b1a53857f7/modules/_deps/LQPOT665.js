import {
  n as e,
  p as n
} from "./6XQQNYIR.js";
import {
  j as i,
  n as t
} from "./3TDUHHJO.js";

// convex/schema/notification.ts
n();
t();
var o = i.union(
  i.literal("pending"),
  i.literal("sent"),
  i.literal("delivered"),
  i.literal("read"),
  i.literal("failed"),
  i.literal("cancelled")
), a = i.union(
  i.literal("low"),
  i.literal("normal"),
  i.literal("high"),
  i.literal("urgent")
), r = i.union(
  i.literal("queued"),
  i.literal("processing"),
  i.literal("sent"),
  i.literal("delivered"),
  i.literal("opened"),
  i.literal("clicked"),
  i.literal("bounced"),
  i.literal("failed"),
  i.literal("spam")
), _ = {
  // 拡張通知設定 - 簡素化
  advancedNotificationSettings: e({
    user_id: i.id("users"),
    // 設定を単純化
    in_app_enabled: i.boolean(),
    in_app_sound: i.boolean(),
    in_app_desktop: i.boolean(),
    in_app_badge: i.boolean(),
    email_enabled: i.boolean(),
    email_frequency: i.string(),
    // "immediate", "hourly", "daily", "weekly"
    email_digest: i.boolean(),
    push_enabled: i.boolean(),
    push_device_tokens: i.optional(i.array(i.string())),
    push_quiet_hours_start: i.optional(i.string()),
    push_quiet_hours_end: i.optional(i.string()),
    push_timezone: i.optional(i.string()),
    sms_enabled: i.boolean(),
    sms_phone_number: i.optional(i.string()),
    sms_country_code: i.optional(i.string()),
    // イベント設定を単純化
    evaluations_completed: i.boolean(),
    evaluations_failed: i.boolean(),
    evaluations_overdue: i.boolean(),
    videos_uploaded: i.boolean(),
    videos_processed: i.boolean(),
    videos_shared: i.boolean(),
    training_assigned: i.boolean(),
    training_completed: i.boolean(),
    training_reminder: i.boolean(),
    system_maintenance: i.boolean(),
    system_updates: i.boolean(),
    system_security: i.boolean(),
    mentions_comments: i.boolean(),
    mentions_reviews: i.boolean(),
    mentions_messages: i.boolean()
  }).index("by_user_id", ["user_id"]),
  // 拡張通知メッセージ - 簡素化
  advancedNotifications: e({
    notification_id: i.string(),
    recipient_id: i.id("users"),
    sender_id: i.optional(i.id("users")),
    notification_type: i.string(),
    // より自由な文字列型
    priority: a,
    status: o,
    title: i.string(),
    message: i.string(),
    // リッチコンテンツを簡素化
    html_content: i.optional(i.string()),
    markdown_content: i.optional(i.string()),
    // メタデータを簡素化
    resource_id: i.optional(i.string()),
    resource_type: i.optional(i.string()),
    tracking_id: i.optional(i.string()),
    campaign_id: i.optional(i.string()),
    // チャンネル配信情報を単純化
    channels_json: i.optional(i.string()),
    // JSON文字列として保存
    scheduled_for: i.optional(i.number()),
    expires_at: i.optional(i.number()),
    read_at: i.optional(i.number()),
    clicked_at: i.optional(i.number()),
    dismissed_at: i.optional(i.number())
  }).index("by_recipient", ["recipient_id"]).index("by_sender", ["sender_id"]).index("by_type", ["notification_type"]).index("by_priority", ["priority"]).index("by_status", ["status"]).index("by_scheduled", ["scheduled_for"]).index("by_read_status", ["recipient_id", "read_at"]),
  // 通知テンプレート - 簡素化
  notificationTemplates: e({
    template_id: i.string(),
    name: i.string(),
    description: i.optional(i.string()),
    notification_type: i.string(),
    channels: i.array(i.string()),
    // 文字列配列として簡素化
    // テンプレートを単純化
    in_app_template: i.optional(i.string()),
    // JSON文字列
    email_template: i.optional(i.string()),
    // JSON文字列
    push_template: i.optional(i.string()),
    // JSON文字列
    sms_template: i.optional(i.string()),
    // JSON文字列
    variables_json: i.optional(i.string()),
    // JSON文字列
    localization_json: i.optional(i.string()),
    // JSON文字列
    created_by: i.id("users"),
    version: i.string(),
    status: i.union(i.literal("draft"), i.literal("active"), i.literal("archived")),
    usage_count: i.optional(i.number()),
    last_used_at: i.optional(i.number())
  }).index("by_template_id", ["template_id"]).index("by_type", ["notification_type"]).index("by_created_by", ["created_by"]).index("by_status", ["status"]),
  // 通知購読管理 - 簡素化
  notificationSubscriptions: e({
    subscription_id: i.string(),
    user_id: i.id("users"),
    subscription_type: i.string(),
    // より自由な文字列型
    topic_id: i.optional(i.string()),
    topic_name: i.optional(i.string()),
    channels: i.array(i.string()),
    // 文字列配列として簡素化
    // フィルターを単純化
    filters_json: i.optional(i.string()),
    // JSON文字列として保存
    status: i.union(i.literal("active"), i.literal("paused"), i.literal("cancelled")),
    created_at: i.number(),
    updated_at: i.number()
  }).index("by_user_id", ["user_id"]).index("by_subscription_type", ["subscription_type"]).index("by_topic_id", ["topic_id"]).index("by_status", ["status"]),
  // 通知配信ログ - 簡素化
  notificationDeliveryLogs: e({
    log_id: i.string(),
    notification_id: i.string(),
    channel: i.string(),
    // 文字列として簡素化
    provider: i.optional(i.string()),
    recipient_id: i.id("users"),
    status: r,
    attempt_count: i.number(),
    sent_at: i.optional(i.number()),
    delivered_at: i.optional(i.number()),
    opened_at: i.optional(i.number()),
    clicked_at: i.optional(i.number()),
    failed_at: i.optional(i.number()),
    error_code: i.optional(i.string()),
    error_message: i.optional(i.string()),
    provider_response_json: i.optional(i.string()),
    // JSON文字列
    cost: i.optional(i.number()),
    processing_time_ms: i.optional(i.number()),
    // メタデータを単純化
    device_type: i.optional(i.string()),
    client_version: i.optional(i.string()),
    user_agent: i.optional(i.string()),
    ip_address: i.optional(i.string())
  }).index("by_notification_id", ["notification_id"]).index("by_channel", ["channel"]).index("by_recipient_id", ["recipient_id"]).index("by_status", ["status"]),
  // 通知統計 - 簡素化
  notificationStats: e({
    stat_id: i.string(),
    period_type: i.union(
      i.literal("hour"),
      i.literal("day"),
      i.literal("week"),
      i.literal("month")
    ),
    period_start: i.number(),
    period_end: i.number(),
    // 基本統計
    total_sent: i.number(),
    total_delivered: i.number(),
    total_opened: i.number(),
    total_clicked: i.number(),
    total_failed: i.number(),
    delivery_rate: i.number(),
    open_rate: i.number(),
    click_rate: i.number(),
    avg_delivery_time_ms: i.number(),
    // 詳細統計をJSON文字列として保存
    by_channel_json: i.optional(i.string()),
    by_type_json: i.optional(i.string()),
    cost_metrics_json: i.optional(i.string())
  }).index("by_period", ["period_type", "period_start"]).index("by_period_start", ["period_start"])
};

export {
  _ as a
};
//# sourceMappingURL=LQPOT665.js.map
