import {
  a
} from "./RUVYHBJQ.js";

// convex/lib/audioConverter.ts
function u(o) {
  return {
    "audio/m4a": "m4a",
    "audio/x-m4a": "m4a",
    "audio/aac": "aac",
    "audio/x-aac": "aac",
    "audio/mp4": "m4a",
    "audio/mp3": "mp3",
    "audio/mpeg": "mp3",
    "audio/x-mp3": "mp3",
    "audio/wav": "wav",
    "audio/wave": "wav",
    "audio/x-wav": "wav",
    "audio/ogg": "ogg",
    "audio/x-ogg": "ogg",
    "audio/opus": "opus",
    "audio/webm": "webm"
  }[o] || "audio";
}
a(u, "getFileExtension");
function d(o) {
  return !["audio/flac", "audio/x-flac", "audio/wav", "audio/wave", "audio/x-wav"].includes(o);
}
a(d, "needsConversionToFLAC");
function e() {
  return [
    "audio/m4a",
    "audio/x-m4a",
    "audio/aac",
    "audio/x-aac",
    "audio/mp4",
    "audio/mp3",
    "audio/mpeg",
    "audio/x-mp3",
    "audio/ogg",
    "audio/x-ogg",
    "audio/opus",
    "audio/webm"
  ];
}
a(e, "getConvertibleFormats");

export {
  u as a,
  d as b,
  e as c
};
//# sourceMappingURL=PJZC2FZI.js.map
