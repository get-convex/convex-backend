import {
  b as i
} from "./_deps/PJZC2FZI.js";
import {
  e as r
} from "./_deps/75JH2J25.js";
import "./_deps/6XQQNYIR.js";
import {
  j as e,
  n as s
} from "./_deps/3TDUHHJO.js";
import {
  a as n
} from "./_deps/RUVYHBJQ.js";

// convex/audioConversionActions.ts
s();
var C = r({
  args: {
    audioData: e.bytes(),
    mimeType: e.string(),
    originalFileName: e.string()
  },
  returns: e.object({
    error: e.string(),
    reason: e.string(),
    suggestion: e.string()
  }),
  handler: /* @__PURE__ */ n(async (t, o) => (console.log(`[convertToFLAC] \u5909\u63DB\u8981\u6C42: ${o.originalFileName} (${o.mimeType})`), {
    error: "Convex\u74B0\u5883\u3067\u306F\u97F3\u58F0\u5909\u63DB\u304C\u3067\u304D\u307E\u305B\u3093",
    reason: "Convex\u3067\u306F\u5916\u90E8\u30D7\u30ED\u30BB\u30B9\uFF08FFmpeg\u7B49\uFF09\u3092\u5B9F\u884C\u3067\u304D\u307E\u305B\u3093",
    suggestion: "\u4E8B\u524D\u306BFLAC/WAV\u5F62\u5F0F\u306B\u5909\u63DB\u3057\u3066\u304B\u3089\u30A2\u30C3\u30D7\u30ED\u30FC\u30C9\u3057\u3066\u304F\u3060\u3055\u3044"
  }), "handler")
}), p = r({
  args: {
    mimeType: e.string(),
    fileName: e.string()
  },
  returns: e.object({
    needsConversion: e.boolean(),
    targetFormat: e.string(),
    reason: e.string()
  }),
  handler: /* @__PURE__ */ n(async (t, o) => i(o.mimeType) ? (console.log(`[checkConversionNeeded] ${o.fileName} \u306F\u5909\u63DB\u304C\u5FC5\u8981\u3067\u3059 (${o.mimeType})`), {
    needsConversion: !0,
    targetFormat: "audio/flac",
    reason: `${o.mimeType}\u5F62\u5F0F\u306FGCP Speech API v2\u3067\u672A\u5BFE\u5FDC\u306E\u305F\u3081\u3001FLAC\u5F62\u5F0F\u306B\u5909\u63DB\u3057\u307E\u3059`
  }) : (console.log(`[checkConversionNeeded] ${o.fileName} \u306F\u5909\u63DB\u4E0D\u8981\u3067\u3059 (${o.mimeType})`), {
    needsConversion: !1,
    targetFormat: o.mimeType,
    reason: `${o.mimeType}\u5F62\u5F0F\u306FGCP Speech API v2\u3067\u5BFE\u5FDC\u6E08\u307F\u3067\u3059`
  }), "handler")
});
export {
  p as checkConversionNeeded,
  C as convertToFLAC
};
//# sourceMappingURL=audioConversionActions.js.map
