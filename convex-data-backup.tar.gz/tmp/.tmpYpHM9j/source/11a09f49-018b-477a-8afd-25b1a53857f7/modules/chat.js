import {
  b as w,
  d as b,
  e as _,
  g as j,
  h as d,
  j as m
} from "./_deps/RYP3LOHW.js";
import {
  j as u,
  k as p
} from "./_deps/MNKTBR2W.js";
import {
  c as o,
  f as g
} from "./_deps/OQRPCOVT.js";
import "./_deps/SZVQRWFS.js";
import {
  a as h,
  b as l,
  c,
  d as y
} from "./_deps/75JH2J25.js";
import "./_deps/6XQQNYIR.js";
import {
  j as e,
  n as v
} from "./_deps/3TDUHHJO.js";
import {
  a
} from "./_deps/RUVYHBJQ.js";

// convex/chat.ts
v();
var E = c({
  args: {},
  returns: e.union(
    e.object({
      success: e.literal(!0),
      data: e.object({
        sessionId: e.string(),
        welcomeMessage: e.string()
      }),
      timestamp: e.number()
    }),
    e.object({
      success: e.literal(!1),
      error: e.object({
        code: e.string(),
        message: e.string(),
        details: e.optional(e.string())
      }),
      timestamp: e.number()
    })
  ),
  handler: /* @__PURE__ */ a(async (t, s) => {
    try {
      let { user: i } = await o(t), n = globalThis.crypto.randomUUID();
      await t.db.insert("chatSessions", {
        session_id: n,
        user_id: i._id,
        status: "active",
        last_message_at: Date.now(),
        title: "\u65B0\u3057\u3044\u30C1\u30E3\u30C3\u30C8"
      });
      let I = "\u3053\u3093\u306B\u3061\u306F\uFF01\u7814\u4FEE\u306B\u3064\u3044\u3066\u3054\u8CEA\u554F\u304C\u3054\u3056\u3044\u307E\u3057\u305F\u3089\u3001\u304A\u6C17\u8EFD\u306B\u304A\u805E\u304D\u304F\u3060\u3055\u3044\u3002";
      return await b(t, {
        sessionId: n,
        userId: i._id,
        action: "session_start"
      }), p({
        sessionId: n,
        welcomeMessage: I
      });
    } catch (i) {
      return m(t, i, {
        operation: "\u30BB\u30C3\u30B7\u30E7\u30F3\u958B\u59CB"
      });
    }
  }, "handler")
}), O = c({
  args: {
    sessionId: e.string(),
    message: e.string()
  },
  returns: e.union(
    e.object({
      success: e.literal(!0),
      data: e.object({
        message: e.string(),
        sessionId: e.string(),
        contextInfo: e.object({
          timestamp: e.number(),
          messageLength: e.number()
        })
      }),
      timestamp: e.number()
    }),
    e.object({
      success: e.literal(!1),
      error: e.object({
        code: e.string(),
        message: e.string(),
        details: e.optional(e.string())
      }),
      timestamp: e.number()
    })
  ),
  handler: /* @__PURE__ */ a(async (t, s) => {
    try {
      let i = w(s.message);
      if (!i.isValid)
        return u(
          i.error?.includes("\u5165\u529B\u3057\u3066") ? "MESSAGE_EMPTY" : "MESSAGE_TOO_LONG",
          i.error || "\u691C\u8A3C\u30A8\u30E9\u30FC"
        );
      let { user: n } = await o(t);
      return await g(t, s.sessionId, n._id), s.message.length > 4e3 ? u("MESSAGE_TOO_LONG", "\u30E1\u30C3\u30BB\u30FC\u30B8\u304C\u9577\u3059\u304E\u307E\u3059\uFF08\u6700\u59274000\u6587\u5B57\uFF09\u3002") : (await t.db.insert("chatConversations", {
        user_id: n._id,
        session_id: s.sessionId,
        role: "user",
        message: s.message,
        metadata: d(s.message)
      }), await _(t, s.sessionId), await b(t, {
        sessionId: s.sessionId,
        userId: n._id,
        action: "message_sent",
        metadata: {
          messageLength: s.message.length
        }
      }), p({
        message: "\u30E1\u30C3\u30BB\u30FC\u30B8\u304C\u9001\u4FE1\u3055\u308C\u307E\u3057\u305F\u3002",
        sessionId: s.sessionId,
        contextInfo: d(s.message)
      }));
    } catch (i) {
      return m(t, i, {
        sessionId: s.sessionId,
        operation: "\u30E1\u30C3\u30BB\u30FC\u30B8\u9001\u4FE1"
      });
    }
  }, "handler")
}), A = h({
  args: {
    sessionId: e.string(),
    limit: e.optional(e.number())
  },
  returns: e.union(
    e.array(
      e.object({
        _id: e.id("chatConversations"),
        _creationTime: e.number(),
        role: e.string(),
        message: e.string(),
        metadata: e.optional(
          e.object({
            timestamp: e.number(),
            messageLength: e.optional(e.number()),
            generated: e.optional(e.boolean()),
            modelVersion: e.optional(e.string()),
            responseTime: e.optional(e.number()),
            confidence: e.optional(e.number())
          })
        )
      })
    ),
    e.object({
      success: e.literal(!1),
      error: e.object({
        code: e.string(),
        message: e.string(),
        details: e.optional(e.string())
      }),
      timestamp: e.number()
    })
  ),
  handler: /* @__PURE__ */ a(async (t, s) => {
    try {
      let { user: i } = await o(t);
      await g(t, s.sessionId, i._id);
      let n = j(s.limit);
      return (await t.db.query("chatConversations").withIndex("by_session_id", (r) => r.eq("session_id", s.sessionId)).order("desc").take(n)).reverse().map((r) => ({
        _id: r._id,
        _creationTime: r._creationTime,
        role: r.role,
        message: r.message,
        metadata: r.metadata
      }));
    } catch (i) {
      return m(t, i, {
        sessionId: s.sessionId,
        operation: "\u30E1\u30C3\u30BB\u30FC\u30B8\u53D6\u5F97"
      });
    }
  }, "handler")
}), C = l({
  args: {
    sessionId: e.string()
  },
  returns: e.array(
    e.object({
      role: e.string(),
      message: e.string()
    })
  ),
  handler: /* @__PURE__ */ a(async (t, s) => (await t.db.query("chatConversations").withIndex("by_session_id", (n) => n.eq("session_id", s.sessionId)).order("desc").take(10)).reverse().map((n) => ({
    role: n.role,
    message: n.message
  })), "handler")
}), q = l({
  args: {},
  returns: e.array(
    e.object({
      trainingTitle: e.string(),
      summary: e.string(),
      keyPoints: e.array(e.string()),
      learningObjectives: e.array(e.string())
    })
  ),
  handler: /* @__PURE__ */ a(async (t, s) => (await t.db.query("trainingSummaries").take(10)).map((n) => ({
    trainingTitle: `\u7814\u4FEE ${n.training_id}`,
    summary: typeof n.summary == "string" ? n.summary : JSON.stringify(n.summary),
    keyPoints: ["\u30DD\u30A4\u30F3\u30C81", "\u30DD\u30A4\u30F3\u30C82"],
    // 後で実際のデータに置き換え
    learningObjectives: ["\u76EE\u6A191", "\u76EE\u6A192"]
    // 後で実際のデータに置き換え
  })), "handler")
}), U = y({
  args: {
    sessionId: e.string(),
    message: e.string(),
    userId: e.id("users"),
    // Unified users table
    modelUsed: e.optional(e.string())
  },
  returns: e.null(),
  handler: /* @__PURE__ */ a(async (t, s) => (await t.db.insert("chatConversations", {
    user_id: s.userId,
    session_id: s.sessionId,
    role: "assistant",
    message: s.message,
    ai_model: s.modelUsed || "gemini-2.0-flash-exp",
    metadata: d(s.message, {
      generated: !0,
      modelVersion: s.modelUsed
    })
  }), await _(t, s.sessionId), null), "handler")
});
export {
  C as getConversationHistory,
  q as getTrainingSummaries,
  A as listMessages,
  U as saveAIResponse,
  O as sendMessage,
  E as startChatSession
};
//# sourceMappingURL=chat.js.map
