import {
  a as l
} from "../_deps/RUVYHBJQ.js";

// convex/test_helpers/uploads_mocks.ts
var v = {
  standard: "user_standard_001",
  admin: "user_admin_001",
  restricted: "user_restricted_001",
  marketing: "user_marketing_001"
}, s = {
  video: "upload_video_20241128_001",
  document: "upload_doc_001",
  image: "upload_img_001",
  audio: "upload_audio_001",
  large: "upload_large_001",
  chunked: "upload_chunked_001",
  expired: "upload_expired_001",
  nonExistent: "upload_non_existent"
}, c = {
  video: "file_video_001",
  document: "file_doc_001",
  image: "file_img_001",
  audio: "file_audio_001"
}, g = {
  valid: "session_token_valid_abc123",
  expired: "session_token_expired_def456",
  invalid: "session_token_invalid_ghi789"
}, p = {
  valid: "sha256:a1b2c3d4e5f6789012345678901234567890abcdef1234567890abcdef123456",
  invalid: "sha256:incorrect_checksum_123456789",
  video: "sha256:video_checksum_abc123def456789",
  document: "sha256:document_checksum_def456ghi789",
  corrupted: "sha256:corrupted_data_123456"
}, e = {
  small: 1024 * 1024,
  // 1MB
  medium: 50 * 1024 * 1024,
  // 50MB
  large: 500 * 1024 * 1024,
  // 500MB
  extraLarge: 2 * 1024 * 1024 * 1024,
  // 2GB
  overLimit: 5 * 1024 * 1024 * 1024,
  // 5GB
  zero: 0,
  negative: -1024
}, i = {
  video: {
    mp4: "video/mp4",
    avi: "video/avi",
    mov: "video/mov",
    mkv: "video/mkv"
  },
  document: {
    pdf: "application/pdf",
    docx: "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
    txt: "text/plain"
  },
  image: {
    jpeg: "image/jpeg",
    png: "image/png",
    gif: "image/gif",
    webp: "image/webp"
  },
  audio: {
    mp3: "audio/mpeg",
    wav: "audio/wav",
    aac: "audio/aac",
    m4a: "audio/m4a"
  },
  unsupported: {
    executable: "application/x-executable",
    malware: "application/x-malware",
    unknown: "application/octet-stream"
  }
}, d = {
  valid: {
    video: "presentation_training.mp4",
    document: "contract_template.pdf",
    image: "company_logo.png",
    audio: "training_audio.mp3",
    withSpaces: "My Training Video - Final (1).mp4",
    unicode: "\u30C6\u30B9\u30C8\u52D5\u753B \u{1F3A5} \u7814\u4FEE\u7D20\u6750.mp4",
    japanese: "\u55B6\u696D\u7814\u4FEE_\u30D7\u30EC\u30BC\u30F3\u30C6\u30FC\u30B7\u30E7\u30F3\u6280\u8853.mp4"
  },
  invalid: {
    empty: "",
    pathTraversal: "../../malicious.mp4",
    scriptInjection: "<script>alert('xss')<\/script>.mp4",
    longPath: "a".repeat(300) + ".mp4",
    invalidChars: "file|name?.mp4",
    nullByte: "file\0name.mp4"
  }
}, f = {
  // 正常なケース
  validVideo: {
    uploadRequest: {
      fileName: d.valid.video,
      fileSize: e.large,
      contentType: i.video.mp4,
      purpose: "video",
      metadata: {
        title: "\u55B6\u696D\u7814\u4FEE\u52D5\u753B - \u30D7\u30EC\u30BC\u30F3\u30C6\u30FC\u30B7\u30E7\u30F3\u6280\u8853",
        description: "\u65B0\u4EBA\u55B6\u696D\u5411\u3051\u306E\u57FA\u790E\u30D7\u30EC\u30BC\u30F3\u30C6\u30FC\u30B7\u30E7\u30F3\u7814\u4FEE\u52D5\u753B",
        category: "\u7814\u4FEE",
        tags: ["\u55B6\u696D", "\u30D7\u30EC\u30BC\u30F3", "\u57FA\u790E"],
        department: "\u55B6\u696D\u90E8",
        author: "\u7530\u4E2D\u592A\u90CE",
        duration: 3600,
        language: "ja",
        difficulty: "beginner"
      },
      chunked: !1
    }
  },
  validDocument: {
    uploadRequest: {
      fileName: d.valid.document,
      fileSize: e.small * 5,
      // 5MB
      contentType: i.document.pdf,
      purpose: "document",
      metadata: {
        title: "\u5951\u7D04\u66F8\u30C6\u30F3\u30D7\u30EC\u30FC\u30C8",
        department: "\u6CD5\u52D9\u90E8",
        version: "v2.1",
        confidentiality: "internal"
      }
    }
  },
  validImage: {
    uploadRequest: {
      fileName: d.valid.image,
      fileSize: e.small,
      contentType: i.image.png,
      purpose: "image",
      metadata: {
        title: "\u4F1A\u793E\u30ED\u30B4",
        usage: "presentation",
        resolution: "1920x1080"
      }
    }
  },
  validAudio: {
    uploadRequest: {
      fileName: d.valid.audio,
      fileSize: e.medium * 2,
      // 100MB
      contentType: i.audio.mp3,
      purpose: "audio",
      metadata: {
        title: "\u97F3\u58F0\u7814\u4FEE\u7D20\u6750",
        speaker: "\u8B1B\u5E2BA",
        duration: 3600,
        quality: "high"
      }
    }
  },
  // チャンクアップロード
  chunkedUpload: {
    uploadRequest: {
      fileName: "large_training_video.mp4",
      fileSize: e.extraLarge,
      contentType: i.video.mp4,
      purpose: "video",
      metadata: {
        title: "\u8A73\u7D30\u7814\u4FEE\u52D5\u753B",
        quality: "4K",
        duration: 7200,
        bitrate: 5e6
      },
      chunked: !0
    }
  },
  // エラーケース
  oversizeFile: {
    uploadRequest: {
      fileName: "huge_video.mp4",
      fileSize: e.overLimit,
      contentType: i.video.mp4,
      purpose: "video"
    }
  },
  unsupportedType: {
    uploadRequest: {
      fileName: "malicious_file.exe",
      fileSize: e.small,
      contentType: i.unsupported.executable,
      purpose: "document"
    }
  },
  invalidFileName: {
    uploadRequest: {
      fileName: d.invalid.pathTraversal,
      fileSize: e.medium,
      contentType: i.video.mp4,
      purpose: "video"
    }
  },
  oversizeMetadata: {
    uploadRequest: {
      fileName: d.valid.video,
      fileSize: e.medium,
      contentType: i.video.mp4,
      purpose: "video",
      metadata: {
        hugeDescription: "x".repeat(2097152),
        // 2MB
        additionalData: { huge: "data" }
      }
    }
  },
  zeroSize: {
    uploadRequest: {
      fileName: d.valid.video,
      fileSize: e.zero,
      contentType: i.video.mp4,
      purpose: "video"
    }
  },
  negativeSize: {
    uploadRequest: {
      fileName: d.valid.video,
      fileSize: e.negative,
      contentType: i.video.mp4,
      purpose: "video"
    }
  }
}, S = {
  validVideo: {
    uploadId: s.video,
    finalValidation: {
      fileChecksum: p.valid,
      actualFileSize: e.large,
      metadata: {
        title: "\u55B6\u696D\u7814\u4FEE\u52D5\u753B - \u30D7\u30EC\u30BC\u30F3\u30C6\u30FC\u30B7\u30E7\u30F3\u6280\u8853",
        description: "\u65B0\u4EBA\u55B6\u696D\u5411\u3051\u306E\u57FA\u790E\u30D7\u30EC\u30BC\u30F3\u30C6\u30FC\u30B7\u30E7\u30F3\u7814\u4FEE",
        category: "\u7814\u4FEE",
        tags: ["\u55B6\u696D", "\u30D7\u30EC\u30BC\u30F3", "\u57FA\u790E"],
        department: "\u55B6\u696D\u90E8",
        author: "\u7530\u4E2D\u592A\u90CE",
        duration: 3600
      }
    }
  },
  validDocument: {
    uploadId: s.document,
    finalValidation: {
      fileChecksum: p.document,
      actualFileSize: e.small * 5,
      metadata: {
        title: "\u5951\u7D04\u66F8\u30C6\u30F3\u30D7\u30EC\u30FC\u30C8",
        department: "\u6CD5\u52D9\u90E8",
        version: "v2.1"
      }
    }
  },
  checksumMismatch: {
    uploadId: s.video,
    finalValidation: {
      fileChecksum: p.invalid,
      actualFileSize: e.large,
      metadata: { title: "\u30C6\u30B9\u30C8\u30D5\u30A1\u30A4\u30EB" }
    }
  },
  sizeMismatch: {
    uploadId: s.video,
    finalValidation: {
      fileChecksum: p.valid,
      actualFileSize: e.small,
      // 申告サイズと異なる
      metadata: { title: "\u30B5\u30A4\u30BA\u4E0D\u4E00\u81F4\u30C6\u30B9\u30C8\u30D5\u30A1\u30A4\u30EB" }
    }
  },
  largeFile: {
    uploadId: s.large,
    finalValidation: {
      fileChecksum: p.video,
      actualFileSize: e.extraLarge,
      metadata: {
        title: "\u9AD8\u753B\u8CEA\u7814\u4FEE\u52D5\u753B",
        quality: "4K",
        duration: 7200,
        bitrate: 5e6
      }
    }
  }
}, E = {
  initiateUpload: {
    video: {
      uploadId: s.video,
      sessionToken: g.valid,
      uploadUrls: {
        single: "https://storage.googleapis.com/bucket/uploads/signed-url-here?signature=xyz"
      },
      expiresAt: Date.now() + 36e5,
      // 1時間後
      metadata: {
        maxChunkSize: 104857600,
        // 100MB
        supportedFormats: ["mp4", "avi", "mov", "mkv"],
        processingOptions: {
          qualityLevels: ["720p", "1080p", "4K"],
          transcoding: !0,
          thumbnailGeneration: !0,
          captionExtraction: !1
        }
      }
    },
    chunked: {
      uploadId: s.chunked,
      sessionToken: g.valid,
      uploadUrls: {
        chunks: Array.from(
          { length: 20 },
          (a, o) => `https://storage.googleapis.com/bucket/uploads/chunk-${o}?signature=${o}`
        )
      },
      expiresAt: Date.now() + 72e5,
      // 2時間後
      metadata: {
        maxChunkSize: 104857600,
        supportedFormats: ["mp4", "avi", "mov", "mkv"],
        processingOptions: {
          qualityLevels: ["4K"],
          transcoding: !0,
          parallelProcessing: !0
        }
      }
    }
  },
  completeUpload: {
    video: {
      fileId: c.video,
      fileUrl: "https://storage.googleapis.com/bucket/videos/file_video_001.mp4",
      processingStatus: "queued",
      metadata: {
        originalName: d.valid.video,
        size: e.large,
        type: i.video.mp4,
        uploadedAt: Date.now(),
        processedAt: void 0
      }
    },
    document: {
      fileId: c.document,
      fileUrl: "https://storage.googleapis.com/bucket/documents/file_doc_001.pdf",
      processingStatus: "completed",
      metadata: {
        originalName: d.valid.document,
        size: e.small * 5,
        type: i.document.pdf,
        uploadedAt: Date.now(),
        processedAt: Date.now()
      }
    }
  },
  uploadLimits: {
    standard: {
      maxFileSize: 1073741824,
      // 1GB
      maxTotalSize: 10737418240,
      // 10GB
      allowedTypes: ["mp4", "avi", "mov", "pdf", "docx", "pptx", "jpg", "png", "gif"],
      currentUsage: {
        totalSize: 2147483648,
        // 2GB使用済み
        fileCount: 25,
        usageByType: {
          video: 1610612736,
          // 1.5GB
          document: 536870912,
          // 512MB
          image: 33554432
          // 32MB
        }
      },
      rateLimits: {
        uploadsPerHour: 50,
        uploadsPerDay: 200,
        currentCounts: {
          hour: 3,
          day: 15
        }
      },
      quotaStatus: {
        storageUsagePercentage: 20,
        remainingStorage: 8589934592,
        // 8GB
        isNearLimit: !1,
        nextResetTime: Date.now() + 36e5
      },
      restrictions: {
        canUploadVideo: !0,
        canUploadDocument: !0,
        canUploadImage: !0,
        canUploadAudio: !0,
        maxConcurrentUploads: 3
      }
    },
    admin: {
      maxFileSize: 5368709120,
      // 5GB
      maxTotalSize: 107374182400,
      // 100GB
      allowedTypes: ["*"],
      // 全形式許可
      rateLimits: {
        uploadsPerHour: 1e3,
        uploadsPerDay: 5e3,
        currentCounts: {
          hour: 10,
          day: 45
        }
      },
      restrictions: {
        canUploadVideo: !0,
        canUploadDocument: !0,
        canUploadImage: !0,
        canUploadAudio: !0,
        maxConcurrentUploads: 10
      }
    },
    restricted: {
      maxFileSize: 0,
      maxTotalSize: 0,
      allowedTypes: [],
      rateLimits: {
        uploadsPerHour: 0,
        uploadsPerDay: 0,
        currentCounts: {
          hour: 0,
          day: 0
        }
      },
      restrictions: {
        canUploadVideo: !1,
        canUploadDocument: !1,
        canUploadImage: !1,
        canUploadAudio: !1,
        maxConcurrentUploads: 0
      }
    },
    nearLimit: {
      quotaStatus: {
        storageUsagePercentage: 92.5,
        remainingStorage: 805306368,
        // 768MB
        isNearLimit: !0,
        nextResetTime: Date.now() + 864e5
        // 24時間後
      }
    }
  }
}, I = {
  // 認証エラー
  AUTHENTICATION_REQUIRED: "\u8A8D\u8A3C\u304C\u5FC5\u8981\u3067\u3059",
  UNAUTHORIZED_SESSION: "Unauthorized: session belongs to different user",
  // ファイルサイズエラー
  FILE_SIZE_EXCEEDS_LIMIT: "File size exceeds maximum limit",
  FILE_SIZE_MISMATCH: "File size mismatch",
  NEGATIVE_FILE_SIZE: "File size cannot be negative",
  ZERO_FILE_SIZE: "File size cannot be zero",
  // ファイル形式エラー
  UNSUPPORTED_FILE_TYPE: "File type 'application/x-executable' is not supported",
  // ファイル名エラー
  INVALID_FILENAME: "Invalid filename: contains prohibited characters",
  EMPTY_FILENAME: "Filename cannot be empty",
  FILENAME_TOO_LONG: "Filename is too long",
  // チェックサムエラー
  CHECKSUM_MISMATCH: "Checksum mismatch: file integrity compromised",
  // セッションエラー
  SESSION_NOT_FOUND: "Upload session not found or expired",
  SESSION_EXPIRED: "Upload session has expired",
  UPLOAD_ALREADY_COMPLETED: "Upload already completed or in progress",
  // 制限エラー
  STORAGE_QUOTA_EXCEEDED: "Storage quota exceeded",
  RATE_LIMIT_EXCEEDED: "Rate limit exceeded. Max 50 uploads per hour",
  CONCURRENT_UPLOADS_EXCEEDED: "Maximum concurrent uploads (10) reached",
  // システムエラー
  SERVICE_UNAVAILABLE: "Temporary service unavailable. Please retry later",
  PROCESSING_FAILED: "File processing failed",
  METADATA_SIZE_EXCEEDED: "Metadata size exceeds limit of 1MB",
  // 権限エラー
  PERMISSION_DENIED: "\u6A29\u9650\u304C\u3042\u308A\u307E\u305B\u3093",
  INSUFFICIENT_PRIVILEGES: "Insufficient privileges for this operation",
  // リソースエラー
  FILE_NOT_FOUND: "File not found",
  RESOURCE_NOT_FOUND: "Resource not found",
  UPLOAD_CANCELLED: "Upload was cancelled"
}, _ = {
  signedUploadUrl: "https://storage.googleapis.com/test-bucket/uploads/signed-url-test",
  finalFileUrl: "https://storage.googleapis.com/test-bucket/files/final-file-url",
  chunkUrls: Array.from(
    { length: 20 },
    (a, o) => `https://storage.googleapis.com/test-bucket/chunks/chunk-${o}`
  )
}, t = {
  now: Date.now(),
  hourAgo: Date.now() - 36e5,
  dayAgo: Date.now() - 864e5,
  weekAgo: Date.now() - 7 * 864e5,
  monthAgo: Date.now() - 30 * 864e5,
  future: Date.now() + 36e5
}, T = {
  starting: {
    uploadId: s.video,
    status: "uploading",
    progress: 0,
    uploadedBytes: 0,
    totalBytes: e.large,
    speed: 0,
    estimatedTimeRemaining: null,
    error: null,
    startedAt: t.now,
    lastUpdatedAt: t.now
  },
  inProgress: {
    uploadId: s.video,
    status: "uploading",
    progress: 45.5,
    uploadedBytes: Math.floor(e.large * 0.455),
    totalBytes: e.large,
    speed: 1048576,
    // 1MB/s
    estimatedTimeRemaining: 3e5,
    // 5分
    error: null,
    startedAt: t.hourAgo,
    lastUpdatedAt: t.now
  },
  completed: {
    uploadId: s.video,
    status: "completed",
    progress: 100,
    uploadedBytes: e.large,
    totalBytes: e.large,
    speed: 0,
    estimatedTimeRemaining: 0,
    error: null,
    startedAt: t.hourAgo,
    lastUpdatedAt: t.now,
    completedAt: t.now
  },
  failed: {
    uploadId: s.video,
    status: "failed",
    progress: 67.3,
    uploadedBytes: Math.floor(e.large * 0.673),
    totalBytes: e.large,
    speed: 0,
    estimatedTimeRemaining: null,
    error: "Network connection lost",
    startedAt: t.hourAgo,
    lastUpdatedAt: t.now,
    failedAt: t.now
  }
}, h = [
  {
    uploadId: s.video,
    fileName: d.valid.video,
    fileSize: e.large,
    progress: 45.5,
    status: "uploading",
    startedAt: t.hourAgo
  },
  {
    uploadId: s.document,
    fileName: d.valid.document,
    fileSize: e.small * 5,
    progress: 78.2,
    status: "uploading",
    startedAt: t.now - 18e5
    // 30分前
  }
], A = [
  {
    uploadId: "upload_completed_001",
    fileName: "past_video.mp4",
    fileSize: e.medium,
    status: "completed",
    startedAt: t.dayAgo,
    completedAt: t.dayAgo + 18e5,
    fileUrl: "https://storage.googleapis.com/bucket/files/past_video.mp4"
  },
  {
    uploadId: "upload_failed_001",
    fileName: "failed_document.pdf",
    fileSize: e.small,
    status: "failed",
    startedAt: t.weekAgo,
    failedAt: t.weekAgo + 3e5,
    error: "Network timeout"
  }
], U = {
  totalUploads: 150,
  successfulUploads: 142,
  failedUploads: 8,
  totalSize: 25 * 1024 * 1024 * 1024,
  // 25GB
  averageFileSize: 167772160,
  // 160MB
  uploadsByType: {
    video: 89,
    document: 42,
    image: 15,
    audio: 4
  },
  sizeByType: {
    video: 22 * 1024 * 1024 * 1024,
    // 22GB
    document: 2 * 1024 * 1024 * 1024,
    // 2GB
    image: 800 * 1024 * 1024,
    // 800MB
    audio: 200 * 1024 * 1024
    // 200MB
  },
  successRate: 94.7,
  averageUploadTime: 42e4,
  // 7分
  peakUploadHour: 14,
  // 14時
  lastUpload: t.now - 36e5
  // 1時間前
}, x = {
  /**
   * 現在時刻からの相対時間を計算
   */
  getRelativeTime: /* @__PURE__ */ l((a) => Date.now() + a, "getRelativeTime"),
  /**
   * ランダムなテスト用ID生成
   */
  generateTestId: /* @__PURE__ */ l((a) => `${a}_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`, "generateTestId"),
  /**
   * ファイルサイズを人間が読める形式に変換
   */
  formatFileSize: /* @__PURE__ */ l((a) => {
    let o = ["B", "KB", "MB", "GB"], r = a, n = 0;
    for (; r >= 1024 && n < o.length - 1; )
      r /= 1024, n++;
    return `${r.toFixed(1)} ${o[n]}`;
  }, "formatFileSize"),
  /**
   * プログレス情報を段階的に生成
   */
  generateProgressSteps: /* @__PURE__ */ l((a, o) => Array.from({ length: o }, (r, n) => {
    let u = (n + 1) / o * 100, m = Math.floor(a * u / 100);
    return {
      progress: u,
      uploadedBytes: m,
      totalBytes: a,
      speed: 1048576,
      // 1MB/s
      estimatedTimeRemaining: Math.floor((a - m) / 1048576 * 1e3)
    };
  }), "generateProgressSteps"),
  /**
   * エラー条件をシミュレート
   */
  simulateNetworkError: /* @__PURE__ */ l(() => ({
    error: "Network connection lost",
    retryable: !0,
    retryAfter: 5e3
  }), "simulateNetworkError"),
  simulateServiceError: /* @__PURE__ */ l(() => ({
    error: "Service temporarily unavailable",
    retryable: !0,
    retryAfter: 3e4
  }), "simulateServiceError"),
  simulateValidationError: /* @__PURE__ */ l((a, o) => ({
    error: `Validation failed: ${a} - ${o}`,
    retryable: !1,
    field: a
  }), "simulateValidationError"),
  /**
   * モックレスポンスの遅延をシミュレート
   */
  simulateDelay: /* @__PURE__ */ l((a) => new Promise((o) => setTimeout(o, a)), "simulateDelay"),
  /**
   * チャンクアップロード用のURL配列生成
   */
  generateChunkUrls: /* @__PURE__ */ l((a, o = _.signedUploadUrl) => Array.from(
    { length: a },
    (r, n) => `${o}/chunk-${n}?signature=test_signature_${n}`
  ), "generateChunkUrls")
};
export {
  S as COMPLETION_REQUESTS,
  i as CONTENT_TYPES,
  I as ERROR_MESSAGES,
  E as EXPECTED_RESPONSES,
  d as FILE_NAMES,
  e as FILE_SIZES,
  h as MOCK_ACTIVE_UPLOADS,
  _ as MOCK_GCS_URLS,
  T as MOCK_PROGRESS,
  U as MOCK_STATISTICS,
  A as MOCK_UPLOAD_HISTORY,
  p as TEST_CHECKSUMS,
  c as TEST_FILE_IDS,
  g as TEST_SESSION_TOKENS,
  t as TEST_TIMESTAMPS,
  s as TEST_UPLOAD_IDS,
  v as TEST_USER_IDS,
  x as TestHelpers,
  f as UPLOAD_REQUESTS
};
//# sourceMappingURL=uploads_mocks.js.map
