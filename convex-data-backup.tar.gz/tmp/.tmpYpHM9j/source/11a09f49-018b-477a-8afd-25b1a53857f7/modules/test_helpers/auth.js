import {
  a as d,
  b as u,
  e as I
} from "../_deps/IVQGLTSC.js";
import "../_deps/6XQQNYIR.js";
import "../_deps/3TDUHHJO.js";
import {
  a as o
} from "../_deps/RUVYHBJQ.js";

// convex/test_helpers/auth.ts
I();
function y(r = {}) {
  return {
    tokenIdentifier: `test-token-${Date.now()}-${Math.random()}`,
    subject: `test-subject-${Date.now()}`,
    name: "Test User",
    email: "test@example.com",
    emailVerified: !0,
    issuer: "test-issuer",
    ...r
  };
}
o(y, "createTestUserIdentity");
async function T(r, n = {}) {
  let t = y(n), e = await r.withIdentity(t).mutation(d.users.store, {}), s = await w(r, e, t);
  return {
    userId: e,
    identity: t,
    sessionId: s,
    data: {
      name: t.name,
      email: t.email,
      tokenIdentifier: t.tokenIdentifier,
      emailVerified: t.emailVerified,
      role: "user",
      isActive: !0,
      joinDate: Date.now()
    }
  };
}
o(T, "createTestUser");
async function w(r, n, t) {
  let e = `test-session-${Date.now()}-${Math.random()}`, s = Date.now();
  try {
    await r.mutation(u.testing.createTestSession, {
      user_id: n,
      clerk_session_id: e,
      device_info: "test-device",
      ip_address: "127.0.0.1",
      user_agent: "test-agent",
      expires_at: s + 24 * 60 * 60 * 1e3,
      // 24 hours
      last_activity_at: s,
      is_active: !0
    });
  } catch (i) {
    console.warn("Could not create test session:", i);
  }
  return e;
}
o(w, "createTestSession");
async function f(r, n = 3) {
  let t = [];
  for (let e = 0; e < n; e++) {
    let s = await T(r, {
      name: `Test User ${e + 1}`,
      email: `test${e + 1}@example.com`
    });
    t.push(s);
  }
  return t;
}
o(f, "createTestUsers");
var g = {
  /**
   * Test that a function requires authentication
   */
  async expectAuthRequired(r, n, t = "\u8A8D\u8A3C\u304C\u5FC5\u8981\u3067\u3059") {
    try {
      throw await n(), new Error(`Expected operation to throw error: ${t}`);
    } catch (e) {
      if (!e || typeof e != "object" || !("message" in e))
        throw new Error(`Expected error with message: ${t}, but got: ${e}`);
      if (!e.message.includes(t))
        throw new Error(`Expected error message to contain: ${t}, but got: ${e.message}`);
    }
  },
  /**
   * Test authenticated operation succeeds
   */
  async expectAuthSuccess(r, n, t) {
    let e = r.withIdentity(n), s = await t(e);
    if (s == null)
      throw new Error("Expected result to be defined, but got undefined or null");
    return s;
  },
  /**
   * Test ownership/permission checks
   */
  async expectOwnershipRequired(r, n, t, e, s, i = "\u6A29\u9650\u304C\u3042\u308A\u307E\u305B\u3093") {
    let m = r.withIdentity(n), c = await e(m), l = r.withIdentity(t);
    try {
      throw await s(l, c), new Error(`Expected operation to throw error: ${i}`);
    } catch (a) {
      if (!a || typeof a != "object" || !("message" in a))
        throw new Error(`Expected error with message: ${i}, but got: ${a}`);
      if (!a.message.includes(i))
        throw new Error(`Expected error message to contain: ${i}, but got: ${a.message}`);
    }
    return c;
  }
}, h = {
  admin: {
    name: "Admin User",
    email: "admin@example.com",
    role: "admin"
  },
  regularUser: {
    name: "Regular User",
    email: "user@example.com",
    role: "user"
  },
  manager: {
    name: "Manager User",
    email: "manager@example.com",
    role: "manager"
  }
};
async function x(r, n) {
  for (let t of n)
    ;
}
o(x, "cleanupTestData");
async function v(r) {
  try {
    console.log("Test data cleanup completed");
  } catch (n) {
    console.warn("Test data cleanup warning:", n);
  }
}
o(v, "clearAllTestData");
export {
  g as authTestPatterns,
  x as cleanupTestData,
  v as clearAllTestData,
  w as createTestSession,
  T as createTestUser,
  y as createTestUserIdentity,
  f as createTestUsers,
  h as testUserTemplates
};
//# sourceMappingURL=auth.js.map
