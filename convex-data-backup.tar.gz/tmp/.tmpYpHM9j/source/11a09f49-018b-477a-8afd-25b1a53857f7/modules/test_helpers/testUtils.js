import {
  a as e
} from "../_deps/RUVYHBJQ.js";

// convex/test_helpers/testUtils.ts
function s(t) {
  let r = "abcdefghijklmnopqrstuvwxyz234567", n = "";
  for (let a = 0; a < 28; a++)
    n += r[Math.floor(Math.random() * r.length)];
  return t.substring(0, 2) + n.substring(2);
}
e(s, "generateValidTestId");
function o(t) {
  return `${t.substring(0, 2)}724nkmga6nk0ng9rfr66ch${t.substring(0, 4)}`.substring(0, 28).padEnd(28, "x");
}
e(o, "generateFakeConvexId");
function d(t, r) {
  let n = {};
  for (let i of r)
    t[i] !== void 0 && (n[i] = t[i]);
  return n;
}
e(d, "sanitizeForValidator");
var f = {
  // デフォルトのユーザーID生成関数
  generateDefaultUserId: /* @__PURE__ */ e(() => s("users"), "generateDefaultUserId"),
  // デフォルトの動画ID生成関数
  generateDefaultVideoId: /* @__PURE__ */ e(() => s("videos"), "generateDefaultVideoId"),
  // デフォルトの研修ID生成関数
  generateDefaultTrainingId: /* @__PURE__ */ e(() => s("trainings"), "generateDefaultTrainingId"),
  // デフォルトのロールプレイID生成関数
  generateDefaultRoleplayId: /* @__PURE__ */ e(() => s("roleplays"), "generateDefaultRoleplayId")
};
export {
  f as TEST_CONFIG,
  o as generateFakeConvexId,
  s as generateValidTestId,
  d as sanitizeForValidator
};
//# sourceMappingURL=testUtils.js.map
