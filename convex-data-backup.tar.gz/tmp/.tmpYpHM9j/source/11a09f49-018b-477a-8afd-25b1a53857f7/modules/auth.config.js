// convex/auth.config.ts
var e = {
  providers: [
    {
      domain: process.env.CLERK_JWT_ISSUER_DOMAIN,
      applicationID: "convex"
    }
  ]
};
export {
  e as default
};
//# sourceMappingURL=auth.config.js.map
