import {
  d as r
} from "./_deps/75JH2J25.js";
import "./_deps/6XQQNYIR.js";
import {
  j as a,
  n as e
} from "./_deps/3TDUHHJO.js";
import {
  a as i
} from "./_deps/RUVYHBJQ.js";

// convex/genAIResults.ts
e();
var d = r({
  args: {
    transcriptionId: a.id("transcriptions"),
    result: a.any(),
    status: a.string()
  },
  handler: /* @__PURE__ */ i(async (s, t) => {
    let n = { evaluation_status: t.status };
    t.result !== null && (n.evaluation = t.result), await s.db.patch(t.transcriptionId, n);
  }, "handler")
}), l = r({
  args: {
    transcriptionId: a.id("transcriptions"),
    result: a.any(),
    status: a.string()
  },
  handler: /* @__PURE__ */ i(async (s, t) => {
    let n = { meeting_minutes_status: t.status };
    t.result !== null && (n.meeting_minutes = t.result), await s.db.patch(t.transcriptionId, n);
  }, "handler")
}), c = r({
  args: {
    transcriptionId: a.id("transcriptions"),
    result: a.any(),
    status: a.string()
  },
  handler: /* @__PURE__ */ i(async (s, t) => {
    let n = { case_summary_status: t.status };
    t.result !== null && (n.case_summary = t.result), await s.db.patch(t.transcriptionId, n);
  }, "handler")
}), m = r({
  args: {
    transcriptionId: a.id("transcriptions"),
    result: a.any(),
    status: a.string()
  },
  handler: /* @__PURE__ */ i(async (s, t) => {
    let n = { meeting_summary_status: t.status };
    t.result !== null && (n.meeting_summary = t.result), await s.db.patch(t.transcriptionId, n);
  }, "handler")
});
export {
  c as updateCaseSummary,
  d as updateEvaluationResult,
  l as updateMeetingMinutes,
  m as updateMeetingSummary
};
//# sourceMappingURL=genAIResults.js.map
