import {
  a as b,
  b as d,
  e as E
} from "./_deps/IVQGLTSC.js";
import {
  a as S,
  b as V
} from "./_deps/6HNJFR7B.js";
import {
  a as M,
  b as _,
  c as w,
  d as U,
  e as T,
  f as I
} from "./_deps/75JH2J25.js";
import "./_deps/6XQQNYIR.js";
import {
  j as e,
  l as v,
  n as A
} from "./_deps/3TDUHHJO.js";
import {
  a as u
} from "./_deps/RUVYHBJQ.js";

// convex/videoUpload.ts
A();
A();
E();
var F = T({
  args: {
    fileName: e.string(),
    fileType: e.string(),
    fileSize: e.number(),
    title: e.optional(e.string()),
    description: e.optional(e.string()),
    labels: e.optional(e.array(e.string())),
    type: e.optional(e.string()),
    intervieweeName: e.optional(e.string())
  },
  returns: e.object({
    success: e.boolean(),
    message: e.string(),
    uploadUrl: e.optional(e.string()),
    videoId: e.optional(e.id("videos")),
    fileUploadId: e.optional(e.id("fileUploads"))
  }),
  handler: /* @__PURE__ */ u(async (t, o) => {
    if (!await t.auth.getUserIdentity())
      return {
        success: !1,
        message: "\u8A8D\u8A3C\u304C\u5FC5\u8981\u3067\u3059"
      };
    let i = await t.runQuery(d.unifiedAuth.getCurrentUser, {});
    if (!i)
      return {
        success: !1,
        message: "\u30E6\u30FC\u30B6\u30FC\u60C5\u5831\u306E\u53D6\u5F97\u306B\u5931\u6557\u3057\u307E\u3057\u305F"
      };
    let { fileName: s, fileType: a, fileSize: n, title: l, description: p, labels: g, type: f } = o;
    console.log("[generateUploadUrl] \u5F15\u6570\u8A73\u7D30:", {
      fileName: s,
      fileType: a,
      fileSize: n,
      title: l,
      titleType: typeof l,
      titleLength: l ? l.length : 0,
      description: p,
      labels: g,
      type: f,
      intervieweeName: o.intervieweeName
    });
    try {
      if (n > 2147483648)
        return {
          success: !1,
          message: `\u30D5\u30A1\u30A4\u30EB\u30B5\u30A4\u30BA\u304C\u5236\u9650\u3092\u8D85\u3048\u3066\u3044\u307E\u3059\uFF08\u6700\u5927: ${2147483648 / (1024 * 1024 * 1024)}GB\uFF09`
        };
      if (![
        "video/mp4",
        "video/webm",
        "video/quicktime",
        "video/avi",
        "audio/mp4",
        "audio/x-m4a",
        "audio/m4a",
        "audio/wav",
        "audio/mpeg",
        "audio/mp3"
      ].includes(a))
        return {
          success: !1,
          message: `\u30B5\u30DD\u30FC\u30C8\u3055\u308C\u3066\u3044\u306A\u3044\u30D5\u30A1\u30A4\u30EB\u5F62\u5F0F\u3067\u3059: ${a}`
        };
      console.log("[generateUploadUrl] GCS\u7F72\u540D\u4ED8\u304DURL\u751F\u6210\u958B\u59CB:", {
        filename: s,
        contentType: a,
        uploadType: "video",
        fileSize: n
      });
      let m = await t.runAction(b.gcsActions.generateGCPUploadUrl, {
        filename: s,
        contentType: a,
        uploadType: "video",
        fileSize: n
      });
      if (console.log("[generateUploadUrl] GCS\u7F72\u540D\u4ED8\u304DURL\u751F\u6210\u7D50\u679C:", m), !m.uploadUrl || !m.gcpFilePath)
        throw console.error("[generateUploadUrl] GCS\u7F72\u540D\u4ED8\u304DURL\u751F\u6210\u5931\u6557:", m), new Error("GCS\u7F72\u540D\u4ED8\u304DURL\u306E\u751F\u6210\u306B\u5931\u6557\u3057\u307E\u3057\u305F");
      let z = s.split(".").slice(0, -1).join(".") || s, h = l && l.trim() && l.trim() !== "sample" ? l.trim() : z;
      console.log("[generateUploadUrl] \u30BF\u30A4\u30C8\u30EB\u51E6\u7406:", {
        originalTitle: l,
        cleanFileName: z,
        finalTitle: h,
        titleProcessing: `${l} -> ${h}`
      });
      let y = await t.runMutation(d.videoUpload.createVideoAndFileRecord, {
        userId: i._id,
        fileName: s,
        fileType: a,
        fileSize: n,
        title: h,
        description: p || "",
        labels: g || [],
        type: f || "uploaded",
        intervieweeName: o.intervieweeName,
        gcpFilePath: m.gcpFilePath
      });
      return y.success ? {
        success: !0,
        message: "\u30A2\u30C3\u30D7\u30ED\u30FC\u30C9URL\u751F\u6210\u5B8C\u4E86",
        uploadUrl: m.uploadUrl,
        videoId: y.videoId,
        fileUploadId: y.fileUploadId
      } : {
        success: !1,
        message: y.message
      };
    } catch (c) {
      return console.error("[generateUploadUrl] \u30A8\u30E9\u30FC:", c), console.error("[generateUploadUrl] \u30A8\u30E9\u30FC\u306E\u8A73\u7D30:", {
        name: c instanceof Error ? c.name : "Unknown",
        message: c instanceof Error ? c.message : String(c),
        stack: c instanceof Error ? c.stack : "No stack trace",
        cause: c instanceof Error ? c.cause : void 0
      }), {
        success: !1,
        message: c instanceof Error ? c.message : "\u4E0D\u660E\u306A\u30A8\u30E9\u30FC\u304C\u767A\u751F\u3057\u307E\u3057\u305F"
      };
    }
  }, "handler")
}), D = U({
  args: {
    userId: e.string(),
    fileName: e.string(),
    fileType: e.string(),
    fileSize: e.number(),
    title: e.string(),
    description: e.string(),
    labels: e.array(e.string()),
    type: e.string(),
    intervieweeName: e.optional(e.string()),
    gcpFilePath: e.string()
  },
  returns: e.object({
    success: e.boolean(),
    message: e.string(),
    videoId: e.optional(e.id("videos")),
    fileUploadId: e.optional(e.id("fileUploads"))
  }),
  handler: /* @__PURE__ */ u(async (t, o) => {
    try {
      let r = {
        user_id: o.userId,
        // メインスキーマは user_id を使用
        title: o.title,
        description: o.description,
        type: o.type,
        url: ""
        // アップロード完了時に更新
      };
      o.labels && o.labels.length > 0 && (r.labels = o.labels), o.intervieweeName && (r.intervieweeName = o.intervieweeName);
      let i = await t.db.insert("videos", r), s = await t.db.insert("fileUploads", {
        user_id: o.userId,
        original_filename: o.fileName,
        content_type: o.fileType,
        file_size: o.fileSize,
        gcp_file_path: o.gcpFilePath,
        storage_id: "",
        // GCS使用時は空文字
        upload_type: "video",
        status: "pending",
        related_resource_type: "video",
        related_resource_id: i,
        uploaded_at: Date.now()
      });
      return {
        success: !0,
        message: "\u30EC\u30B3\u30FC\u30C9\u4F5C\u6210\u5B8C\u4E86",
        videoId: i,
        fileUploadId: s
      };
    } catch (r) {
      return console.error("[createVideoAndFileRecord] \u30A8\u30E9\u30FC:", r), {
        success: !1,
        message: r instanceof Error ? r.message : "\u30EC\u30B3\u30FC\u30C9\u4F5C\u6210\u306B\u5931\u6557\u3057\u307E\u3057\u305F"
      };
    }
  }, "handler")
}), B = w({
  args: {
    videoId: e.id("videos"),
    fileUploadId: e.id("fileUploads")
  },
  returns: e.object({
    success: e.boolean(),
    message: e.string(),
    videoUrl: e.optional(e.string())
  }),
  handler: /* @__PURE__ */ u(async (t, o) => {
    await S(t);
    let { videoId: r, fileUploadId: i } = o, s = await t.db.get(r);
    if (!s)
      throw new v("Video not found");
    let { user: a } = await V(t);
    if (s.user_id !== a._id)
      throw new v("Access denied. You can only complete uploads for your own videos.");
    try {
      let n = await t.db.get(i);
      if (!n)
        return {
          success: !1,
          message: "\u30A2\u30C3\u30D7\u30ED\u30FC\u30C9\u3055\u308C\u305F\u30D5\u30A1\u30A4\u30EB\u304C\u898B\u3064\u304B\u308A\u307E\u305B\u3093"
        };
      let l = `https://storage.googleapis.com/ai-sales-hub-dev-new_dify-ai-sales-hub-dev-new/${n.gcp_file_path}`;
      return await t.db.patch(r, {
        url: l
      }), await t.db.patch(i, {
        status: "completed",
        public_url: l,
        completed_at: Date.now()
      }), await t.scheduler.runAfter(0, d.videoUpload.processUploadedVideo, {
        videoId: r,
        fileUploadId: i,
        videoUrl: l
      }), {
        success: !0,
        message: "\u30A2\u30C3\u30D7\u30ED\u30FC\u30C9\u5B8C\u4E86",
        videoUrl: l
      };
    } catch (n) {
      console.error("[completeUpload] \u30A8\u30E9\u30FC:", n);
      try {
        await t.db.patch(i, {
          status: "failed",
          processing_error: n instanceof Error ? n.message : "Unknown error"
        });
      } catch (l) {
        console.error("[completeUpload] \u30D5\u30A1\u30A4\u30EB\u30A2\u30C3\u30D7\u30ED\u30FC\u30C9\u8A18\u9332\u66F4\u65B0\u30A8\u30E9\u30FC:", l);
      }
      return {
        success: !1,
        message: n instanceof Error ? n.message : "\u4E0D\u660E\u306A\u30A8\u30E9\u30FC\u304C\u767A\u751F\u3057\u307E\u3057\u305F"
      };
    }
  }, "handler")
}), C = w({
  args: {
    files: e.array(
      e.object({
        fileName: e.string(),
        fileType: e.string(),
        fileSize: e.number()
      })
    )
  },
  returns: e.object({
    success: e.boolean(),
    message: e.string(),
    uploads: e.optional(
      e.array(
        e.object({
          fileName: e.string(),
          uploadUrl: e.string(),
          videoId: e.id("videos"),
          fileUploadId: e.id("fileUploads")
        })
      )
    )
  }),
  handler: /* @__PURE__ */ u(async (t, o) => {
    await S(t);
    let { files: r } = o;
    try {
      let i = [];
      for (let s of r) {
        let a = await t.runMutation(b.videoUpload.generateUploadUrl, {
          fileName: s.fileName,
          fileType: s.fileType,
          fileSize: s.fileSize
        });
        a.success && a.uploadUrl && a.videoId && a.fileUploadId ? i.push({
          fileName: s.fileName,
          uploadUrl: a.uploadUrl,
          videoId: a.videoId,
          fileUploadId: a.fileUploadId
        }) : console.error(
          `[generateBatchUploadUrls] \u30D5\u30A1\u30A4\u30EB ${s.fileName} \u306E\u51E6\u7406\u306B\u5931\u6557:`,
          a.message
        );
      }
      return {
        success: !0,
        message: `${i.length}/${r.length} \u30D5\u30A1\u30A4\u30EB\u306E\u7F72\u540D\u4ED8\u304DURL\u751F\u6210\u5B8C\u4E86`,
        uploads: i
      };
    } catch (i) {
      return console.error("[generateBatchUploadUrls] \u30A8\u30E9\u30FC:", i), {
        success: !1,
        message: i instanceof Error ? i.message : "\u4E0D\u660E\u306A\u30A8\u30E9\u30FC\u304C\u767A\u751F\u3057\u307E\u3057\u305F"
      };
    }
  }, "handler")
}), G = M({
  args: { fileUploadId: e.id("fileUploads") },
  returns: e.union(
    e.object({
      id: e.id("fileUploads"),
      status: e.union(
        e.literal("pending"),
        e.literal("uploading"),
        e.literal("completed"),
        e.literal("failed"),
        e.literal("preparing"),
        e.literal("processing")
      ),
      progress_percentage: e.optional(e.number()),
      file_size: e.number(),
      uploaded_at: e.optional(e.number()),
      completed_at: e.optional(e.number()),
      error_message: e.optional(e.string())
    }),
    e.null()
  ),
  handler: /* @__PURE__ */ u(async (t, o) => {
    let { user: r } = await V(t), i = await t.db.get(o.fileUploadId);
    if (!i)
      return null;
    if (i.related_resource_type === "video" && i.related_resource_id) {
      let s = await t.db.get(i.related_resource_id);
      if (s && s.user_id !== r._id)
        throw new v("Access denied. You can only access your own upload progress.");
    }
    return {
      id: i._id,
      status: i.status,
      progress_percentage: 100,
      // Convex File Storageは進行状況の詳細追跡なし
      file_size: i.file_size,
      uploaded_at: i.uploaded_at,
      completed_at: i.completed_at,
      error_message: i.processing_error
    };
  }, "handler")
}), L = I({
  args: {
    videoId: e.id("videos"),
    fileUploadId: e.id("fileUploads"),
    videoUrl: e.string()
  },
  returns: e.null(),
  handler: /* @__PURE__ */ u(async (t, o) => {
    let { videoId: r, fileUploadId: i, videoUrl: s } = o;
    try {
      console.log(`[processUploadedVideo] \u5F8C\u51E6\u7406\u958B\u59CB (Video ID: ${r})`);
      let a = await t.runQuery(d.videoUpload.getFileUploadInfo, {
        fileUploadId: i
      });
      if (!a)
        throw new Error("\u30D5\u30A1\u30A4\u30EB\u30A2\u30C3\u30D7\u30ED\u30FC\u30C9\u60C5\u5831\u304C\u898B\u3064\u304B\u308A\u307E\u305B\u3093");
      let n = {
        size: a.file_size,
        contentType: a.content_type
      };
      n && await t.runMutation(d.videoUpload.updateVideoMetadata, {
        videoId: r,
        fileSize: n.size,
        contentType: n.contentType || "video/mp4"
      }), await t.runMutation(d.videoUpload.updateVideoStatus, {
        videoId: r,
        status: "processing"
      });
      let l = n?.contentType?.startsWith("audio/") || !1;
      l ? console.log(`[processUploadedVideo] \u97F3\u58F0\u30D5\u30A1\u30A4\u30EB\u3068\u3057\u3066\u51E6\u7406\u4E2D (Content-Type: ${n?.contentType})`) : (console.log(`[processUploadedVideo] \u52D5\u753B\u30D5\u30A1\u30A4\u30EB\u3068\u3057\u3066\u51E6\u7406\u4E2D (Content-Type: ${n?.contentType})`), await t.scheduler.runAfter(1e3, d.videoUpload.generateThumbnail, {
        videoId: r,
        videoUrl: s
      })), console.log("[processUploadedVideo] \u6587\u5B57\u8D77\u3053\u3057\u51E6\u7406\u3092\u958B\u59CB");
      let p = await t.runAction(
        d.transcriptions.startTranscriptionInternal,
        {
          resourceType: "video",
          resourceId: r,
          fileUrl: s,
          fileType: n?.contentType || "audio/mp4"
        }
      );
      p.success ? (console.log(
        `[processUploadedVideo] \u6587\u5B57\u8D77\u3053\u3057\u51E6\u7406\u958B\u59CB\u5B8C\u4E86 (transcriptionId: ${p.transcriptionId})`
      ), l && p.transcriptionId && p.message.includes("\u5B8C\u4E86") && (console.log("[processUploadedVideo] \u97F3\u58F0\u30D5\u30A1\u30A4\u30EB\u306E\u305F\u3081\u8A71\u8005\u4ED8\u304D\u6587\u5B57\u8D77\u3053\u3057\u51E6\u7406\u3092\u958B\u59CB"), await t.scheduler.runAfter(3e3, d.videoUpload.processWithSpeakerTranscription, {
        transcriptionId: p.transcriptionId
      }), console.log("[processUploadedVideo] \u8A71\u8005\u4ED8\u304D\u6587\u5B57\u8D77\u3053\u3057\u51E6\u7406\u3092\u30B9\u30B1\u30B8\u30E5\u30FC\u30EB"))) : console.error(`[processUploadedVideo] \u6587\u5B57\u8D77\u3053\u3057\u51E6\u7406\u5931\u6557: ${p.message}`), console.log(`[processUploadedVideo] \u5F8C\u51E6\u7406\u5B8C\u4E86 (Video ID: ${r})`);
    } catch (a) {
      console.error(`[processUploadedVideo] \u30A8\u30E9\u30FC (Video ID: ${r}):`, a), await t.runMutation(d.videoUpload.updateVideoError, {
        videoId: r,
        errorMessage: a instanceof Error ? a.message : "\u4E0D\u660E\u306A\u30A8\u30E9\u30FC"
      });
    }
    return null;
  }, "handler")
}), Q = _({
  args: { fileUploadId: e.id("fileUploads") },
  returns: e.union(
    e.object({
      file_size: e.number(),
      content_type: e.string(),
      original_filename: e.string()
    }),
    e.null()
  ),
  handler: /* @__PURE__ */ u(async (t, o) => {
    let r = await t.db.get(o.fileUploadId);
    return r ? {
      file_size: r.file_size,
      content_type: r.content_type,
      original_filename: r.original_filename
    } : null;
  }, "handler")
}), W = I({
  args: {
    videoId: e.id("videos"),
    videoUrl: e.string()
  },
  returns: e.null(),
  handler: /* @__PURE__ */ u(async (t, o) => {
    let { videoId: r, videoUrl: i } = o;
    try {
      console.log(`[generateThumbnail] \u30B5\u30E0\u30CD\u30A4\u30EB\u751F\u6210\u958B\u59CB (Video ID: ${r})`);
      let s = `${i}?thumbnail=true`;
      await t.runMutation(d.videoUpload.updateVideoThumbnail, {
        videoId: r,
        thumbnailUrl: s
      }), console.log(`[generateThumbnail] \u30B5\u30E0\u30CD\u30A4\u30EB\u751F\u6210\u5B8C\u4E86 (Video ID: ${r})`);
    } catch (s) {
      console.error(`[generateThumbnail] \u30A8\u30E9\u30FC (Video ID: ${r}):`, s);
    }
    return null;
  }, "handler")
}), q = I({
  args: {
    transcriptionId: e.id("transcriptions")
  },
  returns: e.null(),
  handler: /* @__PURE__ */ u(async (t, o) => {
    let { transcriptionId: r } = o;
    try {
      let i = await t.runQuery(
        d.transcriptions.getTranscriptionResult,
        { transcriptionId: r }
      );
      if (!i?.success || !i.data?.text || i.data.text.length < 10)
        throw new Error("\u6587\u5B57\u8D77\u3053\u3057\u30C6\u30AD\u30B9\u30C8\u304C\u4E0D\u5B8C\u5168\u3067\u3059");
      let s = i.data;
      await t.runMutation(d.transcriptions.updateSpeakerAnalysisStatus, {
        transcriptionId: r,
        status: "processing"
      });
      let a = s.text;
      try {
        let { addSpeakersToTranscript: l } = await import("./_deps/BLZNFBTP.js");
        a = await l(s.text);
      } catch (l) {
        console.warn("\u8A71\u8005\u89E3\u6790\u5931\u6557\u3001\u5143\u306E\u30C6\u30AD\u30B9\u30C8\u3092\u4F7F\u7528:", l);
      }
      await Promise.all([
        t.runMutation(d.transcriptions.updateTranscriptWithSpeaker, {
          transcriptionId: r,
          transcriptWithSpeaker: a
        }),
        t.runMutation(d.transcriptions.updateSpeakerAnalysisStatus, {
          transcriptionId: r,
          status: "completed"
        }),
        t.runMutation(d.genAIResults.updateEvaluationResult, {
          transcriptionId: r,
          result: null,
          status: "processing"
        })
      ]);
      let n = await t.runAction(d.googleGenAIActions.processAudioFileAnalysis, {
        transcriptionId: r,
        transcriptionData: {
          text: s.text,
          status: s.status,
          resource_type: s.resource_type,
          resource_id: s.resource_id,
          transcript_with_speaker: a,
          _creationTime: s._creationTime
        }
      });
      if (n?.success && n.results) {
        if (n.results.evaluation?.success) {
          let p = await t.runQuery(d.videoUpload.getVideoById, {
            videoId: s.resource_id
          }), g = await t.runMutation(d.evaluations.startEvaluationInternal, {
            transcriptionId: r,
            videoId: s.resource_id,
            videoType: "\u521D\u56DE\u9762\u8AC7",
            transcript: a,
            userId: p?.user_id
          }), f = await t.runQuery(d.evaluations.getEvaluationByExternalId, {
            externalId: g.evaluationId
          });
          f && await t.runMutation(d.evaluations.updateEvaluationResultWithAI, {
            evaluationId: f._id,
            result: n.results.evaluation.result,
            videoType: "\u521D\u56DE\u9762\u8AC7"
          });
        }
        let l = [];
        for (let [p, g] of Object.entries(n.results))
          if (g && typeof g == "object" && "success" in g) {
            let f = {
              transcriptionId: r,
              result: g.success ? g.result : { error: g.error },
              status: g.success ? "completed" : "failed"
            };
            switch (p) {
              case "evaluation":
                l.push(t.runMutation(d.genAIResults.updateEvaluationResult, f));
                break;
              case "meetingMinutes":
                l.push(t.runMutation(d.genAIResults.updateMeetingMinutes, f));
                break;
              case "caseSummary":
                l.push(t.runMutation(d.genAIResults.updateCaseSummary, f));
                break;
              case "meetingSummary":
                l.push(t.runMutation(d.genAIResults.updateMeetingSummary, f));
                break;
            }
          }
        await Promise.all(l);
      }
    } catch (i) {
      console.error(`\u30A8\u30E9\u30FC (transcriptionId: ${r}):`, i), await Promise.all([
        t.runMutation(d.transcriptions.updateSpeakerAnalysisStatus, {
          transcriptionId: r,
          status: "failed"
        }),
        t.runMutation(d.genAIResults.updateEvaluationResult, {
          transcriptionId: r,
          result: { error: i instanceof Error ? i.message : "Unknown error" },
          status: "failed"
        })
      ]);
    }
    return null;
  }, "handler")
}), Y = _({
  args: {
    storageId: e.id("_storage")
  },
  returns: e.union(
    e.object({
      _id: e.id("_storage"),
      _creationTime: e.number(),
      contentType: e.optional(e.string()),
      sha256: e.string(),
      size: e.number()
    }),
    e.null()
  ),
  handler: /* @__PURE__ */ u(async (t, o) => await t.db.system.get(o.storageId), "handler")
}), O = _({
  args: {
    videoId: e.id("videos")
  },
  returns: e.union(
    e.object({
      _id: e.id("videos"),
      user_id: e.string(),
      title: e.string()
    }),
    e.null()
  ),
  handler: /* @__PURE__ */ u(async (t, o) => {
    let r = await t.db.get(o.videoId);
    return r ? {
      _id: r._id,
      user_id: r.user_id,
      title: r.title
    } : null;
  }, "handler")
}), H = U({
  args: {
    videoId: e.id("videos"),
    fileSize: e.optional(e.number()),
    contentType: e.optional(e.string()),
    duration: e.optional(e.number())
  },
  returns: e.null(),
  handler: /* @__PURE__ */ u(async (t, o) => {
    let { videoId: r, fileSize: i, contentType: s, duration: a } = o, n = {};
    return i !== void 0 && (n.file_size = i), s !== void 0 && (n.content_type = s), a !== void 0 && (n.duration_seconds = a), await t.db.patch(r, n), null;
  }, "handler")
}), J = U({
  args: {
    videoId: e.id("videos"),
    thumbnailUrl: e.string()
  },
  returns: e.null(),
  handler: /* @__PURE__ */ u(async (t, o) => (await t.db.patch(o.videoId, {
    thumbnail_url: o.thumbnailUrl
  }), null), "handler")
}), K = U({
  args: {
    videoId: e.id("videos"),
    status: e.union(
      e.literal("pending"),
      e.literal("processing"),
      e.literal("completed"),
      e.literal("failed")
    )
  },
  returns: e.null(),
  handler: /* @__PURE__ */ u(async (t, o) => (await t.db.patch(o.videoId, {
    processing_status: o.status
  }), null), "handler")
}), X = U({
  args: {
    videoId: e.id("videos"),
    errorMessage: e.string()
  },
  returns: e.null(),
  handler: /* @__PURE__ */ u(async (t, o) => (await t.db.patch(o.videoId, {
    error_message: o.errorMessage,
    processing_status: "failed"
  }), null), "handler")
}), Z = T({
  args: { fileUploadId: e.string() },
  returns: e.object({
    success: e.boolean(),
    data: e.optional(
      e.object({
        id: e.id("fileUploads"),
        status: e.union(
          e.literal("pending"),
          e.literal("uploading"),
          e.literal("completed"),
          e.literal("failed"),
          e.literal("preparing"),
          e.literal("processing")
        ),
        progress_percentage: e.optional(e.number()),
        file_size: e.number(),
        uploaded_at: e.optional(e.number()),
        completed_at: e.optional(e.number()),
        error_message: e.optional(e.string())
      })
    ),
    message: e.optional(e.string())
  }),
  handler: /* @__PURE__ */ u(async (t, o) => {
    try {
      return {
        success: !0,
        data: await t.runQuery(b.videoUpload.getUploadProgress, {
          fileUploadId: o.fileUploadId
        }) ?? void 0
      };
    } catch (r) {
      return {
        success: !1,
        message: r instanceof Error ? r.message : "\u4E0D\u660E\u306A\u30A8\u30E9\u30FC"
      };
    }
  }, "handler")
});
export {
  B as completeUpload,
  D as createVideoAndFileRecord,
  C as generateBatchUploadUrls,
  W as generateThumbnail,
  F as generateUploadUrl,
  Q as getFileUploadInfo,
  Y as getStorageMetadata,
  G as getUploadProgress,
  O as getVideoById,
  Z as httpGetUploadProgress,
  L as processUploadedVideo,
  q as processWithSpeakerTranscription,
  X as updateVideoError,
  H as updateVideoMetadata,
  K as updateVideoStatus,
  J as updateVideoThumbnail
};
//# sourceMappingURL=videoUpload.js.map
