import {
  a as c,
  c as y
} from "./_deps/75JH2J25.js";
import "./_deps/6XQQNYIR.js";
import {
  j as e,
  n as q
} from "./_deps/3TDUHHJO.js";
import {
  a as u
} from "./_deps/RUVYHBJQ.js";

// convex/roleplay.ts
q();
var P = c({
  args: {
    type: e.optional(e.string()),
    created_by: e.optional(e.boolean()),
    page: e.optional(e.number()),
    limit: e.optional(e.number())
  },
  returns: e.object({
    roleplays: e.array(
      e.object({
        _id: e.id("roleplays"),
        title: e.string(),
        description: e.optional(e.string()),
        type: e.string(),
        status: e.string(),
        max_participants: e.optional(e.number()),
        scheduled_at: e.optional(e.number()),
        completed_at: e.optional(e.number()),
        created_by: e.id("users"),
        _creationTime: e.number(),
        participants_count: e.number(),
        is_joined: e.boolean(),
        is_full: e.boolean(),
        is_creator: e.boolean()
      })
    ),
    total: e.number(),
    page: e.number(),
    limit: e.number(),
    totalPages: e.number()
  }),
  handler: /* @__PURE__ */ u(async (r, t) => {
    let a = await r.auth.getUserIdentity(), n = null;
    a && (n = await r.db.query("users").withIndex("by_token", (d) => d.eq("tokenIdentifier", a.tokenIdentifier)).unique());
    let s = t.page || 1, o = t.limit || 20, i = r.db.query("roleplays");
    t.created_by || (i = i.filter((d) => d.neq(d.field("status"), "deleted"))), t.type && t.type !== "all" && (i = i.filter((d) => d.eq(d.field("type"), t.type))), t.created_by && n && (i = i.filter((d) => d.eq(d.field("created_by"), n._id)));
    let l = await i.collect(), p = await Promise.all(
      l.map(async (d) => {
        let f = await r.db.query("roleplayParticipants").withIndex("by_roleplay_id", (w) => w.eq("roleplay_id", d._id)).collect(), h = f.length, m = d.max_participants ? h >= d.max_participants : !1, I = n ? f.some((w) => w.user_id === n._id) : !1, g = n ? d.created_by === n._id : !1;
        return {
          ...d,
          participants_count: h,
          is_joined: I,
          is_full: m,
          is_creator: g
        };
      })
    ), _ = p.length, b = (s - 1) * o;
    return {
      roleplays: p.slice(b, b + o),
      total: _,
      page: s,
      limit: o,
      totalPages: Math.ceil(_ / o)
    };
  }, "handler")
}), j = c({
  args: {
    roleplayId: e.id("roleplays")
  },
  returns: e.union(
    e.object({
      _id: e.id("roleplays"),
      title: e.string(),
      description: e.optional(e.string()),
      type: e.string(),
      status: e.string(),
      max_participants: e.optional(e.number()),
      scheduled_at: e.optional(e.number()),
      completed_at: e.optional(e.number()),
      created_by: e.id("users"),
      _creationTime: e.number(),
      participants: e.array(
        e.object({
          user_id: e.id("users"),
          user_name: e.string(),
          role: e.optional(e.string()),
          is_creator: e.boolean()
        })
      ),
      materials: e.array(e.any())
    }),
    e.null()
  ),
  handler: /* @__PURE__ */ u(async (r, t) => {
    let a = await r.auth.getUserIdentity();
    if (!a)
      throw new Error("\u8A8D\u8A3C\u304C\u5FC5\u8981\u3067\u3059");
    if (!await r.db.query("users").withIndex("by_token", (p) => p.eq("tokenIdentifier", a.tokenIdentifier)).unique())
      throw new Error("\u30E6\u30FC\u30B6\u30FC\u304C\u898B\u3064\u304B\u308A\u307E\u305B\u3093");
    let s = await r.db.get(t.roleplayId);
    if (!s)
      return null;
    let o = await r.db.query("roleplayParticipants").withIndex("by_roleplay_id", (p) => p.eq("roleplay_id", t.roleplayId)).collect(), i = await Promise.all(
      o.map(async (p) => {
        let _ = await r.db.get(p.user_id);
        return {
          user_id: p.user_id,
          user_name: _?.name || "Unknown User",
          role: p.role,
          is_creator: p.is_creator
        };
      })
    );
    return {
      ...s,
      participants: i,
      materials: []
    };
  }, "handler")
}), v = c({
  args: {
    roleplayId: e.id("roleplays")
  },
  returns: e.union(
    e.object({
      overall_score: e.number(),
      evaluation_details: e.object({
        hearingAbility: e.number(),
        problemSetting: e.number(),
        knowledge: e.number(),
        negotiation: e.number(),
        businessManners: e.number()
      }),
      analysis: e.object({
        strengths: e.array(e.string()),
        improvements: e.array(e.string()),
        detailed_feedback: e.string()
      }),
      evaluated_at: e.number()
    }),
    e.null()
  ),
  handler: /* @__PURE__ */ u(async (r, t) => {
    if (!await r.auth.getUserIdentity())
      throw new Error("\u8A8D\u8A3C\u304C\u5FC5\u8981\u3067\u3059");
    return {
      overall_score: 78,
      evaluation_details: {
        hearingAbility: 8.5,
        problemSetting: 7.2,
        knowledge: 8,
        negotiation: 7.8,
        businessManners: 8.3
      },
      analysis: {
        strengths: [
          "\u30D2\u30A2\u30EA\u30F3\u30B0\u80FD\u529B\u304C\u512A\u79C0\u3067\u3001\u76F8\u624B\u306E\u30CB\u30FC\u30BA\u3092\u7684\u78BA\u306B\u628A\u63E1\u3067\u304D\u3066\u3044\u308B",
          "\u30D3\u30B8\u30CD\u30B9\u30DE\u30CA\u30FC\u304C\u8EAB\u306B\u3064\u3044\u3066\u304A\u308A\u3001\u597D\u5370\u8C61\u3092\u4E0E\u3048\u3066\u3044\u308B"
        ],
        improvements: [
          "\u554F\u984C\u8A2D\u5B9A\u306E\u30B9\u30AD\u30EB\u3092\u3082\u3046\u5C11\u3057\u5411\u4E0A\u3055\u305B\u308B\u5FC5\u8981\u304C\u3042\u308B",
          "\u4EA4\u6E09\u6642\u306E\u8AD6\u7406\u7684\u601D\u8003\u529B\u3092\u5F37\u5316\u3059\u3079\u304D"
        ],
        detailed_feedback: "\u5168\u4F53\u7684\u306B\u826F\u597D\u306A\u30D1\u30D5\u30A9\u30FC\u30DE\u30F3\u30B9\u3067\u3057\u305F\u3002\u7279\u306B\u30D2\u30A2\u30EA\u30F3\u30B0\u529B\u306F\u512A\u79C0\u3067\u3001\u9867\u5BA2\u306E\u8981\u671B\u3092\u6B63\u78BA\u306B\u7406\u89E3\u3067\u304D\u3066\u3044\u307E\u3059\u3002\u4ECA\u5F8C\u306F\u554F\u984C\u8A2D\u5B9A\u529B\u3092\u5411\u4E0A\u3055\u305B\u308B\u3053\u3068\u3067\u3001\u3088\u308A\u9AD8\u3044\u6210\u679C\u304C\u671F\u5F85\u3067\u304D\u307E\u3059\u3002"
      },
      evaluated_at: Date.now()
    };
  }, "handler")
}), x = y({
  args: {
    title: e.string(),
    description: e.optional(e.string()),
    type: e.string(),
    max_participants: e.optional(e.number()),
    scheduled_at: e.optional(e.string())
  },
  returns: e.id("roleplays"),
  handler: /* @__PURE__ */ u(async (r, t) => {
    let a = await r.auth.getUserIdentity();
    if (!a)
      throw new Error("\u8A8D\u8A3C\u304C\u5FC5\u8981\u3067\u3059");
    let n = await r.db.query("users").withIndex("by_token", (o) => o.eq("tokenIdentifier", a.tokenIdentifier)).unique();
    if (!n)
      throw new Error("\u30E6\u30FC\u30B6\u30FC\u304C\u898B\u3064\u304B\u308A\u307E\u305B\u3093");
    let s = await r.db.insert("roleplays", {
      title: t.title,
      description: t.description,
      type: t.type,
      status: "scheduled",
      max_participants: t.max_participants,
      scheduled_at: t.scheduled_at ? new Date(t.scheduled_at).getTime() : void 0,
      created_by: n._id
    });
    return await r.db.insert("roleplayParticipants", {
      roleplay_id: s,
      user_id: n._id,
      is_creator: !0,
      role: "\u4F5C\u6210\u8005"
    }), s;
  }, "handler")
}), D = y({
  args: {
    roleplayId: e.id("roleplays"),
    role: e.optional(e.string())
  },
  returns: e.null(),
  handler: /* @__PURE__ */ u(async (r, t) => {
    let a = await r.auth.getUserIdentity();
    if (!a)
      throw new Error("\u8A8D\u8A3C\u304C\u5FC5\u8981\u3067\u3059");
    let n = await r.db.query("users").withIndex("by_token", (i) => i.eq("tokenIdentifier", a.tokenIdentifier)).unique();
    if (!n)
      throw new Error("\u30E6\u30FC\u30B6\u30FC\u304C\u898B\u3064\u304B\u308A\u307E\u305B\u3093");
    if (await r.db.query("roleplayParticipants").withIndex("by_roleplay_id", (i) => i.eq("roleplay_id", t.roleplayId)).filter((i) => i.eq(i.field("user_id"), n._id)).unique())
      throw new Error("\u65E2\u306B\u53C2\u52A0\u6E08\u307F\u3067\u3059");
    let o = await r.db.get(t.roleplayId);
    if (!o)
      throw new Error("\u30ED\u30FC\u30EB\u30D7\u30EC\u30A4\u304C\u898B\u3064\u304B\u308A\u307E\u305B\u3093");
    if (o.created_by === n._id)
      throw new Error("\u81EA\u5206\u304C\u4F5C\u6210\u3057\u305F\u30ED\u30FC\u30EB\u30D7\u30EC\u30A4\u306B\u306F\u53C2\u52A0\u3067\u304D\u307E\u305B\u3093");
    if (o.max_participants && await r.db.query("roleplayParticipants").withIndex("by_roleplay_id", (l) => l.eq("roleplay_id", t.roleplayId)).collect().then((l) => l.length) >= o.max_participants)
      throw new Error("\u5B9A\u54E1\u306B\u9054\u3057\u3066\u3044\u307E\u3059");
    return await r.db.insert("roleplayParticipants", {
      roleplay_id: t.roleplayId,
      user_id: n._id,
      is_creator: !1,
      role: t.role || "\u53C2\u52A0\u8005"
    }), null;
  }, "handler")
}), R = y({
  args: {
    roleplayId: e.id("roleplays")
  },
  returns: e.null(),
  handler: /* @__PURE__ */ u(async (r, t) => {
    let a = await r.auth.getUserIdentity();
    if (!a)
      throw new Error("\u8A8D\u8A3C\u304C\u5FC5\u8981\u3067\u3059");
    let n = await r.db.query("users").withIndex("by_token", (o) => o.eq("tokenIdentifier", a.tokenIdentifier)).unique();
    if (!n)
      throw new Error("\u30E6\u30FC\u30B6\u30FC\u304C\u898B\u3064\u304B\u308A\u307E\u305B\u3093");
    let s = await r.db.query("roleplayParticipants").withIndex("by_roleplay_id", (o) => o.eq("roleplay_id", t.roleplayId)).filter((o) => o.eq(o.field("user_id"), n._id)).unique();
    if (!s)
      throw new Error("\u53C2\u52A0\u3057\u3066\u3044\u307E\u305B\u3093");
    if (s.is_creator)
      throw new Error("\u4F5C\u6210\u8005\u306F\u53C2\u52A0\u3092\u30AD\u30E3\u30F3\u30BB\u30EB\u3067\u304D\u307E\u305B\u3093");
    return await r.db.delete(s._id), null;
  }, "handler")
}), M = y({
  args: {
    roleplayId: e.id("roleplays"),
    scores: e.object({
      hearingAbility: e.number(),
      problemSetting: e.number(),
      knowledge: e.number(),
      negotiation: e.number(),
      businessManners: e.number()
    }),
    comments: e.optional(e.string())
  },
  returns: e.null(),
  handler: /* @__PURE__ */ u(async (r, t) => {
    if (!await r.auth.getUserIdentity())
      throw new Error("\u8A8D\u8A3C\u304C\u5FC5\u8981\u3067\u3059");
    return console.log("\u8A55\u4FA1\u767B\u9332:", t), null;
  }, "handler")
}), T = y({
  args: {
    roleplayId: e.id("roleplays"),
    title: e.optional(e.string()),
    description: e.optional(e.string()),
    status: e.optional(e.string()),
    max_participants: e.optional(e.number()),
    scheduled_at: e.optional(e.string())
  },
  returns: e.null(),
  handler: /* @__PURE__ */ u(async (r, t) => {
    let a = await r.auth.getUserIdentity();
    if (!a)
      throw new Error("\u8A8D\u8A3C\u304C\u5FC5\u8981\u3067\u3059");
    let n = await r.db.query("users").withIndex("by_token", (l) => l.eq("tokenIdentifier", a.tokenIdentifier)).unique();
    if (!n)
      throw new Error("\u30E6\u30FC\u30B6\u30FC\u304C\u898B\u3064\u304B\u308A\u307E\u305B\u3093");
    if (!await r.db.get(t.roleplayId))
      throw new Error("\u30ED\u30FC\u30EB\u30D7\u30EC\u30A4\u304C\u898B\u3064\u304B\u308A\u307E\u305B\u3093");
    if (!await r.db.query("roleplayParticipants").withIndex("by_roleplay_id", (l) => l.eq("roleplay_id", t.roleplayId)).filter((l) => l.eq(l.field("user_id"), n._id)).filter((l) => l.eq(l.field("is_creator"), !0)).unique())
      throw new Error("\u7DE8\u96C6\u6A29\u9650\u304C\u3042\u308A\u307E\u305B\u3093");
    let i = {};
    return t.title !== void 0 && (i.title = t.title), t.description !== void 0 && (i.description = t.description), t.status !== void 0 && (i.status = t.status), t.max_participants !== void 0 && (i.max_participants = t.max_participants), t.scheduled_at !== void 0 && (i.scheduled_at = new Date(t.scheduled_at).getTime()), await r.db.patch(t.roleplayId, i), null;
  }, "handler")
}), A = y({
  args: {
    roleplayId: e.id("roleplays")
  },
  returns: e.null(),
  handler: /* @__PURE__ */ u(async (r, t) => {
    let a = await r.auth.getUserIdentity();
    if (!a)
      throw new Error("\u8A8D\u8A3C\u304C\u5FC5\u8981\u3067\u3059");
    let n = await r.db.query("users").withIndex("by_token", (i) => i.eq("tokenIdentifier", a.tokenIdentifier)).unique();
    if (!n)
      throw new Error("\u30E6\u30FC\u30B6\u30FC\u304C\u898B\u3064\u304B\u308A\u307E\u305B\u3093");
    if (!await r.db.get(t.roleplayId))
      throw new Error("\u30ED\u30FC\u30EB\u30D7\u30EC\u30A4\u304C\u898B\u3064\u304B\u308A\u307E\u305B\u3093");
    if (!await r.db.query("roleplayParticipants").withIndex("by_roleplay_id", (i) => i.eq("roleplay_id", t.roleplayId)).filter((i) => i.eq(i.field("user_id"), n._id)).filter((i) => i.eq(i.field("is_creator"), !0)).unique())
      throw new Error("\u524A\u9664\u6A29\u9650\u304C\u3042\u308A\u307E\u305B\u3093");
    return await r.db.patch(t.roleplayId, {
      status: "deleted"
    }), null;
  }, "handler")
}), S = c({
  args: {
    roleplayId: e.id("roleplays")
  },
  returns: e.object({
    participants: e.array(
      e.object({
        user_id: e.id("users"),
        username: e.string(),
        role: e.optional(e.string()),
        is_creator: e.boolean(),
        learning_goal: e.optional(e.string())
      })
    ),
    error: e.optional(e.string())
  }),
  handler: /* @__PURE__ */ u(async (r, t) => {
    try {
      if (!await r.auth.getUserIdentity())
        return {
          participants: [],
          error: "\u8A8D\u8A3C\u304C\u5FC5\u8981\u3067\u3059"
        };
      if (!await r.db.get(t.roleplayId))
        return {
          participants: [],
          error: "\u30ED\u30FC\u30EB\u30D7\u30EC\u30A4\u304C\u898B\u3064\u304B\u308A\u307E\u305B\u3093"
        };
      let s = await r.db.query("roleplayParticipants").withIndex("by_roleplay_id", (i) => i.eq("roleplay_id", t.roleplayId)).collect();
      return {
        participants: await Promise.all(
          s.map(async (i) => {
            let l = await r.db.get(i.user_id);
            return {
              user_id: i.user_id,
              username: l?.name || "Unknown User",
              role: i.role,
              is_creator: i.is_creator,
              learning_goal: void 0
              // 今後追加予定
            };
          })
        ),
        error: void 0
      };
    } catch (a) {
      return {
        participants: [],
        error: a instanceof Error ? a.message : "\u30A8\u30E9\u30FC\u304C\u767A\u751F\u3057\u307E\u3057\u305F"
      };
    }
  }, "handler")
});
export {
  M as addEvaluation,
  R as cancel,
  x as create,
  A as deleteRoleplay,
  j as getById,
  v as getEvaluation,
  S as getParticipants,
  D as join,
  P as list,
  T as update
};
//# sourceMappingURL=roleplay.js.map
