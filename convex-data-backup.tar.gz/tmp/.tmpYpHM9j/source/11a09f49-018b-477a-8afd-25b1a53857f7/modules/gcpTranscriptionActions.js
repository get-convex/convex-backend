"use node";
import {
  a as t
} from "./_deps/node/QGU4DEQS.js";
import {
  c as i
} from "./_deps/node/PDGHC3PS.js";
import {
  a as n
} from "./_deps/node/UDHF6CTX.js";
import {
  a as r
} from "./_deps/node/V7X2J7BI.js";

// convex/gcpTranscriptionActions.ts
var l = i({
  args: {
    fileUrl: n.string(),
    fileType: n.string(),
    options: n.object({
      enableSpeakerDiarization: n.optional(n.boolean()),
      language: n.optional(n.string())
    })
  },
  returns: n.object({
    text: n.string(),
    segments: n.optional(n.any()),
    confidence: n.optional(n.number()),
    duration_seconds: n.optional(n.number()),
    error: n.optional(n.string())
    // M4A未対応などのエラー情報
  }),
  handler: /* @__PURE__ */ r(async (e, o) => await t(o.fileUrl, o.fileType, o.options), "handler")
});
export {
  l as performGcpChirpTranscription
};
//# sourceMappingURL=gcpTranscriptionActions.js.map
