import {
  a as f,
  b as d
} from "./_deps/6HNJFR7B.js";
import {
  a as _,
  c as u
} from "./_deps/75JH2J25.js";
import "./_deps/6XQQNYIR.js";
import {
  j as t,
  l as o,
  n as l
} from "./_deps/3TDUHHJO.js";
import {
  a as s
} from "./_deps/RUVYHBJQ.js";

// convex/notifications.ts
l();
l();
var y = t.any(), b = t.any(), q = u({
  args: {
    target_user_id: t.string(),
    // Clerkユーザー ID
    type: t.string(),
    title: t.string(),
    message: t.string(),
    data: t.optional(y)
  },
  returns: t.id("notifications"),
  handler: /* @__PURE__ */ s(async (i, e) => {
    await f(i);
    let r = await i.db.query("users").withIndex("by_clerk_user_id", (a) => a.eq("clerkUserId", e.target_user_id)).first();
    if (!r)
      throw new o("Target user not found in system");
    return await i.db.insert("notifications", {
      user_id: r._id,
      type: e.type,
      title: e.title,
      message: e.message,
      data: e.data ? JSON.stringify(e.data) : void 0,
      is_read: !1
    });
  }, "handler")
}), k = _({
  args: {
    unread_only: t.optional(t.boolean()),
    limit: t.optional(t.number())
  },
  returns: t.any(),
  handler: /* @__PURE__ */ s(async (i, e) => {
    let { user: r } = await d(i), n = i.db.query("notifications").filter((a) => a.eq(a.field("user_id"), r._id)).order("desc");
    return e.unread_only && (n = i.db.query("notifications").withIndex(
      "by_user_id_and_read",
      (a) => a.eq("user_id", r._id).eq("is_read", !1)
    ).order("desc")), e.limit ? await n.take(e.limit) : await n.collect();
  }, "handler")
}), U = _({
  args: {
    clerk_user_id: t.string(),
    unread_only: t.optional(t.boolean()),
    limit: t.optional(t.number())
  },
  returns: t.any(),
  handler: /* @__PURE__ */ s(async (i, e) => {
    let { user: r } = await d(i);
    if (r.clerkUserId !== e.clerk_user_id)
      throw new o("Access denied. You can only access your own notifications.");
    let n = await i.db.query("users").withIndex("by_clerk_user_id", (c) => c.eq("clerkUserId", e.clerk_user_id)).first();
    if (!n)
      throw new o("User not found");
    let a = i.db.query("notifications").filter((c) => c.eq(c.field("user_id"), n._id)).order("desc");
    return e.unread_only && (a = i.db.query("notifications").withIndex(
      "by_user_id_and_read",
      (c) => c.eq("user_id", n._id).eq("is_read", !1)
    ).order("desc")), e.limit ? await a.take(e.limit) : await a.collect();
  }, "handler")
}), g = u({
  args: {
    notification_id: t.id("notifications")
  },
  returns: t.any(),
  handler: /* @__PURE__ */ s(async (i, e) => {
    let { user: r } = await d(i), n = await i.db.get(e.notification_id);
    if (!n)
      throw new o("Notification not found");
    if (n.user_id !== r._id)
      throw new o("Access denied. You can only mark your own notifications as read.");
    return await i.db.patch(e.notification_id, {
      is_read: !0
    }), {
      success: !0,
      notification_id: e.notification_id
    };
  }, "handler")
}), I = u({
  args: {
    notification_id: t.id("notifications"),
    clerk_user_id: t.string()
  },
  returns: t.any(),
  handler: /* @__PURE__ */ s(async (i, e) => {
    let { user: r } = await d(i);
    if (r.clerkUserId !== e.clerk_user_id)
      throw new o("Access denied. You can only mark your own notifications as read.");
    let n = await i.db.get(e.notification_id);
    if (!n)
      throw new o("Notification not found");
    if (n.user_id !== r._id)
      throw new o("Notification does not belong to user");
    return await i.db.patch(e.notification_id, {
      is_read: !0
    }), {
      success: !0,
      notification_id: e.notification_id
    };
  }, "handler")
}), N = u({
  args: {},
  returns: t.any(),
  handler: /* @__PURE__ */ s(async (i) => {
    let { user: e } = await d(i), r = await i.db.query("notifications").withIndex(
      "by_user_id_and_read",
      (n) => n.eq("user_id", e._id).eq("is_read", !1)
    ).collect();
    return await Promise.all(
      r.map((n) => i.db.patch(n._id, { is_read: !0 }))
    ), {
      success: !0,
      updated_count: r.length
    };
  }, "handler")
}), A = u({
  args: {
    clerk_user_id: t.string()
  },
  returns: t.any(),
  handler: /* @__PURE__ */ s(async (i, e) => {
    let { user: r } = await d(i);
    if (r.clerkUserId !== e.clerk_user_id)
      throw new o("Access denied. You can only mark your own notifications as read.");
    let n = await i.db.query("notifications").withIndex(
      "by_user_id_and_read",
      (a) => a.eq("user_id", r._id).eq("is_read", !1)
    ).collect();
    return await Promise.all(
      n.map((a) => i.db.patch(a._id, { is_read: !0 }))
    ), {
      success: !0,
      updated_count: n.length
    };
  }, "handler")
}), C = _({
  args: {},
  returns: t.any(),
  handler: /* @__PURE__ */ s(async (i) => {
    let { user: e } = await d(i);
    return {
      count: (await i.db.query("notifications").withIndex(
        "by_user_id_and_read",
        (a) => a.eq("user_id", e._id).eq("is_read", !1)
      ).collect()).length
    };
  }, "handler")
}), Y = _({
  args: {
    clerk_user_id: t.string()
  },
  returns: t.any(),
  handler: /* @__PURE__ */ s(async (i, e) => {
    let { user: r } = await d(i);
    if (r.clerkUserId !== e.clerk_user_id)
      throw new o("Access denied. You can only access your own notification count.");
    return {
      count: (await i.db.query("notifications").withIndex(
        "by_user_id_and_read",
        (c) => c.eq("user_id", r._id).eq("is_read", !1)
      ).collect()).length
    };
  }, "handler")
}), B = u({
  args: {
    notification_id: t.id("notifications")
  },
  returns: t.any(),
  handler: /* @__PURE__ */ s(async (i, e) => {
    let { user: r } = await d(i), n = await i.db.get(e.notification_id);
    if (!n)
      throw new o("Notification not found");
    if (n.user_id !== r._id)
      throw new o("Access denied. You can only delete your own notifications.");
    return await i.db.delete(e.notification_id), {
      success: !0
    };
  }, "handler")
}), R = _({
  args: {
    type: t.string(),
    limit: t.optional(t.number())
  },
  returns: t.any(),
  handler: /* @__PURE__ */ s(async (i, e) => {
    let { user: r } = await d(i), n = i.db.query("notifications").withIndex(
      "by_user_id_and_type",
      (a) => a.eq("user_id", r._id).eq("type", e.type)
    ).order("desc");
    return e.limit ? await n.take(e.limit) : await n.collect();
  }, "handler")
});
export {
  q as createNotification,
  B as deleteNotification,
  k as getNotifications,
  U as getNotificationsByClerkUserId,
  R as getNotificationsByType,
  C as getUnreadCount,
  Y as getUnreadCountByClerkUserId,
  N as markAllNotificationsAsRead,
  A as markAllNotificationsAsReadByClerkUserId,
  g as markNotificationAsRead,
  I as markNotificationAsReadByClerkUserId
};
//# sourceMappingURL=notifications.js.map
