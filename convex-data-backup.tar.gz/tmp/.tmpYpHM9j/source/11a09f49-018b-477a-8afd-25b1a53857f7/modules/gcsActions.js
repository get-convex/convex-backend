"use node";
import {
  c as i
} from "./_deps/node/PDGHC3PS.js";
import {
  a as t
} from "./_deps/node/UDHF6CTX.js";
import {
  a as l
} from "./_deps/node/V7X2J7BI.js";

// convex/gcsActions.ts
var y = i({
  args: {
    filename: t.string(),
    contentType: t.string(),
    uploadType: t.string(),
    fileSize: t.optional(t.number())
  },
  returns: t.object({
    uploadUrl: t.string(),
    gcpFilePath: t.string(),
    isMultipart: t.boolean()
  }),
  handler: /* @__PURE__ */ l(async (p, o) => {
    try {
      console.log("[generateGCPUploadUrl] Cloud Run Proxy\u7D4C\u7531\u3067GCS\u7F72\u540D\u4ED8\u304DURL\u751F\u6210\u958B\u59CB:", {
        filename: o.filename,
        contentType: o.contentType,
        uploadType: o.uploadType,
        fileSize: o.fileSize
      });
      let e = process.env.CLOUD_RUN_PROXY_URL;
      if (!e)
        throw new Error("CLOUD_RUN_PROXY_URL\u74B0\u5883\u5909\u6570\u304C\u8A2D\u5B9A\u3055\u308C\u3066\u3044\u307E\u305B\u3093");
      let n = {
        filename: o.filename,
        contentType: o.contentType,
        uploadType: o.uploadType,
        fileSize: o.fileSize
      };
      console.log(`[generateGCPUploadUrl] Proxy URL: ${e}/gcs/generate-upload-url`), console.log("[generateGCPUploadUrl] \u30EA\u30AF\u30A8\u30B9\u30C8\u30DC\u30C7\u30A3:", n);
      let r = await fetch(`${e}/gcs/generate-upload-url`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify(n)
      });
      if (!r.ok) {
        let a = await r.text();
        throw new Error(`Cloud Run Proxy\u547C\u3073\u51FA\u3057\u5931\u6557: ${r.status} - ${a}`);
      }
      let s = await r.json();
      if (console.log("[generateGCPUploadUrl] Cloud Run Proxy\u5FDC\u7B54\u53D7\u4FE1:", s), !s.success)
        throw new Error(`GCS\u7F72\u540D\u4ED8\u304DURL\u751F\u6210\u5931\u6557: ${s.error || "\u4E0D\u660E\u306A\u30A8\u30E9\u30FC"}`);
      return console.log("[generateGCPUploadUrl] Cloud Run Proxy\u7D4C\u7531\u3067GCS\u7F72\u540D\u4ED8\u304DURL\u751F\u6210\u5B8C\u4E86:", {
        gcpFilePath: s.gcpFilePath,
        isMultipart: s.isMultipart,
        uploadUrlGenerated: s.uploadUrl ? "\u2713" : "\u2717"
      }), {
        uploadUrl: s.uploadUrl,
        gcpFilePath: s.gcpFilePath,
        isMultipart: s.isMultipart
      };
    } catch (e) {
      throw console.error("[generateGCPUploadUrl] \u30A8\u30E9\u30FC:", e), new Error(
        `GCS\u7F72\u540D\u4ED8\u304DURL\u751F\u6210\u306B\u5931\u6557\u3057\u307E\u3057\u305F: ${e instanceof Error ? e.message : "\u4E0D\u660E\u306A\u30A8\u30E9\u30FC"}`
      );
    }
  }, "handler")
}), w = i({
  args: {
    gcpFilePath: t.string()
  },
  returns: t.object({
    success: t.boolean(),
    dataUrl: t.string(),
    // data:audio/m4a;base64,... 形式
    contentType: t.string(),
    size: t.number()
  }),
  handler: /* @__PURE__ */ l(async (p, o) => {
    try {
      console.log("[fetchGCPFileAsUrl] GCS\u30D5\u30A1\u30A4\u30EB\u53D6\u5F97\u958B\u59CB\uFF08\u4E00\u6642\u7684\u306A\u89E3\u6C7A\u7B56\uFF09:", o.gcpFilePath);
      let e = o.gcpFilePath.split("/").pop() || "file";
      throw console.log("[fetchGCPFileAsUrl] \u7F72\u540D\u4ED8\u304DURL\u751F\u6210\u5B8C\u4E86"), new Error("GCS\u6A5F\u80FD\u306F\u4E00\u6642\u7684\u306B\u7121\u52B9\u5316\u3055\u308C\u3066\u3044\u307E\u3059\uFF08\u578B\u306E\u6DF1\u5EA6\u30A8\u30E9\u30FC\u56DE\u907F\u306E\u305F\u3081\uFF09");
    } catch (e) {
      return console.error("[fetchGCPFileAsUrl] \u30A8\u30E9\u30FC:", e), {
        success: !1,
        dataUrl: "data:audio/m4a;base64,",
        contentType: "audio/m4a",
        size: 0
      };
    }
  }, "handler")
}), f = i({
  args: {
    gcpFilePath: t.string(),
    expirationMinutes: t.optional(t.number())
  },
  returns: t.object({
    success: t.boolean(),
    readUrl: t.optional(t.string()),
    error: t.optional(t.string()),
    // Cloud Run Proxyのレスポンスに合わせて、これらのフィールドをオプショナルに変更
    gcpFilePath: t.optional(t.string()),
    expiresIn: t.optional(t.number()),
    expiresAt: t.optional(t.string())
  }),
  handler: /* @__PURE__ */ l(async (p, o) => {
    let e = process.env.CLOUD_RUN_PROXY_URL;
    if (!e) {
      console.error("[generateGCPReadUrl] CLOUD_RUN_PROXY_URL\u74B0\u5883\u5909\u6570\u304C\u8A2D\u5B9A\u3055\u308C\u3066\u3044\u307E\u305B\u3093");
      let n = process.env.GCS_BUCKET_NAME || "ai-sales-hub-dev-new_dify-ai-sales-hub-dev-new", r = `https://storage.googleapis.com/ai-sales-training-hub-media/${o.gcpFilePath}`;
      return console.log("[generateGCPReadUrl] \u30D5\u30A9\u30FC\u30EB\u30D0\u30C3\u30AF - \u30D1\u30D6\u30EA\u30C3\u30AFURL\u3092\u4F7F\u7528:", r), {
        success: !0,
        readUrl: r,
        gcpFilePath: o.gcpFilePath
      };
    }
    try {
      console.log(`[generateGCPReadUrl] \u7F72\u540D\u4ED8\u304DURL\u751F\u6210\u958B\u59CB: ${o.gcpFilePath}`);
      let n = {
        gcpFilePath: o.gcpFilePath,
        expirationMinutes: o.expirationMinutes || 120
        // デフォルト2時間
      };
      console.log("[generateGCPReadUrl] Cloud Run Proxy\u306B\u30EA\u30AF\u30A8\u30B9\u30C8:", n);
      let r = await fetch(`${e}/gcs/generate-read-url`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify(n)
      });
      if (!r.ok) {
        let a = await r.text();
        return console.error(`[generateGCPReadUrl] Cloud Run Proxy\u30A8\u30E9\u30FC: ${r.status} - ${a}`), {
          success: !1,
          error: `Cloud Run Proxy\u30A8\u30E9\u30FC: ${r.status} - ${a}`
        };
      }
      let s = await r.json();
      return console.log("[generateGCPReadUrl] Cloud Run Proxy\u30EC\u30B9\u30DD\u30F3\u30B9:", s), s.success ? (console.log("[generateGCPReadUrl] \u7F72\u540D\u4ED8\u304DURL\u751F\u6210\u6210\u529F"), {
        success: !0,
        readUrl: s.readUrl,
        // レスポンスに含まれている場合のみ設定
        gcpFilePath: s.gcpFilePath,
        expiresIn: s.expiresIn,
        expiresAt: s.expiresAt
      }) : (console.error("[generateGCPReadUrl] \u7F72\u540D\u4ED8\u304DURL\u751F\u6210\u5931\u6557:", s.error), {
        success: !1,
        error: s.error || "\u4E0D\u660E\u306A\u30A8\u30E9\u30FC"
      });
    } catch (n) {
      return console.error("[generateGCPReadUrl] \u4E88\u671F\u3057\u306A\u3044\u30A8\u30E9\u30FC:", n), {
        success: !1,
        error: `\u4E88\u671F\u3057\u306A\u3044\u30A8\u30E9\u30FC: ${n instanceof Error ? n.message : String(n)}`
      };
    }
  }, "handler")
}), F = i({
  args: {
    gcpFilePath: t.string()
  },
  returns: t.object({
    success: t.boolean(),
    data: t.string(),
    // Base64エンコードされたデータ
    contentType: t.string(),
    size: t.number()
  }),
  handler: /* @__PURE__ */ l(async (p, o) => {
    try {
      console.log("[fetchGCPFile] Cloud Run Proxy\u7D4C\u7531\u3067GCS\u30D5\u30A1\u30A4\u30EB\u53D6\u5F97\u958B\u59CB:", {
        gcpFilePath: o.gcpFilePath
      });
      let e = process.env.CLOUD_RUN_PROXY_URL;
      if (!e)
        throw new Error("CLOUD_RUN_PROXY_URL\u74B0\u5883\u5909\u6570\u304C\u8A2D\u5B9A\u3055\u308C\u3066\u3044\u307E\u305B\u3093");
      let n = {
        gcpFilePath: o.gcpFilePath
      };
      console.log(`[fetchGCPFile] Proxy URL: ${e}/gcs/fetch-file`), console.log("[fetchGCPFile] \u30EA\u30AF\u30A8\u30B9\u30C8\u30DC\u30C7\u30A3:", n);
      let r = await fetch(`${e}/gcs/fetch-file`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify(n)
      });
      if (!r.ok) {
        let a = await r.text();
        throw new Error(`Cloud Run Proxy\u547C\u3073\u51FA\u3057\u5931\u6557: ${r.status} - ${a}`);
      }
      let s = await r.json();
      if (console.log("[fetchGCPFile] Cloud Run Proxy\u5FDC\u7B54\u53D7\u4FE1:", {
        success: s.success,
        dataLength: s.data?.length || 0,
        contentType: s.contentType,
        size: s.size
      }), !s.success)
        throw new Error(`GCS\u30D5\u30A1\u30A4\u30EB\u53D6\u5F97\u5931\u6557: ${s.error || "\u4E0D\u660E\u306A\u30A8\u30E9\u30FC"}`);
      return console.log("[fetchGCPFile] Cloud Run Proxy\u7D4C\u7531\u3067GCS\u30D5\u30A1\u30A4\u30EB\u53D6\u5F97\u5B8C\u4E86"), {
        success: !0,
        data: s.data,
        contentType: s.contentType,
        size: s.size
      };
    } catch (e) {
      throw console.error("[fetchGCPFile] \u30A8\u30E9\u30FC:", e), new Error(
        `GCS\u30D5\u30A1\u30A4\u30EB\u53D6\u5F97\u306B\u5931\u6557\u3057\u307E\u3057\u305F: ${e instanceof Error ? e.message : "\u4E0D\u660E\u306A\u30A8\u30E9\u30FC"}`
      );
    }
  }, "handler")
}), R = i({
  args: {
    gcpFilePath: t.string()
  },
  returns: t.object({
    success: t.boolean(),
    publicUrl: t.string()
  }),
  handler: /* @__PURE__ */ l(async (p, o) => {
    try {
      console.log("[makeFileTemporarilyPublic] \u30D5\u30A1\u30A4\u30EB\u3092\u4E00\u6642\u7684\u306B\u30D1\u30D6\u30EA\u30C3\u30AF\u8A2D\u5B9A\u958B\u59CB:", o.gcpFilePath);
      let e = process.env.CLOUD_RUN_PROXY_URL;
      if (!e)
        throw new Error("CLOUD_RUN_PROXY_URL\u74B0\u5883\u5909\u6570\u304C\u8A2D\u5B9A\u3055\u308C\u3066\u3044\u307E\u305B\u3093");
      let n = {
        gcpFilePath: o.gcpFilePath
      };
      console.log(`[makeFileTemporarilyPublic] Proxy URL: ${e}/gcs/make-public`), console.log("[makeFileTemporarilyPublic] \u30EA\u30AF\u30A8\u30B9\u30C8\u30DC\u30C7\u30A3:", n);
      let r = await fetch(`${e}/gcs/make-public`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify(n)
      }), s = process.env.GCS_BUCKET_NAME || "ai-sales-hub-dev-new_dify-ai-sales-hub-dev-new";
      if (!r.ok) {
        let u = await r.text();
        console.warn(`[makeFileTemporarilyPublic] Cloud Run Proxy\u547C\u3073\u51FA\u3057\u5931\u6557: ${r.status} - ${u}`);
        let g = `https://storage.googleapis.com/${s}/${o.gcpFilePath}`;
        return console.log("[makeFileTemporarilyPublic] \u30A8\u30E9\u30FC\u304C\u767A\u751F\u3057\u307E\u3057\u305F\u304C\u3001\u30D1\u30D6\u30EA\u30C3\u30AFURL\u3092\u8FD4\u3057\u307E\u3059:", g), {
          success: !1,
          publicUrl: g
        };
      }
      let a = await r.json();
      console.log("[makeFileTemporarilyPublic] Cloud Run Proxy\u5FDC\u7B54\u53D7\u4FE1:", a);
      let c = a.publicUrl || `https://storage.googleapis.com/${s}/${o.gcpFilePath}`;
      return console.log("[makeFileTemporarilyPublic] \u30D5\u30A1\u30A4\u30EB\u516C\u958B\u8A2D\u5B9A\u5B8C\u4E86:", c), {
        success: !0,
        publicUrl: c
      };
    } catch (e) {
      return console.error("[makeFileTemporarilyPublic] \u30A8\u30E9\u30FC:", e), {
        success: !1,
        publicUrl: `https://storage.googleapis.com/${process.env.GCS_BUCKET_NAME || "ai-sales-hub-dev-new_dify-ai-sales-hub-dev-new"}/${o.gcpFilePath}`
      };
    }
  }, "handler")
}), x = i({
  args: {
    gcpFilePath: t.string()
  },
  returns: t.object({
    success: t.boolean()
  }),
  handler: /* @__PURE__ */ l(async (p, o) => {
    try {
      console.log("[makeFilePrivate] \u30D5\u30A1\u30A4\u30EB\u3092\u975E\u516C\u958B\u306B\u623B\u3059:", o.gcpFilePath);
      let e = process.env.CLOUD_RUN_PROXY_URL;
      if (!e)
        throw new Error("CLOUD_RUN_PROXY_URL\u74B0\u5883\u5909\u6570\u304C\u8A2D\u5B9A\u3055\u308C\u3066\u3044\u307E\u305B\u3093");
      let n = {
        gcpFilePath: o.gcpFilePath
      };
      console.log(`[makeFilePrivate] Proxy URL: ${e}/gcs/make-private`), console.log("[makeFilePrivate] \u30EA\u30AF\u30A8\u30B9\u30C8\u30DC\u30C7\u30A3:", n);
      let r = await fetch(`${e}/gcs/make-private`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify(n)
      });
      if (!r.ok) {
        let s = await r.text();
        console.warn(`[makeFilePrivate] Cloud Run Proxy\u547C\u3073\u51FA\u3057\u5931\u6557: ${r.status} - ${s}`);
      }
      return {
        success: !0
      };
    } catch (e) {
      return console.error("[makeFilePrivate] \u30A8\u30E9\u30FC:", e), {
        success: !0
      };
    }
  }, "handler")
}), E = i({
  args: {
    gcpFilePath: t.string()
  },
  returns: t.object({
    success: t.boolean(),
    publicUrl: t.string()
  }),
  handler: /* @__PURE__ */ l(async (p, o) => {
    try {
      console.log("[makeFilePublic] \u30D5\u30A1\u30A4\u30EB\u3092\u30D1\u30D6\u30EA\u30C3\u30AF\u306B\u8A2D\u5B9A\u958B\u59CB:", o.gcpFilePath);
      let e = process.env.CLOUD_RUN_PROXY_URL;
      if (!e)
        throw new Error("CLOUD_RUN_PROXY_URL\u74B0\u5883\u5909\u6570\u304C\u8A2D\u5B9A\u3055\u308C\u3066\u3044\u307E\u305B\u3093");
      let n = {
        gcpFilePath: o.gcpFilePath
      };
      console.log(`[makeFilePublic] Proxy URL: ${e}/gcs/make-public`), console.log("[makeFilePublic] \u30EA\u30AF\u30A8\u30B9\u30C8\u30DC\u30C7\u30A3:", n);
      let r = await fetch(`${e}/gcs/make-public`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify(n)
      });
      if (!r.ok) {
        let c = await r.text();
        throw new Error(`Cloud Run Proxy\u547C\u3073\u51FA\u3057\u5931\u6557: ${r.status} - ${c}`);
      }
      let s = await r.json();
      if (console.log("[makeFilePublic] Cloud Run Proxy\u5FDC\u7B54\u53D7\u4FE1:", s), !s.success)
        throw new Error(`\u30D5\u30A1\u30A4\u30EB\u516C\u958B\u8A2D\u5B9A\u5931\u6557: ${s.error || "\u4E0D\u660E\u306A\u30A8\u30E9\u30FC"}`);
      let a = `https://storage.googleapis.com/ai-sales-training-hub-media/${o.gcpFilePath}`;
      return console.log("[makeFilePublic] \u30D5\u30A1\u30A4\u30EB\u516C\u958B\u8A2D\u5B9A\u5B8C\u4E86:", {
        gcpFilePath: o.gcpFilePath,
        publicUrl: a
      }), {
        success: !0,
        publicUrl: a
      };
    } catch (e) {
      throw console.error("[makeFilePublic] \u30A8\u30E9\u30FC:", e), new Error(
        `\u30D5\u30A1\u30A4\u30EB\u516C\u958B\u8A2D\u5B9A\u306B\u5931\u6557\u3057\u307E\u3057\u305F: ${e instanceof Error ? e.message : "\u4E0D\u660E\u306A\u30A8\u30E9\u30FC"}`
      );
    }
  }, "handler")
}), v = i({
  args: {
    gcpFilePath: t.string()
  },
  returns: t.object({
    readUrl: t.string(),
    expiresAt: t.number()
  }),
  handler: /* @__PURE__ */ l(async (p, o) => {
    try {
      console.log("[generateElevenLabsReadUrl] ElevenLabs\u7528\u8AAD\u307F\u53D6\u308AURL\u751F\u6210\u958B\u59CB:", {
        gcpFilePath: o.gcpFilePath
      });
      let e = {
        success: !1,
        error: "GCS\u6A5F\u80FD\u306F\u4E00\u6642\u7684\u306B\u7121\u52B9\u5316\u3055\u308C\u3066\u3044\u307E\u3059",
        readUrl: void 0
      };
      if (!e.success || !e.readUrl) {
        console.warn("[generateElevenLabsReadUrl] \u7F72\u540D\u4ED8\u304DURL\u751F\u6210\u5931\u6557\u3001\u30D5\u30A9\u30FC\u30EB\u30D0\u30C3\u30AFURL\u3092\u4F7F\u7528:", e.error);
        let r = process.env.GCS_BUCKET_NAME || "ai-sales-hub-dev-new_dify-ai-sales-hub-dev-new", s = `https://storage.googleapis.com/ai-sales-training-hub-media/${o.gcpFilePath}`, a = Date.now() + 24 * 60 * 60 * 1e3;
        return {
          readUrl: s,
          expiresAt: a
        };
      }
      console.log("[generateElevenLabsReadUrl] ElevenLabs\u7528\u8AAD\u307F\u53D6\u308AURL\u751F\u6210\u5B8C\u4E86:", e.readUrl);
      let n = Date.now() + 24 * 60 * 60 * 1e3;
      return {
        readUrl: e.readUrl,
        expiresAt: n
      };
    } catch (e) {
      console.error("[generateElevenLabsReadUrl] \u30A8\u30E9\u30FC:", e), console.log("[generateElevenLabsReadUrl] \u30A8\u30E9\u30FC\u5F8C\u306E\u30D5\u30A9\u30FC\u30EB\u30D0\u30C3\u30AF\u51E6\u7406\u3092\u5B9F\u884C");
      let n = process.env.GCS_BUCKET_NAME || "ai-sales-hub-dev-new_dify-ai-sales-hub-dev-new", r = `https://storage.googleapis.com/ai-sales-training-hub-media/${o.gcpFilePath}`, s = Date.now() + 24 * 60 * 60 * 1e3;
      return {
        readUrl: r,
        expiresAt: s
      };
    }
  }, "handler")
}), G = i({
  args: {
    gcpFilePath: t.string()
  },
  returns: t.object({
    success: t.boolean(),
    message: t.string()
  }),
  handler: /* @__PURE__ */ l(async (p, o) => {
    try {
      let e = process.env.GOOGLE_CLOUD_PROJECT_ID, n = process.env.GCS_BUCKET_NAME, r = process.env.GCS_CLIENT_EMAIL, s = process.env.GCS_PRIVATE_KEY_BASE64;
      if (!e || !n || !r || !s)
        throw new Error("GCS\u74B0\u5883\u5909\u6570\u304C\u8A2D\u5B9A\u3055\u308C\u3066\u3044\u307E\u305B\u3093");
      let { Storage: a } = await import("./_deps/node/57Z7VQNY.js"), c = Buffer.from(s, "base64").toString("utf-8"), u = {
        type: "service_account",
        project_id: e,
        private_key: c,
        client_email: r,
        auth_uri: "https://accounts.google.com/o/oauth2/auth",
        token_uri: "https://oauth2.googleapis.com/token",
        auth_provider_x509_cert_url: "https://www.googleapis.com/oauth2/v1/certs",
        client_x509_cert_url: `https://www.googleapis.com/robot/v1/metadata/x509/${encodeURIComponent(r)}`,
        universe_domain: "googleapis.com"
      };
      return await new a({
        projectId: e,
        credentials: u
      }).bucket(n).file(o.gcpFilePath).delete(), {
        success: !0,
        message: `\u30D5\u30A1\u30A4\u30EB\u3092\u524A\u9664\u3057\u307E\u3057\u305F: ${o.gcpFilePath}`
      };
    } catch (e) {
      return console.error("[deleteGCSFile] \u30A8\u30E9\u30FC:", e), {
        success: !1,
        message: `\u30D5\u30A1\u30A4\u30EB\u524A\u9664\u306B\u5931\u6557\u3057\u307E\u3057\u305F: ${e instanceof Error ? e.message : "\u4E0D\u660E\u306A\u30A8\u30E9\u30FC"}`
      };
    }
  }, "handler")
}), S = i({
  args: {
    fileData: t.array(t.number()),
    gcpFilePath: t.string(),
    contentType: t.string()
  },
  returns: t.object({
    success: t.boolean(),
    message: t.optional(t.string()),
    url: t.optional(t.string())
  }),
  handler: /* @__PURE__ */ l(async (p, o) => {
    try {
      let e = process.env.GOOGLE_CLOUD_PROJECT_ID, n = process.env.GCS_BUCKET_NAME, r = process.env.GCS_CLIENT_EMAIL, s = process.env.GCS_PRIVATE_KEY_BASE64;
      if (!e || !n || !r || !s)
        throw new Error("GCS\u74B0\u5883\u5909\u6570\u304C\u8A2D\u5B9A\u3055\u308C\u3066\u3044\u307E\u305B\u3093");
      let { Storage: a } = await import("./_deps/node/57Z7VQNY.js"), c = Buffer.from(s, "base64").toString("utf-8"), u = {
        type: "service_account",
        project_id: e,
        private_key: c,
        client_email: r,
        auth_uri: "https://accounts.google.com/o/oauth2/auth",
        token_uri: "https://oauth2.googleapis.com/token",
        auth_provider_x509_cert_url: "https://www.googleapis.com/oauth2/v1/certs",
        client_x509_cert_url: `https://www.googleapis.com/robot/v1/metadata/x509/${encodeURIComponent(r)}`,
        universe_domain: "googleapis.com"
      }, d = new a({
        projectId: e,
        credentials: u
      }).bucket(n).file(o.gcpFilePath), U = Buffer.from(o.fileData);
      console.log("[uploadFileToGCS] Uploading file:", {
        gcpFilePath: o.gcpFilePath,
        contentType: o.contentType,
        size: U.length
      }), await d.save(U, {
        metadata: {
          contentType: o.contentType
        }
      }), console.log("[uploadFileToGCS] Upload successful:", o.gcpFilePath);
      let [P] = await d.getSignedUrl({
        version: "v4",
        action: "read",
        expires: Date.now() + 7 * 24 * 60 * 60 * 1e3
        // 7日間有効
      });
      return {
        success: !0,
        message: `\u30D5\u30A1\u30A4\u30EB\u3092GCS\u306B\u30A2\u30C3\u30D7\u30ED\u30FC\u30C9\u3057\u307E\u3057\u305F: ${o.gcpFilePath}`,
        url: P
      };
    } catch (e) {
      return console.error("[uploadFileToGCS] \u30A8\u30E9\u30FC:", e), {
        success: !1,
        message: `GCS\u30A2\u30C3\u30D7\u30ED\u30FC\u30C9\u306B\u5931\u6557\u3057\u307E\u3057\u305F: ${e instanceof Error ? e.message : "\u4E0D\u660E\u306A\u30A8\u30E9\u30FC"}`
      };
    }
  }, "handler")
}), L = i({
  args: {
    gcpFilePath: t.string()
  },
  returns: t.object({
    readUrl: t.string()
  }),
  handler: /* @__PURE__ */ l(async (p, o) => {
    try {
      console.log("[generateReadUrlForExistingFile] \u65E2\u5B58\u30D5\u30A1\u30A4\u30EB\u306E\u8AAD\u307F\u53D6\u308A\u5C02\u7528URL\u751F\u6210\u958B\u59CB:", o.gcpFilePath);
      let e = process.env.CLOUD_RUN_PROXY_URL;
      if (!e)
        throw new Error("CLOUD_RUN_PROXY_URL\u74B0\u5883\u5909\u6570\u304C\u8A2D\u5B9A\u3055\u308C\u3066\u3044\u307E\u305B\u3093");
      let n = {
        gcpFilePath: o.gcpFilePath,
        action: "read",
        expirationMinutes: 60
      };
      console.log(`[generateReadUrlForExistingFile] Proxy URL: ${e}/gcs/generate-signed-url`), console.log("[generateReadUrlForExistingFile] \u30EA\u30AF\u30A8\u30B9\u30C8\u30DC\u30C7\u30A3:", n);
      let r = await fetch(`${e}/gcs/generate-signed-url`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify(n)
      });
      if (!r.ok) {
        let a = await r.text();
        console.warn(`[generateReadUrlForExistingFile] Cloud Run Proxy\u547C\u3073\u51FA\u3057\u5931\u6557: ${r.status} - ${a}`);
        let u = `https://storage.googleapis.com/${process.env.GCS_BUCKET_NAME || "ai-sales-hub-dev-new_dify-ai-sales-hub-dev-new"}/${o.gcpFilePath}`;
        return console.log("[generateReadUrlForExistingFile] \u30D5\u30A9\u30FC\u30EB\u30D0\u30C3\u30AF - \u30D1\u30D6\u30EA\u30C3\u30AFURL\u3092\u4F7F\u7528:", u), {
          readUrl: u
        };
      }
      let s = await r.json();
      if (console.log("[generateReadUrlForExistingFile] Cloud Run Proxy\u5FDC\u7B54\u53D7\u4FE1:", s), !s.success || !s.signedUrl) {
        let c = `https://storage.googleapis.com/${process.env.GCS_BUCKET_NAME || "ai-sales-hub-dev-new_dify-ai-sales-hub-dev-new"}/${o.gcpFilePath}`;
        return console.log("[generateReadUrlForExistingFile] \u7F72\u540D\u4ED8\u304DURL\u751F\u6210\u5931\u6557 - \u30D1\u30D6\u30EA\u30C3\u30AFURL\u3092\u4F7F\u7528:", c), {
          readUrl: c
        };
      }
      return console.log("[generateReadUrlForExistingFile] \u7F72\u540D\u4ED8\u304DURL\u751F\u6210\u5B8C\u4E86"), {
        readUrl: s.signedUrl
      };
    } catch (e) {
      return console.error("[generateReadUrlForExistingFile] \u30A8\u30E9\u30FC:", e), {
        readUrl: `https://storage.googleapis.com/${process.env.GCS_BUCKET_NAME || "ai-sales-hub-dev-new_dify-ai-sales-hub-dev-new"}/${o.gcpFilePath}`
      };
    }
  }, "handler")
}), T = i({
  args: {
    gcpFilePath: t.string(),
    expirationMinutes: t.optional(t.number())
  },
  returns: t.object({
    downloadUrl: t.string(),
    expiresAt: t.number()
  }),
  handler: /* @__PURE__ */ l(async (p, o) => {
    try {
      let e = process.env.GOOGLE_CLOUD_PROJECT_ID, n = process.env.GCS_BUCKET_NAME, r = process.env.GCS_CLIENT_EMAIL, s = process.env.GCS_PRIVATE_KEY_BASE64;
      if (!e || !n || !r || !s)
        throw new Error("GCS\u74B0\u5883\u5909\u6570\u304C\u8A2D\u5B9A\u3055\u308C\u3066\u3044\u307E\u305B\u3093");
      let { Storage: a } = await import("./_deps/node/57Z7VQNY.js"), c = Buffer.from(s, "base64").toString("utf-8"), u = {
        type: "service_account",
        project_id: e,
        private_key: c,
        client_email: r,
        auth_uri: "https://accounts.google.com/o/oauth2/auth",
        token_uri: "https://oauth2.googleapis.com/token",
        auth_provider_x509_cert_url: "https://www.googleapis.com/oauth2/v1/certs",
        client_x509_cert_url: `https://www.googleapis.com/robot/v1/metadata/x509/${encodeURIComponent(r)}`,
        universe_domain: "googleapis.com"
      }, d = new a({
        projectId: e,
        credentials: u
      }).bucket(n).file(o.gcpFilePath), [U] = await d.exists();
      if (!U)
        throw new Error(`\u30D5\u30A1\u30A4\u30EB\u304C\u5B58\u5728\u3057\u307E\u305B\u3093: ${o.gcpFilePath}`);
      let P = o.expirationMinutes || 7 * 24 * 60, _ = Date.now() + P * 60 * 1e3;
      console.log("[generateGCPDownloadUrl] Generating download URL:", {
        gcpFilePath: o.gcpFilePath,
        expirationMinutes: P,
        expiresAt: new Date(_).toISOString()
      });
      let [m] = await d.getSignedUrl({
        version: "v4",
        action: "read",
        expires: _
      });
      return console.log("[generateGCPDownloadUrl] Generated download URL:", m), {
        downloadUrl: m,
        expiresAt: _
      };
    } catch (e) {
      throw console.error("[generateGCPDownloadUrl] \u30A8\u30E9\u30FC:", e), new Error(
        `GCS\u30C0\u30A6\u30F3\u30ED\u30FC\u30C9URL\u751F\u6210\u306B\u5931\u6557\u3057\u307E\u3057\u305F: ${e instanceof Error ? e.message : "\u4E0D\u660E\u306A\u30A8\u30E9\u30FC"}`
      );
    }
  }, "handler")
}), k = i({
  args: {},
  returns: t.object({
    success: t.boolean(),
    message: t.string()
  }),
  handler: /* @__PURE__ */ l(async (p) => {
    try {
      let o = process.env.GOOGLE_CLOUD_PROJECT_ID, e = process.env.GCS_BUCKET_NAME, n = process.env.GCS_CLIENT_EMAIL, r = process.env.GCS_PRIVATE_KEY_BASE64;
      if (!o || !e || !n || !r)
        return {
          success: !1,
          message: "GCS\u74B0\u5883\u5909\u6570\u304C\u8A2D\u5B9A\u3055\u308C\u3066\u3044\u307E\u305B\u3093"
        };
      let { Storage: s } = await import("./_deps/node/57Z7VQNY.js"), a = Buffer.from(r, "base64").toString("utf-8"), c = {
        type: "service_account",
        project_id: o,
        private_key: a,
        client_email: n,
        auth_uri: "https://accounts.google.com/o/oauth2/auth",
        token_uri: "https://oauth2.googleapis.com/token",
        auth_provider_x509_cert_url: "https://www.googleapis.com/oauth2/v1/certs",
        client_x509_cert_url: `https://www.googleapis.com/robot/v1/metadata/x509/${encodeURIComponent(n)}`,
        universe_domain: "googleapis.com"
      }, g = new s({
        projectId: o,
        credentials: c
      }).bucket(e), [h] = await g.exists();
      return h ? {
        success: !0,
        message: "GCS\u63A5\u7D9A\u6210\u529F"
      } : {
        success: !1,
        message: `\u30D0\u30B1\u30C3\u30C8\u304C\u5B58\u5728\u3057\u307E\u305B\u3093: ${e}`
      };
    } catch (o) {
      return {
        success: !1,
        message: `GCS\u63A5\u7D9A\u30A8\u30E9\u30FC: ${o instanceof Error ? o.message : "\u4E0D\u660E\u306A\u30A8\u30E9\u30FC"}`
      };
    }
  }, "handler")
});
export {
  G as deleteGCSFile,
  F as fetchGCPFile,
  w as fetchGCPFileAsUrl,
  v as generateElevenLabsReadUrl,
  T as generateGCPDownloadUrl,
  f as generateGCPReadUrl,
  y as generateGCPUploadUrl,
  L as generateReadUrlForExistingFile,
  x as makeFilePrivate,
  E as makeFilePublic,
  R as makeFileTemporarilyPublic,
  k as testGCSConnection,
  S as uploadFileToGCS
};
//# sourceMappingURL=gcsActions.js.map
