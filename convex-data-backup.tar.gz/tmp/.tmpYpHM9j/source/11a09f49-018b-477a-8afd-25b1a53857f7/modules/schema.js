var pe = Object.defineProperty;
var i = (t, r) => pe(t, "name", { value: r, configurable: !0 });

// node_modules/convex/dist/esm/values/base64.js
var g = [], m = [], ce = Uint8Array, L = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
for (b = 0, ee = L.length; b < ee; ++b)
  g[b] = L[b], m[L.charCodeAt(b)] = b;
var b, ee;
m[45] = 62;
m[95] = 63;
function _e(t) {
  var r = t.length;
  if (r % 4 > 0)
    throw new Error("Invalid string. Length must be a multiple of 4");
  var n = t.indexOf("=");
  n === -1 && (n = r);
  var a = n === r ? 0 : 4 - n % 4;
  return [n, a];
}
i(_e, "getLens");
function me(t, r, n) {
  return (r + n) * 3 / 4 - n;
}
i(me, "_byteLength");
function H(t) {
  var r, n = _e(t), a = n[0], l = n[1], u = new ce(me(t, a, l)), s = 0, _ = l > 0 ? a - 4 : a, p;
  for (p = 0; p < _; p += 4)
    r = m[t.charCodeAt(p)] << 18 | m[t.charCodeAt(p + 1)] << 12 | m[t.charCodeAt(p + 2)] << 6 | m[t.charCodeAt(p + 3)], u[s++] = r >> 16 & 255, u[s++] = r >> 8 & 255, u[s++] = r & 255;
  return l === 2 && (r = m[t.charCodeAt(p)] << 2 | m[t.charCodeAt(p + 1)] >> 4, u[s++] = r & 255), l === 1 && (r = m[t.charCodeAt(p)] << 10 | m[t.charCodeAt(p + 1)] << 4 | m[t.charCodeAt(p + 2)] >> 2, u[s++] = r >> 8 & 255, u[s++] = r & 255), u;
}
i(H, "toByteArray");
function ge(t) {
  return g[t >> 18 & 63] + g[t >> 12 & 63] + g[t >> 6 & 63] + g[t & 63];
}
i(ge, "tripletToBase64");
function fe(t, r, n) {
  for (var a, l = [], u = r; u < n; u += 3)
    a = (t[u] << 16 & 16711680) + (t[u + 1] << 8 & 65280) + (t[u + 2] & 255), l.push(ge(a));
  return l.join("");
}
i(fe, "encodeChunk");
function S(t) {
  for (var r, n = t.length, a = n % 3, l = [], u = 16383, s = 0, _ = n - a; s < _; s += u)
    l.push(
      fe(
        t,
        s,
        s + u > _ ? _ : s + u
      )
    );
  return a === 1 ? (r = t[n - 1], l.push(g[r >> 2] + g[r << 4 & 63] + "==")) : a === 2 && (r = (t[n - 2] << 8) + t[n - 1], l.push(
    g[r >> 10] + g[r >> 4 & 63] + g[r << 2 & 63] + "="
  )), l.join("");
}
i(S, "fromByteArray");

// node_modules/convex/dist/esm/common/index.js
function re(t) {
  let r = typeof t == "object", n = Object.getPrototypeOf(t), a = n === null || n === Object.prototype || // Objects generated from other contexts (e.g. across Node.js `vm` modules) will not satisfy the previous
  // conditions but are still simple objects.
  n?.constructor?.name === "Object";
  return r && a;
}
i(re, "isSimpleObject");

// node_modules/convex/dist/esm/values/value.js
var ye = !0, w = BigInt("-9223372036854775808"), D = BigInt("9223372036854775807"), Q = BigInt("0"), be = BigInt("8"), he = BigInt("256");
function xe(t) {
  return Number.isNaN(t) || !Number.isFinite(t) || Object.is(t, -0);
}
i(xe, "isSpecial");
function we(t) {
  t < Q && (t -= w + w);
  let r = t.toString(16);
  r.length % 2 === 1 && (r = "0" + r);
  let n = new Uint8Array(new ArrayBuffer(8)), a = 0;
  for (let l of r.match(/.{2}/g).reverse())
    n.set([parseInt(l, 16)], a++), t >>= be;
  return S(n);
}
i(we, "slowBigIntToBase64");
function ve(t) {
  let r = H(t);
  if (r.byteLength !== 8)
    throw new Error(
      `Received ${r.byteLength} bytes, expected 8 for $integer`
    );
  let n = Q, a = Q;
  for (let l of r)
    n += BigInt(l) * he ** a, a++;
  return n > D && (n += w + w), n;
}
i(ve, "slowBase64ToBigInt");
function Ae(t) {
  if (t < w || D < t)
    throw new Error(
      `BigInt ${t} does not fit into a 64-bit signed integer.`
    );
  let r = new ArrayBuffer(8);
  return new DataView(r).setBigInt64(0, t, !0), S(new Uint8Array(r));
}
i(Ae, "modernBigIntToBase64");
function Se(t) {
  let r = H(t);
  if (r.byteLength !== 8)
    throw new Error(
      `Received ${r.byteLength} bytes, expected 8 for $integer`
    );
  return new DataView(r.buffer).getBigInt64(0, !0);
}
i(Se, "modernBase64ToBigInt");
var Te = DataView.prototype.setBigInt64 ? Ae : we, Ke = DataView.prototype.getBigInt64 ? Se : ve, ne = 1024;
function ie(t) {
  if (t.length > ne)
    throw new Error(
      `Field name ${t} exceeds maximum field name length ${ne}.`
    );
  if (t.startsWith("$"))
    throw new Error(`Field name ${t} starts with a '$', which is reserved.`);
  for (let r = 0; r < t.length; r += 1) {
    let n = t.charCodeAt(r);
    if (n < 32 || n >= 127)
      throw new Error(
        `Field name ${t} has invalid character '${t[r]}': Field names can only contain non-control ASCII characters`
      );
  }
}
i(ie, "validateObjectField");
function h(t) {
  return JSON.stringify(t, (r, n) => n === void 0 ? "undefined" : typeof n == "bigint" ? `${n.toString()}n` : n);
}
i(h, "stringifyValueForError");
function O(t, r, n, a) {
  if (t === void 0) {
    let s = n && ` (present at path ${n} in original object ${h(
      r
    )})`;
    throw new Error(
      `undefined is not a valid Convex value${s}. To learn about Convex's supported types, see https://docs.convex.dev/using/types.`
    );
  }
  if (t === null)
    return t;
  if (typeof t == "bigint") {
    if (t < w || D < t)
      throw new Error(
        `BigInt ${t} does not fit into a 64-bit signed integer.`
      );
    return { $integer: Te(t) };
  }
  if (typeof t == "number")
    if (xe(t)) {
      let s = new ArrayBuffer(8);
      return new DataView(s).setFloat64(0, t, ye), { $float: S(new Uint8Array(s)) };
    } else
      return t;
  if (typeof t == "boolean" || typeof t == "string")
    return t;
  if (t instanceof ArrayBuffer)
    return { $bytes: S(new Uint8Array(t)) };
  if (Array.isArray(t))
    return t.map(
      (s, _) => O(s, r, n + `[${_}]`, !1)
    );
  if (t instanceof Set)
    throw new Error(
      V(n, "Set", [...t], r)
    );
  if (t instanceof Map)
    throw new Error(
      V(n, "Map", [...t], r)
    );
  if (!re(t)) {
    let s = t?.constructor?.name, _ = s ? `${s} ` : "";
    throw new Error(
      V(n, _, t, r)
    );
  }
  let l = {}, u = Object.entries(t);
  u.sort(([s, _], [p, He]) => s === p ? 0 : s < p ? -1 : 1);
  for (let [s, _] of u)
    _ !== void 0 ? (ie(s), l[s] = O(_, r, n + `.${s}`, !1)) : a && (ie(s), l[s] = Ie(
      _,
      r,
      n + `.${s}`
    ));
  return l;
}
i(O, "convexToJsonInternal");
function V(t, r, n, a) {
  return t ? `${r}${h(
    n
  )} is not a supported Convex type (present at path ${t} in original object ${h(
    a
  )}). To learn about Convex's supported types, see https://docs.convex.dev/using/types.` : `${r}${h(
    n
  )} is not a supported Convex type.`;
}
i(V, "errorMessageForUnsupportedType");
function Ie(t, r, n) {
  if (t === void 0)
    return { $undefined: null };
  if (r === void 0)
    throw new Error(
      `Programming error. Current value is ${h(
        t
      )} but original value is undefined`
    );
  return O(t, r, n, !1);
}
i(Ie, "convexOrUndefinedToJsonInternal");
function f(t) {
  return O(t, t, "", !1);
}
i(f, "convexToJson");

// node_modules/convex/dist/esm/values/validators.js
var Ce = Object.defineProperty, Ee = /* @__PURE__ */ i((t, r, n) => r in t ? Ce(t, r, { enumerable: !0, configurable: !0, writable: !0, value: n }) : t[r] = n, "__defNormalProp"), d = /* @__PURE__ */ i((t, r, n) => Ee(t, typeof r != "symbol" ? r + "" : r, n), "__publicField"), c = class {
  static {
    i(this, "BaseValidator");
  }
  constructor({ isOptional: r }) {
    d(this, "type"), d(this, "fieldPaths"), d(this, "isOptional"), d(this, "isConvexValidator"), this.isOptional = r, this.isConvexValidator = !0;
  }
  /** @deprecated - use isOptional instead */
  get optional() {
    return this.isOptional === "optional";
  }
}, N = class t extends c {
  static {
    i(this, "VId");
  }
  /**
   * Usually you'd use `v.id(tableName)` instead.
   */
  constructor({
    isOptional: r,
    tableName: n
  }) {
    super({ isOptional: r }), d(this, "tableName"), d(this, "kind", "id"), this.tableName = n;
  }
  /** @internal */
  get json() {
    return { type: "id", tableName: this.tableName };
  }
  /** @internal */
  asOptional() {
    return new t({
      isOptional: "optional",
      tableName: this.tableName
    });
  }
}, T = class t extends c {
  static {
    i(this, "VFloat64");
  }
  constructor() {
    super(...arguments), d(this, "kind", "float64");
  }
  /** @internal */
  get json() {
    return { type: "number" };
  }
  /** @internal */
  asOptional() {
    return new t({
      isOptional: "optional"
    });
  }
}, I = class t extends c {
  static {
    i(this, "VInt64");
  }
  constructor() {
    super(...arguments), d(this, "kind", "int64");
  }
  /** @internal */
  get json() {
    return { type: "bigint" };
  }
  /** @internal */
  asOptional() {
    return new t({ isOptional: "optional" });
  }
}, $ = class t extends c {
  static {
    i(this, "VBoolean");
  }
  constructor() {
    super(...arguments), d(this, "kind", "boolean");
  }
  /** @internal */
  get json() {
    return { type: this.kind };
  }
  /** @internal */
  asOptional() {
    return new t({
      isOptional: "optional"
    });
  }
}, P = class t extends c {
  static {
    i(this, "VBytes");
  }
  constructor() {
    super(...arguments), d(this, "kind", "bytes");
  }
  /** @internal */
  get json() {
    return { type: this.kind };
  }
  /** @internal */
  asOptional() {
    return new t({ isOptional: "optional" });
  }
}, q = class t extends c {
  static {
    i(this, "VString");
  }
  constructor() {
    super(...arguments), d(this, "kind", "string");
  }
  /** @internal */
  get json() {
    return { type: this.kind };
  }
  /** @internal */
  asOptional() {
    return new t({
      isOptional: "optional"
    });
  }
}, j = class t extends c {
  static {
    i(this, "VNull");
  }
  constructor() {
    super(...arguments), d(this, "kind", "null");
  }
  /** @internal */
  get json() {
    return { type: this.kind };
  }
  /** @internal */
  asOptional() {
    return new t({ isOptional: "optional" });
  }
}, k = class t extends c {
  static {
    i(this, "VAny");
  }
  constructor() {
    super(...arguments), d(this, "kind", "any");
  }
  /** @internal */
  get json() {
    return {
      type: this.kind
    };
  }
  /** @internal */
  asOptional() {
    return new t({
      isOptional: "optional"
    });
  }
}, B = class t extends c {
  static {
    i(this, "VObject");
  }
  /**
   * Usually you'd use `v.object({ ... })` instead.
   */
  constructor({
    isOptional: r,
    fields: n
  }) {
    super({ isOptional: r }), d(this, "fields"), d(this, "kind", "object"), this.fields = n;
  }
  /** @internal */
  get json() {
    return {
      type: this.kind,
      value: globalThis.Object.fromEntries(
        globalThis.Object.entries(this.fields).map(([r, n]) => [
          r,
          {
            fieldType: n.json,
            optional: n.isOptional === "optional"
          }
        ])
      )
    };
  }
  /** @internal */
  asOptional() {
    return new t({
      isOptional: "optional",
      fields: this.fields
    });
  }
}, F = class t extends c {
  static {
    i(this, "VLiteral");
  }
  /**
   * Usually you'd use `v.literal(value)` instead.
   */
  constructor({ isOptional: r, value: n }) {
    super({ isOptional: r }), d(this, "value"), d(this, "kind", "literal"), this.value = n;
  }
  /** @internal */
  get json() {
    return {
      type: this.kind,
      value: f(this.value)
    };
  }
  /** @internal */
  asOptional() {
    return new t({
      isOptional: "optional",
      value: this.value
    });
  }
}, R = class t extends c {
  static {
    i(this, "VArray");
  }
  /**
   * Usually you'd use `v.array(element)` instead.
   */
  constructor({
    isOptional: r,
    element: n
  }) {
    super({ isOptional: r }), d(this, "element"), d(this, "kind", "array"), this.element = n;
  }
  /** @internal */
  get json() {
    return {
      type: this.kind,
      value: this.element.json
    };
  }
  /** @internal */
  asOptional() {
    return new t({
      isOptional: "optional",
      element: this.element
    });
  }
}, U = class t extends c {
  static {
    i(this, "VRecord");
  }
  /**
   * Usually you'd use `v.record(key, value)` instead.
   */
  constructor({
    isOptional: r,
    key: n,
    value: a
  }) {
    if (super({ isOptional: r }), d(this, "key"), d(this, "value"), d(this, "kind", "record"), n.isOptional === "optional")
      throw new Error("Record validator cannot have optional keys");
    if (a.isOptional === "optional")
      throw new Error("Record validator cannot have optional values");
    this.key = n, this.value = a;
  }
  /** @internal */
  get json() {
    return {
      type: this.kind,
      // This cast is needed because TypeScript thinks the key type is too wide
      keys: this.key.json,
      values: {
        fieldType: this.value.json,
        optional: !1
      }
    };
  }
  /** @internal */
  asOptional() {
    return new t({
      isOptional: "optional",
      key: this.key,
      value: this.value
    });
  }
}, M = class t extends c {
  static {
    i(this, "VUnion");
  }
  /**
   * Usually you'd use `v.union(...members)` instead.
   */
  constructor({ isOptional: r, members: n }) {
    super({ isOptional: r }), d(this, "members"), d(this, "kind", "union"), this.members = n;
  }
  /** @internal */
  get json() {
    return {
      type: this.kind,
      value: this.members.map((r) => r.json)
    };
  }
  /** @internal */
  asOptional() {
    return new t({
      isOptional: "optional",
      members: this.members
    });
  }
};

// node_modules/convex/dist/esm/values/validator.js
function oe(t) {
  return !!t.isConvexValidator;
}
i(oe, "isValidator");
var e = {
  /**
   * Validates that the value corresponds to an ID of a document in given table.
   * @param tableName The name of the table.
   */
  id: /* @__PURE__ */ i((t) => new N({
    isOptional: "required",
    tableName: t
  }), "id"),
  /**
   * Validates that the value is of type Null.
   */
  null: /* @__PURE__ */ i(() => new j({ isOptional: "required" }), "null"),
  /**
   * Validates that the value is of Convex type Float64 (Number in JS).
   *
   * Alias for `v.float64()`
   */
  number: /* @__PURE__ */ i(() => new T({ isOptional: "required" }), "number"),
  /**
   * Validates that the value is of Convex type Float64 (Number in JS).
   */
  float64: /* @__PURE__ */ i(() => new T({ isOptional: "required" }), "float64"),
  /**
   * @deprecated Use `v.int64()` instead
   */
  bigint: /* @__PURE__ */ i(() => new I({ isOptional: "required" }), "bigint"),
  /**
   * Validates that the value is of Convex type Int64 (BigInt in JS).
   */
  int64: /* @__PURE__ */ i(() => new I({ isOptional: "required" }), "int64"),
  /**
   * Validates that the value is of type Boolean.
   */
  boolean: /* @__PURE__ */ i(() => new $({ isOptional: "required" }), "boolean"),
  /**
   * Validates that the value is of type String.
   */
  string: /* @__PURE__ */ i(() => new q({ isOptional: "required" }), "string"),
  /**
   * Validates that the value is of Convex type Bytes (constructed in JS via `ArrayBuffer`).
   */
  bytes: /* @__PURE__ */ i(() => new P({ isOptional: "required" }), "bytes"),
  /**
   * Validates that the value is equal to the given literal value.
   * @param literal The literal value to compare against.
   */
  literal: /* @__PURE__ */ i((t) => new F({ isOptional: "required", value: t }), "literal"),
  /**
   * Validates that the value is an Array of the given element type.
   * @param element The validator for the elements of the array.
   */
  array: /* @__PURE__ */ i((t) => new R({ isOptional: "required", element: t }), "array"),
  /**
   * Validates that the value is an Object with the given properties.
   * @param fields An object specifying the validator for each property.
   */
  object: /* @__PURE__ */ i((t) => new B({ isOptional: "required", fields: t }), "object"),
  /**
   * Validates that the value is a Record with keys and values that match the given types.
   * @param keys The validator for the keys of the record. This cannot contain string literals.
   * @param values The validator for the values of the record.
   */
  record: /* @__PURE__ */ i((t, r) => new U({
    isOptional: "required",
    key: t,
    value: r
  }), "record"),
  /**
   * Validates that the value matches one of the given validators.
   * @param members The validators to match against.
   */
  union: /* @__PURE__ */ i((...t) => new M({
    isOptional: "required",
    members: t
  }), "union"),
  /**
   * Does not validate the value.
   */
  any: /* @__PURE__ */ i(() => new k({ isOptional: "required" }), "any"),
  /**
   * Allows not specifying a value for a property in an Object.
   * @param value The property value validator to make optional.
   *
   * ```typescript
   * const objectWithOptionalFields = v.object({
   *   requiredField: v.string(),
   *   optionalField: v.optional(v.string()),
   * });
   * ```
   */
  optional: /* @__PURE__ */ i((t) => t.asOptional(), "optional")
};

// node_modules/convex/dist/esm/values/errors.js
var Oe = Object.defineProperty, Ne = /* @__PURE__ */ i((t, r, n) => r in t ? Oe(t, r, { enumerable: !0, configurable: !0, writable: !0, value: n }) : t[r] = n, "__defNormalProp"), G = /* @__PURE__ */ i((t, r, n) => Ne(t, typeof r != "symbol" ? r + "" : r, n), "__publicField"), se, ae, $e = Symbol.for("ConvexError"), W = class extends (ae = Error, se = $e, ae) {
  static {
    i(this, "ConvexError");
  }
  constructor(r) {
    super(typeof r == "string" ? r : h(r)), G(this, "name", "ConvexError"), G(this, "data"), G(this, se, !0), this.data = r;
  }
};

// node_modules/convex/dist/esm/values/compare_utf8.js
var le = /* @__PURE__ */ i(() => Array.from({ length: 4 }, () => 0), "arr"), lt = le(), ut = le();

// node_modules/convex/dist/esm/server/functionName.js
var K = Symbol.for("functionName");

// node_modules/convex/dist/esm/server/components/paths.js
var qe = Symbol.for("toReferencePath");

// node_modules/convex/dist/esm/server/pagination.js
var Nn = e.object({
  numItems: e.number(),
  cursor: e.union(e.string(), e.null()),
  endCursor: e.optional(e.union(e.string(), e.null())),
  id: e.optional(e.number()),
  maximumRowsRead: e.optional(e.number()),
  maximumBytesRead: e.optional(e.number())
});

// node_modules/convex/dist/esm/server/api.js
function ue(t = []) {
  let r = {
    get(n, a) {
      if (typeof a == "string") {
        let l = [...t, a];
        return ue(l);
      } else if (a === K) {
        if (t.length < 2) {
          let s = ["api", ...t].join(".");
          throw new Error(
            `API path is expected to be of the form \`api.moduleName.functionName\`. Found: \`${s}\``
          );
        }
        let l = t.slice(0, -1).join("/"), u = t[t.length - 1];
        return u === "default" ? l : l + ":" + u;
      } else return a === Symbol.toStringTag ? "FunctionReference" : void 0;
    }
  };
  return new Proxy({}, r);
}
i(ue, "createApi");
var Fe = ue();

// node_modules/convex/dist/esm/server/schema.js
var Ue = Object.defineProperty, Me = /* @__PURE__ */ i((t, r, n) => r in t ? Ue(t, r, { enumerable: !0, configurable: !0, writable: !0, value: n }) : t[r] = n, "__defNormalProp"), x = /* @__PURE__ */ i((t, r, n) => Me(t, typeof r != "symbol" ? r + "" : r, n), "__publicField"), z = class {
  static {
    i(this, "TableDefinition");
  }
  /**
   * @internal
   */
  constructor(r) {
    x(this, "indexes"), x(this, "searchIndexes"), x(this, "vectorIndexes"), x(this, "validator"), this.indexes = [], this.searchIndexes = [], this.vectorIndexes = [], this.validator = r;
  }
  /**
   * This API is experimental: it may change or disappear.
   *
   * Returns indexes defined on this table.
   * Intended for the advanced use cases of dynamically deciding which index to use for a query.
   * If you think you need this, please chime in on ths issue in the Convex JS GitHub repo.
   * https://github.com/get-convex/convex-js/issues/49
   */
  " indexes"() {
    return this.indexes;
  }
  /**
   * Define an index on this table.
   *
   * To learn about indexes, see [Defining Indexes](https://docs.convex.dev/using/indexes).
   *
   * @param name - The name of the index.
   * @param fields - The fields to index, in order. Must specify at least one
   * field.
   * @returns A {@link TableDefinition} with this index included.
   */
  index(r, n) {
    return this.indexes.push({ indexDescriptor: r, fields: n }), this;
  }
  /**
   * Define a search index on this table.
   *
   * To learn about search indexes, see [Search](https://docs.convex.dev/text-search).
   *
   * @param name - The name of the index.
   * @param indexConfig - The search index configuration object.
   * @returns A {@link TableDefinition} with this search index included.
   */
  searchIndex(r, n) {
    return this.searchIndexes.push({
      indexDescriptor: r,
      searchField: n.searchField,
      filterFields: n.filterFields || []
    }), this;
  }
  /**
   * Define a vector index on this table.
   *
   * To learn about vector indexes, see [Vector Search](https://docs.convex.dev/vector-search).
   *
   * @param name - The name of the index.
   * @param indexConfig - The vector index configuration object.
   * @returns A {@link TableDefinition} with this vector index included.
   */
  vectorIndex(r, n) {
    return this.vectorIndexes.push({
      indexDescriptor: r,
      vectorField: n.vectorField,
      dimensions: n.dimensions,
      filterFields: n.filterFields || []
    }), this;
  }
  /**
   * Work around for https://github.com/microsoft/TypeScript/issues/57035
   */
  self() {
    return this;
  }
  /**
   * Export the contents of this definition.
   *
   * This is called internally by the Convex framework.
   * @internal
   */
  export() {
    let r = this.validator.json;
    if (typeof r != "object")
      throw new Error(
        "Invalid validator: please make sure that the parameter of `defineTable` is valid (see https://docs.convex.dev/database/schemas)"
      );
    return {
      indexes: this.indexes,
      searchIndexes: this.searchIndexes,
      vectorIndexes: this.vectorIndexes,
      documentType: r
    };
  }
};
function o(t) {
  return oe(t) ? new z(t) : new z(e.object(t));
}
i(o, "defineTable");
var Z = class {
  static {
    i(this, "SchemaDefinition");
  }
  /**
   * @internal
   */
  constructor(r, n) {
    x(this, "tables"), x(this, "strictTableNameTypes"), x(this, "schemaValidation"), this.tables = r, this.schemaValidation = n?.schemaValidation === void 0 ? !0 : n.schemaValidation;
  }
  /**
   * Export the contents of this definition.
   *
   * This is called internally by the Convex framework.
   * @internal
   */
  export() {
    return JSON.stringify({
      tables: Object.entries(this.tables).map(([r, n]) => {
        let { indexes: a, searchIndexes: l, vectorIndexes: u, documentType: s } = n.export();
        return {
          tableName: r,
          indexes: a,
          searchIndexes: l,
          vectorIndexes: u,
          documentType: s
        };
      }),
      schemaValidation: this.schemaValidation
    });
  }
};
function J(t, r) {
  return new Z(t, r);
}
i(J, "defineSchema");
var Zn = J({
  _scheduled_functions: o({
    name: e.string(),
    args: e.array(e.any()),
    scheduledTime: e.float64(),
    completedTime: e.optional(e.float64()),
    state: e.union(
      e.object({ kind: e.literal("pending") }),
      e.object({ kind: e.literal("inProgress") }),
      e.object({ kind: e.literal("success") }),
      e.object({ kind: e.literal("failed"), error: e.string() }),
      e.object({ kind: e.literal("canceled") })
    )
  }),
  _storage: o({
    sha256: e.string(),
    size: e.float64(),
    contentType: e.optional(e.string())
  })
});

// convex/schema/notification.ts
var ze = e.union(
  e.literal("pending"),
  e.literal("sent"),
  e.literal("delivered"),
  e.literal("read"),
  e.literal("failed"),
  e.literal("cancelled")
), Je = e.union(
  e.literal("low"),
  e.literal("normal"),
  e.literal("high"),
  e.literal("urgent")
), Le = e.union(
  e.literal("queued"),
  e.literal("processing"),
  e.literal("sent"),
  e.literal("delivered"),
  e.literal("opened"),
  e.literal("clicked"),
  e.literal("bounced"),
  e.literal("failed"),
  e.literal("spam")
), de = {
  // 拡張通知設定 - 簡素化
  advancedNotificationSettings: o({
    user_id: e.id("users"),
    // 設定を単純化
    in_app_enabled: e.boolean(),
    in_app_sound: e.boolean(),
    in_app_desktop: e.boolean(),
    in_app_badge: e.boolean(),
    email_enabled: e.boolean(),
    email_frequency: e.string(),
    // "immediate", "hourly", "daily", "weekly"
    email_digest: e.boolean(),
    push_enabled: e.boolean(),
    push_device_tokens: e.optional(e.array(e.string())),
    push_quiet_hours_start: e.optional(e.string()),
    push_quiet_hours_end: e.optional(e.string()),
    push_timezone: e.optional(e.string()),
    sms_enabled: e.boolean(),
    sms_phone_number: e.optional(e.string()),
    sms_country_code: e.optional(e.string()),
    // イベント設定を単純化
    evaluations_completed: e.boolean(),
    evaluations_failed: e.boolean(),
    evaluations_overdue: e.boolean(),
    videos_uploaded: e.boolean(),
    videos_processed: e.boolean(),
    videos_shared: e.boolean(),
    training_assigned: e.boolean(),
    training_completed: e.boolean(),
    training_reminder: e.boolean(),
    system_maintenance: e.boolean(),
    system_updates: e.boolean(),
    system_security: e.boolean(),
    mentions_comments: e.boolean(),
    mentions_reviews: e.boolean(),
    mentions_messages: e.boolean()
  }).index("by_user_id", ["user_id"]),
  // 拡張通知メッセージ - 簡素化
  advancedNotifications: o({
    notification_id: e.string(),
    recipient_id: e.id("users"),
    sender_id: e.optional(e.id("users")),
    notification_type: e.string(),
    // より自由な文字列型
    priority: Je,
    status: ze,
    title: e.string(),
    message: e.string(),
    // リッチコンテンツを簡素化
    html_content: e.optional(e.string()),
    markdown_content: e.optional(e.string()),
    // メタデータを簡素化
    resource_id: e.optional(e.string()),
    resource_type: e.optional(e.string()),
    tracking_id: e.optional(e.string()),
    campaign_id: e.optional(e.string()),
    // チャンネル配信情報を単純化
    channels_json: e.optional(e.string()),
    // JSON文字列として保存
    scheduled_for: e.optional(e.number()),
    expires_at: e.optional(e.number()),
    read_at: e.optional(e.number()),
    clicked_at: e.optional(e.number()),
    dismissed_at: e.optional(e.number())
  }).index("by_recipient", ["recipient_id"]).index("by_sender", ["sender_id"]).index("by_type", ["notification_type"]).index("by_priority", ["priority"]).index("by_status", ["status"]).index("by_scheduled", ["scheduled_for"]).index("by_read_status", ["recipient_id", "read_at"]),
  // 通知テンプレート - 簡素化
  notificationTemplates: o({
    template_id: e.string(),
    name: e.string(),
    description: e.optional(e.string()),
    notification_type: e.string(),
    channels: e.array(e.string()),
    // 文字列配列として簡素化
    // テンプレートを単純化
    in_app_template: e.optional(e.string()),
    // JSON文字列
    email_template: e.optional(e.string()),
    // JSON文字列
    push_template: e.optional(e.string()),
    // JSON文字列
    sms_template: e.optional(e.string()),
    // JSON文字列
    variables_json: e.optional(e.string()),
    // JSON文字列
    localization_json: e.optional(e.string()),
    // JSON文字列
    created_by: e.id("users"),
    version: e.string(),
    status: e.union(e.literal("draft"), e.literal("active"), e.literal("archived")),
    usage_count: e.optional(e.number()),
    last_used_at: e.optional(e.number())
  }).index("by_template_id", ["template_id"]).index("by_type", ["notification_type"]).index("by_created_by", ["created_by"]).index("by_status", ["status"]),
  // 通知購読管理 - 簡素化
  notificationSubscriptions: o({
    subscription_id: e.string(),
    user_id: e.id("users"),
    subscription_type: e.string(),
    // より自由な文字列型
    topic_id: e.optional(e.string()),
    topic_name: e.optional(e.string()),
    channels: e.array(e.string()),
    // 文字列配列として簡素化
    // フィルターを単純化
    filters_json: e.optional(e.string()),
    // JSON文字列として保存
    status: e.union(e.literal("active"), e.literal("paused"), e.literal("cancelled")),
    created_at: e.number(),
    updated_at: e.number()
  }).index("by_user_id", ["user_id"]).index("by_subscription_type", ["subscription_type"]).index("by_topic_id", ["topic_id"]).index("by_status", ["status"]),
  // 通知配信ログ - 簡素化
  notificationDeliveryLogs: o({
    log_id: e.string(),
    notification_id: e.string(),
    channel: e.string(),
    // 文字列として簡素化
    provider: e.optional(e.string()),
    recipient_id: e.id("users"),
    status: Le,
    attempt_count: e.number(),
    sent_at: e.optional(e.number()),
    delivered_at: e.optional(e.number()),
    opened_at: e.optional(e.number()),
    clicked_at: e.optional(e.number()),
    failed_at: e.optional(e.number()),
    error_code: e.optional(e.string()),
    error_message: e.optional(e.string()),
    provider_response_json: e.optional(e.string()),
    // JSON文字列
    cost: e.optional(e.number()),
    processing_time_ms: e.optional(e.number()),
    // メタデータを単純化
    device_type: e.optional(e.string()),
    client_version: e.optional(e.string()),
    user_agent: e.optional(e.string()),
    ip_address: e.optional(e.string())
  }).index("by_notification_id", ["notification_id"]).index("by_channel", ["channel"]).index("by_recipient_id", ["recipient_id"]).index("by_status", ["status"]),
  // 通知統計 - 簡素化
  notificationStats: o({
    stat_id: e.string(),
    period_type: e.union(
      e.literal("hour"),
      e.literal("day"),
      e.literal("week"),
      e.literal("month")
    ),
    period_start: e.number(),
    period_end: e.number(),
    // 基本統計
    total_sent: e.number(),
    total_delivered: e.number(),
    total_opened: e.number(),
    total_clicked: e.number(),
    total_failed: e.number(),
    delivery_rate: e.number(),
    open_rate: e.number(),
    click_rate: e.number(),
    avg_delivery_time_ms: e.number(),
    // 詳細統計をJSON文字列として保存
    by_channel_json: e.optional(e.string()),
    by_type_json: e.optional(e.string()),
    cost_metrics_json: e.optional(e.string())
  }).index("by_period", ["period_type", "period_start"]).index("by_period_start", ["period_start"])
};

// convex/schema.ts
var Ui = J({
  // 統一ユーザーテーブル（Clerk認証ベース）
  users: o({
    // Clerk認証情報
    clerkUserId: e.string(),
    // Clerkの固有ID
    tokenIdentifier: e.string(),
    // ClerkのJWTの `sub` (subject) claim
    email: e.string(),
    emailVerified: e.boolean(),
    // ユーザープロフィール
    name: e.string(),
    firstName: e.optional(e.string()),
    lastName: e.optional(e.string()),
    imageUrl: e.optional(e.string()),
    // 企業関連情報
    employeeId: e.optional(e.string()),
    department: e.optional(e.string()),
    position: e.optional(e.string()),
    role: e.string(),
    // 'admin', 'trainer', 'employee'
    managerId: e.optional(e.id("users")),
    // 上長のユーザーID（自己参照）
    // アカウント管理
    isActive: e.boolean(),
    joinDate: e.number(),
    lastLoginAt: e.optional(e.number())
    // Removed migration fields: migratedFromBetterAuth, migrationDate, legacyUserId
    // Phase 2 cleanup completed - these fields were safely removed as migration is complete
  }).index("by_clerk_user_id", ["clerkUserId"]).index("by_token", ["tokenIdentifier"]).index("by_email", ["email"]).index("by_employee_id", ["employeeId"]).index("by_department", ["department"]).index("by_role", ["role"]).index("by_is_active", ["isActive"]).index("by_manager_id", ["managerId"]),
  // 従来システム（段階的廃止予定）
  // PHASE 3 COMPLETED: legacy_users table safely deleted
  // All legacy user data migrated to unified 'users' table
  // Migration completed: Authentication system fully unified
  // Clerkセッション管理（統一）
  userSessions: o({
    user_id: e.id("users"),
    // 統一ユーザーテーブル参照
    clerk_session_id: e.string(),
    device_info: e.optional(e.string()),
    ip_address: e.optional(e.string()),
    user_agent: e.optional(e.string()),
    expires_at: e.number(),
    last_activity_at: e.number(),
    is_active: e.boolean()
  }).index("by_user_id", ["user_id"]).index("by_clerk_session_id", ["clerk_session_id"]).index("by_is_active", ["is_active"]),
  // パスキー認証情報（Clerk統合準備）
  // PHASE 1 COMPLETED: passkeyCredentials table safely deleted
  // All passkey authentication now handled through Clerk
  // Migration completed: Authentication system fully unified
  // --- Better Auth Tables (DEPRECATED - 段階的廃止予定) ---
  // PHASE 3 COMPLETED: better_auth_users table safely deleted
  // All references migrated to unified 'users' table
  // Migration completed: All active functionality now uses unified authentication
  // --- 移行管理テーブル ---
  // PHASE 1 COMPLETED: userMigrationLog table safely deleted
  // All migration tracking completed and archived
  // Migration completed: Historical migration logs no longer needed
  // PHASE 3 COMPLETED: userMapping table safely deleted
  // User mapping functionality was unused as auth migration completed
  // Migration completed: User mapping system removed
  trainings: o({
    title: e.string(),
    description: e.optional(e.string()),
    category: e.optional(e.string()),
    duration_minutes: e.optional(e.number()),
    thumbnail_url: e.optional(e.string()),
    priority: e.optional(e.string())
  }),
  // 新しいコース管理システム
  courses: o({
    title: e.string(),
    description: e.string(),
    category: e.string(),
    duration_minutes: e.number(),
    thumbnail_url: e.optional(e.string()),
    is_published: e.boolean(),
    created_by: e.id("users"),
    modules_count: e.number()
  }).index("by_title", ["title"]).index("by_category", ["category"]).index("by_creator", ["created_by"]).index("by_published", ["is_published"]).index("by_category_published", ["category", "is_published"]),
  modules: o({
    course_id: e.id("courses"),
    title: e.string(),
    description: e.string(),
    duration_minutes: e.number(),
    order_index: e.number(),
    content_type: e.string(),
    // "video", "text", "quiz", etc.
    content_url: e.optional(e.string()),
    is_published: e.boolean()
  }).index("by_course", ["course_id"]).index("by_course_order", ["course_id", "order_index"]).index("by_content_type", ["content_type"]),
  trainingModules: o({
    training_id: e.id("trainings"),
    title: e.string(),
    description: e.optional(e.string()),
    duration_minutes: e.optional(e.number()),
    order_index: e.number(),
    quiz_generation_status: e.optional(e.string()),
    quiz_generation_started_at: e.optional(e.number()),
    quiz_generation_completed_at: e.optional(e.number()),
    quiz_generation_error: e.optional(e.string()),
    // Phase2統合用フィールド（trainingModules+moduleContentsマージ）
    content: e.optional(e.string()),
    content_type: e.optional(e.string()),
    file_url: e.optional(e.string()),
    file_type: e.optional(e.string()),
    merged_from_content: e.optional(e.string()),
    // 統合元moduleContentのID
    merge_type: e.optional(e.string()),
    // "1to1", "1toN_main", "1toN_child"
    merge_timestamp: e.optional(e.number()),
    // 階層管理フィールド
    parent_module_id: e.optional(e.id("trainingModules")),
    child_modules_count: e.optional(e.number()),
    original_order_index: e.optional(e.number())
  }).index("by_training_id", ["training_id"]).index("by_parent_module", ["parent_module_id"]),
  moduleContents: o({
    module_id: e.id("trainingModules"),
    title: e.string(),
    content: e.optional(e.string()),
    content_type: e.string(),
    file_url: e.optional(e.string()),
    file_type: e.optional(e.string()),
    order_index: e.number()
  }).index("by_module_id", ["module_id"]),
  trainingProgress: o({
    user_id: e.id("users"),
    training_id: e.id("trainings"),
    module_id: e.optional(e.id("trainingModules")),
    status: e.union(
      e.literal("not_started"),
      e.literal("in_progress"),
      e.literal("completed"),
      e.literal("paused")
    ),
    progress_percentage: e.number(),
    started_at: e.optional(e.number()),
    completed_at: e.optional(e.number())
    // Removed migration field: new_user_id (Phase 2 cleanup - migration complete)
  }).index("by_user_training", ["user_id", "training_id"]).index("by_user_module", ["user_id", "module_id"]),
  videos: o({
    user_id: e.id("users"),
    title: e.string(),
    description: e.optional(e.string()),
    type: e.optional(e.string()),
    url: e.string(),
    thumbnail_url: e.optional(e.string()),
    duration_seconds: e.optional(e.number()),
    // ラベル機能
    labels: e.optional(e.array(e.string())),
    // 面談者情報
    intervieweeName: e.optional(e.string()),
    // 面談者名
    // アップロード関連フィールド
    file_size: e.optional(e.number()),
    content_type: e.optional(e.string()),
    processing_status: e.optional(
      e.union(
        e.literal("pending"),
        e.literal("processing"),
        e.literal("completed"),
        e.literal("failed")
      )
    ),
    error_message: e.optional(e.string()),
    // Convexストレージ関連フィールド
    storage_id: e.optional(e.id("_storage")),
    // GCS関連フィールド
    gcs_file_path: e.optional(e.string()),
    file_upload_id: e.optional(e.id("fileUploads")),
    // ファイルグループ機能
    upload_session_id: e.optional(e.string()),
    // 同一セッションでアップロードされたファイルをグループ化
    is_group_primary: e.optional(e.boolean()),
    // グループの代表ファイル
    // Phase2統合用フィールド（videos+fileUploadsマージ）
    original_filename: e.optional(e.string()),
    view_count: e.optional(e.number()),
    resolution: e.optional(e.string()),
    quality_score: e.optional(e.number()),
    uploaded_at: e.optional(e.number()),
    completed_at: e.optional(e.number()),
    merged_from_file_upload: e.optional(e.string()),
    // 統合元fileUploadのID
    merge_timestamp: e.optional(e.number()),
    group_order: e.optional(e.number())
    // グループ内での順序
    // Removed migration field: new_user_id (Phase 2 cleanup - migration complete)
  }).index("by_user_id", ["user_id"]).index("by_processing_status", ["processing_status"]).index("by_type", ["type"]).index("by_upload_session", ["upload_session_id"]).index("by_user_and_session", ["user_id", "upload_session_id"]).index("by_session_and_primary", ["upload_session_id", "is_group_primary"]).searchIndex("search_title", {
    searchField: "title",
    filterFields: ["type", "user_id"]
  }).searchIndex("search_description", {
    searchField: "description",
    filterFields: ["type", "user_id"]
  }),
  // PHASE 1 COMPLETED: userIdMapping table safely deleted
  // All user ID mapping completed and archived
  // Migration completed: User mapping no longer needed
  evaluations: o({
    transcription_id: e.id("transcriptions"),
    video_id: e.optional(e.id("videos")),
    user_id: e.id("users"),
    // Updated from better_auth_users to users (migration complete)
    external_id: e.optional(e.string()),
    // 外部ID（UUID）
    video_type: e.union(
      e.literal("M&A\u30ED\u30FC\u30EB\u30D7\u30EC\u30A4"),
      e.literal("\u521D\u56DE\u9762\u8AC7"),
      e.literal("AD\u7DE0\u7D50\u63D0\u6848"),
      e.literal("AD\u7DE0\u7D50\u63D0\u6848"),
      e.literal("\u4F01\u696D\u6982\u8981\u66F8\u63D0\u6848"),
      e.literal("\u8B72\u6E21\u67B6\u96FB")
    ),
    status: e.union(
      e.literal("pending"),
      e.literal("processing"),
      e.literal("completed"),
      e.literal("failed")
    ),
    scores: e.optional(e.record(e.string(), e.number())),
    // 型安全なスコア
    total_score: e.optional(e.number()),
    // 総合スコア（0-100）
    comments: e.optional(e.string()),
    // 初回面談評価項目
    hearingAbility: e.optional(e.number()),
    hearingAbility_analysis: e.optional(e.string()),
    hearingAbility_strength: e.optional(e.string()),
    hearingAbility_weakness: e.optional(e.string()),
    problemSetting: e.optional(e.number()),
    problemSetting_analysis: e.optional(e.string()),
    problemSetting_strength: e.optional(e.string()),
    problemSetting_weakness: e.optional(e.string()),
    knowledge: e.optional(e.number()),
    knowledge_analysis: e.optional(e.string()),
    knowledge_strength: e.optional(e.string()),
    knowledge_weakness: e.optional(e.string()),
    negotiation: e.optional(e.number()),
    negotiation_analysis: e.optional(e.string()),
    negotiation_strength: e.optional(e.string()),
    negotiation_weakness: e.optional(e.string()),
    businessManners: e.optional(e.number()),
    businessManners_analysis: e.optional(e.string()),
    businessManners_strength: e.optional(e.string()),
    businessManners_weakness: e.optional(e.string()),
    // AD締結提案評価項目
    adHearingAbility: e.optional(e.number()),
    adHearingAbility_analysis: e.optional(e.string()),
    adHearingAbility_strength: e.optional(e.string()),
    adHearingAbility_weakness: e.optional(e.string()),
    adKnowledge: e.optional(e.number()),
    adKnowledge_analysis: e.optional(e.string()),
    adKnowledge_strength: e.optional(e.string()),
    adKnowledge_weakness: e.optional(e.string()),
    adProposalAbility: e.optional(e.number()),
    adProposalAbility_analysis: e.optional(e.string()),
    adProposalAbility_strength: e.optional(e.string()),
    adProposalAbility_weakness: e.optional(e.string()),
    adNegotiation: e.optional(e.number()),
    adNegotiation_analysis: e.optional(e.string()),
    adNegotiation_strength: e.optional(e.string()),
    adNegotiation_weakness: e.optional(e.string()),
    adRelationshipBuilding: e.optional(e.number()),
    adRelationshipBuilding_analysis: e.optional(e.string()),
    adRelationshipBuilding_strength: e.optional(e.string()),
    adRelationshipBuilding_weakness: e.optional(e.string()),
    // 企業概要書(IM)提案評価項目
    imNeedsHearingProposal: e.optional(e.number()),
    imNeedsHearingProposal_analysis: e.optional(e.string()),
    imNeedsHearingProposal_strength: e.optional(e.string()),
    imNeedsHearingProposal_weakness: e.optional(e.string()),
    imSellerUnderstanding: e.optional(e.number()),
    imSellerUnderstanding_analysis: e.optional(e.string()),
    imSellerUnderstanding_strength: e.optional(e.string()),
    imSellerUnderstanding_weakness: e.optional(e.string()),
    imBuyerUnderstanding: e.optional(e.number()),
    imBuyerUnderstanding_analysis: e.optional(e.string()),
    imBuyerUnderstanding_strength: e.optional(e.string()),
    imBuyerUnderstanding_weakness: e.optional(e.string()),
    imSynergyProposal: e.optional(e.number()),
    imSynergyProposal_analysis: e.optional(e.string()),
    imSynergyProposal_strength: e.optional(e.string()),
    imSynergyProposal_weakness: e.optional(e.string()),
    imTestClosing: e.optional(e.number()),
    imTestClosing_analysis: e.optional(e.string()),
    imTestClosing_strength: e.optional(e.string()),
    imTestClosing_weakness: e.optional(e.string()),
    // 譲渡架電評価項目
    callTone: e.optional(e.number()),
    callTone_analysis: e.optional(e.string()),
    callTone_strength: e.optional(e.string()),
    callTone_weakness: e.optional(e.string()),
    callListening: e.optional(e.number()),
    callListening_analysis: e.optional(e.string()),
    callListening_strength: e.optional(e.string()),
    callListening_weakness: e.optional(e.string()),
    callScheduling: e.optional(e.number()),
    callScheduling_analysis: e.optional(e.string()),
    callScheduling_strength: e.optional(e.string()),
    callScheduling_weakness: e.optional(e.string()),
    callImportantInfo: e.optional(e.number()),
    callImportantInfo_analysis: e.optional(e.string()),
    callImportantInfo_strength: e.optional(e.string()),
    callImportantInfo_weakness: e.optional(e.string()),
    callDeepHearing: e.optional(e.number()),
    callDeepHearing_analysis: e.optional(e.string()),
    callDeepHearing_strength: e.optional(e.string()),
    callDeepHearing_weakness: e.optional(e.string()),
    // 総合評価コメント
    overallComment: e.optional(e.string()),
    improvementSummary: e.optional(e.string()),
    // AI評価メタデータ
    ai_model: e.optional(e.string()),
    processing_duration_ms: e.optional(e.number()),
    retry_count: e.optional(e.number()),
    error_message: e.optional(e.string()),
    evaluation_requested_at: e.optional(e.number()),
    evaluation_completed_at: e.optional(e.number())
  }).index("by_transcription_id", ["transcription_id"]).index("by_video_id", ["video_id"]).index("by_user_id", ["user_id"]).index("by_video_type", ["video_type"]).index("by_status", ["status"]).index("by_status_and_user", ["status", "user_id"]).index("by_video_type_and_status", ["video_type", "status"]).index("by_user_and_video_type", ["user_id", "video_type"]).index("by_created_time", ["evaluation_requested_at"]).index("by_status_and_created", ["status", "evaluation_requested_at"]).index("by_user_and_created", ["user_id", "evaluation_requested_at"]).index("by_external_id", ["external_id"]),
  roleplays: o({
    title: e.string(),
    description: e.optional(e.string()),
    type: e.string(),
    status: e.string(),
    max_participants: e.optional(e.number()),
    scheduled_at: e.optional(e.number()),
    completed_at: e.optional(e.number()),
    created_by: e.id("users")
  }).index("by_created_by", ["created_by"]).index("by_status", ["status"]).index("by_type", ["type"]),
  roleplayParticipants: o({
    roleplay_id: e.id("roleplays"),
    user_id: e.id("users"),
    // Updated from better_auth_users to users (migration complete)
    is_creator: e.boolean(),
    role: e.optional(e.string())
  }).index("by_roleplay_id", ["roleplay_id"]).index("by_user_id", ["user_id"]),
  // PHASE 3 COMPLETED: roleplayMaterials table safely deleted
  // No roleplay materials data existed in the system
  // Migration completed: Roleplay materials system removed
  videoReviews: o({
    video_id: e.id("videos"),
    user_id: e.id("users"),
    rating: e.optional(e.number()),
    comments: e.optional(e.string())
  }).index("by_video_id", ["video_id"]),
  managerReviews: o({
    video_id: e.id("videos"),
    reviewer_id: e.id("users"),
    overall_rating: e.number(),
    comments: e.string(),
    category_scores: e.optional(e.object({
      listening_skills: e.optional(e.number()),
      proposal_design: e.optional(e.number()),
      knowledge: e.optional(e.number()),
      responsiveness: e.optional(e.number()),
      business_manner: e.optional(e.number())
    }))
  }).index("by_video_id", ["video_id"]).index("by_reviewer_id", ["reviewer_id"]).index("by_video_and_reviewer", ["video_id", "reviewer_id"]),
  moduleQuizzes: o({
    module_id: e.id("trainingModules"),
    title: e.string(),
    description: e.optional(e.string())
  }).index("by_module_id", ["module_id"]),
  quizQuestions: o({
    quiz_id: e.id("moduleQuizzes"),
    question_text: e.string(),
    question_type: e.string(),
    options: e.optional(
      e.array(
        e.object({
          value: e.string(),
          label: e.string(),
          isCorrect: e.optional(e.boolean())
        })
      )
    ),
    correct_answer: e.optional(e.string()),
    explanation: e.optional(e.string())
  }).index("by_quiz_id", ["quiz_id"]),
  quizAttempts: o({
    user_id: e.id("users"),
    quiz_id: e.id("moduleQuizzes"),
    answers: e.record(e.string(), e.union(e.string(), e.number(), e.boolean())),
    is_passed: e.boolean()
    // Removed migration field: new_user_id (Phase 2 cleanup - migration complete)
  }).index("by_user_quiz", ["user_id", "quiz_id"]),
  transcriptions: o({
    // Polymorphic relation - strict typing for resource types
    resource_type: e.union(
      e.literal("video"),
      e.literal("training_content"),
      e.literal("quick_transcription")
    ),
    resource_id: e.string(),
    // ID as string to handle both video and moduleContent IDs
    video_id: e.optional(e.id("videos")),
    // For backwards compatibility
    // Basic transcription data
    text: e.string(),
    segments: e.optional(
      e.array(
        e.object({
          start: e.number(),
          end: e.number(),
          text: e.string(),
          speaker: e.optional(e.string()),
          confidence: e.optional(e.number())
        })
      )
    ),
    // Array of transcription segments with timestamps (deprecated for large files)
    segments_url: e.optional(e.string()),
    // Cloud Storage URL for segment data (for large files)
    formatted_text: e.optional(e.string()),
    // Text with speaker labels
    transcript_with_speaker: e.optional(e.string()),
    // Speaker-based transcript
    speaker_analysis_status: e.optional(
      e.union(
        e.literal("pending"),
        e.literal("processing"),
        e.literal("completed"),
        e.literal("failed")
      )
    ),
    // 話者解析の状態
    status: e.union(
      e.literal("pending"),
      e.literal("processing"),
      e.literal("completed"),
      e.literal("failed")
    ),
    // File metadata
    original_file_url: e.optional(e.string()),
    original_file_type: e.optional(e.string()),
    duration_seconds: e.optional(e.number()),
    // Processing options
    enable_speaker_diarization: e.optional(e.boolean()),
    enable_ai_evaluation: e.optional(e.boolean()),
    // For videos
    enable_content_analysis: e.optional(e.boolean()),
    // For training content
    language: e.optional(e.string()),
    // Video-specific AI analysis results
    meeting_minutes: e.optional(e.any()),
    meeting_minutes_status: e.optional(
      e.union(
        e.literal("pending"),
        e.literal("processing"),
        e.literal("completed"),
        e.literal("failed")
      )
    ),
    meeting_minutes_generated_at: e.optional(e.number()),
    case_summary: e.optional(e.any()),
    case_summary_status: e.optional(
      e.union(
        e.literal("pending"),
        e.literal("processing"),
        e.literal("completed"),
        e.literal("failed")
      )
    ),
    case_summary_generated_at: e.optional(e.number()),
    case_summary_processing_started_at: e.optional(e.number()),
    meeting_summary: e.optional(e.any()),
    meeting_summary_status: e.optional(
      e.union(
        e.literal("pending"),
        e.literal("processing"),
        e.literal("completed"),
        e.literal("failed")
      )
    ),
    meeting_summary_generated_at: e.optional(e.number()),
    meeting_summary_processing_started_at: e.optional(e.number()),
    // Training content-specific AI analysis results
    content_summary: e.optional(
      e.object({
        title: e.string(),
        summary: e.string(),
        learningObjectives: e.optional(e.array(e.string())),
        keyTerms: e.optional(e.array(e.string())),
        difficulty: e.optional(e.string())
      })
    ),
    content_summary_status: e.optional(
      e.union(
        e.literal("pending"),
        e.literal("processing"),
        e.literal("completed"),
        e.literal("failed")
      )
    ),
    content_summary_generated_at: e.optional(e.number()),
    key_points: e.optional(
      e.array(
        e.object({
          point: e.string(),
          importance: e.optional(e.string()),
          timestamp: e.optional(e.number()),
          category: e.optional(e.string())
        })
      )
    ),
    key_points_status: e.optional(
      e.union(
        e.literal("pending"),
        e.literal("processing"),
        e.literal("completed"),
        e.literal("failed")
      )
    ),
    key_points_generated_at: e.optional(e.number()),
    quiz_material: e.optional(
      e.object({
        questions: e.array(
          e.object({
            question: e.string(),
            type: e.string(),
            options: e.optional(e.array(e.string())),
            correctAnswer: e.string(),
            explanation: e.optional(e.string()),
            difficulty: e.optional(e.string())
          })
        ),
        totalQuestions: e.number(),
        estimatedTime: e.optional(e.number())
      })
    ),
    quiz_material_status: e.optional(
      e.union(
        e.literal("pending"),
        e.literal("processing"),
        e.literal("completed"),
        e.literal("failed")
      )
    ),
    quiz_material_generated_at: e.optional(e.number()),
    // Evaluation results (for videos using AI workflow)
    evaluation: e.optional(e.any()),
    evaluation_status: e.optional(
      e.union(
        e.literal("pending"),
        e.literal("processing"),
        e.literal("completed"),
        e.literal("failed")
      )
    ),
    evaluation_generated_at: e.optional(e.number()),
    // Quick transcription specific fields
    quick_transcription: e.optional(
      e.object({
        original_filename: e.string(),
        file_size: e.number(),
        duration_seconds: e.optional(e.number()),
        temporary: e.boolean(),
        expires_at: e.optional(e.number()),
        transcription_type: e.string(),
        custom_prompt: e.optional(e.string()),
        // 議事録関連フィールド
        meeting_minutes: e.optional(
          e.object({
            summary: e.string(),
            keyPoints: e.string(),
            actionItems: e.string(),
            participants: e.string(),
            duration: e.string()
          })
        ),
        meeting_minutes_status: e.optional(
          e.union(
            e.literal("pending"),
            e.literal("processing"),
            e.literal("completed"),
            e.literal("failed")
          )
        ),
        meeting_minutes_generated_at: e.optional(e.number()),
        transcript_with_speaker: e.optional(e.string())
      })
    ),
    // Processing metadata
    confidence_score: e.optional(e.string()),
    processing_duration_ms: e.optional(e.number()),
    error_message: e.optional(e.string()),
    retry_count: e.optional(e.number()),
    // Audio file analysis results (for parallel processing)
    evaluation_result: e.optional(e.string()),
    // JSON string of evaluation result
    audio_analysis_completed: e.optional(e.boolean()),
    // Flag for analysis completion
    audio_analysis_processing_time: e.optional(e.number()),
    // Processing time in ms
    analysis_completed_at: e.optional(e.number()),
    // Timestamp when analysis completed
    audio_analysis_error: e.optional(e.string()),
    // エラーメッセージ
    // Storage-based AI analysis results (performAsyncSyscall対策)
    evaluation_file_id: e.optional(e.id("_storage")),
    // 評価結果のストレージファイルID
    meeting_minutes_file_id: e.optional(e.id("_storage")),
    // 議事録のストレージファイルID
    case_summary_file_id: e.optional(e.id("_storage")),
    // 案件化サマリーのストレージファイルID
    meeting_summary_file_id: e.optional(e.id("_storage")),
    // 商談記録サマリーのストレージファイルID
    // Timestamps
    created_at: e.optional(e.number()),
    updated_at: e.optional(e.number())
  }).index("by_resource", ["resource_type", "resource_id"]).index("by_video_id", ["video_id"]).index("by_status", ["status"]).index("by_resource_type", ["resource_type"]).index("by_resource_status", ["resource_type", "status"]).index("by_created_at", ["created_at"]).index("by_updated_at", ["updated_at"]).index("by_status_and_updated", ["status", "updated_at"]),
  evaluationCriteria: o({
    video_type: e.union(
      e.literal("M&A\u30ED\u30FC\u30EB\u30D7\u30EC\u30A4"),
      e.literal("\u521D\u56DE\u9762\u8AC7"),
      e.literal("AD\u7DE0\u7D50\u63D0\u6848"),
      e.literal("AD\u7DE0\u7D50\u63D0\u6848"),
      e.literal("\u4F01\u696D\u6982\u8981\u66F8\u63D0\u6848"),
      e.literal("\u8B72\u6E21\u67B6\u96FB")
    ),
    criterion_key: e.string(),
    criterion_name: e.string(),
    description: e.optional(e.string()),
    scale: e.object({
      minScore: e.number(),
      maxScore: e.number(),
      description: e.string(),
      scales: e.record(e.string(), e.string())
    }),
    is_active: e.boolean(),
    created_by: e.optional(e.id("users")),
    // Updated from better_auth_users to users (migration complete)
    weight: e.optional(e.number())
    // 評価重みの追加
  }).index("by_video_type", ["video_type"]).index("by_video_type_and_active", ["video_type", "is_active"]).index("by_created_by", ["created_by"]),
  evaluationDetails: o({
    evaluation_id: e.id("evaluations"),
    video_type: e.union(
      e.literal("M&A\u30ED\u30FC\u30EB\u30D7\u30EC\u30A4"),
      e.literal("\u521D\u56DE\u9762\u8AC7"),
      e.literal("AD\u7DE0\u7D50\u63D0\u6848"),
      e.literal("AD\u7DE0\u7D50\u63D0\u6848"),
      e.literal("\u4F01\u696D\u6982\u8981\u66F8\u63D0\u6848"),
      e.literal("\u8B72\u6E21\u67B6\u96FB")
    ),
    final_score: e.number(),
    recommendation: e.union(
      e.literal("\u5408\u683C"),
      e.literal("\u8981\u6539\u5584"),
      e.literal("\u4E0D\u5408\u683C"),
      e.literal("\u51E6\u7406\u4E2D"),
      e.literal("\u30A8\u30E9\u30FC")
    ),
    good_points: e.optional(e.array(e.string())),
    improvement_points: e.optional(e.array(e.string())),
    recommended_actions: e.optional(e.array(e.string())),
    evaluation_details: e.optional(
      e.record(
        e.string(),
        e.union(
          e.number(),
          e.string(),
          e.boolean(),
          e.object({
            score: e.number(),
            analysis: e.string(),
            strength: e.optional(e.string()),
            weakness: e.optional(e.string())
          })
        )
      )
    ),
    retry_count: e.number(),
    evaluation_id_external: e.optional(e.string()),
    // 外部システムとの互換性用
    status: e.optional(
      e.union(
        e.literal("pending"),
        e.literal("processing"),
        e.literal("completed"),
        e.literal("failed")
      )
    ),
    manager_review: e.optional(
      e.object({
        comments: e.string(),
        overrideScore: e.optional(e.number()),
        overrideRecommendation: e.optional(e.string()),
        reviewedAt: e.number(),
        reviewerId: e.id("users")
        // Updated from better_auth_users to users (migration complete)
      })
    )
  }).index("by_evaluation_id", ["evaluation_id"]).index("by_external_id", ["evaluation_id_external"]).index("by_video_type", ["video_type"]).index("by_status", ["status"]),
  // PHASE 1 COMPLETED: humanEvaluations table safely deleted
  // Human evaluation functionality was not implemented
  // All evaluation functionality now uses AI-based evaluations only
  // Migration completed: Unused evaluation system removed
  // PHASE 1 COMPLETED: evaluationAccuracyLogs table safely deleted
  // Evaluation accuracy logging was limitedly used in admin functions
  // Statistical functionality can be replaced by alternative methods
  // Migration completed: Accuracy tracking system removed
  userSettings: o({
    user_id: e.id("users"),
    // Migration: Updated to unified users table
    theme: e.string(),
    language: e.string(),
    timezone: e.string(),
    dashboard_layout: e.optional(
      e.object({
        layout: e.string(),
        widgets: e.optional(
          e.array(
            e.object({
              id: e.string(),
              type: e.string(),
              position: e.object({ x: e.number(), y: e.number() }),
              size: e.object({ width: e.number(), height: e.number() }),
              config: e.optional(
                e.record(e.string(), e.union(e.string(), e.number(), e.boolean()))
              )
            })
          )
        )
      })
    ),
    items_per_page: e.number(),
    default_chart_period: e.string(),
    video_quality: e.string(),
    enable_subtitles: e.boolean(),
    learning_reminder: e.boolean(),
    reminder_time: e.optional(e.string()),
    reminder_days: e.optional(
      e.array(
        e.union(
          e.literal("monday"),
          e.literal("tuesday"),
          e.literal("wednesday"),
          e.literal("thursday"),
          e.literal("friday"),
          e.literal("saturday"),
          e.literal("sunday")
        )
      )
    ),
    session_timeout_minutes: e.number(),
    two_factor_enabled: e.boolean(),
    login_notification: e.boolean(),
    auto_save_enabled: e.boolean(),
    auto_save_interval_seconds: e.number(),
    show_tips: e.boolean()
    // Removed migration field: new_user_id (Phase 2 cleanup - migration complete)
  }).index("by_user_id", ["user_id"]),
  trainingSummaries: o({
    training_id: e.id("trainings"),
    summary: e.string(),
    content_hash: e.optional(e.string()),
    last_updated_content_id: e.optional(e.number()),
    ai_model: e.string()
  }).index("by_training_id", ["training_id"]),
  // Unified chat conversations table (enhanced for Convex Agent compatibility)
  chatConversations: o({
    user_id: e.id("users"),
    // Migration: Updated to unified users table
    session_id: e.string(),
    role: e.string(),
    message: e.string(),
    context_training_ids: e.optional(e.array(e.string())),
    ai_model: e.optional(e.string()),
    // Enhanced fields for Convex Agent compatibility
    thread_id: e.optional(e.string()),
    // Convex Agent thread reference
    metadata: e.optional(
      e.object({
        timestamp: e.number(),
        messageLength: e.optional(e.number()),
        generated: e.optional(e.boolean()),
        modelVersion: e.optional(e.string()),
        responseTime: e.optional(e.number()),
        confidence: e.optional(e.number())
      })
    )
    // Structured metadata for AI context
  }).index("by_session_id", ["session_id"]).index("by_thread_id", ["thread_id"]).index("by_user_id", ["user_id"]),
  // Chat sessions table for managing conversation sessions
  chatSessions: o({
    session_id: e.string(),
    user_id: e.optional(e.id("users")),
    // Updated from better_auth_users to users (migration complete)
    legacy_user_id: e.optional(e.string()),
    // Historical legacy user ID (string)
    thread_id: e.optional(e.string()),
    // Convex Agent thread ID
    title: e.optional(e.string()),
    status: e.string(),
    // "active", "completed", "archived"
    last_message_at: e.optional(e.number()),
    context_summary: e.optional(e.string()),
    training_context_ids: e.optional(e.array(e.string()))
  }).index("by_session_id", ["session_id"]).index("by_user_id", ["user_id"]).index("by_thread_id", ["thread_id"]).index("by_status", ["status"]),
  // Chat activity logging for monitoring and analytics (simplified)
  chatActivityLogs: o({
    session_id: e.string(),
    user_id: e.optional(e.id("users")),
    // Updated from better_auth_users to users (migration complete)
    action: e.string(),
    // Simplified from union type
    timestamp: e.number(),
    metadata: e.optional(e.string())
    // JSON string to avoid deep type instantiation
  }).index("by_session_id", ["session_id"]).index("by_user_id", ["user_id"]).index("by_action", ["action"]).index("by_timestamp", ["timestamp"]),
  cases: o({
    title: e.string(),
    company_name: e.string(),
    description: e.optional(e.string()),
    status: e.union(
      e.literal("active"),
      e.literal("completed"),
      e.literal("on_hold"),
      e.literal("cancelled")
    ),
    created_by: e.id("users"),
    assigned_to: e.optional(e.id("users")),
    overall_progress: e.number(),
    priority: e.union(e.literal("high"), e.literal("medium"), e.literal("low")),
    due_date: e.optional(e.number()),
    interview_data: e.optional(
      e.object({
        questions: e.optional(
          e.array(
            e.object({
              question: e.string(),
              answer: e.optional(e.string()),
              category: e.optional(e.string()),
              importance: e.optional(e.string())
            })
          )
        ),
        notes: e.optional(e.string()),
        interviewer: e.optional(e.string()),
        interview_date: e.optional(e.number()),
        follow_up_required: e.optional(e.boolean())
      })
    )
  }).index("by_assigned_to", ["assigned_to"]).index("by_created_by", ["created_by"]).index("by_status", ["status"]).index("by_priority", ["priority"]),
  case_progress: o({
    case_id: e.id("cases"),
    item_id: e.string(),
    category: e.string(),
    label: e.string(),
    description: e.optional(e.string()),
    weight: e.number(),
    priority: e.union(e.literal("high"), e.literal("medium"), e.literal("low")),
    status: e.union(
      e.literal("completed"),
      e.literal("partial"),
      e.literal("missing"),
      e.literal("in_progress")
    ),
    completed_at: e.optional(e.number()),
    notes: e.optional(e.string()),
    collected_data: e.optional(
      e.record(e.string(), e.union(e.string(), e.number(), e.boolean(), e.array(e.string())))
    )
  }).index("by_case_id", ["case_id"]).index("by_status", ["status"]).index("by_priority", ["priority"]).index("by_case_status", ["case_id", "status"]),
  // ファイルアップロード管理（拡張）
  fileUploads: o({
    // ユーザー情報
    user_id: e.id("users"),
    // Updated from better_auth_users to users (migration complete)
    // ファイル基本情報
    original_filename: e.string(),
    content_type: e.string(),
    file_size: e.number(),
    // ストレージ情報（GCS専用）
    gcp_file_path: e.string(),
    // GCP Cloud Storage専用（必須）
    storage_id: e.optional(e.string()),
    // Convex Storage ID（クイック文字起こし用）
    // アップロード種別
    upload_type: e.union(
      e.literal("video"),
      e.literal("training"),
      e.literal("thumbnail"),
      e.literal("course_thumbnail"),
      e.literal("module_content"),
      e.literal("roleplay_material"),
      e.literal("quick_transcription")
    ),
    // ステータス管理（原子的アップロード対応）
    status: e.union(
      e.literal("preparing"),
      // フェーズ1: DB予約レコード作成済み
      e.literal("pending"),
      // フェーズ2: GCS URL生成済み、アップロード待ち
      e.literal("uploading"),
      // アップロード中
      e.literal("completed"),
      // 完了
      e.literal("failed"),
      // 失敗
      e.literal("processing")
      // 後処理中
    ),
    // 関連リソースID（型安全化）
    related_resource_type: e.optional(
      e.union(
        e.literal("video"),
        e.literal("training"),
        e.literal("trainingModule"),
        e.literal("moduleContent"),
        e.literal("roleplay"),
        e.literal("quick_transcription")
      )
    ),
    related_resource_id: e.optional(
      e.union(
        e.id("videos"),
        e.id("trainings"),
        e.id("trainingModules"),
        e.id("moduleContents"),
        e.id("roleplays"),
        e.id("transcriptions")
      )
    ),
    // 処理結果
    public_url: e.optional(e.string()),
    processing_error: e.optional(e.string()),
    // 拡張メタデータ
    duration_seconds: e.optional(e.number()),
    // 動画・音声ファイル用
    resolution: e.optional(
      e.object({
        // 動画・画像ファイル用
        width: e.number(),
        height: e.number()
      })
    ),
    video_codec: e.optional(e.string()),
    // 動画ファイル用
    audio_codec: e.optional(e.string()),
    // 動画・音声ファイル用
    bitrate: e.optional(e.number()),
    // 動画・音声ファイル用
    frame_rate: e.optional(e.number()),
    // 動画ファイル用
    // サムネイル管理（GCS対応）
    thumbnail_generated: e.optional(e.boolean()),
    thumbnail_gcp_paths: e.optional(
      e.array(
        e.object({
          // 複数サイズサムネイル（GCS）
          size: e.string(),
          // "small", "medium", "large", "poster"
          gcp_file_path: e.string(),
          url: e.string(),
          file_size: e.number(),
          width: e.number(),
          height: e.number()
        })
      )
    ),
    // 文字起こし・AI処理
    transcription_started: e.optional(e.boolean()),
    transcription_id: e.optional(e.id("transcriptions")),
    // 品質分析
    quality_score: e.optional(e.number()),
    // 0-100
    quality_analysis: e.optional(
      e.object({
        audio_quality: e.optional(e.number()),
        video_quality: e.optional(e.number()),
        compression_ratio: e.optional(e.number()),
        recommended_settings: e.optional(e.string())
      })
    ),
    // 重複検出
    file_hash: e.optional(e.string()),
    // SHA-256ハッシュ
    duplicate_of: e.optional(e.id("fileUploads")),
    // 重複元ファイル
    // 使用量統計
    view_count: e.optional(e.number()),
    download_count: e.optional(e.number()),
    last_accessed: e.optional(e.number()),
    // タイムスタンプ
    uploaded_at: e.optional(e.number()),
    completed_at: e.optional(e.number()),
    metadata_processed_at: e.optional(e.number())
  }).index("by_user_id", ["user_id"]).index("by_status", ["status"]).index("by_upload_type", ["upload_type"]).index("by_user_status", ["user_id", "status"]).index("by_user_type", ["user_id", "upload_type"]).index("by_status_uploaded", ["status", "uploaded_at"]).index("by_related_resource", ["related_resource_type", "related_resource_id"]).index("by_file_hash", ["file_hash"]).index("by_duplicate_of", ["duplicate_of"]).index("by_quality_score", ["quality_score"]).index("by_last_accessed", ["last_accessed"]),
  // PHASE 3 COMPLETED: uploadProgress table safely deleted
  // Upload progress tracking was unused as fileUploads provides sufficient progress management
  // Migration completed: Upload progress tracking system removed
  // === External Integration Tables ===
  // All external AI integration tables have been removed
  // === 通知システム（簡素化版） ===
  // 複雑な型定義を避けるため、notification.tsから簡素化されたスキーマを使用
  // 基本通知テーブル（既存との互換性を保つため）
  notifications: o({
    user_id: e.id("users"),
    type: e.string(),
    title: e.string(),
    message: e.string(),
    data: e.optional(e.string()),
    // JSON文字列として簡素化
    is_read: e.boolean()
  }).index("by_user_id_and_read", ["user_id", "is_read"]).index("by_type", ["type"]).index("by_user_id_and_type", ["user_id", "type"]),
  // 基本通知設定テーブル（既存との互換性を保つため）
  notificationSettings: o({
    user_id: e.id("users"),
    notification_type: e.string(),
    email_enabled: e.boolean(),
    system_enabled: e.boolean(),
    slack_enabled: e.boolean()
  }).index("by_user_id", ["user_id"]).index("by_user_id_and_type", ["user_id", "notification_type"]),
  // 拡張通知システム（簡素化版）
  ...de,
  // Slack統合設定（slack.ts用に調整）
  slackIntegrations: o({
    organization_id: e.optional(e.number()),
    webhook_url: e.string(),
    channel_name: e.string(),
    is_active: e.boolean(),
    created_by: e.id("users")
  }).index("by_created_by", ["created_by"]).index("by_created_by_and_active", ["created_by", "is_active"]),
  // OAuth token management for Slack integrations
  slackOAuthTokens: o({
    user_id: e.id("users"),
    team_id: e.string(),
    team_name: e.string(),
    access_token: e.string(),
    bot_user_id: e.optional(e.string()),
    scope: e.string(),
    is_active: e.boolean(),
    expires_at: e.optional(e.number()),
    last_used_at: e.optional(e.number())
  }).index("by_user_id", ["user_id"]).index("by_team_id", ["team_id"]).index("by_user_and_team", ["user_id", "team_id"]).index("by_is_active", ["is_active"]),
  // Slack通知設定（ユーザー別）
  slackNotificationSettings: o({
    // ユーザー参照
    user_id: e.id("users"),
    // Updated from better_auth_users to users (migration complete)
    oauth_token_id: e.id("slackOAuthTokens"),
    // 通知種類別チャンネル設定
    evaluation_complete_channel_id: e.optional(e.string()),
    roleplay_application_channel_id: e.optional(e.string()),
    weekly_report_channel_id: e.optional(e.string()),
    system_notification_channel_id: e.optional(e.string()),
    // デフォルト設定
    default_channel_id: e.string(),
    // 高度な設定
    enable_direct_message: e.boolean(),
    notification_quiet_hours_start: e.optional(e.string()),
    notification_quiet_hours_end: e.optional(e.string())
  }).index("by_user_and_oauth", ["user_id", "oauth_token_id"]),
  // メール送信ログ
  // PHASE 1 COMPLETED: emailLogs table safely deleted
  // Email notification logging can be handled by external email service providers
  // Migration completed: Email logging system removed
  // PHASE 3 COMPLETED: rateLimitRecords table safely deleted
  // Rate limiting can be handled by Clerk authentication system
  // Migration completed: Rate limiting system removed
  // === ファイル管理拡張システム ===
  // PHASE 3 COMPLETED: fileMetadata table safely deleted
  // No metadata data existed - can be consolidated into videos table if needed
  // Migration completed: File metadata system removed
  // サムネイル管理システム（ハイブリッドストレージ対応）
  thumbnails: o({
    // ファイル関連（GCS専用）
    file_upload_id: e.id("fileUploads"),
    // サムネイル情報（GCS）
    gcp_file_path: e.string(),
    // GCS上のサムネイルファイルパス
    thumbnail_url: e.string(),
    // サイズ・品質設定
    width: e.number(),
    height: e.number(),
    size_category: e.union(
      e.literal("small"),
      // 150x150
      e.literal("medium"),
      // 300x300
      e.literal("large"),
      // 640x360
      e.literal("poster"),
      // 1280x720（新追加）
      e.literal("custom")
    ),
    // フィールド名統一（新旧両対応）
    size: e.optional(e.string()),
    // 新システム用
    format: e.union(e.literal("webp"), e.literal("jpeg"), e.literal("png")),
    quality: e.number(),
    // 1-100
    file_size: e.number(),
    // 生成設定
    generation_method: e.union(
      e.literal("frame_extraction"),
      // 動画フレーム抽出
      e.literal("image_resize"),
      // 画像リサイズ
      e.literal("document_preview"),
      // 文書プレビュー
      e.literal("auto_generated")
      // 自動生成
    ),
    frame_time: e.optional(e.number()),
    // 動画の場合、抽出時間（秒）
    // ステータス管理
    generation_status: e.union(
      e.literal("pending"),
      e.literal("processing"),
      e.literal("completed"),
      e.literal("failed")
    ),
    generation_error: e.optional(e.string()),
    generated_at: e.optional(e.number()),
    // 最適化情報
    optimized: e.boolean(),
    compression_ratio: e.optional(e.number())
  }).index("by_file_upload_id", ["file_upload_id"]).index("by_size_category", ["size_category"]).index("by_generation_status", ["generation_status"]).index("by_generated_at", ["generated_at"]),
  // サムネイル生成ジョブ管理
  // PHASE 1 COMPLETED: thumbnailJobs table safely deleted
  // Thumbnail functionality can be consolidated into the main thumbnail processing system
  // Migration completed: Thumbnail job management system removed
  // PHASE 3 COMPLETED: fileQualityAnalysis table safely deleted
  // No quality analysis data existed - can be consolidated into videos table if needed
  // Migration completed: File quality analysis system removed
  // ファイル重複検出
  // PHASE 1 COMPLETED: fileDuplicates table safely deleted
  // Limited usage in metadata.ts can be replaced by file hash-based duplicate detection
  // Migration completed: File duplication detection system removed
  // ファイル使用量統計
  // PHASE 1 COMPLETED: fileUsageStats table safely deleted
  // Statistical functionality can be handled by external analytics services
  // Migration completed: File usage statistics system removed
  // PHASE 3 COMPLETED: processingJobs table safely deleted
  // Generic job processing had alternative implementations available
  // Migration completed: Generic job processing system removed
  // PHASE 3 COMPLETED: encryptionAuditLog table safely deleted
  // No encryption audit data existed - security requirements can be met through alternative methods
  // Migration completed: Encryption audit logging system removed
  // === 議事録の型管理 ===
  // 議事録の型を管理するテーブル（動画アップロード・クイック文字起こし用）
  transcriptionTypes: o({
    // 基本情報
    name: e.string(),
    // 型の名前（例：営業商談用、面接用、研修用）
    description: e.string(),
    // 型の説明
    key: e.string(),
    // 一意のキー（例：business_meeting, interview, training）
    // プロンプトとテンプレート
    prompt: e.string(),
    // AIに送信するプロンプト
    template: e.optional(e.string()),
    // 出力テンプレート（オプション）
    // 分類・管理
    category: e.optional(e.string()),
    // カテゴリ（例：営業、人事、研修）
    is_system: e.boolean(),
    // システム標準の型かどうか
    is_active: e.boolean(),
    // 使用可能かどうか
    // 使用範囲
    available_for_quick_transcription: e.boolean(),
    // クイック文字起こしで使用可能
    available_for_video_upload: e.boolean(),
    // 動画アップロードで使用可能
    // 作成・管理情報
    created_by: e.optional(e.id("users")),
    // 作成者（システムの場合はnull）
    created_at: e.number(),
    updated_at: e.number(),
    // 表示設定
    display_order: e.number(),
    // 表示順序
    icon: e.optional(e.string()),
    // アイコン（オプション）
    color: e.optional(e.string()),
    // カラー（オプション）
    // 統計情報
    usage_count: e.number(),
    // 使用回数
    last_used_at: e.optional(e.number())
    // 最終使用日時
  }).index("by_key", ["key"]).index("by_is_active", ["is_active"]).index("by_category", ["category"]).index("by_created_by", ["created_by"]).index("by_display_order", ["display_order"]).index("by_quick_transcription", ["available_for_quick_transcription", "is_active"]).index("by_video_upload", ["available_for_video_upload", "is_active"]).index("by_usage_count", ["usage_count"]).index("by_last_used", ["last_used_at"]),
  // AI処理ジョブ管理テーブル（Action分割チェーン処理用）
  aiProcessingJobs: o({
    transcription_id: e.id("transcriptions"),
    job_type: e.union(
      e.literal("audio_analysis"),
      // 音声ファイル分析
      e.literal("evaluation"),
      // 評価結果生成
      e.literal("meeting_minutes"),
      // 議事録生成
      e.literal("case_summary"),
      // 案件化サマリー生成
      e.literal("meeting_summary")
      // 商談記録サマリー生成
    ),
    status: e.union(
      e.literal("pending"),
      // 待機中
      e.literal("processing"),
      // 処理中
      e.literal("completed"),
      // 完了
      e.literal("failed"),
      // 失敗
      e.literal("cancelled")
      // キャンセル
    ),
    step: e.optional(e.number()),
    // 現在の処理ステップ（評価→議事録→案件化→商談記録の順）
    total_steps: e.optional(e.number()),
    // 総ステップ数
    current_action: e.optional(e.string()),
    // 現在実行中のAction名
    // 処理結果データ（小さなデータのみ）
    result_data: e.optional(e.string()),
    // JSONストリング（軽量データのみ）
    result_storage_id: e.optional(e.id("_storage")),
    // 大きなデータはストレージに保存
    // エラー情報
    error_message: e.optional(e.string()),
    error_count: e.optional(e.number()),
    last_error_at: e.optional(e.number()),
    // 処理メタデータ
    processing_duration_ms: e.optional(e.number()),
    ai_model: e.optional(e.string()),
    retry_count: e.optional(e.number()),
    max_retries: e.optional(e.number()),
    // 次の処理への引き継ぎ情報
    next_job_id: e.optional(e.id("aiProcessingJobs")),
    // チェーン処理の次のジョブ
    parent_job_id: e.optional(e.id("aiProcessingJobs")),
    // 親ジョブ（全体管理用）
    // タイムスタンプ
    created_at: e.number(),
    started_at: e.optional(e.number()),
    completed_at: e.optional(e.number()),
    updated_at: e.number()
  }).index("by_transcription_id", ["transcription_id"]).index("by_job_type", ["job_type"]).index("by_status", ["status"]).index("by_transcription_status", ["transcription_id", "status"]).index("by_parent_job", ["parent_job_id"]).index("by_created_at", ["created_at"]).index("by_status_created", ["status", "created_at"]),
  // レート制限記録テーブル
  rateLimitRecords: o({
    userId: e.string(),
    action: e.string(),
    count: e.number(),
    windowStart: e.number()
  }).index("by_user_action", ["userId", "action"]).index("by_window_start", ["windowStart"]),
  // セキュリティイベントログテーブル
  securityEvents: o({
    event_type: e.string(),
    // "login_failure", "user_privilege_change", "suspicious_activity", etc.
    severity: e.number(),
    // 1: Low, 2: Medium, 3: High, 4: Critical
    user_id: e.optional(e.id("users")),
    // イベントに関連するユーザー（存在する場合）
    target_user_id: e.optional(e.id("users")),
    // 対象ユーザー（権限変更の場合など）
    ip_address: e.optional(e.string()),
    user_agent: e.optional(e.string()),
    details: e.optional(e.string()),
    // JSON文字列として詳細情報を格納
    created_at: e.number()
  }).index("by_event_type", ["event_type"]).index("by_severity", ["severity"]).index("by_user_id", ["user_id"]).index("by_target_user_id", ["target_user_id"]).index("by_created_at", ["created_at"]).index("by_severity_and_created", ["severity", "created_at"]),
  // マルチパートアップロード管理テーブル
  multipartUploads: o({
    fileUploadId: e.id("fileUploads"),
    // 関連するfileUpload記録
    uploadId: e.string(),
    // マルチパートアップロードの一意ID
    gcpFilePath: e.string(),
    // GCS上のファイルパス
    filename: e.string(),
    // 元のファイル名
    contentType: e.string(),
    // MIMEタイプ
    fileSize: e.number(),
    // ファイルサイズ（バイト）
    totalParts: e.number(),
    // 総パート数
    status: e.string(),
    // "initiated", "in_progress", "completed", "failed"
    // 完了済みパート記録
    completedParts: e.optional(
      e.array(
        e.object({
          partNumber: e.number(),
          etag: e.string(),
          completedAt: e.number()
        })
      )
    ),
    // 再試行記録
    retryAttempts: e.optional(
      e.array(
        e.object({
          partNumber: e.number(),
          attempts: e.number(),
          lastError: e.string(),
          lastAttempt: e.number()
        })
      )
    ),
    // タイムスタンプ
    createdAt: e.optional(e.number()),
    completedAt: e.optional(e.number())
  }).index("by_fileUploadId", ["fileUploadId"]).index("by_fileUploadId_uploadId", ["fileUploadId", "uploadId"]).index("by_status", ["status"]).index("by_created_at", ["createdAt"])
});
export {
  Ui as default
};
//# sourceMappingURL=schema.js.map
