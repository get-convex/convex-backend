import {
  a as p,
  b as _
} from "./_deps/6HNJFR7B.js";
import {
  a as b,
  c as l
} from "./_deps/75JH2J25.js";
import "./_deps/6XQQNYIR.js";
import {
  j as e,
  l as u,
  n as y
} from "./_deps/3TDUHHJO.js";
import {
  a as d
} from "./_deps/RUVYHBJQ.js";

// convex/courseManagement.ts
y();
y();
var C = e.object({
  title: e.string(),
  description: e.string(),
  category: e.string(),
  duration_minutes: e.number(),
  thumbnail_url: e.optional(e.string()),
  is_published: e.optional(e.boolean()),
  created_by: e.id("users"),
  modules_count: e.optional(e.number())
}), q = e.object({
  course_id: e.id("courses"),
  title: e.string(),
  description: e.string(),
  duration_minutes: e.number(),
  order_index: e.number(),
  content_type: e.string(),
  // "video", "text", "quiz", etc.
  content_url: e.optional(e.string()),
  is_published: e.optional(e.boolean())
}), j = l({
  args: {
    title: e.string(),
    description: e.string(),
    category: e.string(),
    duration_minutes: e.number(),
    thumbnail_url: e.optional(e.string())
  },
  returns: e.object({
    success: e.boolean(),
    courseId: e.optional(e.id("courses")),
    message: e.string(),
    data: e.optional(
      e.object({
        _id: e.id("courses"),
        title: e.string(),
        description: e.string(),
        category: e.string(),
        duration_minutes: e.number(),
        thumbnail_url: e.optional(e.string()),
        is_published: e.boolean(),
        created_by: e.id("users"),
        modules_count: e.number(),
        _creationTime: e.number()
      })
    )
  }),
  handler: /* @__PURE__ */ d(async (r, t) => {
    let n = await _(r);
    if (await r.db.query("courses").withIndex("by_title", (i) => i.eq("title", t.title)).first())
      throw new u("\u540C\u3058\u540D\u524D\u306E\u30B3\u30FC\u30B9\u304C\u65E2\u306B\u5B58\u5728\u3057\u307E\u3059");
    try {
      let i = await r.db.insert("courses", {
        title: t.title,
        description: t.description,
        category: t.category,
        duration_minutes: t.duration_minutes,
        ...t.thumbnail_url && { thumbnail_url: t.thumbnail_url },
        is_published: !1,
        // 作成時は未公開
        created_by: n.user._id,
        modules_count: 0
      }), s = await r.db.get(i);
      if (!s)
        throw new u("\u4F5C\u6210\u3055\u308C\u305F\u30B3\u30FC\u30B9\u306E\u53D6\u5F97\u306B\u5931\u6557\u3057\u307E\u3057\u305F");
      return {
        success: !0,
        courseId: i,
        message: "\u30B3\u30FC\u30B9\u304C\u6B63\u5E38\u306B\u4F5C\u6210\u3055\u308C\u307E\u3057\u305F",
        data: s
      };
    } catch (i) {
      throw console.error("Course creation error:", i), new u("\u30B3\u30FC\u30B9\u4F5C\u6210\u306B\u5931\u6557\u3057\u307E\u3057\u305F");
    }
  }, "handler")
}), x = b({
  args: {
    category: e.optional(e.string()),
    search: e.optional(e.string()),
    page: e.optional(e.number()),
    limit: e.optional(e.number()),
    published_only: e.optional(e.boolean())
  },
  returns: e.object({
    courses: e.array(
      e.object({
        _id: e.id("courses"),
        title: e.string(),
        description: e.string(),
        category: e.string(),
        duration_minutes: e.number(),
        thumbnail_url: e.optional(e.string()),
        is_published: e.boolean(),
        created_by: e.id("users"),
        modules_count: e.number(),
        _creationTime: e.number()
      })
    ),
    total: e.number(),
    hasMore: e.boolean()
  }),
  handler: /* @__PURE__ */ d(async (r, t) => {
    await p(r);
    let n;
    t.category ? n = await r.db.query("courses").withIndex("by_category", (c) => c.eq("category", t.category)).collect() : n = await r.db.query("courses").order("desc").collect();
    let o = n;
    if (t.published_only && (o = o.filter((c) => c.is_published)), t.search) {
      let c = t.search.toLowerCase();
      o = o.filter(
        (h) => h.title.toLowerCase().includes(c) || h.description.toLowerCase().includes(c)
      );
    }
    let i = t.page || 1, s = t.limit || 20, a = (i - 1) * s;
    return {
      courses: o.slice(a, a + s),
      total: o.length,
      hasMore: o.length > a + s
    };
  }, "handler")
}), T = b({
  args: {
    courseId: e.id("courses")
  },
  returns: e.union(
    e.object({
      _id: e.id("courses"),
      title: e.string(),
      description: e.string(),
      category: e.string(),
      duration_minutes: e.number(),
      thumbnail_url: e.optional(e.string()),
      is_published: e.boolean(),
      created_by: e.id("users"),
      modules_count: e.number(),
      _creationTime: e.number(),
      modules: e.array(
        e.object({
          _id: e.id("modules"),
          course_id: e.id("courses"),
          title: e.string(),
          description: e.string(),
          duration_minutes: e.number(),
          order_index: e.number(),
          content_type: e.string(),
          content_url: e.optional(e.string()),
          is_published: e.boolean(),
          _creationTime: e.number()
        })
      )
    }),
    e.null()
  ),
  handler: /* @__PURE__ */ d(async (r, t) => {
    await p(r);
    let n = await r.db.get(t.courseId);
    if (!n)
      return null;
    let o = await r.db.query("modules").withIndex("by_course", (i) => i.eq("course_id", t.courseId)).order("asc").collect();
    return {
      ...n,
      modules: o.map((i) => ({
        _id: i._id,
        _creationTime: i._creationTime,
        course_id: i.course_id,
        title: i.title,
        description: i.description,
        duration_minutes: i.duration_minutes,
        order_index: i.order_index,
        content_type: i.content_type,
        content_url: i.content_url,
        // undefinedやnullも含めて直接設定
        is_published: i.is_published
      }))
    };
  }, "handler")
}), M = l({
  args: {
    courseId: e.id("courses"),
    updates: e.object({
      title: e.optional(e.string()),
      description: e.optional(e.string()),
      category: e.optional(e.string()),
      duration_minutes: e.optional(e.number()),
      thumbnail_url: e.optional(e.string()),
      is_published: e.optional(e.boolean())
    })
  },
  returns: e.object({
    success: e.boolean(),
    message: e.string()
  }),
  handler: /* @__PURE__ */ d(async (r, t) => {
    let n = await _(r), o = await r.db.get(t.courseId);
    if (!o)
      throw new u("\u30B3\u30FC\u30B9\u304C\u898B\u3064\u304B\u308A\u307E\u305B\u3093");
    if (o.created_by !== n.user._id && n.user.role !== "admin")
      throw new u("\u3053\u306E\u30B3\u30FC\u30B9\u3092\u66F4\u65B0\u3059\u308B\u6A29\u9650\u304C\u3042\u308A\u307E\u305B\u3093");
    if (t.updates.title && t.updates.title !== o.title) {
      let i = await r.db.query("courses").withIndex("by_title", (s) => s.eq("title", t.updates.title)).first();
      if (i && i._id !== t.courseId)
        throw new u("\u540C\u3058\u540D\u524D\u306E\u30B3\u30FC\u30B9\u304C\u65E2\u306B\u5B58\u5728\u3057\u307E\u3059");
    }
    try {
      let i = {};
      return t.updates.title !== void 0 && (i.title = t.updates.title), t.updates.description !== void 0 && (i.description = t.updates.description), t.updates.category !== void 0 && (i.category = t.updates.category), t.updates.duration_minutes !== void 0 && (i.duration_minutes = t.updates.duration_minutes), t.updates.thumbnail_url !== void 0 && (i.thumbnail_url = t.updates.thumbnail_url), t.updates.is_published !== void 0 && (i.is_published = t.updates.is_published), await r.db.patch(t.courseId, i), {
        success: !0,
        message: "\u30B3\u30FC\u30B9\u304C\u66F4\u65B0\u3055\u308C\u307E\u3057\u305F"
      };
    } catch (i) {
      throw console.error("Course update error:", i), new u("\u30B3\u30FC\u30B9\u306E\u66F4\u65B0\u306B\u5931\u6557\u3057\u307E\u3057\u305F");
    }
  }, "handler")
}), L = l({
  args: {
    courseId: e.id("courses")
  },
  returns: e.object({
    success: e.boolean(),
    message: e.string()
  }),
  handler: /* @__PURE__ */ d(async (r, t) => {
    let n = await _(r), o = await r.db.get(t.courseId);
    if (!o)
      throw new u("\u30B3\u30FC\u30B9\u304C\u898B\u3064\u304B\u308A\u307E\u305B\u3093");
    if (o.created_by !== n.user._id && n.user.role !== "admin")
      throw new u("\u3053\u306E\u30B3\u30FC\u30B9\u3092\u524A\u9664\u3059\u308B\u6A29\u9650\u304C\u3042\u308A\u307E\u305B\u3093");
    try {
      let i = await r.db.query("modules").withIndex("by_course", (s) => s.eq("course_id", t.courseId)).collect();
      for (let s of i)
        await r.db.delete(s._id);
      return await r.db.delete(t.courseId), {
        success: !0,
        message: "\u30B3\u30FC\u30B9\u304C\u524A\u9664\u3055\u308C\u307E\u3057\u305F"
      };
    } catch (i) {
      throw console.error("Course deletion error:", i), new u("\u30B3\u30FC\u30B9\u306E\u524A\u9664\u306B\u5931\u6557\u3057\u307E\u3057\u305F");
    }
  }, "handler")
}), v = l({
  args: {
    course_id: e.id("courses"),
    title: e.string(),
    description: e.string(),
    duration_minutes: e.union(e.number(), e.string()),
    // 文字列も受け入れ、内部で変換
    content_type: e.string(),
    content_url: e.optional(e.string())
  },
  returns: e.object({
    success: e.boolean(),
    moduleId: e.optional(e.id("modules")),
    message: e.string()
  }),
  handler: /* @__PURE__ */ d(async (r, t) => {
    if (await p(r), !await r.db.get(t.course_id))
      throw new u("\u30B3\u30FC\u30B9\u304C\u898B\u3064\u304B\u308A\u307E\u305B\u3093");
    try {
      let o = await r.db.query("modules").withIndex("by_course", (m) => m.eq("course_id", t.course_id)).collect(), i = o.length, s = typeof t.duration_minutes == "string" ? Number.parseFloat(t.duration_minutes) : t.duration_minutes, a = await r.db.insert("modules", {
        course_id: t.course_id,
        title: t.title,
        description: t.description,
        duration_minutes: s,
        order_index: i,
        content_type: t.content_type,
        ...t.content_url && { content_url: t.content_url },
        is_published: !1
      });
      return await r.db.patch(t.course_id, {
        modules_count: o.length + 1
      }), {
        success: !0,
        moduleId: a,
        message: "\u30E2\u30B8\u30E5\u30FC\u30EB\u304C\u8FFD\u52A0\u3055\u308C\u307E\u3057\u305F"
      };
    } catch (o) {
      throw console.error("Module addition error:", o), new u("\u30E2\u30B8\u30E5\u30FC\u30EB\u306E\u8FFD\u52A0\u306B\u5931\u6557\u3057\u307E\u3057\u305F");
    }
  }, "handler")
}), V = b({
  args: {},
  returns: e.array(
    e.object({
      _id: e.id("courses"),
      title: e.string(),
      description: e.string(),
      category: e.string(),
      duration_minutes: e.number(),
      thumbnail_url: e.optional(e.string()),
      is_published: e.boolean(),
      modules_count: e.number(),
      _creationTime: e.number()
    })
  ),
  handler: /* @__PURE__ */ d(async (r) => {
    let t = await _(r);
    return await r.db.query("courses").withIndex("by_creator", (o) => o.eq("created_by", t.user._id)).order("desc").collect();
  }, "handler")
});
export {
  v as addModule,
  C as courseValidator,
  j as createCourse,
  L as deleteCourse,
  T as getCourse,
  x as getCourses,
  V as getMyCourses,
  q as moduleValidator,
  M as updateCourse
};
//# sourceMappingURL=courseManagement.js.map
