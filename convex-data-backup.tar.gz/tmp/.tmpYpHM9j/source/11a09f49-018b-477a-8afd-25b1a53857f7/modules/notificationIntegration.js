"use node";
import {
  a as _
} from "./_deps/node/VTOLWO7E.js";
import {
  a as y,
  b as m,
  d as a
} from "./_deps/node/PDGHC3PS.js";
import {
  a as t
} from "./_deps/node/UDHF6CTX.js";
import {
  a as d
} from "./_deps/node/V7X2J7BI.js";

// convex/lib/notificationTypes.ts
var l = {
  EVALUATION_COMPLETE: "evaluation_complete",
  ROLEPLAY_APPLICATION: "roleplay_application",
  SYSTEM: "system",
  TRAINING_REMINDER: "training_reminder",
  WEEKLY_REPORT: "weekly_report"
}, b = t.object({
  video_id: t.optional(t.string()),
  video_title: t.string(),
  score: t.number(),
  link: t.optional(t.string()),
  evaluation_id: t.optional(t.string())
}), N = t.object({
  roleplay_id: t.string(),
  roleplay_title: t.string(),
  applicant_name: t.string(),
  link: t.optional(t.string()),
  application_id: t.optional(t.string())
}), I = t.object({
  level: t.optional(
    t.union(t.literal("info"), t.literal("warning"), t.literal("error"), t.literal("success"))
  ),
  action_url: t.optional(t.string()),
  action_text: t.optional(t.string()),
  metadata: t.optional(t.record(t.string(), t.union(t.string(), t.number(), t.boolean())))
}), E = t.object({
  training_title: t.string(),
  training_id: t.optional(t.string()),
  due_date: t.optional(t.string()),
  link: t.optional(t.string()),
  priority: t.optional(t.union(t.literal("low"), t.literal("medium"), t.literal("high")))
}), w = t.object({
  report_period: t.string(),
  summary: t.string(),
  link: t.optional(t.string()),
  metrics: t.optional(
    t.object({
      videos_watched: t.optional(t.number()),
      evaluations_completed: t.optional(t.number()),
      training_hours: t.optional(t.number())
    })
  )
}), D = t.union(
  // 評価完了通知
  t.object({
    type: t.literal(l.EVALUATION_COMPLETE),
    data: b
  }),
  // ロールプレイ申請通知
  t.object({
    type: t.literal(l.ROLEPLAY_APPLICATION),
    data: N
  }),
  // システム通知
  t.object({
    type: t.literal(l.SYSTEM),
    data: I
  }),
  // 研修リマインダー通知
  t.object({
    type: t.literal(l.TRAINING_REMINDER),
    data: E
  }),
  // 週次レポート通知
  t.object({
    type: t.literal(l.WEEKLY_REPORT),
    data: w
  })
), u = t.optional(
  t.record(t.string(), t.union(t.string(), t.number(), t.boolean()))
), T = t.object({
  user_id: t.id("users"),
  // Migration: Updated from better_auth_users to unified users table
  type: t.union(
    t.literal(l.EVALUATION_COMPLETE),
    t.literal(l.ROLEPLAY_APPLICATION),
    t.literal(l.SYSTEM),
    t.literal(l.TRAINING_REMINDER),
    t.literal(l.WEEKLY_REPORT)
  ),
  title: t.string(),
  message: t.string(),
  data: u,
  // 移行期間中は柔軟性を保つ
  new_user_id: t.optional(t.string())
});

// convex/notificationIntegration.ts
var S = a({
  args: {
    user_id: t.id("users"),
    new_user_id: t.optional(t.string()),
    notification_data: t.object({
      type: t.string(),
      title: t.string(),
      message: t.string(),
      data: u
    })
  },
  returns: t.object({
    success: t.boolean(),
    system_notification_id: t.optional(t.id("notifications")),
    slack_result: t.object({
      success: t.boolean(),
      sent_count: t.number(),
      errors: t.array(t.string())
    }),
    errors: t.array(t.string())
  }),
  handler: /* @__PURE__ */ d(async (o, i) => {
    let n = [], e, c = {
      success: !1,
      sent_count: 0,
      errors: []
    };
    try {
      try {
        e = await m(o, _.notifications.createNotification, {
          target_user_id: i.new_user_id || i.user_id.toString(),
          type: i.notification_data.type,
          title: i.notification_data.title,
          message: i.notification_data.message,
          data: i.notification_data.data
        });
      } catch (r) {
        console.error("Failed to create system notification:", r), n.push(
          `\u30B7\u30B9\u30C6\u30E0\u5185\u901A\u77E5\u306E\u4F5C\u6210\u306B\u5931\u6557: ${r instanceof Error ? r.message : "Unknown error"}`
        );
      }
      if ((await y(
        o,
        _.notificationSettings.getNotificationSetting,
        {
          user_id: i.user_id,
          notification_type: i.notification_data.type
        }
      ))?.slack_enabled)
        try {
          c = await a(
            o,
            _.slackNotifications.sendTypedSlackNotification,
            {
              user_id: i.user_id,
              notification_type: i.notification_data.type,
              title: i.notification_data.title,
              message: i.notification_data.message,
              data: i.notification_data.data
            }
          );
        } catch (r) {
          console.error("Failed to send Slack notification:", r), n.push(
            `Slack\u901A\u77E5\u306E\u9001\u4FE1\u306B\u5931\u6557: ${r instanceof Error ? r.message : "Unknown error"}`
          );
        }
      else
        console.log(
          `Slack notification disabled for user ${i.user_id}, type: ${i.notification_data.type}`
        );
      return {
        success: e !== void 0 || c.success,
        ...e && { system_notification_id: e },
        slack_result: c,
        errors: n
      };
    } catch (s) {
      return console.error("Integrated notification error:", s), n.push(s instanceof Error ? s.message : "Unknown error"), {
        success: !1,
        ...e && { system_notification_id: e },
        slack_result: c,
        errors: n
      };
    }
  }, "handler")
}), h = a({
  args: {
    user_id: t.id("users"),
    new_user_id: t.optional(t.string()),
    video_id: t.optional(t.string()),
    video_title: t.string(),
    score: t.number(),
    evaluation_link: t.optional(t.string())
  },
  returns: t.object({
    success: t.boolean(),
    notification_id: t.optional(t.id("notifications")),
    errors: t.array(t.string())
  }),
  handler: /* @__PURE__ */ d(async (o, i) => {
    let n = i.evaluation_link || `/videos/${i.video_id}`, e = await a(
      o,
      _.notificationIntegration.sendIntegratedNotification,
      {
        user_id: i.user_id,
        ...i.new_user_id && { new_user_id: i.new_user_id },
        notification_data: {
          type: "evaluation_complete",
          title: "\u52D5\u753B\u8A55\u4FA1\u304C\u5B8C\u4E86\u3057\u307E\u3057\u305F",
          message: `\u300C${i.video_title}\u300D\u306E\u8A55\u4FA1\u304C\u5B8C\u4E86\u3057\u307E\u3057\u305F\u3002\u30B9\u30B3\u30A2: ${i.score}\u70B9`,
          data: {
            video_id: i.video_id || "",
            video_title: i.video_title,
            score: i.score,
            link: n
          }
        }
      }
    );
    return {
      success: e.success,
      ...e.system_notification_id && { notification_id: e.system_notification_id },
      errors: e.errors
    };
  }, "handler")
}), j = a({
  args: {
    manager_user_id: t.id("users"),
    manager_new_user_id: t.optional(t.string()),
    applicant_name: t.string(),
    roleplay_id: t.string(),
    roleplay_title: t.string(),
    application_link: t.optional(t.string())
  },
  returns: t.object({
    success: t.boolean(),
    notification_id: t.optional(t.id("notifications")),
    errors: t.array(t.string())
  }),
  handler: /* @__PURE__ */ d(async (o, i) => {
    let n = i.application_link || `/roleplay/${i.roleplay_id}/applications`, e = await a(
      o,
      _.notificationIntegration.sendIntegratedNotification,
      {
        user_id: i.manager_user_id,
        ...i.manager_new_user_id && { new_user_id: i.manager_new_user_id },
        notification_data: {
          type: "roleplay_application",
          title: "\u65B0\u3057\u3044\u30ED\u30FC\u30EB\u30D7\u30EC\u30A4\u7533\u8ACB\u304C\u3042\u308A\u307E\u3059",
          message: `${i.applicant_name}\u3055\u3093\u304B\u3089\u300C${i.roleplay_title}\u300D\u3078\u306E\u7533\u8ACB\u304C\u3042\u308A\u307E\u3057\u305F\u3002`,
          data: {
            roleplay_id: i.roleplay_id,
            roleplay_title: i.roleplay_title,
            applicant_name: i.applicant_name,
            link: n
          }
        }
      }
    );
    return {
      success: e.success,
      ...e.system_notification_id && { notification_id: e.system_notification_id },
      errors: e.errors
    };
  }, "handler")
}), C = a({
  args: {
    user_id: t.id("users"),
    new_user_id: t.optional(t.string()),
    title: t.string(),
    message: t.string(),
    data: u
  },
  returns: t.object({
    success: t.boolean(),
    notification_id: t.optional(t.id("notifications")),
    errors: t.array(t.string())
  }),
  handler: /* @__PURE__ */ d(async (o, i) => {
    let n = await a(
      o,
      _.notificationIntegration.sendIntegratedNotification,
      {
        user_id: i.user_id,
        ...i.new_user_id && { new_user_id: i.new_user_id },
        notification_data: {
          type: "system",
          title: i.title,
          message: i.message,
          data: i.data
        }
      }
    );
    return {
      success: n.success,
      ...n.system_notification_id && { notification_id: n.system_notification_id },
      errors: n.errors
    };
  }, "handler")
}), $ = a({
  args: {
    user_id: t.id("users"),
    new_user_id: t.optional(t.string()),
    training_title: t.string(),
    training_link: t.optional(t.string()),
    due_date: t.optional(t.string())
  },
  returns: t.object({
    success: t.boolean(),
    notification_id: t.optional(t.id("notifications")),
    errors: t.array(t.string())
  }),
  handler: /* @__PURE__ */ d(async (o, i) => {
    let n = i.due_date ? `\u300C${i.training_title}\u300D\u306E\u671F\u9650\u304C\u8FD1\u3065\u3044\u3066\u3044\u307E\u3059\u3002\u671F\u9650: ${i.due_date}` : `\u300C${i.training_title}\u300D\u3092\u5B8C\u4E86\u3057\u3066\u304F\u3060\u3055\u3044\u3002`, e = await a(
      o,
      _.notificationIntegration.sendIntegratedNotification,
      {
        user_id: i.user_id,
        ...i.new_user_id && { new_user_id: i.new_user_id },
        notification_data: {
          type: "training_reminder",
          title: "\u7814\u4FEE\u30EA\u30DE\u30A4\u30F3\u30C0\u30FC",
          message: n,
          data: {
            training_title: i.training_title,
            due_date: i.due_date || "",
            link: i.training_link || ""
          }
        }
      }
    );
    return {
      success: e.success,
      ...e.system_notification_id && { notification_id: e.system_notification_id },
      errors: e.errors
    };
  }, "handler")
}), M = a({
  args: {
    user_ids: t.array(t.id("users")),
    new_user_ids: t.optional(t.array(t.string())),
    notification_data: t.object({
      type: t.string(),
      title: t.string(),
      message: t.string(),
      data: u
    })
  },
  returns: t.object({
    success: t.boolean(),
    sent_count: t.number(),
    failed_count: t.number(),
    errors: t.array(t.string())
  }),
  handler: /* @__PURE__ */ d(async (o, i) => {
    let n = 0, e = 0, c = [];
    for (let s = 0; s < i.user_ids.length; s++) {
      let r = i.user_ids[s], f = i.new_user_ids?.[s];
      try {
        let p = await a(
          o,
          _.notificationIntegration.sendIntegratedNotification,
          {
            user_id: r,
            ...f && { new_user_id: f },
            notification_data: i.notification_data
          }
        );
        p.success ? n++ : (e++, c.push(`User ${r}: ${p.errors.join(", ")}`));
      } catch (p) {
        e++;
        let g = p instanceof Error ? p.message : "Unknown error";
        c.push(`User ${r}: ${g}`), console.error(`Bulk notification failed for user ${r}:`, p);
      }
    }
    return {
      success: n > 0,
      sent_count: n,
      failed_count: e,
      errors: c
    };
  }, "handler")
}), Y = a({
  args: {
    date_from: t.optional(t.number()),
    date_to: t.optional(t.number())
  },
  returns: t.object({
    total_notifications: t.number(),
    notifications_by_type: t.record(t.string(), t.number()),
    notifications_by_date: t.record(t.string(), t.number())
  }),
  handler: /* @__PURE__ */ d(async (o, i) => {
    let n = Date.now(), e = i.date_from || n - 30 * 24 * 60 * 60 * 1e3, c = i.date_to || n, s = {
      total_notifications: 0,
      notifications_by_type: {},
      notifications_by_date: {}
    };
    return console.log(`Getting notification stats from ${new Date(e)} to ${new Date(c)}`), s;
  }, "handler")
});
export {
  Y as getNotificationStats,
  M as sendBulkNotification,
  h as sendEvaluationCompleteNotification,
  S as sendIntegratedNotification,
  j as sendRoleplayApplicationNotification,
  C as sendSystemNotification,
  $ as sendTrainingReminderNotification
};
//# sourceMappingURL=notificationIntegration.js.map
